import Definitions.FinitePotential
import Definitions.Completion
import Mathlib.Data.Nat.Factorial.Basic

/-! Remaining explicit S1 and B3--B6 estimates. All finite orders and cutoffs are
chosen before the size limit; the factorial and void quantities use the future-walk kernel. -/
noncomputable section
open MeasureTheory ProbabilityTheory Filter
open scoped ENNReal NNReal Topology
namespace TorusCoverTime

def FourierTailIdentities : Prop :=
  (∀ N : Size, ∀ x y : Vertex N, ∀ t : ℝ, 0 ≤ t →
    IntegrableOn (fun s => transitionProbability N x y s - 1 / vertexCount N) (Set.Ici t) ∧
    tailGreen N t x y = ∫ s in Set.Ici t,
      (transitionProbability N x y s - 1 / vertexCount N) ∧
    HasDerivAt (fun s => tailGreen N s x y)
      (-(transitionProbability N x y t - 1 / vertexCount N)) t) ∧
  (∀ N : Size, (∀ k ∈ nonzeroFrequencies N, spectralGap N ≤ finiteEigenvalue N k) ∧
    ∃ k ∈ nonzeroFrequencies N, finiteEigenvalue N k = spectralGap N) ∧
  (∃ C : ℝ, 0 < C ∧ ∀ N : Size,
    |vertexCount N * spectralGap N / Real.pi ^ 2 - 1| ≤ C / vertexCount N) ∧
  Tendsto (fun N => mixingTime N / timeScale N) atTop (𝓝 0)

def GreenDifferenceEstimates : Prop :=
  ∃ C : ℝ, 0 < C ∧ ∀ N : Size,
    (∀ z : Vertex N, 4 ≤ periodicDistance z 0 → ∀ d d' : Fin 4,
      |greenKernel N (z + direction N d) 0 - greenKernel N z 0| ≤
        C / periodicDistance z 0 ∧
      |greenKernel N (z + direction N d + direction N d') 0 -
        greenKernel N (z + direction N d) 0 -
        greenKernel N (z + direction N d') 0 + greenKernel N z 0| ≤
        C / (periodicDistance z 0) ^ 2) ∧
    (∀ D : ℝ, 0 < D → ∀ x x' y y' : Vertex N,
      periodicDistance x x' ≤ D / 4 → periodicDistance y y' ≤ D / 4 →
      D ≤ periodicDistance x y → D ≤ periodicDistance x y' →
      D ≤ periodicDistance x' y → D ≤ periodicDistance x' y' →
      |greenKernel N x y - greenKernel N x' y| ≤ C * periodicDistance x x' / D ∧
      |greenKernel N x y - greenKernel N x' y - greenKernel N x y' + greenKernel N x' y'| ≤
        C * periodicDistance x x' * periodicDistance y y' / D ^ 2) ∧
    (∑ k ∈ nonzeroFrequencies N, 1 / (vertexCount N ^ 2 * finiteEigenvalue N k ^ 2)) ≤ C

def survivalAt (N : Size) (y : Vertex N) (A : Finset (Vertex N)) (t : ℝ) : ℝ :=
  (walkLaw {ω | ∀ a ∈ A, ENNReal.ofReal t < hittingTime N y ω a}).toReal

def earlyHit (N : Size) (y : Vertex N) (A : Finset (Vertex N)) (u : ℝ) : ℝ :=
  (walkLaw {ω | ∃ a ∈ A, hittingTime N y ω a ≤ ENNReal.ofReal u}).toReal

def StationaryTerminalEstimate : Prop :=
  ∀ k : ℕ, 0 < k → ∀ W : ℝ, 0 ≤ W → ∃ C : ℝ, 0 < C ∧
    ∀ᶠ N : Size in atTop, ∀ A : Finset (Vertex N), A.card = k → separatedTarget N A →
      ∀ z : ℝ, |z| ≤ W → ∀ j : Fin 3,
        0 < remainingTime N z - (j.val : ℝ) * mixingTime N ∧
        |(logSize N) ^ ((k : ℝ) / 2) * Real.exp ((k : ℝ) * z) *
          stationarySurvival N A (remainingTime N z - (j.val : ℝ) * mixingTime N) - 1| ≤
          C * survivalErrorRate N

def EarlyHitEstimate : Prop :=
  ∀ k : ℕ, 0 < k → ∃ C : ℝ, 0 < C ∧ ∀ᶠ N : Size in atTop,
    ∀ A : Finset (Vertex N), A.card = k → separatedTarget N A →
    ∀ y : Vertex N, (∀ a ∈ A, distantRadius N / 4 ≤ periodicDistance y a) →
      earlyHit N y A (mixingTime N) ≤
        C * ((logSize N) ^ (1 / 8 : ℝ) + Real.log (logSize N)) / logSize N

def MultiplicativeSurvivalComparison : Prop :=
  ∀ N : Size, ∀ u ε : ℝ, 0 ≤ u → 0 ≤ ε → ε < 1 →
    (∀ x y : Vertex N, |vertexCount N * transitionProbability N x y u - 1| ≤ ε) →
    ∀ A : Finset (Vertex N), ∀ y : Vertex N, ∀ T : ℝ, 2 * u < T →
      (1 - ε) * stationarySurvival N A (T - u) -
        (1 + ε) * earlyHit N y A u * stationarySurvival N A (T - 2 * u) ≤
        survivalAt N y A T ∧
      survivalAt N y A T ≤ (1 + ε) * stationarySurvival N A (T - u)

def farRepresentatives (N : Size) (start : Vertex N) (ω : WalkSample) : Finset (Vertex N) := by
  classical
  exact (representatives N (unvisited N start ω)).filter fun a =>
    distantRadius N / 4 ≤ periodicDistance (walk N start ω (observationTime N)) a

def futureSurvivorCount (N : Size) (start : Vertex N) (ω : WalkSample) (z : ℝ)
    (ω' : WalkSample) : ℕ := by
  classical
  exact ((farRepresentatives N start ω).filter fun a =>
    ENNReal.ofReal (remainingTime N z) <
      hittingTime N (walk N start ω (observationTime N)) ω' a).card

def factorialMomentKernel (N : Size) (start : Vertex N) (ω : WalkSample) (k : ℕ) (z : ℝ) : ℝ :=
  ∫ ω', ((futureSurvivorCount N start ω z ω').descFactorial k : ℝ) ∂walkLaw

def FixedOrderFactorialMoments : Prop :=
  ∀ k : ℕ, 0 < k → ∀ B W : ℝ, 0 ≤ B → 0 ≤ W → ∃ C : ℝ, 0 < C ∧
    ∀ᶠ N : Size in atTop, ∀ start : Vertex N, ∀ ω : WalkSample,
      selectorMass N start ω ≤ B → ∀ z : ℝ, |z| ≤ W →
        Integrable (fun ω' => ((futureSurvivorCount N start ω z ω').descFactorial k : ℝ)) walkLaw ∧
        |factorialMomentKernel N start ω k z - (selectorMass N start ω * Real.exp (-z)) ^ k| ≤
          C * (survivalErrorRate N + (logSize N) ^ (-1 / 2 : ℝ))

def taylorError (J : ℕ) (K : ℝ) : ℝ :=
  K ^ (2 * J + 1) / ((2 * J + 1).factorial : ℝ) +
    K ^ (2 * J + 2) / ((2 * J + 2).factorial : ℝ)

def RepresentativeVoidQuantitative : Prop :=
  (∀ K : ℝ, 0 ≤ K → Tendsto (fun J => taylorError J K) atTop (𝓝 0)) ∧
  (∀ B W : ℝ, 0 ≤ B → 0 ≤ W → ∀ J : ℕ, ∃ C : ℝ, 0 < C ∧
    ∀ᶠ N : Size in atTop, ∀ start : Vertex N, ∀ ω : WalkSample,
      selectorMass N start ω ≤ B → representativeWindowError N start W ω ≤
        C * (survivalErrorRate N + (logSize N) ^ (-1 / 2 : ℝ)) +
          taylorError J (B * Real.exp W)) ∧
  (∀ B W : ℝ, 0 ≤ B → 0 ≤ W → ∃ η : Size → ℝ,
    (∀ N, 0 ≤ η N) ∧ Tendsto η atTop (𝓝 0) ∧
    ∀ᶠ N : Size in atTop, ∀ start : Vertex N, ∀ ω : WalkSample,
      selectorMass N start ω ≤ B → representativeWindowError N start W ω ≤ η N)

def CompletionErrorBudget : Prop :=
  ∃ Cclear : ℝ, 0 < Cclear ∧ ∀ W : ℝ, 0 ≤ W → ∃ Crem : ℝ, 0 < Crem ∧
    ∀ B : ℝ, 0 ≤ B → ∃ η : Size → ℝ, (∀ N, 0 ≤ η N) ∧ Tendsto η atTop (𝓝 0) ∧
      (∀ᶠ N : Size in atTop,
        (∀ start : Vertex N, ∀ ω : WalkSample, selectorMass N start ω ≤ B →
          representativeWindowError N start (W + 1) ω ≤ η N) ∧
        (∀ start : Vertex N, ∀ᵐ ω ∂walkLaw, selectorMass N start ω ≤ B →
          conditionalWindowError N start W ω ≤ η N +
            (Cclear * B + 1 / Real.exp 1) * clearingScale N +
            min 1 (Crem * normalizedOmittedCount N start ω)) ∧
        uniformConditionalError N W ≤
          (⨆ start : Vertex N, (walkLaw {ω | B < selectorMass N start ω}).toReal) + η N +
          (Cclear * B + 1 / Real.exp 1) * clearingScale N +
          (⨆ start : Vertex N, ∫ ω, boundedRemainder N start Crem ω ∂walkLaw)) ∧
      (∀ J : ℕ, ∃ C : ℝ, 0 < C ∧ ∀ᶠ N : Size in atTop,
        ∀ start : Vertex N, ∀ᵐ ω ∂walkLaw, selectorMass N start ω ≤ B →
          conditionalWindowError N start W ω ≤
            C * (survivalErrorRate N + (logSize N) ^ (-1 / 2 : ℝ)) +
            taylorError J (B * Real.exp (W + 1)) +
            (Cclear * B + 1 / Real.exp 1) * clearingScale N +
            min 1 (Crem * normalizedOmittedCount N start ω))

end TorusCoverTime
