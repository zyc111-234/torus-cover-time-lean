import Definitions.Torus
import Mathlib.MeasureTheory.Measure.FiniteMeasure

/-! Random finite measures carry the Borel sigma algebra of the weak topology.
Mathlib's underlying `FiniteMeasure` also has a Giry measurable-space instance; this synonym
makes the weak-Borel choice explicit rather than silently identifying the two instances. -/

noncomputable section
open MeasureTheory

namespace TorusCoverTime

def TorusMeasure := FiniteMeasure Torus

instance : TopologicalSpace TorusMeasure :=
  inferInstanceAs (TopologicalSpace (FiniteMeasure Torus))
instance : MeasurableSpace TorusMeasure := borel TorusMeasure
instance : BorelSpace TorusMeasure := ⟨rfl⟩

def TorusMeasure.ofFinite (μ : FiniteMeasure Torus) : TorusMeasure := μ
def TorusMeasure.toFinite (μ : TorusMeasure) : FiniteMeasure Torus := μ
def TorusMeasure.toMeasure (μ : TorusMeasure) : Measure Torus := μ.toFinite.toMeasure
def TorusMeasure.mass (μ : TorusMeasure) : ℝ := μ.toFinite.mass
def TorusMeasure.scale (c : ℝ) (μ : TorusMeasure) : TorusMeasure :=
  TorusMeasure.ofFinite (Real.toNNReal c • μ.toFinite)

end TorusCoverTime
