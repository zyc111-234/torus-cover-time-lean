import Definitions.MainTarget

/-! Interfaces from R10, R25, and B1. These definitions do not assume any limit theorem. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter
open scoped ENNReal NNReal Topology

namespace TorusCoverTime

/-- The exact center identity in Section C, equation `center-shift`. -/
def phaseACenter (N : Size) : ℝ :=
  observationTime N + (9 * g / 32) * (N.val : ℝ) ^ 2 * (Real.log (logSize N)) ^ 2

def softSet (N : Size) (start : Vertex N) (ω : WalkSample) (u₀ t : ℝ) :
    Finset (Vertex N) := by
  classical
  exact Finset.univ.filter (fun x => localTime N start ω t x ≤ u₀)

def wideDefects (N : Size) (U : Finset (Vertex N)) : Finset (Vertex N) := by
  classical
  exact U.filter fun x => ∃ y ∈ U,
    separationRadius N / 2 < periodicDistance x y ∧
    periodicDistance x y < 2 * distantRadius N

def defectWindowMass (N : Size) (start : Vertex N) (ω : WalkSample) (u₀ W : ℝ) : ℝ :=
  ⨆ c : {c : ℝ // |c| ≤ W},
    ((wideDefects N (softSet N start ω u₀
      (phaseACenter N + c.val * timeScale N))).card : ℝ) / Real.sqrt (logSize N)

/-- Euclidean instance of R10.1, with the supremum INSIDE the probability. -/
def WideDefectLimit : Prop :=
  ∀ u₀ : ℝ, 0 < u₀ → ∀ W : ℝ, 0 ≤ W → ∀ η : ℝ, 0 < η →
    Tendsto (fun N : Size => ⨆ start : Vertex N,
      walkLaw {ω | η < defectWindowMass N start ω u₀ W}) atTop (𝓝 0)

def normalizedOmittedCount (N : Size) (start : Vertex N) (ω : WalkSample) : ℝ :=
  ((omitted N start ω).card : ℝ) / Real.sqrt (logSize N)

def OmittedNegligible : Prop :=
  (∀ N : Size, ∀ start : Vertex N, AEMeasurable (normalizedOmittedCount N start) walkLaw) ∧
  (∀ η : ℝ, 0 < η → Tendsto (fun N : Size => ⨆ start : Vertex N,
    walkLaw {ω | η < normalizedOmittedCount N start ω}) atTop (𝓝 0))

def boundedRemainder (N : Size) (start : Vertex N) (A : ℝ) (ω : WalkSample) : ℝ :=
  min 1 (A * normalizedOmittedCount N start ω)

def BoundedRemainderLimit : Prop :=
  (∀ N : Size, ∀ start : Vertex N, ∀ A : ℝ, 0 ≤ A →
    Integrable (boundedRemainder N start A) walkLaw) ∧
  (∀ A : ℝ, 0 ≤ A → Tendsto (fun N : Size => ⨆ start : Vertex N,
    ∫ ω, boundedRemainder N start A ω ∂walkLaw) atTop (𝓝 0))

/-- Equivalent epsilon/cutoff formulation of B1 `count-tightness`. -/
def SelectorMassTight : Prop :=
  ∀ η : ℝ, 0 < η → ∃ B : ℝ, 0 ≤ B ∧ ∀ᶠ N : Size in atTop,
    ∀ start : Vertex N, walkLaw {ω | B < selectorMass N start ω} ≤ ENNReal.ofReal η

/-- A version measurable in the observation history; equality only needs to hold a.s. -/
def SelectorHistoryMeasurable : Prop :=
  ∀ N : Size, ∀ start : Vertex N, ∃ f : WalkSample → TorusMeasure,
    @Measurable WalkSample TorusMeasure (observationHistory N start) inferInstance f ∧
    f =ᵐ[walkLaw] selectorRandomMeasure N start

def PhaseAConclusion (Z : FieldSample → TorusMeasure) : Prop :=
  ∃ κ : ℝ, 0 < κ ∧ PhaseALimit Z κ ∧
    ∀ κ' : ℝ, 0 < κ' → PhaseALimit Z κ' → κ' = κ

end TorusCoverTime
