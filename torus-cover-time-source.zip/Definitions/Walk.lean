import Definitions.Scales
import Mathlib.Probability.ProductMeasure
import Mathlib.Probability.Distributions.Exponential
import Mathlib.Probability.UniformOn

/-! A concrete rate-one walk: independent exponential holding times and uniform directions.
Nonpositive holding times and explosive samples have totalized definitions; proving that these
exceptions are null is an explicit model obligation, not an assumption on the cover-time limit. -/

noncomputable section
open MeasureTheory ProbabilityTheory
open scoped ENNReal NNReal

namespace TorusCoverTime

abbrev WalkSample := ℕ → (ℝ × Fin 4)

def holdingLaw : Measure ℝ := expMeasure 1
instance holdingLaw_probability : IsProbabilityMeasure holdingLaw :=
  isProbabilityMeasure_expMeasure (by norm_num)

def stepLaw : Measure (ℝ × Fin 4) :=
  holdingLaw.prod (uniformOn (Set.univ : Set (Fin 4)))
instance stepLaw_probability : IsProbabilityMeasure stepLaw := by unfold stepLaw; infer_instance

def walkLaw : Measure WalkSample := Measure.infinitePi (fun _ : ℕ => stepLaw)
instance walkLaw_probability : IsProbabilityMeasure walkLaw := by unfold walkLaw; infer_instance

def holdingTime (ω : WalkSample) (j : ℕ) : ℝ := max (ω j).1 0
def jumpTime (ω : WalkSample) (k : ℕ) : ℝ := ∑ j ∈ Finset.range k, holdingTime ω j

def jumpCount (ω : WalkSample) (t : ℝ) : ℕ := by
  classical
  exact if h : ∃ k : ℕ, t < jumpTime ω (k + 1) then Nat.find h else 0

def position (N : Size) (start : Vertex N) (ω : WalkSample) (k : ℕ) : Vertex N :=
  start + ∑ j ∈ Finset.range k, direction N (ω j).2

def walk (N : Size) (start : Vertex N) (ω : WalkSample) (t : ℝ) : Vertex N :=
  if t < 0 then start else position N start ω (jumpCount ω t)

/-- `∞` is retained if a vertex is never visited. -/
def hittingTime (N : Size) (start : Vertex N) (ω : WalkSample) (x : Vertex N) : ℝ≥0∞ :=
  sInf {u | ∃ t : ℝ, 0 ≤ t ∧ walk N start ω t = x ∧ u = ENNReal.ofReal t}

def coverTime (N : Size) (start : Vertex N) (ω : WalkSample) : ℝ≥0∞ :=
  ⨆ x : Vertex N, hittingTime N start ω x

def localTime (N : Size) (start : Vertex N) (ω : WalkSample) (t : ℝ) (x : Vertex N) : ℝ :=
  ∫ s in Set.Icc 0 t, if walk N start ω s = x then (1 : ℝ) else 0

/-- The real normalization is accompanied by the separate a.s. finiteness obligation. -/
def normalizedCoverTime (N : Size) (start : Vertex N) (ω : WalkSample) : ℝ :=
  ((coverTime N start ω).toReal - timeCenter N) / timeScale N

def coveredBy (N : Size) (start : Vertex N) (ω : WalkSample) (t : ℝ) : Prop :=
  0 ≤ t ∧ coverTime N start ω ≤ ENNReal.ofReal t

def setCoverTime (N : Size) (start : Vertex N) (A : Finset (Vertex N))
    (ω : WalkSample) : ℝ≥0∞ :=
  ⨆ x ∈ A, hittingTime N start ω x

@[simp] theorem jumpTime_zero (ω : WalkSample) : jumpTime ω 0 = 0 := by simp [jumpTime]

@[simp] theorem position_zero (N : Size) (start : Vertex N) (ω : WalkSample) :
    position N start ω 0 = start := by simp [position]

@[simp] theorem setCoverTime_empty (N : Size) (start : Vertex N) (ω : WalkSample) :
    setCoverTime N start ∅ ω = 0 := by simp [setCoverTime]

end TorusCoverTime
