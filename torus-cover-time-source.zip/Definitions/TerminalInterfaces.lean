import Definitions.PhaseInterfaces

/-! Source interfaces B1, B3, B4, B5. Every probability uses the concrete walk. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter
open scoped ENNReal NNReal Topology

namespace TorusCoverTime

def componentOf (N : Size) (U : Finset (Vertex N)) (a : Vertex N) : Finset (Vertex N) := by
  classical
  exact U.filter fun x => (clusterGraph N U).Reachable a x

/-- Geometry in B1, for every finite unvisited-set configuration. Remainder inclusions
are separate deterministic lemmas, including the required local-time argument. -/
def SelectorGeometry : Prop :=
  ∃ C : ℝ, 0 < C ∧ ∀ᶠ N : Size in atTop, ∀ U : Finset (Vertex N),
    (∀ a ∈ representatives N U,
      (∀ x ∈ componentOf N U a, periodicDistance a x ≤ separationRadius N) ∧
      (∀ x ∈ componentOf N U a, ∀ y ∈ componentOf N U a,
        periodicDistance x y ≤ 2 * separationRadius N) ∧
      ((componentOf N U a).card : ℝ) ≤ C * (1 + separationRadius N) ^ 2) ∧
    (∀ a ∈ representatives N U, ∀ b ∈ representatives N U, a ≠ b →
      distantRadius N ≤ periodicDistance a b) ∧
    (∀ y : Vertex N,
      ((representatives N U).filter fun a =>
        periodicDistance y a < distantRadius N / 4).card ≤ 1)

def separatedTarget (N : Size) (A : Finset (Vertex N)) : Prop :=
  ∀ a ∈ A, ∀ b ∈ A, a ≠ b → distantRadius N ≤ periodicDistance a b

/-- Avoid hitting ANY target, distinct from the time to cover ALL targets. -/
def targetAvoidance (N : Size) (start : Vertex N) (A : Finset (Vertex N)) (z : ℝ) : ℝ :=
  (walkLaw {ω | ∀ a ∈ A, ENNReal.ofReal (remainingTime N z) < hittingTime N start ω a}).toReal

def survivalErrorRate (N : Size) : ℝ :=
  (logSize N) ^ (-7 / 8 : ℝ) * Real.log (logSize N)

/-- B3 `relative-survival` and `arbitrary-start-upper`; k is fixed BEFORE N tends to infinity. -/
def TerminalAvoidanceEstimate : Prop :=
  ∀ k : ℕ, 0 < k → ∀ W : ℝ, 0 ≤ W → ∃ C : ℝ, 0 < C ∧
    ∀ᶠ N : Size in atTop, ∀ A : Finset (Vertex N), A.card = k → separatedTarget N A →
      ∀ start : Vertex N, ∀ z : ℝ, |z| ≤ W →
        targetAvoidance N start A z ≤ C * (logSize N) ^ (-(k : ℝ) / 2) ∧
        ((∀ a ∈ A, distantRadius N / 4 ≤ periodicDistance start a) →
          |(logSize N) ^ ((k : ℝ) / 2) * Real.exp ((k : ℝ) * z) *
            targetAvoidance N start A z - 1| ≤ C * survivalErrorRate N)

/-- B4 finite future-walk kernel. Its zero extension for negative remaining time
is irrelevant on every fixed compact window for all sufficiently large N. -/
def representativeKernel (N : Size) (start : Vertex N) (ω : WalkSample) (z : ℝ) : ℝ :=
  if 0 ≤ remainingTime N z then
    (walkLaw {ω' | setCoverTime N (walk N start ω (observationTime N))
      (representatives N (unvisited N start ω)) ω' ≤ ENNReal.ofReal (remainingTime N z)}).toReal
  else 0

def representativeWindowError (N : Size) (start : Vertex N) (W : ℝ) (ω : WalkSample) : ℝ :=
  ⨆ z : {z : ℝ // |z| ≤ W},
    |representativeKernel N start ω z.val -
      Real.exp (-selectorMass N start ω * Real.exp (-z.val))|

def RepresentativeVoidLimit : Prop :=
  (∀ N : Size, ∀ start : Vertex N, ∀ W : ℝ, 0 ≤ W →
    Integrable (representativeWindowError N start W) walkLaw) ∧
  (∀ W : ℝ, 0 ≤ W → Tendsto (fun N : Size => ⨆ start : Vertex N,
    ∫ ω, representativeWindowError N start W ω ∂walkLaw) atTop (𝓝 0))

def harmonicNumber (m : ℕ) : ℝ := ∑ j ∈ Finset.range m, 1 / ((j : ℝ) + 1)

def maximalInternalMeanHit (N : Size) (A : Finset (Vertex N)) : ℝ≥0∞ :=
  ⨆ x ∈ A, ⨆ y ∈ A, ∫⁻ ω, hittingTime N x ω y ∂walkLaw

/-- Nonnegative extended integrals retain infinite expectations. -/
def TargetMatthewsBound : Prop :=
  ∀ N : Size, ∀ A : Finset (Vertex N), A.Nonempty → ∀ start ∈ A,
    (∫⁻ ω, setCoverTime N start A ω ∂walkLaw) ≤
      ENNReal.ofReal (harmonicNumber (A.card - 1)) * maximalInternalMeanHit N A

def LocalClearingBound : Prop :=
  ∃ C : ℝ, 0 < C ∧ ∀ N : Size, ∀ A : Finset (Vertex N), A.Nonempty →
    ∀ d : ℝ, 0 ≤ d → d < (N.val : ℝ) / 2 →
      (∀ x ∈ A, ∀ y ∈ A, periodicDistance x y ≤ d) → ∀ start ∈ A,
        (∫⁻ ω, setCoverTime N start A ω ∂walkLaw) ≤
          ENNReal.ofReal (C * (N.val : ℝ) ^ 2 * (1 + Real.log (d + 1)) ^ 2)

end TorusCoverTime
