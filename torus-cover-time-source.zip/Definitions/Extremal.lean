import Definitions.Activity

/-! R11 and R23, with a concrete finite-field normalization and contact coefficient.
The law and its scale are parameters constrained by a stated extremal limit, not arbitrary
constants chosen to make the activity conclusion true. Cylinder Laplace tests express the
decorated Cox law without choosing an auxiliary realization of the limiting point process. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter
open scoped ENNReal NNReal Topology
namespace TorusCoverTime

abbrev Lattice := ℤ × ℤ
abbrev Decoration := Lattice → ℝ

def DecorationLawRegular (ν : Measure Decoration) : Prop :=
  IsProbabilityMeasure ν ∧
  (∀ᵐ ω ∂ν, ω 0 = 0 ∧ (∀ y, 0 ≤ ω y) ∧
    ∀ h : ℝ, {y | ω y ≤ h}.Finite)

def extremalCenter (N : Size) : ℝ :=
  2 * Real.sqrt g * logSize N - (3 / 4 : ℝ) * Real.sqrt g * Real.log (logSize N)

def latticeTranslate (N : Size) (x : Vertex N) (y : Lattice) : Vertex N :=
  x + ((y.1 : ZMod N.val), (y.2 : ZMod N.val))

def finiteDecoration (N : Size) (ξ : FiniteFieldSample N) (x : Vertex N) : Decoration :=
  fun y => finiteGaussianField N ξ x - finiteGaussianField N ξ (latticeTranslate N x y)

def extremalRoots (N : Size) (ξ : FiniteFieldSample N) (r : ℝ) : Finset (Vertex N) := by
  classical
  exact Finset.univ.filter fun x => ∀ y : Vertex N, graphDistance x y ≤ r →
    finiteGaussianField N ξ y ≤ finiteGaussianField N ξ x ∧
    (finiteGaussianField N ξ y = finiteGaussianField N ξ x → lexLE x y)

def ExtremalRadius (r : Size → ℝ) : Prop :=
  (∀ N, 0 < r N) ∧ Tendsto r atTop atTop ∧
    Tendsto (fun N => r N / (N.val : ℝ)) atTop (𝓝 0)

def CylinderTest (W : Finset Lattice)
    (f : Torus → ℝ → (W → ℝ) → ℝ) : Prop :=
  Continuous (fun p : Torus × ℝ × (W → ℝ) => f p.1 p.2.1 p.2.2) ∧
  (∀ x h ω, 0 ≤ f x h ω) ∧
  (∃ B : ℝ, ∀ x h ω, f x h ω ≤ B) ∧
  ∃ H : ℝ, 0 ≤ H ∧ ∀ x h ω, H < |h| → f x h ω = 0

def finiteExtremalLaplace (N : Size) (r : ℝ) (W : Finset Lattice)
    (f : Torus → ℝ → (W → ℝ) → ℝ) : ℝ :=
  ∫ ξ, Real.exp (-(∑ x ∈ extremalRoots N ξ r,
    f (embed x) (finiteGaussianField N ξ x - extremalCenter N)
      (fun y => finiteDecoration N ξ x y.val))) ∂finiteFieldLaw N

def coxExponent (Z : TorusMeasure) (β : ℝ) (ν : Measure Decoration)
    (W : Finset Lattice) (f : Torus → ℝ → (W → ℝ) → ℝ) : ℝ≥0∞ :=
  ENNReal.ofReal β * ∫⁻ x, ∫⁻ h : ℝ, ∫⁻ ω,
    ENNReal.ofReal (Real.exp (-criticalParameter * h) *
      (1 - Real.exp (-f x h (fun y => ω y.val)))) ∂ν ∂volume ∂Z.toMeasure

def nearExtremalVertices (N : Size) (ξ : FiniteFieldSample N) (H : ℝ) : Finset (Vertex N) := by
  classical
  exact Finset.univ.filter fun x => extremalCenter N - H ≤ finiteGaussianField N ξ x

/-- The high-point count, upper maximum tail and two-scale separation inputs used
alongside the decorated-process law. The separation scale is sent to infinity after N. -/
def ExtremalGeometry : Prop :=
  (∀ H η : ℝ, 0 ≤ H → 0 < η → ∃ B : ℕ, ∀ᶠ N : Size in atTop,
    finiteFieldLaw N {ξ | B < (nearExtremalVertices N ξ H).card} ≤ ENNReal.ofReal η) ∧
  (∀ η : ℝ, 0 < η → ∃ H : ℝ, 0 ≤ H ∧ ∀ᶠ N : Size in atTop,
    finiteFieldLaw N {ξ | ∃ x : Vertex N,
      extremalCenter N + H < finiteGaussianField N ξ x} ≤ ENNReal.ofReal η) ∧
  (∀ H η : ℝ, 0 ≤ H → 0 < η → ∃ R₀ : ℝ, 0 < R₀ ∧ ∀ R : ℝ, R₀ ≤ R →
    ∀ᶠ N : Size in atTop, finiteFieldLaw N {ξ | ∃ x ∈ nearExtremalVertices N ξ H,
      ∃ y ∈ nearExtremalVertices N ξ H,
        R < graphDistance x y ∧ graphDistance x y < (N.val : ℝ) / R} ≤ ENNReal.ofReal η)

def PeriodicExtremalLaw (Z : FieldSample → TorusMeasure)
    (β : ℝ) (ν : Measure Decoration) : Prop :=
  0 < β ∧ DecorationLawRegular ν ∧ ExtremalGeometry ∧
  ∀ W : Finset Lattice, ∀ f : Torus → ℝ → (W → ℝ) → ℝ, CylinderTest W f →
    (∀ ξ, coxExponent (Z ξ) β ν W f ≠ ∞) ∧
    ∀ r : Size → ℝ, ExtremalRadius r →
      Tendsto (fun N => finiteExtremalLaplace N (r N) W f) atTop
        (𝓝 (∫ ξ, Real.exp (-(coxExponent (Z ξ) β ν W f).toReal) ∂fieldLaw))

def ancestorRadius (Cgeo : ℝ) (K : ℕ) : ℕ := ⌈10 + Cgeo * Real.exp (K : ℝ)⌉₊
def ancestorWindow (Cgeo : ℝ) (K : ℕ) : Finset Lattice :=
  (Finset.Icc (-(ancestorRadius Cgeo K : ℤ)) (ancestorRadius Cgeo K : ℤ)).product
    (Finset.Icc (-(ancestorRadius Cgeo K : ℤ)) (ancestorRadius Cgeo K : ℤ))

def contactEvent (Y : Set Lattice) (v h : ℝ) : Set Decoration :=
  {ω | ∃ y ∈ Y, |h - ω y| ≤ Real.sqrt v}

/-- Nonnegative integrals retain possible infinity; finiteness is an explicit theorem clause. -/
def contactCoefficient (β : ℝ) (ν : Measure Decoration) (Y : Set Lattice) (v : ℝ) : ℝ≥0∞ :=
  ENNReal.ofReal β * ∫⁻ h : ℝ,
    ENNReal.ofReal (Real.exp (-criticalParameter * h)) * ν (contactEvent Y v h) ∂volume

def gammaFinite (β : ℝ) (ν : Measure Decoration) (Cgeo : ℝ) (K : ℕ) (v : ℝ) : ℝ≥0∞ :=
  contactCoefficient β ν (ancestorWindow Cgeo K : Set Lattice) v

def gammaInfinite (β : ℝ) (ν : Measure Decoration) (v : ℝ) : ℝ≥0∞ :=
  contactCoefficient β ν Set.univ v

def ContactCoefficientProperties (β : ℝ) (ν : Measure Decoration) : Prop :=
  ∀ v : ℝ, 0 < v →
    0 < gammaInfinite β ν v ∧ gammaInfinite β ν v ≠ ∞ ∧
    (∀ Cgeo : ℝ, 0 < Cgeo →
      Monotone (fun K => gammaFinite β ν Cgeo K v) ∧
      Tendsto (fun K => gammaFinite β ν Cgeo K v) atTop (𝓝 (gammaInfinite β ν v)) ∧
      ∀ K : ℕ,
        ENNReal.ofReal (β * ∫ h in Set.Icc (-Real.sqrt v) (Real.sqrt v),
          Real.exp (-criticalParameter * h)) ≤ gammaFinite β ν Cgeo K v ∧
        gammaFinite β ν Cgeo K v ≤ gammaInfinite β ν v) ∧
    gammaInfinite β ν v ≤ ENNReal.ofReal
      (β / criticalParameter * Real.exp (criticalParameter * Real.sqrt v))

def ExplicitFullActivityLimit (Z : FieldSample → TorusMeasure)
    (β : ℝ) (ν : Measure Decoration) : Prop :=
  ContactCoefficientProperties β ν ∧
  ∀ u₀ : ℝ, 0 < u₀ → ∃ vStar : ℝ, 0 < vStar ∧ vStar < 2 * u₀ ∧
    ∀ v : ℝ, 0 < v → v < vStar → ∀ c : ℝ,
      TendstoInDistribution
        (fun N (ω : Vertex N × WalkSample) =>
          fullActivity N ω.1 ω.2 u₀ (phaseACenter N + c * timeScale N) v) atTop
        (fun ξ => (Z ξ).scale (Real.exp (-c) * (gammaInfinite β ν v).toReal))
        stationaryWalkLaw fieldLaw

def activityPairing (N : Size) (start : Vertex N) (ω : WalkSample) (u₀ c v : ℝ)
    (q : C(Torus, ℝ)) : ℝ :=
  ∫ x, q x ∂(fullActivity N start ω u₀ (phaseACenter N + c * timeScale N) v).toMeasure

/-- R22.6 and deterministic ordinary-path continuity. The spatial test and error
cutoffs are fixed before N; the oscillation supremum remains inside the probability. -/
def FullActivityPreparation : Prop :=
  ∀ u₀ : ℝ, 0 < u₀ → ∃ vStar : ℝ, 0 < vStar ∧ vStar < 2 * u₀ ∧
    ∀ v : ℝ, 0 < v → v < vStar →
      (∀ W η : ℝ, 0 ≤ W → 0 < η → ∃ B : ℝ, 0 ≤ B ∧
        ∀ᶠ N : Size in atTop, ∀ start : Vertex N, ∀ c : ℝ, |c| ≤ W →
          walkLaw {ω | B < (fullActivity N start ω u₀
            (phaseACenter N + c * timeScale N) v).mass} ≤ ENNReal.ofReal η) ∧
      (∀ q : C(Torus, ℝ), (∀ x, 0 ≤ q x ∧ q x ≤ 1) →
        ∀ W η ρ : ℝ, 0 ≤ W → 0 < η → 0 < ρ →
          ∃ δ : ℝ, 0 < δ ∧ δ ≤ 1 ∧ ∀ᶠ N : Size in atTop,
            ∀ start : Vertex N, ∀ c : ℝ, |c| ≤ W →
              walkLaw {ω | η < ⨆ c' : {c' : ℝ // |c' - c| ≤ δ},
                |activityPairing N start ω u₀ c'.val v q -
                  activityPairing N start ω u₀ c v q|} ≤ ENNReal.ofReal ρ)

end TorusCoverTime
