import Definitions.TerminalInterfaces

/-! B5/B6 on the original walk path. Completion delays are measured from s_N;
empty families have delay zero, and infinite hitting times remain infinite. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter
open scoped ENNReal NNReal Topology
namespace TorusCoverTime

def hitAfter (N : Size) (start : Vertex N) (ω : WalkSample) (t : ℝ) (x : Vertex N) : ℝ≥0∞ :=
  sInf {q | ∃ u : ℝ, 0 ≤ u ∧ walk N start ω (t + u) = x ∧ q = ENNReal.ofReal u}
def coverAfter (N : Size) (start : Vertex N) (ω : WalkSample) (t : ℝ)
    (A : Finset (Vertex N)) : ℝ≥0∞ := ⨆ x ∈ A, hitAfter N start ω t x
def representativeDelay (N : Size) (start : Vertex N) (ω : WalkSample) : ℝ≥0∞ :=
  coverAfter N start ω (observationTime N) (representatives N (unvisited N start ω))
def retainedDelay (N : Size) (start : Vertex N) (ω : WalkSample) : ℝ≥0∞ :=
  coverAfter N start ω (observationTime N) (retained N (unvisited N start ω))
def clusterClearDelay (N : Size) (start : Vertex N) (ω : WalkSample) (a : Vertex N) : ℝ≥0∞ :=
  if hitAfter N start ω (observationTime N) a = ∞ then ∞ else
    coverAfter N start ω (observationTime N + (hitAfter N start ω (observationTime N) a).toReal)
      (componentOf N (unvisited N start ω) a)
def maxClusterClearDelay (N : Size) (start : Vertex N) (ω : WalkSample) : ℝ≥0∞ :=
  ⨆ a ∈ representatives N (unvisited N start ω), clusterClearDelay N start ω a
def clearingConditionalTail (N : Size) (start : Vertex N) (ε : ℝ) : WalkSample → ℝ := by
  classical
  exact condExp (observationHistory N start) walkLaw fun ω =>
    if ENNReal.ofReal (ε * timeScale N) < maxClusterClearDelay N start ω then 1 else 0
def clearingScale (N : Size) : ℝ := (logSize N) ^ (-1 / 8 : ℝ)

def ConditionalClusterClearing : Prop :=
  (∀ N : Size, ∀ start : Vertex N, ∀ᵐ ω ∂walkLaw,
    maxClusterClearDelay N start ω ≠ ∞ ∧
    representativeDelay N start ω ≤ retainedDelay N start ω ∧
    retainedDelay N start ω ≤ representativeDelay N start ω + maxClusterClearDelay N start ω) ∧
  (∀ N : Size, ∀ start a : Vertex N,
    (∀ᵐ ω ∂walkLaw, clusterClearDelay N start ω a ≠ ∞) ∧
    Integrable (fun ω => (clusterClearDelay N start ω a).toReal) walkLaw) ∧
  (∃ C : ℝ, 0 < C ∧ ∀ᶠ N : Size in atTop, ∀ start : Vertex N,
    (∀ a : Vertex N, ∀ᵐ ω ∂walkLaw, a ∈ representatives N (unvisited N start ω) →
      condExp (observationHistory N start) walkLaw
        (fun ω' => (clusterClearDelay N start ω' a).toReal) ω ≤
          C * (N.val : ℝ) ^ 2 * (logSize N) ^ (1 / 4 : ℝ)) ∧
    (∀ ε : ℝ, 0 < ε → ∀ᵐ ω ∂walkLaw,
      clearingConditionalTail N start ε ω ≤
        min 1 (C / ε * selectorMass N start ω * (logSize N) ^ (-1 / 4 : ℝ))))

def ClearingNegligible : Prop :=
  ∀ ε : ℝ, 0 < ε → Tendsto (fun N : Size => ⨆ start : Vertex N,
    walkLaw {ω | ENNReal.ofReal (ε * timeScale N) < maxClusterClearDelay N start ω}) atTop (𝓝 0)

/-- Canonical future-walk version of B6's conditional omitted-survivor probability. -/
def omittedSurvivalKernel (N : Size) (start : Vertex N) (ω : WalkSample) (z : ℝ) : ℝ :=
  (walkLaw {ω' | ∃ a ∈ omitted N start ω,
    ENNReal.ofReal (remainingTime N z) <
      hittingTime N (walk N start ω (observationTime N)) ω' a}).toReal
def omittedSurvivalWindow (N : Size) (start : Vertex N) (W : ℝ) (ω : WalkSample) : ℝ :=
  ⨆ z : {z : ℝ // |z| ≤ W}, omittedSurvivalKernel N start ω z.val
def RemainderSurvivalControl : Prop :=
  (∀ W : ℝ, 0 ≤ W → ∃ C : ℝ, 0 < C ∧ ∀ᶠ N : Size in atTop,
    ∀ start : Vertex N, ∀ᵐ ω ∂walkLaw,
      omittedSurvivalWindow N start W ω ≤ min 1 (C * normalizedOmittedCount N start ω)) ∧
  (∀ N : Size, ∀ start : Vertex N, ∀ W : ℝ, 0 ≤ W →
    Integrable (omittedSurvivalWindow N start W) walkLaw) ∧
  (∀ W : ℝ, 0 ≤ W → Tendsto (fun N : Size => ⨆ start : Vertex N,
    ∫ ω, omittedSurvivalWindow N start W ω ∂walkLaw) atTop (𝓝 0))

def ConditionalCompletionSandwich : Prop :=
  ∀ W : ℝ, 0 ≤ W → ∀ᶠ N : Size in atTop, ∀ start : Vertex N, ∀ᵐ ω ∂walkLaw,
    ∀ z : ℝ, |z| ≤ W →
      representativeKernel N start ω (z - clearingScale N) -
        clearingConditionalTail N start (clearingScale N) ω -
        omittedSurvivalKernel N start ω z ≤ coverageKernel N start ω z ∧
      coverageKernel N start ω z ≤ representativeKernel N start ω z

end TorusCoverTime
