import Mathlib.Data.ZMod.Basic
import Mathlib.Analysis.Fourier.AddCircleMulti
import Mathlib.Tactic.NormNum

/-! The finite torus and its embedding, with the manuscript's Euclidean periodic distance.
The product topology on `Torus` is the usual topology on the two-dimensional torus;
we do not use its product (supremum) metric for the manuscript's distance cutoffs. -/

noncomputable section

namespace TorusCoverTime

abbrev Size := {N : ℕ // 3 ≤ N}

instance sizeNeZero (N : Size) : NeZero N.val := ⟨by have := N.property; omega⟩

abbrev Vertex (N : Size) := ZMod N.val × ZMod N.val
abbrev Torus := UnitAddTorus (Fin 2)

/-- Representatives in `{0,...,N-1}²`, in the original coordinate order. -/
def representative {N : Size} (x : Vertex N) : ℕ × ℕ := (x.1.val, x.2.val)

def lexLE {N : Size} (x y : Vertex N) : Prop :=
  x.1.val < y.1.val ∨ (x.1.val = y.1.val ∧ x.2.val ≤ y.2.val)

def embed {N : Size} (x : Vertex N) : Torus := fun i =>
  if i = 0 then ((x.1.val : ℝ) / (N.val : ℝ) : UnitAddCircle)
  else ((x.2.val : ℝ) / (N.val : ℝ) : UnitAddCircle)

def coordinateDistance {N : Size} (x y : ZMod N.val) : ℝ :=
  min |(x.val : ℝ) - (y.val : ℝ)|
    ((N.val : ℝ) - |(x.val : ℝ) - (y.val : ℝ)|)

def periodicDistance {N : Size} (x y : Vertex N) : ℝ :=
  Real.sqrt ((coordinateDistance x.1 y.1) ^ 2 + (coordinateDistance x.2 y.2) ^ 2)

theorem coordinateDistance_comm {N : Size} (x y : ZMod N.val) :
    coordinateDistance x y = coordinateDistance y x := by
  simp only [coordinateDistance, abs_sub_comm]

theorem periodicDistance_comm {N : Size} (x y : Vertex N) :
    periodicDistance x y = periodicDistance y x := by
  simp only [periodicDistance, coordinateDistance_comm]

/-- The four directions are sampled separately, each with probability `1/4`. -/
def direction (N : Size) (d : Fin 4) : Vertex N :=
  if d = 0 then (1, 0) else if d = 1 then (-1, 0)
  else if d = 2 then (0, 1) else (0, -1)

def generator (N : Size) (f : Vertex N → ℝ) (x : Vertex N) : ℝ :=
  (1 / 4 : ℝ) * ∑ d : Fin 4, (f (x + direction N d) - f x)

@[simp] theorem generator_const (N : Size) (c : ℝ) (x : Vertex N) :
    generator N (fun _ => c) x = 0 := by simp [generator]

end TorusCoverTime
