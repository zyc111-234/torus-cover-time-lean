import Mathlib.Probability.Independence.Basic
import Mathlib.MeasureTheory.Integral.Bochner.Basic
import Mathlib.Analysis.SpecialFunctions.Exp
import Mathlib.Analysis.SpecialFunctions.Sqrt

open MeasureTheory ProbabilityTheory
namespace TorusCoverTime

/-- S3 interface on ordinary probability spaces, supplied by the existing universe-polymorphic theorem. -/
def BernoulliExponentialBound : Prop :=
  ∀ (Ω : Type) [MeasurableSpace Ω] (μ : Measure Ω) [IsProbabilityMeasure μ]
    (m : ℕ) (V : Fin m → Ω → ℝ),
    (∀ i, Measurable (V i)) → (∀ i, ∀ᵐ ω ∂μ, 0 ≤ V i ω) → iIndepFun V μ →
    ∀ p lam U : ℝ, 0 ≤ p → p ≤ 1 → 0 < lam → 0 ≤ U →
    (∀ (i : Fin m) (theta : ℝ), 0 ≤ theta →
      (∫ ω, Real.exp (-theta * V i ω) ∂μ) ≤ 1 - p + p * lam / (lam + theta)) →
    μ {ω | (∑ i : Fin m, V i ω) ≤ U} ≤
      ENNReal.ofReal (Real.exp (-((max (Real.sqrt ((m : ℝ) * p) - Real.sqrt (lam * U)) 0) ^ 2)))

end TorusCoverTime
