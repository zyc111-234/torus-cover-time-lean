import Definitions.FinitePotential

/-! F.4--F.7, R22.1--R22.3, and the R23/R24 interfaces.
Canonical clean components DELETE defects before forming components. This is deliberately
a different object from the final selector, which keeps whole components of the unvisited set.
The full activity uses every clean soft parent and a concrete conditional finite Gaussian field. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter
open scoped ENNReal NNReal Topology
namespace TorusCoverTime

def graphDistance {N : Size} (x y : Vertex N) : ℝ :=
  coordinateDistance x.1 y.1 + coordinateDistance x.2 y.2
def canonicalRadius (N : Size) : ℝ := Real.exp ((logSize N) ^ (1 / 6 : ℝ)) / 2
def canonicalSeparation (N : Size) : ℝ :=
  (N.val : ℝ) * Real.exp (-2 * (logSize N) ^ (1 / 8 : ℝ))
def canonicalCleanSet (N : Size) (U : Finset (Vertex N)) : Finset (Vertex N) := by
  classical
  exact U.filter fun x => ¬ ∃ y ∈ U,
    canonicalRadius N < graphDistance x y ∧ graphDistance x y < canonicalSeparation N

def canonicalGraph (N : Size) (U : Finset (Vertex N)) : SimpleGraph (Vertex N) where
  Adj x y := x ≠ y ∧ x ∈ canonicalCleanSet N U ∧ y ∈ canonicalCleanSet N U ∧
    graphDistance x y ≤ canonicalRadius N
  symm := ⟨by
    intro x y h
    exact ⟨h.1.symm, h.2.2.1, h.2.1, by
      simpa only [graphDistance, coordinateDistance_comm] using h.2.2.2⟩⟩
  loopless := ⟨by intro x h; exact h.1 rfl⟩

def canonicalRepresentatives (N : Size) (U : Finset (Vertex N)) : Finset (Vertex N) := by
  classical
  exact (canonicalCleanSet N U).filter fun x =>
    ∀ y ∈ canonicalCleanSet N U, (canonicalGraph N U).Reachable x y → lexLE x y
def canonicalComponent (N : Size) (U : Finset (Vertex N)) (a : Vertex N) : Finset (Vertex N) := by
  classical
  exact (canonicalCleanSet N U).filter fun x => (canonicalGraph N U).Reachable a x

def zeroSet (N : Size) (start : Vertex N) (ω : WalkSample) (t : ℝ) : Finset (Vertex N) := by
  classical
  exact Finset.univ.filter fun x => localTime N start ω t x = 0
def canonicalZeroMeasure (N : Size) (start : Vertex N) (ω : WalkSample) (c : ℝ) : TorusMeasure :=
  TorusMeasure.ofFinite (selectorWeight N •
    ∑ a ∈ canonicalRepresentatives N (zeroSet N start ω (phaseACenter N + c * timeScale N)),
      pointMass (embed a))

abbrev FiniteFieldSample (N : Size) := Vertex N → (ℝ × ℝ)
def finiteFieldLaw (N : Size) : Measure (FiniteFieldSample N) :=
  Measure.pi fun _ => (gaussianReal 0 1).prod (gaussianReal 0 1)
instance finiteFieldLaw_probability (N : Size) : IsProbabilityMeasure (finiteFieldLaw N) := by
  unfold finiteFieldLaw
  infer_instance

/-- Full frequency set: cosine and sine coefficients at k and -k are independent.
The factor 1/sqrt(n lambda_k) gives the Green covariance, including self-inverse modes. -/
def finiteGaussianField (N : Size) (ξ : FiniteFieldSample N) (x : Vertex N) : ℝ :=
  ∑ k ∈ nonzeroFrequencies N, Real.sqrt (1 / (vertexCount N * finiteEigenvalue N k)) *
    ((ξ k).1 * finiteCosine N k x + (ξ k).2 * finiteSine N k x)
def conditionedGaussianField (N : Size) (root : Vertex N)
    (ξ : FiniteFieldSample N) (x : Vertex N) : ℝ :=
  finiteGaussianField N ξ x - greenKernel N x root / greenDiagonal N * finiteGaussianField N ξ root

def FiniteGaussianRegular : Prop :=
  ∀ N : Size,
    (∀ x : Vertex N, MemLp (fun ξ => finiteGaussianField N ξ x) 2 (finiteFieldLaw N) ∧
      (∫ ξ, finiteGaussianField N ξ x ∂finiteFieldLaw N) = 0) ∧
    (∀ x y : Vertex N,
      (∫ ξ, finiteGaussianField N ξ x * finiteGaussianField N ξ y ∂finiteFieldLaw N) =
        greenKernel N x y) ∧
    (∀ root x y : Vertex N,
      (∫ ξ, conditionedGaussianField N root ξ x * conditionedGaussianField N root ξ y
        ∂finiteFieldLaw N) =
      greenKernel N x y - greenKernel N x root * greenKernel N root y / greenDiagonal N)

def activityNormalization : ℝ := 1 / Real.sqrt (2 * Real.pi * g)
def contactIntervals (N : Size) (A : Finset (Vertex N)) (ell z : Vertex N → ℝ) (v : ℝ) : Set ℝ :=
  ⋃ x ∈ A, Set.Icc (-z x - Real.sqrt (v - 2 * ell x)) (-z x + Real.sqrt (v - 2 * ell x))
def contactLength (N : Size) (A : Finset (Vertex N)) (ell z : Vertex N → ℝ) (v : ℝ) : ℝ :=
  (volume (contactIntervals N A ell z v)).toReal
def gaussianActivity (N : Size) (A : Finset (Vertex N)) (ell : Vertex N → ℝ)
    (root : Vertex N) (v : ℝ) : ℝ :=
  activityNormalization * ∫ ξ,
    contactLength N A ell (conditionedGaussianField N root ξ) v ∂finiteFieldLaw N

def fullActivity (N : Size) (start : Vertex N) (ω : WalkSample) (u₀ t v : ℝ) : TorusMeasure :=
  TorusMeasure.ofFinite (selectorWeight N •
    ∑ a ∈ canonicalRepresentatives N (softSet N start ω u₀ t),
      Real.toNNReal (gaussianActivity N
        (canonicalComponent N (softSet N start ω u₀ t) a)
        (fun x => localTime N start ω t x) start v) • pointMass (embed a))

/-- Explicit safeguards against total-integral defaults in the activity construction. -/
def ActivityRegular : Prop :=
  (∀ N : Size, ∀ A : Finset (Vertex N), ∀ ell z : Vertex N → ℝ, ∀ v : ℝ,
    volume (contactIntervals N A ell z v) ≠ ∞) ∧
  (∀ N : Size, ∀ A : Finset (Vertex N), ∀ ell : Vertex N → ℝ,
    ∀ root : Vertex N, ∀ v : ℝ,
      Integrable (fun ξ => contactLength N A ell (conditionedGaussianField N root ξ) v)
        (finiteFieldLaw N) ∧ 0 ≤ gaussianActivity N A ell root v) ∧
  (∀ N : Size, ∀ start : Vertex N, ∀ u₀ t v : ℝ,
    AEMeasurable (fun ω => fullActivity N start ω u₀ t v) walkLaw)

def stationaryWalkLaw (N : Size) : Measure (Vertex N × WalkSample) :=
  (uniformOn (Set.univ : Set (Vertex N))).prod walkLaw
instance stationaryWalkLaw_probability (N : Size) : IsProbabilityMeasure (stationaryWalkLaw N) := by
  unfold stationaryWalkLaw
  infer_instance

/-- Existence-form interface used by R24/R25. `ExplicitFullActivityLimit` in
Definitions.Extremal supplies the coefficient formula, and the theorem implementing
this interface is a checked projection of that stronger statement. -/
def FullActivityLimit (Z : FieldSample → TorusMeasure) : Prop :=
  ∀ u₀ : ℝ, 0 < u₀ → ∃ vStar : ℝ, 0 < vStar ∧ vStar < 2 * u₀ ∧
    ∀ v : ℝ, 0 < v → v < vStar → ∃ Γ : ℝ, 0 < Γ ∧ ∀ c : ℝ,
      TendstoInDistribution
        (fun N (ω : Vertex N × WalkSample) =>
          fullActivity N ω.1 ω.2 u₀ (phaseACenter N + c * timeScale N) v) atTop
        (fun ξ => (Z ξ).scale (Real.exp (-c) * Γ)) stationaryWalkLaw fieldLaw

/-- R24.15 with the source's final uniform-in-start extension, in epsilon/cutoff form. -/
def CanonicalZeroNondegenerate : Prop :=
  (∀ N : Size, ∀ start : Vertex N,
    AEMeasurable (fun ω => (canonicalZeroMeasure N start ω 0).mass) walkLaw) ∧
  (∀ η : ℝ, 0 < η → ∃ ζ : ℝ, 0 < ζ ∧ ∀ᶠ N : Size in atTop,
    ∀ start : Vertex N, walkLaw {ω | (canonicalZeroMeasure N start ω 0).mass < ζ} ≤
      ENNReal.ofReal η)

end TorusCoverTime
