import Definitions.Walk
import Mathlib.Combinatorics.SimpleGraph.Connectivity.Connected
import Mathlib.MeasureTheory.Measure.FiniteMeasure

/-! The selector is computed in the graph on the FULL unvisited set. A representative is the
lexicographically least nondefective vertex in its full component, including any defective
vertices in that component when computing the retained set and omitted remainder. -/

noncomputable section
open MeasureTheory
open scoped ENNReal NNReal

namespace TorusCoverTime

def unvisited (N : Size) (start : Vertex N) (ω : WalkSample) : Finset (Vertex N) := by
  classical
  exact Finset.univ.filter (fun x => ENNReal.ofReal (observationTime N) < hittingTime N start ω x)

def defective (N : Size) (U : Finset (Vertex N)) (x : Vertex N) : Prop :=
  x ∈ U ∧ ∃ y ∈ U, separationRadius N < periodicDistance x y ∧
    periodicDistance x y < distantRadius N

def clusterGraph (N : Size) (U : Finset (Vertex N)) : SimpleGraph (Vertex N) where
  Adj x y := x ≠ y ∧ x ∈ U ∧ y ∈ U ∧ periodicDistance x y ≤ connectionRadius N
  symm := ⟨by
    intro x y h
    exact ⟨h.1.symm, h.2.2.1, h.2.1, by simpa only [periodicDistance_comm] using h.2.2.2⟩⟩
  loopless := ⟨by intro x h; exact h.1 rfl⟩

def representatives (N : Size) (U : Finset (Vertex N)) : Finset (Vertex N) := by
  classical
  exact U.filter fun x => ¬ defective N U x ∧
    ∀ y ∈ U, ¬ defective N U y → (clusterGraph N U).Reachable x y → lexLE x y

def retained (N : Size) (U : Finset (Vertex N)) : Finset (Vertex N) := by
  classical
  exact U.filter fun x => ∃ a ∈ representatives N U, (clusterGraph N U).Reachable a x

def omitted (N : Size) (start : Vertex N) (ω : WalkSample) : Finset (Vertex N) := by
  classical
  exact unvisited N start ω \ retained N (unvisited N start ω)

def pointMass (x : Torus) : FiniteMeasure Torus := ⟨Measure.dirac x, inferInstance⟩

def selectorMeasure (N : Size) (start : Vertex N) (ω : WalkSample) : FiniteMeasure Torus :=
  selectorWeight N • ∑ a ∈ representatives N (unvisited N start ω), pointMass (embed a)

def selectorMass (N : Size) (start : Vertex N) (ω : WalkSample) : ℝ :=
  (selectorMeasure N start ω).mass

theorem representative_mem_unvisited (N : Size) (U : Finset (Vertex N))
    {x : Vertex N} (hx : x ∈ representatives N U) : x ∈ U := by
  classical
  exact (Finset.mem_filter.mp hx).1

theorem representative_not_defective (N : Size) (U : Finset (Vertex N))
    {x : Vertex N} (hx : x ∈ representatives N U) : ¬ defective N U x := by
  classical
  exact (Finset.mem_filter.mp hx).2.1

end TorusCoverTime
