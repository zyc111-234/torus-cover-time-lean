import Definitions.Selector
import Definitions.PeriodicHeatField
import Mathlib.MeasureTheory.Function.ConvergenceInDistribution
import Mathlib.MeasureTheory.Measure.LevyProkhorovMetric
import Mathlib.Probability.Independence.Basic
import Mathlib.MeasureTheory.Function.ConditionalExpectation.Basic

/-! Definitions for the scalar cover-time limit and its probabilistic ingredients. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter
open scoped ENNReal NNReal Topology

namespace TorusCoverTime

def selectorRandomMeasure (N : Size) (start : Vertex N) (ω : WalkSample) : TorusMeasure :=
  TorusMeasure.ofFinite (selectorMeasure N start ω)

/-- The version fixed by the future-walk kernel in Section C, including its early-time branch. -/
def coverageKernel (N : Size) (start : Vertex N) (ω : WalkSample) (z : ℝ) : ℝ := by
  classical
  exact if observationTime N ≤ thresholdTime N z then
    (walkLaw {ω' | setCoverTime N (walk N start ω (observationTime N))
      (unvisited N start ω) ω' ≤ ENNReal.ofReal (remainingTime N z)}).toReal
  else if coveredBy N start ω (thresholdTime N z) then 1 else 0

/-- Raw natural history at s_N. Its completed version gives the same conditional expectation
almost surely; the explicit kernel is required to represent this conditional probability. -/
@[instance_reducible]
def observationHistory (N : Size) (start : Vertex N) : MeasurableSpace WalkSample :=
  ⨆ t : {t : ℝ // 0 ≤ t ∧ t ≤ observationTime N},
    MeasurableSpace.comap (fun ω => walk N start ω t.val) ⊤

def ConditionalKernelCorrect : Prop := by
  classical
  exact ∀ N : Size, ∀ start : Vertex N,
    observationHistory N start ≤ (inferInstance : MeasurableSpace WalkSample) ∧
    ∀ z : ℝ, (fun ω => coverageKernel N start ω z) =ᵐ[walkLaw]
      condExp (observationHistory N start) walkLaw
        (fun ω => if coveredBy N start ω (thresholdTime N z) then (1 : ℝ) else 0)

/-- Completion of the history by ambient walk-law null sets. Its generating sets
are exactly sets agreeing almost everywhere with a raw-history-measurable set. -/
@[instance_reducible]
def completedObservationHistory (N : Size) (start : Vertex N) : MeasurableSpace WalkSample :=
  MeasurableSpace.generateFrom {s | ∃ t : Set WalkSample,
    @MeasurableSet WalkSample (observationHistory N start) t ∧ s =ᵐ[walkLaw] t}

def HistoryCompletionBridge : Prop := by
  classical
  exact ∀ N : Size, ∀ start : Vertex N,
    observationHistory N start ≤ completedObservationHistory N start ∧
    completedObservationHistory N start ≤
      (inferInstance : MeasurableSpace (NullMeasurableSpace WalkSample walkLaw)) ∧
    (∀ f : WalkSample → ℝ, Integrable f walkLaw →
      condExp (observationHistory N start) walkLaw f =ᵐ[walkLaw]
        condExp (completedObservationHistory N start) walkLaw.completion f) ∧
    ∀ z : ℝ, (fun ω => coverageKernel N start ω z) =ᵐ[walkLaw]
      condExp (completedObservationHistory N start) walkLaw.completion
        (fun ω => if coveredBy N start ω (thresholdTime N z) then (1 : ℝ) else 0)

def conditionalWindowError (N : Size) (start : Vertex N) (Z : ℝ) (ω : WalkSample) : ℝ :=
  ⨆ z : {z : ℝ // |z| ≤ Z},
    |coverageKernel N start ω z.val - Real.exp (-selectorMass N start ω * Real.exp (-z.val))|

def uniformConditionalError (N : Size) (Z : ℝ) : ℝ :=
  ⨆ start : Vertex N, ∫ ω, conditionalWindowError N start Z ω ∂walkLaw

def WalkModelRegular : Prop :=
  (∀ᵐ ω ∂walkLaw, (∀ j, 0 < (ω j).1) ∧ Tendsto (jumpTime ω) atTop atTop) ∧
  (∀ N : Size, ∀ start : Vertex N, ∀ᵐ ω ∂walkLaw, coverTime N start ω ≠ ∞) ∧
  (∀ N : Size, ∀ start : Vertex N, AEMeasurable (normalizedCoverTime N start) walkLaw) ∧
  (∀ N : Size, ∀ start : Vertex N, AEMeasurable (selectorRandomMeasure N start) walkLaw) ∧
  (∀ N : Size, ∀ start : Vertex N, ∀ Z : ℝ, 0 ≤ Z →
    Integrable (conditionalWindowError N start Z) walkLaw)

/-- Lévy-Prokhorov distance on finite measures expresses probability convergence in the
weak topology on this compact metric torus. ε tends to zero through POSITIVE real scales. -/
def CriticalChaosLimit (Z : FieldSample → TorusMeasure) : Prop :=
  AEMeasurable Z fieldLaw ∧
  (∀ ε : ℝ, 0 < ε → AEMeasurable (chaosApproximation ε) fieldLaw) ∧
  (∀ᵐ ω ∂fieldLaw, 0 < (Z ω).mass) ∧
  (∀ η : ℝ, 0 < η → Tendsto
    (fun ε : ℝ => fieldLaw {ω | η ≤
      levyProkhorovDist (chaosApproximation ε ω).toMeasure (Z ω).toMeasure})
    (𝓝[>] (0 : ℝ)) (𝓝 0)) ∧
  (∀ᵐ ω ∂fieldLaw, ∀ V : Set Torus, IsOpen V → V.Nonempty →
    0 < (Z ω).toMeasure V)

def PhaseALimit (Z : FieldSample → TorusMeasure) (κ : ℝ) : Prop :=
  ∀ start : (N : Size) → Vertex N,
    TendstoInDistribution (fun N => selectorRandomMeasure N (start N)) atTop
      (fun ω => (Z ω).scale κ) (fun _ => walkLaw) fieldLaw

def ConditionalCoverageLimit : Prop :=
  ∀ Z : ℝ, 0 ≤ Z → Tendsto (fun N : Size => uniformConditionalError N Z) atTop (𝓝 0)

def mixtureCDF (Z : FieldSample → TorusMeasure) (κ z : ℝ) : ℝ :=
  ∫ ω, Real.exp (-((Z ω).scale κ).mass * Real.exp (-z)) ∂fieldLaw

def uniformCDFError (Z : FieldSample → TorusMeasure) (κ : ℝ) (N : Size) : ℝ :=
  ⨆ start : Vertex N, ⨆ z : ℝ,
    |(walkLaw {ω | normalizedCoverTime N start ω ≤ z}).toReal - mixtureCDF Z κ z|

def ScalarCoverageLimit (Z : FieldSample → TorusMeasure) (κ : ℝ) : Prop :=
  Tendsto (uniformCDFError Z κ) atTop (𝓝 0)

def jointLimitLaw : Measure (FieldSample × ℝ) := fieldLaw.prod holdingLaw
instance jointLimitLaw_probability : IsProbabilityMeasure jointLimitLaw := by
  unfold jointLimitLaw
  infer_instance

/-- `-log E` for an independent rate-one exponential `E` has the standard Gumbel law. -/
def gumbelCoordinate (ω : FieldSample × ℝ) : ℝ := -Real.log ω.2

def StandardGumbelCDF : Prop :=
  ∀ z : ℝ, (jointLimitLaw {ω | gumbelCoordinate ω ≤ z}).toReal =
    Real.exp (-Real.exp (-z))


end TorusCoverTime
