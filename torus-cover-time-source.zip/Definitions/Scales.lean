import Definitions.Torus
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring

noncomputable section
open scoped NNReal

namespace TorusCoverTime

def g : ℝ := 2 / Real.pi
def logSize (N : Size) : ℝ := Real.log (N.val : ℝ)
def timeScale (N : Size) : ℝ := g * (N.val : ℝ) ^ 2 * logSize N
def observationTime (N : Size) : ℝ :=
  timeScale N * (2 * logSize N - (3 / 2 : ℝ) * Real.log (logSize N))
def timeCenter (N : Size) : ℝ :=
  timeScale N * (2 * logSize N - Real.log (logSize N))
def thresholdTime (N : Size) (z : ℝ) : ℝ := timeCenter N + z * timeScale N
def remainingTime (N : Size) (z : ℝ) : ℝ := thresholdTime N z - observationTime N
def separationRadius (N : Size) : ℝ := Real.exp ((logSize N) ^ (1 / 8 : ℝ))
def connectionRadius (N : Size) : ℝ := (⌈separationRadius N⌉₊ : ℝ)
def distantRadius (N : Size) : ℝ := (N.val : ℝ) * Real.exp (-((logSize N) ^ (1 / 8 : ℝ)))
def selectorWeight (N : Size) : ℝ≥0 := Real.toNNReal (1 / Real.sqrt (logSize N))

theorem size_real_gt_one (N : Size) : 1 < (N.val : ℝ) := by
  have : 1 < N.val := by have := N.property; omega
  exact_mod_cast this

theorem logSize_pos (N : Size) : 0 < logSize N := Real.log_pos (size_real_gt_one N)

theorem timeScale_pos (N : Size) : 0 < timeScale N := by
  have := logSize_pos N
  have := size_real_gt_one N
  unfold timeScale g
  positivity

theorem observationTime_pos (N : Size) : 0 < observationTime N := by
  have hL := logSize_pos N
  have hlog := Real.log_le_sub_one_of_pos hL
  exact mul_pos (timeScale_pos N) (by linarith)

/-- Exact identity from Section C; no asymptotic replacement of the centering. -/
theorem remainingTime_eq (N : Size) (z : ℝ) :
    remainingTime N z = timeScale N * ((1 / 2 : ℝ) * Real.log (logSize N) + z) := by
  unfold remainingTime thresholdTime timeCenter observationTime
  ring

end TorusCoverTime
