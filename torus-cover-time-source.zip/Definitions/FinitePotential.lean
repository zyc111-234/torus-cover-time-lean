import Definitions.TerminalInterfaces

/-! Concrete finite Fourier/Green and variational spectral objects for S1--S2 and B2.
The infima and epsilon choice are total definitions; their attainment and validity are
explicit conclusions of CapacitySpectrum, never proof assumptions hidden in a definition. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter
open scoped ENNReal NNReal Topology
namespace TorusCoverTime

def vertexCount (N : Size) : ℝ := (N.val : ℝ) ^ 2
def nonzeroFrequencies (N : Size) : Finset (Vertex N) := Finset.univ.erase 0
def fourierAngle (N : Size) (k x : Vertex N) : ℝ :=
  2 * Real.pi * ((k.1.val : ℝ) * x.1.val + (k.2.val : ℝ) * x.2.val) / N.val
def finiteCosine (N : Size) (k x : Vertex N) : ℝ := Real.cos (fourierAngle N k x)
def finiteSine (N : Size) (k x : Vertex N) : ℝ := Real.sin (fourierAngle N k x)
def finiteEigenvalue (N : Size) (k : Vertex N) : ℝ :=
  1 - (Real.cos (2 * Real.pi * k.1.val / N.val) +
    Real.cos (2 * Real.pi * k.2.val / N.val)) / 2
def frequencyNormSq (N : Size) (k : Vertex N) : ℝ :=
  (coordinateDistance k.1 0) ^ 2 + (coordinateDistance k.2 0) ^ 2
def spectralGap (N : Size) : ℝ := (Real.sin (Real.pi / N.val)) ^ 2
def greenKernel (N : Size) (x y : Vertex N) : ℝ :=
  (∑ k ∈ nonzeroFrequencies N, finiteCosine N k (x - y) / finiteEigenvalue N k) /
    vertexCount N
def greenDiagonal (N : Size) : ℝ := greenKernel N 0 0
def tailGreen (N : Size) (t : ℝ) (x y : Vertex N) : ℝ :=
  (∑ k ∈ nonzeroFrequencies N, Real.exp (-t * finiteEigenvalue N k) *
    finiteCosine N k (x - y) / finiteEigenvalue N k) / vertexCount N
def transitionProbability (N : Size) (x y : Vertex N) (t : ℝ) : ℝ :=
  (walkLaw {ω | walk N x ω t = y}).toReal
def mixingTime (N : Size) : ℝ := 4 * vertexCount N * Real.log (logSize N)

def FourierWalkIdentities : Prop :=
  (∀ N : Size, ∀ k : Vertex N,
    4 * frequencyNormSq N k / vertexCount N ≤ finiteEigenvalue N k ∧
    finiteEigenvalue N k ≤ Real.pi ^ 2 * frequencyNormSq N k / vertexCount N ∧
    ∀ x : Vertex N,
      -generator N (finiteCosine N k) x = finiteEigenvalue N k * finiteCosine N k x ∧
      -generator N (finiteSine N k) x = finiteEigenvalue N k * finiteSine N k x) ∧
  (∀ N : Size, ∀ t : ℝ, 0 ≤ t → ∀ x y : Vertex N,
    vertexCount N * transitionProbability N x y t = 1 +
      ∑ k ∈ nonzeroFrequencies N, Real.exp (-t * finiteEigenvalue N k) *
        finiteCosine N k (x - y)) ∧
  (∀ N : Size, ∀ t : ℝ, 0 ≤ t → ∀ x y : Vertex N,
    Integrable (fun ω => localTime N x ω t y) walkLaw ∧
    (∫ ω, localTime N x ω t y ∂walkLaw) =
      t / vertexCount N + greenKernel N x y - tailGreen N t x y) ∧
  (∀ᶠ N : Size in atTop, ∀ t : ℝ, mixingTime N ≤ t → ∀ x y : Vertex N,
    |vertexCount N * transitionProbability N x y t - 1| ≤ (logSize N) ^ (-8 : ℝ) ∧
    |tailGreen N t x y| ≤ (logSize N) ^ (-8 : ℝ))

def GreenEstimates : Prop :=
  ∃ C : ℝ, 0 < C ∧ ∀ N : Size, ∀ x y : Vertex N,
    greenKernel N x x = greenDiagonal N ∧
    |greenDiagonal N - g * logSize N| ≤ C ∧
    |greenKernel N x y| ≤ C * (1 + Real.log ((N.val : ℝ) / max (periodicDistance x y) 1)) ∧
    0 ≤ greenKernel N x x - greenKernel N x y ∧
    greenKernel N x x - greenKernel N x y ≤ C * Real.log (2 + periodicDistance x y) ∧
    (distantRadius N / 4 ≤ periodicDistance x y →
      |greenKernel N x y| ≤ C * (logSize N) ^ (1 / 8 : ℝ))

def spatialMean (N : Size) (f : Vertex N → ℝ) : ℝ := (∑ x, f x) / vertexCount N
def energy (N : Size) (f : Vertex N → ℝ) : ℝ := ∑ x, f x * (-generator N f x)
def vanishesOn (N : Size) (A : Finset (Vertex N)) (f : Vertex N → ℝ) : Prop :=
  ∀ x ∈ A, f x = 0
def capacity (N : Size) (A : Finset (Vertex N)) : ℝ :=
  sInf {r : ℝ | ∃ f : Vertex N → ℝ, spatialMean N f = 0 ∧
    (∀ x ∈ A, f x = 1) ∧ energy N f = r}
def killedEigenvalue (N : Size) (A : Finset (Vertex N)) : ℝ :=
  sInf {r : ℝ | ∃ f : Vertex N → ℝ, vanishesOn N A f ∧
    (∑ x, (f x) ^ 2) = 1 ∧ energy N f = r}
def capacityRatio (N : Size) (A : Finset (Vertex N)) : ℝ :=
  capacity N A / (vertexCount N * spectralGap N)
def IsPrincipalMode (N : Size) (A : Finset (Vertex N)) (f : Vertex N → ℝ) : Prop :=
  vanishesOn N A f ∧ spatialMean N f = 1 ∧ (∀ x, 0 ≤ f x) ∧
    ∀ x, x ∉ A → -generator N f x = killedEigenvalue N A * f x
def principalMode (N : Size) (A : Finset (Vertex N)) : Vertex N → ℝ :=
  Classical.epsilon (IsPrincipalMode N A)
def principalVariance (N : Size) (A : Finset (Vertex N)) : ℝ :=
  spatialMean N (fun x => (principalMode N A x) ^ 2) - 1
def greenChargeEquation (N : Size) (A : Finset (Vertex N)) (q : Vertex N → ℝ) : Prop :=
  (∀ x, x ∉ A → q x = 0) ∧ ∀ x ∈ A, (∑ y, greenKernel N x y * q y) = 1

def IsCapacityMinimizer (N : Size) (A : Finset (Vertex N)) (f : Vertex N → ℝ) : Prop :=
  spatialMean N f = 0 ∧ (∀ x ∈ A, f x = 1) ∧ energy N f = capacity N A

/-- Inverse-Green capacity is expressed by its unique linear-system solution.
The second-eigenvalue bound is expressed as the Rayleigh inequality on the orthogonal
complement; no connectivity assumption on the complement of A is introduced. -/
def CapacitySpectrum : Prop :=
  ∀ N : Size, ∀ A : Finset (Vertex N), A.Nonempty → A ≠ Finset.univ →
    0 < capacity N A ∧
    (∀ q : Vertex N → ℝ, (∀ x, x ∉ A → q x = 0) → q ≠ 0 →
      0 < ∑ x, ∑ y, q x * greenKernel N x y * q y) ∧
    (∃ q : Vertex N → ℝ, greenChargeEquation N A q ∧
      (∀ q', greenChargeEquation N A q' → q' = q) ∧ (∑ x, q x) = capacity N A ∧
      (∀ x ∈ A, capacity N A / vertexCount N ≤ q x) ∧
      (∀ x, (∑ y, greenKernel N x y * q y) ≤ 1) ∧
      spatialMean N (fun x => ∑ y, greenKernel N x y * q y) = 0 ∧
      energy N (fun x => ∑ y, greenKernel N x y * q y) = capacity N A ∧
      (∀ f, IsCapacityMinimizer N A f → f = fun x => ∑ y, greenKernel N x y * q y) ∧
      (∀ x, 0 ≤ q x / capacity N A) ∧ (∑ x, q x / capacity N A) = 1) ∧
    (capacityRatio N A < 1 →
      IsPrincipalMode N A (principalMode N A) ∧
      (∀ f : Vertex N → ℝ, vanishesOn N A f →
        (∀ x, x ∉ A → -generator N f x = killedEigenvalue N A * f x) →
        ∃ c : ℝ, f = fun x => c * principalMode N A x) ∧
      (1 - capacityRatio N A) * capacity N A / vertexCount N ≤ killedEigenvalue N A ∧
      killedEigenvalue N A ≤ capacity N A / vertexCount N ∧
      0 ≤ principalVariance N A ∧
      principalVariance N A ≤ capacityRatio N A / (1 - capacityRatio N A) ∧
      (∀ f : Vertex N → ℝ, vanishesOn N A f →
        (∑ x, f x * principalMode N A x) = 0 →
        spectralGap N * (∑ x, (f x) ^ 2) ≤ energy N f))

def stationarySurvival (N : Size) (A : Finset (Vertex N)) (t : ℝ) : ℝ :=
  (∑ start : Vertex N,
    (walkLaw {ω | ∀ a ∈ A, ENNReal.ofReal t < hittingTime N start ω a}).toReal) / vertexCount N
def stationaryRemainder (N : Size) (A : Finset (Vertex N)) (t : ℝ) : ℝ :=
  stationarySurvival N A t - Real.exp (-killedEigenvalue N A * t) / (1 + principalVariance N A)
def StationaryKilledExpansion : Prop :=
  ∀ N : Size, ∀ A : Finset (Vertex N), A.Nonempty → A ≠ Finset.univ →
    capacityRatio N A < 1 → ∀ t : ℝ, 0 ≤ t →
      0 ≤ stationaryRemainder N A t ∧
      stationaryRemainder N A t ≤
        (1 - (A.card : ℝ) / vertexCount N - 1 / (1 + principalVariance N A)) *
          Real.exp (-spectralGap N * t) ∧
      stationaryRemainder N A t ≤ principalVariance N A * Real.exp (-spectralGap N * t) ∧
      ((Finset.univ \ A).card = 1 → stationaryRemainder N A t = 0)

def FixedTargetCapacityEstimate : Prop :=
  ∀ k : ℕ, 0 < k → ∃ C : ℝ, 0 < C ∧ ∀ᶠ N : Size in atTop,
    ∀ A : Finset (Vertex N), A.card = k → separatedTarget N A →
      |capacity N A * (g * logSize N) / k - 1| ≤ C * (logSize N) ^ (-7 / 8 : ℝ) ∧
      |capacityRatio N A| ≤ C / logSize N ∧
      |timeScale N * killedEigenvalue N A - k| ≤ C * (logSize N) ^ (-7 / 8 : ℝ) ∧
      |principalVariance N A| ≤ C / logSize N

end TorusCoverTime
