import Definitions.MeasureSpace
import Definitions.Scales
import Mathlib.Probability.ProductMeasure
import Mathlib.Probability.Distributions.Gaussian.Real
import Mathlib.MeasureTheory.Function.LocallyIntegrable
import Mathlib.Tactic.FunProp

/-! A concrete real Fourier model of the mean-zero periodic field with covariance 4(-Δ)⁻¹.
One member of each pair {k,-k} supplies an independent cosine and sine Gaussian coefficient.
The variance of EACH real coefficient is 8/λ_k, because cosine and sine have L² norm 1/√2.
The heat multiplier is exp(-ε² λ_k), exactly the smoothing time in (F.3).
Convergence of the series, its covariance, and the critical limit remain proof obligations. -/

noncomputable section
open MeasureTheory ProbabilityTheory
open scoped ENNReal NNReal Topology

namespace TorusCoverTime

abbrev PositiveMode := {k : ℤ × ℤ // 0 < k.1 ∨ (k.1 = 0 ∧ 0 < k.2)}
abbrev FieldSample := PositiveMode → (ℝ × ℝ)

instance continuousField_measurableSpace : MeasurableSpace C(Torus, ℝ) := borel _
instance continuousField_borelSpace : BorelSpace C(Torus, ℝ) := ⟨rfl⟩

def fieldLaw : Measure FieldSample :=
  Measure.infinitePi (fun _ : PositiveMode => (gaussianReal 0 1).prod (gaussianReal 0 1))

instance fieldLaw_probability : IsProbabilityMeasure fieldLaw := by unfold fieldLaw; infer_instance

def modeIndex (k : PositiveMode) : Fin 2 → ℤ := fun i => if i = 0 then k.val.1 else k.val.2
def eigenvalue (k : PositiveMode) : ℝ :=
  4 * Real.pi ^ 2 * ((k.val.1 : ℝ) ^ 2 + (k.val.2 : ℝ) ^ 2)

def cosineMode (k : PositiveMode) : C(Torus, ℝ) :=
  ⟨fun x => (UnitAddTorus.mFourier (modeIndex k) x).re, by fun_prop⟩
def sineMode (k : PositiveMode) : C(Torus, ℝ) :=
  ⟨fun x => (UnitAddTorus.mFourier (modeIndex k) x).im, by fun_prop⟩

def heatMode (ε : ℝ) (ω : FieldSample) (k : PositiveMode) : C(Torus, ℝ) :=
  (Real.sqrt (8 / eigenvalue k) * Real.exp (-(ε ^ 2 * eigenvalue k))) •
    ((ω k).1 • cosineMode k + (ω k).2 • sineMode k)

/-- The sum is in the Banach space of continuous functions, i.e. uniform convergence.
As with every `tsum`, nonsummable inputs are totalized to zero; `HeatFieldRegular` below
requires summability almost surely for every positive smoothing scale. -/
def heatField (ε : ℝ) (ω : FieldSample) : C(Torus, ℝ) := ∑' k, heatMode ε ω k

def heatVariance (ε : ℝ) : ℝ := ∫ ω, (heatField ε ω 0) ^ 2 ∂fieldLaw
def criticalParameter : ℝ := 2 / Real.sqrt g

def heatCovariance (ε δ : ℝ) (x y : Torus) : ℝ :=
  ∑' k : PositiveMode, (8 / eigenvalue k) *
    Real.exp (-((ε ^ 2 + δ ^ 2) * eigenvalue k)) *
      (UnitAddTorus.mFourier (modeIndex k) (x - y)).re

/-- These are conclusions still to prove for the explicit series, not hypotheses imported
from the manuscript or assumptions replacing Phase A. -/
def HeatFieldRegular : Prop :=
  (∀ ε : ℝ, 0 < ε → ∀ᵐ ω ∂fieldLaw, Summable (heatMode ε ω)) ∧
  (∀ ε : ℝ, 0 < ε → AEMeasurable (heatField ε) fieldLaw) ∧
  (∀ ε : ℝ, 0 < ε → ∀ x : Torus, MemLp (fun ω => heatField ε ω x) 2 fieldLaw) ∧
  (∀ ε : ℝ, 0 < ε → ∀ x : Torus, (∫ ω, heatField ε ω x ∂fieldLaw) = 0) ∧
  (∀ ε δ : ℝ, 0 < ε → 0 < δ → ∀ x y : Torus,
    (∫ ω, heatField ε ω x * heatField δ ω y ∂fieldLaw) = heatCovariance ε δ x y)

abbrev FourierTest := PositiveMode → (ℝ × ℝ)

/-- Fourier description of smooth mean-zero tests: every polynomially weighted
absolute coefficient sum is finite. Constant tests pair to zero for the mean-zero field. -/
def RapidFourierDecay (a : FourierTest) : Prop :=
  ∀ p : ℕ, Summable (fun k => (1 + eigenvalue k) ^ p * (|(a k).1| + |(a k).2|))

def fieldCoefficient (ω : FieldSample) (k : PositiveMode) : ℝ × ℝ :=
  (Real.sqrt (8 / eigenvalue k) * (ω k).1, Real.sqrt (8 / eigenvalue k) * (ω k).2)

def distributionPairingTerm (ω : FieldSample) (a : FourierTest) (k : PositiveMode) : ℝ :=
  ((fieldCoefficient ω k).1 * (a k).1 + (fieldCoefficient ω k).2 * (a k).2) / 2

def distributionPairing (ω : FieldSample) (a : FourierTest) : ℝ :=
  ∑' k, distributionPairingTerm ω a k

def inverseLaplacianPairing (a b : FourierTest) : ℝ :=
  ∑' k, ((a k).1 * (b k).1 + (a k).2 * (b k).2) / (2 * eigenvalue k)

def heatTest (ε : ℝ) (x : Torus) : FourierTest := fun k =>
  (2 * Real.exp (-(ε ^ 2 * eigenvalue k)) * cosineMode k x,
   2 * Real.exp (-(ε ^ 2 * eigenvalue k)) * sineMode k x)

/-- Distributional realization in Fourier coordinates: a continuous linear
functional on the rapidly decreasing test coefficients, Gaussian covariance
4(-Delta)^(-1), and equality of its heat smoothing with the concrete series. -/
def FourierDistributionBridge : Prop :=
  (∀ᵐ ω ∂fieldLaw, ∃ p : ℕ, ∃ C : ℝ, 0 ≤ C ∧
    (∀ k, |(fieldCoefficient ω k).1| + |(fieldCoefficient ω k).2| ≤
      C * (1 + eigenvalue k) ^ p) ∧
    (∀ a : FourierTest, RapidFourierDecay a → Summable (distributionPairingTerm ω a) ∧
      |distributionPairing ω a| ≤ C * ∑' k,
        (1 + eigenvalue k) ^ p * (|(a k).1| + |(a k).2|)) ∧
    (∀ a b : FourierTest, RapidFourierDecay a → RapidFourierDecay b →
      distributionPairing ω (a + b) = distributionPairing ω a + distributionPairing ω b) ∧
    (∀ a : FourierTest, RapidFourierDecay a → ∀ c : ℝ,
      distributionPairing ω (c • a) = c * distributionPairing ω a)) ∧
  (∀ a : FourierTest, RapidFourierDecay a →
    MemLp (fun ω => distributionPairing ω a) 2 fieldLaw ∧
    (∫ ω, distributionPairing ω a ∂fieldLaw) = 0 ∧
    Measure.map (fun ω => distributionPairing ω a) fieldLaw =
      gaussianReal 0 (Real.toNNReal (4 * inverseLaplacianPairing a a))) ∧
  (∀ a b : FourierTest, RapidFourierDecay a → RapidFourierDecay b →
    (∫ ω, distributionPairing ω a * distributionPairing ω b ∂fieldLaw) =
      4 * inverseLaplacianPairing a b) ∧
  (∀ ε : ℝ, 0 < ε → (∀ x, RapidFourierDecay (heatTest ε x)) ∧
    ∀ᵐ ω ∂fieldLaw, ∀ x : Torus, distributionPairing ω (heatTest ε x) = heatField ε ω x)

def torusVolume : Measure Torus :=
  Measure.pi (fun _ : Fin 2 => AddCircle.haarAddCircle (T := (1 : ℝ)))

instance torusVolume_probability : IsProbabilityMeasure torusVolume := by
  unfold torusVolume
  infer_instance

def chaosDensity (ε : ℝ) (ω : FieldSample) : C(Torus, ℝ) :=
  ⟨fun x => Real.sqrt (Real.log (1 / ε)) *
    Real.exp (criticalParameter * heatField ε ω x - criticalParameter ^ 2 * heatVariance ε / 2),
    by fun_prop⟩

def chaosApproximation (ε : ℝ) (ω : FieldSample) : TorusMeasure :=
  TorusMeasure.ofFinite ⟨torusVolume.withDensity (fun x => ENNReal.ofReal (chaosDensity ε ω x)),
    isFiniteMeasure_withDensity_ofReal
      ((chaosDensity ε ω).continuous.integrable_of_hasCompactSupport
        (HasCompactSupport.of_compactSpace _)).hasFiniteIntegral⟩

end TorusCoverTime
