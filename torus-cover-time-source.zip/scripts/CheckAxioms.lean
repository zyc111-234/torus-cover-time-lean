import Scalar
import Lean.Util.CollectAxioms

/-! Audit the main theorem's axioms and required proof dependencies. -/
namespace ProofAudit
open Lean

def isProjectName (n : Name) : Bool :=
  let s := n.toString
  s.startsWith "TorusCoverTime." || s.startsWith "_private.Solutions." ||
    s.startsWith "_private.Definitions." || s.startsWith "_private.Theorems."

structure DependencyState where
  seen : NameSet := {}
  missing : Array Name := #[]

partial def visit (env : Environment) (n : Name) : StateM DependencyState Unit := do
  unless isProjectName n do return
  if (← get).seen.contains n then return
  modify fun s => { s with seen := s.seen.insert n }
  match env.find? n with
  | none => modify fun s => { s with missing := s.missing.push n }
  | some info =>
    for dep in info.type.getUsedConstants do visit env dep
    if let some value := info.value? true then
      for dep in value.getUsedConstants do visit env dep
    match info with
    | .inductInfo info => for ctor in info.ctors do visit env ctor
    | _ => pure ()

def collect (env : Environment) (target : Name) : DependencyState :=
  ((visit (env.setExporting false) target).run {}).2

end ProofAudit

/-! Run after building Scalar and checking the theorem contracts. -/
open TorusCoverTime Filter
open scoped Topology

example : ∃ Z : FieldSample → TorusMeasure, CriticalChaosLimit Z ∧
    ∃ κ : ℝ, 0 < κ ∧ Tendsto (uniformCDFError Z κ) atTop (𝓝 0) :=
  scalar_cover_time_limit

open Lean in
def ProofAudit.run : MetaM Unit := do
  let targets := [``TorusCoverTime.Blocks.D.R25.r25_n5,
    ``TorusCoverTime.scalar_main_from_milestones, ``TorusCoverTime.scalar_cover_time_limit]
  let allowed := [`propext, `Classical.choice, `Quot.sound]
  for target in targets do
    let axioms ← Lean.collectAxioms target
    for ax in axioms do
      unless allowed.contains ax do throwError "Unexpected axiom {ax} in {target}"
    IO.println ("AXIOMS:" ++ (Json.mkObj [
      ("target",toJson target.toString),
      ("axioms",toJson (axioms.toList.map Name.toString))]).compress)
  let target := ``TorusCoverTime.scalar_cover_time_limit
  let deps := ProofAudit.collect (← getEnv) target
  unless deps.missing.isEmpty do
    throwError "Missing project constants during dependency audit: {deps.missing}"
  let required : List Name := [
    ``TorusCoverTime.CoverTime.r7_actual_word_one_success,
    ``TorusCoverTime.CoverTime.r7_perturbed_actual_word_one_success,
    ``TorusCoverTime.CoverTime.weighted_intersection_bound,
    ``TorusCoverTime.Blocks.D.R25.S08Width.conditional_pair_mean,
    ``TorusCoverTime.CoverTime.original_scalar_budget_relative,
    ``TorusCoverTime.CoverTime.common_window_coefficient,
    ``TorusCoverTime.CoverTime.central_scalar_limit,
    ``TorusCoverTime.CoverTime.Terminal.fixed_target_capacity,
    ``TorusCoverTime.CoverTime.Terminal.weighted_occupation_splice,
    ``TorusCoverTime.CoverTime.Terminal.central_configuration_budget,
    ``TorusCoverTime.CoverTime.Terminal.central_window_error_tendsto,
    ``TorusCoverTime.CoverTime.Terminal.scalar_coverage_limit]
  let forbidden : List Name := [
    `TorusCoverTime.Blocks.D.R25.n5_selector_laplace,
    `TorusCoverTime.Blocks.D.R25.n5_selector_mass_tight,
    `TorusCoverTime.Blocks.D.R25.n5_conditional_of_tight,
    `TorusCoverTime.Blocks.D.R25.n5_scalar_of_selector_laplace,
    `TorusCoverTime.Blocks.D.R25.selector_stationary_expectation_small]
  for name in required do
    unless deps.seen.contains name do throwError "Required proof component not used: {name}"
  for name in forbidden do
    if deps.seen.contains name then throwError "Old N5 selector transfer remains: {name}"
  IO.println ("PROOF_DEPENDENCIES:" ++ (Json.mkObj [
    ("target",toJson target.toString),
    ("required_present",toJson (required.map Name.toString)),
    ("forbidden_absent",toJson (forbidden.map Name.toString))]).compress)

-- Execute the audit.
run_meta ProofAudit.run
