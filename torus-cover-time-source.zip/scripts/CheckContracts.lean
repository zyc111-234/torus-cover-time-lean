import Scalar

/-! Local contracts for the actual central canonical terminal chain.
This file does not run a transitive dependency or axiom audit. -/
noncomputable section
open Classical Real MeasureTheory ProbabilityTheory Filter Set
open scoped ENNReal Topology
namespace TorusCoverTime.CoverTime.ContractChecks
open Terminal Blocks.D Blocks.D.R25
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1600000

-- Empty configurations have mass zero and are already covered, including
-- the zero-time boundary. No nonempty-cluster hypothesis is hidden here.
example (N : Size) (y : Vertex N) (t : ℝ) : coverProbability N y ∅ t = 1 := by
  simp [coverProbability,setCoverTime]

example (N : Size) : mass N ∅ = 0 := by
  simp [mass,canonicalRepresentatives,canonicalCleanSet]

-- The error and final CDF use one coefficient from the actual central law.
example (Z : FieldSample → TorusMeasure) (hZ : CriticalChaosLimit Z) :
    ∃ κ : ℝ, 0 < κ ∧ CentralLaplace Z κ ∧
      (∀ W : ℝ, 0 ≤ W → Tendsto (fun N : Size =>
        ∫ p : Vertex N × WalkSample,
          (⨆ z : {z : ℝ // |z| ≤ W},
            |centralKernel N p.1 z.val p.2 -
              exp (-(canonicalZeroMeasure N p.1 p.2 0).mass*exp (-z.val))|)
          ∂stationaryWalkLaw N) atTop (𝓝 0)) ∧ ScalarCoverageLimit Z κ := by
  obtain ⟨κ,hκ,hL⟩ := central_laplace Z hZ
  refine ⟨κ,hκ,hL,?_,scalar_of_central_laplace Z hZ κ hκ hL⟩
  intro W hW
  simpa only [centralWindowError,configurationWindowError,centralKernel,← centralMass_eq,
    centralMass] using central_window_error_tendsto Z hZ κ hL W hW

-- The public mathematical target is unchanged and has no model assumption.
example : ∃ Z : FieldSample → TorusMeasure, CriticalChaosLimit Z ∧
    ∃ κ : ℝ, 0 < κ ∧ Tendsto (uniformCDFError Z κ) atTop (𝓝 0) :=
  scalar_cover_time_limit

#check centralKernel_measurable_past
#check central_kernel_weighted
#check centralRemaining_eq
#check central_configuration_budget
#check normalizedCoverTime_start_eq
#check r25_n5

end TorusCoverTime.CoverTime.ContractChecks
