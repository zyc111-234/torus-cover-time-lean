import Theorems.Thm_TorusCoverTime_scalar

/-! Public entry point for the current scalar cover-time target. -/
