import Solutions.Blocks.B.R7PerturbedCountObservable
import Solutions.Blocks.B.R7LowerBarrierExponent
import Solutions.Blocks.B.ShiftedAnnulusGeometry

/-! Uniform absorption of the true annulus-width error in the same-path
completed count. The original lower barrier is not changed. -/

noncomputable section
open MeasureTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

theorem sqrt_count_width_shift (h w ε L : ℝ) (m n : ℕ)
    (hh : 1 ≤ h) (hw : w ≤ h+ε) (hε : 0 ≤ ε) (hmn : n ≤ m)
    (hcount : Real.sqrt (h*(m:ℝ)) ≤ 2*L) (hsmall : ε*(4*L^2) ≤ 1) :
    Real.sqrt (w*(n:ℝ)) ≤ Real.sqrt (h*(m:ℝ))+1 := by
  have hm0 : 0 ≤ (m:ℝ) := Nat.cast_nonneg _
  have hn0 : 0 ≤ (n:ℝ) := Nat.cast_nonneg _
  have hmnR : (n:ℝ) ≤ (m:ℝ) := by exact_mod_cast hmn
  have hs := Real.sq_sqrt (mul_nonneg (by linarith : 0 ≤ h) hm0)
  have hL : 0 ≤ 2*L := (Real.sqrt_nonneg _).trans hcount
  have hmL : (m:ℝ) ≤ 4*L^2 := by
    have hsle := pow_le_pow_left₀ (Real.sqrt_nonneg _) hcount 2
    nlinarith [mul_nonneg (show 0 ≤ h-1 by linarith) hm0]
  have he := (mul_le_mul_of_nonneg_left hmL hε).trans hsmall
  have hp : w*(n:ℝ) ≤ h*(m:ℝ)+1 := by
    calc
      _ ≤ (h+ε)*(n:ℝ) := mul_le_mul_of_nonneg_right hw hn0
      _ ≤ (h+ε)*(m:ℝ) := mul_le_mul_of_nonneg_left hmnR (by linarith)
      _ ≤ _ := by nlinarith
  apply Real.sqrt_le_iff.mpr
  exact ⟨by positivity,by nlinarith [Real.sqrt_nonneg (h*(m:ℝ))]⟩

theorem r7_shift_width_small (γ : ℝ) (hγ : 0 < γ) :
    ∀ᶠ N : Size in atTop, ∀ q : ℝ, (logSize N)^(16*γ) ≤ q →
      1 ≤ q^γ ∧ Real.log 4 ≤ q^γ ∧
      (8*Real.exp (-q^γ))*(4*(logSize N)^2) ≤ 1 := by
  have ht := (polynomial_times_stretched_exp_tendsto_zero (16*γ*γ) 1 2
    (by positivity) zero_lt_one).const_mul 32
  simp only [mul_zero,Real.rpow_two,neg_one_mul] at ht
  have hW := (tendsto_rpow_atTop (by positivity : 0 < 16*γ*γ)).comp blockB_logSize_tendsto
  filter_upwards [hW.eventually_ge_atTop (max 1 (Real.log 4)),
    blockB_logSize_tendsto.eventually (ht.eventually_le_const zero_lt_one)] with N hbase hsmall
  intro q hq
  have hwidth : (logSize N)^(16*γ*γ) ≤ q^γ := by
    rw [Real.rpow_mul (logSize_pos N).le]
    exact Real.rpow_le_rpow (Real.rpow_nonneg (logSize_pos N).le _) hq hγ.le
  refine ⟨(le_max_left _ _).trans (hbase.trans hwidth),
    (le_max_right _ _).trans (hbase.trans hwidth),?_⟩
  have he := mul_le_mul_of_nonneg_right (Real.exp_le_exp.mpr (neg_le_neg hwidth))
    (show 0 ≤ 32*(logSize N)^2 by positivity)
  nlinarith only [he,hsmall]

theorem r7_shifted_traversal_radius_ae (γ : ℝ) (hγ : 0 < γ) :
    ∀ᶠ N : Size in atTop, ∀ x y root : Vertex N, ∀ q : ℝ,
      (logSize N)^(16*γ) ≤ q → q ≤ logSize N-(logSize N)^(16*γ) →
      periodicDistance x y ≤ 2*Real.exp q →
      2*((N.val:ℝ)*Real.exp (-((logSize N)^(16*γ))/2)) ≤ periodicDistance x root →
      ∀ᵐ ω ∂walkLaw, ∀ t : ℝ, 0 ≤ t → r7TraversalRadius N x root γ q (ω,t) ≤ 2*logSize N →
        r7PerturbedTraversalRadius N y root γ q (ω,t) ≤ r7TraversalRadius N x root γ q (ω,t)+1 := by
  filter_upwards [r7_shift_width_small γ hγ,r7_grid_shift_below_root_scale γ hγ,
    r7_perturbed_far_root_outside γ hγ] with N hwidth hshift hout
  intro x y root q hq hqL hxy hfar
  have hs := hwidth q hq
  have hq0 := (Real.rpow_nonneg (logSize_pos N).le _).trans hq
  have hyr := far_root_after_center_shift N x y root _ _ hfar hxy (hshift q hqL)
  have hroot := hout y root q hq0 hqL hyr
  have hi := (r7_perturbed_inner_log q (q^γ) hs.2.1).1
  have hρ : 2*Real.exp q < Real.exp (q+q^γ) := by
    simpa only [r7PerturbedInner,sub_pos] using hi
  have hρR := Real.exp_le_exp.mpr (show q+q^γ ≤ q+2*q^γ by linarith [hs.1])
  have hcount := shifted_annulus_count_le_ae N x y root _ _ _ hρ hρR hxy hroot
  filter_upwards [hcount] with ω hω
  intro t ht hY
  exact sqrt_count_width_shift (q^γ) (r7PerturbedWidth q (q^γ)) (8*Real.exp (-q^γ))
    (logSize N) _ _ hs.1 (r7_perturbed_parameter_bounds q (q^γ) hs.2.1).2.2.2.1
    (by positivity) (hω t ht) hY hs.2.2

end TorusCoverTime.Blocks.B
