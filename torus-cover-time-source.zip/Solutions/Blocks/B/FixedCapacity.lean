import Solutions.Blocks.B.GreenStructure
import Solutions.Blocks.B.EigenvalueBounds
import Mathlib.Analysis.SpecialFunctions.Pow.Asymptotics

/-! Fixed-cardinality capacity estimates from the registered Green and capacity interfaces. -/

noncomputable section
open Filter
open scoped BigOperators Topology

namespace TorusCoverTime.Blocks.B

lemma sum_univ_eq_sum_supported {ι : Type*} [Fintype ι] (A : Finset ι)
    (f : ι → ℝ) (hf : ∀ x, x ∉ A → f x = 0) : (∑ x, f x) = ∑ x ∈ A, f x := by
  classical
  exact (Finset.sum_subset (Finset.subset_univ A) (fun x _ hx => hf x hx)).symm

/-- A positive charge vector turns an entrywise Green estimate into a capacity estimate. -/
lemma charge_capacity_perturbation (hCapacity : CapacitySpectrum)
    (N : Size) (A : Finset (Vertex N)) (hA : A.Nonempty) (hproper : A ≠ Finset.univ)
    (v e : ℝ) (_he : 0 ≤ e)
    (hentries : ∀ a ∈ A, ∀ b ∈ A,
      |greenKernel N a b - if a = b then v else 0| ≤ e) :
    |(A.card : ℝ) - v * capacity N A| ≤ (A.card : ℝ) * e * capacity N A := by
  classical
  obtain ⟨hcpos, _, ⟨q, hq, _, hsum, hqlower, _, _, _, _, _, _⟩, _⟩ :=
    hCapacity N A hA hproper
  have hqnonneg (y : Vertex N) : 0 ≤ q y := by
    by_cases hy : y ∈ A
    · exact (div_nonneg hcpos.le (vertexCount_pos N).le).trans (hqlower y hy)
    · rw [hq.1 y hy]
  have hsumA : (∑ y ∈ A, q y) = capacity N A := by
    rw [← sum_univ_eq_sum_supported A q hq.1, hsum]
  have hcharge (a : Vertex N) (ha : a ∈ A) :
      (∑ b ∈ A, greenKernel N a b * q b) = 1 := by
    rw [← sum_univ_eq_sum_supported A (fun b => greenKernel N a b * q b)
      (fun b hb => by rw [hq.1 b hb, mul_zero])]
    exact hq.2 a ha
  have herr (a : Vertex N) (ha : a ∈ A) : |1 - v * q a| ≤ e * capacity N A := by
    have hid : (∑ b ∈ A, (greenKernel N a b - if a = b then v else 0) * q b) =
        1 - v * q a := by
      simp_rw [sub_mul]
      rw [Finset.sum_sub_distrib, hcharge a ha]
      simp [ha]
    rw [← hid]
    calc
      _ ≤ ∑ b ∈ A, |(greenKernel N a b - if a = b then v else 0) * q b| :=
        Finset.abs_sum_le_sum_abs _ _
      _ ≤ ∑ b ∈ A, e * q b := by
        apply Finset.sum_le_sum
        intro b hb
        rw [abs_mul, abs_of_nonneg (hqnonneg b)]
        exact mul_le_mul_of_nonneg_right (hentries a ha b hb) (hqnonneg b)
      _ = e * capacity N A := by rw [← Finset.mul_sum, hsumA]
  calc
    |(A.card : ℝ) - v * capacity N A| = |∑ a ∈ A, (1 - v * q a)| := by
      rw [Finset.sum_sub_distrib, ← Finset.mul_sum, hsumA]
      simp
    _ ≤ ∑ a ∈ A, |1 - v * q a| := Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ a ∈ A, e * capacity N A := Finset.sum_le_sum herr
    _ = (A.card : ℝ) * e * capacity N A := by simp; ring

lemma separated_green_entry_error (hGreen : GreenEstimates) :
    ∃ C : ℝ, 0 < C ∧ ∀ N : Size, 1 ≤ logSize N → ∀ A : Finset (Vertex N),
      separatedTarget N A → ∀ a ∈ A, ∀ b ∈ A,
        |greenKernel N a b - if a = b then g * logSize N else 0| ≤
          C * (logSize N) ^ (1 / 8 : ℝ) := by
  obtain ⟨C, hC, hbounds⟩ := hGreen
  refine ⟨C, hC, ?_⟩
  intro N hL A hsep a ha b hb
  have hpow : 1 ≤ (logSize N) ^ (1 / 8 : ℝ) := Real.one_le_rpow hL (by norm_num)
  by_cases hab : a = b
  · subst b
    rw [if_pos rfl, (hbounds N a a).1]
    exact (hbounds N a a).2.1.trans (by nlinarith)
  · rw [if_neg hab, sub_zero]
    apply (hbounds N a b).2.2.2.2.2
    have hD : 0 ≤ distantRadius N := by
      have := size_real_gt_one N
      unfold distantRadius
      positivity
    exact (by linarith : distantRadius N / 4 ≤ distantRadius N).trans (hsep a ha b hb hab)

lemma vertexCount_mul_spectralGap_ge_four (N : Size) :
    4 ≤ vertexCount N * spectralGap N := by
  have hN : 0 < (N.val : ℝ) := (size_real_gt_one N).trans' zero_lt_one
  have hN3 : (3 : ℝ) ≤ N.val := by exact_mod_cast N.property
  have hhalf : Real.pi / N.val ≤ Real.pi / 2 := by
    apply (div_le_iff₀ hN).mpr
    nlinarith [Real.pi_pos]
  have hs : 2 / (N.val : ℝ) ≤ Real.sin (Real.pi / N.val) := by
    have hs := Real.mul_le_sin (by positivity : 0 ≤ Real.pi / (N.val : ℝ)) hhalf
    convert! hs using 1
    field_simp
  have hs2 := pow_le_pow_left₀ (by positivity : 0 ≤ 2 / (N.val : ℝ)) hs 2
  have hid : (2 / (N.val : ℝ)) ^ 2 = 4 / vertexCount N := by
    unfold vertexCount
    ring
  rw [hid] at hs2
  have h := (div_le_iff₀ (vertexCount_pos N)).mp hs2
  simpa only [spectralGap, mul_comm] using h

lemma blockB_size_nat_tendsto : Tendsto (fun N : Size => N.val) atTop atTop := by
  apply tendsto_atTop.2
  intro b
  refine eventually_atTop.2 ⟨⟨max 3 b, le_max_left _ _⟩, ?_⟩
  intro N hN
  exact (le_max_right 3 b).trans hN

lemma blockB_logSize_tendsto : Tendsto logSize atTop atTop :=
  Real.tendsto_log_atTop.comp (tendsto_natCast_atTop_atTop.comp blockB_size_nat_tendsto)

lemma fixed_capacity_rate_tendsto :
    Tendsto (fun N : Size => (logSize N) ^ (-7 / 8 : ℝ)) atTop (𝓝 0) := by
  simpa only [Function.comp_def, neg_div] using
    (tendsto_rpow_neg_atTop (by norm_num : (0 : ℝ) < 7 / 8)).comp blockB_logSize_tendsto

lemma log_eighth_eq_mul_rate (L : ℝ) (hL : 0 < L) :
    L ^ (1 / 8 : ℝ) = L * L ^ (-7 / 8 : ℝ) := by
  simpa only [show (1 : ℝ) + -7 / 8 = 1 / 8 by norm_num, Real.rpow_one] using
    Real.rpow_add hL (1 : ℝ) (-7 / 8 : ℝ)

lemma inverse_log_le_capacity_rate (L : ℝ) (hL : 1 ≤ L) :
    1 / L ≤ L ^ (-7 / 8 : ℝ) := by
  have h := Real.rpow_le_rpow_of_exponent_le hL (show (-1 : ℝ) ≤ -7 / 8 by norm_num)
  simpa only [Real.rpow_neg_one, one_div] using h

lemma eventually_fixed_target_proper (k : ℕ) :
    ∀ᶠ N : Size in atTop, ∀ A : Finset (Vertex N), A.card = k → A ≠ Finset.univ := by
  filter_upwards [blockB_size_nat_tendsto.eventually (eventually_gt_atTop k)] with N hN A hcard
  intro hA
  rw [hA, Finset.card_univ, Fintype.card_prod, ZMod.card] at hcard
  have hN1 : 1 ≤ N.val := by have := N.property; omega
  have hmul : N.val ≤ N.val * N.val := by simpa using Nat.mul_le_mul_left N.val hN1
  omega

/-- Scalar perturbation step, with the smallness condition made explicit. -/
lemma scalar_capacity_perturbation (k c C L : ℝ) (hk : 0 < k) (hc : 0 < c)
    (hC : 0 < C) (hL : 0 < L)
    (herr : |k - g * L * c| ≤ k * (C * L ^ (1 / 8 : ℝ)) * c)
    (hsmall : k * C * L ^ (-7 / 8 : ℝ) ≤ g / 2) :
    c ≤ (2 * k / g) / L ∧
    |c * (g * L) / k - 1| ≤ (C * (2 * k / g)) * L ^ (-7 / 8 : ℝ) := by
  have hg : 0 < g := by unfold g; positivity
  have hd : 0 ≤ L ^ (-7 / 8 : ℝ) := Real.rpow_nonneg hL.le _
  rw [log_eighth_eq_mul_rate L hL] at herr
  have hlo := (abs_le.mp herr).1
  have hhi := (abs_le.mp herr).2
  have hsmallmul := mul_le_mul_of_nonneg_right hsmall (mul_nonneg hL.le hc.le)
  have hbound : g * L * c ≤ 2 * k := by nlinarith
  have hcbound : c ≤ (2 * k / g) / L := by
    apply (le_div_iff₀ hL).mpr
    apply (le_div_iff₀ hg).mpr
    nlinarith
  refine ⟨hcbound, ?_⟩
  have hid : c * (g * L) / k - 1 = -(k - g * L * c) / k := by field_simp; ring
  rw [hid, abs_div, abs_neg, abs_of_pos hk]
  apply (div_le_iff₀ hk).mpr
  have hmul := mul_le_mul_of_nonneg_left hcbound
    (show 0 ≤ k * (C * (L * L ^ (-7 / 8 : ℝ))) by positivity)
  have heq : k * (C * (L * L ^ (-7 / 8 : ℝ))) * ((2 * k / g) / L) =
      (C * (2 * k / g)) * L ^ (-7 / 8 : ℝ) * k := by field_simp
  exact herr.trans (heq ▸ hmul)

lemma fixed_capacity_spectral_transfer (hCapacity : CapacitySpectrum)
    (N : Size) (A : Finset (Vertex N)) (hA : A.Nonempty) (hproper : A ≠ Finset.univ)
    (k b E : ℝ) (hk : 0 < k) (hb : 0 ≤ b) (_hE : 0 ≤ E) (hL : 1 ≤ logSize N)
    (hcap : capacity N A ≤ b / logSize N)
    (hscaled : g * logSize N * capacity N A ≤ 2 * k)
    (herror : |capacity N A * (g * logSize N) / k - 1| ≤
      E * (logSize N) ^ (-7 / 8 : ℝ))
    (hsmall : b / logSize N ≤ 1 / 2) :
    |capacityRatio N A| ≤ b / logSize N ∧
    |timeScale N * killedEigenvalue N A - k| ≤
      (k * E + 2 * k * b) * (logSize N) ^ (-7 / 8 : ℝ) ∧
    |principalVariance N A| ≤ (2 * b) / logSize N := by
  have hcs := hCapacity N A hA hproper
  have hn := (vertexCount_pos N).ne'
  have hden := vertexCount_mul_spectralGap_ge_four N
  have hδnonneg : 0 ≤ capacityRatio N A :=
    div_nonneg hcs.1.le (mul_nonneg (vertexCount_pos N).le (spectralGap_pos N).le)
  have hδcap : capacityRatio N A ≤ capacity N A :=
    div_le_self hcs.1.le (by linarith : 1 ≤ vertexCount N * spectralGap N)
  have hδbound := hδcap.trans hcap
  have hδhalf := hδbound.trans hsmall
  have hδlt : capacityRatio N A < 1 := by linarith
  obtain ⟨_, _, hLambdaLo, hLambdaHi, hVnonneg, hVbound, _⟩ := hcs.2.2.2 hδlt
  have hV2 : principalVariance N A ≤ 2 * capacityRatio N A := by
    apply hVbound.trans
    apply (div_le_iff₀ (by linarith : 0 < 1 - capacityRatio N A)).mpr
    nlinarith [mul_nonneg hδnonneg (show 0 ≤ 1 - 2 * capacityRatio N A by linarith)]
  refine ⟨by simpa only [abs_of_nonneg hδnonneg] using hδbound, ?_, ?_⟩
  · have htime : timeScale N = (g * logSize N) * vertexCount N := by
      unfold timeScale vertexCount
      ring
    have hupper : timeScale N * killedEigenvalue N A ≤
        g * logSize N * capacity N A := by
      calc
        _ ≤ timeScale N * (capacity N A / vertexCount N) :=
          mul_le_mul_of_nonneg_left hLambdaHi (timeScale_pos N).le
        _ = _ := by rw [htime]; field_simp [hn]
    have hlower : (1 - capacityRatio N A) * (g * logSize N * capacity N A) ≤
        timeScale N * killedEigenvalue N A := by
      calc
        _ = timeScale N * ((1 - capacityRatio N A) * capacity N A / vertexCount N) := by
          rw [htime]
          field_simp [hn]
        _ ≤ _ := mul_le_mul_of_nonneg_left hLambdaLo (timeScale_pos N).le
    have hid : (capacity N A * (g * logSize N) / k - 1) * k =
        g * logSize N * capacity N A - k := by field_simp
    have hscaledError : |g * logSize N * capacity N A - k| ≤
        k * E * (logSize N) ^ (-7 / 8 : ℝ) := by
      rw [← hid, abs_mul, abs_of_pos hk]
      calc
        _ ≤ (E * (logSize N) ^ (-7 / 8 : ℝ)) * k :=
          mul_le_mul_of_nonneg_right herror hk.le
        _ = _ := by ring
    have hδrate : capacityRatio N A ≤ b * (logSize N) ^ (-7 / 8 : ℝ) := by
      calc
        _ ≤ b / logSize N := hδbound
        _ ≤ _ := by
          rw [div_eq_mul_one_div]
          exact mul_le_mul_of_nonneg_left (inverse_log_le_capacity_rate _ hL) hb
    have hδerror : capacityRatio N A * (g * logSize N * capacity N A) ≤
        (2 * k * b) * (logSize N) ^ (-7 / 8 : ℝ) := by
      calc
        _ ≤ capacityRatio N A * (2 * k) := mul_le_mul_of_nonneg_left hscaled hδnonneg
        _ ≤ (b * (logSize N) ^ (-7 / 8 : ℝ)) * (2 * k) :=
          mul_le_mul_of_nonneg_right hδrate (by positivity)
        _ = _ := by ring
    have he0 := Real.rpow_nonneg (logSize_pos N).le (-7 / 8 : ℝ)
    rw [abs_le] at hscaledError ⊢
    constructor <;> nlinarith
  · rw [abs_of_nonneg hVnonneg]
    calc
      _ ≤ 2 * capacityRatio N A := hV2
      _ ≤ 2 * (b / logSize N) := mul_le_mul_of_nonneg_left hδbound (by norm_num)
      _ = _ := by ring

theorem fixed_target_capacity (hGreen : GreenEstimates) (hCapacity : CapacitySpectrum) :
    FixedTargetCapacityEstimate := by
  intro k hk
  obtain ⟨C, hC, hentries⟩ := separated_green_entry_error hGreen
  have hkR : (0 : ℝ) < k := by exact_mod_cast hk
  have hg : 0 < g := by unfold g; positivity
  let b : ℝ := 2 * k / g
  let E : ℝ := C * b
  let F : ℝ := k * E + 2 * k * b
  let D : ℝ := E + b + F + 2 * b + 1
  have hb : 0 < b := by dsimp [b]; positivity
  have hE : 0 < E := mul_pos hC hb
  have hF : 0 < F := by dsimp [F]; positivity
  have hD : 0 < D := by dsimp [D]; positivity
  have hDE : E ≤ D := by dsimp [D]; linarith
  have hDb : b ≤ D := by dsimp [D]; linarith
  have hDF : F ≤ D := by dsimp [D]; linarith
  have hD2b : 2 * b ≤ D := by dsimp [D]; linarith
  refine ⟨D, hD, ?_⟩
  have hrate : Tendsto (fun N : Size => (k : ℝ) * C * (logSize N) ^ (-7 / 8 : ℝ))
      atTop (𝓝 0) := by simpa using fixed_capacity_rate_tendsto.const_mul ((k : ℝ) * C)
  have hinverse : Tendsto (fun N : Size => b / logSize N) atTop (𝓝 0) := by
    simpa only [div_eq_mul_inv, Pi.inv_apply, mul_zero] using
      blockB_logSize_tendsto.inv_tendsto_atTop.const_mul b
  have hsmallrate : ∀ᶠ N : Size in atTop,
      (k : ℝ) * C * (logSize N) ^ (-7 / 8 : ℝ) ≤ g / 2 :=
    (hrate.eventually (gt_mem_nhds (by positivity : (0 : ℝ) < g / 2))).mono
      (fun _ h => le_of_lt h)
  have hsmallinverse : ∀ᶠ N : Size in atTop, b / logSize N ≤ 1 / 2 :=
    (hinverse.eventually (gt_mem_nhds (by norm_num : (0 : ℝ) < 1 / 2))).mono
      (fun _ h => le_of_lt h)
  filter_upwards [blockB_logSize_tendsto.eventually (eventually_ge_atTop 1),
    eventually_fixed_target_proper k, hsmallrate, hsmallinverse] with N hL hproper hsr hsi
  intro A hcard hsep
  have hA : A.Nonempty := Finset.card_pos.mp (by omega)
  have hcs := hCapacity N A hA (hproper A hcard)
  have herr := charge_capacity_perturbation hCapacity N A hA (hproper A hcard)
    (g * logSize N) (C * (logSize N) ^ (1 / 8 : ℝ)) (by positivity)
    (hentries N hL A hsep)
  rw [hcard] at herr
  have hscalar := scalar_capacity_perturbation (k : ℝ) (capacity N A) C (logSize N)
    hkR hcs.1 hC (logSize_pos N) herr hsr
  have hcap : capacity N A ≤ b / logSize N := hscalar.1
  have herror : |capacity N A * (g * logSize N) / k - 1| ≤
      E * (logSize N) ^ (-7 / 8 : ℝ) := hscalar.2
  have hscaled : g * logSize N * capacity N A ≤ 2 * k := by
    have h := mul_le_mul_of_nonneg_left ((le_div_iff₀ (logSize_pos N)).mp hcap) hg.le
    have hgb : g * b = 2 * k := by dsimp [b]; field_simp
    rw [hgb] at h
    nlinarith
  have hspec := fixed_capacity_spectral_transfer hCapacity N A hA (hproper A hcard)
    k b E hkR hb.le hE.le hL hcap hscaled herror hsi
  have hd := Real.rpow_nonneg (logSize_pos N).le (-7 / 8 : ℝ)
  refine ⟨herror.trans (mul_le_mul_of_nonneg_right hDE hd),
    hspec.1.trans (div_le_div_of_nonneg_right hDb (logSize_pos N).le),
    hspec.2.1.trans (mul_le_mul_of_nonneg_right hDF hd),
    hspec.2.2.trans (div_le_div_of_nonneg_right hD2b (logSize_pos N).le)⟩

end TorusCoverTime.Blocks.B
