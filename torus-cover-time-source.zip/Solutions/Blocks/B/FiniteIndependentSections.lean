import Solutions.Blocks.C.C4.Base.IndependentEndpointSmoothing

/-! A uniform bound on the genuine future sections of an independent product
law. The section may depend on the full past observation. -/

noncomputable section
open MeasureTheory ProbabilityTheory Set
open scoped ENNReal NNReal
namespace TorusCoverTime.Blocks.B

theorem independent_sections_le {Ω A B : Type*}
    [MeasurableSpace Ω] [MeasurableSpace A] [MeasurableSpace B]
    (μ : Measure Ω) [IsProbabilityMeasure μ] (L : Ω → A) (R : Ω → B)
    (hL : Measurable L) (hR : Measurable R) (hind : IndepFun L R μ)
    (S : Set A) (hS : MeasurableSet S) (E : Set (A × B)) (hE : MeasurableSet E)
    (C : ℝ≥0∞) (hsection : ∀ a ∈ S, μ {ω | (a, R ω) ∈ E} ≤ C) :
    μ {ω | L ω ∈ S ∧ (L ω, R ω) ∈ E} ≤ C * μ (L ⁻¹' S) := by
  let F : Set (A × B) := {z | z.1 ∈ S ∧ z ∈ E}
  have hF : MeasurableSet F := (hS.preimage measurable_fst).inter hE
  change μ ((fun ω => (L ω, R ω)) ⁻¹' F) ≤ _
  rw [← Measure.map_apply (hL.prodMk hR) hF,
    hind.map_prod_eq_prod_map_map hL.aemeasurable hR.aemeasurable, Measure.prod_apply hF]
  calc
    _ ≤ ∫⁻ a, S.indicator (fun _ => C) a ∂μ.map L := by
      apply lintegral_mono
      intro a
      change (μ.map R) (Prod.mk a ⁻¹' F) ≤ S.indicator (fun _ => C) a
      by_cases ha : a ∈ S
      · rw [indicator_of_mem ha]
        have he : Prod.mk a ⁻¹' F = Prod.mk a ⁻¹' E := by
          ext b
          simp [F, ha]
        rw [he, Measure.map_apply hR (hE.preimage (show Measurable (Prod.mk a) by fun_prop))]
        exact hsection a ha
      · rw [indicator_of_notMem ha]
        have he : Prod.mk a ⁻¹' F = ∅ := by ext b; simp [F, ha]
        rw [he, measure_empty]
    _ = _ := by rw [lintegral_indicator hS, setLIntegral_const, Measure.map_apply hL hS]

end TorusCoverTime.Blocks.B
