import Solutions.Blocks.B.R8NestedPath
import Solutions.Blocks.B.R8NestedRecord

/-! Sharp-mean error absorption for the nested Chernoff exponent. The
result has a Gaussian square-root gap with an explicit constant 1/24. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

theorem sqrt_gap_rescale (A β v : ℝ) (hA : 0 ≤ A) (hβ : 0 < β) (hv : 0 ≤ v) :
    (max (Real.sqrt A-Real.sqrt ((1/β)*v^2)) 0)^2 =
      (max (Real.sqrt (A*β)-v) 0)^2/β := by
  have hs : 0 < Real.sqrt β := Real.sqrt_pos.mpr hβ
  have he : (1/β)*v^2 = v^2/β := by ring
  rw [he,Real.sqrt_div (sq_nonneg v),Real.sqrt_sq hv,Real.sqrt_mul hA]
  have hd : Real.sqrt A-v/Real.sqrt β = (Real.sqrt A*Real.sqrt β-v)/Real.sqrt β := by
    field_simp
  rw [hd]
  have hm : max ((Real.sqrt A*Real.sqrt β-v)/Real.sqrt β) 0 =
      max (Real.sqrt A*Real.sqrt β-v) 0/Real.sqrt β := by
    by_cases h : 0 ≤ Real.sqrt A*Real.sqrt β-v
    · rw [max_eq_left h, max_eq_left (div_nonneg h hs.le)]
    · rw [max_eq_right (le_of_not_ge h), max_eq_right (div_nonpos_of_nonpos_of_nonneg (le_of_not_ge h) hs.le),zero_div]
  rw [hm,div_pow,Real.sq_sqrt hβ.le]

theorem sqrt_mean_relative_loss (m h μ δ : ℝ) (hm : 0 ≤ m) (hh : 0 < h)
    (hδ : 0 ≤ δ) (hδh : δ ≤ h) (hμ : h-δ ≤ μ) :
    Real.sqrt (m*h)*(1-δ/h) ≤ Real.sqrt (m*μ) := by
  have hz : 0 ≤ 1-δ/h := by have := (div_le_one hh).mpr hδh; linarith
  have hz1 : 1-δ/h ≤ 1 := sub_le_self _ (div_nonneg hδ hh.le)
  have hfactor : h*(1-δ/h) = h-δ := by field_simp
  have hsq : (Real.sqrt (m*h)*(1-δ/h))^2 ≤ m*μ := by
    rw [mul_pow,Real.sq_sqrt (mul_nonneg hm hh.le)]
    calc
      _ ≤ (m*h)*(1-δ/h) := mul_le_mul_of_nonneg_left (by nlinarith : (1-δ/h)^2 ≤ 1-δ/h)
        (mul_nonneg hm hh.le)
      _ = m*(h-δ) := by rw [mul_assoc,hfactor]
      _ ≤ _ := mul_le_mul_of_nonneg_left hμ hm
  calc
    _ = Real.sqrt ((Real.sqrt (m*h)*(1-δ/h))^2) :=
      (Real.sqrt_sq (mul_nonneg (Real.sqrt_nonneg _) hz)).symm
    _ ≤ _ := Real.sqrt_le_sqrt hsq

theorem bernoulli_exponent_gaussian_bound (m h p β v δ : ℝ)
    (hm : 0 ≤ m) (hh : 0 < h) (hp : 0 ≤ p) (hβ : 0 < β) (hβhi : β ≤ 6*h)
    (hv : 0 ≤ v) (hδ : 0 ≤ δ) (hδh : δ ≤ h) (hμ : h-δ ≤ p*β)
    (hgap : v ≤ Real.sqrt (m*h))
    (hloss : Real.sqrt (m*h)*δ/h ≤ (Real.sqrt (m*h)-v)/2) :
    Real.exp (-((max (Real.sqrt (m*p)-Real.sqrt ((1/β)*v^2)) 0)^2)) ≤
      Real.exp (-((Real.sqrt (m*h)-v)^2/(24*h))) := by
  have hx := sqrt_mean_relative_loss m h (p*β) δ hm hh hδ hδh hμ
  have hpos : 0 ≤ Real.sqrt (m*h)-v := sub_nonneg.mpr hgap
  have he : Real.sqrt (m*h)*(1-δ/h) = Real.sqrt (m*h)-Real.sqrt (m*h)*δ/h := by ring
  rw [he] at hx
  have hxgap : (Real.sqrt (m*h)-v)/2 ≤ Real.sqrt ((m*p)*β)-v := by
    rw [mul_assoc]
    linarith
  have hmax := hxgap.trans (le_max_left (Real.sqrt ((m*p)*β)-v) 0)
  have hsq : (Real.sqrt (m*h)-v)^2/4 ≤ (max (Real.sqrt ((m*p)*β)-v) 0)^2 := by
    nlinarith [le_max_right (Real.sqrt ((m*p)*β)-v) 0]
  have hexponent : (Real.sqrt (m*h)-v)^2/(24*h) ≤
      (max (Real.sqrt ((m*p)*β)-v) 0)^2/β := by
    calc
      _ = ((Real.sqrt (m*h)-v)^2/4)/(6*h) := by ring
      _ ≤ ((Real.sqrt (m*h)-v)^2/4)/β :=
        div_le_div_of_nonneg_left (by positivity) hβ hβhi
      _ ≤ _ := div_le_div_of_nonneg_right hsq hβ.le
  rw [sqrt_gap_rescale (m*p) β v (mul_nonneg hm hp) hβ hv]
  exact Real.exp_le_exp.mpr (neg_le_neg hexponent)

theorem r8_nested_gaussian_bound (γ : ℝ) (hγ : 0 < γ) (hγ1 : γ < 1) :
    ∀ᶠ q : ℝ in atTop, ∀ m : ℕ, ∀ v : ℝ, 0 ≤ v → v ≤ Real.sqrt ((m:ℝ)*q^γ) →
      Real.sqrt ((m:ℝ)*q^γ)*(3*r8NestedKernelError γ q)/q^γ ≤
        (Real.sqrt ((m:ℝ)*q^γ)-v)/2 →
      r8NestedLowerTailBound γ q m (v^2) ≤
        Real.exp (-((Real.sqrt ((m:ℝ)*q^γ)-v)^2/(24*q^γ))) := by
  filter_upwards [r8_nested_effective_parameters γ hγ hγ1, r8_nested_geometric_tail γ hγ hγ1,
    r8_nested_scale_geometry γ hγ hγ1,
    (r8NestedKernelError_tendsto_zero γ hγ).eventually_le_const (by norm_num : (0:ℝ) < 1/3),
    eventually_ge_atTop (0:ℝ)] with q hpar hprob hgeom herr hq
  intro m v hv hgap hloss
  have hh : 0 < q^γ := by have := hgeom.1; linarith
  have he := r8NestedKernelError_nonneg γ q hq
  have hδh : 3*r8NestedKernelError γ q ≤ q^γ := by have := hgeom.1; linarith
  have hmu : q^γ-3*r8NestedKernelError γ q ≤
      r8NestedEntrance γ q*((r8NestedScale γ q)^γ/r8NestedEscape γ q) := by
    simpa only [mul_div_assoc] using hpar.1
  have hb := bernoulli_exponent_gaussian_bound (m:ℝ) (q^γ) (r8NestedEntrance γ q)
    ((r8NestedScale γ q)^γ/r8NestedEscape γ q) v (3*r8NestedKernelError γ q)
    (Nat.cast_nonneg _) hh hprob.1.le hpar.2.2.1 hpar.2.2.2 hv (by positivity) hδh hmu hgap hloss
  simpa only [one_div_div,r8NestedLowerTailBound] using hb

end TorusCoverTime.Blocks.B
