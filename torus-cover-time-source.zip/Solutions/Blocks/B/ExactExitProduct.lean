import Solutions.Blocks.B.FiniteExitWords

/-! R1 product avoidance and the exact cost of conditioning a duration union bound on softness.
The later duration-tail input is explicit; it is not installed here as an axiom. -/

noncomputable section
open MeasureTheory ProbabilityTheory Classical
open scoped ENNReal BigOperators
namespace TorusCoverTime.Blocks.B

def FeasibleAvoidingExit (N : Size) (D K : Finset (Vertex N)) (a b : Vertex N) : Prop :=
  ∃ n ≤ D.card + 1, ∃ d : Fin n → Fin 4,
    exitsThroughAt N D a b (sampleOfDirections d) n ∧ discreteAvoids N a K (sampleOfDirections d) n

lemma exactExitLaw_probability_of_path (N : Size) (D K : Finset (Vertex N)) (a b : Vertex N)
    (hpath : FeasibleAvoidingExit N D K a b) : IsProbabilityMeasure (exactExitLaw N D a b) := by
  obtain ⟨n, _, d, he, ha⟩ := hpath
  exact exactExitLaw_probability_of_feasible N D K a b n d he ha

lemma finite_domain_exit_probability_lower (N : Size) (D K : Finset (Vertex N)) (a b : Vertex N)
    (hpath : FeasibleAvoidingExit N D K a b) :
    1 / (4 : ℝ≥0∞) ^ (D.card + 1) ≤ walkLaw (exitsThrough N D a b) := by
  obtain ⟨n, hn, d, he, ha⟩ := hpath
  calc
    _ ≤ 1 / (4 : ℝ≥0∞) ^ n := ENNReal.div_le_div_left (pow_le_pow_right₀ (by norm_num) hn) 1
    _ ≤ walkLaw (exitsThroughAvoiding N D K a b) := feasible_exit_word_probability N D K a b n d he ha
    _ ≤ _ := measure_mono (exitsThroughAvoiding_subset N D K a b)

lemma exactExitLaw_event_upper (N : Size) (D K : Finset (Vertex N)) (a b : Vertex N)
    (hpath : FeasibleAvoidingExit N D K a b) (S : Set WalkSample) :
    exactExitLaw N D a b S ≤ (4 : ℝ≥0∞) ^ (D.card + 1) * walkLaw S := by
  rw [exactExitLaw, cond_apply (measurableSet_exitsThrough N D a b)]
  have hi : (walkLaw (exitsThrough N D a b))⁻¹ ≤ (4 : ℝ≥0∞) ^ (D.card + 1) := by
    have h := ENNReal.inv_le_inv.mpr (finite_domain_exit_probability_lower N D K a b hpath)
    simpa only [one_div, inv_inv] using h
  exact mul_le_mul' hi (measure_mono Set.inter_subset_right)

def exactExitProductLaw (N : Size) (D : Finset (Vertex N)) (m : ℕ)
    (a b : Fin m → Vertex N) : Measure (Fin m → WalkSample) :=
  Measure.pi fun i => exactExitLaw N D (a i) (b i)

def allExitBlocksAvoid (N : Size) (D K : Finset (Vertex N)) (m : ℕ)
    (a b : Fin m → Vertex N) : Set (Fin m → WalkSample) :=
  Set.pi Set.univ fun i => exitsThroughAvoiding N D K (a i) (b i)

lemma exactExitProduct_probability (N : Size) (D K : Finset (Vertex N)) (m : ℕ)
    (a b : Fin m → Vertex N) (hpath : ∀ i, FeasibleAvoidingExit N D K (a i) (b i)) :
    IsProbabilityMeasure (exactExitProductLaw N D m a b) := by
  have hp (i : Fin m) : IsProbabilityMeasure (exactExitLaw N D (a i) (b i)) :=
    exactExitLaw_probability_of_path N D K _ _ (hpath i)
  unfold exactExitProductLaw
  infer_instance

lemma allExitBlocksAvoid_probability_lower (N : Size) (D K : Finset (Vertex N)) (m : ℕ)
    (a b : Fin m → Vertex N) (hpath : ∀ i, FeasibleAvoidingExit N D K (a i) (b i)) :
    1 / (4 : ℝ≥0∞) ^ (m * (D.card + 1)) ≤ exactExitProductLaw N D m a b (allExitBlocksAvoid N D K m a b) := by
  have hp (i : Fin m) : IsProbabilityMeasure (exactExitLaw N D (a i) (b i)) :=
    exactExitLaw_probability_of_path N D K _ _ (hpath i)
  rw [exactExitProductLaw, allExitBlocksAvoid, Measure.pi_pi]
  have hprod := Finset.prod_le_prod' (s := (Finset.univ : Finset (Fin m)))
    (fun i _ => finite_domain_exit_avoidance_lower N D K (a i) (b i) (hpath i))
  simpa only [Finset.prod_const, Finset.card_univ, Fintype.card_fin, one_div,
    ← ENNReal.inv_pow, ← pow_mul, mul_comm m] using hprod

lemma exactExitProduct_conditioned_union_bound_ae (N : Size) (D K : Finset (Vertex N)) (m : ℕ)
    (a b : Fin m → Vertex N) (hpath : ∀ i, FeasibleAvoidingExit N D K (a i) (b i))
    (S : Set (Fin m → WalkSample)) (hS : MeasurableSet S)
    (hAvoidS : ∀ᵐ ω ∂exactExitProductLaw N D m a b,
      ω ∈ allExitBlocksAvoid N D K m a b → ω ∈ S)
    (bad : Fin m → Set WalkSample) (hbad : ∀ i, MeasurableSet (bad i))
    (ε : ℝ≥0∞) (hε : ∀ i, walkLaw (bad i) ≤ ε) :
    (exactExitProductLaw N D m a b)[{ω | ∃ i : Fin m, ω i ∈ bad i} | S] ≤
      (m : ℝ≥0∞) * ε * (4 : ℝ≥0∞) ^ ((m + 1) * (D.card + 1)) := by
  have hp (i : Fin m) : IsProbabilityMeasure (exactExitLaw N D (a i) (b i)) :=
    exactExitLaw_probability_of_path N D K _ _ (hpath i)
  let μ := exactExitProductLaw N D m a b
  have hlow : 1 / (4 : ℝ≥0∞) ^ (m * (D.card + 1)) ≤ μ S :=
    (allExitBlocksAvoid_probability_lower N D K m a b hpath).trans (measure_mono_ae hAvoidS)
  have hinv : (μ S)⁻¹ ≤ (4 : ℝ≥0∞) ^ (m * (D.card + 1)) := by
    have h := ENNReal.inv_le_inv.mpr hlow
    simpa only [one_div, inv_inv] using h
  have hmarg (i : Fin m) : μ {ω | ω i ∈ bad i} = exactExitLaw N D (a i) (b i) (bad i) := by
    change (Measure.pi fun j => exactExitLaw N D (a j) (b j)) ((Function.eval i) ⁻¹' bad i) = _
    rw [← Measure.map_apply (measurable_pi_apply i) (hbad i), Measure.pi_map_eval]
    simp only [measure_univ, Finset.prod_const_one, one_smul]
  have hunion : μ {ω | ∃ i : Fin m, ω i ∈ bad i} ≤
      (m : ℝ≥0∞) * ((4 : ℝ≥0∞) ^ (D.card + 1) * ε) := by
    rw [Set.ofPred_exists]
    calc
      _ ≤ ∑' i : Fin m, μ {ω | ω i ∈ bad i} := measure_iUnion_le _
      _ = ∑ i : Fin m, μ {ω | ω i ∈ bad i} := tsum_fintype _
      _ ≤ ∑ _i : Fin m, (4 : ℝ≥0∞) ^ (D.card + 1) * ε := by
        apply Finset.sum_le_sum
        intro i _
        rw [hmarg]
        exact (exactExitLaw_event_upper N D K _ _ (hpath i) _).trans (mul_le_mul' le_rfl (hε i))
      _ = _ := by simp
  change μ[{ω | ∃ i : Fin m, ω i ∈ bad i} | S] ≤ _
  rw [cond_apply hS]
  calc
    _ ≤ (4 : ℝ≥0∞) ^ (m * (D.card + 1)) *
        ((m : ℝ≥0∞) * ((4 : ℝ≥0∞) ^ (D.card + 1) * ε)) :=
      mul_le_mul' hinv ((measure_mono Set.inter_subset_right).trans hunion)
    _ = _ := by
      rw [add_mul, one_mul, pow_add]
      ring

lemma exactExitProduct_conditioned_union_bound (N : Size) (D K : Finset (Vertex N)) (m : ℕ)
    (a b : Fin m → Vertex N) (hpath : ∀ i, FeasibleAvoidingExit N D K (a i) (b i))
    (S : Set (Fin m → WalkSample)) (hS : MeasurableSet S)
    (hAvoidS : allExitBlocksAvoid N D K m a b ⊆ S)
    (bad : Fin m → Set WalkSample) (hbad : ∀ i, MeasurableSet (bad i))
    (ε : ℝ≥0∞) (hε : ∀ i, walkLaw (bad i) ≤ ε) :
    (exactExitProductLaw N D m a b)[{ω | ∃ i : Fin m, ω i ∈ bad i} | S] ≤
      (m : ℝ≥0∞) * ε * (4 : ℝ≥0∞) ^ ((m + 1) * (D.card + 1)) :=
  exactExitProduct_conditioned_union_bound_ae N D K m a b hpath S hS
    (Filter.Eventually.of_forall hAvoidS) bad hbad ε hε

end TorusCoverTime.Blocks.B
