import Solutions.Blocks.B.HarmonicImageEnvelope
import Solutions.Blocks.B.ShellCountLimit

/-! R5.3 applied to the actual harmonic square image. The two signs use a
common Gaussian envelope; the remainder retains its n-level L log L scale. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal NNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

def harmonicShellTest (N : Size) (c : Vertex N) (q v : ℝ)
    (z : FiniteFieldSample N × (ℝ × Bool)) : ℝ≥0∞ :=
  if harmonicImageRadius N c q (harmonicShiftedSquareImage N z.1 z.2.1 z.2.2) ≤ v then 1 else 0

theorem harmonicShellTest_measurable (N : Size) (c : Vertex N) (q v : ℝ) :
    Measurable (harmonicShellTest N c q v) := by
  have hm : Measurable (fun z : FiniteFieldSample N × (ℝ × Bool) =>
      harmonicShiftedSquareImage N z.1 z.2.1 z.2.2) := by
    have hsign : Measurable (fun z : FiniteFieldSample N × (ℝ × Bool) =>
        if z.2.2 then z.2.1 else -z.2.1) :=
      ((measurable_fst.comp measurable_snd).ite
        (measurableSet_eq_fun (measurable_snd.comp measurable_snd) measurable_const)
        (measurable_fst.comp measurable_snd).neg)
    apply measurable_const.prodMk
    apply measurable_pi_lambda
    intro x
    exact ((by unfold finiteGaussianField; fun_prop :
      Measurable (fun z : FiniteFieldSample N × (ℝ × Bool) => finiteGaussianField N z.1 x)).add hsign).pow_const 2
  exact measurable_const.ite (measurableSet_le
    ((harmonicImageRadius_measurable N c q).comp hm) measurable_const) measurable_const

theorem harmonicShellTest_le_one (N : Size) (c : Vertex N) (q v : ℝ)
    (z : FiniteFieldSample N × (ℝ × Bool)) : harmonicShellTest N c q v z ≤ 1 := by
  unfold harmonicShellTest
  split_ifs <;> simp

def harmonicShellMass (N : Size) (θ : ℝ) (c : Vertex N) (q v : ℝ) : ℝ≥0∞ :=
  ∫⁻ z, shellCountObservable N θ (harmonicShellTest N c q v) z ∂
    D.normalizedAveragedShell N (D.shellEnergyParameter N θ)

theorem harmonic_shell_tail (H ε : ℝ) (hH : 0 ≤ H) (hε : 0 < ε) :
    ∃ c₀ C : ℝ, 0 < c₀ ∧ 0 < C ∧ ∀ᶠ N : Size in atTop,
      ∀ θ : ℝ, |θ| ≤ H → ∀ c : Vertex N, ∀ q v : ℝ,
        0 ≤ q → q ≤ logSize N → 2*(Real.exp (q+1)+1) < N.val →
        harmonicShellMass N θ c q v ≤
          ENNReal.ofReal (4*C*Real.exp (-(max
            (Real.sqrt (D.shellEnergyParameter N θ-greenDiagonal N)/Real.sqrt (2*g)-v-
              ε*Real.log (logSize N)/Real.sqrt (2*g)) 0)^2 /
                (logSize N-q+2*harmonicVarianceErrorConstant))) +
          ENNReal.ofReal (C*vertexCount N*logSize N^2*
            Real.exp (-c₀*ε*logSize N*Real.log (logSize N))) := by
  obtain ⟨c₀,C,hc,hC,htransfer⟩ := D.energy_shell_count_transfer H hH ε hε
  refine ⟨c₀,C,hc,hC,?_⟩
  filter_upwards [htransfer,blockB_logSize_tendsto.eventually_ge_atTop 1] with N hN hL
  intro θ hθ c q v hq hqL hsmall
  let a₀ := Real.sqrt (D.shellEnergyParameter N θ-greenDiagonal N)
  let δ := ε*Real.log (logSize N)
  let M := fun z : FiniteFieldSample N × Bool => harmonicGaussianEnvelope N c q a₀ δ v z.1
  have hδ : 0 ≤ δ := mul_nonneg hε.le (Real.log_nonneg hL)
  have hm : Measurable M := (harmonicGaussianEnvelope_measurable N c q a₀ δ v).comp measurable_fst
  have hcount (z) : harmonicShellTest N c q v z ≤ ENNReal.ofReal (vertexCount N) := by
    apply (harmonicShellTest_le_one N c q v z).trans
    rw [← ENNReal.ofReal_one]
    apply ENNReal.ofReal_le_ofReal
    rw [D.vertexCount_eq_card]
    exact_mod_cast Fintype.card_pos_iff.mpr (inferInstance : Nonempty (Vertex N))
  have hmajor (ξ : FiniteFieldSample N) (a : ℝ) (σ : Bool) (ha : |a-a₀| ≤ δ) :
      harmonicShellTest N c q v (ξ,a,σ) ≤ M (ξ,σ) :=
    harmonic_image_tail_envelope N c q a₀ δ v hsmall hδ ξ a σ ha
  have hh := (hN θ hθ).2.2 (harmonicShellTest N c q v)
    (harmonicShellTest_measurable N c q v) hcount M hm hmajor
  let E := Real.exp (-(max (a₀/Real.sqrt (2*g)-v-δ/Real.sqrt (2*g)) 0)^2/
    (logSize N-q+2*harmonicVarianceErrorConstant))
  have hmean : (∫⁻ ξ, M (ξ,true)+M (ξ,false) ∂finiteFieldLaw N) ≤ ENNReal.ofReal (4*E) := by
    rw [lintegral_add_left (harmonicGaussianEnvelope_measurable N c q a₀ δ v)]
    have he := harmonicGaussianEnvelope_lintegral_bound N c q a₀ δ v hq hqL hsmall
    exact (add_le_add he he).trans_eq (by rw [← ENNReal.ofReal_add (by positivity) (by positivity)]; congr 1; dsimp [E]; ring)
  apply hh.trans
  apply add_le_add _ le_rfl
  exact (mul_le_mul' (le_refl (ENNReal.ofReal C)) hmean).trans_eq (by
    rw [← ENNReal.ofReal_mul hC.le]
    congr 1
    dsimp [E,a₀,δ]
    ring)

end TorusCoverTime.Blocks.B
