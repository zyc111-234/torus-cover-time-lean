import Solutions.Blocks.B.BT6NormToBridge

noncomputable section
open MeasureTheory ProbabilityTheory
namespace TorusCoverTime.Blocks.B

def bt6FiniteBound (L C A : ℝ) (K M n r : ℕ) : ℝ :=
  bridgeContactConstant ((K:ℝ)+2*C)*(2*A+bridgeBarrierPadding ((K:ℝ)+2*C))^2*
    (4*A+bridgeBarrierPadding ((K:ℝ)+2*C))^3/((n:ℝ)*Real.sqrt r)+
    (M+2:ℕ)*(2*Real.exp (-A/2)+2*Real.exp (-A^2/(2*K)))+
    dirichletResidualTailConstant 12*Real.exp (-((Real.log L)^2)/2)

/-- Quantitative B.30 before choosing the integer grid and the powers of log N.
All geometric and clock inputs are discharged for the actual Dirichlet field. -/
theorem bt6_finite_bound (N : Size) (root c x : Vertex N) (ρ : ℝ) (K M n r : ℕ)
    (hρ : 0<ρ) (hR : 1≤ρ*(N.val:ℝ)) (hsmall : 2*(ρ*(N.val:ℝ)+1)<N.val)
    (hdeep : periodicDistance x c+(Real.exp ((M:ℝ)+1)+1)≤ρ*(N.val:ℝ)/2)
    (hroot : root∉torusDisk N c (ρ*(N.val:ℝ)))
    (hL : 8*(bt6ClockError ρ+1)≤logSize N)
    (hK : 0<K) (hn : 0<n) (hsize : 4*bt6ClockError ρ+2≤(K:ℝ))
    (hnlo : (K:ℝ)*n≤logSize N) (hnhi : logSize N<(K:ℝ)*(n+1))
    (hmlo : K*(n-1)≤M) (hmhi : M<K*n) (hM : (M:ℝ)≤logSize N)
    (A S η δ t : ℝ) (hA : 1≤A) (hAS : A≤S) (hAC : 4*bt6ClockError ρ≤A)
    (hlast : logSize N-S≤M) (hη : 0≤η) (hηL : η≤logSize N) (hδ : 0≤δ)
    (ht : |t-harmonicExtremeCenter N|≤η)
    (hbudget : 2*δ+6*bt6BridgeError (logSize N) (bt6ClockError ρ) η≤A)
    (hr : 1≤r) (hrn : 2*r≤n) (hrS : (r:ℝ)≤S/(2*K)) (hS : 2*(K:ℝ)≤S) :
    (finiteFieldLaw N).real (bt6BarrierEvent N root (torusDisk N c (ρ*(N.val:ℝ))) x A S η δ t)≤
      bt6FiniteBound (logSize N) (bt6ClockError ρ) A K M n r := by
  let W := bt6IntegerPath N root c x (ρ*(N.val:ℝ)) M hdeep hroot
  let f := bt6GridIndex K M n hK hn hmlo
  let g := bt6NearestGrid K M n hK hmhi
  have hc := (bt6ClockError_pos ρ).le
  have hl1 : 1≤logSize N := by linarith
  have hclock := dirichlet_macroscopic_clock N root c x ρ hρ hR hsmall hroot
    (by linarith [Real.exp_pos ((M:ℝ)+1)])
  have hv := (bt6_clock_comparison (logSize N) (bt6ClockError ρ) _ hc hL hclock).1
  have hwv : 0<W.clock (Fin.last (M+1)) := by
    simpa only [W,bt6IntegerPath_clock,bt6IntegerDomain_last] using hv
  have herr := bt6IntegerPath_clock_error N root c x ρ M hρ hR hsmall hdeep hroot
  have hf := bt6GridIndex_mono K M n hK hn hmlo
  have hf0 := bt6GridIndex_zero K M n hK hn hmlo
  have hfl := bt6GridIndex_last K M n hK hn hmlo
  have hbounds : (W.neg.subsample f hf hf0).ClockBounds ((K:ℝ)+2*bt6ClockError ρ) := by
    apply GaussianClockPath.clockBounds_of_sparse_time _ (logSize N) (bt6ClockError ρ) K hc hK hsize hnlo hnhi
    intro i
    exact bt6_subsample_clock_error N root c x ρ K M n hρ hR hsmall hdeep hroot hK hn hmlo i
  have hgap := bt6_clock_nearest_gap K M n W hK hn hmlo hmhi (logSize N) (bt6ClockError ρ)
    (by linarith) herr
  have hmid (j : Fin (M+2)) (hj : j.val≤M) (hs : S≤(j.val:ℝ)) (hl : (j.val:ℝ)≤logSize N-S) :
      r≤(g j).val ∧ r≤n-(g j).val :=
    bt6_nearest_middle (logSize N) S K M n r hK hmhi hnhi hrS hS j (by omega) hs hl
  have hb := W.rawMiddleContact_bound (logSize N) (bt6ClockError ρ) A S K ((K:ℝ)+2*bt6ClockError ρ)
    (by linarith) (by exact_mod_cast hK) hc hAC hwv herr f hf hf0 hfl g
    (fun j => (bt6_nearest_grid_gap K M n hK hn hmlo hmhi j).1) hgap hbounds r hr hrn hmid
  have htail := bt6ResidualFailure_bound N root c x (ρ*(N.val:ℝ)) M hsmall hroot hdeep hv hM t
    (bt6_endpoint_clock_bound N (bt6ClockError ρ) _ η t hc hL hclock hηL ht)
  have hs := bt6BarrierEvent_subset N root c x ρ M hρ hR hsmall hdeep hroot hl1 hv
    A S η δ t hA hAS hlast hη hδ ht hbudget
  exact ((measureReal_mono (μ := finiteFieldLaw N) hs).trans (measureReal_union_le _ _)).trans
    (add_le_add hb htail)

end TorusCoverTime.Blocks.B
