import Solutions.Blocks.B.R8HighCountScaleSum

/-! Uniform disappearance of all coarse-scale high-count soft sites in a
bounded physical window. This is the full high-count branch of B-T5. -/
noncomputable section
open MeasureTheory Filter Set Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

theorem r8_high_count_envelope_tendsto (H : ℝ) :
    Tendsto (fun N : Size => 4*H*logSize N*Real.exp (-36*logSize N)) atTop (𝓝 0) := by
  have ht := ((polynomial_times_stretched_exp_tendsto_zero 1 36 1 (by norm_num) (by norm_num)).const_mul (4*H)).comp blockB_logSize_tendsto
  simpa only [Real.rpow_one,mul_zero,mul_assoc,Function.comp_def] using ht

theorem r8_all_high_count_uniform (hWalk : WalkModelRegular) (γ U H : ℝ)
    (hγ : 0 < γ) (hγ1 : γ < 1) (hU : 0 ≤ U) (hH : 0 ≤ H) :
    ∀ ε : ℝ, 0 < ε → ∀ᶠ N : Size in atTop, ∀ l r : ℝ, r-l ≤ 2*H*timeScale N →
      r8AllHighCountMass N γ U l r ≤ ENNReal.ofReal ε := by
  intro ε hε
  filter_upwards [r8_all_high_count_bound hWalk γ U H hγ hγ1 hU hH,
    (r8_high_count_envelope_tendsto H).eventually_le_const hε] with N hN hsmall
  intro l r hlen
  exact (hN l r hlen).trans (ENNReal.ofReal_le_ofReal hsmall)

theorem r8_all_high_count_tendsto (hWalk : WalkModelRegular) (γ U H : ℝ)
    (hγ : 0 < γ) (hγ1 : γ < 1) (hU : 0 ≤ U) (hH : 0 ≤ H) (l r : Size → ℝ)
    (hlen : ∀ᶠ N : Size in atTop, r N-l N ≤ 2*H*timeScale N) :
    Tendsto (fun N => r8AllHighCountMass N γ U (l N) (r N)) atTop (𝓝 0) := by
  have ht := ENNReal.tendsto_ofReal (r8_high_count_envelope_tendsto H)
  simp only [ENNReal.ofReal_zero] at ht
  apply tendsto_of_tendsto_of_tendsto_of_le_of_le' tendsto_const_nhds ht (Eventually.of_forall fun _ => bot_le)
  filter_upwards [r8_all_high_count_bound hWalk γ U H hγ hγ1 hU hH,hlen] with N hN hlenN
  exact hN (l N) (r N) hlenN

end TorusCoverTime.Blocks.B
