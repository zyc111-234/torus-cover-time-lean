import Solutions.Blocks.B.ExponentialMoments
import Solutions.Blocks.B.R7HarmonicOccupation

/-! R7.1 factorial moments on the original three radii and exact-exit law.
The only Green input below is the already proved harmonic-average bound.
The sharper deterministic center is deliberately a separate obligation. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

theorem measurable_harmonicExitOccupation (N : Size) (c : Vertex N) (r R : ℝ)
    (a : Vertex N) : Measurable (harmonicExitOccupation N c r R a) :=
  measurable_exitOccupation N (torusDisk N c R) (fun z => diskHarmonicWeight N c r z/g) a

theorem disk_harmonic_potential_bound (N : Size) (c : Vertex N) (R : ℝ)
    (hR : 0 ≤ R) (hsmall : 2*(R+1) < N.val) (b : Vertex N)
    (U : Vertex N → ℝ) (hU : ∀ z, 0 ≤ U z) (K H : ℝ) (hH : 0 ≤ H)
    (haverage : ∀ z, U z ≠ 0 → (∑ z', U z'*diskGreen N c R z z') ≤ K)
    (hratio : ∀ z z', U z ≠ 0 → U z' ≠ 0 →
      exitHarmonic N (torusDisk N c R) b z' ≤ H*exitHarmonic N (torusDisk N c R) b z)
    (z : Vertex N) (hz : U z ≠ 0) :
    exitPotentialMean N (torusDisk N c R) b U z ≤ (H*K)*exitHarmonic N (torusDisk N c R) b z := by
  rw [disk_exitPotentialMean_green N c R hR hsmall b U hU z]
  calc
    _ ≤ ∑ z', (U z'*diskGreen N c R z z')*(H*exitHarmonic N (torusDisk N c R) b z) := by
      apply Finset.sum_le_sum
      intro z' _
      by_cases hz' : U z' = 0
      · simp only [hz', zero_mul, le_refl]
      · have h := mul_le_mul_of_nonneg_left (hratio z z' hz hz')
          (mul_nonneg (hU z') (diskGreen_nonneg N c R hR hsmall z z'))
        convert h using 1 <;> ring
    _ = (∑ z', U z'*diskGreen N c R z z')*(H*exitHarmonic N (torusDisk N c R) b z) :=
      (Finset.sum_mul ..).symm
    _ ≤ K*(H*exitHarmonic N (torusDisk N c R) b z) := mul_le_mul_of_nonneg_right
      (haverage z hz) (mul_nonneg hH (exitHarmonic_nonneg N _ b z))
    _ = _ := by ring

theorem r7_support_exit_control (γ : ℝ) (hγ : 0 < γ) :
    ∀ᶠ q : ℝ in atTop, ∀ N : Size, ∀ c b : Vertex N,
      2*(Real.exp (q+2*q^γ)+1) < N.val →
      diskExteriorNeighbor N c (Real.exp (q+2*q^γ)) b →
      (∀ z, diskHarmonicWeight N c (Real.exp (q+1)) z ≠ 0 →
        0 < exitHarmonic N (torusDisk N c (Real.exp (q+2*q^γ))) b z) ∧
      (∀ z z', diskHarmonicWeight N c (Real.exp (q+1)) z ≠ 0 →
        diskHarmonicWeight N c (Real.exp (q+1)) z' ≠ 0 →
        exitHarmonic N (torusDisk N c (Real.exp (q+2*q^γ))) b z' ≤
          2*exitHarmonic N (torusDisk N c (Real.exp (q+2*q^γ))) b z) := by
  have hdecay : Tendsto (fun q : ℝ => diskExitOscillationConstant*
      Real.exp (-diskExitOscillationExponent*q^γ)) atTop (𝓝 0) := by
    have ht := (tendsto_rpow_atTop hγ).const_mul_atTop diskExitOscillationExponent_pos
    simpa only [mul_zero, neg_mul, Function.comp_def] using (Real.tendsto_exp_neg_atTop_nhds_zero.comp ht).const_mul
      diskExitOscillationConstant
  filter_upwards [r6_exit_ratio_exponential γ hγ, eventually_ge_atTop (1:ℝ),
    (tendsto_rpow_atTop hγ).eventually_ge_atTop (1:ℝ),
    (tendsto_order.mp hdecay).2 (1/2) (by norm_num)] with q hrat hq hw hε
  intro N c b hsmall hb
  have hzP : ∀ z, diskHarmonicWeight N c (Real.exp (q+1)) z ≠ 0 →
      z ∈ torusDisk N c (2*Real.exp (q+q^γ)) := by
    intro z hz
    have hrad := (diskExteriorNeighbor_radius N c _ z
      (diskHarmonicWeight_support N c _ (Real.exp_pos _) z hz)).2
    have he := Real.exp_le_exp.mpr (show q+1 ≤ q+q^γ by linarith)
    have he1 : 1 < Real.exp (q+q^γ) := Real.one_lt_exp_iff.mpr (by linarith)
    exact (mem_torusDisk N c z _).mpr (by linarith)
  have hp : ∀ z, diskHarmonicWeight N c (Real.exp (q+1)) z ≠ 0 →
      0 < exitHarmonic N (torusDisk N c (Real.exp (q+2*q^γ))) b z := by
    intro z hz
    have h := hrat N c b z z hsmall hb (hzP z hz) (hzP z hz)
    have hn := exitHarmonic_nonneg N (torusDisk N c (Real.exp (q+2*q^γ))) b z
    by_contra hnot
    have heq := le_antisymm (not_lt.mp hnot) hn
    rw [heq, zero_div, zero_sub, abs_neg, abs_one] at h
    linarith
  refine ⟨hp, ?_⟩
  intro z z' hz hz'
  have h := (abs_le.mp (hrat N c b z' z hsmall hb (hzP z' hz') (hzP z hz))).2
  have hr : exitHarmonic N (torusDisk N c (Real.exp (q+2*q^γ))) b z' /
      exitHarmonic N (torusDisk N c (Real.exp (q+2*q^γ))) b z ≤ 2 := by linarith
  exact (div_le_iff₀ (hp z hz)).mp hr

def r7MomentConstant : ℝ := 8*r7GreenAverageConstant

theorem r7MomentConstant_pos : 0 < r7MomentConstant := by
  unfold r7MomentConstant
  exact mul_pos (by norm_num) r7GreenAverageConstant_pos

theorem r7_occupation_exp_bound (hWalk : WalkModelRegular) (γ : ℝ) (hγ : 0 < γ) :
    ∀ᶠ q : ℝ in atTop, ∀ N : Size, ∀ c a b : Vertex N,
      2*(Real.exp (q+2*q^γ)+1) < N.val →
      diskExteriorNeighbor N c (Real.exp (q+2*q^γ)) b →
      (∫⁻ ω, ENNReal.ofReal (Real.exp ((1/(4*r7GreenAverageConstant*q^γ))*
        harmonicExitOccupation N c (Real.exp (q+1)) (Real.exp (q+2*q^γ)) a ω))
        ∂exactExitLaw N (torusDisk N c (Real.exp (q+2*q^γ))) a b) ≤ 2 := by
  filter_upwards [r7_support_exit_control γ hγ, eventually_ge_atTop (0:ℝ),
    (tendsto_rpow_atTop hγ).eventually_ge_atTop (1:ℝ)] with q hc hq hw
  intro N c a b hsmall hb
  have hC := r7GreenAverageConstant_pos
  have hw0 : 0 < q^γ := by linarith
  let U := fun z => diskHarmonicWeight N c (Real.exp (q+1)) z/g
  have hU : ∀ z, 0 ≤ U z := fun z => div_nonneg (diskHarmonicWeight_nonneg N c _ z) (by unfold g; positivity)
  have hne : ∀ z, U z ≠ 0 → diskHarmonicWeight N c (Real.exp (q+1)) z ≠ 0 := by
    intro z hz he
    exact hz (by dsimp only [U]; rw [he, zero_div])
  obtain ⟨hpos,hratio⟩ := hc N c b hsmall hb
  have hK : 0 < 2*r7GreenAverageConstant*q^γ := by positivity
  have hθ : 0 < 1/(4*r7GreenAverageConstant*q^γ) := by positivity
  have hθK : (1/(4*r7GreenAverageConstant*q^γ))*(2*r7GreenAverageConstant*q^γ) ≤ 1/2 := by
    apply le_of_eq
    field_simp [hC.ne', hw0.ne']
    <;> ring
  exact disk_conditioned_occupation_exp_lintegral hWalk N c _ (Real.exp_pos _).le hsmall b U hU
    _ _ hK.le hθ.le hθK (fun z _ hz => hpos z (hne z hz)) (by
      intro z _ hz
      have h := disk_harmonic_potential_bound N c _ (Real.exp_pos _).le hsmall b U hU
        (r7GreenAverageConstant*q^γ) 2 (by norm_num) (by
          intro z' hz'
          have hh := r7_harmonic_green_average_bound N c q (q^γ) hq hw hsmall z' (hne z' hz')
          simpa only [U, div_mul_eq_mul_div] using hh)
        (fun z z' hz hz' => hratio z z' (hne z hz) (hne z' hz')) z hz
      simpa only [mul_assoc] using h) a

theorem r7_occupation_factorial_moments (hWalk : WalkModelRegular) (γ : ℝ) (hγ : 0 < γ) :
    ∀ᶠ q : ℝ in atTop, ∀ N : Size, ∀ c a b : Vertex N,
      2*(Real.exp (q+2*q^γ)+1) < N.val →
      diskExteriorNeighbor N c (Real.exp (q+2*q^γ)) b → ∀ j : ℕ, 1 ≤ j →
      Integrable (fun ω => (harmonicExitOccupation N c (Real.exp (q+1)) (Real.exp (q+2*q^γ)) a ω)^j)
        (exactExitLaw N (torusDisk N c (Real.exp (q+2*q^γ))) a b) ∧
      (∫ ω, (harmonicExitOccupation N c (Real.exp (q+1)) (Real.exp (q+2*q^γ)) a ω)^j
        ∂exactExitLaw N (torusDisk N c (Real.exp (q+2*q^γ))) a b) ≤
        (j.factorial:ℝ)*(r7MomentConstant*q^γ)^j := by
  filter_upwards [r7_occupation_exp_bound hWalk γ hγ,
    (tendsto_rpow_atTop hγ).eventually_ge_atTop (1:ℝ)] with q he hw
  intro N c a b hsmall hb j hj
  have hC := r7GreenAverageConstant_pos
  have hw0 : 0 < q^γ := by linarith
  have hθ : 0 < 1/(4*r7GreenAverageConstant*q^γ) := by positivity
  have hh := power_moments_of_exp_bound _ _ (measurable_harmonicExitOccupation N c _ _ a)
    (harmonicExitOccupation_nonneg N c _ _ a) _ 2 hθ (by norm_num)
      (by simpa only [ENNReal.ofReal_ofNat] using he N c a b hsmall hb) j
  refine ⟨hh.1, hh.2.trans ?_⟩
  have h2 : (2:ℝ) ≤ 2^j := by
    simpa only [pow_one] using pow_le_pow_right₀ (by norm_num : (1:ℝ)≤2) hj
  have hmul := mul_le_mul_of_nonneg_right h2
    (show 0 ≤ (j.factorial:ℝ)*(4*r7GreenAverageConstant*q^γ)^j by positivity)
  simpa only [r7MomentConstant, one_div, inv_pow, div_inv_eq_mul,
    show 8*r7GreenAverageConstant*q^γ = 2*(4*r7GreenAverageConstant*q^γ) by ring,
    mul_pow, mul_assoc, mul_left_comm] using hmul

end TorusCoverTime.Blocks.B
