import Solutions.Blocks.B.PointSoftCentral
import Solutions.Blocks.B.DiskCardinality

/-! Spatial union bounds with the original terminal vertex kept until its
finite sum. This is valid for arbitrary initial vertices, not only stationarity. -/
noncomputable section
open MeasureTheory Filter Set Classical
open scoped ENNReal Topology BigOperators
namespace TorusCoverTime.Blocks.B

theorem point_soft_vertex_count (N : Size) : (Fintype.card (Vertex N):ℝ) = vertexCount N := by
  simp [Vertex,vertexCount,Fintype.card_prod,ZMod.card,pow_two]

theorem point_soft_sites_joint (N : Size) (a b : Vertex N) (S : Finset (Vertex N)) (t u J : ℝ)
    (hJ : ∀ c ∈ S, walkLaw.real {ω | localTime N a ω t c ≤ u ∧ walk N a ω t=b} ≤ J) :
    walkLaw.real {ω | (∃ c ∈ S, localTime N a ω t c ≤ u) ∧ walk N a ω t=b} ≤ (S.card:ℝ)*J := by
  have he : {ω | (∃ c ∈ S, localTime N a ω t c ≤ u) ∧ walk N a ω t=b} =
      ⋃ c ∈ S, {ω | localTime N a ω t c ≤ u ∧ walk N a ω t=b} := by
    ext ω
    simp only [Set.mem_ofPred_eq,mem_iUnion]
    aesop
  rw [he]
  apply (measureReal_biUnion_finset_le S _).trans
  have h := Finset.sum_le_sum hJ
  simpa only [Finset.sum_const,nsmul_eq_mul] using h

theorem point_soft_terminal_sites (N : Size) (a : Vertex N) (S : Vertex N → Finset (Vertex N))
    (t u J B : ℝ) (hJ0 : 0 ≤ J) (hS : ∀ b, (S b).card ≤ B)
    (hJ : ∀ c b : Vertex N, walkLaw.real {ω | localTime N a ω t c ≤ u ∧ walk N a ω t=b} ≤ J) :
    walkLaw.real {ω | ∃ c ∈ S (walk N a ω t), localTime N a ω t c ≤ u} ≤ vertexCount N*B*J := by
  have he : {ω | ∃ c ∈ S (walk N a ω t), localTime N a ω t c ≤ u} =
      ⋃ b : Vertex N, {ω | (∃ c ∈ S b, localTime N a ω t c ≤ u) ∧ walk N a ω t=b} := by
    ext ω
    simp only [Set.mem_ofPred_eq,mem_iUnion]
    constructor
    · intro h
      exact ⟨walk N a ω t,h,rfl⟩
    · rintro ⟨b,h,hb⟩
      simpa only [hb] using h
  rw [he]
  apply (measureReal_iUnion_fintype_le _).trans
  have hh : ∀ b : Vertex N,
      walkLaw.real {ω | (∃ c ∈ S b, localTime N a ω t c ≤ u) ∧ walk N a ω t=b} ≤ B*J := fun b =>
    (point_soft_sites_joint N a b (S b) t u J (fun c _ => hJ c b)).trans
      (mul_le_mul_of_nonneg_right (hS b) hJ0)
  have h := Finset.sum_le_sum (s := Finset.univ) (fun b _ => hh b)
  simpa only [Finset.sum_const,Finset.card_univ,nsmul_eq_mul,point_soft_vertex_count,mul_assoc] using h

theorem point_soft_single_marginal (N : Size) (a c : Vertex N) (t u J : ℝ) (hJ0 : 0 ≤ J)
    (hJ : ∀ b : Vertex N, walkLaw.real {ω | localTime N a ω t c ≤ u ∧ walk N a ω t=b} ≤ J) :
    walkLaw.real {ω | localTime N a ω t c ≤ u} ≤ vertexCount N*J := by
  have hs : walkLaw.real {ω | ∃ x ∈ ({c}:Finset (Vertex N)), localTime N a ω t x ≤ u} ≤ vertexCount N*J := by
    have he : {ω | localTime N a ω t c ≤ u} = ⋃ b : Vertex N,
        {ω | localTime N a ω t c ≤ u ∧ walk N a ω t=b} := by ext ω; simp
    simp only [Finset.mem_singleton,exists_eq_left]
    rw [he]
    apply (measureReal_iUnion_fintype_le _).trans
    simpa only [Finset.sum_const,Finset.card_univ,nsmul_eq_mul,point_soft_vertex_count] using
      Finset.sum_le_sum (s := Finset.univ) (fun b _ => hJ b)
  simpa using hs

def pointNearSoftEvent (N : Size) (a root : Vertex N) (R u : ℝ) : Set (WalkSample × ℝ) :=
  {z | ∃ c ∈ torusDisk N root R, localTime N a z.1 z.2 c ≤ u}

def pointNearTerminalEvent (N : Size) (a : Vertex N) (R u : ℝ) : Set (WalkSample × ℝ) :=
  {z | ∃ c ∈ torusDisk N (walk N a z.1 z.2) R, localTime N a z.1 z.2 c ≤ u}

theorem pointNearSoftEvent_measurable (N : Size) (a root : Vertex N) (R u : ℝ) :
    MeasurableSet (pointNearSoftEvent N a root R u) := by
  simp only [pointNearSoftEvent,Set.ofPred_exists]
  apply MeasurableSet.iUnion
  intro c
  by_cases hc : c ∈ torusDisk N root R
  · simpa only [hc,true_and] using
      measurableSet_le (localTime_joint_measurable N a c) (measurable_const (a := u))
  · simp [hc]

theorem pointNearTerminalEvent_eq_union (N : Size) (a : Vertex N) (R u : ℝ) :
    pointNearTerminalEvent N a R u = ⋃ b : Vertex N,
      pointNearSoftEvent N a b R u ∩ {z | walk N a z.1 z.2=b} := by
  ext z
  simp only [pointNearTerminalEvent,pointNearSoftEvent,Set.mem_ofPred_eq,mem_iUnion,mem_inter_iff]
  constructor
  · intro h
    exact ⟨walk N a z.1 z.2,h,rfl⟩
  · rintro ⟨b,h,hb⟩
    simpa only [hb] using h

theorem pointNearTerminalEvent_measurable (N : Size) (a : Vertex N) (R u : ℝ) :
    MeasurableSet (pointNearTerminalEvent N a R u) := by
  rw [pointNearTerminalEvent_eq_union]
  exact MeasurableSet.iUnion fun b => (pointNearSoftEvent_measurable N a b R u).inter
    (measurable_walk_eq_joint N a b).setOf

theorem point_near_fixed_probability (N : Size) (a root : Vertex N) (R t u J : ℝ)
    (hR : 0 ≤ R) (hJ0 : 0 ≤ J)
    (hJ : ∀ c b : Vertex N, walkLaw.real {ω | localTime N a ω t c ≤ u ∧ walk N a ω t=b} ≤ J) :
    walkLaw.real {ω | (ω,t) ∈ pointNearSoftEvent N a root R u} ≤ vertexCount N*(2*R+1)^2*J :=
  point_soft_terminal_sites N a (fun _ => torusDisk N root R) t u J _ hJ0
    (fun _ => torusDisk_card_le N root R hR) hJ

theorem point_near_terminal_probability (N : Size) (a : Vertex N) (R t u J : ℝ)
    (hR : 0 ≤ R) (hJ0 : 0 ≤ J)
    (hJ : ∀ c b : Vertex N, walkLaw.real {ω | localTime N a ω t c ≤ u ∧ walk N a ω t=b} ≤ J) :
    walkLaw.real {ω | (ω,t) ∈ pointNearTerminalEvent N a R u} ≤ vertexCount N*(2*R+1)^2*J :=
  point_soft_terminal_sites N a (fun b => torusDisk N b R) t u J _ hJ0
    (fun b => torusDisk_card_le N b R hR) hJ

end TorusCoverTime.Blocks.B
