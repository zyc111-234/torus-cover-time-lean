import Solutions.Blocks.B.EigenvalueBounds

/-! Exact folding of finite-torus coordinates into their centered distances. -/

noncomputable section
open scoped BigOperators
namespace TorusCoverTime.Blocks.B

lemma sum_centered_coordinate (N : Size) (f : ℝ → ℝ) :
    (∑ a : ZMod N.val, f (coordinateDistance a 0)) = f 0 +
      (∑ j ∈ Finset.range (N.val / 2), f ((j : ℝ) + 1)) +
      (∑ j ∈ Finset.range ((N.val - 1) / 2), f ((j : ℝ) + 1)) := by
  classical
  have hlow : (∑ a ∈ Finset.univ.filter (fun a : ZMod N.val => a.val ≤ N.val / 2),
      f (coordinateDistance a 0)) = ∑ j ∈ Finset.range (N.val / 2 + 1), f (j : ℝ) := by
    apply Finset.sum_bij (fun a _ => a.val)
    · intro a ha
      exact Finset.mem_range.mpr (by have := (Finset.mem_filter.mp ha).2; omega)
    · intro a _ b _ hab
      exact ZMod.val_injective N.val hab
    · intro j hj
      have hj' := Finset.mem_range.mp hj
      have hjN : j < N.val := by have := N.property; omega
      refine ⟨(j : ZMod N.val), ?_, ZMod.val_cast_of_lt hjN⟩
      simp only [Finset.mem_filter, Finset.mem_univ, true_and, ZMod.val_cast_of_lt hjN]
      omega
    · intro a ha
      have htw : 2 * a.val ≤ N.val := by have := (Finset.mem_filter.mp ha).2; omega
      have htwR : 2 * (a.val : ℝ) ≤ N.val := by exact_mod_cast htw
      rw [coordinateDistance_zero_eq_min, min_eq_left (by linarith)]
  have hhigh : (∑ a ∈ Finset.univ.filter (fun a : ZMod N.val => ¬ a.val ≤ N.val / 2),
      f (coordinateDistance a 0)) =
      ∑ j ∈ Finset.range ((N.val - 1) / 2), f ((j : ℝ) + 1) := by
    apply Finset.sum_bij (fun a _ => N.val - a.val - 1)
    · intro a ha
      have hv := ZMod.val_lt a
      have hhalf := (Finset.mem_filter.mp ha).2
      apply Finset.mem_range.mpr
      omega
    · intro a _ b _ hab
      apply ZMod.val_injective N.val
      have := ZMod.val_lt a
      have := ZMod.val_lt b
      omega
    · intro j hj
      have hj' := Finset.mem_range.mp hj
      have hjN : N.val - (j + 1) < N.val := by have := N.property; omega
      refine ⟨((N.val - (j + 1) : ℕ) : ZMod N.val), ?_, ?_⟩
      · simp only [Finset.mem_filter, Finset.mem_univ, true_and, ZMod.val_cast_of_lt hjN]
        omega
      · rw [ZMod.val_cast_of_lt hjN]
        omega
    · intro a ha
      have hv := ZMod.val_lt a
      have hhalf := (Finset.mem_filter.mp ha).2
      have htw : N.val ≤ 2 * a.val := by omega
      have htwR : (N.val : ℝ) ≤ 2 * a.val := by exact_mod_cast htw
      rw [coordinateDistance_zero_eq_min, min_eq_right (by linarith)]
      congr 1
      rw [Nat.cast_sub (by omega : 1 ≤ N.val - a.val), Nat.cast_sub hv.le, Nat.cast_one]
      ring
  rw [← Finset.sum_filter_add_sum_filter_not (p := fun a : ZMod N.val => a.val ≤ N.val / 2),
    hlow, hhigh, Finset.sum_range_succ']
  simp only [Nat.cast_add, Nat.cast_one, Nat.cast_zero]
  ring

def symmetricCoordinateSum (n : ℕ) (f : ℝ → ℝ) : ℝ :=
  f 0 + 2 * ∑ j ∈ Finset.range n, f ((j : ℝ) + 1)

lemma sum_centered_coordinate_bounds (N : Size) (f : ℝ → ℝ)
    (hf : ∀ j : ℕ, 0 ≤ f ((j : ℝ) + 1)) :
    symmetricCoordinateSum ((N.val - 1) / 2) f ≤
      (∑ a : ZMod N.val, f (coordinateDistance a 0)) ∧
    (∑ a : ZMod N.val, f (coordinateDistance a 0)) ≤
      symmetricCoordinateSum (N.val / 2) f := by
  have hm : (N.val - 1) / 2 ≤ N.val / 2 := by omega
  have hs : (∑ j ∈ Finset.range ((N.val - 1) / 2), f ((j : ℝ) + 1)) ≤
      ∑ j ∈ Finset.range (N.val / 2), f ((j : ℝ) + 1) := by
    apply Finset.sum_le_sum_of_subset_of_nonneg (Finset.range_mono hm)
    intro j _ _
    exact hf j
  rw [sum_centered_coordinate]
  unfold symmetricCoordinateSum
  constructor <;> linarith

lemma symmetricCoordinateSum_nonneg (n : ℕ) (f : ℝ → ℝ)
    (h0 : 0 ≤ f 0) (hf : ∀ j : ℕ, 0 ≤ f ((j : ℝ) + 1)) :
    0 ≤ symmetricCoordinateSum n f := by
  exact add_nonneg h0 (mul_nonneg (by norm_num) (Finset.sum_nonneg (fun j _ => hf j)))

lemma symmetricCoordinateSum_mono (n : ℕ) (f g : ℝ → ℝ)
    (h0 : f 0 ≤ g 0) (hf : ∀ j : ℕ, f ((j : ℝ) + 1) ≤ g ((j : ℝ) + 1)) :
    symmetricCoordinateSum n f ≤ symmetricCoordinateSum n g := by
  apply add_le_add h0
  exact mul_le_mul_of_nonneg_left (Finset.sum_le_sum (fun j _ => hf j)) (by norm_num)

lemma symmetricCoordinateSum_eq_twice (n : ℕ) (f : ℝ → ℝ) :
    symmetricCoordinateSum n f = 2 * (∑ j ∈ Finset.range (n + 1), f (j : ℝ)) - f 0 := by
  rw [Finset.sum_range_succ']
  simp only [Nat.cast_add, Nat.cast_one, Nat.cast_zero, symmetricCoordinateSum]
  ring

lemma sum_centered_two_coordinates_bounds (N : Size) (f : ℝ → ℝ → ℝ)
    (hf : ∀ x y, 0 ≤ f x y) :
    symmetricCoordinateSum ((N.val - 1) / 2)
        (fun x => symmetricCoordinateSum ((N.val - 1) / 2) (f x)) ≤
      (∑ a : ZMod N.val, ∑ b : ZMod N.val, f (coordinateDistance a 0) (coordinateDistance b 0)) ∧
    (∑ a : ZMod N.val, ∑ b : ZMod N.val, f (coordinateDistance a 0) (coordinateDistance b 0)) ≤
      symmetricCoordinateSum (N.val / 2) (fun x => symmetricCoordinateSum (N.val / 2) (f x)) := by
  let actual := fun x : ℝ => ∑ b : ZMod N.val, f x (coordinateDistance b 0)
  have hx (x : ℝ) := sum_centered_coordinate_bounds N (f x) (fun j => hf x _)
  have houter := sum_centered_coordinate_bounds N actual
    (fun j => Finset.sum_nonneg (fun b _ => hf _ _))
  constructor
  · exact (symmetricCoordinateSum_mono _ _ _ (hx 0).1 (fun j => (hx _).1)).trans houter.1
  · exact houter.2.trans (symmetricCoordinateSum_mono _ _ _ (hx 0).2 (fun j => (hx _).2))

end TorusCoverTime.Blocks.B
