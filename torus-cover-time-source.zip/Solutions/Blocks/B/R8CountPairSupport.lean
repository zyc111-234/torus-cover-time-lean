import Solutions.Blocks.B.R8ModerateCountSupport

/-! The actual pair of counts has a finite support, including zero counts.
The support bound pays both indices explicitly. -/
noncomputable section
open Filter Set Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

def r8CountPairs (L : ℝ) : Finset (ℕ × ℕ) := (r8ModerateCounts L) ×ˢ (r8ModerateCounts L)

theorem r8_count_pair_mem (L h h' : ℝ) (m n : ℕ) (hh : 1 ≤ h) (hh' : 1 ≤ h')
    (hm : Real.sqrt (h*(m:ℝ)) ≤ 10*L) (hn : Real.sqrt (h'*(n:ℝ)) ≤ 10*L) :
    (m,n) ∈ r8CountPairs L :=
  Finset.mem_product.mpr ⟨r8_moderate_count_mem L h m hh hm,r8_moderate_count_mem L h' n hh' hn⟩

theorem r8_count_pairs_card (L : ℝ) (hL : 1 ≤ L) :
    ((r8CountPairs L).card:ℝ) ≤ 10201*L^4 := by
  have hc := r8_moderate_counts_card L hL
  have hp := mul_le_mul hc hc (Nat.cast_nonneg _) (by positivity : 0 ≤ 101*L^2)
  simpa only [r8CountPairs,Finset.card_product,Nat.cast_mul] using
    hp.trans_eq (show (101*L^2)*(101*L^2) = 10201*L^4 by ring)

theorem r8_count_pairs_sum_bound (L : ℝ) (hL : 1 ≤ L) (f : ℕ × ℕ → ℝ≥0∞) (A : ℝ≥0∞)
    (hf : ∀ p ∈ r8CountPairs L, f p ≤ A) :
    (∑ p ∈ r8CountPairs L, f p) ≤ ENNReal.ofReal (10201*L^4)*A := by
  calc
    _ ≤ ∑ _p ∈ r8CountPairs L, A := Finset.sum_le_sum hf
    _ ≤ _ := by
      rw [Finset.sum_const,nsmul_eq_mul]
      apply mul_le_mul' _ le_rfl
      simpa only [ENNReal.ofReal_natCast] using ENNReal.ofReal_le_ofReal (r8_count_pairs_card L hL)

end TorusCoverTime.Blocks.B
