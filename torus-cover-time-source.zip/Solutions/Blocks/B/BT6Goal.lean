import Solutions.Blocks.B.DirichletConditionedField
import Solutions.Blocks.B.GaussianBridgeContactBound

/-! Fixed B-T6 target. The amplitude is quantified inside the event, and
every integer scale of the paper is retained. B.30 is a bound for the actual
Gaussian conditional field, uniformly in the deep interior and endpoint. -/

noncomputable section
open MeasureTheory Filter
open scoped BigOperators Topology
namespace TorusCoverTime.Blocks.B

def bt6ExitNorm (N : Size) (x : Vertex N) (q : ℕ) (f : Vertex N → ℝ) (a : ℝ) : ℝ :=
  Real.sqrt (∑ z, exitHarmonic N (torusDisk N x (Real.exp ((q:ℝ)+1))) z x*(f z-a)^2)

def bt6BadField (N : Size) (x : Vertex N) (γ η δ : ℝ) (f : Vertex N → ℝ) : Prop :=
  ∃ a : ℝ, |a-harmonicExtremeCenter N|≤η ∧
    (∀ q : ℕ, (logSize N)^(32*γ)≤(q:ℝ) → (q:ℝ)≤logSize N-(logSize N)^(32*γ) →
      Real.sqrt 2*(q:ℝ)-δ≤bt6ExitNorm N x q f a) ∧
    ∃ q : ℕ, (logSize N)^(1/10:ℝ)≤(q:ℝ) ∧ (q:ℝ)≤logSize N-(logSize N)^(1/10:ℝ) ∧
      bt6ExitNorm N x q f a≤Real.sqrt 2*(q:ℝ)+δ

def BT6DirichletConclusion (γ ρ C₀ C₁ : ℝ) : Prop :=
  ∃ C : ℝ, 0<C ∧ ∀ᶠ N : Size in atTop,
    ∀ root c x : Vertex N, root∉torusDisk N c (ρ*(N.val:ℝ)) →
      periodicDistance x c≤ρ*(N.val:ℝ)/4 → ∀ t : ℝ,
        |t-harmonicExtremeCenter N|≤C₀*(Real.log (logSize N)+1) →
    (finiteFieldLaw N) {ξ | bt6BadField N x γ (C₀*(Real.log (logSize N)+1)) (C₁*(logSize N)^(8*γ))
      (dirichletConditionedField N root (torusDisk N c (ρ*(N.val:ℝ))) x t ξ)} ≤
        ENNReal.ofReal (C*(logSize N)^(160*γ)/(logSize N*Real.sqrt ((logSize N)^(1/10:ℝ)))+
          C*Real.exp (-((Real.log (logSize N))^2)/4))

end TorusCoverTime.Blocks.B
