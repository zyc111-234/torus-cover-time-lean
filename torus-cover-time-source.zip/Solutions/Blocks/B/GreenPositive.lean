import Solutions.Blocks.B.DirichletEnergy

/-! Strict positivity of the Green quadratic form on every proper support. -/

noncomputable section
open scoped BigOperators
namespace TorusCoverTime.Blocks.B

lemma greenOperator_add (N : Size) (q r : Vertex N → ℝ) :
    greenOperator N (q + r) = greenOperator N q + greenOperator N r := by
  funext x
  simp [greenOperator, mul_add, Finset.sum_add_distrib]

lemma greenOperator_sub (N : Size) (q r : Vertex N → ℝ) :
    greenOperator N (q - r) = greenOperator N q - greenOperator N r := by
  funext x
  simp [greenOperator, mul_sub, Finset.sum_sub_distrib]

lemma greenOperator_smul (N : Size) (c : ℝ) (q : Vertex N → ℝ) :
    greenOperator N (c • q) = c • greenOperator N q := by
  funext x
  simp only [greenOperator, Pi.smul_apply, smul_eq_mul, Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro y _
  ring

lemma greenOperator_zero (N : Size) : greenOperator N 0 = 0 := by
  funext x
  simp [greenOperator]

lemma sum_eq_zero_of_mean_zero (N : Size) (f : Vertex N → ℝ)
    (hf : spatialMean N f = 0) : (∑ x : Vertex N, f x) = 0 :=
  (div_eq_zero_iff.mp hf).resolve_right (vertexCount_pos N).ne'

lemma dirichletPairing_green (N : Size) (f q : Vertex N → ℝ)
    (hf : spatialMean N f = 0) :
    dirichletPairing N f (greenOperator N q) = ∑ x : Vertex N, f x * q x := by
  simp only [dirichletPairing, greenOperator_generator, mul_sub, Finset.sum_sub_distrib]
  rw [← Finset.sum_mul, sum_eq_zero_of_mean_zero N f hf, zero_mul, sub_zero]

lemma energy_greenOperator (N : Size) (q : Vertex N → ℝ) :
    energy N (greenOperator N q) = ∑ x : Vertex N, q x * greenOperator N q x := by
  simpa only [dirichletPairing, energy, mul_comm] using
    dirichletPairing_green N (greenOperator N q) q (greenOperator_mean_zero N q)

lemma green_quadratic_eq_energy (N : Size) (q : Vertex N → ℝ) :
    (∑ x : Vertex N, ∑ y : Vertex N, q x * greenKernel N x y * q y) =
      energy N (greenOperator N q) := by
  rw [energy_greenOperator]
  simp only [greenOperator, Finset.mul_sum, mul_assoc]

lemma greenOperator_energy_zero_constant (N : Size) (q : Vertex N → ℝ)
    (hq : energy N (greenOperator N q) = 0) : ∀ x, q x = spatialMean N q := by
  have hz := energy_zero_of_mean_zero N (greenOperator N q) (greenOperator_mean_zero N q) hq
  intro x
  have hgen := greenOperator_generator N q x
  rw [hz] at hgen
  have hgen0 : generator N (0 : Vertex N → ℝ) x = 0 := generator_const N 0 x
  rw [hgen0, neg_zero] at hgen
  linarith

lemma green_quadratic_pos (N : Size) (A : Finset (Vertex N)) (hA : A ≠ Finset.univ)
    (q : Vertex N → ℝ) (hsupport : ∀ x, x ∉ A → q x = 0) (hq : q ≠ 0) :
    0 < ∑ x : Vertex N, ∑ y : Vertex N, q x * greenKernel N x y * q y := by
  rw [green_quadratic_eq_energy]
  refine lt_of_le_of_ne (energy_nonneg N _) ?_
  intro hz
  have hconst := greenOperator_energy_zero_constant N q hz.symm
  obtain ⟨z, hz⟩ : ∃ z : Vertex N, z ∉ A := by
    by_contra! hall
    exact hA (Finset.eq_univ_iff_forall.mpr hall)
  have hmean : spatialMean N q = 0 := (hconst z).symm.trans (hsupport z hz)
  apply hq
  funext x
  exact (hconst x).trans hmean

lemma supported_green_injective (N : Size) (A : Finset (Vertex N)) (hA : A ≠ Finset.univ)
    (q : Vertex N → ℝ) (hsupport : ∀ x, x ∉ A → q x = 0)
    (hgreen : ∀ x ∈ A, greenOperator N q x = 0) : q = 0 := by
  by_contra hq
  have hpos := green_quadratic_pos N A hA q hsupport hq
  rw [green_quadratic_eq_energy, energy_greenOperator] at hpos
  have hzero : (∑ x : Vertex N, q x * greenOperator N q x) = 0 := by
    apply Finset.sum_eq_zero
    intro x _
    by_cases hx : x ∈ A
    · rw [hgreen x hx, mul_zero]
    · rw [hsupport x hx, zero_mul]
  linarith

end TorusCoverTime.Blocks.B
