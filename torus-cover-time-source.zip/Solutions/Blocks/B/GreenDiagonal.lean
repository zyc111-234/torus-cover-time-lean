import Solutions.Blocks.B.LatticeSums
import Solutions.Blocks.B.CenteredFrequencies

/-! The precise (2/pi) log N Green-diagonal asymptotic, with a uniform bounded error. -/

noncomputable section
open scoped BigOperators
namespace TorusCoverTime.Blocks.B

def symmetricLatticeSum (n : ℕ) : ℝ :=
  symmetricCoordinateSum n (fun x => symmetricCoordinateSum n (fun y => 1 / (x ^ 2 + y ^ 2)))

lemma symmetricLatticeSum_eq_quadrant (n : ℕ) :
    symmetricLatticeSum n = 4 * quadrantReciprocalSum n -
      4 * ∑ j ∈ Finset.range n, 1 / ((j : ℝ) + 1) ^ 2 := by
  have hrow : (∑ j ∈ Finset.range (n + 1), 1 / (j : ℝ) ^ 2) =
      ∑ j ∈ Finset.range n, 1 / ((j : ℝ) + 1) ^ 2 := by
    rw [Finset.sum_range_succ']
    simp
  unfold symmetricLatticeSum
  simp_rw [symmetricCoordinateSum_eq_twice]
  simp only [zero_pow (by decide : 2 ≠ 0), add_zero, zero_add, div_zero,
    Finset.sum_sub_distrib, ← Finset.mul_sum, sub_zero, hrow]
  unfold quadrantReciprocalSum
  ring

lemma symmetricLatticeSum_log_error (n : ℕ) (hn : 0 < n) :
    |symmetricLatticeSum n - 2 * Real.pi * Real.log n| ≤ 32 + 2 * Real.pi := by
  have hq := abs_le.mp (quadrantReciprocalSum_log_error n hn)
  have hsq := sum_reciprocal_squares_le_two n
  have hnonneg : 0 ≤ ∑ j ∈ Finset.range n, 1 / ((j : ℝ) + 1) ^ 2 :=
    Finset.sum_nonneg (fun j _ => by positivity)
  rw [symmetricLatticeSum_eq_quadrant, abs_le]
  constructor <;> nlinarith

lemma sum_reciprocal_frequency_eq_double (N : Size) :
    (∑ k ∈ nonzeroFrequencies N, 1 / frequencyNormSq N k) =
      ∑ a : ZMod N.val, ∑ b : ZMod N.val,
        1 / ((coordinateDistance a 0) ^ 2 + (coordinateDistance b 0) ^ 2) := by
  classical
  have h := Finset.sum_erase_add (s := (Finset.univ : Finset (Vertex N)))
    (fun k => 1 / frequencyNormSq N k) (Finset.mem_univ 0)
  have hz : frequencyNormSq N 0 = 0 := by simp [frequencyNormSq, coordinateDistance]
  simp only [hz, div_zero, add_zero] at h
  rw [show nonzeroFrequencies N = Finset.univ.erase 0 from rfl, h]
  simp only [Fintype.sum_prod_type, frequencyNormSq]

lemma sum_reciprocal_frequency_sandwich (N : Size) :
    symmetricLatticeSum ((N.val - 1) / 2) ≤
      (∑ k ∈ nonzeroFrequencies N, 1 / frequencyNormSq N k) ∧
    (∑ k ∈ nonzeroFrequencies N, 1 / frequencyNormSq N k) ≤
      symmetricLatticeSum (N.val / 2) := by
  rw [sum_reciprocal_frequency_eq_double]
  exact sum_centered_two_coordinates_bounds N (fun x y => 1 / (x ^ 2 + y ^ 2))
    (fun x y => by positivity)

lemma centered_radius_log_bounds (N : Size) :
    0 < (N.val - 1) / 2 ∧ 0 < N.val / 2 ∧
    Real.log (N.val : ℝ) - Real.log 4 ≤ Real.log (((N.val - 1) / 2 : ℕ) : ℝ) ∧
    Real.log ((N.val / 2 : ℕ) : ℝ) ≤ Real.log (N.val : ℝ) := by
  have hN := N.property
  have hm : 0 < (N.val - 1) / 2 := by omega
  have hr : 0 < N.val / 2 := by omega
  have hmR : 0 < (((N.val - 1) / 2 : ℕ) : ℝ) := by exact_mod_cast hm
  have hrR : 0 < ((N.val / 2 : ℕ) : ℝ) := by exact_mod_cast hr
  refine ⟨hm, hr, ?_, ?_⟩
  · have hfour : (N.val : ℝ) ≤ 4 * (((N.val - 1) / 2 : ℕ) : ℝ) := by
      exact_mod_cast (show N.val ≤ 4 * ((N.val - 1) / 2) by omega)
    have hl := Real.log_le_log (lt_trans zero_lt_one (size_real_gt_one N)) hfour
    rw [Real.log_mul (by norm_num) hmR.ne'] at hl
    linarith
  · apply Real.log_le_log hrR
    exact_mod_cast (show N.val / 2 ≤ N.val by omega)

lemma sum_reciprocal_frequency_log_error (N : Size) :
    |(∑ k ∈ nonzeroFrequencies N, 1 / frequencyNormSq N k) -
      2 * Real.pi * logSize N| ≤ 32 + 2 * Real.pi + 2 * Real.pi * Real.log 4 := by
  have hr := centered_radius_log_bounds N
  have hlo := abs_le.mp (symmetricLatticeSum_log_error _ hr.1)
  have hhi := abs_le.mp (symmetricLatticeSum_log_error _ hr.2.1)
  have hs := sum_reciprocal_frequency_sandwich N
  have hp : 0 ≤ 2 * Real.pi := by positivity
  have hlomul := mul_le_mul_of_nonneg_left hr.2.2.1 hp
  have hhimul := mul_le_mul_of_nonneg_left hr.2.2.2 hp
  have hl4 : 0 ≤ Real.log 4 := Real.log_nonneg (by norm_num)
  unfold logSize
  rw [abs_le]
  constructor <;> nlinarith [mul_nonneg hp hl4]

def greenDiagonalErrorConstant : ℝ :=
  Real.pi ^ 2 / 12 + (32 + 2 * Real.pi + 2 * Real.pi * Real.log 4) / Real.pi ^ 2

lemma greenDiagonalErrorConstant_pos : 0 < greenDiagonalErrorConstant := by
  have hl4 : 0 ≤ Real.log 4 := Real.log_nonneg (by norm_num)
  unfold greenDiagonalErrorConstant
  positivity

lemma greenDiagonal_log_error (N : Size) :
    |greenDiagonal N - g * logSize N| ≤ greenDiagonalErrorConstant := by
  have hp := sq_pos_of_pos Real.pi_pos
  have hid : greenDiagonal N - g * logSize N =
      (greenDiagonal N - (∑ k ∈ nonzeroFrequencies N, 1 / frequencyNormSq N k) / Real.pi ^ 2) +
      ((∑ k ∈ nonzeroFrequencies N, 1 / frequencyNormSq N k) -
        2 * Real.pi * logSize N) / Real.pi ^ 2 := by
    unfold g
    field_simp
    ring
  rw [hid]
  apply (abs_add_le _ _).trans
  apply add_le_add (greenDiagonal_quadratic_error N)
  rw [abs_div, abs_of_pos hp]
  exact div_le_div_of_nonneg_right (sum_reciprocal_frequency_log_error N) hp.le

end TorusCoverTime.Blocks.B
