import Solutions.Blocks.B.ExitSinglePointLaplace
import Solutions.Blocks.B.ExactExitSoftness
import Solutions.Blocks.B.BernoulliExponential

/-! B-T3: optimized lower tails for the sum of the actual full local times
of independent specified-exit blocks. The Green parameter bounds in this
general interface are discharged for the paper's annuli in R8SingleSoftness. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

theorem bernoulli_laplace_envelope_mono (p P l L t : ℝ)
    (hp : 0 ≤ p) (hP : p ≤ P) (hl : 0 < l) (hL : l ≤ L) (ht : 0 ≤ t) :
    1-P*t/(l+t) ≤ 1-p+p*L/(L+t) := by
  have hlt : 0 < l+t := add_pos_of_pos_of_nonneg hl ht
  have hLt : 0 < L+t := by linarith
  have h := (div_le_div_of_nonneg_left (mul_nonneg hp ht) hlt
    (show l+t ≤ L+t by linarith)).trans
      (div_le_div_of_nonneg_right (mul_le_mul_of_nonneg_right hP ht) hlt.le)
  have he : 1-p+p*L/(L+t) = 1-p*t/(L+t) := by field_simp; ring
  rw [he]
  linarith

theorem disk_exitBlock_normalized_softness_bound (hWalk : WalkModelRegular)
    (N : Size) (c : Vertex N) (R : ℝ) (hR : 0 ≤ R) (hsmall : 2*(R+1) < N.val)
    (m : ℕ) (a b : Fin m → Vertex N)
    (hexit : ∀ i, walkLaw (exitsThrough N (torusDisk N c R) (a i) (b i)) ≠ 0)
    (x : Vertex N) (hx : x ∈ torusDisk N c R) (p lam U : ℝ)
    (hp : 0 ≤ p) (hlam : 0 < lam) (hU : 0 ≤ U)
    (hhit : ∀ i, p ≤ diskGreen N c R (a i) x/diskGreen N c R x x *
      (exitHarmonic N (torusDisk N c R) (b i) x /
        exitHarmonic N (torusDisk N c R) (b i) (a i)))
    (hrate : g/diskGreen N c R x x ≤ lam) :
    (exactExitProductLaw N (torusDisk N c R) m a b).real
      {ω | exitBlockOccupation N (torusDisk N c R) m a ω x/g ≤ U} ≤
      Real.exp (-((max (Real.sqrt ((m:ℝ)*p)-Real.sqrt (lam*U)) 0)^2)) := by
  let D := torusDisk N c R
  let ν := fun i => exactExitLaw N D (a i) (b i)
  have (i : Fin m) : IsProbabilityMeasure (ν i) := cond_isProbabilityMeasure (hexit i)
  let μ := Measure.pi ν
  let X := fun (i : Fin m) (ω : WalkSample) =>
    localTime N (a i) ω (finiteExitDuration N D (a i) ω) x/g
  let V := fun (i : Fin m) (ω : Fin m → WalkSample) => X i (ω i)
  have hg : 0 < g := by unfold g; positivity
  have hG : 0 < diskGreen N c R x x :=
    zero_lt_one.trans_le (diskGreen_diagonal N c R hR hsmall x hx)
  have hm (i : Fin m) : Measurable (X i) :=
    (localTime_measurable_random_time N (a i) x _
      (measurable_finiteExitDuration N D (a i))).div_const g
  have hV (i : Fin m) : Measurable (V i) := (hm i).comp (measurable_pi_apply i)
  have hV0 (i : Fin m) : ∀ᵐ ω ∂μ, 0 ≤ V i ω := Eventually.of_forall fun ω =>
    div_nonneg (localTime_nonneg N (a i) x (ω i) _) hg.le
  have hind : iIndepFun V μ := iIndepFun_pi (fun i => (hm i).aemeasurable)
  have hmean (i : Fin m) (t : ℝ) :
      (∫ ω, Real.exp (-t*V i ω) ∂μ) = ∫ ω, Real.exp (-t*X i ω) ∂ν i := by
    have hi := integral_map (μ := μ) (φ := fun ω : Fin m → WalkSample => ω i)
      (f := fun ω : WalkSample => Real.exp (-t*X i ω))
      (measurable_pi_apply i).aemeasurable ((hm i).const_mul (-t)).exp.aestronglyMeasurable
    rw [(measurePreserving_eval ν i).map_eq] at hi
    exact hi.symm
  have hlap (i : Fin m) (t : ℝ) (ht : 0 ≤ t) :
      (∫ ω, Real.exp (-t*V i ω) ∂μ) ≤ 1-p+p*lam/(lam+t) := by
    rw [hmean]
    have ha : 0 < exitHarmonic N D (b i) (a i) :=
      ENNReal.toReal_pos (hexit i) (measure_ne_top walkLaw _)
    rw [show (∫ ω, Real.exp (-t*X i ω) ∂ν i) = _ from
      disk_conditioned_normalized_localTime_laplace hWalk N c R hR hsmall
        (a i) (b i) x hx ha t ht]
    exact bernoulli_laplace_envelope_mono p _ _ lam t hp (hhit i)
      (div_pos hg hG) hrate ht
  have h := chernoff_optimize_sqrt_gap _ ((m:ℝ)*p) lam U
    (mul_nonneg (Nat.cast_nonneg m) hp) hlam hU measureReal_le_one
    (fun t ht => bernoulli_exponential_chernoff μ m V hV hV0 hind p lam U t
      hlam ht (fun i => hlap i t ht))
  simpa only [V, X, ← Finset.sum_div, μ, ν, D, exitBlockOccupation,
    exactExitProductLaw] using h

end TorusCoverTime.Blocks.B
