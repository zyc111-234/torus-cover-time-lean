import Solutions.Blocks.B.NestedPhysicalGaussian
import Solutions.Blocks.B.NestedExteriorCount
import Solutions.Blocks.B.CenteredPhysicalWordWindow
import Solutions.Blocks.B.WordWindowMixture

/-! The actual low inner natural count in a fixed outer count window, averaged over all endpoint words. -/
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B


theorem physicalWordWindow_low_inner_le_nested (N : Size) (Q O I J : Finset (Vertex N)) (root : Vertex N)
    (m n : ℕ) (w : Fin (2*m) → Vertex N) (h U l r : ℝ) (hh : 0 ≤ h) (hU : h*(n:ℝ) ≤ U) :
    physicalWordWindow N Q O root m w
      (fun z => if completedTraversalCount N I J root z.1 z.2 ≤ n then 1 else 0) l r ≤
      nestedPhysicalExteriorSlice N Q O I J root m w h U (fun _ => 1) l r := by
  apply lintegral_mono
  intro ω
  apply lintegral_mono
  intro t
  dsimp only
  by_cases hwin : t < adaptiveExitTime N (alternatingDomain N Q O) root (2*m+1) ω ∧
      walk N root ω t = root ∧ t ∈ Icc l r
  · rw [if_pos hwin]
    by_cases hn : completedTraversalCount N I J root ω t ≤ n
    · have hc : (completedTraversalCount N I J root ω t:ℝ) ≤ (n:ℝ) := by exact_mod_cast hn
      have hlow := (mul_le_mul_of_nonneg_left hc hh).trans hU
      simp [hn,hwin.1,hwin.2.1,hwin.2.2,hlow]
    · simp [hn]
  · simp only [if_neg hwin,zero_le]

theorem r8_nested_low_count_window (hWalk : WalkModelRegular) (γ : ℝ) (hγ : 0 < γ) (hγ1 : γ < 1) :
    ∀ᶠ N : Size in atTop, ∀ c root : Vertex N, ∀ m n : ℕ, ∀ q : ℝ,
      2*(logSize N)^(16*γ) ≤ q → q ≤ logSize N-2*(logSize N)^(16*γ) →
      root ∉ torusDisk N c (Real.exp (q+2*q^γ)) →
      Real.sqrt ((m:ℝ)*q^γ) ≤ 10*logSize N →
      (logSize N)^(5*γ) ≤ Real.sqrt ((m:ℝ)*q^γ)-Real.sqrt (((r8NestedScale γ q)^γ)*(n:ℝ)) →
      ∀ l r : ℝ,
      let Q := torusDisk N c (Real.exp (q+q^γ))
      let O := torusDisk N c (Real.exp (q+2*q^γ))
      let I := torusDisk N c (Real.exp (r8NestedScale γ q+(r8NestedScale γ q)^γ))
      let J := torusDisk N c (Real.exp (r8NestedScale γ q+2*(r8NestedScale γ q)^γ))
      let d := (m:ℝ)*Real.exp (2*logSize N-(logSize N)^(16*γ))
      physicalCountWindow N Q O root m (fun z => if completedTraversalCount N I J root z.1 z.2 ≤ n then 1 else 0) l r ≤
        2*ENNReal.ofReal (Real.exp (-((Real.sqrt ((m:ℝ)*q^γ)-Real.sqrt (((r8NestedScale γ q)^γ)*(n:ℝ)))^2/(24*q^γ))))*
          physicalCountWindow N Q O root m (fun _ => 1) (l-d) (r+d) +
        ENNReal.ofReal (r-l)*ENNReal.ofReal (Real.exp (-Real.exp ((logSize N)^(16*γ)/2))) := by
  filter_upwards [r8_nested_physical_exterior_gaussian hWalk γ hγ hγ1,r8_nested_coarse_range γ hγ hγ1]
    with N hwin hgeom
  intro c root m n q hq hqL hr hvL hgap l r
  have hs := hgeom q hq hqL
  have hQ0 := Real.rpow_nonneg (logSize_pos N).le (16*γ)
  have hqlo : (logSize N)^(16*γ) ≤ q := by linarith
  have hqhi : q ≤ logSize N-(logSize N)^(16*γ) := by linarith
  have hq0 := hQ0.trans hqlo
  have hIO := torusDisk_subset N c (Real.exp (q+q^γ)) (Real.exp (q+2*q^γ))
    (Real.exp_le_exp.mpr (by linarith [Real.rpow_nonneg hq0 γ]))
  have hh := Real.rpow_nonneg (hQ0.trans hs.1) γ
  apply physicalCountWindow_of_word_bound N _ _ hIO (torusDisk_nonempty N c _ (Real.exp_pos _)) root hr m
  intro w hw
  have hb := hwin c root m w q hqlo hqhi hr hw (fun _ => 1) measurable_const (fun _ _ => le_rfl)
    (Real.sqrt (((r8NestedScale γ q)^γ)*(n:ℝ))) l r (Real.sqrt_nonneg _) hvL hgap
  have hl := physicalWordWindow_low_inner_le_nested N
    (torusDisk N c (Real.exp (q+q^γ))) (torusDisk N c (Real.exp (q+2*q^γ)))
    (torusDisk N c (Real.exp (r8NestedScale γ q+(r8NestedScale γ q)^γ)))
    (torusDisk N c (Real.exp (r8NestedScale γ q+2*(r8NestedScale γ q)^γ))) root m n w ((r8NestedScale γ q)^γ)
    ((Real.sqrt (((r8NestedScale γ q)^γ)*(n:ℝ)))^2) l r hh (by rw [Real.sq_sqrt (by positivity)])
  dsimp only at hb
  rw [← physicalWordWindow_one_eq_exterior] at hb
  exact hl.trans hb


end TorusCoverTime.Blocks.B
