import Solutions.Blocks.B.DirichletResidualFamilyConditioning

/-! The actual finite Dirichlet field conditioned at one coordinate, realized
by its Gaussian regression on the original Fourier sample space. -/

noncomputable section
open MeasureTheory ProbabilityTheory
open scoped BigOperators
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

def dirichletRootProfileLS (N : Size) (root : Vertex N) (E : Finset (Vertex N))
    (x z : Vertex N) : ℝ := dirichletKernelLS N root E z x/dirichletClockLS N root E x

def dirichletConditionedField (N : Size) (root : Vertex N) (E : Finset (Vertex N))
    (x : Vertex N) (t : ℝ) (ξ : FiniteFieldSample N) (z : Vertex N) : ℝ :=
  dirichletFieldLS N root E ξ z-dirichletRootProfileLS N root E x z*dirichletFieldLS N root E ξ x+
    dirichletRootProfileLS N root E x z*t

theorem dirichletConditionedField_reconstruct (N : Size) (root : Vertex N) (E : Finset (Vertex N))
    (x z : Vertex N) (ξ : FiniteFieldSample N) :
    dirichletConditionedField N root E x (dirichletFieldLS N root E ξ x) ξ z=dirichletFieldLS N root E ξ z := by
  unfold dirichletConditionedField
  ring

theorem dirichletConditionedField_root (N : Size) (root : Vertex N) (E : Finset (Vertex N))
    (x : Vertex N) (hV : 0<dirichletClockLS N root E x) (t : ℝ) (ξ : FiniteFieldSample N) :
    dirichletConditionedField N root E x t ξ x=t := by
  have hp : dirichletRootProfileLS N root E x x=1 := div_self hV.ne'
  rw [dirichletConditionedField,hp]
  ring

@[fun_prop] theorem dirichletConditionedField_measurable (N : Size) (root : Vertex N)
    (E : Finset (Vertex N)) (x : Vertex N) (t : ℝ) : Measurable (dirichletConditionedField N root E x t) := by
  apply measurable_pi_lambda
  intro z
  unfold dirichletConditionedField
  fun_prop

theorem dirichlet_root_profile_average (N : Size) (root : Vertex N) (D E : Finset (Vertex N))
    (hDE : D⊆E) (hroot : root∉E) (x : Vertex N) (hV : 0<dirichletClockLS N root E x) :
    (∑ z, exitHarmonic N D z x*dirichletRootProfileLS N root E x z)=
      1-dirichletClockLS N root D x/dirichletClockLS N root E x := by
  have hcov : cov[fun ξ => dirichletLSHarmonicAverage N root D E ξ x,
      fun ξ => dirichletFieldLS N root E ξ x;finiteFieldLaw N]=
      dirichletClockLS N root E x-dirichletClockLS N root D x := by
    simp_rw [dirichlet_LS_harmonic_average N root D E hDE hroot]
    rw [covariance_fun_sub_left (dirichletFieldLS_memLp N root E x) (dirichletFieldLS_memLp N root D x)
      (dirichletFieldLS_memLp N root E x),dirichletFieldLS_covariance N root E hroot,
      dirichletFieldLS_covariance_nested N root D E hDE (fun hh => hroot (hDE hh))]
    rfl
  have hs : (∑ z, exitHarmonic N D z x*dirichletKernelLS N root E z x)=
      dirichletClockLS N root E x-dirichletClockLS N root D x := by
    rw [← hcov]
    unfold dirichletLSHarmonicAverage
    rw [covariance_fun_sum_left (fun z => (dirichletFieldLS_memLp N root E z).const_mul _)
      (dirichletFieldLS_memLp N root E x)]
    simp only [covariance_const_mul_left,dirichletFieldLS_covariance N root E hroot]
  unfold dirichletRootProfileLS
  simp_rw [← mul_div_assoc]
  rw [← Finset.sum_div,hs]
  field_simp

theorem dirichletConditionedField_average (N : Size) (root : Vertex N) (D E : Finset (Vertex N))
    (hDE : D⊆E) (hroot : root∉E) (x : Vertex N) (hV : 0<dirichletClockLS N root E x)
    (t : ℝ) (ξ : FiniteFieldSample N) :
    (∑ z, exitHarmonic N D z x*dirichletConditionedField N root E x t ξ z)=
      dirichletLSHarmonicAverage N root D E ξ x+
        (1-dirichletClockLS N root D x/dirichletClockLS N root E x)*(t-dirichletFieldLS N root E ξ x) := by
  unfold dirichletConditionedField
  simp_rw [mul_add,mul_sub,← mul_assoc]
  rw [Finset.sum_add_distrib,Finset.sum_sub_distrib,← Finset.sum_mul,← Finset.sum_mul,
    dirichlet_root_profile_average N root D E hDE hroot x hV]
  unfold dirichletLSHarmonicAverage
  ring

theorem dirichletConditionedField_residual (N : Size) (root : Vertex N) (D E : Finset (Vertex N))
    (hDE : D⊆E) (hroot : root∉E) (x z : Vertex N) (hV : 0<dirichletClockLS N root E x)
    (t : ℝ) (ξ : FiniteFieldSample N) :
    dirichletConditionedField N root E x t ξ z-
      (∑ y, exitHarmonic N D y x*dirichletConditionedField N root E x t ξ y)=
        dirichletResidualAtEndpoint N root D E x t ξ z := by
  rw [dirichletConditionedField_average N root D E hDE hroot x hV]
  change _=(dirichletLSResidual N root D E x z ξ-dirichletResidualSlope N root D E x z*
    dirichletFieldLS N root E ξ x)+dirichletResidualSlope N root D E x z*t
  rw [dirichletResidualSlope_eq N root D E hDE hroot]
  unfold dirichletConditionedField dirichletRootProfileLS dirichletLSResidual
  field_simp
  <;> ring

end TorusCoverTime.Blocks.B
