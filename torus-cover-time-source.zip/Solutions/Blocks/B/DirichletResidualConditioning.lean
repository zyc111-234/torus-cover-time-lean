import Solutions.Blocks.B.DirichletResidualCovariance
import Solutions.Blocks.B.WeightedGaussianResidualTail

/-! The full residual vector has a genuine finite Gaussian regression kernel.
Its independent noise and its original exit weights give a dimension-free
square tail. Spatial Green bounds are explicit hypotheses, not tail axioms. -/

noncomputable section
set_option backward.isDefEq.respectTransparency false
open MeasureTheory ProbabilityTheory Classical
open scoped BigOperators
namespace TorusCoverTime.Blocks.B

def dirichletResidualSlope (N : Size) (root : Vertex N) (D E : Finset (Vertex N))
    (x z : Vertex N) : ℝ := scalarRegressionSlope (finiteFieldLaw N)
      (fun ξ => dirichletFieldLS N root E ξ x) (dirichletLSResidual N root D E x z)

def dirichletResidualNoise (N : Size) (root : Vertex N) (D E : Finset (Vertex N))
    (x : Vertex N) (ξ : FiniteFieldSample N) (z : Vertex N) : ℝ :=
  scalarRegressionResidual (finiteFieldLaw N) (fun η => dirichletFieldLS N root E η x)
    (dirichletLSResidual N root D E x z) ξ

def dirichletResidualAtEndpoint (N : Size) (root : Vertex N) (D E : Finset (Vertex N))
    (x : Vertex N) (t : ℝ) (ξ : FiniteFieldSample N) (z : Vertex N) : ℝ :=
  dirichletResidualNoise N root D E x ξ z+dirichletResidualSlope N root D E x z*t

theorem dirichletResidualSlope_eq (N : Size) (root : Vertex N) (D E : Finset (Vertex N))
    (hDE : D⊆E) (hroot : root∉E) (x z : Vertex N) :
    dirichletResidualSlope N root D E x z =
      (dirichletKernelLS N root E z x-(dirichletClockLS N root E x-dirichletClockLS N root D x))/
        dirichletClockLS N root E x := by
  unfold dirichletResidualSlope scalarRegressionSlope
  rw [covariance_comm,dirichletLSResidual_covariance_endpoint N root D E hDE hroot,
    dirichletFieldLS_variance N root E hroot]

theorem dirichletResidualAtEndpoint_reconstruct (N : Size) (root : Vertex N) (D E : Finset (Vertex N))
    (x z : Vertex N) (ξ : FiniteFieldSample N) :
    dirichletResidualAtEndpoint N root D E x (dirichletFieldLS N root E ξ x) ξ z=
      dirichletLSResidual N root D E x z ξ := by
  unfold dirichletResidualAtEndpoint dirichletResidualNoise scalarRegressionResidual dirichletResidualSlope
  ring

theorem dirichletResidualNoise_measurable (N : Size) (root : Vertex N) (D E : Finset (Vertex N))
    (hDE : D⊆E) (hroot : root∉E) (x : Vertex N) : Measurable (dirichletResidualNoise N root D E x) := by
  apply measurable_pi_lambda
  intro z
  exact (dirichletLSResidual_measurable N root D E hDE hroot x z).sub
    (measurable_const.mul (dirichletFieldLS_measurable N root E x))

theorem dirichletResidualNoise_indep_endpoint (N : Size) (root : Vertex N) (D E : Finset (Vertex N))
    (hDE : D⊆E) (hroot : root∉E) (x : Vertex N) (hV : 0<dirichletClockLS N root E x) :
    IndepFun (dirichletResidualNoise N root D E x) (fun ξ => dirichletFieldLS N root E ξ x) (finiteFieldLaw N) := by
  let X := dirichletLSCoordinateMap N root E x
  let R := ContinuousLinearMap.pi (fun z : Vertex N =>
    dirichletLSCoordinateMap N root E z-(dirichletLSCoordinateMap N root E x-dirichletLSCoordinateMap N root D x)-
      dirichletResidualSlope N root D E x z • X)
  let S := ContinuousLinearMap.pi (fun _ : Unit => X)
  have hj : HasGaussianLaw (fun ξ => (dirichletResidualNoise N root D E x ξ,
      fun _ : Unit => dirichletFieldLS N root E ξ x)) (finiteFieldLaw N) := by
    apply ((Blocks.D.finiteFieldSample_gaussian N).map_fun (R.prod S)).congr
    exact Filter.Eventually.of_forall (fun ξ => by
      apply Prod.ext <;> funext z <;>
        simp only [R,S,X,id_eq,ContinuousLinearMap.prod_apply,ContinuousLinearMap.pi_apply,
          sub_apply,smul_apply,smul_eq_mul,dirichletLSCoordinateMap_apply,
          dirichletResidualNoise,scalarRegressionResidual,dirichletResidualSlope,
          dirichletLSResidual_eq N root D E hDE hroot])
  have hz (z : Vertex N) (_ : Unit) :
      cov[fun ξ => dirichletResidualNoise N root D E x ξ z,
        fun ξ => dirichletFieldLS N root E ξ x;finiteFieldLaw N]=0 := by
    have hv : 0<Var[fun ξ => dirichletFieldLS N root E ξ x;finiteFieldLaw N] := by
      rwa [dirichletFieldLS_variance N root E hroot]
    have hg := scalar_gaussian_regression (finiteFieldLaw N) _ _
      (dirichletLSResidual_joint_gaussian N root D E hDE hroot x z) hv
    exact hg.2.1.symm.covariance_eq_zero hg.1.snd.memLp_two hg.1.fst.memLp_two
  simpa only [Function.comp_def,id_eq] using
    (hj.indepFun_of_covariance_eval hz).comp measurable_id (measurable_pi_apply ())

theorem dirichletResidualNoise_jointLaw (N : Size) (root : Vertex N) (D E : Finset (Vertex N))
    (hDE : D⊆E) (hroot : root∉E) (x : Vertex N) (hV : 0<dirichletClockLS N root E x) :
    (finiteFieldLaw N).map (fun ξ => (dirichletFieldLS N root E ξ x,dirichletResidualNoise N root D E x ξ))=
      (gaussianReal 0 (dirichletClockLS N root E x).toNNReal).prod
        ((finiteFieldLaw N).map (dirichletResidualNoise N root D E x)) := by
  rw [(dirichletResidualNoise_indep_endpoint N root D E hDE hroot x hV).symm.map_prod_eq_prod_map_map
    (dirichletFieldLS_measurable N root E x).aemeasurable
    (dirichletResidualNoise_measurable N root D E hDE hroot x).aemeasurable,
    (dirichletFieldLS_gaussian N root E x).map_eq_gaussianReal,dirichletFieldLS_mean,
    dirichletFieldLS_variance N root E hroot]

theorem dirichletResidual_condExp_functional (N : Size) (root : Vertex N) (D E : Finset (Vertex N))
    (hDE : D⊆E) (hroot : root∉E) (x : Vertex N) (hV : 0<dirichletClockLS N root E x)
    (F : (Vertex N → ℝ) → ℝ) (hF : Measurable F) (C : ℝ) (hC : ∀ f, ‖F f‖≤C) :
    (finiteFieldLaw N)[fun ξ => F (fun z => dirichletLSResidual N root D E x z ξ) |
      MeasurableSpace.comap (fun ξ => dirichletFieldLS N root E ξ x) inferInstance] =ᵐ[finiteFieldLaw N]
        fun ξ => ∫ η, F (dirichletResidualAtEndpoint N root D E x (dirichletFieldLS N root E ξ x) η)
          ∂finiteFieldLaw N := by
  let X := fun ξ => dirichletFieldLS N root E ξ x
  let Y := dirichletResidualNoise N root D E x
  let f := fun v : ℝ × (Vertex N → ℝ) => F (fun z => v.2 z+dirichletResidualSlope N root D E x z*v.1)
  have hX : Measurable X := dirichletFieldLS_measurable N root E x
  have hY : Measurable Y := dirichletResidualNoise_measurable N root D E hDE hroot x
  have hf : Measurable f := by apply hF.comp; fun_prop
  have hh := Blocks.C.independent_condExp_bounded (finiteFieldLaw N) hX hY
    (dirichletResidualNoise_indep_endpoint N root D E hDE hroot x hV).symm hf
    (fun v => hC (fun z => v.2 z+dirichletResidualSlope N root D E x z*v.1))
  have he : (fun ξ => f (X ξ,Y ξ)) = fun ξ => F (fun z => dirichletLSResidual N root D E x z ξ) := by
    funext ξ
    apply congrArg F
    funext z
    exact dirichletResidualAtEndpoint_reconstruct N root D E x z ξ
  rw [he] at hh
  filter_upwards [hh] with ξ hξ
  rw [hξ]
  exact integral_map hY.aemeasurable
    ((hf.comp (measurable_const.prodMk measurable_id)).aestronglyMeasurable)

theorem dirichletResidual_conditioned_tail (N : Size) (root : Vertex N) (D E : Finset (Vertex N))
    (hDE : D⊆E) (hroot : root∉E) (x : Vertex N) (hV : 0<dirichletClockLS N root E x)
    (Q M t s : ℝ) (hQ : 0<Q)
    (hvar : ∀ z, exitHarmonic N D z x≠0 →
      Var[dirichletLSResidual N root D E x z;finiteFieldLaw N]≤Q)
    (hmean : ∀ z, exitHarmonic N D z x≠0 → |dirichletResidualSlope N root D E x z*t|≤M) :
    (finiteFieldLaw N).real {ξ | 8*Q*s ≤
      ∑ z, exitHarmonic N D z x*(dirichletResidualAtEndpoint N root D E x t ξ z)^2} ≤
        2*Real.exp (M^2/(4*Q)-s) := by
  have hv : 0<Var[fun ξ => dirichletFieldLS N root E ξ x;finiteFieldLaw N] := by
    rwa [dirichletFieldLS_variance N root E hroot]
  let Z := fun z ξ => dirichletResidualNoise N root D E x ξ z
  have hZ (z : Vertex N) : HasGaussianLaw (Z z) (finiteFieldLaw N) :=
    (scalar_gaussian_regression (finiteFieldLaw N) _ _
      (dirichletLSResidual_joint_gaussian N root D E hDE hroot x z) hv).1.snd
  have hz0 (z : Vertex N) : (∫ ξ, Z z ξ ∂finiteFieldLaw N)=0 :=
    scalarRegressionResidual_mean (finiteFieldLaw N) _ _
      (dirichletLSResidual_joint_gaussian N root D E hDE hroot x z)
      (dirichletFieldLS_mean N root E x) (dirichletLSResidual_mean N root D E hDE hroot x z)
  have hzv (z : Vertex N) (hz : exitHarmonic N D z x≠0) : Var[Z z;finiteFieldLaw N]≤Q :=
    (scalar_regression_variance_bounds (finiteFieldLaw N) _ _
      (dirichletLSResidual_joint_gaussian N root D E hDE hroot x z) hv).1.trans (hvar z hz)
  exact weighted_gaussian_residual_tail (fun z => exitHarmonic N D z x)
    (fun z => dirichletResidualSlope N root D E x z*t) Z (fun z => exitHarmonic_nonneg N D z x)
    (exitHarmonic_sum_one N D (Blocks.C.C4.domain_proper_of_root_outside N root D (fun hh => hroot (hDE hh))) x)
    (fun z => (measurable_pi_apply z).comp (dirichletResidualNoise_measurable N root D E hDE hroot x))
    hZ hz0 Q M s hQ hzv hmean

end TorusCoverTime.Blocks.B
