import Solutions.Blocks.B.ExitTotalLaplace
import Solutions.Blocks.B.DiskGreenSquare

/-! B-T3 / bridge (B.13d): exact specified-exit transform of the full
single-site physical local time, including every return before exit. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

theorem disk_exitLaplace_single_resolvent (N : Size) (c : Vertex N) (R : ℝ)
    (hR : 0 ≤ R) (hsmall : 2*(R+1) < N.val) (a b x : Vertex N)
    (u : ℝ) (hu : 0 ≤ u) :
    exitLaplace N (torusDisk N c R) b (fun z => if z=x then u else 0) a =
      exitHarmonic N (torusDisk N c R) b a -
        u * diskGreen N c R a x * exitHarmonic N (torusDisk N c R) b x /
          (1+u*diskGreen N c R x x) := by
  let U : Vertex N → ℝ := fun z => if z=x then u else 0
  have hU : ∀ z, 0 ≤ U z := by intro z; dsimp only [U]; split_ifs <;> positivity
  have h (y : Vertex N) := disk_exitLaplace_resolvent N c R hR hsmall b U hU y
  simp only [U, ite_mul, zero_mul, Finset.sum_ite_eq', Finset.mem_univ, if_true] at h
  have hd : 0 < 1+u*diskGreen N c R x x := by
    have := diskGreen_nonneg N c R hR hsmall x x
    positivity
  have hx : exitLaplace N (torusDisk N c R) b U x =
      exitHarmonic N (torusDisk N c R) b x/(1+u*diskGreen N c R x x) := by
    apply (eq_div_iff hd.ne').mpr
    have hh := h x
    change exitLaplace N (torusDisk N c R) b U x = _ at hh
    nlinarith
  change exitLaplace N (torusDisk N c R) b U a = _
  calc
    _ = exitHarmonic N (torusDisk N c R) b a -
        u * exitLaplace N (torusDisk N c R) b U x * diskGreen N c R a x := h a
    _ = _ := by rw [hx]; ring

theorem disk_conditioned_localTime_laplace (hWalk : WalkModelRegular)
    (N : Size) (c : Vertex N) (R : ℝ) (hR : 0 ≤ R) (hsmall : 2*(R+1) < N.val)
    (a b x : Vertex N) (ha : 0 < exitHarmonic N (torusDisk N c R) b a)
    (u : ℝ) (hu : 0 ≤ u) :
    (∫ ω, Real.exp (-u * localTime N a ω (finiteExitDuration N (torusDisk N c R) a ω) x)
      ∂exactExitLaw N (torusDisk N c R) a b) =
      1 - (diskGreen N c R a x * exitHarmonic N (torusDisk N c R) b x /
        exitHarmonic N (torusDisk N c R) b a) * u / (1+u*diskGreen N c R x x) := by
  have h := conditioned_exitOccupation_laplace hWalk N (torusDisk N c R) a b
    (fun z => if z=x then u else 0)
  simp only [exitOccupation, ite_mul, zero_mul, Finset.sum_ite_eq',
    Finset.mem_univ, if_true, neg_mul] at h
  simp only [neg_mul]
  rw [h, disk_exitLaplace_single_resolvent N c R hR hsmall a b x u hu, sub_div,
    div_self ha.ne']
  ring

theorem disk_conditioned_normalized_localTime_laplace (hWalk : WalkModelRegular)
    (N : Size) (c : Vertex N) (R : ℝ) (hR : 0 ≤ R) (hsmall : 2*(R+1) < N.val)
    (a b x : Vertex N) (hx : x ∈ torusDisk N c R)
    (ha : 0 < exitHarmonic N (torusDisk N c R) b a)
    (θ : ℝ) (hθ : 0 ≤ θ) :
    (∫ ω, Real.exp (-θ * (localTime N a ω
      (finiteExitDuration N (torusDisk N c R) a ω) x / g))
      ∂exactExitLaw N (torusDisk N c R) a b) =
      1 - (diskGreen N c R a x / diskGreen N c R x x *
        (exitHarmonic N (torusDisk N c R) b x / exitHarmonic N (torusDisk N c R) b a)) *
        θ / (g/diskGreen N c R x x+θ) := by
  have hg : 0 < g := by unfold g; positivity
  have hG : 0 < diskGreen N c R x x :=
    zero_lt_one.trans_le (diskGreen_diagonal N c R hR hsmall x hx)
  have hden : 0 < g/diskGreen N c R x x+θ := add_pos_of_pos_of_nonneg (div_pos hg hG) hθ
  have hden' : 0 < 1+θ/g*diskGreen N c R x x := by positivity
  have he : (fun ω => Real.exp (-θ * (localTime N a ω
      (finiteExitDuration N (torusDisk N c R) a ω) x / g))) =
      (fun ω => Real.exp (-(θ/g) * localTime N a ω
        (finiteExitDuration N (torusDisk N c R) a ω) x)) := by
    funext ω
    congr 1
    ring
  rw [he, disk_conditioned_localTime_laplace hWalk N c R hR hsmall a b x ha (θ/g)
    (div_nonneg hθ hg.le)]
  field_simp
  <;> ring

end TorusCoverTime.Blocks.B
