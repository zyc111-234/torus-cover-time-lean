import Solutions.Blocks.B.ExitChainTailLaw
import Solutions.Blocks.B.R7SquareRootConcentration

/-! Transfer of the independent exit-block laws to occupation increments of a
single compatible path. Selected blocks may be separated by arbitrary proper
domains, as in the alternating outward/return decomposition. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

instance exactExitLaw_finite (N : Size) (D : Finset (Vertex N)) (a b : Vertex N) :
    IsFiniteMeasure (exactExitLaw N D a b) := by
  unfold exactExitLaw
  infer_instance

instance exactExitRecordLaw_finite (N : Size) (D : Finset (Vertex N)) (a b : Vertex N) :
    IsFiniteMeasure (exactExitRecordLaw N D a b) := by
  unfold exactExitRecordLaw
  infer_instance

theorem pi_select_law {ι κ Z : Type*} [Fintype ι] [Fintype κ] [MeasurableSpace Z]
    (μ : ι → Measure Z) [∀ i, IsProbabilityMeasure (μ i)] (s : κ → ι) (hs : Function.Injective s) :
    (Measure.pi μ).map (fun p i => p (s i)) = Measure.pi (fun i => μ (s i)) := by
  rw [← Measure.infinitePi_eq_pi, ← Measure.infinitePi_eq_pi]
  exact Measure.map_infinitePi_infinitePi_of_inj (P := μ) hs

theorem exitChain_selected_record_law (N : Size) (D : ℕ → Finset (Vertex N))
    (hD : ∀ k, ∃ b : Vertex N, b ∉ D k) (a b : ℕ → Vertex N) (n m : ℕ)
    (hp : ∀ j : Fin n, walkLaw (exitsThrough N (D j.val) (a j.val) (b j.val)) ≠ 0)
    (s : Fin m → Fin n) (hs : Function.Injective s) :
    (walkLaw[|exitChainEndpoints N D a b n]).map
      (fun ω => fun i : Fin m => exitChainRecord N D a (s i).val ω) =
      Measure.pi (fun i : Fin m => exactExitRecordLaw N (D (s i).val) (a (s i).val) (b (s i).val)) := by
  have (j : Fin n) : IsProbabilityMeasure (exactExitLaw N (D j.val) (a j.val) (b j.val)) :=
    cond_isProbabilityMeasure (hp j)
  have (j : Fin n) : IsProbabilityMeasure (exactExitRecordLaw N (D j.val) (a j.val) (b j.val)) :=
    Measure.isProbabilityMeasure_map (finiteExitRecord_measurable N (D j.val) (a j.val)).aemeasurable
  have hm : Measurable (fun p : Fin n → ℕ × WalkSample => fun i : Fin m => p (s i)) := by fun_prop
  rw [show (fun ω => fun i : Fin m => exitChainRecord N D a (s i).val ω) =
    (fun p : Fin n → ℕ × WalkSample => fun i : Fin m => p (s i)) ∘
      (fun ω => fun j : Fin n => exitChainRecord N D a j.val ω) from rfl,
    ← Measure.map_map hm (measurable_pi_lambda _ fun j => exitChainRecord_measurable N D hD a j.val),
    exitChainRecord_conditioned_law N D hD a b n, pi_select_law _ s hs]

def weightedExitOccupation (N : Size) (D : Finset (Vertex N)) (a : Vertex N)
    (U : Vertex N → ℝ) (ω : WalkSample) : ℝ :=
  ∑ x, U x*localTime N a ω (finiteExitDuration N D a ω) x

theorem weightedExitOccupation_measurable (N : Size) (D : Finset (Vertex N)) (a : Vertex N)
    (U : Vertex N → ℝ) : Measurable (weightedExitOccupation N D a U) :=
  Finset.measurable_sum _ fun x _ => measurable_const.mul
    (localTime_measurable_random_time N a x _ (measurable_finiteExitDuration N D a))

theorem exactExitRecord_cost_law (N : Size) (D : Finset (Vertex N)) (a b : Vertex N)
    (U : Vertex N → ℝ) :
    (exactExitRecordLaw N D a b).map (excursionRecordCost N a U) =
      (exactExitLaw N D a b).map (weightedExitOccupation N D a U) := by
  rw [exactExitRecordLaw, Measure.map_map (excursionRecordCost_measurable N a U)
    (finiteExitRecord_measurable N D a)]
  apply Measure.map_congr
  apply (cond_absolutelyContinuous (μ := walkLaw) (s := exitsThrough N D a b)).ae_le
  filter_upwards [finiteExit_weighted_occupation_eq_record N D a U] with ω hω
  exact hω.symm

def exitChainSelectedCost (N : Size) (D : ℕ → Finset (Vertex N)) (a : ℕ → Vertex N)
    (U : Vertex N → ℝ) (n m : ℕ) (s : Fin m → Fin n) (ω : WalkSample) : ℝ :=
  ∑ i, excursionRecordCost N (a (s i).val) U (exitChainRecord N D a (s i).val ω)

def exitChainSelectedOccupation (N : Size) (D : ℕ → Finset (Vertex N)) (a : ℕ → Vertex N)
    (U : Vertex N → ℝ) (n m : ℕ) (s : Fin m → Fin n) (ω : WalkSample) : ℝ :=
  ∑ i, ∑ x, U x*(localTime N (a 0) ω (exitChainTime N D a ((s i).val+1) ω) x -
    localTime N (a 0) ω (exitChainTime N D a (s i).val ω) x)

theorem exitChainSelectedOccupation_measurable (N : Size) (D : ℕ → Finset (Vertex N))
    (hD : ∀ k, ∃ b : Vertex N, b ∉ D k) (a : ℕ → Vertex N)
    (U : Vertex N → ℝ) (n m : ℕ) (s : Fin m → Fin n) :
    Measurable (exitChainSelectedOccupation N D a U n m s) := by
  apply Finset.measurable_sum
  intro i _
  apply Finset.measurable_sum
  intro x _
  exact measurable_const.mul
    ((localTime_measurable_random_time N (a 0) x _ (exitChainTime_measurable N D hD a _)).sub
      (localTime_measurable_random_time N (a 0) x _ (exitChainTime_measurable N D hD a _)))

theorem exitChainSelectedOccupation_eq_cost_ae (N : Size) (D : ℕ → Finset (Vertex N))
    (hD : ∀ k, ∃ b : Vertex N, b ∉ D k) (a b : ℕ → Vertex N) (n m : ℕ)
    (hab : ∀ k < n, b k = a (k+1)) (U : Vertex N → ℝ) (s : Fin m → Fin n) :
    exitChainSelectedOccupation N D a U n m s =ᵐ[walkLaw[|exitChainEndpoints N D a b n]]
      exitChainSelectedCost N D a U n m s := by
  have hr := (cond_absolutelyContinuous (μ := walkLaw) (s := exitChainEndpoints N D a b n)).ae_le
    A.holding_positive_and_nonexplosive
  filter_upwards [hr, ae_cond_mem (μ := walkLaw) (exitChainEndpoints_measurable N D hD a b n)] with ω hreg hω
  apply Finset.sum_congr rfl
  intro i _
  exact exitChain_occupation_increment N D a b n hab ω hω hreg.1 hreg.2 U (s i).val (s i).isLt

theorem exitChain_selected_cost_vector_law (N : Size) (D : ℕ → Finset (Vertex N))
    (hD : ∀ k, ∃ b : Vertex N, b ∉ D k) (a b : ℕ → Vertex N) (n m : ℕ)
    (hp : ∀ j : Fin n, walkLaw (exitsThrough N (D j.val) (a j.val) (b j.val)) ≠ 0)
    (s : Fin m → Fin n) (hs : Function.Injective s) (U : Vertex N → ℝ) :
    (walkLaw[|exitChainEndpoints N D a b n]).map
      (fun ω => fun i : Fin m => excursionRecordCost N (a (s i).val) U (exitChainRecord N D a (s i).val ω)) =
      Measure.pi (fun i : Fin m => (exactExitLaw N (D (s i).val) (a (s i).val) (b (s i).val)).map
        (weightedExitOccupation N (D (s i).val) (a (s i).val) U)) := by
  have hm : Measurable (fun p : Fin m → ℕ × WalkSample => fun i : Fin m =>
      excursionRecordCost N (a (s i).val) U (p i)) :=
    measurable_pi_lambda _ fun i => (excursionRecordCost_measurable N (a (s i).val) U).comp (measurable_pi_apply i)
  change (walkLaw[|exitChainEndpoints N D a b n]).map
    ((fun p : Fin m → ℕ × WalkSample => fun i : Fin m => excursionRecordCost N (a (s i).val) U (p i)) ∘
      (fun ω => fun i : Fin m => exitChainRecord N D a (s i).val ω)) = _
  rw [← Measure.map_map hm (measurable_pi_lambda _ fun i => exitChainRecord_measurable N D hD a (s i).val),
    exitChain_selected_record_law N D hD a b n m hp s hs,
    Measure.pi_map_pi (fun i : Fin m => (excursionRecordCost_measurable N (a (s i).val) U).aemeasurable)]
  simp_rw [exactExitRecord_cost_law]

theorem exitChain_selected_occupation_law (N : Size) (D : ℕ → Finset (Vertex N))
    (hD : ∀ k, ∃ b : Vertex N, b ∉ D k) (a b : ℕ → Vertex N) (n m : ℕ)
    (hp : ∀ j : Fin n, walkLaw (exitsThrough N (D j.val) (a j.val) (b j.val)) ≠ 0)
    (hab : ∀ k < n, b k = a (k+1)) (s : Fin m → Fin n) (hs : Function.Injective s)
    (U : Vertex N → ℝ) (D₀ : Finset (Vertex N)) (hDs : ∀ i, D (s i).val = D₀) :
    (walkLaw[|exitChainEndpoints N D a b n]).map (exitChainSelectedOccupation N D a U n m s) =
      (exactExitProductLaw N D₀ m (fun i => a (s i).val) (fun i => b (s i).val)).map
        (fun ω => ∑ i, weightedExitOccupation N D₀ (a (s i).val) U (ω i)) := by
  rw [Measure.map_congr (exitChainSelectedOccupation_eq_cost_ae N D hD a b n m hab U s)]
  have hsum : Measurable (fun p : Fin m → ℝ => ∑ i, p i) := by fun_prop
  have hm : Measurable (fun ω => fun i : Fin m =>
      excursionRecordCost N (a (s i).val) U (exitChainRecord N D a (s i).val ω)) :=
    measurable_pi_lambda _ fun i => (excursionRecordCost_measurable N (a (s i).val) U).comp
      (exitChainRecord_measurable N D hD a (s i).val)
  change (walkLaw[|exitChainEndpoints N D a b n]).map
    ((fun p : Fin m → ℝ => ∑ i, p i) ∘ (fun ω => fun i : Fin m =>
      excursionRecordCost N (a (s i).val) U (exitChainRecord N D a (s i).val ω))) = _
  rw [← Measure.map_map hsum hm, exitChain_selected_cost_vector_law N D hD a b n m hp s hs U]
  simp_rw [hDs]
  have hm' : Measurable (fun ω : Fin m → WalkSample => fun i : Fin m =>
      weightedExitOccupation N D₀ (a (s i).val) U (ω i)) :=
    measurable_pi_lambda _ fun i => (weightedExitOccupation_measurable N D₀ (a (s i).val) U).comp
      (measurable_pi_apply i)
  change _ = (Measure.pi (fun i : Fin m => exactExitLaw N D₀ (a (s i).val) (b (s i).val))).map
    ((fun p : Fin m → ℝ => ∑ i, p i) ∘ (fun ω : Fin m → WalkSample => fun i : Fin m =>
      weightedExitOccupation N D₀ (a (s i).val) U (ω i)))
  rw [← Measure.map_map hsum hm', Measure.pi_map_pi
    (fun i : Fin m => (weightedExitOccupation_measurable N D₀ (a (s i).val) U).aemeasurable)]

end TorusCoverTime.Blocks.B
