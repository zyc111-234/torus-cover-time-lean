import Solutions.Blocks.B.ComplexCenteredSums

/-! Absolute and oscillatory bounds for one-dimensional rows of the quadratic Green symbol. -/

noncomputable section
open MeasureTheory
open scoped BigOperators
namespace TorusCoverTime.Blocks.B

def quadraticFourierRow (N : Size) (z : ZMod N.val) (b : ℝ) : ℂ :=
  ∑ a : ZMod N.val, ((1 / (b ^ 2 + coordinateDistance a 0 ^ 2) : ℝ) : ℂ) *
    coordinateCharacter N (a * z)

lemma reciprocal_row_antitone (b : ℝ) (hb : 0 < b) :
    Antitone (fun j : ℕ => 1 / (b ^ 2 + (j : ℝ) ^ 2)) := by
  intro i j hij
  exact reciprocal_quadratic_antitone b hb
    (by simpa only [Set.mem_Ici] using (Nat.cast_nonneg (α := ℝ) i))
    (by simpa only [Set.mem_Ici] using (Nat.cast_nonneg (α := ℝ) j))
    (by exact_mod_cast hij)

lemma reciprocal_row_sum_bound (b : ℝ) (hb : 0 < b) (n : ℕ) :
    (∑ j ∈ Finset.range n, 1 / (b ^ 2 + ((j : ℝ) + 1) ^ 2)) ≤ Real.pi / (2 * b) := by
  have hanti : AntitoneOn (fun x : ℝ => 1 / (b ^ 2 + x ^ 2)) (Set.Icc 0 (0 + (n : ℝ))) :=
    (reciprocal_quadratic_antitone b hb).mono (fun _ hx => hx.1)
  have h := hanti.sum_le_integral (a := n) (x₀ := 0)
  simp only [zero_add, Nat.cast_add, Nat.cast_one] at h
  apply h.trans
  simp only [one_div, integral_inv_sq_add_sq hb.ne', zero_div, Real.arctan_zero, sub_zero]
  have harc := mul_le_mul_of_nonneg_left (Real.arctan_lt_pi_div_two ((n : ℝ) / b)).le
    (inv_nonneg.mpr hb.le)
  convert harc using 1
  ring

lemma quadraticFourierRow_absolute (N : Size) (z : ZMod N.val) (b : ℝ) (hb : 1 ≤ b) :
    ‖quadraticFourierRow N z b‖ ≤ (1 + Real.pi) / b := by
  have hb0 : 0 < b := lt_of_lt_of_le zero_lt_one hb
  have hnorm : ‖quadraticFourierRow N z b‖ ≤
      ∑ a : ZMod N.val, 1 / (b ^ 2 + coordinateDistance a 0 ^ 2) := by
    apply (norm_sum_le _ _).trans
    apply Finset.sum_le_sum
    intro a _
    rw [norm_mul, Complex.norm_real, Real.norm_eq_abs,
      abs_of_nonneg (by positivity), coordinateCharacter_norm, mul_one]
  have hfold := sum_centered_coordinate N (fun x => 1 / (b ^ 2 + x ^ 2))
  simp only [zero_pow (by decide : 2 ≠ 0), add_zero] at hfold
  rw [hfold] at hnorm
  have hR := reciprocal_row_sum_bound b hb0 (N.val / 2)
  have hM := reciprocal_row_sum_bound b hb0 ((N.val - 1) / 2)
  have hbInv : 1 / b ^ 2 ≤ 1 / b := by
    apply one_div_le_one_div_of_le hb0
    nlinarith
  have hid : (1 + Real.pi) / b = 1 / b + 2 * (Real.pi / (2 * b)) := by
    simp only [div_eq_mul_inv, mul_inv_rev]
    ring
  rw [hid]
  linarith

lemma quadraticFourierRow_centered (N : Size) (z : ZMod N.val) (b : ℝ) :
    quadraticFourierRow N z b = ((1 / b ^ 2 : ℝ) : ℂ) +
      (∑ j ∈ Finset.range (N.val / 2), ((1 / (b ^ 2 + ((j : ℝ) + 1) ^ 2) : ℝ) : ℂ) *
        coordinateCharacter N z ^ (j + 1)) +
      (∑ j ∈ Finset.range ((N.val - 1) / 2), ((1 / (b ^ 2 + ((j : ℝ) + 1) ^ 2) : ℝ) : ℂ) *
        (coordinateCharacter N z)⁻¹ ^ (j + 1)) := by
  unfold quadraticFourierRow
  rw [sum_zmod_centered_complex]
  have hd0 : coordinateDistance (0 : ZMod N.val) 0 = 0 := by simp [coordinateDistance]
  simp only [hd0, zero_pow (by decide : 2 ≠ 0), add_zero, zero_mul, coordinateCharacter_zero, mul_one]
  congr 1
  · congr 1
    apply Finset.sum_congr rfl
    intro j hj
    have hj' : j + 1 ≤ N.val / 2 := by have := Finset.mem_range.mp hj; omega
    rw [coordinateDistance_natCast_half N _ hj', coordinateCharacter_nat_mul]
    simp only [Nat.cast_add, Nat.cast_one]
  · apply Finset.sum_congr rfl
    intro j hj
    have hj' : j + 1 ≤ N.val / 2 := by have := Finset.mem_range.mp hj; omega
    rw [coordinateDistance_neg_zero, coordinateDistance_natCast_half N _ hj', neg_mul,
      coordinateCharacter_neg, coordinateCharacter_nat_mul, inv_pow]
    simp only [Nat.cast_add, Nat.cast_one]

lemma quadraticFourierRow_oscillatory_raw (N : Size) (z : ZMod N.val) (hz : z ≠ 0)
    (b : ℝ) (hb : 0 < b) :
    ‖quadraticFourierRow N z b‖ ≤ 1 / b ^ 2 +
      4 * (1 / b ^ 2) / ‖coordinateCharacter N z - 1‖ := by
  let f := fun j : ℕ => 1 / (b ^ 2 + (j : ℝ) ^ 2)
  have hf (j) : 0 ≤ f j := by dsimp [f]; positivity
  have hanti : Antitone f := reciprocal_row_antitone b hb
  have hw := coordinateCharacter_norm N z
  have hw1 := coordinateCharacter_ne_one N hz
  have hR := norm_antitone_geometric_shift f (coordinateCharacter N z) hf hanti hw hw1 (N.val / 2)
  have hM := norm_antitone_geometric_shift f (coordinateCharacter N z)⁻¹ hf hanti
    (by rw [norm_inv, hw, inv_one]) (by simpa using hw1) ((N.val - 1) / 2)
  simp only [f, Nat.cast_add, Nat.cast_one, Nat.cast_zero, zero_pow (by decide : 2 ≠ 0),
    add_zero, coordinateCharacter_inv_gap] at hR hM
  rw [quadraticFourierRow_centered]
  apply (norm_add_le _ _).trans
  apply le_trans (add_le_add (norm_add_le _ _) le_rfl)
  rw [Complex.norm_real, Real.norm_eq_abs, abs_of_pos (by positivity : 0 < 1 / b ^ 2)]
  have hid : 4 * (1 / b ^ 2) / ‖coordinateCharacter N z - 1‖ =
      2 * (2 * (1 / b ^ 2) / ‖coordinateCharacter N z - 1‖) := by ring
  rw [hid]
  linarith

lemma quadraticFourierRow_oscillatory (N : Size) (z : ZMod N.val) (hz : z ≠ 0)
    (b : ℝ) (hb : 0 < b) :
    ‖quadraticFourierRow N z b‖ ≤
      2 * (N.val : ℝ) / (coordinateDistance z 0 * b ^ 2) := by
  have hd : 0 < coordinateDistance z 0 :=
    lt_of_lt_of_le zero_lt_one (coordinateDistance_nonzero_ge_one N z hz)
  have hn : 0 < (N.val : ℝ) := lt_trans zero_lt_one (size_real_gt_one N)
  have hB : 0 < ‖coordinateCharacter N z - 1‖ :=
    norm_pos_iff.mpr (sub_ne_zero.mpr (coordinateCharacter_ne_one N hz))
  have hgap := (div_le_iff₀ hn).mp (coordinateCharacter_distance_lower N z)
  have hr : 1 ≤ (N.val : ℝ) / coordinateDistance z 0 := by
    apply (le_div_iff₀ hd).mpr
    have := (coordinateDistance_zero_bounds N z).2
    linarith
  have hrec : 4 / ‖coordinateCharacter N z - 1‖ ≤ (N.val : ℝ) / coordinateDistance z 0 := by
    apply (div_le_div_iff₀ hB hd).mpr
    nlinarith [hgap]
  have hf0 : 0 ≤ 1 / b ^ 2 := by positivity
  have hhead := mul_le_mul_of_nonneg_right hr hf0
  have htail := mul_le_mul_of_nonneg_right hrec hf0
  have hraw := quadraticFourierRow_oscillatory_raw N z hz b hb
  calc
    _ ≤ 1 / b ^ 2 + 4 * (1 / b ^ 2) / ‖coordinateCharacter N z - 1‖ := hraw
    _ ≤ 2 * ((N.val : ℝ) / coordinateDistance z 0) * (1 / b ^ 2) := by
      simp only [one_mul] at hhead
      have hid : 4 * (1 / b ^ 2) / ‖coordinateCharacter N z - 1‖ =
          (4 / ‖coordinateCharacter N z - 1‖) * (1 / b ^ 2) := by ring
      rw [hid]
      linarith
    _ = _ := by simp only [div_eq_mul_inv, mul_inv_rev]; ring

lemma quadraticFourierRow_zero (N : Size) (z : ZMod N.val) :
    ‖quadraticFourierRow N z 0‖ ≤ 4 := by
  calc
    _ ≤ ∑ a : ZMod N.val, 1 / coordinateDistance a 0 ^ 2 := by
      apply (norm_sum_le _ _).trans
      apply Finset.sum_le_sum
      intro a _
      simp only [zero_pow (by decide : 2 ≠ 0), zero_add, norm_mul, Complex.norm_real,
        Real.norm_eq_abs, abs_of_nonneg (by positivity : 0 ≤ 1 / coordinateDistance a 0 ^ 2),
        coordinateCharacter_norm, mul_one]
      exact le_rfl
    _ ≤ _ := sum_coordinate_inverse_squares_le_four N

end TorusCoverTime.Blocks.B
