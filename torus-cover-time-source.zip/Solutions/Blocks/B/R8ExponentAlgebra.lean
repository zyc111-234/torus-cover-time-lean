import Solutions.Blocks.B.R8SoftExponentCoarse
import Solutions.Blocks.B.R8ExactCountMarginal

/-! Exact product exponent and error accounting for two resamplings.
Additive iteration and duration errors are never silently multiplied away. -/
noncomputable section
open Filter
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

def r8CombinedExponent (L γ K q l s s' : ℝ) : ℝ :=
  -2*L+2*(q-l)+2*Real.sqrt 2*(s-s')+8*L^(2*γ)+K*L^γ

theorem r8_soft_marginal_product (L γ K C q l s s' : ℝ) :
    Real.exp (-2*l-2*Real.sqrt 2*s'+K*L^γ)*
      (C*Real.sqrt L*Real.exp (-2*(L-q)+2*Real.sqrt 2*s+8*L^(2*γ))) =
    C*Real.sqrt L*Real.exp (r8CombinedExponent L γ K q l s s') := by
  calc
    _ = C*Real.sqrt L*(Real.exp (-2*l-2*Real.sqrt 2*s'+K*L^γ)*
        Real.exp (-2*(L-q)+2*Real.sqrt 2*s+8*L^(2*γ))) := by ring
    _ = _ := by
      rw [← Real.exp_add]
      congr 2
      unfold r8CombinedExponent
      ring

theorem r8_probability_times_error (p A ε : ℝ≥0∞) (hp : p ≤ 1) :
    p*(A+ε) ≤ p*A+ε := by
  rw [mul_add]
  exact add_le_add le_rfl ((mul_le_mul' hp le_rfl).trans_eq (one_mul ε))

theorem r8_two_resampling_budget (p ρ A ε₁ ε₂ : ℝ≥0∞) (hp : p ≤ 1) :
    2*p*(2*ρ*A+ε₂)+ε₁ ≤ 4*p*ρ*A+2*ε₂+ε₁ := by
  have he : (2*p)*ε₂ ≤ (2*1)*ε₂ := mul_le_mul' (mul_le_mul' le_rfl hp) (le_refl ε₂)
  simp only [mul_one] at he
  calc
    _ = 4*p*ρ*A+(2*p)*ε₂+ε₁ := by ring
    _ ≤ _ := add_le_add (add_le_add le_rfl he) le_rfl

theorem r8_three_case_partition (δ B : ℝ) :
    |δ| ≤ B ∨ B < δ ∨ δ < -B := by
  by_cases h : |δ| ≤ B
  · exact Or.inl h
  · by_cases hδ : B < δ
    · exact Or.inr (Or.inl hδ)
    · apply Or.inr; apply Or.inr
      by_contra hn
      exact h (abs_le.mpr ⟨by linarith,le_of_not_gt hδ⟩)

end TorusCoverTime.Blocks.B
