import Solutions.Blocks.B.ExactExitSoftness

/-! R6.6 with a scale-uniform avoidance lower bound and the exact-endpoint duration
tail. The inputs are explicit actual probabilities; their disk estimates are not assumed proved. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Classical
open scoped ENNReal Topology BigOperators
namespace TorusCoverTime.Blocks.B

lemma exitBlockSoftness_probability_of_avoidance (hWalk : WalkModelRegular)
    (N : Size) (D K : Finset (Vertex N)) (m : ℕ) (a b : Fin m → Vertex N)
    (hexit : ∀ i, walkLaw (exitsThrough N D (a i) (b i)) ≠ 0)
    (hK : K.Nonempty) (u : ℝ) (hu : 0 ≤ u) (c : ℝ≥0∞)
    (havoid : ∀ i, c ≤ exactExitLaw N D (a i) (b i) (exitsThroughAvoiding N D K (a i) (b i))) :
    c ^ m ≤ exactExitProductLaw N D m a b (exitBlockSoftness N D K m a u) := by
  have (i : Fin m) : IsProbabilityMeasure (exactExitLaw N D (a i) (b i)) :=
    cond_isProbabilityMeasure (hexit i)
  have hprod : c ^ m ≤ exactExitProductLaw N D m a b (allExitBlocksAvoid N D K m a b) := by
    rw [exactExitProductLaw, allExitBlocksAvoid, Measure.pi_pi]
    simpa using Finset.prod_le_prod' (s := (Finset.univ : Finset (Fin m))) (fun i _ => havoid i)
  exact hprod.trans (measure_mono_ae
    (allExitBlocksAvoid_implies_softness_ae hWalk N D K m a b hK u hu))

lemma exactExit_duration_union_bound (N : Size) (D : Finset (Vertex N))
    (m : ℕ) (a b : Fin m → Vertex N)
    (hexit : ∀ i, walkLaw (exitsThrough N D (a i) (b i)) ≠ 0)
    (d : ℝ) (ε : ℝ≥0∞)
    (htail : ∀ i, exactExitLaw N D (a i) (b i) {ω | d < finiteExitDuration N D (a i) ω} ≤ ε) :
    exactExitProductLaw N D m a b {ω | ∃ i, d < finiteExitDuration N D (a i) (ω i)} ≤
      (m : ℝ≥0∞) * ε := by
  let ν := fun i => exactExitLaw N D (a i) (b i)
  have (i : Fin m) : IsProbabilityMeasure (ν i) := cond_isProbabilityMeasure (hexit i)
  have hmarg (i : Fin m) :
      exactExitProductLaw N D m a b {ω | d < finiteExitDuration N D (a i) (ω i)} =
        ν i {ω | d < finiteExitDuration N D (a i) ω} := by
    change Measure.pi ν ((Function.eval i) ⁻¹' {ω | d < finiteExitDuration N D (a i) ω}) = _
    rw [← Measure.map_apply (measurable_pi_apply i)
      (measurableSet_lt measurable_const (measurable_finiteExitDuration N D (a i))),
      (measurePreserving_eval ν i).map_eq]
  rw [Set.ofPred_exists]
  calc
    _ ≤ ∑' i : Fin m, exactExitProductLaw N D m a b
        {ω | d < finiteExitDuration N D (a i) (ω i)} := measure_iUnion_le _
    _ = ∑ i : Fin m, ν i {ω | d < finiteExitDuration N D (a i) ω} := by
      rw [tsum_fintype]
      simp_rw [hmarg]
    _ ≤ ∑ _i : Fin m, ε := Finset.sum_le_sum (fun i _ => htail i)
    _ = _ := by simp

theorem r6_duration_given_softness_bound (hWalk : WalkModelRegular)
    (N : Size) (D K : Finset (Vertex N)) (m : ℕ) (a b : Fin m → Vertex N)
    (hexit : ∀ i, walkLaw (exitsThrough N D (a i) (b i)) ≠ 0)
    (hK : K.Nonempty) (u d : ℝ) (hu : 0 ≤ u) (c ε : ℝ≥0∞)
    (havoid : ∀ i, c ≤ exactExitLaw N D (a i) (b i) (exitsThroughAvoiding N D K (a i) (b i)))
    (htail : ∀ i, exactExitLaw N D (a i) (b i) {ω | d < finiteExitDuration N D (a i) ω} ≤ ε) :
    (exactExitProductLaw N D m a b)[{ω | ∃ i, d < finiteExitDuration N D (a i) (ω i)} |
      exitBlockSoftness N D K m a u] ≤ (m : ℝ≥0∞) * ε / c ^ m := by
  have hlow := exitBlockSoftness_probability_of_avoidance hWalk N D K m a b hexit hK u hu c havoid
  have hunion := exactExit_duration_union_bound N D m a b hexit d ε htail
  rw [cond_apply (measurableSet_exitBlockSoftness N D K m a u)]
  calc
    _ ≤ (c ^ m)⁻¹ * ((m : ℝ≥0∞) * ε) :=
      mul_le_mul' (ENNReal.inv_le_inv.mpr hlow)
        ((measure_mono Set.inter_subset_right).trans hunion)
    _ = _ := by rw [div_eq_mul_inv]; ac_rfl

lemma r6_duration_no_blocks (N : Size) (D K : Finset (Vertex N))
    (a b : Fin 0 → Vertex N) (u d : ℝ) :
    (exactExitProductLaw N D 0 a b)[{ω | ∃ i, d < finiteExitDuration N D (a i) (ω i)} |
      exitBlockSoftness N D K 0 a u] = 0 := by
  simp

end TorusCoverTime.Blocks.B
