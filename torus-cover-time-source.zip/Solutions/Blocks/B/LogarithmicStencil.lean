import Solutions.Blocks.B.DiskBarrier

/-! The four-neighbor logarithmic stencil has a fourth-order radial error.
The cancellation is algebraic and keeps the generator's factor 1/4. -/

noncomputable section
namespace TorusCoverTime.Blocks.B

theorem log_near_one_abs (t : ℝ) (ht : 1/2 ≤ t) : |Real.log t| ≤ 2*|t-1| := by
  have ht0 : 0 < t := by linarith
  have hu := Real.log_le_sub_one_of_pos ht0
  have hl := Real.log_le_sub_one_of_pos (inv_pos.mpr ht0)
  rw [Real.log_inv] at hl
  have hi : t⁻¹-1 = (1-t)/t := by field_simp <;> ring
  rw [hi] at hl
  have hab : 1-t ≤ |t-1| := by linarith [neg_le_abs (t-1)]
  have hmul := mul_le_mul_of_nonneg_right ht (abs_nonneg (t-1))
  have hr : (1-t)/t ≤ 2*|t-1| := by
    apply (div_le_iff₀ ht0).mpr
    nlinarith
  exact abs_le.mpr ⟨by linarith, by linarith [le_abs_self (t-1), abs_nonneg (t-1)]⟩

theorem logarithmic_stencil_error (x y : ℝ) (hs : 4 ≤ x^2+y^2) :
    |(Real.log ((x+1)^2+y^2)+Real.log ((x-1)^2+y^2)+
        Real.log (x^2+(y+1)^2)+Real.log (x^2+(y-1)^2)-4*Real.log (x^2+y^2))/8| ≤
      1/(x^2+y^2)^2 := by
  let s := x^2+y^2
  let P := ((x+1)^2+y^2)*((x-1)^2+y^2)*(x^2+(y+1)^2)*(x^2+(y-1)^2)
  have hs0 : 0 < s := by dsimp only [s]; linarith
  have hs2 : 4 ≤ s^2 := by dsimp only [s]; nlinarith
  have hs4 : 0 < s^4 := pow_pos hs0 _
  have hxp : 0 < (x+1)^2+y^2 := by nlinarith [sq_nonneg (x+2), sq_nonneg y]
  have hxm : 0 < (x-1)^2+y^2 := by nlinarith [sq_nonneg (x-2), sq_nonneg y]
  have hyp : 0 < x^2+(y+1)^2 := by nlinarith [sq_nonneg (y+2), sq_nonneg x]
  have hym : 0 < x^2+(y-1)^2 := by nlinarith [sq_nonneg (y-2), sq_nonneg x]
  have hP : 0 < P := by dsimp only [P]; positivity
  have he : P-s^4 = -2*s^2+1+16*x^2*y^2 := by dsimp only [P,s]; ring
  have hxy : 4*x^2*y^2 ≤ s^2 := by
    have h := sq_nonneg (x^2-y^2)
    dsimp only [s]
    nlinarith
  have hxy0 : 0 ≤ x^2*y^2 := mul_nonneg (sq_nonneg x) (sq_nonneg y)
  have herror : |P-s^4| ≤ 4*s^2 := by
    apply abs_le.mpr
    constructor <;> nlinarith
  have hs4lower : 4*s^2 ≤ s^4 := by
    nlinarith [mul_nonneg (sq_nonneg s) (sub_nonneg.mpr hs2)]
  have ht : 1/2 ≤ P/s^4 := by
    apply (le_div_iff₀ hs4).mpr
    nlinarith
  have ht1 : |P/s^4-1| ≤ 4/s^2 := by
    rw [show P/s^4-1 = (P-s^4)/s^4 by field_simp <;> ring,
      abs_div, abs_of_pos hs4]
    calc
      _ ≤ (4*s^2)/s^4 := div_le_div_of_nonneg_right herror hs4.le
      _ = _ := by field_simp <;> ring
  have hl := (log_near_one_abs (P/s^4) ht).trans (mul_le_mul_of_nonneg_left ht1 (by norm_num : (0:ℝ)≤2))
  have hlog : Real.log (P/s^4) =
      Real.log ((x+1)^2+y^2)+Real.log ((x-1)^2+y^2)+
        Real.log (x^2+(y+1)^2)+Real.log (x^2+(y-1)^2)-4*Real.log s := by
    rw [Real.log_div hP.ne' (pow_ne_zero _ hs0.ne'), Real.log_pow]
    dsimp only [P]
    rw [Real.log_mul (mul_pos (mul_pos hxp hxm) hyp).ne' hym.ne',
      Real.log_mul (mul_pos hxp hxm).ne' hyp.ne', Real.log_mul hxp.ne' hxm.ne']
    norm_num
  rw [hlog] at hl
  change |(_)/8| ≤ 1/s^2
  rw [abs_div, abs_of_pos (by norm_num : (0:ℝ)<8)]
  apply (div_le_iff₀ (by norm_num : (0:ℝ)<8)).mpr
  exact hl.trans_eq (by ring)

end TorusCoverTime.Blocks.B
