import Solutions.Blocks.B.DiskExitSupport
import Solutions.Blocks.B.GreenLogarithm

/-! Precise logarithmic estimates for the actual small-disk Green kernel,
including its finite-torus correction and actual exterior exit distribution. -/

noncomputable section
namespace TorusCoverTime.Blocks.B

theorem log_comparable_radius (R d : ℝ) (hR : 0 < R) (hdlo : R/2 ≤ d) (hdhi : d ≤ 3*R) :
    |Real.log d - Real.log R| ≤ Real.log 3 := by
  have hd : 0 < d := by linarith
  have h1 := Real.log_le_log hd hdhi
  have h2 := Real.log_le_log hR (show R ≤ 3*d by linarith)
  rw [Real.log_mul (by norm_num) hR.ne'] at h1
  rw [Real.log_mul (by norm_num) hd.ne'] at h2
  rw [abs_le]
  constructor <;> linarith

theorem diskExteriorNeighbor_green_error (N : Size) (c : Vertex N) (R : ℝ) (hR : 1 ≤ R)
    (b x : Vertex N) (hb : diskExteriorNeighbor N c R b) (hx : periodicDistance x c ≤ R/2) :
    |greenKernel N b x - g * Real.log ((N.val : ℝ)/R)| ≤
      greenLogErrorConstant + g * Real.log 3 := by
  have hd := diskExteriorNeighbor_inner_distance N c R hR b x hb hx
  have hR0 : 0 < R := by linarith
  have hd0 : 0 < periodicDistance b x := by linarith [hd.1]
  have hbx : b ≠ x := by intro he; subst b; rw [periodicDistance_self_zero] at hd0; linarith
  have hg := greenKernel_log_error N b x hbx
  have hl := log_comparable_radius R (periodicDistance b x) hR0 hd.1 hd.2
  have hn : (N.val : ℝ) ≠ 0 := (zero_lt_one.trans (size_real_gt_one N)).ne'
  have hgap : |g*Real.log ((N.val : ℝ)/periodicDistance b x) - g*Real.log ((N.val : ℝ)/R)| ≤
      g*Real.log 3 := by
    rw [Real.log_div hn hd0.ne', Real.log_div hn hR0.ne', ← mul_sub]
    rw [show (Real.log (N.val : ℝ) - Real.log (periodicDistance b x)) -
        (Real.log (N.val : ℝ) - Real.log R) = -(Real.log (periodicDistance b x) - Real.log R) by ring]
    rw [abs_mul, abs_neg, abs_of_pos (by unfold g; positivity)]
    exact mul_le_mul_of_nonneg_left hl (by unfold g; positivity)
  calc
    _ = |(greenKernel N b x - g*Real.log ((N.val : ℝ)/periodicDistance b x)) +
        (g*Real.log ((N.val : ℝ)/periodicDistance b x) - g*Real.log ((N.val : ℝ)/R))| := by congr 1; ring
    _ ≤ _ := abs_add_le _ _
    _ ≤ _ := add_le_add hg hgap

theorem diskGreen_exit_average_error (N : Size) (c : Vertex N) (R : ℝ) (hR : 1 ≤ R)
    (hsmall : 2*(R+1) < N.val) (a x : Vertex N) (ha : a ∈ torusDisk N c R)
    (hx : periodicDistance x c ≤ R/2) :
    |exitExtension N (torusDisk N c R) (fun b => greenKernel N b x) a -
      g * Real.log ((N.val : ℝ)/R)| ≤ greenLogErrorConstant + g * Real.log 3 :=
  diskExitExtension_abs_error N c R (by linarith) hsmall a ha _ _ _
    (fun b hb => diskExteriorNeighbor_green_error N c R hR b x hb hx)

def diskGreenLogErrorConstant : ℝ :=
  2*greenLogErrorConstant + greenDiagonalErrorConstant + g*Real.log 3 + 1

theorem diskGreenLogErrorConstant_pos : 0 < diskGreenLogErrorConstant := by
  have := greenLogErrorConstant_pos
  have := greenDiagonalErrorConstant_pos
  have hl : 0 < Real.log 3 := Real.log_pos (by norm_num)
  unfold diskGreenLogErrorConstant g
  positivity

theorem diskGreen_offdiagonal_log_error (N : Size) (c : Vertex N) (R : ℝ) (hR : 1 ≤ R)
    (hsmall : 2*(R+1) < N.val) (a x : Vertex N) (ha : a ∈ torusDisk N c R)
    (hx : periodicDistance x c ≤ R/2) (hax : a ≠ x) :
    |diskGreen N c R a x - g*Real.log (R/periodicDistance a x)| ≤ diskGreenLogErrorConstant := by
  have hg := greenKernel_log_error N a x hax
  have he := diskGreen_exit_average_error N c R hR hsmall a x ha hx
  have hb := diskBarrier_correction_bound N c R (by linarith) hsmall a
  have hn : (N.val : ℝ) ≠ 0 := (zero_lt_one.trans (size_real_gt_one N)).ne'
  have hR0 : 0 < R := by linarith
  have hd : 0 < periodicDistance a x := by
    have hd := periodicDistance_nonzero_ge_one N (a-x) (sub_ne_zero.mpr hax)
    rw [periodicDistance_sub_zero] at hd
    linarith
  have hid : diskGreen N c R a x - g*Real.log (R/periodicDistance a x) =
      (greenKernel N a x - g*Real.log ((N.val : ℝ)/periodicDistance a x)) -
      (exitExtension N (torusDisk N c R) (fun b => greenKernel N b x) a - g*Real.log ((N.val : ℝ)/R)) +
      (1/vertexCount N) * (diskBarrier N c R a - exitExtension N (torusDisk N c R) (diskBarrier N c R) a) := by
    rw [Real.log_div hR0.ne' hd.ne', Real.log_div hn hd.ne', Real.log_div hn hR0.ne']
    unfold diskGreen domainGreenFromBarrier
    ring
  rw [hid]
  apply ((abs_add_le _ _).trans (add_le_add (abs_sub _ _) le_rfl)).trans
  apply (add_le_add (add_le_add hg he) hb).trans
  unfold diskGreenLogErrorConstant
  have := greenDiagonalErrorConstant_pos
  linarith

theorem diskGreen_diagonal_precise (N : Size) (c : Vertex N) (R : ℝ) (hR : 1 ≤ R)
    (hsmall : 2*(R+1) < N.val) (x : Vertex N) (hx : periodicDistance x c ≤ R/2) :
    |diskGreen N c R x x - g*Real.log R| ≤ diskGreenLogErrorConstant := by
  have hR0 : 0 < R := by linarith
  have hxD : x ∈ torusDisk N c R := (mem_torusDisk N c x R).mpr (by linarith)
  have hg := greenDiagonal_log_error N
  have he := diskGreen_exit_average_error N c R hR hsmall x x hxD hx
  have hb := diskBarrier_correction_bound N c R (by linarith) hsmall x
  have hn : (N.val : ℝ) ≠ 0 := (zero_lt_one.trans (size_real_gt_one N)).ne'
  have hid : diskGreen N c R x x - g*Real.log R =
      (greenDiagonal N - g*logSize N) -
      (exitExtension N (torusDisk N c R) (fun b => greenKernel N b x) x - g*Real.log ((N.val : ℝ)/R)) +
      (1/vertexCount N) * (diskBarrier N c R x - exitExtension N (torusDisk N c R) (diskBarrier N c R) x) := by
    rw [Real.log_div hn hR0.ne']
    unfold diskGreen domainGreenFromBarrier logSize
    rw [greenKernel_diagonal]
    ring
  rw [hid]
  apply ((abs_add_le _ _).trans (add_le_add (abs_sub _ _) le_rfl)).trans
  apply (add_le_add (add_le_add hg he) hb).trans
  unfold diskGreenLogErrorConstant
  have := greenLogErrorConstant_pos
  linarith

theorem diskGreen_lower_of_distance (N : Size) (c : Vertex N) (R : ℝ) (hR : 1 ≤ R)
    (hsmall : 2*(R+1) < N.val) (a x : Vertex N) (ha : a ∈ torusDisk N c R)
    (hx : periodicDistance x c ≤ R/2) (hax : a ≠ x) (s : ℝ) (hs : periodicDistance a x ≤ s) :
    g*Real.log (R/s) - diskGreenLogErrorConstant ≤ diskGreen N c R a x := by
  have he := (abs_le.mp (diskGreen_offdiagonal_log_error N c R hR hsmall a x ha hx hax)).1
  have hd : 0 < periodicDistance a x := by
    have hd := periodicDistance_nonzero_ge_one N (a-x) (sub_ne_zero.mpr hax)
    rw [periodicDistance_sub_zero] at hd
    linarith
  have hs0 := hd.trans_le hs
  have hl : Real.log (R/s) ≤ Real.log (R/periodicDistance a x) :=
    Real.log_le_log (div_pos (by linarith) hs0) (div_le_div_of_nonneg_left (by linarith) hd hs)
  have hh := mul_le_mul_of_nonneg_left hl (by unfold g; positivity : 0 ≤ g)
  linarith

end TorusCoverTime.Blocks.B
