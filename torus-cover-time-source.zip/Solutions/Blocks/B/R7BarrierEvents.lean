import Solutions.Blocks.B.R7ShiftedBarrierExponent

/-! The manuscript's original lower barrier, its exact finite integer-scale
representation, and the same-path reduction to the deterministic grid. -/

noncomputable section
open MeasureTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

def r7CoarseIntegerScales (N : Size) (γ : ℝ) : Finset ℕ :=
  (Finset.range (⌊logSize N⌋₊+1)).filter (fun k =>
    (logSize N)^(16*γ) ≤ (k:ℝ) ∧ (k:ℝ) ≤ logSize N-(logSize N)^(16*γ))

theorem mem_r7CoarseIntegerScales (N : Size) (γ : ℝ) (k : ℕ) :
    k ∈ r7CoarseIntegerScales N γ ↔
      (logSize N)^(16*γ) ≤ (k:ℝ) ∧ (k:ℝ) ≤ logSize N-(logSize N)^(16*γ) := by
  rw [r7CoarseIntegerScales,Finset.mem_filter]
  constructor
  · exact And.right
  · intro h
    refine ⟨Finset.mem_range.mpr (Nat.lt_succ_iff.mpr ?_),h⟩
    exact (Nat.le_floor_iff (logSize_pos N).le).mpr
      (h.2.trans (sub_le_self _ (Real.rpow_nonneg (logSize_pos N).le _)))

theorem r7_coarse_integer_scales_card (N : Size) (γ : ℝ) (hL : 1 ≤ logSize N) :
    ((r7CoarseIntegerScales N γ).card:ℝ) ≤ 2*logSize N := by
  have hc : (r7CoarseIntegerScales N γ).card ≤ ⌊logSize N⌋₊+1 :=
    (Finset.card_filter_le _ _).trans_eq (Finset.card_range _)
  have hcR : ((r7CoarseIntegerScales N γ).card:ℝ) ≤ (⌊logSize N⌋₊:ℝ)+1 := by exact_mod_cast hc
  linarith [Nat.floor_le (logSize_pos N).le]

def r7LowerBarrierFailure (N : Size) (root : Vertex N) (γ q : ℝ) : Set (WalkSample × ℝ) :=
  {z | ∃ x : Vertex N,
    2*((N.val:ℝ)*Real.exp (-((logSize N)^(16*γ))/2)) ≤ periodicDistance x root ∧
    r7TraversalRadius N x root γ q z < Real.sqrt 2*q-(logSize N)^(3*γ)}

theorem r7LowerBarrierFailure_measurable (N : Size) (root : Vertex N) (γ q : ℝ) :
    MeasurableSet (r7LowerBarrierFailure N root γ q) := by
  simp only [r7LowerBarrierFailure,Set.ofPred_exists]
  exact MeasurableSet.iUnion (fun x => (MeasurableSet.const _).inter
    (measurableSet_lt (r7TraversalRadius_measurable N x root γ q) measurable_const))

def r7LowerBarrier (N : Size) (root : Vertex N) (γ : ℝ) (z : WalkSample × ℝ) : Prop :=
  ∀ k : ℕ, (logSize N)^(16*γ) ≤ (k:ℝ) → (k:ℝ) ≤ logSize N-(logSize N)^(16*γ) →
    ∀ x : Vertex N,
      2*((N.val:ℝ)*Real.exp (-((logSize N)^(16*γ))/2)) ≤ periodicDistance x root →
      Real.sqrt 2*(k:ℝ)-(logSize N)^(3*γ) ≤ r7TraversalRadius N x root γ k z

theorem r7LowerBarrier_compl_eq (N : Size) (root : Vertex N) (γ : ℝ) :
    {z | ¬ r7LowerBarrier N root γ z} =
      ⋃ k ∈ r7CoarseIntegerScales N γ, r7LowerBarrierFailure N root γ k := by
  ext z
  simp only [r7LowerBarrier,r7LowerBarrierFailure,mem_iUnion,mem_ofPred_eq,
    mem_r7CoarseIntegerScales]
  push Not
  aesop

theorem r7LowerBarrier_iff_int (N : Size) (root : Vertex N) (γ : ℝ) (z : WalkSample × ℝ) :
    r7LowerBarrier N root γ z ↔
      ∀ k : ℤ, (logSize N)^(16*γ) ≤ (k:ℝ) → (k:ℝ) ≤ logSize N-(logSize N)^(16*γ) →
        ∀ x : Vertex N,
          2*((N.val:ℝ)*Real.exp (-((logSize N)^(16*γ))/2)) ≤ periodicDistance x root →
          Real.sqrt 2*(k:ℝ)-(logSize N)^(3*γ) ≤ r7TraversalRadius N x root γ k z := by
  constructor
  · intro h k hlo hhi x hx
    have hkR : (0:ℝ) ≤ (k:ℝ) := (Real.rpow_nonneg (logSize_pos N).le _).trans hlo
    have hk : 0 ≤ k := by exact_mod_cast hkR
    have he : (k.toNat:ℝ) = (k:ℝ) := by exact_mod_cast Int.toNat_of_nonneg hk
    simpa only [he] using h k.toNat (by simpa only [he] using hlo) (by simpa only [he] using hhi) x hx
  · intro h k hlo hhi x hx
    exact h (k:ℤ) (by simpa using hlo) (by simpa using hhi) x hx

def r7PerturbedBarrierEvent (N : Size) (root c : Vertex N) (γ q : ℝ) : Set (WalkSample × ℝ) :=
  {z | (N.val:ℝ)*Real.exp (-((logSize N)^(16*γ))/2) ≤ periodicDistance c root ∧
    r7PerturbedTraversalRadius N c root γ q z ≤ r7ShiftedBarrier N γ q}

theorem r7PerturbedBarrierEvent_measurable (N : Size) (root c : Vertex N) (γ q : ℝ) :
    MeasurableSet (r7PerturbedBarrierEvent N root c γ q) :=
  (MeasurableSet.const _).inter
    (measurableSet_le (r7PerturbedTraversalRadius_measurable N c root γ q) measurable_const)

theorem r7_lower_barrier_grid_ae (γ : ℝ) (hγ : 0 < γ) :
    ∀ᶠ N : Size in atTop, ∀ root : Vertex N, ∀ q : ℝ,
      (logSize N)^(16*γ) ≤ q → q ≤ logSize N-(logSize N)^(16*γ) →
      ∀ᵐ ω ∂walkLaw, ∀ t : ℝ, 0 ≤ t → (ω,t) ∈ r7LowerBarrierFailure N root γ q →
        (ω,t) ∈ ⋃ y ∈ r7Grid N q, r7PerturbedBarrierEvent N root y γ q := by
  have hQ := (tendsto_rpow_atTop (by positivity : 0 < 16*γ)).comp blockB_logSize_tendsto
  filter_upwards [r7_shifted_traversal_radius_ae γ hγ,r7_lower_barrier_parameters γ hγ,
    r7_grid_shift_below_root_scale γ hγ,hQ.eventually_ge_atTop (Real.log 2)] with N hs hp hd hbase
  intro root q hq hqL
  have hqL' := hqL.trans (sub_le_self _ (Real.rpow_nonneg (logSize_pos N).le _))
  have hv := hp q hq hqL'
  have hpoint (x : Vertex N) : ∀ᵐ ω ∂walkLaw, ∀ t : ℝ, 0 ≤ t →
      2*((N.val:ℝ)*Real.exp (-((logSize N)^(16*γ))/2)) ≤ periodicDistance x root →
      r7TraversalRadius N x root γ q (ω,t) < Real.sqrt 2*q-(logSize N)^(3*γ) →
      (ω,t) ∈ ⋃ y ∈ r7Grid N q, r7PerturbedBarrierEvent N root y γ q := by
    by_cases hfar : 2*((N.val:ℝ)*Real.exp (-((logSize N)^(16*γ))/2)) ≤ periodicDistance x root
    · obtain ⟨y,hy,hxy⟩ := r7_grid_cover N q (hbase.trans hq) x
      filter_upwards [hs x y root q hq hqL hxy hfar] with ω hω
      intro t ht _ hbad
      have hcmp := hω t ht (hbad.le.trans hv.2)
      refine mem_iUnion.mpr ⟨y,mem_iUnion.mpr ⟨hy,?_⟩⟩
      exact ⟨far_root_after_center_shift N x y root _ _ hfar hxy (hd q hqL),
        by dsimp only [r7ShiftedBarrier]; linarith⟩
    · exact Eventually.of_forall (by intros; contradiction)
  filter_upwards [ae_all_iff.mpr hpoint] with ω hω
  rintro t ht ⟨x,hfar,hbad⟩
  exact hω x t ht hfar hbad

end TorusCoverTime.Blocks.B
