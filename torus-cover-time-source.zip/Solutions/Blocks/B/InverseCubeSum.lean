import Solutions.Blocks.B.SquareShells
import Solutions.Blocks.B.LatticeSums
import Solutions.Blocks.B.TorusMetric

/-! Summable radial weights on any finite torus, with constants independent
of its size. A fourth-power tail is controlled by the third-power sum. -/

noncomputable section
open Classical
namespace TorusCoverTime.Blocks.B

theorem symmetricMaxSum_inverse_cube (n : ℕ) :
    symmetricMaxSum n (fun r => 1/(max 1 r)^3) ≤ 17 := by
  rw [symmetricMaxSum_shells]
  have he (j : ℕ) : ((j:ℝ)+1)*(1/(max 1 ((j:ℝ)+1))^3) = 1/((j:ℝ)+1)^2 := by
    rw [max_eq_right (by have := Nat.cast_nonneg (α := ℝ) j; linarith)]
    field_simp
  simp only [he, max_eq_left (by norm_num : (0:ℝ) ≤ 1), one_pow, div_one]
  linarith [sum_reciprocal_squares_le_two n]

theorem torus_inverse_cube_sum (N : Size) (c : Vertex N) :
    (∑ z : Vertex N, 1/(max 1 (periodicDistance z c))^3) ≤ 17 := by
  have he : (∑ z : Vertex N, 1/(max 1 (periodicDistance z c))^3) =
      ∑ z : Vertex N, 1/(max 1 (periodicDistance z 0))^3 := by
    apply Finset.sum_bij (fun z _ => z-c)
    · simp
    · intro x _ y _ hxy
      exact sub_left_inj.mp hxy
    · intro z _
      exact ⟨z+c, Finset.mem_univ _, by abel⟩
    · intro z _
      rw [periodicDistance_sub_zero]
  rw [he]
  calc
    _ ≤ ∑ z : Vertex N,
        1/(max 1 (max (coordinateDistance z.1 0) (coordinateDistance z.2 0)))^3 := by
      apply Finset.sum_le_sum
      intro z _
      apply one_div_le_one_div_of_le (by positivity)
      apply pow_le_pow_left₀ (by positivity)
      exact max_le_max_left 1 (max_le (periodicDistance_coordinate_le N z).1
        (periodicDistance_coordinate_le N z).2)
    _ ≤ symmetricMaxSum (N.val/2) (fun r => 1/(max 1 r)^3) := by
      rw [Fintype.sum_prod_type]
      exact (sum_centered_two_coordinates_bounds N
        (fun x y => 1/(max 1 (max x y))^3) (by intros; positivity)).2
    _ ≤ 17 := symmetricMaxSum_inverse_cube _

theorem torus_inverse_fourth_tail (N : Size) (c : Vertex N) (S : Finset (Vertex N))
    (r : ℝ) (hr : 0 < r) (hS : ∀ z ∈ S, r ≤ periodicDistance z c) :
    (∑ z ∈ S, 1/(max 1 (periodicDistance z c))^4) ≤ 17/r := by
  have ht (z : Vertex N) (hz : z ∈ S) :
      1/(max 1 (periodicDistance z c))^4 ≤
        (1/(max 1 (periodicDistance z c))^3)/r := by
    let d := max 1 (periodicDistance z c)
    have hd : 0 < d := lt_of_lt_of_le zero_lt_one (le_max_left _ _)
    have hrd : r ≤ d := (hS z hz).trans (le_max_right _ _)
    change 1/d^4 ≤ (1/d^3)/r
    rw [div_div]
    apply one_div_le_one_div_of_le (by positivity)
    nlinarith [mul_le_mul_of_nonneg_left hrd (pow_nonneg hd.le 3)]
  calc
    _ ≤ ∑ z ∈ S, (1/(max 1 (periodicDistance z c))^3)/r :=
      Finset.sum_le_sum ht
    _ = (∑ z ∈ S, 1/(max 1 (periodicDistance z c))^3)/r := (Finset.sum_div ..).symm
    _ ≤ (∑ z : Vertex N, 1/(max 1 (periodicDistance z c))^3)/r := by
      apply div_le_div_of_nonneg_right _ hr.le
      exact Finset.sum_le_sum_of_subset_of_nonneg (Finset.subset_univ S)
        (fun z _ _ => by positivity)
    _ ≤ 17/r := div_le_div_of_nonneg_right (torus_inverse_cube_sum N c) hr.le

end TorusCoverTime.Blocks.B
