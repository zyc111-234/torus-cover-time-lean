import Solutions.Blocks.B.PinnedCoarseProbe
import Solutions.Blocks.B.R10WitnessAlgebra
import Solutions.Blocks.B.R6CoarseCounts

/-! The concrete R7 coarse probe on the original finite Gaussian field.
Its three cutoffs are simultaneous, and its lower probability is uniform
over the coarse scales and all roots satisfying the manuscript's distance bound. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal NNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

theorem far_root_green_bound (N : Size) (root x : Vertex N) (Q : ℝ)
    (hfar : (N.val:ℝ)*Real.exp (-Q/2) ≤ periodicDistance x root) :
    |greenKernel N x root| ≤ greenSpatialConstant*(1+Q/2) := by
  have hn : 0 < (N.val:ℝ) := lt_trans zero_lt_one (size_real_gt_one N)
  have hd : 0 < max (periodicDistance x root) 1 := lt_of_lt_of_le zero_lt_one (le_max_right _ _)
  have hh := mul_le_mul_of_nonneg_right (hfar.trans (le_max_left (periodicDistance x root) 1)) (Real.exp_pos (Q/2)).le
  have he : Real.exp (-Q/2)*Real.exp (Q/2) = 1 := by
    rw [← Real.exp_add,show -Q/2+Q/2 = 0 by ring,Real.exp_zero]
  rw [mul_assoc,he,mul_one] at hh
  have hquot : (N.val:ℝ)/max (periodicDistance x root) 1 ≤ Real.exp (Q/2) :=
    (div_le_iff₀ hd).mpr (by simpa only [mul_comm] using hh)
  have hlog := Real.log_le_log (div_pos hn hd) hquot
  rw [Real.log_exp] at hlog
  exact (greenKernel_spatial_bound N x root).trans
    (mul_le_mul_of_nonneg_left (add_le_add le_rfl hlog) greenSpatialConstant_pos.le)

theorem r7_far_root_variance (γ : ℝ) (hγ : 16*γ < 1) :
    ∀ᶠ N : Size in atTop, greenDiagonal N ≤ 2*g*logSize N ∧
      ∀ root x : Vertex N, (N.val:ℝ)*Real.exp (-((logSize N)^(16*γ))/2) ≤ periodicDistance x root →
        1 ≤ pinnedCoordinateVariance N root x ∧ greenDiagonal N ≤ pinnedCoordinateVariance N root x := by
  have hg := coarseProbe_g_pos
  have hD := blockB_logSize_tendsto.eventually
    (power_eventually_le_power greenDiagonalErrorConstant 0 1 (g/2) (by norm_num) (by positivity))
  have hC := blockB_logSize_tendsto.eventually
    (power_eventually_le_power greenSpatialConstant 0 1 (g/8) (by norm_num) (by positivity))
  have hQ := blockB_logSize_tendsto.eventually
    (power_eventually_le_power greenSpatialConstant (16*γ) 1 (g/4) hγ (by positivity))
  filter_upwards [hD,hC,hQ,blockB_logSize_tendsto.eventually_ge_atTop (2/g)] with N hD hC hQ hL
  simp only [Real.rpow_zero,Real.rpow_one,mul_one] at hD hC hQ
  have hdiag := abs_le.mp (greenDiagonal_log_error N)
  have hGlo : g*logSize N/2 ≤ greenDiagonal N := by linarith
  have hGone : 1 ≤ greenDiagonal N := by
    have hh := mul_le_mul_of_nonneg_left hL hg.le
    rw [mul_div_cancel₀ _ hg.ne'] at hh
    linarith
  refine ⟨by nlinarith [logSize_pos N],?_⟩
  intro root x hfar
  have hfarG := far_root_green_bound N root x ((logSize N)^(16*γ)) hfar
  have hGxy : greenKernel N x root ≤ greenDiagonal N/2 := by
    have hh := le_abs_self (greenKernel N x root)
    nlinarith
  have hVlo : greenDiagonal N ≤ pinnedCoordinateVariance N root x := by
    unfold pinnedCoordinateVariance
    linarith
  exact ⟨hGone.trans hVlo,hVlo⟩

theorem harmonic_weight_probe_support (N : Size) (c : Vertex N) (q : ℝ) (hq : 1 ≤ q)
    (z : Vertex N) (hz : diskHarmonicWeight N c (Real.exp (q+1)) z ≠ 0) :
    Real.log (2+periodicDistance z c) ≤ q+3 := by
  have hs := diskHarmonicWeight_support N c _ (Real.exp_pos _) z hz
  have hd := (diskExteriorNeighbor_radius N c _ z hs).2
  have hR : 3 ≤ Real.exp (q+1) := by linarith [Real.add_one_le_exp (q+1)]
  have h2 : 2 ≤ Real.exp (2:ℝ) := by linarith [Real.add_one_le_exp (2:ℝ)]
  have hbound : 2+periodicDistance z c ≤ Real.exp (q+3) := by
    have he : Real.exp (q+3) = Real.exp (q+1)*Real.exp 2 := by rw [← Real.exp_add]; congr 1; ring
    rw [he]
    nlinarith
  have hd0 : 0 ≤ periodicDistance z c := Real.sqrt_nonneg _
  have hh := Real.log_le_log (by linarith : 0 < 2+periodicDistance z c) hbound
  simpa only [Real.log_exp] using hh

def r7CoarseProbe (N : Size) (root c : Vertex N) (q : ℝ) : Set (FiniteFieldSample N) :=
  {ξ | |D.pinnedField N root ξ c| ≤ 1 ∧
    pinnedWeightedEnergy N root (diskHarmonicWeight N c (Real.exp (q+1))) ξ ≤ 4*(coarseProbeRadialConstant*q) ∧
      D.pinnedEnergy N root ξ ≤ (64*g)*vertexCount N*logSize N}

def coarseProbeProbabilityConstant : ℝ := Real.exp (-(1:ℝ)/2)/Real.sqrt (16*Real.pi*g)

theorem coarseProbeProbabilityConstant_pos : 0 < coarseProbeProbabilityConstant := by
  have := coarseProbe_g_pos
  unfold coarseProbeProbabilityConstant
  positivity

theorem r7CoarseProbe_measurable (N : Size) (root c : Vertex N) (q : ℝ) :
    MeasurableSet (r7CoarseProbe N root c q) :=
  (pinnedSlab_measurable N root c).inter
    ((measurableSet_le (pinnedWeightedEnergy_measurable N root _) measurable_const).inter
      (measurableSet_le (Finset.measurable_sum _ fun z _ => (pinned_coordinate_measurable N root z).pow_const 2) measurable_const))

theorem r7_coarse_probe_mass (γ : ℝ) (hγ : 0 < γ) (hγ1 : 16*γ < 1) :
    ∀ᶠ N : Size in atTop, ∀ root c : Vertex N, ∀ q : ℝ,
      (logSize N)^(16*γ) ≤ q → q ≤ logSize N-(logSize N)^(16*γ) →
      (N.val:ℝ)*Real.exp (-((logSize N)^(16*γ))/2) ≤ periodicDistance c root →
        coarseProbeProbabilityConstant/Real.sqrt (logSize N) ≤
          (finiteFieldLaw N).real (r7CoarseProbe N root c q) := by
  have hQ := (tendsto_rpow_atTop (by positivity : 0 < 16*γ)).comp blockB_logSize_tendsto
  filter_upwards [r7_far_root_variance γ hγ1,r6_disk_radius_embedding γ hγ,hQ.eventually_ge_atTop 1]
    with N hvar hsmall hlarge
  intro root c q hq hqL hfar
  have hq1 : 1 ≤ q := hlarge.trans hq
  have hq0 : 0 ≤ q := by linarith
  have hw : 1 ≤ q^γ := Real.one_le_rpow hq1 hγ.le
  have hr : 2*(Real.exp (q+1)+1) < N.val := by
    have hh := hsmall q hq0 hqL
    have he := Real.exp_le_exp.mpr (show q+1 ≤ q+2*q^γ by linarith)
    linarith
  have hV := hvar.2 root c hfar
  have hp := pinned_coarse_probe_mass N root c _ (diskHarmonicWeight_nonneg N c _)
    (diskHarmonicWeight_sum N c _ (Real.exp_pos _).le hr) q hq1
    (harmonic_weight_probe_support N c q hq1) hV.1 hV.2
  have hsub : pinnedCoarseProbe N root c (diskHarmonicWeight N c (Real.exp (q+1))) q ⊆ r7CoarseProbe N root c q := by
    intro ξ hξ
    refine ⟨hξ.1,hξ.2.1,hξ.2.2.trans ?_⟩
    nlinarith [mul_le_mul_of_nonneg_left hvar.1 (vertexCount_pos N).le]
  have hp' := hp.trans (measureReal_mono hsub)
  have hVup := (pinned_coordinate_variance_le N root c).trans (mul_le_mul_of_nonneg_left hvar.1 (by norm_num : (0:ℝ) ≤ 4))
  have hden : Real.sqrt (2*Real.pi*pinnedCoordinateVariance N root c) ≤
      Real.sqrt (16*Real.pi*g)*Real.sqrt (logSize N) := by
    rw [← Real.sqrt_mul (by have := coarseProbe_g_pos; positivity : 0 ≤ 16*Real.pi*g)]
    apply Real.sqrt_le_sqrt
    nlinarith [mul_le_mul_of_nonneg_left hVup (by positivity : 0 ≤ 2*Real.pi)]
  have hden0 : 0 < Real.sqrt (2*Real.pi*pinnedCoordinateVariance N root c) :=
    Real.sqrt_pos.mpr (by have := hV.1; positivity)
  calc
    _ = Real.exp (-(1:ℝ)/2)/(Real.sqrt (16*Real.pi*g)*Real.sqrt (logSize N)) := by
      unfold coarseProbeProbabilityConstant
      ring
    _ ≤ Real.exp (-(1:ℝ)/2)/Real.sqrt (2*Real.pi*pinnedCoordinateVariance N root c) :=
      div_le_div_of_nonneg_left (Real.exp_pos _).le hden0 hden
    _ ≤ _ := hp'

end TorusCoverTime.Blocks.B
