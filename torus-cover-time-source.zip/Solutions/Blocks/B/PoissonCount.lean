import Solutions.Blocks.B.PoissonMoments

/-! The Poisson jump-count probabilities for the concrete exponential-holding-time walk. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter
open scoped BigOperators ENNReal Topology

namespace TorusCoverTime.Blocks.B

lemma integral_jumpTime_holding_pair (hWalk : WalkModelRegular) (n : ℕ)
    (f : ℝ × ℝ → ℝ) (hf : Measurable f) (M : ℝ) (hbound : ∀ p, ‖f p‖ ≤ M) :
    (∫ ω : WalkSample, f (jumpTime ω n, holdingTime ω n) ∂walkLaw) =
      ∫ u, (∫ s, f (u, s) ∂holdingLaw) ∂walkLaw.map (fun ω => jumpTime ω n) := by
  let law := walkLaw.map (fun ω => jumpTime ω n)
  let : IsProbabilityMeasure law := Measure.isProbabilityMeasure_map (measurable_jumpTime n).aemeasurable
  have hpair : Measurable (fun ω : WalkSample => (jumpTime ω n, holdingTime ω n)) :=
    (measurable_jumpTime n).prodMk (measurable_holdingTime n)
  have hprod : Integrable f (law.prod holdingLaw) :=
    Integrable.of_bound hf.aestronglyMeasurable M (Filter.Eventually.of_forall hbound)
  have hmap := (jumpTime_independent_next_holding n).map_prod_eq_prod_map_map
    (measurable_jumpTime n).aemeasurable (measurable_holdingTime n).aemeasurable
  rw [holdingTime_law hWalk n] at hmap
  rw [← integral_map hpair.aemeasurable hf.aestronglyMeasurable, hmap, integral_prod _ hprod]

lemma holdingLaw_tail_probability (t : ℝ) (ht : 0 ≤ t) :
    holdingLaw.real (Set.Ioi t) = Real.exp (-t) := by
  have hCDF : holdingLaw.real (Set.Iic t) = 1 - Real.exp (-t) := by
    let : IsProbabilityMeasure (expMeasure 1) := isProbabilityMeasure_expMeasure (by norm_num)
    have h := cdf_expMeasure_eq (by norm_num : (0 : ℝ) < 1) t
    rw [cdf_eq_real] at h
    simpa only [holdingLaw, if_pos ht, one_mul] using h
  rw [← Set.compl_Iic, probReal_compl_eq_one_sub measurableSet_Iic, hCDF]
  ring

lemma jumpCount_probability (hWalk : WalkModelRegular) (t : ℝ) (ht : 0 ≤ t) (n : ℕ) :
    (walkLaw {ω | jumpCount ω t = n}).toReal =
      Real.exp (-t) * t ^ n / (n.factorial : ℝ) := by
  classical
  let f : ℝ × ℝ → ℝ := fun p => if p.1 ≤ t ∧ t < p.1 + p.2 then 1 else 0
  have hf : Measurable f := Measurable.ite
    ((measurableSet_le measurable_fst measurable_const).inter
      (measurableSet_lt measurable_const (measurable_fst.add measurable_snd)))
    measurable_const measurable_const
  have hbound (p : ℝ × ℝ) : ‖f p‖ ≤ 1 := by dsimp [f]; split_ifs <;> norm_num
  have hinner (u : ℝ) : (∫ s, f (u, s) ∂holdingLaw) =
      Real.exp (-t) * (if u ≤ t then Real.exp u else 0) := by
    by_cases hu : u ≤ t
    · have heq : (fun s => f (u, s)) =
          (Set.Ioi (t - u)).indicator (fun _ : ℝ => (1 : ℝ)) := by
        funext s
        have hs : t < u + s ↔ t - u < s := by constructor <;> intro h <;> linarith
        simp [f, hu, hs, Set.indicator]
      rw [heq, integral_indicator_const (1 : ℝ) measurableSet_Ioi,
        holdingLaw_tail_probability (t - u) (by linarith), if_pos hu]
      simp only [smul_eq_mul, mul_one]
      rw [← Real.exp_add]
      congr 1
      ring
    · simp [f, hu]
  have hmoment : (∫ ω : WalkSample, f (jumpTime ω n, holdingTime ω n) ∂walkLaw) =
      Real.exp (-t) * truncatedJumpMoment n t := by
    rw [integral_jumpTime_holding_pair hWalk n f hf 1 hbound]
    simp_rw [hinner]
    have htr : Measurable (fun u : ℝ => if u ≤ t then Real.exp u else 0) :=
      Measurable.ite (measurableSet_le measurable_id measurable_const)
        Real.measurable_exp measurable_const
    rw [integral_const_mul, integral_map (measurable_jumpTime n).aemeasurable htr.aestronglyMeasurable]
    rfl
  have hcount : Measurable (fun ω : WalkSample => jumpCount ω t) :=
    measurable_jumpCount_joint.comp (measurable_prodMk_right (y := t))
  have hevent : MeasurableSet {ω : WalkSample | jumpCount ω t = n} :=
    (measurableSet_singleton n).preimage hcount
  have hindicator : (∫ ω : WalkSample, if jumpCount ω t = n then (1 : ℝ) else 0 ∂walkLaw) =
      (walkLaw {ω | jumpCount ω t = n}).toReal := by
    simpa only [Set.indicator, Set.mem_ofPred_eq, Measure.real, smul_eq_mul, mul_one] using
      integral_indicator_const (μ := walkLaw) (1 : ℝ) hevent
  rw [← hindicator]
  have hcongr : (∫ ω : WalkSample, if jumpCount ω t = n then (1 : ℝ) else 0 ∂walkLaw) =
      ∫ ω : WalkSample, f (jumpTime ω n, holdingTime ω n) ∂walkLaw := by
    apply integral_congr_ae
    filter_upwards [jumpCount_event_ae hWalk t ht n] with ω hω
    have hJT : jumpTime ω (n + 1) = jumpTime ω n + holdingTime ω n := by
      simp [jumpTime, Finset.sum_range_succ]
    rw [hJT] at hω
    simp only [hω, f]
  rw [hcongr, hmoment, truncatedJumpMoment_eq hWalk n t ht]
  ring

end TorusCoverTime.Blocks.B
