import Solutions.Blocks.B.CenteredExteriorWindow
import Solutions.Blocks.B.LowHarmonicWindow

/-! Two-sided centered record event equals the original path harmonic event on closed physical slices. -/
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B


def harmonicCenteredPhysicalSlice (N : Size) (I O : Finset (Vertex N)) (c root : Vertex N)
    (m : ℕ) (w : Fin (2*m) → Vertex N) (γ q Δ : ℝ)
    (E : TraversalExteriorSample m × ℝ → ℝ≥0∞) (l r : ℝ) : ℝ≥0∞ :=
  ∫⁻ ω, (∫⁻ t in Ioi (adaptiveExitTime N (alternatingDomain N I O) root (2*m) ω),
    if t < adaptiveExitTime N (alternatingDomain N I O) root (2*m+1) ω ∧
      walk N root ω t = root ∧ t ∈ Icc l r then
      (if Δ < |Real.sqrt (harmonicPathOccupation N c root q (ω,t))-Real.sqrt ((m:ℝ)*q^γ)| then
        E (traversalExteriorData N I O root m ω,t-adaptiveExitTime N (alternatingDomain N I O) root (2*m) ω) else 0)
      else 0)
    ∂walkLaw[|{ω | adaptiveExitWord N (alternatingDomain N I O) root (2*m) ω = w}]

theorem harmonicCenteredPhysicalSlice_eq_record (N : Size) (I O : Finset (Vertex N))
    (c root : Vertex N) (hIO : I ⊆ O) (hI : I.Nonempty) (hr : root ∉ O)
    (m : ℕ) (w : Fin (2*m) → Vertex N) (γ q Δ : ℝ)
    (hU : ∀ x, x ∉ I → diskHarmonicWeight N c (Real.exp (q+1)) x/g = 0)
    (E : TraversalExteriorSample m × ℝ → ℝ≥0∞) (l r : ℝ) :
    harmonicCenteredPhysicalSlice N I O c root m w γ q Δ E l r =
      conditionalTraversalExteriorSlice N I O root m w (r7WordCenteredOccupation N c root m w γ q Δ) E l r := by
  have hac : walkLaw[|{ω | adaptiveExitWord N (alternatingDomain N I O) root (2*m) ω = w}] ≪ walkLaw :=
    cond_absolutelyContinuous
  unfold harmonicCenteredPhysicalSlice conditionalTraversalExteriorSlice
  apply lintegral_congr_ae
  filter_upwards [hac.ae_le (completedTraversalCount_loop_iff_ae N I O hIO hI root hr),
    hac.ae_le (traversalOccupation_loop_localTime_ae N I O hIO hI root hr _ hU),
    ae_cond_mem (μ := walkLaw) ((adaptiveExitWord_measurable N _ root (2*m)) (measurableSet_singleton w))]
    with ω hcount hocc hw
  apply lintegral_congr_ae
  filter_upwards [ae_restrict_mem (measurableSet_Ioi
    (a := adaptiveExitTime N (alternatingDomain N I O) root (2*m) ω))] with t ht
  by_cases hb : t < adaptiveExitTime N (alternatingDomain N I O) root (2*m+1) ω ∧
      walk N root ω t = root ∧ t ∈ Icc l r
  · have ht0 : 0 ≤ t := (jumpTime_nonneg ω _).trans ht.le
    have hm := (hcount t ht0 hb.2.1 m).mpr ⟨ht.le,hb.1⟩
    have he := hocc t ht0 hb.2.1
    rw [hm] at he
    have hcost := (traversalWordOutwardOccupation_of_word N I O root m w _ ω hw).trans he.symm
    simp only [if_pos hb,traversalExteriorMarkedTest,r7WordCenteredOccupation,mem_ofPred_eq,hcost]
    rfl
  · simp only [if_neg hb]


end TorusCoverTime.Blocks.B

