import Solutions.Blocks.B.R7CountObservable

/-! The sharp Gaussian exponent at the lower count barrier cancels the
e^(2(L-q)) spatial grid factor, with a remaining L^(3 gamma) gain. -/

noncomputable section
open Filter
open scoped Topology
namespace TorusCoverTime.Blocks.B

theorem lower_barrier_quadratic_gain (r S C : ℝ) (hr : 0 < r) (hS : 0 ≤ S)
    (hC : 0 ≤ C) (hSr : S ≤ r) (hCS : 4*C ≤ S) :
    2*r+S/4 ≤ (Real.sqrt 2*r+S/2)^2/(r+C) := by
  have hsqrt := Real.sq_sqrt (by norm_num : (0:ℝ) ≤ 2)
  have hroot : 1 ≤ Real.sqrt (2:ℝ) := by nlinarith [Real.sqrt_nonneg (2:ℝ)]
  have he : (Real.sqrt 2*r+S/2)^2 = 2*r^2+Real.sqrt 2*r*S+S^2/4 := by
    calc
      _ = (Real.sqrt 2)^2*r^2+Real.sqrt 2*r*S+S^2/4 := by ring
      _ = _ := by rw [hsqrt]
  apply (le_div_iff₀ (by linarith : 0 < r+C)).mpr
  have h1 := mul_le_mul_of_nonneg_right hroot (mul_nonneg hr.le hS)
  have h2 := mul_le_mul_of_nonneg_left hCS hr.le
  have h3 := mul_le_mul_of_nonneg_left hSr hC
  nlinarith only [he,h1,h2,h3,sq_nonneg S]

theorem harmonicExtremeCenter_eq (N : Size) :
    harmonicExtremeCenter N = Real.sqrt 2*logSize N-(3/(4*Real.sqrt 2))*Real.log (logSize N) := by
  have hs := Real.sq_sqrt (by norm_num : (0:ℝ) ≤ 2)
  have hp : 0 < Real.sqrt (2:ℝ) := by positivity
  unfold harmonicExtremeCenter
  field_simp
  nlinarith only [congrArg (fun x : ℝ => x*logSize N) hs]

theorem r7_lower_barrier_parameters (γ : ℝ) (hγ : 0 < γ) :
    ∀ᶠ N : Size in atTop, ∀ q : ℝ,
      (logSize N)^(16*γ) ≤ q → q ≤ logSize N →
      q ≤ Real.sqrt 2*q-(logSize N)^(3*γ) ∧
      Real.sqrt 2*q-(logSize N)^(3*γ) ≤ 2*logSize N := by
  have hsqrt := Real.sq_sqrt (by norm_num : (0:ℝ) ≤ 2)
  have hroot : 0 < Real.sqrt (2:ℝ)-1 := by nlinarith [Real.sqrt_nonneg (2:ℝ)]
  filter_upwards [blockB_logSize_tendsto.eventually (power_eventually_le_power 1 (3*γ) (16*γ)
    (Real.sqrt 2-1) (by linarith) hroot)] with N hN
  intro q hq hqL
  have hq0 := (Real.rpow_nonneg (logSize_pos N).le _).trans hq
  have h1 := mul_le_mul_of_nonneg_left hq hroot.le
  have h2 := mul_le_mul_of_nonneg_left hqL (Real.sqrt_nonneg (2:ℝ))
  have h3 : Real.sqrt (2:ℝ) ≤ 2 := by nlinarith [Real.sqrt_nonneg (2:ℝ)]
  have h4 := mul_le_mul_of_nonneg_right h3 (logSize_pos N).le
  constructor <;> nlinarith [Real.rpow_nonneg (logSize_pos N).le (3*γ)]

theorem r7_lower_barrier_exponent (γ C : ℝ) (hγ : 0 < γ) (hC : 0 ≤ C) :
    ∀ᶠ N : Size in atTop, ∀ q : ℝ,
      (logSize N)^(16*γ) ≤ q → q ≤ logSize N-(logSize N)^(16*γ) →
      2*(logSize N-q)+(logSize N)^(3*γ)/4 ≤
        (max (harmonicExtremeCenter N-(Real.sqrt 2*q-(logSize N)^(3*γ))-
          (logSize N)^(2*γ)-C*Real.log (logSize N)) 0)^2/(logSize N-q+C) := by
  filter_upwards [blockB_logSize_tendsto.eventually_ge_atTop 1,
    blockB_logSize_tendsto.eventually (power_eventually_le_power 1 (2*γ) (3*γ) (1/4) (by linarith) (by norm_num)),
    blockB_logSize_tendsto.eventually (log_eventually_le_power (C+3/(4*Real.sqrt 2)) (3*γ) (1/4) (by positivity) (by norm_num)),
    ((tendsto_rpow_atTop (by positivity : 0 < 3*γ)).comp blockB_logSize_tendsto).eventually_ge_atTop (4*C)]
    with N hL hpow hlog hlarge
  intro q hq hqL
  have hS : 0 ≤ (logSize N)^(3*γ) := Real.rpow_nonneg (logSize_pos N).le _
  have hQ : 0 < (logSize N)^(16*γ) := Real.rpow_pos_of_pos (logSize_pos N) _
  have hr : 0 < logSize N-q := by linarith
  have hSr : (logSize N)^(3*γ) ≤ logSize N-q :=
    (Real.rpow_le_rpow_of_exponent_le hL (by linarith : 3*γ ≤ 16*γ)).trans (by linarith)
  have hbase : Real.sqrt 2*(logSize N-q)+(logSize N)^(3*γ)/2 ≤
      max (harmonicExtremeCenter N-(Real.sqrt 2*q-(logSize N)^(3*γ))-
        (logSize N)^(2*γ)-C*Real.log (logSize N)) 0 := by
    apply le_trans _ (le_max_left _ _)
    rw [harmonicExtremeCenter_eq]
    nlinarith only [hpow,hlog]
  apply (lower_barrier_quadratic_gain (logSize N-q) ((logSize N)^(3*γ)) C hr hS hC hSr hlarge).trans
  apply div_le_div_of_nonneg_right _ (by linarith : 0 ≤ logSize N-q+C)
  apply pow_le_pow_left₀ _ hbase
  positivity

end TorusCoverTime.Blocks.B
