import Solutions.Blocks.B.RootTimeMeasurability
import Solutions.Blocks.B.JumpOccupationRestart
import Solutions.Blocks.B.WalkRenewal

/-! The finite-time occupation Laplace kernel of the original rate-one path.
The first-step identity retains both the physical clock and terminal vertex. -/
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology BigOperators
namespace TorusCoverTime.Blocks.B

def pointOccupationWeight (N : Size) (c a b : Vertex N) (t : ℝ) (ω : WalkSample) : ℝ :=
  if walk N a ω t = b then Real.exp (-localTime N a ω t c) else 0

theorem pointOccupationWeight_joint_measurable (N : Size) (c a b : Vertex N) :
    Measurable (fun p : WalkSample × ℝ => pointOccupationWeight N c a b p.2 p.1) :=
  Measurable.ite (measurable_walk_eq_joint N a b).setOf
    (localTime_joint_measurable N a c).neg.exp measurable_const

theorem pointOccupationWeight_nonneg (N : Size) (c a b : Vertex N) (t : ℝ) (ω : WalkSample) :
    0 ≤ pointOccupationWeight N c a b t ω := by
  unfold pointOccupationWeight
  split_ifs <;> positivity

theorem pointOccupationWeight_le_indicator (N : Size) (c a b : Vertex N) (t : ℝ) (ω : WalkSample) :
    pointOccupationWeight N c a b t ω ≤ if walk N a ω t = b then 1 else 0 := by
  unfold pointOccupationWeight
  split_ifs
  · exact Real.exp_le_one_iff.mpr (neg_nonpos.mpr (localTime_nonneg N a c ω t))
  · rfl

theorem pointOccupationWeight_norm_le_one (N : Size) (c a b : Vertex N) (t : ℝ) (ω : WalkSample) :
    ‖pointOccupationWeight N c a b t ω‖ ≤ 1 := by
  rw [Real.norm_eq_abs,abs_of_nonneg (pointOccupationWeight_nonneg N c a b t ω)]
  exact (pointOccupationWeight_le_indicator N c a b t ω).trans (by split_ifs <;> norm_num)

theorem pointOccupationWeight_integrable (N : Size) (c a b : Vertex N) (t : ℝ) :
    Integrable (pointOccupationWeight N c a b t) walkLaw :=
  Integrable.of_bound
    ((pointOccupationWeight_joint_measurable N c a b).comp
      (measurable_id.prodMk measurable_const)).aestronglyMeasurable 1
    (Eventually.of_forall (pointOccupationWeight_norm_le_one N c a b t))

def pointOccupationKernel (N : Size) (c : Vertex N) (t : ℝ) (a b : Vertex N) : ℝ :=
  ∫ ω, pointOccupationWeight N c a b t ω ∂walkLaw

theorem pointOccupationKernel_measurable (N : Size) (c a b : Vertex N) :
    Measurable (fun t => pointOccupationKernel N c t a b) :=
  (pointOccupationWeight_joint_measurable N c a b).stronglyMeasurable.integral_prod_left.measurable

theorem pointOccupationKernel_nonneg (N : Size) (c a b : Vertex N) (t : ℝ) :
    0 ≤ pointOccupationKernel N c t a b :=
  integral_nonneg (pointOccupationWeight_nonneg N c a b t)

theorem pointOccupationKernel_norm_le_one (N : Size) (c a b : Vertex N) (t : ℝ) :
    ‖pointOccupationKernel N c t a b‖ ≤ 1 := by
  simpa [pointOccupationKernel] using
    norm_integral_le_of_norm_le_const (μ := walkLaw)
      (Eventually.of_forall (pointOccupationWeight_norm_le_one N c a b t))

theorem pointOccupationKernel_le_transition (N : Size) (c a b : Vertex N) (t : ℝ) :
    pointOccupationKernel N c t a b ≤ transitionProbability N a b t := by
  have hm : MeasurableSet {ω : WalkSample | walk N a ω t = b} :=
    ((measurable_walk_eq_joint N a b).comp (measurable_id.prodMk measurable_const)).setOf
  have hi : Integrable (fun ω : WalkSample => if walk N a ω t = b then (1:ℝ) else 0) walkLaw :=
    Integrable.of_bound (Measurable.ite hm measurable_const measurable_const).aestronglyMeasurable
      1 (Eventually.of_forall fun ω => by split_ifs <;> norm_num)
  have h := integral_mono (pointOccupationWeight_integrable N c a b t) hi
    (pointOccupationWeight_le_indicator N c a b t)
  have he := integral_indicator_const (μ := walkLaw) (1:ℝ) hm
  have he' : (∫ ω : WalkSample, if walk N a ω t = b then (1:ℝ) else 0 ∂walkLaw) =
      transitionProbability N a b t := by
    simpa [Set.indicator,transitionProbability,Measure.real] using he
  exact h.trans_eq he'

def pointSitePotential (N : Size) (c a : Vertex N) : ℝ := if a=c then 1 else 0

theorem pointSitePotential_nonneg (N : Size) (c a : Vertex N) : 0 ≤ pointSitePotential N c a := by
  unfold pointSitePotential
  split_ifs <;> norm_num

theorem pointOccupationWeight_first_step (N : Size) (c a b : Vertex N) (t : ℝ) (ht : 0 ≤ t) :
    ∀ᵐ ω ∂walkLaw, pointOccupationWeight N c a b t ω =
      if t < holdingTime ω 0 then
        Real.exp (-pointSitePotential N c a*t)*(if a=b then 1 else 0)
      else Real.exp (-pointSitePotential N c a*holdingTime ω 0)*
        pointOccupationWeight N c (a+direction N (ω 0).2) b (t-holdingTime ω 0) (walkTail ω) := by
  have htail : ∀ᵐ ω ∂walkLaw, Tendsto (jumpTime (walkTail ω)) atTop atTop :=
    (show MeasurePreserving walkTail walkLaw walkLaw from
      ⟨measurable_walkTail,walkTail_law⟩).quasiMeasurePreserving.ae
      (A.holding_positive_and_nonexplosive.mono fun _ h => h.2)
  filter_upwards [A.holding_positive_and_nonexplosive,htail] with ω hreg htail
  have ht0 : jumpTime ω 1 = holdingTime ω 0 := by simp [jumpTime]
  have hp0 : position N a ω 1 = a+direction N (ω 0).2 := by simp [position]
  have het : (fun j => ω (1+j)) = walkTail ω := by funext j; simp [walkTail,Nat.add_comm]
  have hl (s : ℝ) (hs : 0 ≤ s) (hs' : s ≤ holdingTime ω 0) :
      localTime N a ω s c = pointSitePotential N c a*s := by
    have h := localTime_partial_holding N a c hreg.1 hreg.2 0 s hs hs'
    simpa [jumpTime_zero,position_zero,localTime,pointSitePotential,ite_mul] using h
  by_cases hfirst : t < holdingTime ω 0
  · rw [if_pos hfirst,pointOccupationWeight]
    have hw := walk_eq_position_on_holding_interval N a hreg.1 hreg.2 0 t
      (show t ∈ Ico (jumpTime ω 0) (jumpTime ω 1) by simpa [ht0] using And.intro ht hfirst)
    rw [hw,position_zero,hl t ht hfirst.le]
    simp only [neg_mul]
    split_ifs <;> ring
  · rw [if_neg hfirst]
    have hu := sub_nonneg.mpr (le_of_not_gt hfirst)
    have hw := walk_jumpTime_shift N a ω 1 hreg.1 (by simpa only [het] using htail)
      (t-holdingTime ω 0) hu
    have ho := localTime_jump_restart N a c ω 1 hreg.1 (by simpa only [het] using htail)
      (t-holdingTime ω 0) hu
    rw [ht0,add_sub_cancel,hp0,het] at hw ho
    rw [hl _ (by unfold holdingTime; positivity) le_rfl] at ho
    simp only [pointOccupationWeight,hw,ho,neg_add,Real.exp_add,neg_mul]
    split_ifs <;> ring

end TorusCoverTime.Blocks.B
