import Solutions.Blocks.B.BT6ResidualEvent
import Solutions.Blocks.B.DirichletIntegerClockBounds

noncomputable section
open MeasureTheory ProbabilityTheory
open scoped BigOperators
namespace TorusCoverTime.Blocks.B

def bt6ConditionedMean (N : Size) (root : Vertex N) (E : Finset (Vertex N)) (x : Vertex N)
    (q : ℕ) (t a : ℝ) (ξ : FiniteFieldSample N) : ℝ :=
  (∑ z, exitHarmonic N (torusDisk N x (Real.exp ((q:ℝ)+1))) z x*dirichletConditionedField N root E x t ξ z)-a

theorem bt6_conditioned_norm (N : Size) (root : Vertex N) (E : Finset (Vertex N)) (x : Vertex N)
    (q : ℕ) (hDE : torusDisk N x (Real.exp ((q:ℝ)+1))⊆E) (hroot : root∉E)
    (hV : 0<dirichletClockLS N root E x) (t a : ℝ) (ξ : FiniteFieldSample N) :
    bt6ExitNorm N x q (dirichletConditionedField N root E x t ξ) a=
      Real.sqrt ((bt6ConditionedMean N root E x q t a ξ)^2+bt6ResidualSquare N root E x q t ξ) := by
  unfold bt6ExitNorm bt6ConditionedMean bt6ResidualSquare
  rw [dirichlet_conditioned_square_decomposition N root _ E hDE hroot x hV]

theorem bt6_integer_regression_error (N : Size) (root c x : Vertex N) (ρ : ℝ) (M : ℕ)
    (hρ : 0<ρ) (hR : 1≤ρ*(N.val:ℝ)) (hsmall : 2*(ρ*(N.val:ℝ)+1)<N.val)
    (hdeep : periodicDistance x c+(Real.exp ((M:ℝ)+1)+1)≤ρ*(N.val:ℝ)/2)
    (hroot : root∉torusDisk N c (ρ*(N.val:ℝ))) (hL : 1≤logSize N)
    (hV : 0<dirichletClockLS N root (torusDisk N c (ρ*(N.val:ℝ))) x)
    (i : Fin (M+2)) (hi0 : i.val≠0) (hil : i.val≠M+1) (η t a : ℝ)
    (ht : |t-harmonicExtremeCenter N|≤η) (ha : |a-harmonicExtremeCenter N|≤η) (ξ : FiniteFieldSample N) :
    |bt6ConditionedMean N root (torusDisk N c (ρ*(N.val:ℝ))) x i.val t a ξ+Real.sqrt 2*(i.val:ℝ)+
      (bt6IntegerPath N root c x (ρ*(N.val:ℝ)) M hdeep hroot).bridge ξ i|≤
        4*Real.sqrt 2*bt6ClockError ρ+Real.log (logSize N)+2*η := by
  let D := bt6IntegerDomain N c x (ρ*(N.val:ℝ)) M
  have hd := bt6IntegerDomain_mono N c x (ρ*(N.val:ℝ)) M hdeep
  have hr : ∀ j, root∉D j := fun j hh => hroot (bt6IntegerDomain_subset N c x (ρ*(N.val:ℝ)) M hdeep j hh)
  have hz := bt6IntegerDomain_zero N c x (ρ*(N.val:ℝ)) M
  have hl : D (Fin.last (M+1))=torusDisk N c (ρ*(N.val:ℝ)) := bt6IntegerDomain_last N c x (ρ*(N.val:ℝ)) M
  have hv : 0<dirichletClockLS N root (D (Fin.last (M+1))) x := by rwa [hl]
  have hlocal : |dirichletClockLS N root (D i) x-(i.val:ℝ)/2|≤bt6ClockError ρ := by
    have hh := bt6IntegerPath_clock_error N root c x ρ M hρ hR hsmall hdeep hroot i
    rw [bt6IntegerPath_clock] at hh
    simpa only [sparseClockTime,if_neg hil,Nat.cast_one,one_mul] using hh
  have hglobal : |dirichletClockLS N root (D (Fin.last (M+1))) x-logSize N/2|≤bt6ClockError ρ := by
    rw [hl]
    apply dirichlet_macroscopic_clock N root c x ρ hρ hR hsmall hroot
    have hh := Real.exp_pos ((M:ℝ)+1); linarith
  have hh := dirichlet_conditioned_bridge_error N root D hd hr hz x hv i i.val (bt6ClockError ρ) η t a
    (bt6ClockError_pos ρ).le hL hlocal hglobal ht ha ξ
  have hi : D i=torusDisk N x (Real.exp ((i.val:ℝ)+1)) := by simp [D,bt6IntegerDomain,hi0,hil]
  rw [hl,hi] at hh
  exact hh

end TorusCoverTime.Blocks.B
