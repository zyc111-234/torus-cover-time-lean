import Solutions.Blocks.B.PointKillingKernel
import Solutions.Blocks.B.PointOccupationRenewal

/-! The same first-step Volterra equation, now derived from the finite
spectral kernel by the fundamental theorem of calculus. -/
noncomputable section
open MeasureTheory Filter Set Classical
open scoped ENNReal Topology BigOperators
namespace TorusCoverTime.Blocks.B

theorem pointKillingKernel_hasDerivAt_average (N : Size) (c a b : Vertex N) (t : ℝ) :
    HasDerivAt (fun s => pointKillingKernel N c s a b)
      ((∑ d : Fin 4, pointKillingKernel N c t (a+direction N d) b)/4 -
        (1+pointSitePotential N c a)*pointKillingKernel N c t a b) t := by
  convert pointKillingKernel_hasDerivAt N c a b t using 1 ; try rfl
  simp only [generator,Finset.sum_sub_distrib,Finset.sum_const,Finset.card_univ,
    Fintype.card_fin,nsmul_eq_mul,Nat.cast_ofNat,pointSitePotential]
  split_ifs <;> ring

theorem pointKillingKernel_renewal (N : Size) (c a b : Vertex N) (t : ℝ) (ht : 0 ≤ t) :
    pointKillingKernel N c t a b =
      Real.exp (-(1+pointSitePotential N c a)*t)*(if a=b then 1 else 0) +
        ∫ s in Icc 0 t, Real.exp (-(1+pointSitePotential N c a)*s)*
          ((∑ d : Fin 4, pointKillingKernel N c (t-s) (a+direction N d) b)/4) := by
  let r := 1+pointSitePotential N c a
  let A := fun s => (∑ d : Fin 4, pointKillingKernel N c (t-s) (a+direction N d) b)/4
  have hc : Continuous A := by
    apply Continuous.div_const
    apply continuous_finsetSum
    intro d _
    exact (pointKillingKernel_continuous N c _ b).comp (continuous_const.sub continuous_id)
  have hd (s : ℝ) : HasDerivAt (fun u => Real.exp (-r*u)*pointKillingKernel N c (t-u) a b)
      (- (Real.exp (-r*s)*A s)) s := by
    have h := (((hasDerivAt_id s).const_mul (-r)).exp).mul
      ((pointKillingKernel_hasDerivAt_average N c a b (t-s)).comp s
        ((hasDerivAt_const s t).sub (hasDerivAt_id s)))
    simp only [id_eq,mul_one,zero_sub,Function.comp_def] at h
    convert h using 1 <;> try rfl
    dsimp only [A,r]
    ring
  have hi : IntervalIntegrable (fun s => -(Real.exp (-r*s)*A s)) volume 0 t :=
    ((by fun_prop : Continuous (fun s : ℝ => Real.exp (-r*s))).mul hc).neg.intervalIntegrable _ _
  have h := intervalIntegral.integral_eq_sub_of_hasDerivAt (fun s _ => hd s) hi
  rw [intervalIntegral.integral_of_le ht,← integral_Icc_eq_integral_Ioc,integral_neg] at h
  simp only [sub_self,pointKillingKernel_zero,mul_zero,Real.exp_zero,sub_zero,one_mul] at h
  change pointKillingKernel N c t a b = Real.exp (-r*t)*(if a=b then 1 else 0) +
    ∫ s in Icc 0 t, Real.exp (-r*s)*A s
  linarith only [h]

end TorusCoverTime.Blocks.B
