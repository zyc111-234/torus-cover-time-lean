import Solutions.Blocks.B.LatticePaths

/-! Connectivity of the actual circular lattice annulus. The proof reaches
a square of integer radius k inside the annulus and walks along its sides. -/

noncomputable section
open Classical
namespace TorusCoverTime.Blocks.B

def latticeAnnulus (r R : ℝ) : Set LatticePoint := {z | r ≤ latticeRadius z ∧ latticeRadius z < R}

def annularAnchor (k x : ℤ) : ℤ := if 0 ≤ x then k else -k

lemma annularAnchor_abs (k x : ℤ) (hk : 0 ≤ k) : |annularAnchor k x| = k := by
  unfold annularAnchor
  split_ifs <;> simp [abs_of_nonneg hk]

lemma annularAnchor_sq (k x : ℤ) : (annularAnchor k x : ℝ) ^ 2 = (k : ℝ) ^ 2 := by
  unfold annularAnchor
  split_ifs <;> simp

lemma annularAnchor_interval_lower (k x j : ℤ) (hk : 0 ≤ k)
    (h1 : min x (annularAnchor k x) ≤ j) (h2 : j ≤ max x (annularAnchor k x)) :
    min |x| k ≤ |j| := by
  by_cases hx : 0 ≤ x
  · have hj : 0 ≤ j := (le_min hx hk).trans (by simpa [annularAnchor, hx] using h1)
    simpa [annularAnchor, hx, abs_of_nonneg hx, abs_of_nonneg hj] using h1
  · have hx' : x ≤ 0 := le_of_not_ge hx
    have hj : j ≤ 0 := (by simpa [annularAnchor, hx] using h2 : j ≤ max x (-k)).trans
      (max_le hx' (neg_nonpos.mpr hk))
    have hh := neg_le_neg (show j ≤ max x (-k) by simpa [annularAnchor, hx] using h2)
    simpa only [← min_neg_neg, neg_neg, abs_of_nonpos hx', abs_of_nonpos hj] using hh

lemma latticeAnnulus_swap (r R : ℝ) (z : LatticePoint) (hz : z ∈ latticeAnnulus r R) :
    z.swap ∈ latticeAnnulus r R := by simpa only [latticeAnnulus, Set.mem_ofPred_eq, latticeRadius_swap] using hz

lemma lattice_square_radius (k : ℤ) (hk : 0 ≤ k) (a b : ℤ) (ha : |a| ≤ k) (hb : |b| ≤ k) :
    latticeRadius (a, b) ≤ 2 * k := by
  have hkr : 0 ≤ (k : ℝ) := by exact_mod_cast hk
  have har : |(a : ℝ)| ≤ k := by exact_mod_cast ha
  have hbr : |(b : ℝ)| ≤ k := by exact_mod_cast hb
  nlinarith [latticeRadius_sq (a, b), latticeRadius_nonneg (a, b), sq_abs (a : ℝ), sq_abs (b : ℝ),
    abs_nonneg (a : ℝ), abs_nonneg (b : ℝ)]

lemma latticeAnnulus_horizontal (r R : ℝ) (a b y : ℤ)
    (hy : r ≤ |(y : ℝ)|) (ha : latticeRadius (a, y) < R) (hb : latticeRadius (b, y) < R) :
    latticeReachWithin (latticeAnnulus r R) (a, y) (b, y) := by
  apply lattice_horizontal
  intro j hj1 hj2
  exact ⟨hy.trans (latticeRadius_coordinates (j, y)).2,
    (lattice_segment_radius_bound a b j y hj1 hj2).trans_lt (max_lt ha hb)⟩

lemma latticeAnnulus_vertical (r R : ℝ) (x a b : ℤ)
    (hx : r ≤ |(x : ℝ)|) (ha : latticeRadius (x, a) < R) (hb : latticeRadius (x, b) < R) :
    latticeReachWithin (latticeAnnulus r R) (x, a) (x, b) := by
  have h := latticeAnnulus_horizontal r R a b x hx
    (by simpa [latticeRadius, add_comm] using ha)
    (by simpa [latticeRadius, add_comm] using hb)
  exact latticeReachWithin_swap (latticeAnnulus_swap r R) h

lemma latticeAnnulus_anchor_outer (r R : ℝ) (k : ℤ) (hk : 0 < k)
    (hR : 2 * (k : ℝ) < R) (x y : ℤ) (hdom : |y| ≤ |x|)
    (hz : (x, y) ∈ latticeAnnulus r R) : latticeRadius (annularAnchor k x, y) < R := by
  have hkr : 0 < (k : ℝ) := by exact_mod_cast hk
  have hxs := annularAnchor_sq k x
  rcases le_total k |x| with hlarge | hsmall
  · have hx : (k : ℝ) ≤ |(x : ℝ)| := by exact_mod_cast hlarge
    have hrad : latticeRadius (annularAnchor k x, y) ≤ latticeRadius (x, y) := by
      nlinarith [latticeRadius_sq (annularAnchor k x, y), latticeRadius_sq (x, y),
        latticeRadius_nonneg (annularAnchor k x, y), latticeRadius_nonneg (x, y), sq_abs (x : ℝ)]
    exact hrad.trans_lt hz.2
  · exact (lattice_square_radius k hk.le _ y (annularAnchor_abs k x hk.le).le (hdom.trans hsmall)).trans_lt hR

lemma latticeAnnulus_first_segment (r R : ℝ) (k : ℤ) (hk : 0 < k) (hr : r ≤ k)
    (hR : 2 * (k : ℝ) < R) (x y : ℤ) (hdom : |y| ≤ |x|)
    (hz : (x, y) ∈ latticeAnnulus r R) :
    latticeReachWithin (latticeAnnulus r R) (x, y) (annularAnchor k x, y) := by
  have hout := latticeAnnulus_anchor_outer r R k hk hR x y hdom hz
  apply lattice_horizontal
  intro j hj1 hj2
  refine ⟨?_, (lattice_segment_radius_bound x (annularAnchor k x) j y hj1 hj2).trans_lt (max_lt hz.2 hout)⟩
  have hlow := annularAnchor_interval_lower k x j hk.le hj1 hj2
  rcases le_total |x| k with hsmall | hlarge
  · rw [min_eq_left hsmall] at hlow
    have hh : |(x : ℝ)| ≤ |(j : ℝ)| := by exact_mod_cast hlow
    have hrad : latticeRadius (x, y) ≤ latticeRadius (j, y) := by
      nlinarith [latticeRadius_sq (x, y), latticeRadius_sq (j, y),
        latticeRadius_nonneg (x, y), latticeRadius_nonneg (j, y),
        sq_abs (x : ℝ), sq_abs (j : ℝ), abs_nonneg (x : ℝ)]
    exact hz.1.trans hrad
  · rw [min_eq_right hlarge] at hlow
    have hh : (k : ℝ) ≤ |(j : ℝ)| := by exact_mod_cast hlow
    exact hr.trans (hh.trans (latticeRadius_coordinates (j, y)).1)

lemma latticeAnnulus_dominant_reachable (r R : ℝ) (k : ℤ) (hk : 0 < k) (hr : r ≤ k)
    (hR : 2 * (k : ℝ) < R) (x y : ℤ) (hdom : |y| ≤ |x|)
    (hz : (x, y) ∈ latticeAnnulus r R) :
    latticeReachWithin (latticeAnnulus r R) (x, y) (k, k) := by
  have hax : |(annularAnchor k x : ℝ)| = k := by exact_mod_cast annularAnchor_abs k x hk.le
  have hcorner : latticeRadius (annularAnchor k x, k) < R :=
    (lattice_square_radius k hk.le _ k (annularAnchor_abs k x hk.le).le (by simp [abs_of_nonneg hk.le])).trans_lt hR
  have hkk : latticeRadius (k, k) < R :=
    (lattice_square_radius k hk.le k k (by simp [abs_of_nonneg hk.le]) (by simp [abs_of_nonneg hk.le])).trans_lt hR
  have hfirst := latticeAnnulus_first_segment r R k hk hr hR x y hdom hz
  have hsecond := latticeAnnulus_vertical r R (annularAnchor k x) y k (by simpa only [hax] using hr)
    (latticeAnnulus_anchor_outer r R k hk hR x y hdom hz) hcorner
  have hkreal : 0 ≤ (k : ℝ) := by exact_mod_cast hk.le
  have hthird := latticeAnnulus_horizontal r R (annularAnchor k x) k k
    (by simpa only [abs_of_nonneg hkreal] using hr) hcorner hkk
  exact latticeReachWithin_trans (latticeReachWithin_trans hfirst hsecond) hthird

theorem latticeAnnulus_reachable_corner (r R : ℝ) (k : ℤ) (hk : 0 < k) (hr : r ≤ k)
    (hR : 2 * (k : ℝ) < R) (z : LatticePoint) (hz : z ∈ latticeAnnulus r R) :
    latticeReachWithin (latticeAnnulus r R) z (k, k) := by
  rcases le_total |z.2| |z.1| with hdom | hdom
  · exact latticeAnnulus_dominant_reachable r R k hk hr hR z.1 z.2 hdom hz
  · have h := latticeAnnulus_dominant_reachable r R k hk hr hR z.2 z.1 hdom (latticeAnnulus_swap r R z hz)
    exact latticeReachWithin_swap (latticeAnnulus_swap r R) h

theorem latticeAnnulus_preconnected (r R : ℝ) (k : ℤ) (hk : 0 < k) (hr : r ≤ k)
    (hR : 2 * (k : ℝ) < R) : (latticeNeighborGraph.induce (latticeAnnulus r R)).Preconnected := by
  intro x y
  obtain ⟨hx, hcorner, hxc⟩ := latticeAnnulus_reachable_corner r R k hk hr hR x.val x.property
  obtain ⟨hy, hcorner', hyc⟩ := latticeAnnulus_reachable_corner r R k hk hr hR y.val y.property
  exact hxc.trans hyc.symm

end TorusCoverTime.Blocks.B
