import Solutions.Blocks.B.R7LowHarmonicMass

/-! The physical-window recurrence after the actual far-root sum. The terminal
bound n times the window ratio is sufficient; no unproved heat-kernel input
is used to remove that factor before the superexponential iteration. -/

noncomputable section
open MeasureTheory Filter Set Classical
open scoped ENNReal NNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

theorem r7_far_root_outside (γ : ℝ) (hγ : 0 < γ) :
    ∀ᶠ N : Size in atTop, ∀ c root : Vertex N, ∀ q : ℝ,
      0 ≤ q → q ≤ logSize N-(logSize N)^(16*γ) →
      (N.val:ℝ)*Real.exp (-((logSize N)^(16*γ))/2) ≤ periodicDistance c root →
      root ∉ torusDisk N c (Real.exp (q+2*q^γ)) := by
  filter_upwards [blockB_logSize_tendsto.eventually
    (power_eventually_le_power 2 γ (16*γ) (1/4) (by linarith) (by norm_num))] with N hpow
  intro c root q hq hqL hfar hin
  have hqL' := hqL.trans (sub_le_self _ (Real.rpow_nonneg (logSize_pos N).le _))
  have hqpow := Real.rpow_le_rpow hq hqL' hγ.le
  have hQ := Real.rpow_pos_of_pos (logSize_pos N) (16*γ)
  have hrad : Real.exp (q+2*q^γ) < (N.val:ℝ)*Real.exp (-((logSize N)^(16*γ))/2) := by
    have he : Real.exp (logSize N-(logSize N)^(16*γ)/2) =
        (N.val:ℝ)*Real.exp (-((logSize N)^(16*γ))/2) := by
      rw [sub_eq_add_neg,Real.exp_add,show Real.exp (logSize N) = (N.val:ℝ) by
        exact Real.exp_log (lt_trans zero_lt_one (size_real_gt_one N))]
      congr 2
      ring
    rw [← he]
    exact Real.exp_lt_exp.mpr (by linarith)
  have hh := (mem_torusDisk N c root _).mp hin
  rw [periodicDistance_comm root c] at hh
  linarith

def farRootCountedMass (N : Size) (c : Vertex N) (γ q : ℝ) (M : ℕ) (l r : ℝ) : ℝ≥0∞ :=
  ∑ root : Vertex N, if (N.val:ℝ)*Real.exp (-((logSize N)^(16*γ))/2) ≤ periodicDistance c root then
    countedLoopWindowMass N (torusDisk N c (Real.exp (q+q^γ)))
      (torusDisk N c (Real.exp (q+2*q^γ))) root M l r else 0

def normalizedFarRootCountedMass (N : Size) (c : Vertex N) (γ q : ℝ) (M : ℕ) (l r : ℝ) : ℝ≥0∞ :=
  (ENNReal.ofReal (timeScale N))⁻¹ * farRootCountedMass N c γ q M l r

theorem farRootCountedMass_le_length (N : Size) (c : Vertex N) (γ q : ℝ) (M : ℕ) (l r : ℝ) :
    farRootCountedMass N c γ q M l r ≤ ENNReal.ofReal (vertexCount N)*ENNReal.ofReal (r-l) := by
  calc
    _ ≤ ∑ _root : Vertex N, ENNReal.ofReal (r-l) := by
      apply Finset.sum_le_sum
      intro root _
      split_ifs
      · exact countedLoopWindowMass_le_length N _ _ root M l r
      · exact bot_le
    _ = _ := by simp only [Finset.sum_const,Finset.card_univ,nsmul_eq_mul,D.vertexCount_eq_card,ENNReal.ofReal_natCast]

theorem normalizedFarRootCountedMass_le_length (N : Size) (c : Vertex N) (γ q : ℝ) (M : ℕ) (l r : ℝ) :
    normalizedFarRootCountedMass N c γ q M l r ≤ ENNReal.ofReal (vertexCount N*(r-l)/timeScale N) := by
  apply (mul_le_mul' (le_refl ((ENNReal.ofReal (timeScale N))⁻¹))
    (farRootCountedMass_le_length N c γ q M l r)).trans_eq
  rw [← ENNReal.ofReal_inv_of_pos (timeScale_pos N),
    ← ENNReal.ofReal_mul (vertexCount_pos N).le,
    ← ENNReal.ofReal_mul (inv_nonneg.mpr (timeScale_pos N).le)]
  congr 1
  ring

theorem normalizedFarRootCountedMass_ne_top (N : Size) (c : Vertex N) (γ q : ℝ) (M : ℕ) (l r : ℝ) :
    normalizedFarRootCountedMass N c γ q M l r ≠ ∞ :=
  ne_of_lt ((normalizedFarRootCountedMass_le_length N c γ q M l r).trans_lt ENNReal.ofReal_lt_top)

theorem far_root_counted_recurrence (hWalk : WalkModelRegular) (γ : ℝ) (hγ : 0 < γ) (hγ1 : γ ≤ 1) :
    ∀ᶠ N : Size in atTop, ∀ c : Vertex N, ∀ M : ℕ, ∀ q : ℝ,
      (logSize N)^(16*γ) ≤ q → q ≤ logSize N-(logSize N)^(16*γ) → (M:ℝ) ≤ (logSize N)^4+1 →
      ∀ v Δ : ℝ, 0 ≤ v → (M:ℝ)*q^γ ≤ v^2 → 0 ≤ Δ →
      2*r7MeanConstant*Real.exp (-r7MeanExponent*q^γ)*v ≤ Δ → Δ ≤ v → ∀ l r : ℝ,
      let d := (M:ℝ)*Real.exp (2*logSize N-(logSize N)^(16*γ))
      farRootCountedMass N c γ q M l r ≤ farRootLowHarmonicMass N c γ q (v+Δ) l r +
        2*ENNReal.ofReal (2*Real.exp (-(r7ConcentrationConstant/4)*Δ^2/q^γ)) *
          farRootCountedMass N c γ q M (l-d) (r+d) +
        ENNReal.ofReal (vertexCount N)*((M+1:ℕ):ℝ≥0∞)*ENNReal.ofReal (r-l)*
          ENNReal.ofReal (Real.exp (-Real.exp ((logSize N)^(16*γ)/2))) := by
  filter_upwards [r7_physical_window_recurrence hWalk γ hγ hγ1,r7_far_root_outside γ hγ] with N hN hr
  intro c M q hq hqL hM v Δ hv hMv hΔ hlo hhi l r
  let d := (M:ℝ)*Real.exp (2*logSize N-(logSize N)^(16*γ))
  let p := 2*ENNReal.ofReal (2*Real.exp (-(r7ConcentrationConstant/4)*Δ^2/q^γ))
  let e := ((M+1:ℕ):ℝ≥0∞)*ENNReal.ofReal (r-l)*ENNReal.ofReal (Real.exp (-Real.exp ((logSize N)^(16*γ)/2)))
  let far := fun root : Vertex N => (N.val:ℝ)*Real.exp (-((logSize N)^(16*γ))/2) ≤ periodicDistance c root
  let A := fun root l r => if far root then countedLoopWindowMass N (torusDisk N c (Real.exp (q+q^γ)))
    (torusDisk N c (Real.exp (q+2*q^γ))) root M l r else 0
  let B := fun root => if far root then lowHarmonicLoopWindowMass N c root q (v+Δ) l r else 0
  have hstep (root : Vertex N) : A root l r ≤ B root+p*A root (l-d) (r+d)+e := by
    by_cases hfar : far root
    · simp only [A,B,if_pos hfar]
      exact hN c root M q hq hqL hM
        (hr c root q ((Real.rpow_nonneg (logSize_pos N).le _).trans hq) hqL hfar) v Δ hv hMv hΔ hlo hhi l r
    · simp only [A,B,if_neg hfar,zero_mul,mul_zero,zero_add]
      exact bot_le
  have hh := Finset.sum_le_sum (fun root (_ : root ∈ (Finset.univ : Finset (Vertex N))) => hstep root)
  simp only [Finset.sum_add_distrib,← Finset.mul_sum,Finset.sum_const,Finset.card_univ,nsmul_eq_mul] at hh
  have he : (Fintype.card (Vertex N):ℝ≥0∞)*e =
      ENNReal.ofReal (vertexCount N)*((M+1:ℕ):ℝ≥0∞)*ENNReal.ofReal (r-l)*
        ENNReal.ofReal (Real.exp (-Real.exp ((logSize N)^(16*γ)/2))) := by
    rw [D.vertexCount_eq_card,ENNReal.ofReal_natCast]
    dsimp [e]
    ac_rfl
  rw [he] at hh
  exact hh

end TorusCoverTime.Blocks.B
