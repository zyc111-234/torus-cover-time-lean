import Solutions.Blocks.B.PrincipalMode

/-! The principal eigenvalue and variance estimates at the registered capacity scale. -/

noncomputable section
open scoped BigOperators
namespace TorusCoverTime.Blocks.B

lemma killedEigenvalue_le_capacity (N : Size) (A : Finset (Vertex N)) (hA : A ≠ Finset.univ) :
    killedEigenvalue N A ≤ capacity N A / vertexCount N := by
  obtain ⟨q, hq⟩ := exists_greenCharge N A hA
  let v : Vertex N → ℝ := (fun _ => 1) - greenOperator N q
  have hvA : vanishesOn N A v := by
    intro x hx
    change 1 - greenOperator N q x = 0
    rw [show greenOperator N q x = 1 from hq.2 x hx, sub_self]
  have hvmean : spatialMean N v = 1 := by
    dsimp only [v]
    rw [spatialMean_sub, spatialMean_const, greenOperator_mean_zero, sub_zero]
  have hvenergy : energy N v = capacity N A := by
    dsimp only [v]
    rw [energy_const_sub]
    exact (greenCharge_is_minimizer N A q hq).2.2
  have hs : vertexCount N ≤ squareSum N v := by
    have h := square_mean_le_mean_square N v
    rw [hvmean, one_pow] at h
    have h' := (le_div_iff₀ (vertexCount_pos N)).mp h
    simpa only [one_mul, squareSum] using h'
  have hr := killed_rayleigh N A hA v hvA
  rw [hvenergy] at hr
  apply (le_div_iff₀ (vertexCount_pos N)).mpr
  exact (mul_le_mul_of_nonneg_left hs (killedEigenvalue_nonneg N A hA)).trans hr

lemma capacity_div_count_eq_ratio_gap (N : Size) (A : Finset (Vertex N)) :
    capacity N A / vertexCount N = capacityRatio N A * spectralGap N := by
  have hg := (spectralGap_pos N).ne'
  unfold capacityRatio
  field_simp

lemma killedEigenvalue_lt_gap (N : Size) (A : Finset (Vertex N)) (hA : A ≠ Finset.univ)
    (hd : capacityRatio N A < 1) : killedEigenvalue N A < spectralGap N := by
  have h := killedEigenvalue_le_capacity N A hA
  rw [capacity_div_count_eq_ratio_gap] at h
  exact h.trans_lt (by nlinarith [spectralGap_pos N])

lemma principalVariance_nonneg (N : Size) (A : Finset (Vertex N)) (hA : A ≠ Finset.univ) :
    0 ≤ principalVariance N A := by
  have h := square_mean_le_mean_square N (principalMode N A)
  rw [(principalMode_valid N A hA).2.1, one_pow] at h
  exact sub_nonneg.mpr h

lemma principalMode_squareSum (N : Size) (A : Finset (Vertex N)) :
    squareSum N (principalMode N A) = vertexCount N * (1 + principalVariance N A) := by
  rw [squareSum, sum_eq_vertexCount_mean]
  unfold principalVariance
  ring

lemma principalVariance_le_ratio_mul (N : Size) (A : Finset (Vertex N))
    (hA : A ≠ Finset.univ) :
    principalVariance N A ≤ capacityRatio N A * (1 + principalVariance N A) := by
  have hp := poincare_variance N (principalMode N A)
  rw [(principalMode_valid N A hA).2.1, one_pow, mul_one] at hp
  change spectralGap N * (squareSum N (principalMode N A) - vertexCount N) ≤
    energy N (principalMode N A) at hp
  rw [principalMode_energy N A hA, principalMode_squareSum] at hp
  have hdiv : spectralGap N * principalVariance N A ≤
      killedEigenvalue N A * (1 + principalVariance N A) := by
    apply (mul_le_mul_iff_left₀ (vertexCount_pos N)).mp
    nlinarith [hp]
  have hl := killedEigenvalue_le_capacity N A hA
  rw [capacity_div_count_eq_ratio_gap] at hl
  have hv := principalVariance_nonneg N A hA
  have hupper := mul_le_mul_of_nonneg_right hl (show 0 ≤ 1 + principalVariance N A by linarith)
  apply (mul_le_mul_iff_left₀ (spectralGap_pos N)).mp
  nlinarith [hdiv, hupper]

lemma principalVariance_bound (N : Size) (A : Finset (Vertex N))
    (hA : A ≠ Finset.univ) (hd : capacityRatio N A < 1) :
    principalVariance N A ≤ capacityRatio N A / (1 - capacityRatio N A) := by
  apply (le_div_iff₀ (sub_pos.mpr hd)).mpr
  have h := principalVariance_le_ratio_mul N A hA
  nlinarith

lemma capacity_le_principal_energy (N : Size) (A : Finset (Vertex N)) (hA : A ≠ Finset.univ) :
    capacity N A / vertexCount N ≤ killedEigenvalue N A * (1 + principalVariance N A) := by
  have hf := principalMode_valid N A hA
  have hm : spatialMean N ((fun _ => 1) - principalMode N A) = 0 := by
    rw [spatialMean_sub, spatialMean_const, hf.2.1, sub_self]
  have hb : ∀ x ∈ A, ((fun _ : Vertex N => (1 : ℝ)) - principalMode N A) x = 1 := by
    intro x hx
    simp only [Pi.sub_apply, hf.1 x hx, sub_zero]
  have h := capacity_le_energy N A hA _ hm hb
  rw [energy_const_sub, principalMode_energy N A hA, principalMode_squareSum] at h
  apply (div_le_iff₀ (vertexCount_pos N)).mpr
  nlinarith [h]

lemma killedEigenvalue_lower_bound (N : Size) (A : Finset (Vertex N))
    (hA : A ≠ Finset.univ) (hd : capacityRatio N A < 1) :
    (1 - capacityRatio N A) * capacity N A / vertexCount N ≤ killedEigenvalue N A := by
  have hv := principalVariance_le_ratio_mul N A hA
  have hprod : (1 - capacityRatio N A) * (1 + principalVariance N A) ≤ 1 := by nlinarith
  have hc := capacity_le_principal_energy N A hA
  have hs := mul_le_mul_of_nonneg_left hc (sub_pos.mpr hd).le
  calc
    _ = (1 - capacityRatio N A) * (capacity N A / vertexCount N) := by ring
    _ ≤ (1 - capacityRatio N A) *
        (killedEigenvalue N A * (1 + principalVariance N A)) := hs
    _ = killedEigenvalue N A * ((1 - capacityRatio N A) * (1 + principalVariance N A)) := by ring
    _ ≤ killedEigenvalue N A * 1 :=
      mul_le_mul_of_nonneg_left hprod (killedEigenvalue_nonneg N A hA)
    _ = _ := mul_one _

end TorusCoverTime.Blocks.B
