import Solutions.Blocks.B.ExteriorTraversalCountIdentity
import Solutions.Blocks.B.R8NestedCoarseRange

/-! Discharge the annulus inclusions for the exact nested disk used by R8. -/
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B


theorem r8_nested_disk_inclusions (N : Size) (c : Vertex N) (γ q : ℝ)
    (hq : 0 ≤ q) (hl : 0 ≤ r8NestedScale γ q)
    (hsep : r8NestedScale γ q+2*(r8NestedScale γ q)^γ < q) :
    torusDisk N c (Real.exp (r8NestedScale γ q+(r8NestedScale γ q)^γ)) ⊆
      torusDisk N c (Real.exp (r8NestedScale γ q+2*(r8NestedScale γ q)^γ)) ∧
    torusDisk N c (Real.exp (r8NestedScale γ q+2*(r8NestedScale γ q)^γ)) ⊆
      torusDisk N c (Real.exp (q+q^γ)) ∧
    torusDisk N c (Real.exp (q+q^γ)) ⊆ torusDisk N c (Real.exp (q+2*q^γ)) := by
  have hh := Real.rpow_nonneg hq γ
  have hh' := Real.rpow_nonneg hl γ
  refine ⟨torusDisk_subset N c _ _ (Real.exp_le_exp.mpr (by linarith)),
    torusDisk_subset N c _ _ (Real.exp_le_exp.mpr (by linarith)),
    torusDisk_subset N c _ _ (Real.exp_le_exp.mpr (by linarith))⟩

theorem nested_count_exterior_identity (N : Size) (c root : Vertex N) (γ q : ℝ)
    (hq : 0 ≤ q) (hl : 0 ≤ r8NestedScale γ q)
    (hsep : r8NestedScale γ q+2*(r8NestedScale γ q)^γ < q)
    (hr : root ∉ torusDisk N c (Real.exp (q+2*q^γ))) (m : ℕ) (w : Fin (2*m) → Vertex N) :
    let I := torusDisk N c (Real.exp (r8NestedScale γ q+(r8NestedScale γ q)^γ))
    let J := torusDisk N c (Real.exp (r8NestedScale γ q+2*(r8NestedScale γ q)^γ))
    let Q := torusDisk N c (Real.exp (q+q^γ))
    let O := torusDisk N c (Real.exp (q+2*q^γ))
    ∀ᵐ ω ∂walkLaw[|{ω | adaptiveExitWord N (alternatingDomain N I J) root (2*m) ω = w}],
      ∀ t, adaptiveExitTime N (alternatingDomain N I J) root (2*m) ω ≤ t →
        completedTraversalCount N Q O root ω t =
          exteriorTraversalCount N Q O root c m w
            (traversalExteriorData N I J root m ω,t-adaptiveExitTime N (alternatingDomain N I J) root (2*m) ω) := by
  have hi := r8_nested_disk_inclusions N c γ q hq hl hsep
  exact exteriorTraversalCount_actual_ae N _ _ _ _ hi.1 (torusDisk_nonempty N c _ (Real.exp_pos _))
    hi.2.1 hi.2.2 root c hr ((mem_torusDisk N c c _).mpr (by rw [periodicDistance_self_zero]; positivity)) m w


end TorusCoverTime.Blocks.B

