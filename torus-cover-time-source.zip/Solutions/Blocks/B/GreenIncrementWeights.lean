import Solutions.Blocks.B.GreenFarField
import Solutions.Blocks.B.LocalFrequencyCutoff
import Solutions.Blocks.B.SquareShells

/-! Frequency-by-frequency and square-shell bounds for local Green increments. -/

noncomputable section
open scoped BigOperators
namespace TorusCoverTime.Blocks.B

def frequencyMax (N : Size) (k : Vertex N) : ℝ :=
  max (coordinateDistance k.1 0) (coordinateDistance k.2 0)

lemma frequencyMax_pos (N : Size) (k : Vertex N) (hk : k ∈ nonzeroFrequencies N) :
    0 < frequencyMax N k := by
  have hq := frequencyNormSq_pos N k hk
  have h1 := (coordinateDistance_zero_bounds N k.1).1
  have h2 := (coordinateDistance_zero_bounds N k.2).1
  have hm1 := le_max_left (coordinateDistance k.1 0) (coordinateDistance k.2 0)
  have hm2 := le_max_right (coordinateDistance k.1 0) (coordinateDistance k.2 0)
  unfold frequencyMax
  by_contra h
  have hn := le_of_not_gt h
  have hz1 : coordinateDistance k.1 0 = 0 := by linarith
  have hz2 : coordinateDistance k.2 0 = 0 := by linarith
  simp [frequencyNormSq, hz1, hz2] at hq

lemma frequencyMax_sq_le (N : Size) (k : Vertex N) :
    frequencyMax N k ^ 2 ≤ frequencyNormSq N k := by
  unfold frequencyMax frequencyNormSq
  rcases le_total (coordinateDistance k.1 0) (coordinateDistance k.2 0) with h | h
  · rw [max_eq_right h]
    nlinarith [sq_nonneg (coordinateDistance k.1 0)]
  · rw [max_eq_left h]
    nlinarith [sq_nonneg (coordinateDistance k.2 0)]

lemma green_increment_sum (N : Size) (x y : Vertex N) :
    greenKernel N x x - greenKernel N x y =
      ∑ k ∈ nonzeroFrequencies N,
        (1 - finiteCosine N k (x - y)) / (vertexCount N * finiteEigenvalue N k) := by
  rw [greenKernel_diagonal, greenDiagonal_eq_sum, greenKernel,
    Finset.sum_div, Finset.sum_div, ← Finset.sum_sub_distrib]
  apply Finset.sum_congr rfl
  intro k _
  simp only [div_eq_mul_inv, mul_inv_rev]
  ring

lemma green_increment_multiplier (N : Size) (k z : Vertex N)
    (hk : k ∈ nonzeroFrequencies N) (hd : 0 < periodicDistance z 0) :
    (1 - finiteCosine N k z) / (vertexCount N * finiteEigenvalue N k) ≤
      (Real.pi ^ 2 / 2) * min (1 / ((N.val : ℝ) / periodicDistance z 0) ^ 2)
        (1 / frequencyNormSq N k) := by
  let c := Real.pi ^ 2 / 2
  let t := (N.val : ℝ) / periodicDistance z 0
  have hn := vertexCount_pos N
  have hN : 0 < (N.val : ℝ) := lt_trans zero_lt_one (size_real_gt_one N)
  have hq := frequencyNormSq_pos N k hk
  have hl := eigenvalue_pos_of_nonzero N hk
  have hden := mul_pos hn hl
  have hc : 0 < c := by dsimp [c]; positivity
  have ht : 0 < t := div_pos hN hd
  have hscaled : 4 * frequencyNormSq N k ≤ vertexCount N * finiteEigenvalue N k := by
    simpa only [mul_comm] using (div_le_iff₀ hn).mp (eigenvalue_frequency_bounds N k).1
  have hsmall : (1 - finiteCosine N k z) / (vertexCount N * finiteEigenvalue N k) ≤
      c * (1 / t ^ 2) := by
    apply (div_le_iff₀ hden).mpr
    have hmul := mul_le_mul_of_nonneg_left hscaled (show 0 ≤ c * (1 / t ^ 2) by positivity)
    have hid : (c * (1 / t ^ 2)) * (4 * frequencyNormSq N k) =
        2 * Real.pi ^ 2 * frequencyNormSq N k * periodicDistance z 0 ^ 2 / vertexCount N := by
      dsimp [c, t, vertexCount]
      field_simp
      ring
    rw [hid] at hmul
    exact (finiteCosine_increment_quadratic N k z).trans hmul
  have hlarge : (1 - finiteCosine N k z) / (vertexCount N * finiteEigenvalue N k) ≤
      c * (1 / frequencyNormSq N k) := by
    apply (div_le_iff₀ hden).mpr
    have hmul := mul_le_mul_of_nonneg_left hscaled
      (show 0 ≤ c * (1 / frequencyNormSq N k) by positivity)
    have hid : (c * (1 / frequencyNormSq N k)) * (4 * frequencyNormSq N k) = 2 * Real.pi ^ 2 := by
      dsimp [c]
      field_simp
      norm_num
    rw [hid] at hmul
    have hnum : 1 - finiteCosine N k z ≤ 2 := by
      have := Real.neg_one_le_cos (fourierAngle N k z)
      change -1 ≤ finiteCosine N k z at this
      linarith
    have hpi : 2 ≤ 2 * Real.pi ^ 2 := by nlinarith [Real.two_le_pi]
    exact hnum.trans (hpi.trans hmul)
  change _ ≤ c * min (1 / t ^ 2) (1 / frequencyNormSq N k)
  rcases le_total (1 / t ^ 2) (1 / frequencyNormSq N k) with h | h
  · rw [min_eq_left h]
    exact hsmall
  · rw [min_eq_right h]
    exact hlarge

lemma local_frequency_sum (N : Size) (t : ℝ) (ht : 1 ≤ t) :
    (∑ k ∈ nonzeroFrequencies N, min (1 / t ^ 2) (1 / frequencyNormSq N k)) ≤
      8 * (2 + Real.log (max (((N.val / 2 : ℕ) : ℝ) / t) 1)) := by
  classical
  let F := fun r : ℝ => min (1 / t ^ 2) (1 / r ^ 2)
  have hF (r : ℝ) : 0 ≤ F r := by dsimp [F]; positivity
  have hF0 : F 0 = 0 := by
    simp only [F, zero_pow (by decide : 2 ≠ 0), div_zero]
    exact min_eq_right (by positivity)
  calc
    _ ≤ ∑ k ∈ nonzeroFrequencies N, F (frequencyMax N k) := by
      apply Finset.sum_le_sum
      intro k hk
      apply min_le_min le_rfl
      exact one_div_le_one_div_of_le (sq_pos_of_pos (frequencyMax_pos N k hk)) (frequencyMax_sq_le N k)
    _ ≤ ∑ k : Vertex N, F (frequencyMax N k) := by
      apply Finset.sum_le_sum_of_subset_of_nonneg (Finset.subset_univ _)
      intro k _ _
      exact hF _
    _ = ∑ a : ZMod N.val, ∑ b : ZMod N.val,
        F (max (coordinateDistance a 0) (coordinateDistance b 0)) := by
      simp only [Fintype.sum_prod_type, frequencyMax]
    _ ≤ symmetricMaxSum (N.val / 2) F :=
      (sum_centered_two_coordinates_bounds N (fun x y => F (max x y)) (fun x y => hF _)).2
    _ = 8 * ∑ j ∈ Finset.range (N.val / 2), ((j : ℝ) + 1) *
        min (1 / t ^ 2) (1 / ((j : ℝ) + 1) ^ 2) := by
      rw [symmetricMaxSum_shells, hF0, zero_add]
    _ ≤ _ := mul_le_mul_of_nonneg_left (local_frequency_cutoff_sum t ht (N.val / 2)) (by norm_num)

end TorusCoverTime.Blocks.B
