import Solutions.Blocks.B.DirichletResidualAllScales

/-! All residual coordinates at all selected scales are conditioned jointly
on the same actual endpoint. This closes the distinction between individual
conditional tails and the simultaneous residual event. -/

noncomputable section
open MeasureTheory ProbabilityTheory Classical
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

def dirichletResidualFamilyNoise {I : Type*} (N : Size) (root : Vertex N)
    (D : I → Finset (Vertex N)) (E : Finset (Vertex N)) (x : Vertex N)
    (ξ : FiniteFieldSample N) (j : I × Vertex N) : ℝ :=
  dirichletResidualNoise N root (D j.1) E x ξ j.2

theorem dirichletResidualFamilyNoise_measurable {I : Type*} (N : Size) (root : Vertex N)
    (D : I → Finset (Vertex N)) (E : Finset (Vertex N))
    (hDE : ∀ i, D i⊆E) (hroot : root∉E) (x : Vertex N) :
    Measurable (dirichletResidualFamilyNoise N root D E x) := by
  apply measurable_pi_lambda
  intro j
  exact (measurable_pi_apply j.2).comp (dirichletResidualNoise_measurable N root (D j.1) E (hDE j.1) hroot x)

theorem dirichletResidualFamilyNoise_indep_endpoint {I : Type*} [Fintype I]
    (N : Size) (root : Vertex N) (D : I → Finset (Vertex N)) (E : Finset (Vertex N))
    (hDE : ∀ i, D i⊆E) (hroot : root∉E) (x : Vertex N) (hV : 0<dirichletClockLS N root E x) :
    IndepFun (dirichletResidualFamilyNoise N root D E x)
      (fun ξ => dirichletFieldLS N root E ξ x) (finiteFieldLaw N) := by
  let X := dirichletLSCoordinateMap N root E x
  let R := ContinuousLinearMap.pi (fun j : I × Vertex N =>
    dirichletLSCoordinateMap N root E j.2-(dirichletLSCoordinateMap N root E x-dirichletLSCoordinateMap N root (D j.1) x)-
      dirichletResidualSlope N root (D j.1) E x j.2 • X)
  let S := ContinuousLinearMap.pi (fun _ : Unit => X)
  have hj : HasGaussianLaw (fun ξ => (dirichletResidualFamilyNoise N root D E x ξ,
      fun _ : Unit => dirichletFieldLS N root E ξ x)) (finiteFieldLaw N) := by
    apply ((Blocks.D.finiteFieldSample_gaussian N).map_fun (R.prod S)).congr
    exact Filter.Eventually.of_forall (fun ξ => by
      apply Prod.ext <;> funext j <;>
        simp only [R,S,X,id_eq,ContinuousLinearMap.prod_apply,ContinuousLinearMap.pi_apply,
          sub_apply,smul_apply,smul_eq_mul,dirichletLSCoordinateMap_apply,dirichletResidualFamilyNoise,
          dirichletResidualNoise,scalarRegressionResidual,dirichletResidualSlope,
          dirichletLSResidual_eq N root _ E (hDE _) hroot])
  have hz (j : I × Vertex N) (_ : Unit) :
      cov[fun ξ => dirichletResidualFamilyNoise N root D E x ξ j,
        fun ξ => dirichletFieldLS N root E ξ x;finiteFieldLaw N]=0 := by
    have hv : 0<Var[fun ξ => dirichletFieldLS N root E ξ x;finiteFieldLaw N] := by
      rwa [dirichletFieldLS_variance N root E hroot]
    have hg := scalar_gaussian_regression (finiteFieldLaw N) _ _
      (dirichletLSResidual_joint_gaussian N root (D j.1) E (hDE j.1) hroot x j.2) hv
    exact hg.2.1.symm.covariance_eq_zero hg.1.snd.memLp_two hg.1.fst.memLp_two
  simpa only [Function.comp_def,id_eq] using
    (hj.indepFun_of_covariance_eval hz).comp measurable_id (measurable_pi_apply ())

theorem dirichletResidualFamily_condExp_functional {I : Type*} [Fintype I]
    (N : Size) (root : Vertex N) (D : I → Finset (Vertex N)) (E : Finset (Vertex N))
    (hDE : ∀ i, D i⊆E) (hroot : root∉E) (x : Vertex N) (hV : 0<dirichletClockLS N root E x)
    (F : ((I × Vertex N) → ℝ) → ℝ) (hF : Measurable F) (C : ℝ) (hC : ∀ f, ‖F f‖≤C) :
    (finiteFieldLaw N)[fun ξ => F (fun j => dirichletLSResidual N root (D j.1) E x j.2 ξ) |
      MeasurableSpace.comap (fun ξ => dirichletFieldLS N root E ξ x) inferInstance] =ᵐ[finiteFieldLaw N]
        fun ξ => ∫ η, F (fun j => dirichletResidualAtEndpoint N root (D j.1) E x
          (dirichletFieldLS N root E ξ x) η j.2) ∂finiteFieldLaw N := by
  let X := fun ξ => dirichletFieldLS N root E ξ x
  let Y := dirichletResidualFamilyNoise N root D E x
  let f := fun v : ℝ × ((I × Vertex N) → ℝ) =>
    F (fun j => v.2 j+dirichletResidualSlope N root (D j.1) E x j.2*v.1)
  have hX : Measurable X := dirichletFieldLS_measurable N root E x
  have hY : Measurable Y := dirichletResidualFamilyNoise_measurable N root D E hDE hroot x
  have hf : Measurable f := by apply hF.comp; fun_prop
  have hh := Blocks.C.independent_condExp_bounded (finiteFieldLaw N) hX hY
    (dirichletResidualFamilyNoise_indep_endpoint N root D E hDE hroot x hV).symm hf
    (fun v => hC (fun j => v.2 j+dirichletResidualSlope N root (D j.1) E x j.2*v.1))
  have he : (fun ξ => f (X ξ,Y ξ)) = fun ξ => F (fun j => dirichletLSResidual N root (D j.1) E x j.2 ξ) := by
    funext ξ
    apply congrArg F
    funext j
    exact dirichletResidualAtEndpoint_reconstruct N root (D j.1) E x j.2 ξ
  rw [he] at hh
  filter_upwards [hh] with ξ hξ
  rw [hξ]
  exact integral_map hY.aemeasurable
    ((hf.comp (measurable_const.prodMk measurable_id)).aestronglyMeasurable)

end TorusCoverTime.Blocks.B
