import Solutions.Blocks.B.R7CoarseProbe
import Solutions.Blocks.B.R7PhysicalWindow
import Solutions.Blocks.B.S5CoareaTransfer

/-! Concrete low-harmonic source to coarea-image transfer. The image test
depends only on (s,W), and the same global energy cutoff controls the image
window. The Gaussian image tail is the remaining, separate estimate. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal NNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

def harmonicImageRadius (N : Size) (c : Vertex N) (q : ℝ) (z : D.CoareaImage N) : ℝ :=
  Real.sqrt ((∑ x, diskHarmonicWeight N c (Real.exp (q+1)) x*z.2 x)/(2*g))

theorem harmonicImageRadius_measurable (N : Size) (c : Vertex N) (q : ℝ) :
    Measurable (harmonicImageRadius N c q) :=
  ((Finset.measurable_sum _ fun x _ => ((measurable_pi_apply x).comp measurable_snd).const_mul _).div_const (2*g)).sqrt

theorem harmonicPathOccupation_nonneg (N : Size) (c root : Vertex N) (q : ℝ) (z : WalkSample × ℝ) :
    0 ≤ harmonicPathOccupation N c root q z := by
  apply Finset.sum_nonneg
  intro x _
  exact mul_nonneg (div_nonneg (diskHarmonicWeight_nonneg N c _ x) coarseProbe_g_pos.le)
    (localTime_nonneg N root x z.1 z.2)

theorem harmonicImageRadius_source (N : Size) (c root : Vertex N) (q : ℝ)
    (z : D.LoopSource × FiniteFieldSample N) :
    harmonicImageRadius N c q (D.sourceCoareaImage N root z) =
      Real.sqrt (harmonicPathOccupation N c root q (z.1.2,z.1.1)+
        pinnedWeightedEnergy N root (diskHarmonicWeight N c (Real.exp (q+1))) z.2) := by
  unfold harmonicImageRadius D.sourceCoareaImage harmonicPathOccupation pinnedWeightedEnergy
  congr 1
  simp only [mul_add,Finset.sum_add_distrib,add_div,Finset.sum_div]
  congr 1
  apply Finset.sum_congr rfl
  intro x _
  ring

theorem r7_probe_image_radius (N : Size) (c root : Vertex N) (q v Δ : ℝ)
    (hq : 0 ≤ q) (hqv : q ≤ v) (hΔ : 0 ≤ Δ) (z : D.LoopSource × FiniteFieldSample N)
    (hlow : Real.sqrt (harmonicPathOccupation N c root q (z.1.2,z.1.1)) ≤ v+Δ)
    (hprobe : z.2 ∈ r7CoarseProbe N root c q) :
    harmonicImageRadius N c q (D.sourceCoareaImage N root z) ≤ v+Δ+2*coarseProbeRadialConstant := by
  rw [harmonicImageRadius_source]
  have hh : harmonicPathOccupation N c root q (z.1.2,z.1.1) ≤ (v+Δ)^2 := by
    have hs := (sq_le_sq₀ (Real.sqrt_nonneg _) (by linarith : 0 ≤ v+Δ)).mpr hlow
    rwa [Real.sq_sqrt (harmonicPathOccupation_nonneg N c root q _)] at hs
  have he := Real.sqrt_le_sqrt (add_le_add hh hprobe.2.1)
  have hshift := r7_probe_sqrt_shift q v Δ (4*coarseProbeRadialConstant) hq hqv hΔ
    (by have := coarseProbeRadialConstant_pos; positivity)
  have harg : (v+Δ)^2+4*(coarseProbeRadialConstant*q) = (v+Δ)^2+(4*coarseProbeRadialConstant)*q := by ring
  rw [harg] at he
  exact (he.trans hshift).trans_eq (by ring)

def lowHarmonicLoopTest (N : Size) (c root : Vertex N) (q a l r : ℝ) (z : D.LoopSource) : ℝ≥0∞ :=
  if z.1 ∈ Icc l r ∧ Real.sqrt (harmonicPathOccupation N c root q (z.2,z.1)) ≤ a then 1 else 0

theorem lowHarmonicLoopTest_measurable (N : Size) (c root : Vertex N) (q a l r : ℝ) :
    Measurable (lowHarmonicLoopTest N c root q a l r) :=
  measurable_const.ite ((measurable_fst measurableSet_Icc).inter
    (measurableSet_le ((harmonicPathOccupation_measurable N c root q).comp measurable_swap).sqrt measurable_const)) measurable_const

theorem lowHarmonicLoopTest_lintegral (N : Size) (c root : Vertex N) (q a l r : ℝ) :
    (∫⁻ z, lowHarmonicLoopTest N c root q a l r z ∂D.rootedLoopMeasure N root) =
      lowHarmonicLoopWindowMass N c root q a l r := by
  rw [rootedLoop_lintegral N root _ (lowHarmonicLoopTest_measurable N c root q a l r)]
  apply lintegral_congr
  intro ω
  apply lintegral_congr
  intro t
  dsimp only [lowHarmonicLoopTest]
  split_ifs <;> simp_all

def r7HarmonicImageTest (N : Size) (c : Vertex N) (q v Δ l r : ℝ) (z : D.CoareaImage N) : ℝ≥0∞ :=
  if z.1 ∈ Icc l (r+(64*g)*vertexCount N*logSize N/2) ∧
    harmonicImageRadius N c q z ≤ v+Δ+2*coarseProbeRadialConstant then 1 else 0

theorem r7HarmonicImageTest_measurable (N : Size) (c : Vertex N) (q v Δ l r : ℝ) :
    Measurable (r7HarmonicImageTest N c q v Δ l r) :=
  measurable_const.ite ((measurable_fst measurableSet_Icc).inter
    (measurableSet_le (harmonicImageRadius_measurable N c q) measurable_const)) measurable_const

theorem r7_low_harmonic_coarea_transfer (γ : ℝ) (hγ : 0 < γ) (hγ1 : 16*γ < 1) :
    ∀ᶠ N : Size in atTop, ∀ root c : Vertex N, ∀ q : ℝ,
      (logSize N)^(16*γ) ≤ q → q ≤ logSize N-(logSize N)^(16*γ) →
      (N.val:ℝ)*Real.exp (-((logSize N)^(16*γ))/2) ≤ periodicDistance c root →
      ∀ v Δ l r : ℝ, q ≤ v → 0 ≤ Δ →
        ENNReal.ofReal (coarseProbeProbabilityConstant/Real.sqrt (logSize N))*
          lowHarmonicLoopWindowMass N c root q (v+Δ) l r ≤
            ∫⁻ z, r7HarmonicImageTest N c q v Δ l r z ∂D.rootedShellImageMeasure N root := by
  filter_upwards [r7_coarse_probe_mass γ hγ hγ1] with N hN
  intro root c q hq hqL hfar v Δ l r hqv hΔ
  let w := lowHarmonicLoopTest N c root q (v+Δ) l r
  let p := ENNReal.ofReal (coarseProbeProbabilityConstant/Real.sqrt (logSize N))
  let b := fun z : D.LoopSource × FiniteFieldSample N => if z.2 ∈ r7CoarseProbe N root c q then (1 : ℝ≥0∞) else 0
  let F := r7HarmonicImageTest N c q v Δ l r
  have hw := lowHarmonicLoopTest_measurable N c root q (v+Δ) l r
  have hb : Measurable b := measurable_const.ite
    (measurable_snd (r7CoarseProbe_measurable N root c q)) measurable_const
  have hp : p ≤ (finiteFieldLaw N) (r7CoarseProbe N root c q) := by
    exact (ENNReal.ofReal_le_iff_le_toReal (measure_ne_top _ _)).mpr (hN root c q hq hqL hfar)
  have hprob (a : D.LoopSource) : p ≤ ∫⁻ ξ, b (a,ξ) ∂finiteFieldLaw N := by
    have he : (fun ξ => b (a,ξ)) = (r7CoarseProbe N root c q).indicator (fun _ => (1 : ℝ≥0∞)) := by
      funext ξ
      simp [b,Set.indicator]
    rw [he,lintegral_indicator (r7CoarseProbe_measurable N root c q)]
    simpa only [lintegral_one,Measure.restrict_apply_univ] using hp
  have hmajor (z : D.LoopSource × FiniteFieldSample N) : w z.1*b z ≤ F (D.sourceCoareaImage N root z) := by
    by_cases hlow : z.1.1 ∈ Icc l r ∧ Real.sqrt (harmonicPathOccupation N c root q (z.1.2,z.1.1)) ≤ v+Δ
    · by_cases hprobe : z.2 ∈ r7CoarseProbe N root c q
      · have ht := D.coarea_source_time_window N root z l r _ hlow.1 hprobe.2.2
        have hr := r7_probe_image_radius N c root q v Δ
          ((Real.rpow_nonneg (logSize_pos N).le _).trans hq) hqv hΔ z hlow.2 hprobe
        simp [w,lowHarmonicLoopTest,hlow,b,hprobe,F,r7HarmonicImageTest,ht,hr]
      · simp only [b,if_neg hprobe,mul_zero]
        exact bot_le
    · simp only [w,lowHarmonicLoopTest,if_neg hlow,zero_mul]
      exact bot_le
  have hh := s5_counted_probe_transfer N root ({()} : Finset Unit) (fun _ => w) (fun _ => p)
    (fun _ => b) F (fun _ _ => hw) (fun _ _ => hb)
    (r7HarmonicImageTest_measurable N c q v Δ l r) (fun _ _ a _ => hprob a)
    (fun z => by simpa only [Finset.sum_singleton] using hmajor z)
  simp only [Finset.sum_singleton] at hh
  rw [lintegral_mul_const p hw,lowHarmonicLoopTest_lintegral N c root q (v+Δ) l r,mul_comm] at hh
  exact hh

end TorusCoverTime.Blocks.B
