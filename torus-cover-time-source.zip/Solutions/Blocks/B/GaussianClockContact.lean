import Solutions.Blocks.B.GaussianClockFlatBallot
import Solutions.Blocks.B.GaussianClockMarkov
import Solutions.Blocks.B.FiniteIndependentSections

/-! A contact estimate retaining killing on both sides of the visit.  The
future bound is integrated against the actual past/contact coordinate, so no
factor corresponding to near-contact survival is discarded. -/

noncomputable section
open MeasureTheory ProbabilityTheory Classical Set
open scoped ENNReal NNReal
namespace TorusCoverTime.Blocks.B.GaussianClockPath
variable {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
variable {n : ℕ} (W : GaussianClockPath μ n)

theorem path_contact_interval_le {U : ℝ} (h : W.ClockBounds U)
    (k : Fin (n+1)) (hk : 3 ≤ k.val) (hrest : 3 ≤ n-k.val)
    (H b : ℝ) (hH : 0 ≤ H) (hb : 0 ≤ b) :
    μ {ω | W.path ω (Fin.last n) ∈ Icc (-1) 0 ∧
      (∀ i, W.path ω i ≤ H) ∧ H-b ≤ W.path ω k} ≤
      ENNReal.ofReal (1024*b*(H+2*Real.sqrt U+1)*(b+2*Real.sqrt U+1) /
        ((k.val : ℝ)*Real.sqrt k.val)) *
      ENNReal.ofReal (1024*(b+2*Real.sqrt U+1)*(H+1+2*Real.sqrt U+1) /
        ((n-k.val : ℕ)*Real.sqrt ((n-k.val : ℕ) : ℝ))) := by
  let P := W.prefixPath k
  let Q := W.suffix k
  let S : Set (Fin (k.val+1) → ℝ) :=
    {f | f (Fin.last k.val) ∈ Icc (H-b) H ∧ ∀ i, f i ≤ H}
  let E : Set ((Fin (k.val+1) → ℝ) × (Fin (n-k.val+1) → ℝ)) :=
    {z | z.2 (Fin.last (n-k.val)) ∈ Icc (-1-z.1 (Fin.last k.val)) (-z.1 (Fin.last k.val)) ∧
      ∀ i, z.2 i ≤ H-z.1 (Fin.last k.val)}
  let C : ℝ := 1024*(b+2*Real.sqrt U+1)*(H+1+2*Real.sqrt U+1) /
    ((n-k.val : ℕ)*Real.sqrt ((n-k.val : ℕ) : ℝ))
  have hS : MeasurableSet S := by
    apply ((measurable_pi_apply _) measurableSet_Icc).inter
    change MeasurableSet {f : Fin (k.val+1) → ℝ | ∀ i, f i ≤ H}
    rw [Set.ofPred_forall]
    exact MeasurableSet.iInter (fun i => measurableSet_le (measurable_pi_apply i) measurable_const)
  have hE : MeasurableSet E := by
    change MeasurableSet {z : ((Fin (k.val+1) → ℝ) × (Fin (n-k.val+1) → ℝ)) |
      (-1-z.1 (Fin.last k.val) ≤ z.2 (Fin.last (n-k.val)) ∧
       z.2 (Fin.last (n-k.val)) ≤ -z.1 (Fin.last k.val)) ∧
        ∀ i, z.2 i ≤ H-z.1 (Fin.last k.val)}
    apply MeasurableSet.inter
    · exact (measurableSet_le
        (show Measurable (fun z : ((Fin (k.val+1) → ℝ) × (Fin (n-k.val+1) → ℝ)) =>
          -1-z.1 (Fin.last k.val)) by fun_prop)
        (show Measurable (fun z : ((Fin (k.val+1) → ℝ) × (Fin (n-k.val+1) → ℝ)) =>
          z.2 (Fin.last (n-k.val))) by fun_prop)).inter
        (measurableSet_le
          (show Measurable (fun z : ((Fin (k.val+1) → ℝ) × (Fin (n-k.val+1) → ℝ)) =>
            z.2 (Fin.last (n-k.val))) by fun_prop)
          (show Measurable (fun z : ((Fin (k.val+1) → ℝ) × (Fin (n-k.val+1) → ℝ)) =>
            -z.1 (Fin.last k.val)) by fun_prop))
    change MeasurableSet {z : ((Fin (k.val+1) → ℝ) × (Fin (n-k.val+1) → ℝ)) |
      ∀ i, z.2 i ≤ H-z.1 (Fin.last k.val)}
    rw [Set.ofPred_forall]
    exact MeasurableSet.iInter (fun i => measurableSet_le (by fun_prop) (by fun_prop))
  have hsection (f : Fin (k.val+1) → ℝ) (hf : f ∈ S) : μ {ω | (f, Q.path ω) ∈ E} ≤ ENNReal.ofReal C := by
    let t := f (Fin.last k.val)
    have ht : H-b ≤ t ∧ t ≤ H := hf.1
    have he := Q.flat_ballot_thirds (ClockBounds.suffix W h k) hrest (H-t) (-1-t) (-t)
      (by linarith) (by linarith) (by linarith)
    change μ {ω | Q.path ω (Fin.last (n-k.val)) ∈ Icc (-1-t) (-t) ∧
      ∀ i, Q.path ω i ≤ H-t} ≤ _
    refine he.trans (ENNReal.ofReal_le_ofReal ?_)
    have he1 : -t-(-1-t) = 1 := by ring
    have he2 : H-t-(-1-t) = H+1 := by ring
    rw [he1, he2, mul_one]
    dsimp [C]
    gcongr
    linarith
  have hd := independent_sections_le μ P.path Q.path P.measurable Q.measurable (W.prefix_indep_suffix k)
    S hS E hE (ENNReal.ofReal C) hsection
  have hl := P.flat_ballot_thirds (ClockBounds.prefixPath W h k) hk H (H-b) H hH (by linarith) (by linarith)
  rw [show H-(H-b) = b by ring] at hl
  have hsub : {ω | W.path ω (Fin.last n) ∈ Icc (-1) 0 ∧
      (∀ i, W.path ω i ≤ H) ∧ H-b ≤ W.path ω k} ⊆
      {ω | P.path ω ∈ S ∧ (P.path ω, Q.path ω) ∈ E} := by
    intro ω hω
    constructor
    · refine ⟨?_, ?_⟩
      · simpa only [P, W.prefix_last, mem_Icc] using And.intro hω.2.2 (hω.2.1 k)
      · intro i
        simpa only [P, W.prefix_path] using hω.2.1 (prefixIndex k i)
    · change Q.path ω (Fin.last (n-k.val)) ∈ Icc (-1-P.path ω (Fin.last k.val))
          (-P.path ω (Fin.last k.val)) ∧ ∀ i, Q.path ω i ≤ H-P.path ω (Fin.last k.val)
      simp only [P, Q, W.prefix_last, W.suffix_last, W.suffix_path, mem_Icc]
      exact ⟨⟨by linarith [hω.1.1], by linarith [hω.1.2]⟩,
        fun i => sub_le_sub_right (hω.2.1 (suffixIndex k i)) _⟩
  refine (measure_mono hsub).trans (hd.trans ?_)
  calc
    _ ≤ ENNReal.ofReal C * ENNReal.ofReal (1024*b*(H+2*Real.sqrt U+1)*(b+2*Real.sqrt U+1) /
        ((k.val : ℝ)*Real.sqrt k.val)) := mul_le_mul' le_rfl hl
    _ = _ := mul_comm _ _

end TorusCoverTime.Blocks.B.GaussianClockPath
