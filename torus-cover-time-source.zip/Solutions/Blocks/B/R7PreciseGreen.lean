import Solutions.Blocks.B.R7PreciseGeometry

/-! The exponentially accurate R7 Green center, with the actual entrance
tolerance and torus size condition. No asymptotic Green estimate is assumed. -/

noncomputable section
open Filter Classical
namespace TorusCoverTime.Blocks.B

def r7GreenDifferenceConstant : ℝ := Classical.choose green_nearest_differences

theorem r7GreenDifferenceConstant_pos : 0 < r7GreenDifferenceConstant :=
  (Classical.choose_spec green_nearest_differences).1

theorem r7GreenDifferenceConstant_control : NearestGreenControl r7GreenDifferenceConstant :=
  (Classical.choose_spec green_nearest_differences).2

def r7GreenCenterConstant : ℝ :=
  5+35328*greenIncrementConstant+557056*r7GreenDifferenceConstant

theorem r7GreenCenterConstant_pos : 0 < r7GreenCenterConstant := by
  have := greenIncrementConstant_pos
  have := r7GreenDifferenceConstant_pos
  unfold r7GreenCenterConstant
  positivity

theorem r7_green_center_explicit (N : Size) (c a b : Vertex N) (q w : ℝ)
    (hq : 64 ≤ q) (hw : Real.log 8 ≤ w) (hwq : w ≤ q)
    (hsmall : 2*(Real.exp (q+2*w)+1) < N.val)
    (ha : |periodicDistance a c-Real.exp (q+w)| ≤ 2)
    (hb : diskExteriorNeighbor N c (Real.exp (q+2*w)) b) :
    |diskGreen N c (Real.exp (q+2*w)) a c/g-w| ≤ r7GreenCenterConstant*Real.exp (-w/4) := by
  have hw0 : 0 ≤ w := (Real.log_nonneg (by norm_num : (1:ℝ) ≤ 8)).trans hw
  have hq0 : 0 ≤ q := by linarith
  have hg : 0 < g := by unfold g; positivity
  have hC := r7GreenDifferenceConstant_pos
  have hG := greenIncrementConstant_pos
  let C := r7GreenDifferenceConstant
  let G := greenIncrementConstant
  let n := r7GreenCoreSize q
  let E := Real.exp (q+w)
  let R := Real.exp (q+2*w)
  let e := Real.exp (-q/2)
  have hE : 0 < E := Real.exp_pos _
  have hR : 0 < R := Real.exp_pos _
  have he : 0 < e := Real.exp_pos _
  have hgeom := r6_green_geometry N c a c q w hq0 hw ha
    ((mem_torusDisk N c c _).mpr (by rw [periodicDistance_self_zero]; positivity))
  have hn := r7GreenCoreSize_bounds q hq0
  have hn0 : 0 < (n:ℝ) := by exact_mod_cast hn.1
  have hER : E/2 ≤ R := by
    have hh : E ≤ R := Real.exp_le_exp.mpr (by linarith)
    linarith
  have hmain := diskGreen_precise_log_error C hC r7GreenDifferenceConstant_control N c R (E/2)
    (half_pos hE) hER hsmall a b hgeom.2.1 hb hgeom.2.2.2.2.2.1 n hn.1
    (r7_core_separation q w hq hw0)
  have hlog0 : 0 ≤ Real.log (3+2*R) := Real.log_nonneg (by linarith)
  have hbnd : g/R ≤ g*e := by
    rw [div_eq_mul_inv]
    apply mul_le_mul_of_nonneg_left _ hg.le
    change (Real.exp (q+2*w))⁻¹ ≤ Real.exp (-q/2)
    rw [← Real.exp_neg]
    exact Real.exp_le_exp.mpr (by linarith)
  have hmass : (4416*g*G*Real.log (3+2*R))/(n:ℝ) ≤
      (35328*g*G*(q+1))*e := by
    calc
      _ ≤ (4416*g*G*Real.log (3+2*R))/Real.exp (q/2) :=
        div_le_div_of_nonneg_left (by positivity) (Real.exp_pos _) hn.2.1
      _ ≤ (4416*g*G*(8*(q+1)))/Real.exp (q/2) := by
        apply div_le_div_of_nonneg_right _ (Real.exp_pos _).le
        exact mul_le_mul_of_nonneg_left (r7_log_radius_bound q w hq0 hw0 hwq) (by positivity)
      _ = _ := by dsimp [e]; rw [show -q/2 = -(q/2) by ring, Real.exp_neg]; ring
  have hcore : (139264*C*g*(n:ℝ))/(E/2) ≤ (557056*C*g)*e := by
    calc
      _ ≤ (139264*C*g*(2*Real.exp (q/2)))/(E/2) := by
        apply div_le_div_of_nonneg_right _ (half_pos hE).le
        exact mul_le_mul_of_nonneg_left hn.2.2 (by positivity)
      _ = (557056*C*g)*Real.exp (-q/2-w) := by
        dsimp [E]
        rw [show -q/2-w = q/2-(q+w) by ring, Real.exp_sub]
        ring
      _ ≤ (557056*C*g)*e := by
        apply mul_le_mul_of_nonneg_left _ (by positivity)
        exact Real.exp_le_exp.mpr (by linarith)
  have hlog := log_radius_tolerance (periodicDistance a c) E hE hgeom.2.2.2.2.2.1 ha
  have hentrance : |g*Real.log (R/periodicDistance a c)-g*w| ≤ 4*g*e := by
    have hd := (half_pos hE).trans_le hgeom.2.2.2.2.2.1
    rw [Real.log_div hR.ne' hd.ne', show Real.log R = q+2*w from Real.log_exp _,
      show g*(q+2*w-Real.log (periodicDistance a c))-g*w =
        -g*(Real.log (periodicDistance a c)-Real.log E) by rw [Real.log_exp]; ring,
      abs_mul, abs_neg, abs_of_pos hg]
    apply (mul_le_mul_of_nonneg_left hlog hg.le).trans
    calc
      g*(4/E) = 4*g*Real.exp (-(q+w)) := by dsimp [E]; rw [Real.exp_neg]; ring
      _ ≤ 4*g*e := by
        apply mul_le_mul_of_nonneg_left _ (by positivity)
        exact Real.exp_le_exp.mpr (by linarith)
  have hraw : |diskGreen N c R a c-g*w| ≤
      (g+35328*g*G*(q+1)+557056*C*g+4*g)*e := by
    calc
      _ ≤ |diskGreen N c R a c-g*Real.log (R/periodicDistance a c)| +
          |g*Real.log (R/periodicDistance a c)-g*w| := abs_sub_le _ _ _
      _ ≤ (g/R+(4416*g*G*Real.log (3+2*R))/(n:ℝ)+(139264*C*g*(n:ℝ))/(E/2))+
          4*g*e := add_le_add hmain hentrance
      _ ≤ (g*e+(35328*g*G*(q+1))*e+(557056*C*g)*e)+4*g*e := by gcongr
      _ = _ := by ring
  have hcoef : g+35328*g*G*(q+1)+557056*C*g+4*g ≤ g*r7GreenCenterConstant*(q+1) := by
    dsimp [r7GreenCenterConstant, C, G]
    nlinarith [mul_nonneg hg.le hq0,
      mul_nonneg (mul_nonneg hC.le hg.le) hq0]
  have hfinal : |diskGreen N c R a c-g*w| ≤ g*r7GreenCenterConstant*Real.exp (-w/4) := by
    calc
      _ ≤ (g+35328*g*G*(q+1)+557056*C*g+4*g)*e := hraw
      _ ≤ (g*r7GreenCenterConstant)*(q+1)*e := mul_le_mul_of_nonneg_right hcoef he.le
      _ = (g*r7GreenCenterConstant)*((q+1)*e) := by ring
      _ ≤ (g*r7GreenCenterConstant)*Real.exp (-q/4) :=
        mul_le_mul_of_nonneg_left (r7_polynomial_exp_absorption q hq)
          (mul_nonneg hg.le r7GreenCenterConstant_pos.le)
      _ ≤ _ := mul_le_mul_of_nonneg_left (Real.exp_le_exp.mpr (by linarith))
        (mul_nonneg hg.le r7GreenCenterConstant_pos.le)
  rw [show diskGreen N c R a c/g-w = (diskGreen N c R a c-g*w)/g by field_simp <;> ring,
    abs_div, abs_of_pos hg]
  exact (div_le_div_of_nonneg_right hfinal hg.le).trans_eq (by field_simp)

theorem r7_green_center (γ : ℝ) (hγ : 0 < γ) (hγ1 : γ ≤ 1) :
    ∀ᶠ q : ℝ in atTop, ∀ N : Size, ∀ c a b : Vertex N,
      2*(Real.exp (q+2*q^γ)+1) < N.val →
      |periodicDistance a c-Real.exp (q+q^γ)| ≤ 2 →
      diskExteriorNeighbor N c (Real.exp (q+2*q^γ)) b →
      |diskGreen N c (Real.exp (q+2*q^γ)) a c/g-q^γ| ≤
        r7GreenCenterConstant*Real.exp (-(q^γ)/4) := by
  filter_upwards [eventually_ge_atTop (64:ℝ),
    (tendsto_rpow_atTop hγ).eventually_ge_atTop (Real.log 8)] with q hq hw
  intro N c a b hsmall ha hb
  exact r7_green_center_explicit N c a b q (q^γ) hq hw
    (by simpa only [Real.rpow_one] using
      Real.rpow_le_rpow_of_exponent_le (show 1 ≤ q by linarith) hγ1) hsmall ha hb

end TorusCoverTime.Blocks.B
