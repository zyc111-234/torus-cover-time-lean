import Solutions.Blocks.B.CentralPhysicalWindows
import Solutions.Blocks.B.LogarithmicExponentialBudget

/-! R7.P1 for the actual integrated loop law on any fixed central physical
window. The source probe, coarea identity, root averaging and Gaussian tail
are all proved dependencies, rather than additional hypotheses. -/

noncomputable section
open MeasureTheory Filter Set Classical
open scoped ENNReal NNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

theorem gaussian_tail_monotone (a b V W : ℝ) (ha : 0 ≤ a) (hab : a ≤ b)
    (hV : 0 < V) (hVW : V ≤ W) : Real.exp (-b^2/V) ≤ Real.exp (-a^2/W) := by
  have hfrac : a^2/W ≤ b^2/V := by
    calc
      _ ≤ b^2/W := div_le_div_of_nonneg_right (by nlinarith) (hV.le.trans hVW)
      _ ≤ _ := div_le_div_of_nonneg_left (sq_nonneg _) hV hVW
  exact Real.exp_le_exp.mpr (by simpa only [neg_div] using neg_le_neg hfrac)

theorem r7_low_harmonic_mass (γ H : ℝ) (hγ : 0 < γ) (hγ1 : 16*γ < 1) (hH : 0 ≤ H) :
    ∃ c₀ C : ℝ, 0 < c₀ ∧ 0 < C ∧ ∀ᶠ N : Size in atTop,
      ∀ c : Vertex N, ∀ q v Δ l r : ℝ,
        (logSize N)^(16*γ) ≤ q → q ≤ logSize N-(logSize N)^(16*γ) → q ≤ v → 0 ≤ Δ →
        phaseACenter N-H*timeScale N ≤ l → r ≤ phaseACenter N+H*timeScale N →
        normalizedFarRootLowHarmonicMass N c γ q (v+Δ) l r ≤
          ENNReal.ofReal (C*Real.sqrt (logSize N)*Real.exp (-(max
            (harmonicExtremeCenter N-v-Δ-C*Real.log (logSize N)) 0)^2/(logSize N-q+C))) +
          ENNReal.ofReal (Real.exp (-c₀*logSize N*Real.log (logSize N))) := by
  obtain ⟨c₀,C₀,hc₀,hC₀,hbound⟩ := central_low_harmonic_bound γ H hγ hγ1 hH
  let P := 2*(2*H+32)/coarseProbeProbabilityConstant
  let S := harmonicShellTailShift (r7ShellWindowRadius H)
  let C := 1+4*P*C₀+2*coarseProbeRadialConstant+S+2*harmonicVarianceErrorConstant
  have hP : 0 < P := by dsimp [P]; exact div_pos (by positivity) coarseProbeProbabilityConstant_pos
  have hS : 0 ≤ S := by
    dsimp [S,harmonicShellTailShift]
    exact add_nonneg (harmonicShellCenterError_nonneg _ (r7ShellWindowRadius_nonneg H hH)) (by positivity)
  have hrad := coarseProbeRadialConstant_pos
  have hvar := harmonicVarianceErrorConstant_pos
  have hC : 0 < C := by dsimp [C]; positivity
  have hmain : 4*P*C₀ ≤ C := by dsimp [C]; nlinarith
  have hshift : 2*coarseProbeRadialConstant+S ≤ C := by dsimp [C]; nlinarith
  have hden : 2*harmonicVarianceErrorConstant ≤ C := by dsimp [C]; nlinarith
  have hlog := Real.tendsto_log_atTop.comp blockB_logSize_tendsto
  refine ⟨c₀/2,C,by positivity,hC,?_⟩
  filter_upwards [hbound,r7_shell_remainder_absorption c₀ (P*C₀) hc₀ (by positivity),
    hlog.eventually_ge_atTop 1] with N hN herr hl
  change 1 ≤ Real.log (logSize N) at hl
  intro c q v Δ l r hq hqL hqv hΔ hleft hright
  have hh := hN c q v Δ l r hq hqL hqv hΔ hleft hright
  have hprobe := coarseProbeProbabilityConstant_pos
  let E := Real.exp (-(max (harmonicExtremeCenter N-v-Δ-
    2*coarseProbeRadialConstant-S*Real.log (logSize N)) 0)^2/
      (logSize N-q+2*harmonicVarianceErrorConstant))
  have hprecise : normalizedFarRootLowHarmonicMass N c γ q (v+Δ) l r ≤
      ENNReal.ofReal ((4*P*C₀)*Real.sqrt (logSize N)*E) +
      ENNReal.ofReal ((P*C₀)*Real.sqrt (logSize N)*vertexCount N*logSize N^2*
        Real.exp (-c₀*logSize N*Real.log (logSize N))) := by
    apply hh.trans_eq
    rw [r7ShellTailBudget,mul_add,← ENNReal.ofReal_mul (by positivity),
      ← ENNReal.ofReal_mul (by positivity)]
    congr 1 <;> congr 1 <;> dsimp [P,S,E] <;> ring
  apply hprecise.trans
  apply add_le_add _ (ENNReal.ofReal_le_ofReal herr)
  apply ENNReal.ofReal_le_ofReal
  have hqL' : q ≤ logSize N := hqL.trans (sub_le_self _ (Real.rpow_nonneg (logSize_pos N).le _))
  have hV : 0 < logSize N-q+2*harmonicVarianceErrorConstant := by linarith
  have hs : 2*coarseProbeRadialConstant+S*Real.log (logSize N) ≤ C*Real.log (logSize N) := by
    have h1 := mul_le_mul_of_nonneg_left hl (by positivity : 0 ≤ 2*coarseProbeRadialConstant)
    have h2 := mul_le_mul_of_nonneg_right hshift (by linarith : 0 ≤ Real.log (logSize N))
    nlinarith
  have he : E ≤ Real.exp (-(max (harmonicExtremeCenter N-v-Δ-C*Real.log (logSize N)) 0)^2/(logSize N-q+C)) := by
    apply gaussian_tail_monotone _ _ _ _ (le_max_right _ _)
    · apply max_le_max _ le_rfl
      linarith
    · exact hV
    · linarith
  exact mul_le_mul (mul_le_mul_of_nonneg_right hmain (Real.sqrt_nonneg _)) he
    (Real.exp_pos _).le (by positivity)

end TorusCoverTime.Blocks.B
