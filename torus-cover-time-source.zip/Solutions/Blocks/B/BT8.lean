import Solutions.Blocks.B.BT8Conclusion
import Solutions.Blocks.A.ModelRegularity

/-! B-T8 entry point: bt8_conclusion and bt8_paper_gamma prove the original
root-summed soft-contact count limit in compact Phase A physical windows. -/

namespace TorusCoverTime.Blocks.B

/-- The concrete walk satisfies the regularity hypotheses used by the proof. -/
theorem bt8_actual_conclusion (γ u : ℝ) (hγ : 0<γ) (hmargin : 160*γ<1/20)
    (hu : 0≤u) : BT8Conclusion γ u :=
  bt8_conclusion A.walk_model_regular γ u hγ hmargin hu

theorem bt8_actual_paper_gamma (u : ℝ) (hu : 0≤u) : BT8Conclusion (1/8192) u :=
  bt8_paper_gamma A.walk_model_regular u hu

end TorusCoverTime.Blocks.B
