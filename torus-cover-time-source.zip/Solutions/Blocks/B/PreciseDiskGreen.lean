import Solutions.Blocks.B.GreenSourceRepresentation
import Solutions.Blocks.B.TorusLogCore

/-! A quantitative logarithmic center for the actual disk Green function.
All error terms are explicit: boundary discretization, normalized core mass,
core oscillation, and the summable source tail. -/

noncomputable section
open Classical
namespace TorusCoverTime.Blocks.B

theorem finite_source_center_error {ι : Type*} [DecidableEq ι]
    (D S : Finset ι) (hSD : S ⊆ D) (s K : ι → ℝ) (k M B η V T : ℝ)
    (hM : |(∑ z ∈ S, s z)-1| ≤ M) (hk : |k| ≤ B)
    (hη : 0 ≤ η) (hB : 0 ≤ B)
    (hcore : ∀ z ∈ S, |K z-k| ≤ η) (htail : ∀ z ∈ D \ S, |K z| ≤ B)
    (hV : (∑ z ∈ S, |s z|) ≤ V) (hT : (∑ z ∈ D \ S, |s z|) ≤ T) :
    |(∑ z ∈ D, s z*K z)-k| ≤ M*B+η*V+B*T := by
  have he : (∑ z ∈ D, s z*K z)-k =
      ((∑ z ∈ S, s z)-1)*k + (∑ z ∈ S, s z*(K z-k)) +
        ∑ z ∈ D \ S, s z*K z := by
    have hsplit := Finset.sum_sdiff hSD (f := fun z => s z*K z)
    simp only [mul_sub, Finset.sum_sub_distrib, ← Finset.sum_mul]
    linarith
  have h1 : |((∑ z ∈ S, s z)-1)*k| ≤ M*B := by
    rw [abs_mul]
    exact mul_le_mul hM hk (abs_nonneg _) ((abs_nonneg _).trans hM)
  have h2 : |∑ z ∈ S, s z*(K z-k)| ≤ η*V := by
    calc
      _ ≤ ∑ z ∈ S, |s z*(K z-k)| := Finset.abs_sum_le_sum_abs _ _
      _ ≤ ∑ z ∈ S, η*|s z| := by
        apply Finset.sum_le_sum
        intro z hz
        rw [abs_mul]
        exact (mul_le_mul_of_nonneg_left (hcore z hz) (abs_nonneg _)).trans_eq (mul_comm _ _)
      _ = η*(∑ z ∈ S, |s z|) := (Finset.mul_sum ..).symm
      _ ≤ η*V := mul_le_mul_of_nonneg_left hV hη
  have h3 : |∑ z ∈ D \ S, s z*K z| ≤ B*T := by
    calc
      _ ≤ ∑ z ∈ D \ S, |s z*K z| := Finset.abs_sum_le_sum_abs _ _
      _ ≤ ∑ z ∈ D \ S, B*|s z| := by
        apply Finset.sum_le_sum
        intro z hz
        rw [abs_mul]
        exact (mul_le_mul_of_nonneg_left (htail z hz) (abs_nonneg _)).trans_eq (mul_comm _ _)
      _ = B*(∑ z ∈ D \ S, |s z|) := (Finset.mul_sum ..).symm
      _ ≤ B*T := mul_le_mul_of_nonneg_left hT hB
  rw [he]
  exact (abs_add_le _ _).trans
    (add_le_add ((abs_add_le _ _).trans (add_le_add h1 h2)) h3)

theorem disk_log_boundary_error (N : Size) (c : Vertex N) (R : ℝ) (hR : 0 < R)
    (hsmall : 2*(R+1) < N.val) (a : Vertex N) (ha : a ∈ torusDisk N c R) :
    |exitExtension N (torusDisk N c R) (torusLogPotential N c) a-g*Real.log R| ≤ g/R := by
  have hg : 0 < g := by unfold g; positivity
  apply diskExitExtension_abs_error N c R hR.le hsmall a ha
  intro b hb
  have hr := diskExteriorNeighbor_radius N c R b hb
  have hd := hR.trans_le hr.1
  have hlo : 0 ≤ Real.log (periodicDistance b c)-Real.log R :=
    sub_nonneg.mpr (Real.log_le_log hR hr.1)
  have hu := Real.log_le_sub_one_of_pos (div_pos hd hR)
  rw [Real.log_div hd.ne' hR.ne'] at hu
  have hfrac : periodicDistance b c/R-1 ≤ 1/R := by
    apply (le_div_iff₀ hR).mpr
    rw [sub_mul, div_mul_cancel₀ _ hR.ne', one_mul]
    linarith [hr.2]
  change |g*Real.log (periodicDistance b c)-g*Real.log R| ≤ _
  rw [← mul_sub, abs_mul, abs_of_pos hg, abs_of_nonneg hlo]
  exact (mul_le_mul_of_nonneg_left (hu.trans hfrac) hg.le).trans_eq (mul_one_div _ _)

theorem diskGreen_precise_log_error (C : ℝ) (hC : 0 < C) (hNear : NearestGreenControl C)
    (N : Size) (c : Vertex N) (R ρ : ℝ) (hρ : 0 < ρ) (hρR : ρ ≤ R)
    (hsmall : 2*(R+1) < N.val) (a b : Vertex N)
    (ha : a ∈ torusDisk N c R) (hb : diskExteriorNeighbor N c R b)
    (hsep : ρ ≤ periodicDistance a c) (n : ℕ) (hn : 0 < n) (hnρ : 8*(n:ℝ) ≤ ρ) :
    |diskGreen N c R a c-g*Real.log (R/periodicDistance a c)| ≤
      g/R + (4416*g*greenIncrementConstant*Real.log (3+2*R))/(n:ℝ) +
        (139264*C*g*(n:ℝ))/ρ := by
  have hR := hρ.trans_le hρR
  have hn0 : 0 < (n:ℝ) := by exact_mod_cast hn
  have hnR : 2*(n:ℝ) < R := by linarith
  have hnN : 2*((n:ℝ)+1) < N.val := by linarith
  have hg : 0 < g := by unfold g; positivity
  let D := torusDisk N c R
  let S := torusLogCore N c n
  let B := 2*greenIncrementConstant*Real.log (3+2*R)
  let η := 64*C*(n:ℝ)/ρ
  have hB : 0 ≤ B := mul_nonneg (by have := greenIncrementConstant_pos; positivity)
    (Real.log_nonneg (by linarith))
  have hη : 0 ≤ η := by dsimp [η]; positivity
  have hSD : S ⊆ D := by
    intro z hz
    exact (mem_torusDisk N c z R).mpr
      ((torusLogCore_radius N c n (by linarith) z hz).trans_lt hnR)
  have hlocal (z : Vertex N) (hz : z ∈ D) : 2*(periodicDistance z c+1) < N.val := by
    have hh := (mem_torusDisk N c z R).mp hz
    linarith
  have hcore (z : Vertex N) (hz : z ∈ S) : |diskGreen N c R a z-diskGreen N c R a c| ≤ η := by
    have hd := torusLogCore_radius N c n (by linarith) z hz
    apply (diskGreen_second_difference_of_nearest C hC hNear N c R ρ hρ hρR hsmall a z ha hsep
      (by linarith)).trans
    change 32*C*periodicDistance z c/ρ ≤ 64*C*(n:ℝ)/ρ
    apply div_le_div_of_nonneg_right _ hρ.le
    nlinarith [mul_le_mul_of_nonneg_left hd hC.le]
  have hvariation : (∑ z ∈ S, |torusLogSource N c z|) ≤ 2176*g :=
    torusLogSource_variation N c S (fun z hz => hlocal z (hSD hz))
  have htail : (∑ z ∈ D \ S, |torusLogSource N c z|) ≤ (2176*g)/(n:ℝ) :=
    torusLogSource_tail N c (D \ S) n hn0
      (fun z hz => (torusLogCore_outside N c n z (Finset.mem_sdiff.mp hz).2).le)
      (fun z hz => hlocal z (Finset.mem_sdiff.mp hz).1)
  have hsource := finite_source_center_error D S hSD (torusLogSource N c)
    (diskGreen N c R a) (diskGreen N c R a c) ((32*g)/(n:ℝ)) B η (2176*g) ((2176*g)/(n:ℝ))
    (torusLogCore_normalized N c n hn hnN) (diskGreen_all_log_bound N c R hR.le hsmall b a c hb)
    hη hB hcore (fun z _ => diskGreen_all_log_bound N c R hR.le hsmall b a z hb) hvariation htail
  have hrep := diskGreen_source N c R hR.le hsmall (torusLogPotential N c) a
  change exitExtension N D (torusLogPotential N c) a-torusLogPotential N c a =
    ∑ z ∈ D, torusLogSource N c z*diskGreen N c R a z at hrep
  rw [← hrep] at hsource
  have hbnd := disk_log_boundary_error N c R hR hsmall a ha
  have hid : diskGreen N c R a c-g*Real.log (R/periodicDistance a c) =
      (exitExtension N D (torusLogPotential N c) a-g*Real.log R)-
        (exitExtension N D (torusLogPotential N c) a-torusLogPotential N c a-diskGreen N c R a c) := by
    rw [Real.log_div hR.ne' (hρ.trans_le hsep).ne']
    unfold torusLogPotential
    ring
  rw [hid]
  apply (abs_sub _ _).trans ((add_le_add hbnd hsource).trans_eq _)
  dsimp [B, η]
  ring

end TorusCoverTime.Blocks.B
