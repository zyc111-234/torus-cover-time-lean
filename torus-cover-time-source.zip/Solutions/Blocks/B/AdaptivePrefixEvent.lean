import Solutions.Blocks.B.AdaptiveExitChain

/-! A finite adaptive exit certificate. Each exit must actually occur, so
the default exit index of a non-exiting padded sample cannot certify an exit.
The certificate is measurable and depends only on the specified prefix. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

def adaptivePrefixEvent (N : Size) (D : ℕ → Finset (Vertex N)) (a : Vertex N)
    (n k : ℕ) : Set WalkSample :=
  {ω | adaptiveExitIndex N D a k ω ≤ n ∧ ∀ j < k, ∃ t : ℕ,
    position N (adaptiveExitStart N D a j ω) (adaptiveExitTail N D a j ω) t ∉ D j}

theorem measurableSet_variable_eventualExit (N : Size) (D : Finset (Vertex N))
    (A : WalkSample → Vertex N) (T : WalkSample → WalkSample)
    (hA : Measurable A) (hT : Measurable T) :
    MeasurableSet {ω | ∃ t : ℕ, position N (A ω) (T ω) t ∉ D} := by
  have he : {ω | ∃ t : ℕ, position N (A ω) (T ω) t ∉ D} =
      ⋃ a : Vertex N, {ω | A ω = a} ∩ T ⁻¹' {η | ∃ t : ℕ, position N a η t ∉ D} := by
    ext ω
    simp only [mem_ofPred_eq, mem_iUnion, mem_inter_iff, mem_preimage]
    constructor
    · intro h
      exact ⟨A ω, rfl, h⟩
    · rintro ⟨a, ha, h⟩
      simpa only [ha] using h
  rw [he]
  apply MeasurableSet.iUnion
  intro a
  apply (hA (measurableSet_singleton a)).inter
  apply hT
  simp only [Set.ofPred_exists]
  exact MeasurableSet.iUnion fun t => (measurableSet_position_mem N a D t).compl

theorem adaptivePrefixEvent_measurable (N : Size) (D : ℕ → Finset (Vertex N))
    (a : Vertex N) (n k : ℕ) : MeasurableSet (adaptivePrefixEvent N D a n k) := by
  have he : adaptivePrefixEvent N D a n k =
      {ω | adaptiveExitIndex N D a k ω ≤ n} ∩
        ⋂ j : Fin k, {ω | ∃ t : ℕ,
          position N (adaptiveExitStart N D a j.val ω)
            (adaptiveExitTail N D a j.val ω) t ∉ D j.val} := by
    ext ω
    simp only [adaptivePrefixEvent, mem_ofPred_eq, mem_inter_iff, mem_iInter]
    constructor
    · rintro ⟨h, he⟩
      exact ⟨h, fun j => he j.val j.isLt⟩
    · rintro ⟨h, he⟩
      exact ⟨h, fun j hj => he ⟨j,hj⟩⟩
  rw [he]
  exact (measurableSet_le (adaptiveExitIndex_measurable N D a k) measurable_const).inter
    (MeasurableSet.iInter fun j => measurableSet_variable_eventualExit N (D j.val) _ _
      (adaptiveExitStart_measurable N D a j.val) (adaptiveExitTail_measurable N D a j.val))

theorem adaptiveExit_prefix_step (N : Size) (D : ℕ → Finset (Vertex N)) (a : Vertex N)
    (n j : ℕ) {ω η : WalkSample} (hp : ∀ i < n, η i = ω i)
    (hi : adaptiveExitIndex N D a j η = adaptiveExitIndex N D a j ω)
    (hn : adaptiveExitIndex N D a (j+1) ω ≤ n)
    (hexit : ∃ t : ℕ,
      position N (adaptiveExitStart N D a j ω) (adaptiveExitTail N D a j ω) t ∉ D j) :
    adaptiveExitIndex N D a (j+1) η = adaptiveExitIndex N D a (j+1) ω ∧
      ∃ t : ℕ, position N (adaptiveExitStart N D a j η)
        (adaptiveExitTail N D a j η) t ∉ D j := by
  have hs : adaptiveExitIndex N D a j ω ≤ n :=
    (adaptiveExitIndex_mono N D a ω (Nat.le_succ j)).trans hn
  have ha : adaptiveExitStart N D a j η = adaptiveExitStart N D a j ω := by
    change position N a η (adaptiveExitIndex N D a j η) = _
    rw [hi]
    exact A.position_eq_of_prefix N a n hp _ hs
  let t := finiteExitIndex N (D j) (adaptiveExitStart N D a j ω) (adaptiveExitTail N D a j ω)
  have hst : adaptiveExitIndex N D a j ω+t ≤ n := hn
  have htail : ∀ i < t, adaptiveExitTail N D a j η i = adaptiveExitTail N D a j ω i := by
    intro i hit
    change η (adaptiveExitIndex N D a j η+i) = ω (adaptiveExitIndex N D a j ω+i)
    rw [hi]
    exact hp _ (by omega)
  have hw := finiteExitIndex_spec N (D j) (adaptiveExitStart N D a j ω)
    (adaptiveExitTail N D a j ω) hexit
  have he := (exitsThroughAt_prefix N (D j) (adaptiveExitStart N D a j ω) _ t htail).mpr hw
  have ht : finiteExitIndex N (D j) (adaptiveExitStart N D a j η)
      (adaptiveExitTail N D a j η) = t := by
    rw [ha]
    exact finiteExitIndex_of_exit_word N (D j) _ _ _ t he
  refine ⟨?_, t, ?_⟩
  · rw [adaptiveExitIndex_succ, adaptiveExitIndex_succ, hi, ht]
  · rw [ha, he.2.1]
    exact he.1

theorem adaptivePrefixEvent_transfer (N : Size) (D : ℕ → Finset (Vertex N))
    (a : Vertex N) (n : ℕ) {ω η : WalkSample} (hp : ∀ i < n, η i = ω i) (k : ℕ)
    (hω : ω ∈ adaptivePrefixEvent N D a n k) :
    η ∈ adaptivePrefixEvent N D a n k ∧
      adaptiveExitIndex N D a k η = adaptiveExitIndex N D a k ω := by
  induction k with
  | zero => exact ⟨⟨by simp, by simp⟩, rfl⟩
  | succ k ih =>
    have hpre : ω ∈ adaptivePrefixEvent N D a n k :=
      ⟨(adaptiveExitIndex_mono N D a ω (Nat.le_succ k)).trans hω.1,
        fun j hj => hω.2 j (by omega)⟩
    obtain ⟨hη, hi⟩ := ih hpre
    obtain ⟨hi', he⟩ := adaptiveExit_prefix_step N D a n k hp hi hω.1 (hω.2 k (by omega))
    refine ⟨⟨by rw [hi']; exact hω.1, ?_⟩, hi'⟩
    intro j hj
    by_cases hjk : j < k
    · exact hη.2 j hjk
    · have hjk' : j = k := by omega
      simpa only [hjk'] using he

theorem adaptivePrefixEvent_prefix (N : Size) (D : ℕ → Finset (Vertex N))
    (a : Vertex N) (n k : ℕ) {ω η : WalkSample} (hp : ∀ i < n, η i = ω i) :
    η ∈ adaptivePrefixEvent N D a n k ↔ ω ∈ adaptivePrefixEvent N D a n k := by
  constructor
  · intro h
    exact (adaptivePrefixEvent_transfer N D a n (fun i hi => (hp i hi).symm) k h).1
  · intro h
    exact (adaptivePrefixEvent_transfer N D a n hp k h).1

end TorusCoverTime.Blocks.B
