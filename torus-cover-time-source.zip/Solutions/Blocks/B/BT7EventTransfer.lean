import Solutions.Blocks.B.BT7Goal
import Mathlib.Analysis.InnerProductSpace.PiL2

noncomputable section
open Classical
open scoped BigOperators
namespace TorusCoverTime.Blocks.B

theorem weighted_sqrt_lipschitz {I : Type*} [Fintype I] (w f g : I → ℝ) (d : ℝ)
    (hw : ∀ i, 0≤w i) (hs : ∑ i, w i=1) (hd : 0≤d)
    (hfg : ∀ i, w i≠0 → |f i-g i|≤d) :
    |Real.sqrt (∑ i, w i*(f i)^2)-Real.sqrt (∑ i, w i*(g i)^2)|≤d := by
  let F : EuclideanSpace ℝ I := WithLp.toLp 2 (fun i => Real.sqrt (w i)*f i)
  let G : EuclideanSpace ℝ I := WithLp.toLp 2 (fun i => Real.sqrt (w i)*g i)
  have hF : ‖F‖=Real.sqrt (∑ i, w i*(f i)^2) := by
    rw [EuclideanSpace.norm_eq]
    simp [F,Real.norm_eq_abs,mul_pow,Real.sq_sqrt (hw _)]
  have hG : ‖G‖=Real.sqrt (∑ i, w i*(g i)^2) := by
    rw [EuclideanSpace.norm_eq]
    simp [G,Real.norm_eq_abs,mul_pow,Real.sq_sqrt (hw _)]
  have hn : ‖F-G‖^2≤d^2 := by
    rw [EuclideanSpace.real_norm_sq_eq]
    calc
      _ = ∑ i, w i*(f i-g i)^2 := by
        apply Finset.sum_congr rfl
        intro i _
        change (Real.sqrt (w i)*f i-Real.sqrt (w i)*g i)^2=_
        rw [← mul_sub,mul_pow,Real.sq_sqrt (hw i)]
      _ ≤ ∑ i, w i*d^2 := by
        apply Finset.sum_le_sum
        intro i _
        by_cases hi : w i=0
        · simp [hi]
        · apply mul_le_mul_of_nonneg_left _ (hw i)
          simpa only [sq_abs] using (sq_le_sq₀ (abs_nonneg _) hd).mpr (hfg i hi)
      _ = _ := by rw [← Finset.sum_mul,hs,one_mul]
  rw [← hF,← hG]
  exact (abs_norm_sub_norm_le F G).trans ((sq_le_sq₀ (norm_nonneg _) hd).mp hn)

theorem bt6ExitNorm_lipschitz (N : Size) (x : Vertex N) (q : ℕ) (f g : Vertex N → ℝ) (a d : ℝ)
    (hsmall : 2*(Real.exp ((q:ℝ)+1)+1)<N.val) (hd : 0≤d)
    (hfg : ∀ z, exitHarmonic N (torusDisk N x (Real.exp ((q:ℝ)+1))) z x≠0 → |f z-g z|≤d) :
    |bt6ExitNorm N x q f a-bt6ExitNorm N x q g a|≤d := by
  apply weighted_sqrt_lipschitz _ (fun z => f z-a) (fun z => g z-a) d
    (fun z => exitHarmonic_nonneg N _ z x)
    (exitHarmonic_sum_one N _ (torusDisk_proper N x _ (Real.exp_pos _).le hsmall) x) hd
  intro z hz
  simpa only [sub_sub_sub_cancel_right] using hfg z hz

/-- The original amplitude is retained; only endpoint and barrier tolerances
are enlarged. This implication is deterministic and applies to the fresh field. -/
theorem bt7BadPoint_transfer (N : Size) (γ ε C₀ C₁ : ℝ) (f g : Vertex N → ℝ) (x : Vertex N) (d : ℝ)
    (hd : 0≤d) (hAS : (logSize N)^(32*γ)≤(logSize N)^(1/10:ℝ))
    (hx : |f x-g x|≤d)
    (hscale : ∀ q : ℕ, (logSize N)^(32*γ)≤(q:ℝ) → (q:ℝ)≤logSize N-(logSize N)^(32*γ) →
      2*(Real.exp ((q:ℝ)+1)+1)<N.val ∧
      ∀ z, exitHarmonic N (torusDisk N x (Real.exp ((q:ℝ)+1))) z x≠0 → |f z-g z|≤d)
    (hbad : bt7BadPoint N γ ε C₀ C₁ f x) :
    |g x-harmonicExtremeCenter N|≤ε*Real.log (logSize N)+2*C₀+d ∧
    bt6BadField N x γ (ε*Real.log (logSize N)+C₀) (C₁*(logSize N)^(8*γ)+d) g := by
  rcases hbad with ⟨a,ha,hfa,hl,q,hq,hq',hu⟩
  have hn (j : ℕ) (hj : (logSize N)^(32*γ)≤(j:ℝ)) (hj' : (j:ℝ)≤logSize N-(logSize N)^(32*γ)) :=
    bt6ExitNorm_lipschitz N x j f g a d (hscale j hj hj').1 hd (hscale j hj hj').2
  constructor
  · have h1 := abs_sub_le (g x) (f x) a
    have h2 := abs_sub_le (g x) a (harmonicExtremeCenter N)
    rw [abs_sub_comm (g x) (f x)] at h1
    linarith
  · refine ⟨a,ha,?_,q,hq,hq',?_⟩
    · intro j hj hj'
      have he := abs_le.mp (hn j hj hj')
      linarith [hl j hj hj']
    · have he := abs_le.mp (hn q (hAS.trans hq) (by linarith))
      linarith

end TorusCoverTime.Blocks.B
