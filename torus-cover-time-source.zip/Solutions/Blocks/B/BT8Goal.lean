import Solutions.Blocks.B.BT1RootClosure
import Solutions.Blocks.B.R7GlobalLowerBarrier
import Solutions.Blocks.B.BT7
import Solutions.Blocks.B.CentralPhysicalWindows

/-! Fixed B-T8 target: the actual soft traversal-contact count under the
original root-summed physical loop window, with all integer contact scales. -/
noncomputable section
open MeasureTheory Filter Set Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

def bt8ContactAt (N : Size) (root x : Vertex N) (γ : ℝ) (q : ℕ) (z : WalkSample × ℝ) : Prop :=
  (logSize N)^(1/10:ℝ)≤(q:ℝ) ∧ (q:ℝ)≤logSize N-(logSize N)^(1/10:ℝ) ∧
    r7TraversalRadius N x root γ q z≤Real.sqrt 2*(q:ℝ)+(logSize N)^(8*γ)

def bt8SoftPoint (N : Size) (root x : Vertex N) (γ u : ℝ) (z : WalkSample × ℝ) : Prop :=
  localTime N root z.1 z.2 x≤u ∧ ∃ q : ℕ, bt8ContactAt N root x γ q z

def bt8SoftCount (N : Size) (root : Vertex N) (γ u : ℝ) (z : WalkSample × ℝ) : ℝ :=
  ∑ x, if bt8SoftPoint N root x γ u z then 1 else 0

def bt8Good (N : Size) (root : Vertex N) (γ u : ℝ) (z : WalkSample × ℝ) : Prop :=
  r7LowerBarrier N root γ z ∧ bt1R8Good N root γ u z

def BT8Conclusion (γ u : ℝ) : Prop :=
  ∀ H η : ℝ, 0≤H → 0<η → ∀ l r : Size → ℝ,
    (∀ᶠ N : Size in atTop, l N≤r N ∧ phaseACenter N-H*timeScale N≤l N ∧
      r N≤phaseACenter N+H*timeScale N) →
    Tendsto (fun N => r7LoopEventMass N
      (fun root => {z | η*Real.sqrt (logSize N)<bt8SoftCount N root γ u z}) (l N) (r N))
      atTop (𝓝 0)

def bt8ImageBad (N : Size) (γ u : ℝ) (x : Vertex N) (y : D.CoareaImage N) : Prop :=
  y.2 x≤2*u+1 ∧
    (∀ q : ℕ, (logSize N)^(32*γ)≤(q:ℝ) → (q:ℝ)≤logSize N-(logSize N)^(32*γ) →
      Real.sqrt 2*(q:ℝ)-4*(logSize N)^(8*γ)≤harmonicImageRadius N x q y) ∧
    ∃ q : ℕ, (logSize N)^(1/10:ℝ)≤(q:ℝ) ∧ (q:ℝ)≤logSize N-(logSize N)^(1/10:ℝ) ∧
      harmonicImageRadius N x q y≤Real.sqrt 2*(q:ℝ)+4*(logSize N)^(8*γ)

def bt8ImageCount (N : Size) (γ u : ℝ) (y : D.CoareaImage N) : ℝ≥0∞ :=
  ∑ x, if bt8ImageBad N γ u x y then 1 else 0

/-- The probe reads a contact witness from the source; the image event only
asks for the existence of a contact and never reads this source witness. -/
def bt8Probe (N : Size) (root x : Vertex N) (γ : ℝ)
    (z : D.LoopSource × FiniteFieldSample N) : Prop :=
  ∃ q : ℕ, bt8ContactAt N root x γ q (z.1.2,z.1.1) ∧ z.2∈r7CoarseProbe N root x q

end TorusCoverTime.Blocks.B
