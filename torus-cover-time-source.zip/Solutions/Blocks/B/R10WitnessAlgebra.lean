import Solutions.Blocks.B.R1Superexponential

/-! The exact scalar cancellation in R10.3 and summability at its witness-excess scale.
This module does not assume or assert the missing probabilistic witness-pair estimate. -/

noncomputable section
open Filter Asymptotics
open scoped Topology
namespace TorusCoverTime.Blocks.B

lemma r10_denominator_loss (r C v : ℝ) (hr : 0 < r) (hC : 0 ≤ C)
    (hv : v ^ 2 ≤ 2 * r ^ 2) : v ^ 2 / r - 2 * C ≤ v ^ 2 / (r + C) := by
  have hm := mul_le_mul_of_nonneg_right hv hC
  have hpoly : (v ^ 2 - 2 * C * r) * (r + C) ≤ v ^ 2 * r := by
    nlinarith [mul_nonneg (sq_nonneg C) hr.le]
  have h := (div_le_div_iff₀ hr (add_pos_of_pos_of_nonneg hr hC)).mpr hpoly
  simpa only [sub_div, mul_div_cancel_right₀ _ hr.ne'] using h

lemma r10_witness_exponent_bound (r C s d E : ℝ) (hr : 0 < r) (hC : 0 ≤ C)
    (hs : 0 ≤ s) (hd : 0 ≤ d) :
    2 * r - (max (Real.sqrt 2 * r - s - d) 0) ^ 2 / (r + C) -
      4 * Real.sqrt 2 * s + E ≤ -2 * Real.sqrt 2 * s + 2 * Real.sqrt 2 * d + 2 * C + E := by
  have ha := Real.sqrt_nonneg (2 : ℝ)
  have ha2 := Real.sq_sqrt (by norm_num : (0 : ℝ) ≤ 2)
  have hasq : (Real.sqrt 2 * r) ^ 2 = 2 * r ^ 2 := by rw [mul_pow, ha2]
  by_cases hv : 0 ≤ Real.sqrt 2 * r - s - d
  · rw [max_eq_left hv]
    have hvsq : (Real.sqrt 2 * r - s - d) ^ 2 ≤ 2 * r ^ 2 := by
      rw [← hasq]
      exact pow_le_pow_left₀ hv (by linarith) 2
    have hdrop := r10_denominator_loss r C (Real.sqrt 2 * r - s - d) hr hC hvsq
    have hbase : 2 * r - 2 * Real.sqrt 2 * (s + d) ≤ (Real.sqrt 2 * r - s - d) ^ 2 / r := by
      apply (le_div_iff₀ hr).mpr
      nlinarith [sq_nonneg (s + d), hasq]
    linarith
  · rw [max_eq_right (le_of_not_ge hv), zero_pow (by decide : 2 ≠ 0), zero_div]
    have hmul := mul_le_mul_of_nonneg_left (show Real.sqrt 2 * r ≤ s + d by linarith) ha
    rw [← mul_assoc, ← pow_two, ha2] at hmul
    nlinarith [mul_nonneg ha hs, mul_nonneg ha hd]

lemma r10_witness_exponent_negative (r C s d E : ℝ) (hr : 0 < r) (hC : 0 ≤ C)
    (hs : 0 ≤ s) (hd : 0 ≤ d)
    (herror : 2 * Real.sqrt 2 * d + 2 * C + E ≤ (2 * Real.sqrt 2 - 1) * s) :
    2 * r - (max (Real.sqrt 2 * r - s - d) 0) ^ 2 / (r + C) -
      4 * Real.sqrt 2 * s + E ≤ -s := by
  have h := r10_witness_exponent_bound r C s d E hr hC hs hd
  nlinarith

lemma power_eventually_le_power (C a b δ : ℝ) (hab : a < b) (hδ : 0 < δ) :
    ∀ᶠ L : ℝ in atTop, C * L ^ a ≤ δ * L ^ b := by
  have ht : Tendsto (fun L : ℝ => C * L ^ (a - b)) atTop (𝓝 0) := by
    have h := (tendsto_rpow_neg_atTop (sub_pos.mpr hab)).const_mul C
    simpa only [neg_sub, mul_zero] using h
  filter_upwards [eventually_gt_atTop (0 : ℝ), ht.eventually_lt_const hδ] with L hL hsmall
  have heq : C * L ^ a / L ^ b = C * L ^ (a - b) := by rw [Real.rpow_sub hL]; ring
  rw [← heq] at hsmall
  exact (div_le_iff₀ (Real.rpow_pos_of_pos hL b)).mp hsmall.le

lemma log_eventually_le_power (C b δ : ℝ) (hb : 0 < b) (hδ : 0 < δ) :
    ∀ᶠ L : ℝ in atTop, C * Real.log L ≤ δ * L ^ b := by
  have h := ((isLittleO_log_rpow_atTop hb).const_mul_left C).bound hδ
  filter_upwards [eventually_ge_atTop (0 : ℝ), h] with L hL hbound
  have hnorm : |C * Real.log L| ≤ δ * L ^ b := by
    simpa only [Real.norm_eq_abs, abs_of_nonneg (Real.rpow_nonneg hL _)] using hbound
  exact (le_abs_self _).trans hnorm

lemma r10_error_absorption (γ C : ℝ) (hγ : 0 < γ) (hC : 0 ≤ C) :
    ∀ᶠ L : ℝ in atTop, ∀ q s : ℝ, 0 ≤ q → q ≤ L → L ^ (8 * γ) ≤ s →
      2 * Real.sqrt 2 * (L ^ (2 * γ) + C * Real.log L) + 2 * C + C * q ^ γ ≤
        (2 * Real.sqrt 2 - 1) * s := by
  filter_upwards [eventually_ge_atTop (1 : ℝ),
    power_eventually_le_power (2 * Real.sqrt 2) (2 * γ) (8 * γ) (1 / 4) (by linarith) (by norm_num),
    log_eventually_le_power (2 * Real.sqrt 2 * C) (8 * γ) (1 / 4) (by positivity) (by norm_num),
    power_eventually_le_power (2 * C) 0 (8 * γ) (1 / 4) (by positivity) (by norm_num),
    power_eventually_le_power C γ (8 * γ) (1 / 4) (by linarith) (by norm_num)]
    with L hL h1 h2 h3 h4
  intro q s hq hqL hs
  have hqpow : C * q ^ γ ≤ C * L ^ γ :=
    mul_le_mul_of_nonneg_left (Real.rpow_le_rpow hq hqL hγ.le) hC
  simp only [Real.rpow_zero, mul_one] at h3
  have hs0 : 0 ≤ s := (Real.rpow_nonneg (by linarith : 0 ≤ L) _).trans hs
  have hroot : 1 ≤ Real.sqrt (2 : ℝ) := by
    have hsq := Real.sq_sqrt (by norm_num : (0 : ℝ) ≤ 2)
    nlinarith [Real.sqrt_nonneg (2 : ℝ)]
  nlinarith [mul_nonneg (sub_nonneg.mpr hroot) hs0]

lemma r10_witness_exponent_eventually (γ C : ℝ) (hγ : 0 < γ) (hC : 0 ≤ C) :
    ∀ᶠ L : ℝ in atTop, ∀ q s : ℝ, 0 ≤ q → q < L → L ^ (8 * γ) ≤ s →
      2 * (L - q) -
        (max (Real.sqrt 2 * (L - q) - s - (L ^ (2 * γ) + C * Real.log L)) 0) ^ 2 /
          (L - q + C) - 4 * Real.sqrt 2 * s + C * q ^ γ ≤ -s := by
  filter_upwards [eventually_ge_atTop (1 : ℝ), r10_error_absorption γ C hγ hC] with L hL herr
  intro q s hq hqL hs
  have hL0 : 0 ≤ L := by linarith
  apply r10_witness_exponent_negative _ C s _ _ (sub_pos.mpr hqL) hC
    ((Real.rpow_nonneg hL0 _).trans hs)
    (add_nonneg (Real.rpow_nonneg hL0 _) (mul_nonneg hC (Real.log_nonneg hL)))
  exact herr q s hq hqL.le hs

lemma polynomial_times_stretched_exp_tendsto_zero (a c M : ℝ) (ha : 0 < a) (hc : 0 < c) :
    Tendsto (fun L : ℝ => L ^ M * Real.exp (-c * L ^ a)) atTop (𝓝 0) := by
  have h := (tendsto_rpow_mul_exp_neg_mul_atTop_nhds_zero (M / a) c hc).comp (tendsto_rpow_atTop ha)
  apply h.congr'
  filter_upwards [eventually_ge_atTop (0 : ℝ)] with L hL
  change (L ^ a) ^ (M / a) * Real.exp (-c * L ^ a) = _
  rw [← Real.rpow_mul hL, show a * (M / a) = M by field_simp]

end TorusCoverTime.Blocks.B
