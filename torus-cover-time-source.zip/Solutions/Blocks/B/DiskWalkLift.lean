import Solutions.Blocks.B.DiskBarrier

/-! Small torus disks and planar lattice disks have identical first-exit kernels
on the same direction/holding-time sample. The correspondence includes the exit step. -/

noncomputable section
open MeasureTheory ProbabilityTheory Classical
namespace TorusCoverTime.Blocks.B

def latticePosition (z : LatticePoint) (ω : WalkSample) (n : ℕ) : LatticePoint :=
  z + ∑ j ∈ Finset.range n, latticeDirection (ω j).2

@[simp] lemma latticePosition_zero (z : LatticePoint) (ω : WalkSample) :
    latticePosition z ω 0 = z := by simp [latticePosition]

lemma latticePosition_succ (z : LatticePoint) (ω : WalkSample) (n : ℕ) :
    latticePosition z ω (n+1) = latticePosition z ω n + latticeDirection (ω n).2 := by
  simp [latticePosition, Finset.sum_range_succ, add_assoc]

lemma position_succ_step (N : Size) (a : Vertex N) (ω : WalkSample) (n : ℕ) :
    position N a ω (n+1) = position N a ω n + direction N (ω n).2 := by
  simp [position, Finset.sum_range_succ, add_assoc]

lemma latticePosition_projection (N : Size) (y : Vertex N) (z : LatticePoint)
    (ω : WalkSample) (n : ℕ) :
    torusProjection N y (latticePosition z ω n) = position N (torusProjection N y z) ω n := by
  induction n with
  | zero => simp
  | succ n ih =>
    rw [latticePosition_succ, torusProjection_add_direction, ih, position_succ_step]

lemma latticePosition_centered_projection (N : Size) (y a : Vertex N)
    (ω : WalkSample) (n : ℕ) :
    torusProjection N y (latticePosition (centeredLift N y a) ω n) = position N a ω n := by
  rw [latticePosition_projection, torusProjection_centeredLift]

lemma centeredLift_position_of_stays (N : Size) (y a : Vertex N) (R : ℝ)
    (hsmall : 2*(R+1) < N.val) (ω : WalkSample) (n : ℕ)
    (hstays : ∀ j < n, position N a ω j ∈ torusDisk N y R) :
    centeredLift N y (position N a ω n) = latticePosition (centeredLift N y a) ω n := by
  induction n with
  | zero => simp
  | succ n ih =>
    have hn := (mem_torusDisk N y (position N a ω n) R).mp (hstays n (by omega))
    rw [position_succ_step, centeredLift_add_direction N y _ _ (by linarith),
      ih (fun j hj => hstays j (by omega)), latticePosition_succ]

def latticeExitsThroughAt (R : ℝ) (a b : LatticePoint) (ω : WalkSample) (n : ℕ) : Prop :=
  R ≤ latticeRadius b ∧ latticePosition a ω n = b ∧
    ∀ j : Fin n, latticeRadius (latticePosition a ω j.val) < R

def latticeExitsThrough (R : ℝ) (a b : LatticePoint) : Set WalkSample :=
  {ω | ∃ n : ℕ, latticeExitsThroughAt R a b ω n}

def latticeExactExitLaw (R : ℝ) (a b : LatticePoint) : Measure WalkSample :=
  walkLaw[|latticeExitsThrough R a b]

lemma exitsThroughAt_iff_lattice (N : Size) (y a b : Vertex N) (R : ℝ)
    (hsmall : 2*(R+1) < N.val) (ω : WalkSample) (n : ℕ) :
    exitsThroughAt N (torusDisk N y R) a b ω n ↔
      latticeExitsThroughAt R (centeredLift N y a) (centeredLift N y b) ω n := by
  constructor
  · rintro ⟨hb, hend, hpre⟩
    have hstays : ∀ j < n, position N a ω j ∈ torusDisk N y R :=
      fun j hj => hpre ⟨j,hj⟩
    refine ⟨?_, ?_, ?_⟩
    · rw [latticeRadius_centeredLift]
      simpa only [mem_torusDisk, not_lt] using hb
    · rw [← centeredLift_position_of_stays N y a R hsmall ω n hstays, hend]
    · intro j
      rw [← centeredLift_position_of_stays N y a R hsmall ω j.val
        (fun k hk => hstays k (by omega)), latticeRadius_centeredLift]
      exact (mem_torusDisk N y _ R).mp (hpre j)
  · rintro ⟨hb, hend, hpre⟩
    refine ⟨?_, ?_, ?_⟩
    · simpa only [mem_torusDisk, not_lt, latticeRadius_centeredLift] using hb
    · have hp := congrArg (torusProjection N y) hend
      simpa only [latticePosition_centered_projection, torusProjection_centeredLift] using hp
    · intro j
      rw [← latticePosition_centered_projection N y a ω j.val]
      have hz := hpre j
      have hc := latticeRadius_coordinates (latticePosition (centeredLift N y a) ω j.val)
      rw [projection_mem_disk_iff N y R _ (by linarith [hc.1]) (by linarith [hc.2])]
      exact hz

theorem exitsThrough_eq_lattice (N : Size) (y a b : Vertex N) (R : ℝ)
    (hsmall : 2*(R+1) < N.val) :
    exitsThrough N (torusDisk N y R) a b =
      latticeExitsThrough R (centeredLift N y a) (centeredLift N y b) := by
  ext ω
  exact exists_congr fun n => exitsThroughAt_iff_lattice N y a b R hsmall ω n

theorem disk_exactExitLaw_eq_lattice (N : Size) (y a b : Vertex N) (R : ℝ)
    (hsmall : 2*(R+1) < N.val) :
    exactExitLaw N (torusDisk N y R) a b =
      latticeExactExitLaw R (centeredLift N y a) (centeredLift N y b) := by
  rw [exactExitLaw, latticeExactExitLaw, exitsThrough_eq_lattice N y a b R hsmall]

end TorusCoverTime.Blocks.B
