import Solutions.Blocks.B.PointNearLoopWindow
import Solutions.Blocks.B.PointSoftBridge
import Solutions.Blocks.B.PointNearFullWindow
import Solutions.Blocks.B.R8SoftVertexUniform

/-! Final B-T1 entry point. Root exclusion is connected to the already
proved R8 control: on a common event of asymptotically full loop-window mass,
every actual soft site is in the valid range of R8. This does not assert R9 or R10. -/
noncomputable section
open MeasureTheory Filter Set Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

theorem bt1_soft_site_far (N : Size) (a root c : Vertex N) (R u : ℝ) (z : WalkSample × ℝ)
    (hnear : z ∉ pointNearSoftEvent N a root R u) (hsoft : localTime N a z.1 z.2 c ≤ u) :
    R ≤ periodicDistance c root := by
  apply le_of_not_gt
  intro hc
  exact hnear ⟨c,(mem_torusDisk N root c R).mpr hc,hsoft⟩

def bt1R8Good (N : Size) (root : Vertex N) (γ u : ℝ) (z : WalkSample × ℝ) : Prop :=
  r8SimultaneousGood N root γ (u/g) z ∧
    z ∉ pointNearSoftEvent N root root (pointNearRadius N γ 2) u

theorem bt1R8Good_measurable (N : Size) (root : Vertex N) (γ u : ℝ) :
    MeasurableSet {z | bt1R8Good N root γ u z} :=
  (r8SimultaneousGood_measurable N root γ (u/g)).inter
    (pointNearSoftEvent_measurable N root root (pointNearRadius N γ 2) u).compl

theorem bt1_r8_all_soft_control (N : Size) (root c : Vertex N) (γ u : ℝ)
    (z : WalkSample × ℝ) (hgood : bt1R8Good N root γ u z)
    (k : ℤ) (hk : 2*(logSize N)^(16*γ) ≤ (k:ℝ))
    (hkL : (k:ℝ) ≤ logSize N-2*(logSize N)^(16*γ))
    (hsoft : localTime N root z.1 z.2 c ≤ u) :
    r7TraversalRadius N c root γ k z ≤ 10*logSize N ∧
      |Real.sqrt (harmonicPathOccupation N c root k z)-r7TraversalRadius N c root γ k z| ≤
        (logSize N)^(4*γ) := by
  have hfar := bt1_soft_site_far N root root c (pointNearRadius N γ 2) u z hgood.2 hsoft
  have hfar' : 2*((N.val:ℝ)*Real.exp (-((logSize N)^(16*γ))/2)) ≤ periodicDistance c root := by
    simpa only [pointNearRadius,mul_assoc] using hfar
  exact r8_simultaneous_soft_control_int N root c γ (u/g) z hgood.1 k hk hkL hfar'
    (div_le_div_of_nonneg_right hsoft (by unfold g; positivity))

theorem bt1_r8_good_failure_bound (N : Size) (γ u l r : ℝ) :
    r7LoopEventMass N (fun root => {z | ¬bt1R8Good N root γ u z}) l r ≤
      r7LoopEventMass N (fun root => {z | ¬r8SimultaneousGood N root γ (u/g) z}) l r +
        r7LoopEventMass N (fun root => pointNearSoftEvent N root root (pointNearRadius N γ 2) u) l r := by
  have he : (fun root : Vertex N => {z | ¬bt1R8Good N root γ u z}) = fun root =>
      {z | ¬r8SimultaneousGood N root γ (u/g) z} ∪
        pointNearSoftEvent N root root (pointNearRadius N γ 2) u := by
    funext root
    ext z
    simp only [bt1R8Good,mem_setOf_eq,mem_union]
    tauto
  rw [he]
  exact r7LoopEventMass_union_le N _ _
    (fun root => (r8SimultaneousGood_measurable N root γ (u/g)).compl)
    (fun root => pointNearSoftEvent_measurable N root root (pointNearRadius N γ 2) u) l r

theorem bt1_r8_good_failure_tendsto (hWalk : WalkModelRegular) (γ u H : ℝ)
    (hγ : 0 < γ) (hγ1 : 16*γ < 1) (hu : 0 ≤ u) (hH : 0 ≤ H) (l r : Size → ℝ)
    (hwindow : ∀ᶠ N : Size in atTop, l N ≤ r N ∧
      phaseACenter N-H*timeScale N ≤ l N ∧ r N ≤ phaseACenter N+H*timeScale N) :
    Tendsto (fun N => r7LoopEventMass N (fun root => {z | ¬bt1R8Good N root γ u z}) (l N) (r N))
      atTop (𝓝 0) := by
  have ht := (r8_simultaneous_failure_tendsto hWalk γ (u/g) H hγ hγ1
    (div_nonneg hu (by unfold g; positivity)) hH l r hwindow).add
      (point_near_loop_window_tendsto hWalk γ 2 u H hγ (by norm_num) hH l r hwindow)
  simp only [add_zero] at ht
  exact tendsto_of_tendsto_of_tendsto_of_le_of_le' tendsto_const_nhds ht
    (Eventually.of_forall fun _ => bot_le)
    (Eventually.of_forall fun N => bt1_r8_good_failure_bound N γ u (l N) (r N))

end TorusCoverTime.Blocks.B
