import Solutions.Blocks.B.FourierOccupation

/-! R10's supremum is inside the probability, and is exactly the earliest-time defect mass. -/

noncomputable section
open MeasureTheory Filter
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

lemma localTime_mono_time (N : Size) (start : Vertex N) (ω : WalkSample) (x : Vertex N) :
    Monotone (fun t => localTime N start ω t x) := by
  classical
  intro s t hst
  let f := fun r : ℝ => if walk N start ω r = x then (1 : ℝ) else 0
  have hm : Measurable f := (measurable_walk_indicator_joint N start x).comp
    (measurable_const.prodMk measurable_id)
  have hi : IntegrableOn f (Set.Icc 0 t) := by
    apply Integrable.of_bound hm.aestronglyMeasurable 1
    exact Eventually.of_forall (fun r => by dsimp [f]; split_ifs <;> norm_num)
  exact setIntegral_mono_set hi (Eventually.of_forall (fun r => by dsimp [f]; positivity))
    (Eventually.of_forall (fun r hr => ⟨hr.1, hr.2.trans hst⟩))

lemma softSet_antitone_time (N : Size) (start : Vertex N) (ω : WalkSample) (u₀ : ℝ) :
    Antitone (softSet N start ω u₀) := by
  classical
  intro s t hst x hx
  simp only [softSet, Finset.mem_filter, Finset.mem_univ, true_and] at hx ⊢
  exact (localTime_mono_time N start ω x hst).trans hx

lemma wideDefects_mono (N : Size) : Monotone (wideDefects N) := by
  classical
  intro U V hUV x hx
  rcases Finset.mem_filter.mp hx with ⟨hxU, y, hyU, hxy, hxy'⟩
  exact Finset.mem_filter.mpr ⟨hUV hxU, y, hUV hyU, hxy, hxy'⟩

lemma defectCount_antitone_time (N : Size) (start : Vertex N) (ω : WalkSample) (u₀ : ℝ) :
    Antitone (fun t => (wideDefects N (softSet N start ω u₀ t)).card) := by
  intro s t hst
  exact Finset.card_le_card (wideDefects_mono N (softSet_antitone_time N start ω u₀ hst))

def earliestDefectMass (N : Size) (start : Vertex N) (ω : WalkSample) (u₀ W : ℝ) : ℝ :=
  ((wideDefects N (softSet N start ω u₀ (phaseACenter N - W * timeScale N))).card : ℝ) /
    Real.sqrt (logSize N)

lemma defectWindowMass_eq_earliest (N : Size) (start : Vertex N) (ω : WalkSample)
    (u₀ W : ℝ) (hW : 0 ≤ W) : defectWindowMass N start ω u₀ W = earliestDefectMass N start ω u₀ W := by
  let cmin : {c : ℝ // |c| ≤ W} := ⟨-W, by simpa only [abs_neg, abs_of_nonneg hW] using le_refl W⟩
  have : Nonempty {c : ℝ // |c| ≤ W} := ⟨cmin⟩
  let F := fun c : {c : ℝ // |c| ≤ W} =>
    ((wideDefects N (softSet N start ω u₀ (phaseACenter N + c.val * timeScale N))).card : ℝ) /
      Real.sqrt (logSize N)
  have hbounded : BddAbove (Set.range F) := by
    refine ⟨(Fintype.card (Vertex N) : ℝ) / Real.sqrt (logSize N), ?_⟩
    rintro _ ⟨c, rfl⟩
    exact div_le_div_of_nonneg_right (by exact_mod_cast Finset.card_le_univ _) (Real.sqrt_nonneg _)
  have hmin : F cmin = earliestDefectMass N start ω u₀ W := by
    simp only [F, cmin, earliestDefectMass, neg_mul, sub_eq_add_neg]
  change (⨆ c, F c) = _
  apply le_antisymm
  · apply ciSup_le
    intro c
    apply div_le_div_of_nonneg_right _ (Real.sqrt_nonneg _)
    apply Nat.cast_le.mpr
    apply defectCount_antitone_time
    have hc := (abs_le.mp c.property).1
    have ht := mul_le_mul_of_nonneg_right hc (timeScale_pos N).le
    linarith
  · rw [← hmin]
    exact le_ciSup hbounded cmin

lemma localTime_measurable_in_sample (N : Size) (start x : Vertex N) (t : ℝ) :
    Measurable (fun ω => localTime N start ω t x) :=
  (measurable_walk_indicator_joint N start x).stronglyMeasurable.integral_prod_right'.measurable

lemma softSet_measurable (N : Size) (start : Vertex N) (u₀ t : ℝ) :
    Measurable (fun ω => softSet N start ω u₀ t) := by
  classical
  apply measurable_finset_iff.mpr
  intro x
  apply measurableSet_setOfPred.mp
  simpa only [softSet, Finset.mem_filter, Finset.mem_univ, true_and] using
    measurableSet_le (localTime_measurable_in_sample N start x t) measurable_const

lemma earliestDefectMass_measurable (N : Size) (start : Vertex N) (u₀ W : ℝ) :
    Measurable (fun ω => earliestDefectMass N start ω u₀ W) := by
  exact (measurable_of_countable (fun U : Finset (Vertex N) => ((wideDefects N U).card : ℝ) /
    Real.sqrt (logSize N))).comp (softSet_measurable N start u₀ _)

lemma defectWindowMass_measurable (N : Size) (start : Vertex N) (u₀ W : ℝ) (hW : 0 ≤ W) :
    Measurable (fun ω => defectWindowMass N start ω u₀ W) := by
  simp_rw [defectWindowMass_eq_earliest N start _ u₀ W hW]
  exact earliestDefectMass_measurable N start u₀ W

lemma wideDefectLimit_iff_earliest : WideDefectLimit ↔
    ∀ u₀ : ℝ, 0 < u₀ → ∀ W : ℝ, 0 ≤ W → ∀ η : ℝ, 0 < η →
      Tendsto (fun N : Size => ⨆ start : Vertex N,
        walkLaw {ω | η < earliestDefectMass N start ω u₀ W}) atTop (𝓝 0) := by
  constructor
  · intro h u₀ hu W hW η hη
    have ht := h u₀ hu W hW η hη
    simpa only [defectWindowMass_eq_earliest _ _ _ u₀ W hW] using ht
  · intro h u₀ hu W hW η hη
    simpa only [defectWindowMass_eq_earliest _ _ _ u₀ W hW] using h u₀ hu W hW η hη

end TorusCoverTime.Blocks.B
