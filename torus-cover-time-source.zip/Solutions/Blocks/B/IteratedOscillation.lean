import Solutions.Blocks.B.DiskOscillation

/-! Finite iteration of the proved local oscillation contraction. The
minimal radius remains explicit, so no small-scale estimate is assumed. -/

noncomputable section
namespace TorusCoverTime.Blocks.B

theorem disk_scale_radius_le (R : ℝ) (hR : 0 ≤ R) (k : ℕ) : R/diskOscillationScale^k ≤ R := by
  have hS := diskOscillationScale_ge_two
  have hp : 1 ≤ diskOscillationScale^k := one_le_pow₀ (by linarith)
  exact div_le_self hR hp

theorem disk_scale_radius_step (R : ℝ) (hR : 0 ≤ R) (k : ℕ) :
    R/diskOscillationScale^(k+1) ≤ R/diskOscillationScale^k := by
  have hS := diskOscillationScale_ge_two
  rw [pow_succ, ← div_div]
  exact div_le_self (by positivity) (by linarith)

theorem disk_iterated_bounds (N : Size) (c : Vertex N) (R : ℝ) (hR : 0 < R)
    (hsmall : 4*(R+1) < N.val) (f : Vertex N → ℝ) (l u : ℝ)
    (hb : ∀ z ∈ torusDisk N c R, l ≤ f z ∧ f z ≤ u)
    (hg : ∀ z ∈ torusDisk N c R, generator N f z = 0)
    (k : ℕ) (hk : 2*diskHarnackRadiusThreshold ≤ R/diskOscillationScale^k) :
    ∃ l' u' : ℝ, l ≤ l' ∧ u' ≤ u ∧ l' ≤ u' ∧
      u'-l' ≤ diskOscillationFactor^k*(u-l) ∧
      ∀ z ∈ torusDisk N c (R/diskOscillationScale^k), l' ≤ f z ∧ f z ≤ u' := by
  induction k with
  | zero =>
    have hc : c ∈ torusDisk N c R := (mem_torusDisk N c c R).mpr (by simpa [periodicDistance_self_zero] using hR)
    refine ⟨l,u,le_rfl,le_rfl,(hb c hc).1.trans (hb c hc).2,?_,?_⟩
    · simp
    · simpa using hb
  | succ k ih =>
    have hprev := disk_scale_radius_step R hR.le k
    obtain ⟨l',u',hll,huu,hlu,hwidth,hbounds⟩ := ih (hk.trans hprev)
    have hrad := disk_scale_radius_le R hR.le k
    have hgen : ∀ z ∈ torusDisk N c (R/diskOscillationScale^k), generator N f z = 0 := by
      intro z hz
      exact hg z ((mem_torusDisk N c z R).mpr (((mem_torusDisk N c z _).mp hz).trans_le hrad))
    obtain ⟨l'',u'',hll',huu',hlu',hw',hb'⟩ := disk_oscillation_contract N c
      (R/diskOscillationScale^k) (hk.trans hprev) (by linarith) f l' u' hbounds hgen
    refine ⟨l'',u'',hll.trans hll',huu'.trans huu,hlu',?_,?_⟩
    · have hm := mul_le_mul_of_nonneg_left hwidth diskOscillationFactor_bounds.1.le
      calc
        _ ≤ diskOscillationFactor*(u'-l') := hw'
        _ ≤ diskOscillationFactor*(diskOscillationFactor^k*(u-l)) := hm
        _ = _ := by rw [pow_succ]; ring
    · simpa only [div_div, ← pow_succ] using hb'

theorem disk_iterated_oscillation (N : Size) (c : Vertex N) (R : ℝ) (hR : 0 < R)
    (hsmall : 4*(R+1) < N.val) (f : Vertex N → ℝ) (l u : ℝ)
    (hb : ∀ z ∈ torusDisk N c R, l ≤ f z ∧ f z ≤ u)
    (hg : ∀ z ∈ torusDisk N c R, generator N f z = 0)
    (k : ℕ) (hk : 2*diskHarnackRadiusThreshold ≤ R/diskOscillationScale^k)
    (x y : Vertex N) (hx : x ∈ torusDisk N c (R/diskOscillationScale^k))
    (hy : y ∈ torusDisk N c (R/diskOscillationScale^k)) :
    |f x-f y| ≤ diskOscillationFactor^k*(u-l) := by
  obtain ⟨l',u',_,_,_,hw,hb'⟩ := disk_iterated_bounds N c R hR hsmall f l u hb hg k hk
  have hxb := hb' x hx
  have hyb := hb' y hy
  exact (abs_le.mpr ⟨by linarith, by linarith⟩).trans hw

end TorusCoverTime.Blocks.B
