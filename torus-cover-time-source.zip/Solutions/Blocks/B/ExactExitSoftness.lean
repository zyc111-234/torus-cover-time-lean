import Solutions.Blocks.B.ExactExitProduct
import Solutions.Blocks.B.FiniteExitDuration

/-! The R1 softness event uses the actual occupation time of every exit block.
The tail estimate remains a separately stated input to the last inequality. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Classical
open scoped ENNReal Topology BigOperators
namespace TorusCoverTime.Blocks.B

def exitBlockOccupation (N : Size) (D : Finset (Vertex N)) (m : ℕ)
    (a : Fin m → Vertex N) (ω : Fin m → WalkSample) (x : Vertex N) : ℝ :=
  ∑ i, localTime N (a i) (ω i) (finiteExitDuration N D (a i) (ω i)) x

def exitBlockSoftness (N : Size) (D K : Finset (Vertex N)) (m : ℕ)
    (a : Fin m → Vertex N) (u₀ : ℝ) : Set (Fin m → WalkSample) :=
  {ω | ∃ x ∈ K, exitBlockOccupation N D m a ω x ≤ u₀}

lemma measurable_exitBlockOccupation (N : Size) (D : Finset (Vertex N)) (m : ℕ)
    (a : Fin m → Vertex N) (x : Vertex N) :
    Measurable (fun ω => exitBlockOccupation N D m a ω x) := by
  apply Finset.measurable_sum
  intro i _
  exact (localTime_measurable_random_time N (a i) x _
    (measurable_finiteExitDuration N D (a i))).comp (measurable_pi_apply i)

lemma measurableSet_exitBlockSoftness (N : Size) (D K : Finset (Vertex N)) (m : ℕ)
    (a : Fin m → Vertex N) (u₀ : ℝ) : MeasurableSet (exitBlockSoftness N D K m a u₀) := by
  simp only [exitBlockSoftness, Set.ofPred_exists]
  apply MeasurableSet.iUnion
  intro x
  by_cases hx : x ∈ K
  · simpa only [hx, true_and] using
      measurableSet_le (measurable_exitBlockOccupation N D m a x) (measurable_const (a := u₀))
  · simp only [hx, false_and, Set.ofPred_false, MeasurableSet.empty]

lemma exactExitProduct_regular (hWalk : WalkModelRegular)
    (N : Size) (D : Finset (Vertex N)) (m : ℕ) (a b : Fin m → Vertex N) :
    ∀ᵐ ω ∂exactExitProductLaw N D m a b, ∀ i : Fin m,
      (∀ j, 0 < (ω i j).1) ∧ Tendsto (jumpTime (ω i)) atTop atTop := by
  have (i : Fin m) : IsZeroOrProbabilityMeasure (exactExitLaw N D (a i) (b i)) := by
    unfold exactExitLaw
    infer_instance
  apply ae_all_iff.mpr
  intro i
  have hi : ∀ᵐ ω ∂exactExitLaw N D (a i) (b i),
      (∀ j, 0 < (ω j).1) ∧ Tendsto (jumpTime ω) atTop atTop :=
    cond_absolutelyContinuous.ae_le hWalk.1
  exact (Measure.quasiMeasurePreserving_eval
    (fun j => exactExitLaw N D (a j) (b j)) i).ae hi

lemma allExitBlocksAvoid_implies_softness_ae (hWalk : WalkModelRegular)
    (N : Size) (D K : Finset (Vertex N)) (m : ℕ) (a b : Fin m → Vertex N)
    (hK : K.Nonempty) (u₀ : ℝ) (hu₀ : 0 ≤ u₀) :
    ∀ᵐ ω ∂exactExitProductLaw N D m a b,
      ω ∈ allExitBlocksAvoid N D K m a b → ω ∈ exitBlockSoftness N D K m a u₀ := by
  filter_upwards [exactExitProduct_regular hWalk N D m a b] with ω hω
  intro ha
  obtain ⟨x, hx⟩ := hK
  refine ⟨x, hx, ?_⟩
  have hz : exitBlockOccupation N D m a ω x = 0 := by
    apply Finset.sum_eq_zero
    intro i _
    exact localTime_zero_on_avoiding_exit N D K (a i) (b i) (hω i).1 (hω i).2
      (ha i (Set.mem_univ i)) x hx
  rw [hz]
  exact hu₀

lemma exitBlockSoftness_probability_lower (hWalk : WalkModelRegular)
    (N : Size) (D K : Finset (Vertex N)) (m : ℕ) (a b : Fin m → Vertex N)
    (hpath : ∀ i, FeasibleAvoidingExit N D K (a i) (b i))
    (hK : K.Nonempty) (u₀ : ℝ) (hu₀ : 0 ≤ u₀) :
    1 / (4 : ℝ≥0∞) ^ (m * (D.card + 1)) ≤
      exactExitProductLaw N D m a b (exitBlockSoftness N D K m a u₀) :=
  (allExitBlocksAvoid_probability_lower N D K m a b hpath).trans
    (measure_mono_ae (allExitBlocksAvoid_implies_softness_ae hWalk N D K m a b hK u₀ hu₀))

lemma duration_union_bound_given_softness (hWalk : WalkModelRegular)
    (N : Size) (D K : Finset (Vertex N)) (m : ℕ) (a b : Fin m → Vertex N)
    (hpath : ∀ i, FeasibleAvoidingExit N D K (a i) (b i))
    (hK : K.Nonempty) (u₀ : ℝ) (hu₀ : 0 ≤ u₀) (d : ℝ)
    (ε : ℝ≥0∞) (hε : ∀ i, walkLaw {ω | d < finiteExitDuration N D (a i) ω} ≤ ε) :
    (exactExitProductLaw N D m a b)[{ω | ∃ i : Fin m, d < finiteExitDuration N D (a i) (ω i)} |
        exitBlockSoftness N D K m a u₀] ≤
      (m : ℝ≥0∞) * ε * (4 : ℝ≥0∞) ^ ((m + 1) * (D.card + 1)) :=
  exactExitProduct_conditioned_union_bound_ae N D K m a b hpath _
    (measurableSet_exitBlockSoftness N D K m a u₀)
    (allExitBlocksAvoid_implies_softness_ae hWalk N D K m a b hK u₀ hu₀)
    (fun i => {ω | d < finiteExitDuration N D (a i) ω})
    (fun i => measurableSet_lt measurable_const (measurable_finiteExitDuration N D (a i))) ε hε

end TorusCoverTime.Blocks.B
