import Solutions.Blocks.B.TraversalOccupation

/-! The original occupation at a jump plus residual time, including every holding interval. -/
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B


theorem localTime_jump_restart (N : Size) (a x : Vertex N) (ω : WalkSample) (n : ℕ)
    (hp : ∀ j, 0 < (ω j).1)
    (hd : Tendsto (jumpTime (fun j => ω (n+j))) atTop atTop) (u : ℝ) (hu : 0 ≤ u) :
    localTime N a ω (jumpTime ω n+u) x =
      localTime N a ω (jumpTime ω n) x +
        localTime N (position N a ω n) (fun j => ω (n+j)) u x := by
  rw [localTime_add_shift N a x ω _ u (jumpTime_nonneg ω n) hu]
  congr 1
  apply setIntegral_congr_fun measurableSet_Icc
  intro v hv
  dsimp only
  rw [walk_jumpTime_shift N a ω n hp hd v hv.1]

theorem adaptiveExit_occupation_restart_ae (N : Size) (D : ℕ → Finset (Vertex N))
    (root : Vertex N) (U : Vertex N → ℝ) :
    ∀ᵐ ω ∂walkLaw, ∀ k u, 0 ≤ u →
      (∑ x, U x*localTime N root ω (adaptiveExitTime N D root k ω+u) x) =
        (∑ j ∈ Finset.range k, excursionRecordCost N (adaptiveExitStart N D root j ω) U
          (adaptiveExitRecord N D root j ω)) +
        ∑ x, U x*localTime N (adaptiveExitStart N D root k ω) (adaptiveExitTail N D root k ω) u x := by
  have hall : ∀ᵐ ω ∂walkLaw, ∀ n, Tendsto (jumpTime (fun j => ω (n+j))) atTop atTop :=
    ae_all_iff.mpr fun n => (fixedShift_measurePreserving n).quasiMeasurePreserving.ae
      (A.holding_positive_and_nonexplosive.mono fun _ h => h.2)
  filter_upwards [A.holding_positive_and_nonexplosive,hall] with ω hreg ht
  intro k u hu
  simp_rw [adaptiveExitTime,localTime_jump_restart N root _ ω _ hreg.1 (ht _) u hu,mul_add]
  rw [Finset.sum_add_distrib]
  exact congrArg (fun s : ℝ => s + ∑ x, U x*localTime N
    (adaptiveExitStart N D root k ω) (adaptiveExitTail N D root k ω) u x)
      (adaptiveExit_weighted_prefix N D root ω hreg.1 hreg.2 U k)


end TorusCoverTime.Blocks.B
