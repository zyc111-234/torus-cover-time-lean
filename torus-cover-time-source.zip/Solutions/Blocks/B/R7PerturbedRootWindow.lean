import Solutions.Blocks.B.R7PerturbedPhysicalWindow
import Solutions.Blocks.B.R7CountedRootWindow

/-! Far-root sum and normalization for the perturbed annulus. The harmonic
source and its far-root cutoff remain the original ones. -/

noncomputable section
open MeasureTheory Filter Set Classical
open scoped ENNReal NNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B
def perturbedFarRootCountedMass (N : Size) (c : Vertex N) (γ q : ℝ) (M : ℕ) (l r : ℝ) : ℝ≥0∞ :=
  ∑ root : Vertex N, if (N.val:ℝ)*Real.exp (-((logSize N)^(16*γ))/2) ≤ periodicDistance c root then
    countedLoopWindowMass N (torusDisk N c (r7PerturbedInner q (q^γ)))
      (torusDisk N c (r7PerturbedOuter q (q^γ))) root M l r else 0

def normalizedPerturbedFarRootCountedMass (N : Size) (c : Vertex N) (γ q : ℝ) (M : ℕ) (l r : ℝ) : ℝ≥0∞ :=
  (ENNReal.ofReal (timeScale N))⁻¹ * perturbedFarRootCountedMass N c γ q M l r

theorem perturbedFarRootCountedMass_le_length (N : Size) (c : Vertex N) (γ q : ℝ) (M : ℕ) (l r : ℝ) :
    perturbedFarRootCountedMass N c γ q M l r ≤ ENNReal.ofReal (vertexCount N)*ENNReal.ofReal (r-l) := by
  calc
    _ ≤ ∑ _root : Vertex N, ENNReal.ofReal (r-l) := by
      apply Finset.sum_le_sum
      intro root _
      split_ifs
      · exact countedLoopWindowMass_le_length N _ _ root M l r
      · exact bot_le
    _ = _ := by simp only [Finset.sum_const,Finset.card_univ,nsmul_eq_mul,D.vertexCount_eq_card,ENNReal.ofReal_natCast]

theorem normalizedPerturbedFarRootCountedMass_le_length (N : Size) (c : Vertex N) (γ q : ℝ) (M : ℕ) (l r : ℝ) :
    normalizedPerturbedFarRootCountedMass N c γ q M l r ≤ ENNReal.ofReal (vertexCount N*(r-l)/timeScale N) := by
  apply (mul_le_mul' (le_refl ((ENNReal.ofReal (timeScale N))⁻¹))
    (perturbedFarRootCountedMass_le_length N c γ q M l r)).trans_eq
  rw [← ENNReal.ofReal_inv_of_pos (timeScale_pos N),
    ← ENNReal.ofReal_mul (vertexCount_pos N).le,
    ← ENNReal.ofReal_mul (inv_nonneg.mpr (timeScale_pos N).le)]
  congr 1
  ring

theorem normalizedPerturbedFarRootCountedMass_ne_top (N : Size) (c : Vertex N) (γ q : ℝ) (M : ℕ) (l r : ℝ) :
    normalizedPerturbedFarRootCountedMass N c γ q M l r ≠ ∞ :=
  ne_of_lt ((normalizedPerturbedFarRootCountedMass_le_length N c γ q M l r).trans_lt ENNReal.ofReal_lt_top)

theorem perturbed_far_root_counted_recurrence (hWalk : WalkModelRegular) (γ : ℝ) (hγ : 0 < γ) (hγ1 : γ < 1) :
    ∀ᶠ N : Size in atTop, ∀ c : Vertex N, ∀ M : ℕ, ∀ q : ℝ,
      (logSize N)^(16*γ) ≤ q → q ≤ logSize N-(logSize N)^(16*γ) → (M:ℝ) ≤ (logSize N)^4+1 →
      ∀ v Δ : ℝ, 0 ≤ v → (M:ℝ)*r7PerturbedWidth q (q^γ) ≤ v^2 → 0 ≤ Δ →
      2*r7PerturbedMeanConstant*Real.exp (-r7MeanExponent*q^γ)*v ≤ Δ → ∀ l r : ℝ,
      let d := (M:ℝ)*Real.exp (2*logSize N-(logSize N)^(16*γ))
      perturbedFarRootCountedMass N c γ q M l r ≤ farRootLowHarmonicMass N c γ q (v+Δ) l r +
        2*ENNReal.ofReal (2*Real.exp (-(r7PerturbedConcentrationConstant/4)*Δ^2/q^γ)) *
          perturbedFarRootCountedMass N c γ q M (l-d) (r+d) +
        ENNReal.ofReal (vertexCount N)*((M+1:ℕ):ℝ≥0∞)*ENNReal.ofReal (r-l)*
          ENNReal.ofReal (Real.exp (-Real.exp ((logSize N)^(16*γ)/2))) := by
  filter_upwards [r7_perturbed_physical_window_recurrence hWalk γ hγ hγ1,r7_perturbed_far_root_outside γ hγ] with N hN hr
  intro c M q hq hqL hM v Δ hv hMv hΔ hlo l r
  let d := (M:ℝ)*Real.exp (2*logSize N-(logSize N)^(16*γ))
  let p := 2*ENNReal.ofReal (2*Real.exp (-(r7PerturbedConcentrationConstant/4)*Δ^2/q^γ))
  let e := ((M+1:ℕ):ℝ≥0∞)*ENNReal.ofReal (r-l)*ENNReal.ofReal (Real.exp (-Real.exp ((logSize N)^(16*γ)/2)))
  let far := fun root : Vertex N => (N.val:ℝ)*Real.exp (-((logSize N)^(16*γ))/2) ≤ periodicDistance c root
  let A := fun root l r => if far root then countedLoopWindowMass N (torusDisk N c (r7PerturbedInner q (q^γ)))
    (torusDisk N c (r7PerturbedOuter q (q^γ))) root M l r else 0
  let B := fun root => if far root then lowHarmonicLoopWindowMass N c root q (v+Δ) l r else 0
  have hstep (root : Vertex N) : A root l r ≤ B root+p*A root (l-d) (r+d)+e := by
    by_cases hfar : far root
    · simp only [A,B,if_pos hfar]
      exact hN c root M q hq hqL hM
        (hr c root q ((Real.rpow_nonneg (logSize_pos N).le _).trans hq) hqL hfar) v Δ hv hMv hΔ hlo l r
    · simp only [A,B,if_neg hfar,zero_mul,mul_zero,zero_add]
      exact bot_le
  have hh := Finset.sum_le_sum (fun root (_ : root ∈ (Finset.univ : Finset (Vertex N))) => hstep root)
  simp only [Finset.sum_add_distrib,← Finset.mul_sum,Finset.sum_const,Finset.card_univ,nsmul_eq_mul] at hh
  have he : (Fintype.card (Vertex N):ℝ≥0∞)*e =
      ENNReal.ofReal (vertexCount N)*((M+1:ℕ):ℝ≥0∞)*ENNReal.ofReal (r-l)*
        ENNReal.ofReal (Real.exp (-Real.exp ((logSize N)^(16*γ)/2))) := by
    rw [D.vertexCount_eq_card,ENNReal.ofReal_natCast]
    dsimp [e]
    ac_rfl
  rw [he] at hh
  exact hh

end TorusCoverTime.Blocks.B

