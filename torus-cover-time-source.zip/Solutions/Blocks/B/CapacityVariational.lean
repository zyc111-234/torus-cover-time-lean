import Solutions.Blocks.B.GreenCharge
import Solutions.Blocks.B.EnergyAlgebra

/-! Attainment and uniqueness of variational capacity, with the registered normalization. -/

noncomputable section
open scoped BigOperators
namespace TorusCoverTime.Blocks.B

lemma dirichletPairing_admissible_charge (N : Size) (A : Finset (Vertex N))
    (q f : Vertex N → ℝ) (hq : greenChargeEquation N A q)
    (hmean : spatialMean N f = 0) (hboundary : ∀ x ∈ A, f x = 1) :
    dirichletPairing N f (greenOperator N q) = ∑ x : Vertex N, q x := by
  rw [dirichletPairing_green N f q hmean]
  apply Finset.sum_congr rfl
  intro x _
  by_cases hx : x ∈ A
  · rw [hboundary x hx, one_mul]
  · rw [hq.1 x hx, mul_zero]

lemma energy_admissible_decomposition (N : Size) (A : Finset (Vertex N))
    (q f : Vertex N → ℝ) (hq : greenChargeEquation N A q)
    (hmean : spatialMean N f = 0) (hboundary : ∀ x ∈ A, f x = 1) :
    energy N f = (∑ x : Vertex N, q x) + energy N (f - greenOperator N q) := by
  rw [energy_sub, energy_greenCharge N A q hq,
    dirichletPairing_admissible_charge N A q f hq hmean hboundary]
  ring

lemma capacity_eq_charge (N : Size) (A : Finset (Vertex N))
    (q : Vertex N → ℝ) (hq : greenChargeEquation N A q) :
    capacity N A = ∑ x : Vertex N, q x := by
  let S : Set ℝ := {r | ∃ f : Vertex N → ℝ, spatialMean N f = 0 ∧
    (∀ x ∈ A, f x = 1) ∧ energy N f = r}
  have hmem : (∑ x : Vertex N, q x) ∈ S :=
    ⟨greenOperator N q, greenOperator_mean_zero N q, hq.2, energy_greenCharge N A q hq⟩
  have hbelow : BddBelow S := by
    refine ⟨0, ?_⟩
    rintro r ⟨f, _, _, rfl⟩
    exact energy_nonneg N f
  change sInf S = _
  apply le_antisymm (csInf_le hbelow hmem)
  apply le_csInf ⟨_, hmem⟩
  rintro r ⟨f, hmean, hboundary, rfl⟩
  rw [energy_admissible_decomposition N A q f hq hmean hboundary]
  exact le_add_of_nonneg_right (energy_nonneg N _)

lemma capacity_pos (N : Size) (A : Finset (Vertex N))
    (hne : A.Nonempty) (hA : A ≠ Finset.univ) : 0 < capacity N A := by
  obtain ⟨q, hq⟩ := exists_greenCharge N A hA
  rw [capacity_eq_charge N A q hq]
  exact greenCharge_sum_pos N A hne hA q hq

lemma greenCharge_is_minimizer (N : Size) (A : Finset (Vertex N))
    (q : Vertex N → ℝ) (hq : greenChargeEquation N A q) :
    IsCapacityMinimizer N A (greenOperator N q) := by
  refine ⟨greenOperator_mean_zero N q, hq.2, ?_⟩
  rw [energy_greenCharge N A q hq, capacity_eq_charge N A q hq]

lemma capacity_minimizer_unique (N : Size) (A : Finset (Vertex N))
    (q f : Vertex N → ℝ) (hq : greenChargeEquation N A q)
    (hf : IsCapacityMinimizer N A f) : f = greenOperator N q := by
  have hmean : spatialMean N (f - greenOperator N q) = 0 := by
    rw [spatialMean_sub, hf.1, greenOperator_mean_zero, sub_self]
  have hdecomp := energy_admissible_decomposition N A q f hq hf.1 hf.2.1
  rw [hf.2.2, capacity_eq_charge N A q hq] at hdecomp
  have henergy : energy N (f - greenOperator N q) = 0 := by linarith
  exact sub_eq_zero.mp (energy_zero_of_mean_zero N _ hmean henergy)

lemma capacity_le_energy (N : Size) (A : Finset (Vertex N))
    (hA : A ≠ Finset.univ) (f : Vertex N → ℝ)
    (hmean : spatialMean N f = 0) (hboundary : ∀ x ∈ A, f x = 1) :
    capacity N A ≤ energy N f := by
  obtain ⟨q, hq⟩ := exists_greenCharge N A hA
  rw [capacity_eq_charge N A q hq,
    energy_admissible_decomposition N A q f hq hmean hboundary]
  exact le_add_of_nonneg_right (energy_nonneg N _)

end TorusCoverTime.Blocks.B
