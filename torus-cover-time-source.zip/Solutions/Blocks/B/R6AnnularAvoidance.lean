import Solutions.Blocks.B.AnnularPotential
import Solutions.Blocks.B.R6GreenEstimates

/-! Actual unconditioned annulus core-hit and core-avoidance probabilities
are 1/2 up to O(1/w), uniformly in the original exponential radii. -/

noncomputable section
open MeasureTheory Filter Classical
open scoped Topology
namespace TorusCoverTime.Blocks.B

def r6AnnularProbabilityConstant : ℝ := (2*annularBoundaryError + g*Real.log 3)/(2*g)

theorem r6AnnularProbabilityConstant_pos : 0 < r6AnnularProbabilityConstant := by
  have := annularBoundaryError_pos
  have hl : 0 < Real.log 3 := Real.log_pos (by norm_num)
  unfold r6AnnularProbabilityConstant g
  positivity

theorem r6_annular_probability_error (N : Size) (c a : Vertex N) (q w : ℝ)
    (hq : Real.log 2 ≤ q) (hw : Real.log 8 ≤ w)
    (hsmall : 2*(Real.exp (q+2*w)+1) < N.val)
    (ha : |periodicDistance a c - Real.exp (q+w)| ≤ 2) :
    |walkLaw.real (exitsInto N (torusDisk N c (Real.exp (q+2*w)) \ torusDisk N c (Real.exp q))
      (torusDisk N c (Real.exp q)) a) - 1/2| ≤ r6AnnularProbabilityConstant/w ∧
    |walkLaw.real (exitsAvoidingCore N (torusDisk N c (Real.exp (q+2*w)))
      (torusDisk N c (Real.exp q)) a) - 1/2| ≤ r6AnnularProbabilityConstant/w := by
  have hg : 0 < g := by unfold g; positivity
  have hw0 : 0 < w := (Real.log_pos (by norm_num : (1 : ℝ) < 8)).trans_le hw
  have hq0 : 0 ≤ q := (Real.log_nonneg (by norm_num : (1 : ℝ) ≤ 2)).trans hq
  have hr : 2 ≤ Real.exp q := by
    simpa only [Real.exp_log (by norm_num : (0 : ℝ) < 2)] using Real.exp_le_exp.mpr hq
  have hs : 8 ≤ Real.exp w := by
    simpa only [Real.exp_log (by norm_num : (0 : ℝ) < 8)] using Real.exp_le_exp.mpr hw
  have hρ : 8*Real.exp q ≤ Real.exp (q+w) := by
    rw [Real.exp_add]
    nlinarith [Real.exp_pos q]
  have hrR : Real.exp q < Real.exp (q+2*w) := Real.exp_lt_exp.mpr (by linarith)
  have hc : c ∈ torusDisk N c (Real.exp q) :=
    (mem_torusDisk N c c _).mpr (by rw [periodicDistance_self_zero]; exact Real.exp_pos q)
  have hgeom := r6_green_geometry N c a c q w hq0 hw ha hc
  have haA : a ∈ torusDisk N c (Real.exp (q+2*w)) \ torusDisk N c (Real.exp q) := by
    refine Finset.mem_sdiff.mpr ⟨hgeom.2.1, ?_⟩
    intro ham
    have ham' := (mem_torusDisk N c a _).mp ham
    have hl := (abs_le.mp ha).1
    linarith
  have hbalance := annular_core_probability_balance N c (Real.exp q) (Real.exp (q+2*w)) hr hrR hsmall a haA
  simp only [Real.log_exp] at hbalance
  have hlog := log_comparable_radius (Real.exp (q+w)) (periodicDistance a c)
    (Real.exp_pos _) hgeom.2.2.2.2.2.1 (hgeom.2.2.2.2.2.2.trans (by linarith [Real.exp_pos (q+w)]))
  rw [Real.log_exp] at hlog
  have hlog' : |g*(Real.log (periodicDistance a c)-(q+w))| ≤ g*Real.log 3 := by
    rw [abs_mul, abs_of_pos hg]
    exact mul_le_mul_of_nonneg_left hlog hg.le
  let p := walkLaw.real (exitsInto N (torusDisk N c (Real.exp (q+2*w)) \ torusDisk N c (Real.exp q))
    (torusDisk N c (Real.exp q)) a)
  have he : 2*g*w*(p-1/2) =
      (g*(q+2*w-q)*p-g*(q+2*w-Real.log (periodicDistance a c))) -
      g*(Real.log (periodicDistance a c)-(q+w)) := by ring
  have herr : |2*g*w*(p-1/2)| ≤ 2*annularBoundaryError + g*Real.log 3 := by
    rw [he]
    exact (abs_sub _ _).trans (add_le_add hbalance hlog')
  rw [abs_mul, abs_of_pos (by positivity : 0 < 2*g*w)] at herr
  have hp : |p-1/2| ≤ r6AnnularProbabilityConstant/w := by
    apply (le_div_iff₀ hw0).mpr
    unfold r6AnnularProbabilityConstant
    apply (le_div_iff₀ (by positivity : 0 < 2*g)).mpr
    nlinarith
  refine ⟨hp, ?_⟩
  have hsum := annulus_core_avoid_probabilities N (torusDisk N c (Real.exp (q+2*w)))
    (torusDisk N c (Real.exp q)) (torusDisk_proper N c _ (Real.exp_pos _).le hsmall)
    (torusDisk_subset N c _ _ hrR.le) a
  change p + _ = 1 at hsum
  have he' : walkLaw.real (exitsAvoidingCore N (torusDisk N c (Real.exp (q+2*w)))
      (torusDisk N c (Real.exp q)) a) - 1/2 = -(p-1/2) := by linarith
  rw [he', abs_neg]
  exact hp

theorem r6_unconditioned_avoidance (γ : ℝ) (hγ : 0 < γ) :
    ∀ᶠ q : ℝ in atTop, ∀ N : Size, ∀ c a : Vertex N,
      2*(Real.exp (q+2*q^γ)+1) < N.val →
      |periodicDistance a c - Real.exp (q+q^γ)| ≤ 2 →
      1/4 ≤ walkLaw.real (exitsAvoidingCore N (torusDisk N c (Real.exp (q+2*q^γ)))
        (torusDisk N c (Real.exp q)) a) := by
  filter_upwards [eventually_ge_atTop (Real.log 2),
    (tendsto_rpow_atTop hγ).eventually_ge_atTop (Real.log 8),
    (tendsto_rpow_atTop hγ).eventually_ge_atTop (4*r6AnnularProbabilityConstant)] with q hq hw hC
  intro N c a hsmall ha
  have hw0 : 0 < q^γ := (Real.log_pos (by norm_num : (1 : ℝ) < 8)).trans_le hw
  have he := (r6_annular_probability_error N c a q (q^γ) hq hw hsmall ha).2
  have hdiv : r6AnnularProbabilityConstant/q^γ ≤ 1/4 := (div_le_iff₀ hw0).mpr (by linarith)
  have hlo := (abs_le.mp he).1
  linarith

end TorusCoverTime.Blocks.B
