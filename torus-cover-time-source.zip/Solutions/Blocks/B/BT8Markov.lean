import Solutions.Blocks.B.BT8CountedCoarea

noncomputable section
open MeasureTheory Filter Set Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

theorem bt8Good_compl_measurable (N : Size) (root : Vertex N) (γ u : ℝ) :
    MeasurableSet {z | ¬bt8Good N root γ u z} := by
  simpa only [Set.compl_ofPred] using (bt8Good_measurable N root γ u).compl

def bt8WindowIndicator (E : Set (WalkSample × ℝ)) (l r : ℝ) (a : D.LoopSource) : ℝ≥0∞ :=
  if a.1∈Icc l r ∧ (a.2,a.1)∈E then 1 else 0

theorem bt8WindowIndicator_measurable (E : Set (WalkSample × ℝ)) (hE : MeasurableSet E) (l r : ℝ) :
    Measurable (bt8WindowIndicator E l r) :=
  measurable_const.ite ((measurable_fst measurableSet_Icc).inter (hE.preimage measurable_swap)) measurable_const

theorem bt8_loop_window_identity (N : Size) (E : Vertex N → Set (WalkSample × ℝ))
    (hE : ∀ root, MeasurableSet (E root)) (l r : ℝ) :
    r7LoopEventMass N E l r=(ENNReal.ofReal (timeScale N))⁻¹*
      ∑ root, ∫⁻ a, bt8WindowIndicator (E root) l r a ∂D.rootedLoopMeasure N root := by
  unfold r7LoopEventMass
  congr 1
  apply Finset.sum_congr rfl
  intro root _
  rw [rootedLoop_lintegral N root _ (bt8WindowIndicator_measurable _ (hE root) l r)]
  apply lintegral_congr
  intro ω
  apply lintegral_congr
  intro t
  unfold r7LoopEventTest bt8WindowIndicator
  split_ifs <;> simp_all

theorem bt8SourceWeight_sum (N : Size) (root : Vertex N) (γ u l r : ℝ) (a : D.LoopSource)
    (ht : a.1∈Icc l r) (hg : bt8Good N root γ u (a.2,a.1)) :
    (∑ x, bt8SourceWeight N root x γ u l r a)=ENNReal.ofReal (bt8SoftCount N root γ u (a.2,a.1)) := by
  unfold bt8SourceWeight bt8SoftCount
  simp only [ht,hg,true_and]
  rw [ENNReal.ofReal_sum_of_nonneg (fun x _ => by split_ifs <;> norm_num)]
  apply Finset.sum_congr rfl
  intro x _
  split_ifs <;> norm_num

theorem bt8_markov_point (N : Size) (root : Vertex N) (γ u l r t : ℝ) (ht : 0<t) (a : D.LoopSource) :
    bt8WindowIndicator {z | t<bt8SoftCount N root γ u z} l r a≤
      bt8WindowIndicator {z | ¬bt8Good N root γ u z} l r a+
        (ENNReal.ofReal t)⁻¹*(∑ x, bt8SourceWeight N root x γ u l r a) := by
  by_cases htime : a.1∈Icc l r
  · by_cases hg : bt8Good N root γ u (a.2,a.1)
    · rw [bt8SourceWeight_sum N root γ u l r a htime hg]
      simp only [bt8WindowIndicator,htime,Set.mem_ofPred_eq,hg,not_true_eq_false,and_false,if_false,zero_add,true_and]
      split_ifs with hc
      · have hh := mul_le_mul' (le_refl ((ENNReal.ofReal t)⁻¹)) (ENNReal.ofReal_le_ofReal hc.le)
        simpa only [ENNReal.inv_mul_cancel (ENNReal.ofReal_pos.mpr ht).ne' ENNReal.ofReal_ne_top] using hh
      · exact bot_le
    · simp only [bt8WindowIndicator,htime,Set.mem_ofPred_eq,hg,not_false_eq_true,and_self,if_true,true_and]
      split_ifs <;> simp
  · simp only [bt8WindowIndicator,htime,false_and,if_false]; exact bot_le

theorem bt8_markov (N : Size) (γ u l r t : ℝ) (ht : 0<t) :
    r7LoopEventMass N (fun root => {z | t<bt8SoftCount N root γ u z}) l r≤
      r7LoopEventMass N (fun root => {z | ¬bt8Good N root γ u z}) l r+
        (ENNReal.ofReal t)⁻¹*bt8GoodCountMass N γ u l r := by
  rw [bt8_loop_window_identity N _ (fun root =>
    measurableSet_lt measurable_const (bt8SoftCount_measurable N root γ u)),
    bt8_loop_window_identity N _ (fun root => bt8Good_compl_measurable N root γ u)]
  have hroot (root : Vertex N) :
      (∫⁻ a, bt8WindowIndicator {z | t<bt8SoftCount N root γ u z} l r a ∂D.rootedLoopMeasure N root)≤
        (∫⁻ a, bt8WindowIndicator {z | ¬bt8Good N root γ u z} l r a ∂D.rootedLoopMeasure N root)+
          (ENNReal.ofReal t)⁻¹*(∫⁻ a, ∑ x, bt8SourceWeight N root x γ u l r a ∂D.rootedLoopMeasure N root) := by
    have hh := lintegral_mono (μ := D.rootedLoopMeasure N root) (bt8_markov_point N root γ u l r t ht)
    refine hh.trans_eq ?_
    rw [lintegral_add_left (bt8WindowIndicator_measurable _ (bt8Good_compl_measurable N root γ u) l r),
      lintegral_const_mul _ (Finset.measurable_sum _ (fun x _ => bt8SourceWeight_measurable N root x γ u l r))]
  have hh := mul_le_mul' (le_refl ((ENNReal.ofReal (timeScale N))⁻¹))
    (Finset.sum_le_sum (fun root (_ : root∈(Finset.univ:Finset (Vertex N))) => hroot root))
  simp only [Finset.sum_add_distrib,← Finset.mul_sum,mul_add,bt8GoodCountMass] at hh ⊢
  exact hh.trans_eq (by ac_rfl)

end TorusCoverTime.Blocks.B
