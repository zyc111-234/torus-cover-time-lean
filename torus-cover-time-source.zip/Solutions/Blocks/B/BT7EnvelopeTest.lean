import Solutions.Blocks.B.BT7DirichletProbability
import Solutions.Blocks.B.BT7EventTransfer

noncomputable section
open MeasureTheory ProbabilityTheory Classical Set
namespace TorusCoverTime.Blocks.B

def bt7EnvelopeTest (N : Size) (x : Vertex N) (γ η b U : ℝ) : Set ((Vertex N → ℝ) × ℝ) :=
  {v | |v.1 x-harmonicExtremeCenter N|≤b+v.2 ∧ (v.2≤U → bt6BadField N x γ η η v.1)}

theorem bt7EnvelopeTest_measurableSet (N : Size) (x : Vertex N) (γ η b U : ℝ) :
    MeasurableSet (bt7EnvelopeTest N x γ η b U) := by
  change MeasurableSet ({v : (Vertex N → ℝ) × ℝ | |v.1 x-harmonicExtremeCenter N|≤b+v.2} ∩
    {v : (Vertex N → ℝ) × ℝ | v.2≤U → bt6BadField N x γ η η v.1})
  apply MeasurableSet.inter
  · exact measurableSet_le (f := fun v : (Vertex N → ℝ) × ℝ => |v.1 x-harmonicExtremeCenter N|)
      (g := fun v => b+v.2) (by fun_prop) (by fun_prop)
  · have he : {v : (Vertex N → ℝ) × ℝ | v.2≤U → bt6BadField N x γ η η v.1}=
        {v | v.2≤U}ᶜ ∪ {v | bt6BadField N x γ η η v.1} := by ext v; simp only [mem_setOf_eq,mem_union,mem_compl_iff]; tauto
    rw [he]
    exact (measurableSet_le measurable_snd measurable_const).compl.union
      ((bt6BadField_measurableSet N x γ η η).preimage measurable_fst)

theorem bt6BadField_mono (N : Size) (x : Vertex N) (γ η δ η' δ' : ℝ)
    (hη : η≤η') (hδ : δ≤δ') (f : Vertex N → ℝ) (h : bt6BadField N x γ η δ f) :
    bt6BadField N x γ η' δ' f := by
  rcases h with ⟨a,ha,hl,q,hq,hq',hu⟩
  refine ⟨a,ha.trans hη,?_,q,hq,hq',by linarith⟩
  intro j hj hj'
  linarith [hl j hj hj']

theorem bt7EnvelopeTest_section_bound (N : Size) (root c x : Vertex N) (ρ γ η b U P : ℝ)
    (hρ : 0<ρ) (hb : 0≤b) (hR : 1≤ρ*(N.val:ℝ)) (hsmall : 2*(ρ*(N.val:ℝ)+1)<N.val)
    (hroot : root∉torusDisk N c (ρ*(N.val:ℝ))) (hx : periodicDistance x c≤ρ*(N.val:ℝ)/2)
    (hL : 8*(bt6ClockError ρ+1)≤logSize N) (hη : b+U≤η) (hP : 0≤P)
    (hcond : ∀ t : ℝ, |t-harmonicExtremeCenter N|≤η →
      (finiteFieldLaw N).real {ζ | bt6BadField N x γ η η
        (dirichletConditionedField N root (torusDisk N c (ρ*(N.val:ℝ))) x t ζ)}≤P)
    (T : ℝ) (hT : 0≤T) :
    (finiteFieldLaw N).real {ξ | (dirichletFieldLS N root (torusDisk N c (ρ*(N.val:ℝ))) ξ,T)∈bt7EnvelopeTest N x γ η b U}≤
      (2*Real.exp (8*bt6ClockError ρ)/vertexCount N*logSize N)*
        ((b+T)*Real.exp (8*(b+T))*(if T≤U then P else 1)) := by
  let D := torusDisk N c (ρ*(N.val:ℝ))
  have hbT : 0≤b+T := add_nonneg hb hT
  have he := dirichlet_endpoint_interval N root c x ρ (b+T) hρ hbT hR hsmall hroot hx hL
  by_cases ht : T≤U
  · have hv := (bt6_clock_comparison (logSize N) (bt6ClockError ρ) _ (bt6ClockError_pos ρ).le hL
      (dirichlet_macroscopic_clock N root c x ρ hρ hR hsmall hroot hx)).1
    have hh := bt6_endpoint_restricted_probability N root D hroot x hv γ η η (b+T) P
      (fun t h => hcond t (h.trans (by linarith)))
    have htest : {ξ | (dirichletFieldLS N root D ξ,T)∈bt7EnvelopeTest N x γ η b U}=
        {ξ | |dirichletFieldLS N root D ξ x-harmonicExtremeCenter N|≤b+T ∧ bt6BadField N x γ η η (dirichletFieldLS N root D ξ)} := by
      ext ξ
      simp only [bt7EnvelopeTest,mem_setOf_eq,ht,true_implies]
    rw [htest,if_pos ht]
    refine hh.trans ((mul_le_mul_of_nonneg_left he hP).trans_eq ?_)
    ring
  · have htest : {ξ | (dirichletFieldLS N root D ξ,T)∈bt7EnvelopeTest N x γ η b U}=
        {ξ | |dirichletFieldLS N root D ξ x-harmonicExtremeCenter N|≤b+T} := by
      ext ξ
      simp only [bt7EnvelopeTest,mem_setOf_eq,ht,false_implies,and_true]
    rw [htest,if_neg ht]
    exact he.trans_eq (by ring)

end TorusCoverTime.Blocks.B
