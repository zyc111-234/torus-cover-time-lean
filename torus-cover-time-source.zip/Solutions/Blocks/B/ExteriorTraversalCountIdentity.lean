import Solutions.Blocks.B.ExteriorTraversalPrefixIdentity
import Solutions.Blocks.B.TraversalScanPhysicalCount
import Solutions.Blocks.B.JumpCountRestart

/-! The original outer completed count is an actual complete-exterior observable after inner-record erasure. -/
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B


theorem exteriorTraversalCount_actual_ae (N : Size) (I J Q O : Finset (Vertex N))
    (hIJ : I ⊆ J) (hI : I.Nonempty) (hJQ : J ⊆ Q) (hQO : Q ⊆ O)
    (root c : Vertex N) (hr : root ∉ O) (hc : c ∈ Q) (m : ℕ) (w : Fin (2*m) → Vertex N) :
    ∀ᵐ ω ∂walkLaw[|{ω | adaptiveExitWord N (alternatingDomain N I J) root (2*m) ω = w}],
      ∀ t, adaptiveExitTime N (alternatingDomain N I J) root (2*m) ω ≤ t →
      completedTraversalCount N Q O root ω t =
        exteriorTraversalCount N Q O root c m w
          (traversalExteriorData N I J root m ω,t-adaptiveExitTime N (alternatingDomain N I J) root (2*m) ω) := by
  have hrJ : root ∉ J := fun hx => hr (hQO (hJQ hx))
  have hac : walkLaw[|{ω | adaptiveExitWord N (alternatingDomain N I J) root (2*m) ω = w}] ≪ walkLaw :=
    cond_absolutelyContinuous
  filter_upwards [exteriorTraversal_prefix_identity N I J Q O hIJ hI hJQ hQO root c hrJ hc m w,
    hac.ae_le (completedTraversalCount_eq_scan_ae N Q O hQO ⟨c,hc⟩ root hr),
    hac.ae_le A.holding_positive_and_nonexplosive,hac.ae_le walk_all_shifts_regular,
    ae_cond_mem (μ := walkLaw) ((adaptiveExitWord_measurable N _ root (2*m)) (measurableSet_singleton w))]
    with ω hprefix hcount hreg hshift hw
  intro t ht
  have ht0 : 0 ≤ t := (jumpTime_nonneg ω _).trans ht
  rw [hcount t ht0,traversalPrefixScan_physical_restart N Q O root ω _ hreg.1 (hshift _).2 t ht]
  change traversalPrefixScan N Q O (adaptiveExitStart N (alternatingDomain N I J) root (2*m) ω)
    (adaptiveExitTail N (alternatingDomain N I J) root (2*m) ω)
    (jumpCount (adaptiveExitTail N (alternatingDomain N I J) root (2*m) ω)
      (t-adaptiveExitTime N (alternatingDomain N I J) root (2*m) ω)+1)
    (traversalPrefixScan N Q O root ω (adaptiveExitIndex N (alternatingDomain N I J) root (2*m) ω) 0)/2 = _
  rw [← hprefix,adaptiveExitStart_of_word N _ root (2*m) w ω hw (2*m) le_rfl]
  rfl


end TorusCoverTime.Blocks.B

