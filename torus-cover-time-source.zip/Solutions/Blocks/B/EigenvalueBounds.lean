import Solutions.Blocks.B.FiniteSpectrum

/-! The centered frequency comparisons in the first clause of FourierWalkIdentities. -/

noncomputable section
namespace TorusCoverTime.Blocks.B

lemma coordinateDistance_zero_eq_min (N : Size) (k : ZMod N.val) :
    coordinateDistance k 0 = min (k.val : ℝ) ((N.val : ℝ) - k.val) := by
  simp only [coordinateDistance, ZMod.val_zero, Nat.cast_zero, sub_zero,
    abs_of_nonneg (show 0 ≤ (k.val : ℝ) from Nat.cast_nonneg k.val)]

lemma coordinateDistance_zero_bounds (N : Size) (k : ZMod N.val) :
    0 ≤ coordinateDistance k 0 ∧ coordinateDistance k 0 ≤ (N.val : ℝ) / 2 := by
  rw [coordinateDistance_zero_eq_min]
  have h0 : (0 : ℝ) ≤ k.val := Nat.cast_nonneg k.val
  have hk : (k.val : ℝ) < N.val := by exact_mod_cast ZMod.val_lt k
  refine ⟨le_min h0 (by linarith), ?_⟩
  have h1 := min_le_left (k.val : ℝ) ((N.val : ℝ) - k.val)
  have h2 := min_le_right (k.val : ℝ) ((N.val : ℝ) - k.val)
  linarith

lemma sine_val_eq_sine_distance (N : Size) (k : ZMod N.val) :
    Real.sin (Real.pi * k.val / N.val) =
      Real.sin (Real.pi * coordinateDistance k 0 / N.val) := by
  have hN : (N.val : ℝ) ≠ 0 := ne_of_gt (lt_trans zero_lt_one (size_real_gt_one N))
  rw [coordinateDistance_zero_eq_min]
  rcases le_total (k.val : ℝ) ((N.val : ℝ) - k.val) with hk | hk
  · rw [min_eq_left hk]
  · rw [min_eq_right hk]
    have heq : Real.pi * ((N.val : ℝ) - k.val) / N.val =
        Real.pi - Real.pi * k.val / N.val := by field_simp
    rw [heq, Real.sin_pi_sub]

lemma finite_sine_distance_bounds (N : Size) (k : ZMod N.val) :
    (2 * coordinateDistance k 0 / N.val) ^ 2 ≤
        Real.sin (Real.pi * k.val / N.val) ^ 2 ∧
    Real.sin (Real.pi * k.val / N.val) ^ 2 ≤
        (Real.pi * coordinateDistance k 0 / N.val) ^ 2 := by
  have hN : 0 < (N.val : ℝ) := lt_trans zero_lt_one (size_real_gt_one N)
  have hd := coordinateDistance_zero_bounds N k
  have ha0 : 0 ≤ Real.pi * coordinateDistance k 0 / N.val :=
    div_nonneg (mul_nonneg Real.pi_pos.le hd.1) hN.le
  have hahalf : Real.pi * coordinateDistance k 0 / N.val ≤ Real.pi / 2 := by
    apply (div_le_iff₀ hN).mpr
    have h := mul_le_mul_of_nonneg_left hd.2 Real.pi_pos.le
    nlinarith
  have hlower := Real.mul_le_sin ha0 hahalf
  have heq : 2 / Real.pi * (Real.pi * coordinateDistance k 0 / N.val) =
      2 * coordinateDistance k 0 / N.val := by field_simp
  rw [heq] at hlower
  rw [sine_val_eq_sine_distance]
  refine ⟨pow_le_pow_left₀ (div_nonneg (mul_nonneg zero_le_two hd.1) hN.le) hlower 2, ?_⟩
  exact Real.sin_sq_le_sq

lemma eigenvalue_frequency_bounds (N : Size) (k : Vertex N) :
    4 * frequencyNormSq N k / vertexCount N ≤ finiteEigenvalue N k ∧
    finiteEigenvalue N k ≤ Real.pi ^ 2 * frequencyNormSq N k / vertexCount N := by
  have h1 := finite_sine_distance_bounds N k.1
  have h2 := finite_sine_distance_bounds N k.2
  rw [finiteEigenvalue_eq_sines]
  unfold frequencyNormSq vertexCount
  constructor
  · calc
      4 * (coordinateDistance k.1 0 ^ 2 + coordinateDistance k.2 0 ^ 2) / (N.val : ℝ) ^ 2
          = (2 * coordinateDistance k.1 0 / N.val) ^ 2 +
            (2 * coordinateDistance k.2 0 / N.val) ^ 2 := by ring
      _ ≤ _ := add_le_add h1.1 h2.1
  · calc
      Real.sin (Real.pi * k.1.val / N.val) ^ 2 + Real.sin (Real.pi * k.2.val / N.val) ^ 2
          ≤ (Real.pi * coordinateDistance k.1 0 / N.val) ^ 2 +
            (Real.pi * coordinateDistance k.2 0 / N.val) ^ 2 := add_le_add h1.2 h2.2
      _ = _ := by ring

end TorusCoverTime.Blocks.B
