import Solutions.Blocks.B.PeriodicAnnular

/-! Actual annular multipliers: exact normalization and uniform derivatives on a fundamental cell. -/

noncomputable section
open Function
open scoped Topology ContDiff BigOperators
namespace TorusCoverTime.Blocks.B

lemma periodicAnnularCore_fundamental_derivative_bound (ds : List (Fin 4)) (p : ℕ) :
    ∃ C : ℝ, 0 < C ∧ ∀ a x y : ℝ, |a| ≤ 2 →
      |a * x| ≤ 1 / 2 → |a * y| ≤ 1 / 2 →
      ‖iteratedFDeriv ℝ p (fun v : ℝ × (ℝ × ℝ) => periodicAnnularCore ds v.1 v.2.1 v.2.2)
        (a, x, y)‖ ≤ C := by
  let F := fun v : ℝ × (ℝ × ℝ) => periodicAnnularCore ds v.1 v.2.1 v.2.2
  let K : Set (ℝ × (ℝ × ℝ)) := Set.Icc (-2) 2 ×ˢ
    (Set.Icc (-4) 4 ×ˢ Set.Icc (-4) 4)
  have hK : IsCompact K := isCompact_Icc.prod (isCompact_Icc.prod isCompact_Icc)
  have hcont : ContinuousOn (iteratedFDeriv ℝ p F) K := by
    intro v _
    exact ((periodicAnnularCore_contDiff ds).contDiffAt.continuousAt_iteratedFDeriv (k := p)
      (by exact_mod_cast (le_top : (p : ℕ∞) ≤ ⊤))).continuousWithinAt
  obtain ⟨B, hB⟩ := hK.exists_bound_of_continuousOn hcont
  let S : Set (ℝ × (ℝ × ℝ)) :=
    {v | |sineCoordinate v.1 v.2.1| ≤ 2} ∩ {v | |sineCoordinate v.1 v.2.2| ≤ 2}
  have hS : IsClosed S := by
    apply IsClosed.inter
    · exact isClosed_le (by fun_prop) continuous_const
    · exact isClosed_le (by fun_prop) continuous_const
  have hsupp : support F ⊆ S := by
    rintro ⟨a, x, y⟩ hv
    constructor
    · by_contra hx
      exact hv (periodicAnnularCore_zero_outer ds a x y (Or.inl (le_of_lt (lt_of_not_ge hx))))
    · by_contra hy
      exact hv (periodicAnnularCore_zero_outer ds a x y (Or.inr (le_of_lt (lt_of_not_ge hy))))
  have hdsupp : support (iteratedFDeriv ℝ p F) ⊆ S :=
    (support_iteratedFDeriv_subset p).trans (closure_minimal hsupp hS)
  refine ⟨max 1 B, lt_of_lt_of_le zero_lt_one (le_max_left _ _), ?_⟩
  intro a x y ha hx hy
  change ‖iteratedFDeriv ℝ p F (a, x, y)‖ ≤ _
  by_cases hz : iteratedFDeriv ℝ p F (a, x, y) = 0
  · rw [hz, norm_zero]
    exact le_trans zero_le_one (le_max_left _ _)
  · have hs := hdsupp hz
    have hxb : |x| ≤ 4 := (sineCoordinate_bound_implies_coordinate_bound a x hx hs.1).trans Real.pi_le_four
    have hyb : |y| ≤ 4 := (sineCoordinate_bound_implies_coordinate_bound a y hy hs.2).trans Real.pi_le_four
    exact (hB (a, x, y) ⟨abs_le.mp ha, abs_le.mp hxb, abs_le.mp hyb⟩).trans (le_max_right _ _)

lemma list_scaled_product (ds : List (Fin 4)) (a : ℂ) (f : Fin 4 → ℂ) :
    (ds.map (fun d => a * f d)).prod = a ^ ds.length * (ds.map f).prod := by
  induction ds with
  | nil => simp
  | cons d ds ih =>
    simp only [List.map_cons, List.prod_cons, List.length_cons, ih, pow_succ]
    ring

def annularArray (N : Size) (R : ℝ) (ds : List (Fin 4)) (k : Vertex N) : ℂ :=
  ((frequencyCutoff N R k - frequencyCutoff N (R / 2) k : ℝ) : ℂ) * greenMultiplier N k *
    (ds.map (fun d => finiteCharacter N k (direction N d) - 1)).prod

lemma annularArray_scaled (N : Size) (R : ℝ) (hR : R ≠ 0)
    (ds : List (Fin 4)) (k : Vertex N) :
    annularArray N R ds k = (((R / N.val) ^ ds.length / R ^ 2 : ℝ) : ℂ) *
      periodicAnnularCore ds (R / N.val) ((k.1.valMinAbs : ℝ) / R) ((k.2.valMinAbs : ℝ) / R) := by
  have hN : (N.val : ℝ) ≠ 0 := ne_of_gt (lt_trans zero_lt_one (size_real_gt_one N))
  by_cases hk : k = 0
  · subst k
    have hz : annularReciprocal 0 (0 : ℝ) 0 = 0 := by
      simp [annularReciprocal, annularCutoff, rectangleCutoff]
    simp [annularArray, greenMultiplier, periodicAnnularCore, sineCoordinate, hz]
  · have hEig : 0 < finiteEigenvalue N k :=
      eigenvalue_pos_of_nonzero N (by simpa [nonzeroFrequencies] using hk)
    have hS : scaledSymbol (R / N.val) ((k.1.valMinAbs : ℝ) / R) ((k.2.valMinAbs : ℝ) / R) ≠ 0 := by
      intro hz
      have heq := finiteEigenvalue_eq_scaledSymbol N k R hR
      rw [hz, mul_zero] at heq
      exact hEig.ne' heq
    rw [annularArray, frequencyCutoff_difference N R hR, greenMultiplier, if_neg hk,
      periodicAnnularCore_eq]
    simp_rw [finiteCharacter_direction_increment_scaled N k R hR]
    rw [list_scaled_product]
    unfold frequencySineCoordinate
    rw [finiteEigenvalue_eq_scaledSymbol N k R hR]
    unfold vertexCount
    push_cast
    have hRc : (R : ℂ) ≠ 0 := by exact_mod_cast hR
    have hNc : (N.val : ℂ) ≠ 0 := by exact_mod_cast hN
    have hSc : (scaledSymbol (R / N.val) ((k.1.valMinAbs : ℝ) / R)
      ((k.2.valMinAbs : ℝ) / R) : ℂ) ≠ 0 := by exact_mod_cast hS
    field_simp [hRc, hNc, hSc]

end TorusCoverTime.Blocks.B
