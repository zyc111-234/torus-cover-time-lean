import Solutions.Blocks.B.LogarithmicStencil

/-! The scalar logarithmic cancellation on the actual lattice and on the
embedded finite torus. This is groundwork for precise Green centering;
normalization of the total source is a separate obligation. -/

noncomputable section
open Classical
namespace TorusCoverTime.Blocks.B

def latticeLogPotential (z : LatticePoint) : ℝ := Real.log (latticeRadius z)

theorem lattice_log_generator_error (z : LatticePoint) (hz : 2 ≤ latticeRadius z) :
    |(1/4:ℝ)*(∑ d : Fin 4, (latticeLogPotential (z+latticeDirection d)-latticeLogPotential z))| ≤
      1/(latticeRadius z)^4 := by
  have hsq := latticeRadius_sq z
  have hs : 4 ≤ (z.1:ℝ)^2+(z.2:ℝ)^2 := by nlinarith [Real.sqrt_nonneg ((z.1:ℝ)^2+(z.2:ℝ)^2)]
  have h := logarithmic_stencil_error (z.1:ℝ) (z.2:ℝ) hs
  have hlog (w : LatticePoint) : latticeLogPotential w = Real.log ((w.1:ℝ)^2+(w.2:ℝ)^2)/2 :=
    Real.log_sqrt (by positivity)
  have he : (1/4:ℝ)*(∑ d : Fin 4, (latticeLogPotential (z+latticeDirection d)-latticeLogPotential z)) =
      (Real.log (((z.1:ℝ)+1)^2+(z.2:ℝ)^2)+Real.log (((z.1:ℝ)-1)^2+(z.2:ℝ)^2)+
        Real.log ((z.1:ℝ)^2+((z.2:ℝ)+1)^2)+Real.log ((z.1:ℝ)^2+((z.2:ℝ)-1)^2)-
          4*Real.log ((z.1:ℝ)^2+(z.2:ℝ)^2))/8 := by
    simp [Fin.sum_univ_succ, hlog, latticeDirection, Prod.fst_add, Prod.snd_add]
    <;> ring
  rw [he, show (latticeRadius z)^4 = ((z.1:ℝ)^2+(z.2:ℝ)^2)^2 by
    calc
      _ = ((latticeRadius z)^2)^2 := by ring
      _ = _ := by rw [hsq]]
  exact h

theorem torus_log_generator_error (N : Size) (c x : Vertex N)
    (hx : 2 ≤ periodicDistance x c) (hsmall : 2*(periodicDistance x c+1) < N.val) :
    |generator N (fun z => Real.log (periodicDistance z c)) x| ≤ 1/(periodicDistance x c)^4 := by
  have h := lattice_log_generator_error (centeredLift N c x) (by rwa [latticeRadius_centeredLift])
  have heq (d : Fin 4) : periodicDistance (x+direction N d) c =
      latticeRadius (centeredLift N c x+latticeDirection d) := by
    rw [← centeredLift_add_direction N c x d hsmall, latticeRadius_centeredLift]
  simpa only [generator, heq, latticeLogPotential, latticeRadius_centeredLift] using h

end TorusCoverTime.Blocks.B
