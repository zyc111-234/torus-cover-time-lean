import Solutions.Blocks.B.IteratedOscillation
import Solutions.Blocks.B.R6ConditionedHitting

/-! Relative oscillation of the actual specified-endpoint exit kernel.
The finite scale iteration is explicit; its R6 specialization is uniform
over the torus, center, entry, exterior exit, and core point. -/

noncomputable section
open MeasureTheory Filter Classical
open scoped Topology
namespace TorusCoverTime.Blocks.B

theorem disk_exit_relative_oscillation (N : Size) (c : Vertex N) (R : ℝ)
    (hR : 3*diskHarnackRadiusThreshold ≤ R) (hsmall : 2*(R+1) < N.val)
    (a b x : Vertex N) (hb : diskExteriorNeighbor N c R b) (k : ℕ)
    (hk : 2*diskHarnackRadiusThreshold ≤ (R/(24*diskGreenInnerScale))/diskOscillationScale^k)
    (ha : a ∈ torusDisk N c ((R/(24*diskGreenInnerScale))/diskOscillationScale^k))
    (hx : x ∈ torusDisk N c ((R/(24*diskGreenInnerScale))/diskOscillationScale^k)) :
    |exitHarmonic N (torusDisk N c R) b x / exitHarmonic N (torusDisk N c R) b a - 1| ≤
      diskHarnackConstant*diskOscillationFactor^k := by
  have hT := diskHarnackRadiusThreshold_ge_one
  have hR0 : 0 < R := by linarith
  have hL := diskGreenInnerScale_ge_four
  have hL0 : 0 < diskGreenInnerScale := by linarith
  let A := R/(24*diskGreenInnerScale)
  have hA0 : 0 < A := div_pos hR0 (by positivity)
  have hAR : A ≤ R/4 := div_le_div_of_nonneg_left hR0.le (by norm_num) (by linarith)
  have hAi : A ≤ R/(12*diskGreenInnerScale) :=
    div_le_div_of_nonneg_left hR0.le (by positivity) (by linarith)
  have hrad := disk_scale_radius_le A hA0.le k
  have haA : periodicDistance a c < A := ((mem_torusDisk N c a _).mp ha).trans_le hrad
  have haD : a ∈ torusDisk N c R := (mem_torusDisk N c a R).mpr (by linarith)
  have hp := disk_exitHarmonic_pos N c R hR0 (by linarith) a b haD hb
  let f := exitHarmonic N (torusDisk N c R) b
  have hgen : ∀ z ∈ torusDisk N c A, generator N f z = 0 := by
    intro z hz
    have hd := (mem_torusDisk N c z A).mp hz
    exact exitHarmonic_generator N _ b z ((mem_torusDisk N c z R).mpr (by linarith))
  have hbounds : ∀ z ∈ torusDisk N c A, 0 ≤ f z ∧ f z ≤ diskHarnackConstant*f a := by
    intro z hz
    refine ⟨exitHarmonic_nonneg N _ b z, ?_⟩
    exact disk_harnack_small_torus N c R hR hsmall f (exitHarmonic_nonneg N _ b)
      (fun y hy => exitHarmonic_generator N _ b y hy) a z (haA.le.trans hAi)
      (((mem_torusDisk N c z A).mp hz).le.trans hAi)
  have he := disk_iterated_oscillation N c A hA0 (by linarith) f 0 (diskHarnackConstant*f a)
    hbounds hgen k hk x a hx ha
  have hid : f x/f a-1 = (f x-f a)/f a := by field_simp [show f a ≠ 0 from hp.ne']
  change |f x/f a-1| ≤ _
  rw [hid, abs_div, abs_of_pos hp]
  apply (div_le_iff₀ hp).mpr
  simpa only [sub_zero, mul_assoc, mul_left_comm, mul_comm] using he

theorem r6_oscillation_geometry (γ : ℝ) (hγ : 0 < γ) (k : ℕ) :
    ∀ᶠ q : ℝ in atTop, ∀ N : Size, ∀ c a x : Vertex N,
      |periodicDistance a c - Real.exp (q+q^γ)| ≤ 2 →
      x ∈ torusDisk N c (Real.exp q) →
      3*diskHarnackRadiusThreshold ≤ Real.exp (q+2*q^γ) ∧
      2*diskHarnackRadiusThreshold ≤
        (Real.exp (q+2*q^γ)/(24*diskGreenInnerScale))/diskOscillationScale^k ∧
      a ∈ torusDisk N c ((Real.exp (q+2*q^γ)/(24*diskGreenInnerScale))/diskOscillationScale^k) ∧
      x ∈ torusDisk N c ((Real.exp (q+2*q^γ)/(24*diskGreenInnerScale))/diskOscillationScale^k) := by
  have hL := diskGreenInnerScale_ge_four
  have hL0 : 0 < diskGreenInnerScale := by linarith
  have hS := diskOscillationScale_ge_two
  have hS0 : 0 < diskOscillationScale := by linarith
  have hT := diskHarnackRadiusThreshold_ge_one
  have hT0 : 0 < 3*diskHarnackRadiusThreshold := by linarith
  let K := 24*diskGreenInnerScale*diskOscillationScale^k
  have hK0 : 0 < K := by dsimp [K]; positivity
  filter_upwards [eventually_ge_atTop (1:ℝ),
    eventually_ge_atTop (Real.log (3*diskHarnackRadiusThreshold)),
    (tendsto_rpow_atTop hγ).eventually_ge_atTop (Real.log (8*K))] with q hq hqt hqw
  intro N c a x ha hx
  have hq0 : 0 < q := by linarith
  have hw0 : 0 < q^γ := Real.rpow_pos_of_pos hq0 γ
  have hρ0 : 0 < Real.exp (q+q^γ) := Real.exp_pos _
  have hρ1 : 1 ≤ Real.exp (q+q^γ) := Real.one_le_exp_iff.mpr (by linarith)
  have hρT : 3*diskHarnackRadiusThreshold ≤ Real.exp (q+q^γ) := by
    have he := Real.exp_le_exp.mpr (hqt.trans (by linarith : q ≤ q+q^γ))
    rwa [Real.exp_log hT0] at he
  have hew : 8*K ≤ Real.exp (q^γ) := by
    simpa only [Real.exp_log (by positivity : 0 < 8*K)] using Real.exp_le_exp.mpr hqw
  have hRρ : 8*Real.exp (q+q^γ) ≤ Real.exp (q+2*q^γ)/K := by
    apply (le_div_iff₀ hK0).mpr
    rw [show q+2*q^γ = (q+q^γ)+q^γ by ring, Real.exp_add (q+q^γ) (q^γ)]
    nlinarith
  have hid : (Real.exp (q+2*q^γ)/(24*diskGreenInnerScale))/diskOscillationScale^k =
      Real.exp (q+2*q^γ)/K := by dsimp [K]; ring
  rw [hid]
  have hax := (abs_le.mp ha).2
  have hxc := (mem_torusDisk N c x (Real.exp q)).mp hx
  have hinner : Real.exp q ≤ Real.exp (q+q^γ) := Real.exp_le_exp.mpr (by linarith)
  refine ⟨?_, by linarith, ?_, ?_⟩
  · have he := Real.exp_le_exp.mpr (hqt.trans (by linarith : q ≤ q+2*q^γ))
    rwa [Real.exp_log hT0] at he
  · exact (mem_torusDisk N c a _).mpr (by linarith)
  · exact (mem_torusDisk N c x _).mpr (by linarith)

theorem r6_exit_ratio_eventually (γ : ℝ) (hγ : 0 < γ) (ε : ℝ) (hε : 0 < ε) :
    ∀ᶠ q : ℝ in atTop, ∀ N : Size, ∀ c a b x : Vertex N,
      2*(Real.exp (q+2*q^γ)+1) < N.val →
      |periodicDistance a c - Real.exp (q+q^γ)| ≤ 2 →
      diskExteriorNeighbor N c (Real.exp (q+2*q^γ)) b →
      x ∈ torusDisk N c (Real.exp q) →
      |exitHarmonic N (torusDisk N c (Real.exp (q+2*q^γ))) b x /
          exitHarmonic N (torusDisk N c (Real.exp (q+2*q^γ))) b a - 1| ≤ ε := by
  have hH0 : 0 < diskHarnackConstant := zero_lt_one.trans diskHarnackConstant_gt_one
  have hlim := tendsto_pow_atTop_nhds_zero_of_lt_one diskOscillationFactor_bounds.1.le
    diskOscillationFactor_bounds.2
  obtain ⟨k,hk⟩ := (hlim.eventually (gt_mem_nhds (div_pos hε hH0))).exists
  have hbound : diskHarnackConstant*diskOscillationFactor^k ≤ ε := by
    have hh := (lt_div_iff₀ hH0).mp hk
    nlinarith
  filter_upwards [r6_oscillation_geometry γ hγ k] with q hq
  intro N c a b x hsmall ha hb hx
  obtain ⟨hR,hkR,haR,hxR⟩ := hq N c a x ha hx
  exact (disk_exit_relative_oscillation N c _ hR hsmall a b x hb k hkR haR hxR).trans hbound

end TorusCoverTime.Blocks.B
