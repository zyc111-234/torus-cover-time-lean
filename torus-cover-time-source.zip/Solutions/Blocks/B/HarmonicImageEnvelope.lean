import Solutions.Blocks.B.R7HarmonicCoarea
import Solutions.Blocks.B.HarmonicGaussianTail

/-! The coarea image's harmonic square radius controls the shifted Gaussian
average for either sign. An amplitude interval yields a measurable field-only
tail envelope, with no independence assumption on the amplitude. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal NNReal
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

theorem probability_weights_square_bound {ι : Type*} [Fintype ι] (w f : ι → ℝ)
    (hw : ∀ i, 0 ≤ w i) (hs : ∑ i, w i = 1) : (∑ i, w i*f i)^2 ≤ ∑ i, w i*f i^2 := by
  have hh := Finset.sum_sq_le_sum_mul_sum_of_sq_le_mul (R := ℝ) Finset.univ
    (r := fun i => w i*f i) (f := w) (g := fun i => w i*f i^2)
    (fun i _ => hw i) (fun i _ => mul_nonneg (hw i) (sq_nonneg _)) (fun i _ => by nlinarith [sq_nonneg (w i*f i)])
  simpa only [hs,one_mul] using hh

theorem probability_weights_normalized_abs {ι : Type*} [Fintype ι] (w f : ι → ℝ)
    (hw : ∀ i, 0 ≤ w i) (hs : ∑ i, w i = 1) (d : ℝ) (hd : 0 < d) :
    |(∑ i, w i*f i)/Real.sqrt d| ≤ Real.sqrt ((∑ i, w i*f i^2)/d) := by
  apply (sq_le_sq₀ (abs_nonneg _) (Real.sqrt_nonneg _)).mp
  rw [sq_abs,div_pow,Real.sq_sqrt hd.le,
    Real.sq_sqrt (div_nonneg (Finset.sum_nonneg (fun i _ => mul_nonneg (hw i) (sq_nonneg _))) hd.le)]
  exact div_le_div_of_nonneg_right (probability_weights_square_bound w f hw hs) hd.le

def harmonicShiftedSquareImage (N : Size) (ξ : FiniteFieldSample N) (a : ℝ) (σ : Bool) : D.CoareaImage N :=
  (0,fun x => (finiteGaussianField N ξ x+(if σ then a else -a))^2)

theorem harmonic_shifted_image_average (N : Size) (c : Vertex N) (q : ℝ)
    (hsmall : 2*(Real.exp (q+1)+1) < N.val) (ξ : FiniteFieldSample N) (a : ℝ) (σ : Bool) :
    |harmonicGaussianAverage N c q ξ+(if σ then a else -a)/Real.sqrt (2*g)| ≤
      harmonicImageRadius N c q (harmonicShiftedSquareImage N ξ a σ) := by
  have hw := diskHarmonicWeight_nonneg N c (Real.exp (q+1))
  have hs := diskHarmonicWeight_sum N c (Real.exp (q+1)) (Real.exp_pos _).le hsmall
  have hh := probability_weights_normalized_abs (diskHarmonicWeight N c (Real.exp (q+1)))
    (fun x => finiteGaussianField N ξ x+(if σ then a else -a)) hw hs (2*g) (by have := coarseProbe_g_pos; positivity)
  have he : (∑ x, diskHarmonicWeight N c (Real.exp (q+1)) x*
      (finiteGaussianField N ξ x+(if σ then a else -a)))/Real.sqrt (2*g) =
        harmonicGaussianAverage N c q ξ+(if σ then a else -a)/Real.sqrt (2*g) := by
    simp only [mul_add,Finset.sum_add_distrib,← Finset.sum_mul,hs,one_mul,add_div]
    unfold harmonicGaussianAverage D.fieldProjection
    ring
  rw [he] at hh
  exact hh

theorem shifted_abs_amplitude_envelope (X a a₀ δ v d : ℝ) (hd : 0 < d) (hδ : 0 ≤ δ)
    (σ : Bool) (ha : |a-a₀| ≤ δ) (hx : |X+(if σ then a else -a)/d| ≤ v) :
    max (a₀/d-v-δ/d) 0 ≤ |X| := by
  have htri := abs_add_le (X+(if σ then a else -a)/d) (-X)
  have he : X+(if σ then a else -a)/d + -X = (if σ then a else -a)/d := by ring
  rw [he,abs_neg,abs_div,abs_of_pos hd] at htri
  have hs : |(if σ then a else -a)| = |a| := by cases σ <;> simp
  rw [hs] at htri
  have hbase : (a₀-δ)/d ≤ |a|/d :=
    div_le_div_of_nonneg_right ((by linarith [(abs_le.mp ha).1] : a₀-δ ≤ a).trans (le_abs_self a)) hd.le
  apply max_le _ (abs_nonneg X)
  rw [sub_div] at hbase
  linarith

def harmonicGaussianEnvelope (N : Size) (c : Vertex N) (q a₀ δ v : ℝ) (ξ : FiniteFieldSample N) : ℝ≥0∞ :=
  if max (a₀/Real.sqrt (2*g)-v-δ/Real.sqrt (2*g)) 0 ≤ |harmonicGaussianAverage N c q ξ| then 1 else 0

theorem harmonicGaussianAverage_measurable (N : Size) (c : Vertex N) (q : ℝ) :
    Measurable (harmonicGaussianAverage N c q) := by
  unfold harmonicGaussianAverage D.fieldProjection finiteGaussianField
  fun_prop

theorem harmonicGaussianEnvelope_measurable (N : Size) (c : Vertex N) (q a₀ δ v : ℝ) :
    Measurable (harmonicGaussianEnvelope N c q a₀ δ v) :=
  measurable_const.ite (measurableSet_le measurable_const (harmonicGaussianAverage_measurable N c q).abs) measurable_const

theorem harmonic_image_tail_envelope (N : Size) (c : Vertex N) (q a₀ δ v : ℝ)
    (hsmall : 2*(Real.exp (q+1)+1) < N.val) (hδ : 0 ≤ δ)
    (ξ : FiniteFieldSample N) (a : ℝ) (σ : Bool) (ha : |a-a₀| ≤ δ) :
    (if harmonicImageRadius N c q (harmonicShiftedSquareImage N ξ a σ) ≤ v then (1:ℝ≥0∞) else 0) ≤
      harmonicGaussianEnvelope N c q a₀ δ v ξ := by
  by_cases hv : harmonicImageRadius N c q (harmonicShiftedSquareImage N ξ a σ) ≤ v
  · have hx := (harmonic_shifted_image_average N c q hsmall ξ a σ).trans hv
    have he := shifted_abs_amplitude_envelope (harmonicGaussianAverage N c q ξ) a a₀ δ v _
      (by have := coarseProbe_g_pos; positivity) hδ σ ha hx
    simp only [if_pos hv,harmonicGaussianEnvelope,if_pos he,le_refl]
  · simp only [if_neg hv]
    exact bot_le

theorem harmonicGaussianEnvelope_lintegral_bound (N : Size) (c : Vertex N) (q a₀ δ v : ℝ)
    (hq : 0 ≤ q) (hqL : q ≤ logSize N) (hsmall : 2*(Real.exp (q+1)+1) < N.val) :
    (∫⁻ ξ, harmonicGaussianEnvelope N c q a₀ δ v ξ ∂finiteFieldLaw N) ≤
      ENNReal.ofReal (2*Real.exp (-(max (a₀/Real.sqrt (2*g)-v-δ/Real.sqrt (2*g)) 0)^2/
        (logSize N-q+2*harmonicVarianceErrorConstant))) := by
  let a := max (a₀/Real.sqrt (2*g)-v-δ/Real.sqrt (2*g)) 0
  let E := {ξ | a ≤ |harmonicGaussianAverage N c q ξ|}
  have hE : MeasurableSet E := measurableSet_le measurable_const (harmonicGaussianAverage_measurable N c q).abs
  have he : harmonicGaussianEnvelope N c q a₀ δ v = E.indicator (fun _ => (1:ℝ≥0∞)) := by
    funext ξ
    simp [harmonicGaussianEnvelope,E,a,Set.indicator]
  rw [he,lintegral_indicator hE,lintegral_one,Measure.restrict_apply_univ]
  exact (ENNReal.le_ofReal_iff_toReal_le (measure_ne_top _ _) (by positivity)).mpr
    (harmonicGaussianAverage_abs_tail N c q a hq hqL (le_max_right _ _) hsmall)

end TorusCoverTime.Blocks.B
