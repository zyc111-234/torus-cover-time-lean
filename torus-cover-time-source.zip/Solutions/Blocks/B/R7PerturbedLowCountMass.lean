import Solutions.CoverTime.Estimates.R7PerturbedOneSuccess
import Solutions.CoverTime.Estimates.R7TransferParameters

/-! R7.8 via a single successful replacement. The public low-count marginal
is unchanged; only one enlarged window and one duration error are needed. -/

noncomputable section
open MeasureTheory Filter Set Classical
open scoped ENNReal NNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B
open TorusCoverTime.CoverTime

set_option maxHeartbeats 800000 in
theorem r7_perturbed_low_count_mass (hWalk : WalkModelRegular) (γ H C₁ : ℝ)
    (hγ : 0 < γ) (hγ1 : 16*γ < 1) (hH : 0 ≤ H) (hC₁ : 0 < C₁) :
    ∃ c₀ C : ℝ, 0 < c₀ ∧ 0 < C ∧ ∀ᶠ N : Size in atTop,
      ∀ c : Vertex N, ∀ q v l r : ℝ,
        (logSize N)^(16*γ) ≤ q → q ≤ logSize N-(logSize N)^(16*γ) → q ≤ v → v ≤ C₁*logSize N →
        l ≤ r → phaseACenter N-H*timeScale N ≤ l → r ≤ phaseACenter N+H*timeScale N →
        normalizedPerturbedFarRootCountedMass N c γ q (r7PerturbedLowCountCutoff q γ v) l r ≤
          ENNReal.ofReal (C*Real.sqrt (logSize N)*Real.exp (-(max
            (harmonicExtremeCenter N-v-(logSize N)^(2*γ)-C*Real.log (logSize N)) 0)^2/(logSize N-q+C))) +
          ENNReal.ofReal (Real.exp (-c₀*logSize N*Real.log (logSize N))) := by
  obtain ⟨c₀,C,hc,hC,hlow⟩ := r7_low_harmonic_mass γ (H+1) hγ hγ1 (by linarith)
  have hlog := Real.tendsto_log_atTop.comp blockB_logSize_tendsto
  have herrabs := polynomial_logarithmic_exponential_absorption c₀ 5 0 hc 0
  refine ⟨c₀/2,2*C,by positivity,by positivity,?_⟩
  filter_upwards [hlow,r7_perturbed_normalized_counted_one_success hWalk γ hγ (by linarith),
    r7_perturbed_iteration_side_conditions γ C₁ hγ (by linarith) hC₁,r7_single_window_size γ hγ,
    r7_one_success_failure γ r7PerturbedConcentrationConstant hγ r7PerturbedConcentrationConstant_pos,
    r7_duration_remainder_bound γ c₀ (2*(H+1)) hγ (by positivity),
    blockB_logSize_tendsto.eventually herrabs,hlog.eventually_ge_atTop 0] with
      N hlo hrec hpar hsize hfail herror habs hlogN
  change 0 ≤ Real.log (logSize N) at hlogN
  intro c q v l r hq hqL hqv hvL hlr hleft hright
  have hqL' := hqL.trans (sub_le_self _ (Real.rpow_nonneg (logSize_pos N).le _))
  have hs := hpar q v hq hqL' hqv hvL
  let M := r7PerturbedLowCountCutoff q γ v
  let d := r7WindowStep N γ M
  let A := C*Real.sqrt (logSize N)*Real.exp (-(max
    (harmonicExtremeCenter N-v-(logSize N)^(2*γ)-C*Real.log (logSize N)) 0)^2/(logSize N-q+C))
  let E := Real.exp (-c₀*logSize N*Real.log (logSize N))
  have hA : 0 ≤ A := by dsimp [A]; positivity
  have hE : 0 ≤ E := (Real.exp_pos _).le
  have hd : 0 ≤ d := r7WindowStep_nonneg N γ M
  have hsize' := hsize M hs.2.2.1
  have hcentral : phaseACenter N-(H+1)*timeScale N ≤ l-d ∧
      r+d ≤ phaseACenter N+(H+1)*timeScale N := by
    change d ≤ timeScale N at hsize'
    constructor <;> linarith
  have hlowj := hlo c q v ((logSize N)^(2*γ)) (l-d) (r+d)
    hq hqL hqv hs.2.2.2.1 hcentral.1 hcentral.2
  have hlow' : normalizedFarRootLowHarmonicMass N c γ q (v+(logSize N)^(2*γ))
      (l-d) (r+d) ≤ ENNReal.ofReal (A+E) := by
    rw [ENNReal.ofReal_add hA hE]
    exact hlowj
  have hh := hrec c M q hq hqL hs.2.2.1 v ((logSize N)^(2*γ)) (by linarith [hs.1])
    hs.2.1 hs.2.2.2.1 hs.2.2.2.2.2.1 (hfail q hq hqL') l r
  have helen : r-l ≤ 2*(H+1)*timeScale N := by
    have := timeScale_pos N
    linarith
  have he := ENNReal.ofReal_le_ofReal (herror M hs.2.2.1 l r helen)
  have hb := hh.trans (add_le_add (mul_le_mul' (le_refl (2:ℝ≥0∞)) hlow') he)
  have hid : (2:ℝ≥0∞)*ENNReal.ofReal (A+E)+ENNReal.ofReal E = ENNReal.ofReal (2*A+3*E) := by
    rw [show (2:ℝ≥0∞) = ENNReal.ofReal (2:ℝ) by norm_num,
      ← ENNReal.ofReal_mul (by norm_num : (0:ℝ) ≤ 2),
      ← ENNReal.ofReal_add (by positivity) hE]
    congr 1
    ring
  rw [hid] at hb
  have ht := ENNReal.toReal_mono ENNReal.ofReal_ne_top hb
  rw [ENNReal.toReal_ofReal (by positivity : 0 ≤ 2*A+3*E)] at ht
  have hreal : (normalizedPerturbedFarRootCountedMass N c γ q M l r).toReal ≤ 2*A+5*E := by linarith
  have herr : 5*E ≤ Real.exp (-(c₀/2)*logSize N*Real.log (logSize N)) := by
    simpa only [E,pow_zero,mul_one,zero_mul,zero_sub,neg_mul] using habs
  have hmain : 2*A ≤ (2*C)*Real.sqrt (logSize N)*Real.exp (-(max
      (harmonicExtremeCenter N-v-(logSize N)^(2*γ)-(2*C)*Real.log (logSize N)) 0)^2/(logSize N-q+2*C)) := by
    have he := gaussian_tail_monotone
      (max (harmonicExtremeCenter N-v-(logSize N)^(2*γ)-(2*C)*Real.log (logSize N)) 0)
      (max (harmonicExtremeCenter N-v-(logSize N)^(2*γ)-C*Real.log (logSize N)) 0)
      (logSize N-q+C) (logSize N-q+2*C) (le_max_right _ _)
      (max_le_max (by nlinarith only [mul_nonneg hC.le hlogN]) le_rfl)
      (by linarith only [hqL',hC]) (by linarith only [hC])
    have hm := mul_le_mul_of_nonneg_left he (show 0 ≤ 2*C*Real.sqrt (logSize N) by positivity)
    exact (show 2*A = 2*C*Real.sqrt (logSize N)*Real.exp (-(max
      (harmonicExtremeCenter N-v-(logSize N)^(2*γ)-C*Real.log (logSize N)) 0)^2/(logSize N-q+C)) by
      dsimp [A]; ring).le.trans hm
  have hfinal := hreal.trans (add_le_add hmain herr)
  rw [← ENNReal.ofReal_add (by positivity) (by positivity)]
  exact (ENNReal.le_ofReal_iff_toReal_le (normalizedPerturbedFarRootCountedMass_ne_top N c γ q M l r) (by positivity)).mpr hfinal

end TorusCoverTime.Blocks.B

