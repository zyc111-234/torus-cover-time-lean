import Solutions.Blocks.B.PeriodicBindingEnvelope
import Solutions.Blocks.B.GaussianProbeMass
import Mathlib.Probability.IdentDistribIndep

noncomputable section
open MeasureTheory ProbabilityTheory Classical
open scoped BigOperators
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

def freshDirichletField (N : Size) (root : Vertex N) (D : Finset (Vertex N))
    (v : FiniteFieldSample N × FiniteFieldSample N) (x : Vertex N) : ℝ :=
  massZeroFieldLS N root D v.1 x+dirichletMassProfile N root D x*normalizedDirichletMass N root D v.2

theorem dirichletFieldLS_mass_reconstruct (N : Size) (root : Vertex N) (D : Finset (Vertex N))
    (hV : 0<dirichletMassVariance N root D) (ξ : FiniteFieldSample N) (x : Vertex N) :
    massZeroFieldLS N root D ξ x+dirichletMassProfile N root D x*normalizedDirichletMass N root D ξ=
      dirichletFieldLS N root D ξ x := by
  unfold massZeroFieldLS dirichletMassSlope dirichletMassProfile normalizedDirichletMass
  field_simp [hV.ne',(Real.sqrt_pos.mpr hV).ne']
  rw [Real.sq_sqrt hV.le]
  ring

theorem identDistrib_fst_self {Ω E : Type*} [MeasurableSpace Ω] [MeasurableSpace E]
    (μ : Measure Ω) [IsProbabilityMeasure μ] (f : Ω → E) (hf : Measurable f) :
    IdentDistrib (fun v : Ω × Ω => f v.1) f (μ.prod μ) μ := by
  refine ⟨(hf.comp measurable_fst).aemeasurable,hf.aemeasurable,?_⟩
  rw [show (fun v : Ω × Ω => f v.1)=f ∘ Prod.fst by rfl,← Measure.map_map hf measurable_fst,
    (measurePreserving_fst (μ := μ) (ν := μ)).map_eq]

theorem identDistrib_snd_self {Ω E : Type*} [MeasurableSpace Ω] [MeasurableSpace E]
    (μ : Measure Ω) [IsProbabilityMeasure μ] (f : Ω → E) (hf : Measurable f) :
    IdentDistrib (fun v : Ω × Ω => f v.2) f (μ.prod μ) μ := by
  refine ⟨(hf.comp measurable_snd).aemeasurable,hf.aemeasurable,?_⟩
  rw [show (fun v : Ω × Ω => f v.2)=f ∘ Prod.snd by rfl,← Measure.map_map hf measurable_snd,
    (measurePreserving_snd (μ := μ) (ν := μ)).map_eq]

/-- The added normal comes from a second independent sample. This theorem
asserts the full spatial law, not just its coordinate marginals. -/
theorem freshDirichletField_identDistrib (N : Size) (root : Vertex N) (D : Finset (Vertex N))
    (hroot : root∉D) (hV : 0<dirichletMassVariance N root D) :
    IdentDistrib (freshDirichletField N root D) (dirichletFieldLS N root D)
      ((finiteFieldLaw N).prod (finiteFieldLaw N)) (finiteFieldLaw N) := by
  have hX := massZeroFieldLS_measurable N root D
  have hZ : Measurable (normalizedDirichletMass N root D) := (dirichletMass_measurable N root D).div_const _
  have hi : IndepFun (massZeroFieldLS N root D) (normalizedDirichletMass N root D) (finiteFieldLaw N) :=
    (massZeroFieldLS_indep_mass N root D hroot hV).comp measurable_id (measurable_id.div_const _)
  have hh := (identDistrib_fst_self (finiteFieldLaw N) _ hX).prodMk
    (identDistrib_snd_self (finiteFieldLaw N) _ hZ) (indepFun_prod hX hZ) hi
  have he := hh.comp (show Measurable (fun v : (Vertex N → ℝ) × ℝ =>
    fun x => v.1 x+dirichletMassProfile N root D x*v.2) by fun_prop)
  have hr : (fun ξ => fun x => massZeroFieldLS N root D ξ x+
      dirichletMassProfile N root D x*normalizedDirichletMass N root D ξ)=dirichletFieldLS N root D :=
    funext (fun ξ => funext (fun x => dirichletFieldLS_mass_reconstruct N root D hV ξ x))
  unfold freshDirichletField
  simpa only [Function.comp_def,hr] using he

def bt7FreshSlabMass : ℝ := 2*Real.exp (-(1:ℝ)/2)/Real.sqrt (2*Real.pi)

theorem bt7FreshSlabMass_pos : 0<bt7FreshSlabMass := by unfold bt7FreshSlabMass; positivity

theorem normalizedDirichletMass_slab (N : Size) (root : Vertex N) (D : Finset (Vertex N))
    (hroot : root∉D) (hV : 0<dirichletMassVariance N root D) :
    bt7FreshSlabMass≤(finiteFieldLaw N).real {ξ | |normalizedDirichletMass N root D ξ|≤1} := by
  have hh := gaussian_variable_unit_slab_mass (finiteFieldLaw N) (normalizedDirichletMass N root D)
    ((dirichletMass_measurable N root D).div_const _) (periodicBindingData_gaussian N root D none)
    (periodicBindingData_mean N root D none) (le_of_eq (normalizedDirichletMass_variance N root D hroot hV).symm)
  simpa only [normalizedDirichletMass_variance N root D hroot hV,mul_one,bt7FreshSlabMass] using hh

theorem freshDirichletField_close (N : Size) (root c : Vertex N) (ρ : ℝ)
    (hR : 4*diskHarnackRadiusThreshold≤ρ*(N.val:ℝ)) (hsmall : 2*(ρ*(N.val:ℝ)+1)<N.val)
    (hroot : root∉torusDisk N c (ρ*(N.val:ℝ))) (v : FiniteFieldSample N × FiniteFieldSample N)
    (hz : |normalizedDirichletMass N root (torusDisk N c (ρ*(N.val:ℝ))) v.2|≤1)
    (x : Vertex N) (hx : periodicDistance x c≤(ρ*(N.val:ℝ)/4)/(4*diskGreenInnerScale)) :
    |periodicFieldLS N v.1 x-freshDirichletField N root (torusDisk N c (ρ*(N.val:ℝ))) v x|≤
      periodicBindingEnvelope N root c ρ v.1+dirichletMassProfileBound := by
  have hR4 : 4≤ρ*(N.val:ℝ) := by linarith [diskHarnackRadiusThreshold_ge_one]
  have hq := dirichletMassProfile_disk_bound N root c (ρ*(N.val:ℝ)) (by linarith) hsmall hroot x
  have hj := correctedBindingLS_le_envelope N root c ρ hR hsmall hroot v.1 x hx
  rw [periodicFieldLS_mass_corrected N root _ v.1 x]
  unfold freshDirichletField
  rw [show massZeroFieldLS N root _ v.1 x+correctedBindingLS N root _ v.1 x-
      (massZeroFieldLS N root _ v.1 x+dirichletMassProfile N root _ x*normalizedDirichletMass N root _ v.2)=
      correctedBindingLS N root _ v.1 x-dirichletMassProfile N root _ x*normalizedDirichletMass N root _ v.2 by ring]
  rw [sub_eq_add_neg]
  refine (abs_add_le _ _).trans (add_le_add hj ?_)
  rw [abs_neg,abs_mul,abs_of_nonneg hq.1]
  exact (mul_le_mul_of_nonneg_left hz hq.1).trans (by simpa only [mul_one] using hq.2)

end TorusCoverTime.Blocks.B
