import Solutions.Blocks.B.BT10CountWindow
import Solutions.Blocks.B.R8PairDurationBound

/-! Marginal mass and two-site softness combine before the spatial sum.
The iteration and duration errors retain their full multiplicities. -/
noncomputable section
open MeasureTheory Filter Set Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

theorem bt10_exponent_cancellation (γ K : ℝ) (hγ : 0<γ) (hK : 0≤K) :
    ∀ᶠ L : ℝ in atTop, ∀ q s : ℝ, 0≤q → q≤L → L^(8*γ)≤s →
      (-4*q-4*Real.sqrt 2*s+K*q^γ)+(-2*(L-q)+2*Real.sqrt 2*s+8*L^(2*γ)) ≤
        -2*L-2*q-L^(8*γ) := by
  filter_upwards [eventually_ge_atTop (0:ℝ),
    power_eventually_le_power 8 (2*γ) (8*γ) (1/2) (by linarith) (by norm_num),
    power_eventually_le_power K γ (8*γ) (1/2) (by linarith) (by norm_num)] with L hL h₁ h₂
  intro q s hq hqL hs
  have hkq := mul_le_mul_of_nonneg_left (Real.rpow_le_rpow hq hqL hγ.le) hK
  have hs0 := (Real.rpow_nonneg hL (8*γ)).trans hs
  have hroot : 1≤Real.sqrt 2 := by nlinarith [Real.sq_sqrt (by norm_num : (0:ℝ)≤2),Real.sqrt_nonneg 2]
  nlinarith [mul_nonneg (sub_nonneg.mpr hroot) hs0]

set_option maxHeartbeats 800000 in
theorem bt10_scalar_product (γ K C : ℝ) (hγ : 0<γ) (hK : 0≤K) (hC : 0≤C) :
    ∀ᶠ L : ℝ in atTop, ∀ q : ℝ, ∀ m : ℕ, 0≤q → q≤L →
      L^(8*γ)≤Real.sqrt (q^γ*(m:ℝ))-Real.sqrt 2*q →
      bt10PairFactor γ K q m*ENNReal.ofReal (C*Real.sqrt L*Real.exp
        (-2*(L-q)+2*Real.sqrt 2*(Real.sqrt (q^γ*(m:ℝ))-Real.sqrt 2*q)+8*L^(2*γ))) ≤
      ENNReal.ofReal (2*C*Real.sqrt L*Real.exp (-2*L-2*q-L^(8*γ))) := by
  filter_upwards [bt10_exponent_cancellation γ K hγ hK] with L hL
  intro q m hq hqL hs
  apply (mul_le_mul' (bt10PairFactor_le_exp γ K q m) le_rfl).trans
  rw [show (2:ℝ≥0∞)=ENNReal.ofReal 2 by norm_num,
    ← ENNReal.ofReal_mul (by norm_num : (0:ℝ)≤2),
    ← ENNReal.ofReal_mul (by unfold bt10PairEnvelope; positivity)]
  apply ENNReal.ofReal_le_ofReal
  have he := Real.exp_le_exp.mpr (hL q _ hq hqL hs)
  have hp := mul_le_mul_of_nonneg_left he (show 0≤2*C*Real.sqrt L by positivity)
  rw [Real.exp_add] at hp
  calc
    _ = (2*C*Real.sqrt L)*(Real.exp (-4*q-4*Real.sqrt 2*(Real.sqrt (q^γ*(m:ℝ))-Real.sqrt 2*q)+K*q^γ)*
        Real.exp (-2*(L-q)+2*Real.sqrt 2*(Real.sqrt (q^γ*(m:ℝ))-Real.sqrt 2*q)+8*L^(2*γ))) := by
      unfold bt10PairEnvelope
      ring
    _ ≤ _ := hp

def bt10SliceEvent (N : Size) (x y root : Vertex N) (γ q U : ℝ) (m : ℕ) : Set (WalkSample × ℝ) :=
  {z | x≠y ∧ q-2≤Real.log (periodicDistance x y) ∧ Real.log (periodicDistance x y)<q ∧
    (logSize N)^(8*γ)≤Real.sqrt (q^γ*(m:ℝ))-Real.sqrt 2*q ∧
    Real.sqrt (q^γ*(m:ℝ))≤10*logSize N ∧ z∈bt10PairEvent N x y root γ q U m}

theorem bt10SliceEvent_measurable (N : Size) (x y root : Vertex N) (γ q U : ℝ) (m : ℕ) :
    MeasurableSet (bt10SliceEvent N x y root γ q U m) := by
  exact (MeasurableSet.const _).inter ((MeasurableSet.const _).inter ((MeasurableSet.const _).inter
    ((MeasurableSet.const _).inter ((MeasurableSet.const _).inter (bt10PairEvent_measurable N x y root γ q U m)))))

def bt10SliceMass (N : Size) (x y : Vertex N) (γ q U : ℝ) (m : ℕ) (l r : ℝ) : ℝ≥0∞ :=
  r7LoopEventMass N (fun root => bt10SliceEvent N x y root γ q U m) l r

def bt10SliceEnvelope (L γ H a C q : ℝ) : ℝ :=
  2*C*Real.sqrt L*Real.exp (-2*L-2*q-L^(8*γ))+
    2*Real.exp (-a*L*Real.log L)+
    6*(H+1)*Real.exp (2*L)*Real.exp (-Real.exp (L^(16*γ)/2))

theorem bt10_slice_bound (hWalk : WalkModelRegular) (γ U H : ℝ)
    (hγ : 0<γ) (hγ1 : 16*γ<1) (hU : 0≤U) (hH : 0≤H) :
    ∃ a C : ℝ, 0<a ∧ 0<C ∧ ∀ᶠ N : Size in atTop, ∀ x y : Vertex N,
      ∀ m∈r8ModerateCounts (logSize N), ∀ q l r : ℝ,
      (logSize N)^(16*γ)≤q → q≤logSize N-(logSize N)^(16*γ) →
      l≤r → phaseACenter N-H*timeScale N≤l → r≤phaseACenter N+H*timeScale N →
      bt10SliceMass N x y γ q U m l r≤ENNReal.ofReal (bt10SliceEnvelope (logSize N) γ H a C q) := by
  obtain ⟨K,hK,hpair⟩ := bt10_pair_count_window hWalk γ U hγ (by linarith) hU
  obtain ⟨a,C,ha,hC,hmargin⟩ := r8_exact_count_marginal hWalk γ (H+1) hγ hγ1 (by linarith)
  refine ⟨a,C,ha,hC,?_⟩
  filter_upwards [hpair,hmargin,r8_two_window_steps_small γ hγ,
    blockB_logSize_tendsto.eventually (bt10_scalar_product γ K C hγ hK.le hC.le),
    blockB_logSize_tendsto.eventually_ge_atTop 20] with N hpair hmarg hwin hscalar hL
  intro x y m hm q l r hq hqL hlr hlo hhi
  by_cases hc : x≠y ∧ q-2≤Real.log (periodicDistance x y) ∧ Real.log (periodicDistance x y)<q ∧
      (logSize N)^(8*γ)≤Real.sqrt (q^γ*(m:ℝ))-Real.sqrt 2*q ∧ Real.sqrt (q^γ*(m:ℝ))≤10*logSize N
  · have hQ := Real.rpow_pos_of_pos (logSize_pos N) (16*γ)
    have hq0 : 0≤q := hQ.le.trans hq
    have hqL' : q≤logSize N := by linarith
    have h0 : 0∈r8ModerateCounts (logSize N) := by simp [r8ModerateCounts]
    have hmcut := r8_count_pair_total_cutoff (logSize N) hL m 0 hm h0
    simp only [Nat.add_zero] at hmcut
    have hstep := hwin (m,0) (Finset.mem_product.mpr ⟨hm,h0⟩)
    simp only [r7WindowStep,Nat.cast_zero,zero_mul,add_zero] at hstep
    change r7WindowStep N γ m≤timeScale N at hstep
    have hd := r7WindowStep_nonneg N γ m
    have hs := hc.2.2.2.1
    have hv : q≤Real.sqrt (q^γ*(m:ℝ)) := by
      have hroot : 1≤Real.sqrt 2 := by nlinarith [Real.sq_sqrt (by norm_num : (0:ℝ)≤2),Real.sqrt_nonneg 2]
      nlinarith [Real.rpow_nonneg (logSize_pos N).le (8*γ),mul_nonneg (sub_nonneg.mpr hroot) hq0]
    have hb := hpair x y m q hq hqL hmcut hc.1 hc.2.1 hc.2.2.1 l r
    have hmar := hmarg x q m (l-r7WindowStep N γ m) (r+r7WindowStep N γ m) hq hqL hv hc.2.2.2.2
      (by linarith) (by nlinarith) (by nlinarith)
    have herr := r8_pair_duration_bound N γ q U H l r 0 0 hH
      (by simpa [r8PairWindowShift] using (timeScale_pos N).le) (by nlinarith)
    have herr' : (ENNReal.ofReal (timeScale N))⁻¹*(Fintype.card (Vertex N):ℝ≥0∞)*
        (ENNReal.ofReal (r-l)*ENNReal.ofReal (Real.exp (-Real.exp ((logSize N)^(16*γ)/2)))) ≤
        ENNReal.ofReal (6*(H+1)*Real.exp (2*logSize N)*Real.exp (-Real.exp ((logSize N)^(16*γ)/2))) := by
      apply le_trans _ herr
      exact mul_le_mul' le_rfl (le_add_left le_rfl)
    have hsub : bt10SliceMass N x y γ q U m l r≤bt10PairMass N x y γ q U m l r :=
      r7LoopEventMass_mono_ae N _ _ (fun _ => Eventually.of_forall (fun _ _ _ hz => hz.2.2.2.2.2)) l r
    apply hsub.trans (hb.trans ((add_le_add (mul_le_mul' le_rfl hmar) herr').trans ?_))
    rw [mul_add]
    have hbmain := hscalar q m hq0 hqL' hs
    have hberr := mul_le_mul' (bt10PairFactor_le_two γ K q m)
      (le_refl (ENNReal.ofReal (Real.exp (-a*logSize N*Real.log (logSize N)))))
    apply (add_le_add (add_le_add hbmain hberr) le_rfl).trans_eq
    rw [show (2:ℝ≥0∞)=ENNReal.ofReal 2 by norm_num,← ENNReal.ofReal_mul (by norm_num : (0:ℝ)≤2),
      ← ENNReal.ofReal_add (by positivity) (by positivity),← ENNReal.ofReal_add (by positivity) (by positivity)]
    rfl
  · have he : ∀ root, bt10SliceEvent N x y root γ q U m=∅ := by
      intro root; ext z; simp only [bt10SliceEvent,mem_setOf_eq,mem_empty_iff_false]
      tauto
    simp only [bt10SliceMass,r7LoopEventMass,he,r7LoopEventTest,mem_empty_iff_false,false_and,
      if_false,lintegral_zero,Finset.sum_const_zero,mul_zero,zero_le]

end TorusCoverTime.Blocks.B
