import Solutions.Blocks.B.BT7EventMeasurable

noncomputable section
open MeasureTheory ProbabilityTheory Classical Set
open scoped BigOperators
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

theorem periodicFieldLS_gaussian_whole (N : Size) : HasGaussianLaw (periodicFieldLS N) (finiteFieldLaw N) := by
  let A := ContinuousLinearMap.pi (fun x => periodicLSCoordinateMap N x)
  apply ((Blocks.D.finiteFieldSample_gaussian N).map_fun A).congr
  exact Filter.Eventually.of_forall (fun ξ => by funext x; simp [A,periodicLSCoordinateMap_apply])

theorem periodicFieldLS_neg_identDistrib (N : Size) :
    IdentDistrib (fun ξ => fun z => -periodicFieldLS N ξ z) (periodicFieldLS N) (finiteFieldLaw N) (finiteFieldLaw N) := by
  have hg := periodicFieldLS_gaussian_whole N
  have hn : HasGaussianLaw (fun ξ => fun z => -periodicFieldLS N ξ z) (finiteFieldLaw N) := hg.fun_neg
  have hm : (∫ ξ, periodicFieldLS N ξ ∂finiteFieldLaw N)=0 := by
    funext x
    have hh := (ContinuousLinearMap.proj x : (Vertex N → ℝ) →L[ℝ] ℝ).integral_comp_comm hg.integrable
    change (∫ ξ, periodicFieldLS N ξ ∂finiteFieldLaw N) x=0
    exact hh.symm.trans (periodicFieldLS_mean N x)
  refine ⟨hn.aemeasurable,hg.aemeasurable,?_⟩
  apply Measure.ext_of_charFunDual
  funext L
  rw [hn.charFunDual_map_eq_fun,hg.charFunDual_map_eq_fun]
  have hL : (∫ ξ, L (periodicFieldLS N ξ) ∂finiteFieldLaw N)=0 := by
    rw [L.integral_comp_comm hg.integrable,hm,map_zero]
  change Complex.exp (((∫ ξ, L (-periodicFieldLS N ξ) ∂finiteFieldLaw N):ℝ)*Complex.I-
    Var[fun ξ => L (-periodicFieldLS N ξ);finiteFieldLaw N]/2)=_
  simp only [map_neg,integral_neg,hL,neg_zero,variance_fun_neg]

theorem bt7BadCount_expectation_le (N : Size) (γ ε C₀ C₁ Q : ℝ)
    (hq : ∀ x : Vertex N, (finiteFieldLaw N).real {ξ | bt7BadPoint N γ ε C₀ C₁ (periodicFieldLS N ξ) x}≤Q) :
    (∫ ξ, bt7BadCount N γ ε C₀ C₁ ξ ∂finiteFieldLaw N)≤2*vertexCount N*Q := by
  let A := fun x : Vertex N => {ξ | bt7BadPoint N γ ε C₀ C₁ (periodicFieldLS N ξ) x}
  let B := fun x : Vertex N => {ξ | bt7BadPoint N γ ε C₀ C₁ (fun z => -periodicFieldLS N ξ z) x}
  have hA (x : Vertex N) : MeasurableSet (A x) := (bt7BadPoint_measurableSet N γ ε C₀ C₁ x).preimage (periodicFieldLS_measurable N)
  have hB (x : Vertex N) : MeasurableSet (B x) := (bt7BadPoint_measurableSet N γ ε C₀ C₁ x).preimage
    (show Measurable (fun ξ : FiniteFieldSample N => fun z => -periodicFieldLS N ξ z) by fun_prop)
  have hsym (x : Vertex N) : (finiteFieldLaw N).real (B x)=(finiteFieldLaw N).real (A x) :=
    congrArg ENNReal.toReal ((periodicFieldLS_neg_identDistrib N).measure_mem_eq (bt7BadPoint_measurableSet N γ ε C₀ C₁ x))
  have he : bt7BadCount N γ ε C₀ C₁=fun ξ => ∑ x, (A x∪B x).indicator (fun _ => (1:ℝ)) ξ := by
    funext ξ
    apply Finset.sum_congr rfl
    intro x _
    simp only [A,B,Set.indicator,mem_union,mem_setOf_eq]
  rw [he,integral_finsetSum _ (fun x _ => (integrable_const (1:ℝ)).indicator ((hA x).union (hB x)))]
  calc
    _ = ∑ x, (finiteFieldLaw N).real (A x∪B x) := by
      apply Finset.sum_congr rfl
      intro x _
      simpa only [Pi.one_def] using integral_indicator_one (μ := finiteFieldLaw N) ((hA x).union (hB x))
    _ ≤ ∑ _ : Vertex N, (2*Q) := by
      apply Finset.sum_le_sum
      intro x _
      have hh := measureReal_union_le (μ := finiteFieldLaw N) (A x) (B x)
      rw [hsym x] at hh
      exact hh.trans (by linarith [hq x])
    _ = _ := by rw [sum_const_vertex]; ring

end TorusCoverTime.Blocks.B
