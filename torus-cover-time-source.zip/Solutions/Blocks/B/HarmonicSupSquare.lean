import Solutions.Blocks.B.DiskHarnack
import Solutions.Blocks.B.WeightedGaussianResidualTail
import Solutions.Blocks.B.DirichletWeightedResidual

/-! Harnack and a weighted square bound give a dimension-free Gaussian
supremum tail on a deep inner disk. No metric entropy construction is needed. -/
noncomputable section
open MeasureTheory ProbabilityTheory Classical
open scoped BigOperators
namespace TorusCoverTime.Blocks.B

theorem weighted_abs_square_le {I : Type*} [Fintype I] (w f : I → ℝ)
    (hw : ∀ i, 0≤w i) (hs : ∑ i, w i=1) :
    (∑ i, w i*|f i|)^2≤∑ i, w i*(f i)^2 := by
  have hh := weighted_square_residual w (fun i => |f i|) hs 0
  simp only [sub_zero,sq_abs] at hh
  have hn : 0≤∑ i, w i*(|f i|-∑ j, w j*|f j|)^2 :=
    Finset.sum_nonneg (fun i _ => mul_nonneg (hw i) (sq_nonneg _))
  linarith

theorem harmonic_inner_abs_le (N : Size) (c : Vertex N) (R : ℝ)
    (hR : diskHarnackRadiusThreshold≤R) (hsmall : 4*(R+1)<N.val)
    (f : Vertex N → ℝ) (hg : ∀ z∈torusDisk N c R, generator N f z=0)
    (x : Vertex N) (hx : periodicDistance x c≤R/(4*diskGreenInnerScale)) :
    |f x|≤diskHarnackConstant*∑ z, exitHarmonic N (torusDisk N c R) z c*|f z| := by
  have hR0 : 0≤R := le_trans (by norm_num) (diskHarnackRadiusThreshold_ge_one.trans hR)
  have he := congrFun (harmonic_exit_representation N _ (torusDisk_proper N c R hR0 (by linarith)) f hg) x
  rw [he]
  calc
    _ ≤ ∑ z, |f z*exitHarmonic N (torusDisk N c R) z x| := Finset.abs_sum_le_sum_abs _ _
    _ = ∑ z, exitHarmonic N (torusDisk N c R) z x*|f z| := by
      apply Finset.sum_congr rfl
      intro z _
      rw [abs_mul,abs_of_nonneg (exitHarmonic_nonneg N _ z x)]
      ring
    _ ≤ ∑ z, (diskHarnackConstant*exitHarmonic N (torusDisk N c R) z c)*|f z| := by
      apply Finset.sum_le_sum
      intro z _
      apply mul_le_mul_of_nonneg_right _ (abs_nonneg _)
      exact disk_exit_harnack N c R hR hsmall z c x
        (by rw [periodicDistance_self_zero]; positivity [diskGreenInnerScale_ge_four]) hx
    _ = _ := by rw [Finset.mul_sum]; apply Finset.sum_congr rfl; intro z _; ring

theorem harmonic_inner_square_le (N : Size) (c : Vertex N) (R : ℝ)
    (hR : diskHarnackRadiusThreshold≤R) (hsmall : 4*(R+1)<N.val)
    (f : Vertex N → ℝ) (hg : ∀ z∈torusDisk N c R, generator N f z=0)
    (x : Vertex N) (hx : periodicDistance x c≤R/(4*diskGreenInnerScale)) :
    (f x)^2≤diskHarnackConstant^2*∑ z, exitHarmonic N (torusDisk N c R) z c*(f z)^2 := by
  have hh := harmonic_inner_abs_le N c R hR hsmall f hg x hx
  have hw := weighted_abs_square_le (fun z => exitHarmonic N (torusDisk N c R) z c) f
    (fun z => exitHarmonic_nonneg N _ z c)
    (exitHarmonic_sum_one N _ (torusDisk_proper N c R (by linarith [diskHarnackRadiusThreshold_ge_one]) (by linarith)) c)
  have hs := mul_le_mul_of_nonneg_left hw (sq_nonneg diskHarnackConstant)
  have hab : 0≤diskHarnackConstant*∑ z, exitHarmonic N (torusDisk N c R) z c*|f z| := by
    apply mul_nonneg (by linarith [diskHarnackConstant_gt_one])
    exact Finset.sum_nonneg (fun z _ => mul_nonneg (exitHarmonic_nonneg N _ z c) (abs_nonneg _))
  calc
    _ ≤ (diskHarnackConstant*∑ z, exitHarmonic N (torusDisk N c R) z c*|f z|)^2 := by
      simpa only [sq_abs] using (sq_le_sq₀ (abs_nonneg (f x)) hab).mpr hh
    _ = _ := mul_pow _ _ 2
    _ ≤ _ := hs

theorem harmonic_gaussian_inner_tail {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
    (N : Size) (c : Vertex N) (R : ℝ) (hR : diskHarnackRadiusThreshold≤R) (hsmall : 4*(R+1)<N.val)
    (H : Ω → Vertex N → ℝ) (hH : ∀ z, Measurable (fun ω => H ω z))
    (hG : ∀ z, HasGaussianLaw (fun ω => H ω z) μ) (hmean : ∀ z, (∫ ω, H ω z ∂μ)=0)
    (hharm : ∀ ω z, z∈torusDisk N c R → generator N (H ω) z=0)
    (V t : ℝ) (hV : 0<V) (ht : 0≤t)
    (hvar : ∀ z, exitHarmonic N (torusDisk N c R) z c≠0 → Var[fun ω => H ω z;μ]≤V) :
    μ.real {ω | ∃ x : Vertex N, periodicDistance x c≤R/(4*diskGreenInnerScale) ∧ t≤|H ω x|}≤
      2*Real.exp (-t^2/(8*V*diskHarnackConstant^2)) := by
  have hh := weighted_gaussian_residual_tail (fun z => exitHarmonic N (torusDisk N c R) z c)
    (fun _ => 0) (fun z ω => H ω z) (fun z => exitHarmonic_nonneg N _ z c)
    (exitHarmonic_sum_one N _ (torusDisk_proper N c R (by linarith [diskHarnackRadiusThreshold_ge_one]) (by linarith)) c)
    hH hG hmean V 0 (t^2/(8*V*diskHarnackConstant^2)) hV hvar (by simp)
  have hC : 0<diskHarnackConstant := by linarith [diskHarnackConstant_gt_one]
  have hs : {ω | ∃ x : Vertex N, periodicDistance x c≤R/(4*diskGreenInnerScale) ∧ t≤|H ω x|} ⊆
      {ω | 8*V*(t^2/(8*V*diskHarnackConstant^2))≤
        weightedShiftedSquares (fun z => exitHarmonic N (torusDisk N c R) z c) (fun _ => 0) (fun z ω => H ω z) ω} := by
    rintro ω ⟨x,hx,hxt⟩
    have hx2 := harmonic_inner_square_le N c R hR hsmall (H ω) (hharm ω) x hx
    have he : 8*V*(t^2/(8*V*diskHarnackConstant^2))=t^2/diskHarnackConstant^2 := by field_simp
    simp only [Set.mem_ofPred_eq,he,weightedShiftedSquares,add_zero]
    apply (div_le_iff₀ (by positivity)).mpr
    nlinarith [sq_abs (H ω x)]
  simpa only [zero_pow (by norm_num : (2:ℕ)≠0),zero_div,zero_sub,neg_div] using
    (measureReal_mono (μ := μ) hs).trans hh

end TorusCoverTime.Blocks.B
