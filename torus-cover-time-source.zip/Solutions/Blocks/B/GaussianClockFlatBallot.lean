import Solutions.Blocks.B.GaussianClockDecoupling

/-! A full three-halves endpoint estimate for finite discrete killing, uniform
over bounded variance tables. It follows from two survival factors and the
independent middle density, rather than a continuously killed heat kernel. -/

noncomputable section
open MeasureTheory ProbabilityTheory Set
open scoped ENNReal NNReal
namespace TorusCoverTime.Blocks.B.GaussianClockPath
variable {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
variable {n : ℕ} (W : GaussianClockPath μ n)

theorem flat_ballot_cuts {U : ℝ} (h : W.ClockBounds U)
    (lo hi : Fin (n + 1)) (hlo : 0 < lo.val) (hlohi : lo < hi) (hhi : 0 < hi.rev.val)
    (H a b : ℝ) (hH : 0 ≤ H) (haH : a ≤ H) (hab : a ≤ b) :
    μ {ω | W.path ω (Fin.last n) ∈ Icc a b ∧ ∀ i, W.path ω i ≤ H} ≤
      ENNReal.ofReal (((b-a) / Real.sqrt (2*Real.pi*((hi.val : ℝ)-lo.val))) *
        (8*(H+2*Real.sqrt U+1) / Real.sqrt (lo.val : ℝ)) *
        (8*(H-a+2*Real.sqrt U+1) / Real.sqrt (hi.rev.val : ℝ))) := by
  have hδ : 0 < (hi.val : ℝ)-lo.val := sub_pos.mpr (by exact_mod_cast hlohi)
  have hd := W.barrier_interval_decoupling lo hi hlohi.le _ hδ (h.lower lo hi hlohi.le) H a b hab
  have hl := W.bounded_survival_le h H hH lo hlo
  have hr := W.reverse.bounded_survival_le h.reverse (H-a) (sub_nonneg.mpr haH) hi.rev hhi
  refine hd.trans ((mul_le_mul' (mul_le_mul' le_rfl hl) hr).trans_eq ?_)
  have hc : 0 ≤ (b-a) / Real.sqrt (2*Real.pi*((hi.val : ℝ)-lo.val)) := by positivity
  have hl0 : 0 ≤ 8*(H+2*Real.sqrt U+1) / Real.sqrt (lo.val : ℝ) := by positivity
  rw [ENNReal.ofReal_mul (mul_nonneg hc hl0), ENNReal.ofReal_mul hc]

theorem flat_ballot_thirds {U : ℝ} (h : W.ClockBounds U) (hn : 3 ≤ n)
    (H a b : ℝ) (hH : 0 ≤ H) (haH : a ≤ H) (hab : a ≤ b) :
    μ {ω | W.path ω (Fin.last n) ∈ Icc a b ∧ ∀ i, W.path ω i ≤ H} ≤
      ENNReal.ofReal (1024*(b-a)*(H+2*Real.sqrt U+1)*(H-a+2*Real.sqrt U+1) /
        ((n : ℝ)*Real.sqrt n)) := by
  let l := n/3
  let lo : Fin (n+1) := ⟨l, by dsimp [l]; omega⟩
  let hi : Fin (n+1) := ⟨n-l, by omega⟩
  have hl : 0 < l := by dsimp [l]; omega
  have h3 : 3*l ≤ n := by dsimp [l]; omega
  have h5 : n ≤ 5*l := by dsimp [l]; omega
  have hrev : hi.rev.val = l := by simp only [Fin.val_rev, Nat.succ_sub_succ_eq_sub, hi]; omega
  have hcuts : lo < hi := by change l < n-l; omega
  have hd := W.flat_ballot_cuts h lo hi hl hcuts (by rw [hrev]; exact hl) H a b hH haH hab
  rw [hrev] at hd
  have hlr : (0 : ℝ) < l := by exact_mod_cast hl
  have hnr : (0 : ℝ) < n := by exact_mod_cast (show 0<n by omega)
  have h3r : 3*(l : ℝ) ≤ n := by exact_mod_cast h3
  have h5r : (n : ℝ) ≤ 5*l := by exact_mod_cast h5
  have hgap : (l : ℝ) ≤ (hi.val : ℝ)-lo.val := by
    dsimp [hi, lo]
    rw [Nat.cast_sub (by omega : l ≤ n)]
    linarith
  have hden : Real.sqrt (l : ℝ) ≤ Real.sqrt (2*Real.pi*((hi.val : ℝ)-lo.val)) := by
    apply Real.sqrt_le_sqrt
    have := Real.pi_gt_three
    nlinarith
  have hsl : 0 < Real.sqrt (l : ℝ) := Real.sqrt_pos.mpr hlr
  have hsn : 0 < Real.sqrt (n : ℝ) := Real.sqrt_pos.mpr hnr
  have hscompare : Real.sqrt (n : ℝ) ≤ 3*Real.sqrt (l : ℝ) := by
    nlinarith [Real.sq_sqrt hlr.le, Real.sq_sqrt hnr.le]
  have hdcompare : (n : ℝ)*Real.sqrt n ≤ 16*((l : ℝ)*Real.sqrt l) := by
    have hh := mul_le_mul h5r hscompare hsn.le (by positivity : 0 ≤ 5*(l : ℝ))
    nlinarith
  have hx : 0 ≤ (b-a)*(H+2*Real.sqrt U+1)*(H-a+2*Real.sqrt U+1) := by positivity
  refine hd.trans (ENNReal.ofReal_le_ofReal ?_)
  calc
    _ ≤ ((b-a) / Real.sqrt (l : ℝ)) * (8*(H+2*Real.sqrt U+1)/Real.sqrt (l : ℝ)) *
        (8*(H-a+2*Real.sqrt U+1)/Real.sqrt (l : ℝ)) := by
      change _ ≤ ((b-a) / Real.sqrt (lo.val : ℝ)) * _ * _
      gcongr
    _ = 64*((b-a)*(H+2*Real.sqrt U+1)*(H-a+2*Real.sqrt U+1)) / ((l : ℝ)*Real.sqrt l) := by
      have hs2 := Real.sq_sqrt hlr.le
      field_simp
      rw [hs2]
      ring
    _ ≤ _ := by
      apply (div_le_div_iff₀ (mul_pos hlr hsl) (mul_pos hnr hsn)).mpr
      nlinarith [mul_nonneg hx (sub_nonneg.mpr hdcompare)]

end TorusCoverTime.Blocks.B.GaussianClockPath
