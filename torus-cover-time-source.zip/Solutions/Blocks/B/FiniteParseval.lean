import Solutions.Blocks.B.EnergyAlgebra

/-! Real finite Fourier reconstruction and Parseval, with unnormalized coefficients. -/

noncomputable section
open scoped BigOperators
namespace TorusCoverTime.Blocks.B

lemma finiteCharacter_neg (N : Size) (k x : Vertex N) :
    finiteCharacter N k (-x) = star (finiteCharacter N k x) := by
  simp only [finiteCharacter, Prod.fst_neg, Prod.snd_neg, mul_neg, ← neg_add,
    coordinateCharacter_neg, Complex.inv_eq_conj (coordinateCharacter_norm N _)]
  rfl

lemma finiteCosine_sub (N : Size) (k x y : Vertex N) :
    finiteCosine N k (x - y) =
      finiteCosine N k x * finiteCosine N k y + finiteSine N k x * finiteSine N k y := by
  rw [← finiteCharacter_re, sub_eq_add_neg, finiteCharacter_add, finiteCharacter_neg]
  simp only [Complex.mul_re, Complex.star_def, Complex.conj_re, Complex.conj_im,
    finiteCharacter_re, finiteCharacter_im]
  ring

def cosineCoefficient (N : Size) (f : Vertex N → ℝ) (k : Vertex N) : ℝ :=
  ∑ x : Vertex N, f x * finiteCosine N k x

def sineCoefficient (N : Size) (f : Vertex N → ℝ) (k : Vertex N) : ℝ :=
  ∑ x : Vertex N, f x * finiteSine N k x

def fourierComponent (N : Size) (f : Vertex N → ℝ) (k x : Vertex N) : ℝ :=
  cosineCoefficient N f k * finiteCosine N k x + sineCoefficient N f k * finiteSine N k x

lemma fourierComponent_convolution (N : Size) (f : Vertex N → ℝ) (k x : Vertex N) :
    fourierComponent N f k x = ∑ y : Vertex N, f y * finiteCosine N k (x - y) := by
  simp only [fourierComponent, cosineCoefficient, sineCoefficient, finiteCosine_sub,
    mul_add, Finset.sum_add_distrib, Finset.sum_mul]
  congr 1 <;> apply Finset.sum_congr rfl <;> intro y _ <;> ring

lemma fourier_inversion (N : Size) (f : Vertex N → ℝ) (x : Vertex N) :
    (∑ k ∈ nonzeroFrequencies N, fourierComponent N f k x) =
      vertexCount N * f x - ∑ y : Vertex N, f y := by
  classical
  simp_rw [fourierComponent_convolution]
  rw [Finset.sum_comm]
  have hsum (y : Vertex N) : (∑ k ∈ nonzeroFrequencies N, finiteCosine N k (x - y)) =
      (if x = y then vertexCount N else 0) - 1 := by
    have h := finite_fourier_initial_condition N x y
    linarith
  simp_rw [← Finset.mul_sum, hsum, mul_sub, mul_one]
  rw [Finset.sum_sub_distrib]
  congr 1
  simp only [mul_ite, mul_zero]
  simp [mul_comm]

lemma fourierComponent_pair (N : Size) (f : Vertex N → ℝ) (k : Vertex N) :
    (∑ x : Vertex N, f x * fourierComponent N f k x) =
      cosineCoefficient N f k ^ 2 + sineCoefficient N f k ^ 2 := by
  simp only [fourierComponent, mul_add, Finset.sum_add_distrib]
  have hc : (∑ x : Vertex N, f x * (cosineCoefficient N f k * finiteCosine N k x)) =
      cosineCoefficient N f k * cosineCoefficient N f k := by
    rw [cosineCoefficient, Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro x _
    ring
  have hs : (∑ x : Vertex N, f x * (sineCoefficient N f k * finiteSine N k x)) =
      sineCoefficient N f k * sineCoefficient N f k := by
    rw [sineCoefficient, Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro x _
    ring
  rw [hc, hs, ← sq, ← sq]

lemma finite_parseval (N : Size) (f : Vertex N → ℝ) :
    (∑ k ∈ nonzeroFrequencies N, (cosineCoefficient N f k ^ 2 + sineCoefficient N f k ^ 2)) =
      vertexCount N * (∑ x : Vertex N, f x ^ 2) - (∑ x : Vertex N, f x) ^ 2 := by
  simp_rw [← fourierComponent_pair]
  rw [Finset.sum_comm]
  simp_rw [← Finset.mul_sum, fourier_inversion, mul_sub]
  rw [Finset.sum_sub_distrib, ← Finset.sum_mul]
  have hsum : (∑ x : Vertex N, f x * (vertexCount N * f x)) =
      vertexCount N * ∑ x : Vertex N, f x ^ 2 := by
    rw [Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro x _
    ring
  rw [hsum, ← sq]

lemma fourierComponent_generator (N : Size) (f : Vertex N → ℝ) (k x : Vertex N) :
    -generator N (fourierComponent N f k) x =
      finiteEigenvalue N k * fourierComponent N f k x := by
  have heq : fourierComponent N f k =
      (fun z => cosineCoefficient N f k * finiteCosine N k z) +
      (fun z => sineCoefficient N f k * finiteSine N k z) := rfl
  rw [heq, generator_add, neg_add_rev, generator_mul_left, generator_mul_left]
  simp only [neg_mul_eq_mul_neg, finiteCosine_generator, finiteSine_generator, Pi.add_apply]
  ring

lemma fourier_generator_inversion (N : Size) (f : Vertex N → ℝ) (x : Vertex N) :
    (∑ k ∈ nonzeroFrequencies N, finiteEigenvalue N k * fourierComponent N f k x) =
      vertexCount N * (-generator N f x) := by
  have hfun : (fun z => ∑ k ∈ nonzeroFrequencies N, fourierComponent N f k z) =
      (fun z => vertexCount N * f z) - (fun _ => ∑ y : Vertex N, f y) :=
    funext (fourier_inversion N f)
  have hgen := congrArg (fun u : Vertex N → ℝ => -generator N u x) hfun
  rw [generator_sum, ← Finset.sum_neg_distrib] at hgen
  simp only [fourierComponent_generator, generator_sub, generator_const, sub_zero,
    generator_mul_left, neg_mul_eq_mul_neg] at hgen
  exact hgen

lemma finite_energy_parseval (N : Size) (f : Vertex N → ℝ) :
    (∑ k ∈ nonzeroFrequencies N, finiteEigenvalue N k *
      (cosineCoefficient N f k ^ 2 + sineCoefficient N f k ^ 2)) =
      vertexCount N * energy N f := by
  simp_rw [← fourierComponent_pair, Finset.mul_sum]
  rw [Finset.sum_comm]
  have hsum (x : Vertex N) :
      (∑ k ∈ nonzeroFrequencies N, finiteEigenvalue N k * (f x * fourierComponent N f k x)) =
        f x * (∑ k ∈ nonzeroFrequencies N, finiteEigenvalue N k * fourierComponent N f k x) := by
    rw [Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro k _
    ring
  simp_rw [hsum, fourier_generator_inversion]
  rw [energy, Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro x _
  ring

end TorusCoverTime.Blocks.B
