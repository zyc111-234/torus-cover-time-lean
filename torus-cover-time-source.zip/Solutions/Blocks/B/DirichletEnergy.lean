import Solutions.Blocks.B.GreenOperator

/-! The exact Dirichlet form and its nullspace on the finite torus. -/

noncomputable section
open scoped BigOperators
namespace TorusCoverTime.Blocks.B

lemma sum_translate (N : Size) (f : Vertex N → ℝ) (a : Vertex N) :
    (∑ x : Vertex N, f (x + a)) = ∑ x : Vertex N, f x :=
  Fintype.sum_equiv (Equiv.addRight a) _ _ (fun _ => rfl)

lemma sum_translate_mul (N : Size) (f g : Vertex N → ℝ) (a : Vertex N) :
    (∑ x : Vertex N, f (x + a) * g x) = ∑ x : Vertex N, f x * g (x - a) := by
  simpa only [add_sub_cancel_right] using
    (sum_translate N (fun x => f x * g (x - a)) a)

def dirichletPairing (N : Size) (f g : Vertex N → ℝ) : ℝ :=
  ∑ x : Vertex N, f x * (-generator N g x)

lemma edge_pairing (N : Size) (f g : Vertex N → ℝ) (a : Vertex N) :
    (∑ x : Vertex N, (f (x + a) - f x) * (g (x + a) - g x)) =
      ∑ x : Vertex N, f x * (2 * g x - g (x + a) - g (x - a)) := by
  have hshift := sum_translate N (fun x => f x * g x) a
  have hcross := sum_translate_mul N f g a
  simp only [sub_mul, mul_sub, Finset.sum_sub_distrib] at ⊢
  rw [hshift, hcross]
  rw [show (∑ x : Vertex N, f x * (2 * g x)) =
      2 * ∑ x : Vertex N, f x * g x by
    rw [Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro x _
    ring]
  ring

lemma dirichletPairing_edges (N : Size) (f g : Vertex N → ℝ) :
    dirichletPairing N f g = (1 / 4 : ℝ) *
      ((∑ x : Vertex N, (f (x + (1, 0)) - f x) * (g (x + (1, 0)) - g x)) +
       (∑ x : Vertex N, (f (x + (0, 1)) - f x) * (g (x + (0, 1)) - g x))) := by
  rw [edge_pairing, edge_pairing, ← Finset.sum_add_distrib, Finset.mul_sum]
  unfold dirichletPairing
  apply Finset.sum_congr rfl
  intro x _
  simp [generator, Fin.sum_univ_succ, direction, sub_eq_add_neg]
  ring

lemma dirichletPairing_symm (N : Size) (f g : Vertex N → ℝ) :
    dirichletPairing N f g = dirichletPairing N g f := by
  simp only [dirichletPairing_edges, mul_comm]

lemma energy_edges (N : Size) (f : Vertex N → ℝ) :
    energy N f = (1 / 4 : ℝ) *
      ((∑ x : Vertex N, (f (x + (1, 0)) - f x) ^ 2) +
       (∑ x : Vertex N, (f (x + (0, 1)) - f x) ^ 2)) := by
  simpa only [← sq, dirichletPairing, energy] using dirichletPairing_edges N f f

lemma energy_nonneg (N : Size) (f : Vertex N → ℝ) : 0 ≤ energy N f := by
  rw [energy_edges]
  positivity

lemma energy_zero_edges (N : Size) (f : Vertex N → ℝ) (hf : energy N f = 0)
    (x : Vertex N) : f (x + (1, 0)) = f x ∧ f (x + (0, 1)) = f x := by
  have h1 : 0 ≤ ∑ y : Vertex N, (f (y + (1, 0)) - f y) ^ 2 :=
    Finset.sum_nonneg (fun _ _ => sq_nonneg _)
  have h2 : 0 ≤ ∑ y : Vertex N, (f (y + (0, 1)) - f y) ^ 2 :=
    Finset.sum_nonneg (fun _ _ => sq_nonneg _)
  have hx1 := Finset.single_le_sum (s := (Finset.univ : Finset (Vertex N)))
    (f := fun y => (f (y + (1, 0)) - f y) ^ 2) (fun _ _ => sq_nonneg _) (Finset.mem_univ x)
  have hx2 := Finset.single_le_sum (s := (Finset.univ : Finset (Vertex N)))
    (f := fun y => (f (y + (0, 1)) - f y) ^ 2) (fun _ _ => sq_nonneg _) (Finset.mem_univ x)
  rw [energy_edges] at hf
  constructor <;> nlinarith [sq_nonneg (f (x + (1, 0)) - f x),
    sq_nonneg (f (x + (0, 1)) - f x)]

lemma energy_zero_constant (N : Size) (f : Vertex N → ℝ) (hf : energy N f = 0) :
    ∀ x : Vertex N, f x = f 0 := by
  have hstep := energy_zero_edges N f hf
  have hfirst (x : Vertex N) (n : ℕ) : f (x + ((n : ZMod N.val), 0)) = f x := by
    induction n with
    | zero => simp [← Prod.zero_eq_mk]
    | succ n ih =>
      rw [Nat.cast_add, Nat.cast_one]
      have heq : x + ((n : ZMod N.val) + 1, 0) =
          (x + ((n : ZMod N.val), 0)) + (1, 0) := by ext <;> simp [add_assoc]
      rw [heq, (hstep _).1, ih]
  have hsecond (x : Vertex N) (n : ℕ) : f (x + (0, (n : ZMod N.val))) = f x := by
    induction n with
    | zero => simp [← Prod.zero_eq_mk]
    | succ n ih =>
      rw [Nat.cast_add, Nat.cast_one]
      have heq : x + (0, (n : ZMod N.val) + 1) =
          (x + (0, (n : ZMod N.val))) + (0, 1) := by ext <;> simp [add_assoc]
      rw [heq, (hstep _).2, ih]
  intro x
  have h1 := hfirst (0, x.2) x.1.val
  have h2 := hsecond 0 x.2.val
  simp only [ZMod.natCast_zmod_val, Prod.mk_add_mk, zero_add, add_zero] at h1 h2
  exact h1.trans h2

lemma spatialMean_const (N : Size) (c : ℝ) : spatialMean N (fun _ => c) = c := by
  have hn := vertexCount_pos N
  simp only [spatialMean, Finset.sum_const, Finset.card_univ, Fintype.card_prod,
    ZMod.card, nsmul_eq_mul, Nat.cast_mul]
  change (N.val * N.val * c) / vertexCount N = c
  rw [← pow_two, ← vertexCount]
  exact mul_div_cancel_left₀ c hn.ne'

lemma energy_zero_of_mean_zero (N : Size) (f : Vertex N → ℝ)
    (hmean : spatialMean N f = 0) (hf : energy N f = 0) : f = 0 := by
  have hconst : f = fun _ => f 0 := funext (energy_zero_constant N f hf)
  have hzero : f 0 = 0 := by
    rw [hconst, spatialMean_const] at hmean
    exact hmean
  funext x
  exact (energy_zero_constant N f hf x).trans hzero

end TorusCoverTime.Blocks.B
