import Solutions.Blocks.B.DiskCardinality
import Solutions.Blocks.B.DiskBarrier

noncomputable section
open Classical
namespace TorusCoverTime.Blocks.B

theorem torusDisk_card_lower (N : Size) (c : Vertex N) (R : ℝ) (hR : 0<R)
    (hsmall : R<N.val) : R^2/4≤((torusDisk N c R).card:ℝ) := by
  let m := ⌊R/2⌋₊+1
  let Q := Finset.range m ×ˢ Finset.range m
  let p := fun z : ℕ × ℕ => torusProjection N c ((z.1:ℤ),(z.2:ℤ))
  have hcoord {k : ℕ} (hk : k<m) : (k:ℝ)≤R/2 := by
    have hh : k≤⌊R/2⌋₊ := by dsimp [m] at hk; omega
    exact (by exact_mod_cast hh : (k:ℝ)≤(⌊R/2⌋₊:ℝ)).trans (Nat.floor_le (by positivity))
  have hsmallcoord {k : ℕ} (hk : k<m) : 2*|((k:ℤ):ℝ)|<(N.val:ℝ) := by
    simp only [Int.cast_natCast,abs_of_nonneg (Nat.cast_nonneg (α := ℝ) k)]
    linarith [hcoord hk]
  have hmem {z : ℕ × ℕ} (hz : z∈Q) : p z∈torusDisk N c R := by
    obtain ⟨h1,h2⟩ := Finset.mem_product.mp hz
    have hz1 := Finset.mem_range.mp h1
    have hz2 := Finset.mem_range.mp h2
    apply (mem_torusDisk N c _ R).mpr
    rw [show p z=torusProjection N c ((z.1:ℤ),(z.2:ℤ)) by rfl,
      periodicDistance_projection_of_small N c _ (hsmallcoord hz1) (hsmallcoord hz2)]
    unfold latticeRadius
    push_cast
    apply (Real.sqrt_lt (by positivity) hR.le).mpr
    have hh1 := hcoord hz1
    have hh2 := hcoord hz2
    nlinarith [Nat.cast_nonneg (α := ℝ) z.1,Nat.cast_nonneg (α := ℝ) z.2]
  have hinj : Set.InjOn p ↑Q := by
    intro z hz w hw he
    have hz' := Finset.mem_product.mp hz
    have hw' := Finset.mem_product.mp hw
    have he' := congrArg (centeredLift N c) he
    change centeredLift N c (torusProjection N c ((z.1:ℤ),(z.2:ℤ)))=
      centeredLift N c (torusProjection N c ((w.1:ℤ),(w.2:ℤ))) at he'
    rw [centeredLift_projection_of_small N c _ (hsmallcoord (Finset.mem_range.mp hz'.1)) (hsmallcoord (Finset.mem_range.mp hz'.2)),
      centeredLift_projection_of_small N c _ (hsmallcoord (Finset.mem_range.mp hw'.1)) (hsmallcoord (Finset.mem_range.mp hw'.2))] at he'
    apply Prod.ext
    · exact Int.ofNat_inj.mp (congrArg Prod.fst he')
    · exact Int.ofNat_inj.mp (congrArg Prod.snd he')
  have hc := Finset.card_le_card_of_injOn p (fun z hz => hmem hz) hinj
  have hc' : (m:ℝ)^2≤((torusDisk N c R).card:ℝ) := by
    have hh : (Q.card:ℝ)≤((torusDisk N c R).card:ℝ) := by exact_mod_cast hc
    simpa only [Q,Finset.card_product,Finset.card_range,Nat.cast_mul,pow_two] using hh
  have hm : R/2<(m:ℝ) := by simpa only [m,Nat.cast_add,Nat.cast_one] using Nat.lt_floor_add_one (R/2)
  nlinarith [Nat.cast_nonneg (α := ℝ) m]

end TorusCoverTime.Blocks.B
