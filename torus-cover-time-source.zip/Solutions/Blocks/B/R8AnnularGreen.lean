import Solutions.Blocks.B.AnnularPotential
import Solutions.Blocks.B.R7PreciseGreen

/-! B-T4: sharp actual annulus hitting probabilities. Using the disk Green
function instead of the bounded-error potential retains exponential precision
for both the starting point and the first entrance boundary. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

theorem diskGreen_annulus_harmonic (N : Size) (c : Vertex N) (r R : ℝ)
    (hr : 0 < r) (hR : 0 ≤ R) (hsmall : 2*(R+1) < N.val) :
    ∀ z ∈ torusDisk N c R \ torusDisk N c r,
      generator N (fun x => diskGreen N c R x c/g) z = 0 := by
  intro z hz
  have hzc : z ≠ c := by
    intro he
    subst z
    exact (Finset.mem_sdiff.mp hz).2
      ((mem_torusDisk N c c r).mpr (by rwa [periodicDistance_self_zero]))
  have hgen := domainGreenFromBarrier_generator N (torusDisk N c R) (diskBarrier N c R)
    (fun x hx => diskBarrier_generator N c R hR hsmall x hx) z c (Finset.mem_sdiff.mp hz).1
  rw [if_neg hzc] at hgen
  change -generator N (fun x => diskGreen N c R x c) z = 0 at hgen
  have he : (fun x => diskGreen N c R x c/g) =
      (fun x => g⁻¹*diskGreen N c R x c) := by funext x; ring
  rw [he,generator_mul_left,show generator N (fun x => diskGreen N c R x c) z = 0 by linarith,mul_zero]

theorem r8_annular_core_probability_sharp (N : Size) (c a b : Vertex N) (s w v : ℝ)
    (hqw : 64 ≤ s-2*w) (hw : Real.log 8 ≤ w) (hwq : w ≤ s-2*w)
    (hqv : 64 ≤ s-2*v) (hv : Real.log 8 ≤ v) (hvq : v ≤ s-2*v)
    (hsmall : 2*(Real.exp s+1) < N.val)
    (ha : |periodicDistance a c-Real.exp (s-w)| ≤ 2)
    (haA : a ∈ torusDisk N c (Real.exp s) \ torusDisk N c (Real.exp (s-v)))
    (hb : diskExteriorNeighbor N c (Real.exp s) b) :
    |v*walkLaw.real (exitsInto N
      (torusDisk N c (Real.exp s) \ torusDisk N c (Real.exp (s-v)))
        (torusDisk N c (Real.exp (s-v))) a)-w| ≤
      r7GreenCenterConstant*(Real.exp (-w/4)+Real.exp (-v/4)) := by
  let R := Real.exp s
  let r := Real.exp (s-v)
  let A := torusDisk N c R \ torusDisk N c r
  let F := fun z => diskGreen N c R z c/g
  let U := fun z => if z ∈ torusDisk N c r then v else 0
  have hR : 0 < R := Real.exp_pos _
  have hr : 0 < r := Real.exp_pos _
  have hproper : A ≠ Finset.univ := proper_sdiff N _ _ (torusDisk_proper N c R hR.le hsmall)
  have hF := diskGreen_annulus_harmonic N c r R hr hR.le hsmall
  have hstart : |F a-w| ≤ r7GreenCenterConstant*Real.exp (-w/4) := by
    have he₁ : (s-2*w)+2*w = s := by ring
    have he₂ : (s-2*w)+w = s-w := by ring
    have ht := r7_green_center_explicit N c a b (s-2*w) w hqw hw hwq
    rw [he₁,he₂] at ht
    exact ht hsmall ha hb
  have hboundary : ∀ z, exitHarmonic N A z a ≠ 0 →
      |F z-U z| ≤ r7GreenCenterConstant*Real.exp (-v/4) := by
    intro z hz
    have hgeom := exitHarmonic_annulus_geometry N c r R a z haA hz
    by_cases hzI : z ∈ torusDisk N c r
    · have hd := (mem_torusDisk N c z r).mp hzI
      have hdz : |periodicDistance z c-r| ≤ 2 := abs_le.mpr ⟨by linarith [hgeom.1 hzI],by linarith⟩
      have he₁ : (s-2*v)+2*v = s := by ring
      have he₂ : (s-2*v)+v = s-v := by ring
      have ht := r7_green_center_explicit N c z b (s-2*v) v hqv hv hvq
      rw [he₁,he₂] at ht
      simpa only [U,if_pos hzI] using ht hsmall hdz hb
    · have hzO := (hgeom.2 hzI).1
      have hzG : diskGreen N c R z c = 0 := domainGreenFromBarrier_boundary N
        (torusDisk N c R) (diskBarrier N c R) z c hzO
      simp only [F,U,if_neg hzI,hzG,zero_div,sub_zero,abs_zero]
      exact mul_nonneg r7GreenCenterConstant_pos.le (Real.exp_pos _).le
  have havg := exitExtension_uniform_error N A hproper a F U
    (r7GreenCenterConstant*Real.exp (-v/4)) hboundary
  rw [← congrFun (harmonic_exit_representation N A hproper F hF) a,
    exitExtension_two_values N A (torusDisk N c r) hproper a v 0,
    sub_zero,zero_add] at havg
  calc
    _ ≤ |v*walkLaw.real (exitsInto N A (torusDisk N c r) a)-F a|+|F a-w| := abs_sub_le _ _ _
    _ ≤ r7GreenCenterConstant*Real.exp (-v/4)+r7GreenCenterConstant*Real.exp (-w/4) :=
      add_le_add (by rwa [abs_sub_comm]) hstart
    _ = _ := by ring

theorem r8_annular_avoid_probability_sharp (N : Size) (c a b : Vertex N) (s w v : ℝ)
    (hqw : 64 ≤ s-2*w) (hw : Real.log 8 ≤ w) (hwq : w ≤ s-2*w)
    (hqv : 64 ≤ s-2*v) (hv : Real.log 8 ≤ v) (hvq : v ≤ s-2*v)
    (hsmall : 2*(Real.exp s+1) < N.val)
    (ha : |periodicDistance a c-Real.exp (s-w)| ≤ 2)
    (haA : a ∈ torusDisk N c (Real.exp s) \ torusDisk N c (Real.exp (s-v)))
    (hb : diskExteriorNeighbor N c (Real.exp s) b) :
    |v*walkLaw.real (exitsAvoidingCore N (torusDisk N c (Real.exp s))
      (torusDisk N c (Real.exp (s-v))) a)-(v-w)| ≤
      r7GreenCenterConstant*(Real.exp (-w/4)+Real.exp (-v/4)) := by
  have hcore := r8_annular_core_probability_sharp N c a b s w v hqw hw hwq hqv hv hvq hsmall ha haA hb
  have hv0 : 0 ≤ v := (Real.log_nonneg (by norm_num : (1:ℝ) ≤ 8)).trans hv
  have hsum := annulus_core_avoid_probabilities N (torusDisk N c (Real.exp s))
    (torusDisk N c (Real.exp (s-v))) (torusDisk_proper N c _ (Real.exp_pos _).le hsmall)
    (torusDisk_subset N c _ _ (Real.exp_le_exp.mpr (by linarith))) a
  have he : v*walkLaw.real (exitsAvoidingCore N (torusDisk N c (Real.exp s))
      (torusDisk N c (Real.exp (s-v))) a)-(v-w) =
      -(v*walkLaw.real (exitsInto N
        (torusDisk N c (Real.exp s) \ torusDisk N c (Real.exp (s-v)))
          (torusDisk N c (Real.exp (s-v))) a)-w) := by linear_combination v*hsum
  rwa [he,abs_neg]

end TorusCoverTime.Blocks.B
