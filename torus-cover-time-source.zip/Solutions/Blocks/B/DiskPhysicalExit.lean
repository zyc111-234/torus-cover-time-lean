import Solutions.Blocks.B.DiskExitTail

/-! Finiteness and radius-squared tails for the physical disk exit time, including
the event of never exiting. The finite-index convention is justified almost surely. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

lemma domainExitTime_le_hittingTime (N : Size) (D : Finset (Vertex N))
    (a x : Vertex N) (ω : WalkSample) (hx : x ∉ D) :
    domainExitTime N D a ω ≤ hittingTime N a ω x := by
  apply le_sInf
  rintro u ⟨t, ht, hxw, rfl⟩
  exact sInf_le ⟨t, ht, by simpa only [hxw] using hx, rfl⟩

lemma domainExitTime_tail_le_survival (N : Size) (D : Finset (Vertex N))
    (a : Vertex N) (t : ℝ) :
    walkLaw {ω | ENNReal.ofReal t < domainExitTime N D a ω} ≤
      walkLaw {ω | ∀ x ∈ Finset.univ \ D, ENNReal.ofReal t < hittingTime N a ω x} := by
  apply measure_mono
  intro ω hω x hx
  exact hω.trans_le (domainExitTime_le_hittingTime N D a x ω (Finset.mem_sdiff.mp hx).2)

theorem disk_physical_exit_tail (hWalk : WalkModelRegular)
    (N : Size) (y : Vertex N) (R : ℝ) (hR : 0 < R) (hsmall : 2*(R+1) < N.val)
    (a : Vertex N) (t : ℝ) (ht : 0 ≤ t) :
    walkLaw {ω | ENNReal.ofReal t < domainExitTime N (torusDisk N y R) a ω} ≤
      ENNReal.ofReal ((2*R+1)^2 * Real.exp (-t/(R+1)^2)) := by
  apply (ENNReal.le_ofReal_iff_toReal_le (measure_ne_top walkLaw _) (by positivity)).mpr
  exact (ENNReal.toReal_mono (measure_ne_top walkLaw _)
    (domainExitTime_tail_le_survival N (torusDisk N y R) a t)).trans
      (disk_survival_tail hWalk N y R hR hsmall a t ht)

theorem disk_physical_exit_ne_top_ae (hWalk : WalkModelRegular)
    (N : Size) (y : Vertex N) (R : ℝ) (hR : 0 < R) (hsmall : 2*(R+1) < N.val)
    (a : Vertex N) :
    ∀ᵐ ω ∂walkLaw, domainExitTime N (torusDisk N y R) a ω ≠ ∞ := by
  let E := {ω | domainExitTime N (torusDisk N y R) a ω = ∞}
  have hbound : ∀ᶠ s : ℝ in atTop,
      (walkLaw E).toReal ≤ (2*R+1)^2 * Real.exp (-s) := by
    filter_upwards [eventually_ge_atTop (0 : ℝ)] with s hs
    have hsub : E ⊆ {ω | ENNReal.ofReal ((R+1)^2*s) <
        domainExitTime N (torusDisk N y R) a ω} := by
      intro ω hω
      change domainExitTime N (torusDisk N y R) a ω = ∞ at hω
      change ENNReal.ofReal ((R+1)^2*s) < domainExitTime N (torusDisk N y R) a ω
      rw [hω]
      exact ENNReal.ofReal_lt_top
    have hb := (measure_mono hsub).trans
      (disk_physical_exit_tail hWalk N y R hR hsmall a ((R+1)^2*s) (by positivity))
    have heq : -((R+1)^2*s)/(R+1)^2 = -s := by field_simp
    rw [heq] at hb
    exact (ENNReal.le_ofReal_iff_toReal_le (measure_ne_top walkLaw _) (by positivity)).mp hb
  have ht : Tendsto (fun s : ℝ => (2*R+1)^2 * Real.exp (-s)) atTop (𝓝 0) := by
    simpa only [mul_zero] using Real.tendsto_exp_neg_atTop_nhds_zero.const_mul ((2*R+1)^2)
  have hr : (walkLaw E).toReal = 0 :=
    le_antisymm (le_of_tendsto_of_tendsto tendsto_const_nhds ht hbound) ENNReal.toReal_nonneg
  have hz : walkLaw E = 0 :=
    ((ENNReal.toReal_eq_zero_iff (walkLaw E)).mp hr).resolve_right (measure_ne_top walkLaw _)
  apply ae_iff.mpr
  simpa [E] using hz

lemma domainExitTime_eq_top_of_no_exit (N : Size) (D : Finset (Vertex N))
    (a : Vertex N) (ω : WalkSample) (hno : ¬ ∃ n : ℕ, position N a ω n ∉ D) :
    domainExitTime N D a ω = ∞ := by
  have he : {u | ∃ t : ℝ, 0 ≤ t ∧ walk N a ω t ∉ D ∧ u = ENNReal.ofReal t} = ∅ := by
    apply Set.eq_empty_iff_forall_notMem.mpr
    rintro u ⟨t, ht, hnot, _⟩
    apply hno
    refine ⟨jumpCount ω t, ?_⟩
    simpa only [walk, if_neg (not_lt.mpr ht)] using hnot
  rw [domainExitTime, he, sInf_empty]

lemma exit_word_of_exists_exit (N : Size) (D : Finset (Vertex N))
    (a : Vertex N) (ω : WalkSample) (he : ∃ n : ℕ, position N a ω n ∉ D) :
    exitsThroughAt N D a (position N a ω (Nat.find he)) ω (Nat.find he) := by
  exact ⟨Nat.find_spec he, rfl, fun j => not_not.mp (Nat.find_min he j.isLt)⟩

theorem disk_finiteExitDuration_eq_physical_ae (hWalk : WalkModelRegular)
    (N : Size) (y : Vertex N) (R : ℝ) (hR : 0 < R) (hsmall : 2*(R+1) < N.val)
    (a : Vertex N) :
    ∀ᵐ ω ∂walkLaw, domainExitTime N (torusDisk N y R) a ω =
      ENNReal.ofReal (finiteExitDuration N (torusDisk N y R) a ω) := by
  filter_upwards [hWalk.1, disk_physical_exit_ne_top_ae hWalk N y R hR hsmall a] with ω hω hfinite
  have he : ∃ n : ℕ, position N a ω n ∉ torusDisk N y R := by
    by_contra he
    exact hfinite (domainExitTime_eq_top_of_no_exit N _ a ω he)
  exact domainExitTime_of_exit_word N _ a _ hω.1 hω.2 _ (exit_word_of_exists_exit N _ a ω he)

end TorusCoverTime.Blocks.B
