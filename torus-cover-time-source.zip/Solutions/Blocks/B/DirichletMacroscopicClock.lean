import Solutions.Blocks.B.DirichletConditionedField

noncomputable section
namespace TorusCoverTime.Blocks.B

def bt6ClockError (ρ : ℝ) : ℝ := dirichletLogError+|Real.log ρ|/2+1

theorem bt6ClockError_pos (ρ : ℝ) : 0<bt6ClockError ρ := by
  have h := dirichletLogError_pos
  unfold bt6ClockError
  positivity

theorem dirichlet_macroscopic_clock (N : Size) (root c x : Vertex N) (ρ : ℝ) (hρ : 0<ρ)
    (hR : 1≤ρ*(N.val:ℝ)) (hsmall : 2*(ρ*(N.val:ℝ)+1)<N.val)
    (hroot : root∉torusDisk N c (ρ*(N.val:ℝ))) (hx : periodicDistance x c≤ρ*(N.val:ℝ)/2) :
    |dirichletClockLS N root (torusDisk N c (ρ*(N.val:ℝ))) x-logSize N/2|≤bt6ClockError ρ := by
  have hh := dirichlet_LS_disk_clock_log N root c (ρ*(N.val:ℝ)) hR hsmall hroot x hx
  have hN : (N.val:ℝ)≠0 := (zero_lt_one.trans (size_real_gt_one N)).ne'
  rw [Real.log_mul hρ.ne' hN] at hh
  change |_-((Real.log ρ+logSize N)/2)|≤dirichletLogError at hh
  calc
    _ = |(dirichletClockLS N root (torusDisk N c (ρ*(N.val:ℝ))) x-(Real.log ρ+logSize N)/2)+Real.log ρ/2| := by congr 1; ring
    _ ≤ dirichletLogError+|Real.log ρ|/2 := by
      exact (abs_add_le _ _).trans (add_le_add hh (by rw [abs_div]; norm_num))
    _ ≤ _ := by unfold bt6ClockError; linarith

theorem bt6_clock_comparison (L C V : ℝ) (hC : 0≤C) (hL : 8*(C+1)≤L) (hV : |V-L/2|≤C) :
    0<V ∧ L/4≤V ∧ V≤L := by
  have hh := abs_le.mp hV
  constructor
  · linarith
  constructor <;> linarith

theorem bt6_endpoint_clock_bound (N : Size) (C V η t : ℝ) (hC : 0≤C)
    (hL : 8*(C+1)≤logSize N) (hV : |V-logSize N/2|≤C)
    (hη : η≤logSize N) (ht : |t-harmonicExtremeCenter N|≤η) : |t|≤12*V := by
  have hv := bt6_clock_comparison (logSize N) C V hC hL hV
  have hl1 : 1≤logSize N := by linarith
  have hm := harmonicExtremeCenter_log_error N hl1
  have hlog := Real.log_le_sub_one_of_pos (show 0<logSize N by linarith)
  have hs2 : Real.sqrt (2:ℝ)≤2 := by nlinarith [Real.sq_sqrt (by norm_num : (0:ℝ)≤2),Real.sqrt_nonneg (2:ℝ)]
  have hcenter : |harmonicExtremeCenter N|≤2*logSize N := by
    unfold harmonicExtremeCenter
    have hs : 0<Real.sqrt (2:ℝ) := by positivity
    have hs1 : 1≤Real.sqrt (2:ℝ) := by nlinarith [Real.sq_sqrt (by norm_num : (0:ℝ)≤2),Real.sqrt_nonneg (2:ℝ)]
    rw [abs_div,abs_of_pos hs,abs_of_nonneg (by linarith [Real.log_nonneg hl1])]
    apply (div_le_iff₀ hs).mpr
    nlinarith [mul_nonneg (show 0≤logSize N by linarith) (sub_nonneg.mpr hs1),Real.log_nonneg hl1]
  have htri : |t|≤η+2*logSize N := by
    calc
      _ = |(t-harmonicExtremeCenter N)+harmonicExtremeCenter N| := by congr 1; ring
      _ ≤ _ := (abs_add_le _ _).trans (add_le_add ht hcenter)
  linarith

end TorusCoverTime.Blocks.B
