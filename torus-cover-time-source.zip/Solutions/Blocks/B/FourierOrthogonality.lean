import Solutions.Blocks.B.FiniteFourier

/-! Finite Fourier orthogonality and the initial condition of the heat-kernel formula. -/

noncomputable section
open scoped BigOperators

namespace TorusCoverTime.Blocks.B

lemma coordinateCharacter_injective (N : Size) : Function.Injective (coordinateCharacter N) := by
  intro a b hab
  apply ZMod.toAddCircle_injective N
  apply AddCircle.injective_toCircle one_ne_zero
  exact Subtype.coe_injective hab

lemma coordinateCharacter_ne_one (N : Size) {a : ZMod N.val} (ha : a ≠ 0) :
    coordinateCharacter N a ≠ 1 := by
  intro h
  apply ha
  apply coordinateCharacter_injective N
  simpa only [coordinateCharacter_zero] using h

lemma finiteCharacter_symm (N : Size) (k x : Vertex N) :
    finiteCharacter N k x = finiteCharacter N x k := by
  unfold finiteCharacter
  congr 1
  ring

lemma finiteCharacter_sum_eq_zero (N : Size) (k : Vertex N) (hk : k ≠ 0) :
    (∑ x : Vertex N, finiteCharacter N k x) = 0 := by
  have hex : ∃ a : Vertex N, finiteCharacter N k a ≠ 1 := by
    by_cases hk1 : k.1 = 0
    · have hk2 : k.2 ≠ 0 := by
        intro hk2
        exact hk (Prod.ext hk1 hk2)
      refine ⟨(0, 1), ?_⟩
      simpa [finiteCharacter] using coordinateCharacter_ne_one N hk2
    · refine ⟨(1, 0), ?_⟩
      simpa [finiteCharacter] using coordinateCharacter_ne_one N hk1
  obtain ⟨a, ha⟩ := hex
  have hshift : (∑ x : Vertex N, finiteCharacter N k (x + a)) =
      ∑ x : Vertex N, finiteCharacter N k x :=
    Fintype.sum_equiv (Equiv.addRight a) (fun x => finiteCharacter N k (x + a))
      (finiteCharacter N k) (fun _ => rfl)
  simp_rw [finiteCharacter_add] at hshift
  rw [← Finset.sum_mul] at hshift
  have hzero : (∑ x : Vertex N, finiteCharacter N k x) * (finiteCharacter N k a - 1) = 0 := by
    rw [mul_sub, mul_one, hshift, sub_self]
  exact (mul_eq_zero.mp hzero).resolve_right (sub_ne_zero.mpr ha)

lemma finiteCharacter_sum (N : Size) (k : Vertex N) :
    (∑ x : Vertex N, finiteCharacter N k x) =
      if k = 0 then (vertexCount N : ℂ) else 0 := by
  by_cases hk : k = 0
  · subst k
    simp [finiteCharacter, vertexCount, Fintype.card_prod, ZMod.card, pow_two]
  · rw [if_neg hk]
    exact finiteCharacter_sum_eq_zero N k hk

lemma finiteCosine_sum (N : Size) (z : Vertex N) :
    (∑ k : Vertex N, finiteCosine N k z) = if z = 0 then vertexCount N else 0 := by
  have h := congrArg Complex.re (finiteCharacter_sum N z)
  have hterms (k : Vertex N) : (finiteCharacter N z k).re = finiteCosine N k z := by
    rw [finiteCharacter_symm, finiteCharacter_re]
  have hsum : (∑ x : Vertex N, finiteCharacter N z x).re =
      ∑ x : Vertex N, (finiteCharacter N z x).re := map_sum Complex.reAddGroupHom _ _
  rw [hsum] at h
  simpa only [hterms, apply_ite, Complex.ofReal_re, Complex.zero_re] using h

lemma finite_fourier_initial_condition (N : Size) (x y : Vertex N) :
    1 + (∑ k ∈ nonzeroFrequencies N, finiteCosine N k (x - y)) =
      if x = y then vertexCount N else 0 := by
  have hsum := Finset.sum_erase_add (s := (Finset.univ : Finset (Vertex N)))
    (fun k => finiteCosine N k (x - y)) (Finset.mem_univ (0 : Vertex N))
  have hzero : finiteCosine N 0 (x - y) = 1 := by simp [finiteCosine, fourierAngle]
  rw [hzero, finiteCosine_sum] at hsum
  simpa only [nonzeroFrequencies, sub_eq_zero, add_comm] using hsum

end TorusCoverTime.Blocks.B
