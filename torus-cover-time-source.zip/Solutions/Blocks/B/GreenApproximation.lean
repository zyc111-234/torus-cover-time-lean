import Solutions.Blocks.B.EigenvalueBounds
import Solutions.Blocks.B.GreenStructure

/-! Uniform comparison of the discrete Green multiplier with its quadratic symbol. -/

noncomputable section
open scoped BigOperators
namespace TorusCoverTime.Blocks.B

lemma frequencyNormSq_pos (N : Size) (k : Vertex N) (hk : k ∈ nonzeroFrequencies N) :
    0 < frequencyNormSq N k := by
  have h := (eigenvalue_pos_of_nonzero N hk).trans_le (eigenvalue_frequency_bounds N k).2
  have hprod := (div_pos_iff_of_pos_right (vertexCount_pos N)).mp h
  exact (mul_pos_iff_of_pos_left (sq_pos_of_pos Real.pi_pos)).mp hprod

lemma eigenvalue_quadratic_error (N : Size) (k : Vertex N) :
    0 ≤ Real.pi ^ 2 * frequencyNormSq N k / vertexCount N - finiteEigenvalue N k ∧
    Real.pi ^ 2 * frequencyNormSq N k / vertexCount N - finiteEigenvalue N k ≤
      Real.pi ^ 4 * frequencyNormSq N k ^ 2 / (3 * vertexCount N ^ 2) := by
  refine ⟨sub_nonneg.mpr (eigenvalue_frequency_bounds N k).2, ?_⟩
  let a := Real.pi * coordinateDistance k.1 0 / N.val
  let b := Real.pi * coordinateDistance k.2 0 / N.val
  have ha : 0 ≤ a := div_nonneg
    (mul_nonneg Real.pi_pos.le (coordinateDistance_zero_bounds N k.1).1)
    (lt_trans zero_lt_one (size_real_gt_one N)).le
  have hb : 0 ≤ b := div_nonneg
    (mul_nonneg Real.pi_pos.le (coordinateDistance_zero_bounds N k.2).1)
    (lt_trans zero_lt_one (size_real_gt_one N)).le
  have he1 := (abs_le.mp (abs_sine_square_error a ha)).1
  have he2 := (abs_le.mp (abs_sine_square_error b hb)).1
  have hlam : finiteEigenvalue N k = Real.sin a ^ 2 + Real.sin b ^ 2 := by
    rw [finiteEigenvalue_eq_sines, sine_val_eq_sine_distance, sine_val_eq_sine_distance]
  have hquad : Real.pi ^ 2 * frequencyNormSq N k / vertexCount N = a ^ 2 + b ^ 2 := by
    simp only [a, b, frequencyNormSq, vertexCount]
    ring
  have hfour : Real.pi ^ 4 * frequencyNormSq N k ^ 2 / (3 * vertexCount N ^ 2) =
      (a ^ 2 + b ^ 2) ^ 2 / 3 := by
    simp only [a, b, frequencyNormSq, vertexCount]
    ring
  rw [hlam, hquad, hfour]
  nlinarith [mul_nonneg (sq_nonneg a) (sq_nonneg b)]

lemma reciprocal_quadratic_error (n q lam p : ℝ)
    (hn : 0 < n) (hq : 0 < q) (hp : 0 < p)
    (hlo : 4 * q / n ≤ lam) (hhi : lam ≤ p ^ 2 * q / n)
    (herr : p ^ 2 * q / n - lam ≤ p ^ 4 * q ^ 2 / (3 * n ^ 2)) :
    0 ≤ 1 / (n * lam) - 1 / (p ^ 2 * q) ∧
    1 / (n * lam) - 1 / (p ^ 2 * q) ≤ p ^ 2 / (12 * n) := by
  have hl : 0 < lam := (div_pos (mul_pos (by norm_num) hq) hn).trans_le hlo
  have hpq : 0 < p ^ 2 * q := mul_pos (sq_pos_of_pos hp) hq
  have hden := mul_pos (mul_pos hn hl) hpq
  have hscaled := (div_le_iff₀ hn).mp hlo
  have hscaledhi := (le_div_iff₀ hn).mp hhi
  have hscalederr := (le_div_iff₀ (show 0 < 3 * n ^ 2 by positivity)).mp herr
  have hid : 1 / (n * lam) - 1 / (p ^ 2 * q) =
      (p ^ 2 * q - n * lam) / (n * lam * (p ^ 2 * q)) := by
    field_simp
  rw [hid]
  refine ⟨div_nonneg (by nlinarith) hden.le, ?_⟩
  apply (div_le_iff₀ hden).mpr
  rw [div_mul_eq_mul_div]
  apply (le_div_iff₀ (show 0 < 12 * n by positivity)).mpr ?_
  have herr' : 3 * n * (p ^ 2 * q - n * lam) ≤ p ^ 4 * q ^ 2 := by
    calc
      _ = (p ^ 2 * q / n - lam) * (3 * n ^ 2) := by field_simp
      _ ≤ _ := hscalederr
  have hmul := mul_le_mul_of_nonneg_left hscaled
    (show 0 ≤ p ^ 4 * q by positivity)
  calc
    (p ^ 2 * q - n * lam) * (12 * n) ≤ 4 * (p ^ 4 * q ^ 2) := by nlinarith [herr']
    _ ≤ p ^ 2 * (n * lam * (p ^ 2 * q)) := by nlinarith [hmul]

lemma green_multiplier_quadratic_error (N : Size) (k : Vertex N)
    (hk : k ∈ nonzeroFrequencies N) :
    0 ≤ 1 / (vertexCount N * finiteEigenvalue N k) -
        1 / (Real.pi ^ 2 * frequencyNormSq N k) ∧
    1 / (vertexCount N * finiteEigenvalue N k) -
        1 / (Real.pi ^ 2 * frequencyNormSq N k) ≤ Real.pi ^ 2 / (12 * vertexCount N) :=
  reciprocal_quadratic_error _ _ _ _ (vertexCount_pos N) (frequencyNormSq_pos N k hk)
    Real.pi_pos (eigenvalue_frequency_bounds N k).1 (eigenvalue_frequency_bounds N k).2
    (eigenvalue_quadratic_error N k).2

lemma greenDiagonal_quadratic_error (N : Size) :
    |greenDiagonal N -
      (∑ k ∈ nonzeroFrequencies N, 1 / frequencyNormSq N k) / Real.pi ^ 2| ≤
        Real.pi ^ 2 / 12 := by
  classical
  have hn := vertexCount_pos N
  have hN : (N.val : ℝ) ≠ 0 := (lt_trans zero_lt_one (size_real_gt_one N)).ne'
  have hid : greenDiagonal N -
      (∑ k ∈ nonzeroFrequencies N, 1 / frequencyNormSq N k) / Real.pi ^ 2 =
        ∑ k ∈ nonzeroFrequencies N, (1 / (vertexCount N * finiteEigenvalue N k) -
          1 / (Real.pi ^ 2 * frequencyNormSq N k)) := by
    rw [greenDiagonal_eq_sum, Finset.sum_div, Finset.sum_div, ← Finset.sum_sub_distrib]
    apply Finset.sum_congr rfl
    intro k _
    ring
  rw [hid, abs_of_nonneg (Finset.sum_nonneg (fun k hk =>
    (green_multiplier_quadratic_error N k hk).1))]
  calc
    _ ≤ ∑ _k ∈ nonzeroFrequencies N, Real.pi ^ 2 / (12 * vertexCount N) :=
      Finset.sum_le_sum (fun k hk => (green_multiplier_quadratic_error N k hk).2)
    _ ≤ ∑ _k : Vertex N, Real.pi ^ 2 / (12 * vertexCount N) := by
      apply Finset.sum_le_sum_of_subset_of_nonneg (Finset.subset_univ _)
      intro _ _ _
      positivity
    _ = Real.pi ^ 2 / 12 := by
      simp only [Finset.sum_const, Finset.card_univ, Fintype.card_prod, ZMod.card,
        nsmul_eq_mul, Nat.cast_mul, vertexCount]
      field_simp

end TorusCoverTime.Blocks.B
