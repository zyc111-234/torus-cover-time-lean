import Solutions.Blocks.B.KilledVariational

/-! An elementary quadratic variation gives the killed Euler equation. -/

noncomputable section
open scoped BigOperators
namespace TorusCoverTime.Blocks.B

lemma quadratic_linear_zero (a b : ℝ) (h : ∀ t : ℝ, 0 ≤ a * t ^ 2 + 2 * b * t) : b = 0 := by
  have ha : 0 ≤ a := by
    have h1 := h 1
    have hneg := h (-1)
    nlinarith
  have hd : a + 1 ≠ 0 := by linarith
  have hh := mul_nonneg (sq_nonneg (a + 1)) (h (-b / (a + 1)))
  have heq : (a + 1) ^ 2 * (a * (-b / (a + 1)) ^ 2 + 2 * b * (-b / (a + 1))) =
      -(a + 2) * b ^ 2 := by
    field_simp
    ring
  rw [heq] at hh
  have hsq : b ^ 2 ≤ 0 := by
    by_contra! hb
    have hp : 0 < (a + 2) * b ^ 2 := mul_pos (by linarith) hb
    linarith
  nlinarith [sq_nonneg b]

lemma squareSum_add_smul (N : Size) (f g : Vertex N → ℝ) (t : ℝ) :
    squareSum N (f + t • g) = squareSum N f + t ^ 2 * squareSum N g +
      2 * t * ∑ x : Vertex N, f x * g x := by
  simp only [squareSum, Pi.add_apply, Pi.smul_apply, smul_eq_mul,
    Finset.mul_sum, ← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro x _
  ring

lemma energy_add_smul (N : Size) (f g : Vertex N → ℝ) (t : ℝ) :
    energy N (f + t • g) = energy N f + t ^ 2 * energy N g +
      2 * t * dirichletPairing N f g := by
  rw [energy_add, energy_smul, dirichletPairing_smul_right]
  ring

lemma vanishesOn_add_smul (N : Size) (A : Finset (Vertex N))
    (f g : Vertex N → ℝ) (hf : vanishesOn N A f) (hg : vanishesOn N A g) (t : ℝ) :
    vanishesOn N A (f + t • g) := by
  intro x hx
  simp [hf x hx, hg x hx]

lemma killed_minimizer_pairing (N : Size) (A : Finset (Vertex N)) (hA : A ≠ Finset.univ)
    (f g : Vertex N → ℝ) (hf : vanishesOn N A f) (hg : vanishesOn N A g)
    (hmin : energy N f = killedEigenvalue N A * squareSum N f) :
    dirichletPairing N f g = killedEigenvalue N A * ∑ x : Vertex N, f x * g x := by
  apply sub_eq_zero.mp
  apply quadratic_linear_zero (energy N g - killedEigenvalue N A * squareSum N g)
  intro t
  have h := killed_rayleigh N A hA (f + t • g) (vanishesOn_add_smul N A f g hf hg t)
  rw [squareSum_add_smul, energy_add_smul, hmin] at h
  nlinarith [h]

lemma dirichletPairing_single (N : Size) (f : Vertex N → ℝ) (x : Vertex N) :
    dirichletPairing N f (Pi.single x 1) = -generator N f x := by
  classical
  rw [dirichletPairing_symm]
  simp [dirichletPairing, Pi.single_apply]

lemma killed_minimizer_eigenfunction (N : Size) (A : Finset (Vertex N)) (hA : A ≠ Finset.univ)
    (f : Vertex N → ℝ) (hf : vanishesOn N A f)
    (hmin : energy N f = killedEigenvalue N A * squareSum N f) :
    ∀ x, x ∉ A → -generator N f x = killedEigenvalue N A * f x := by
  classical
  intro x hx
  have h := killed_minimizer_pairing N A hA f (Pi.single x 1) hf
    (vanishesOn_single N A x hx) hmin
  simpa only [dirichletPairing_single, Pi.single_apply, mul_ite, mul_one, mul_zero,
    Finset.sum_ite_eq', Finset.mem_univ, if_true] using h

end TorusCoverTime.Blocks.B
