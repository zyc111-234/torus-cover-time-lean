import Solutions.Blocks.B.DirichletResidualConditioning

/-! Actual exit-residual tail reduced to spatial Green estimates. No
conditional probability bound is assumed: regression, Jensen and the
one-dimensional Gaussian square integral supply it. -/

noncomputable section
open MeasureTheory ProbabilityTheory
open scoped BigOperators
namespace TorusCoverTime.Blocks.B

theorem dirichletResidual_conditioned_Green_tail (N : Size) (root : Vertex N)
    (D E : Finset (Vertex N)) (hDE : D⊆E) (hroot : root∉E) (x : Vertex N)
    (hV : 0<dirichletClockLS N root E x) (Q C T t s : ℝ) (hQ : 0<Q) (hC : 0≤C) (ht : |t|≤T)
    (hinc : ∀ z, exitHarmonic N D z x≠0 →
      dirichletClockLS N root E z+dirichletClockLS N root E x-2*dirichletKernelLS N root E z x≤Q)
    (hcross : ∀ z, exitHarmonic N D z x≠0 →
      |dirichletKernelLS N root E z x-(dirichletClockLS N root E x-dirichletClockLS N root D x)|≤C) :
    (finiteFieldLaw N).real {ξ | 8*Q*s ≤
      ∑ z, exitHarmonic N D z x*(dirichletResidualAtEndpoint N root D E x t ξ z)^2} ≤
        2*Real.exp ((C*T/dirichletClockLS N root E x)^2/(4*Q)-s) := by
  have hrD : root∉D := fun hh => hroot (hDE hh)
  have hv : 0≤dirichletClockLS N root D x := by
    rw [← dirichletFieldLS_variance N root D hrD]
    exact variance_nonneg _ _
  have hvar (z : Vertex N) (hz : exitHarmonic N D z x≠0) :
      Var[dirichletLSResidual N root D E x z;finiteFieldLaw N]≤Q := by
    have hzD : z∉D := fun hzi => hz (exitHarmonic_zero_inside N D x z hzi)
    rw [dirichletLSResidual_variance_boundary N root D E hDE hroot x z hzD]
    linarith [hinc z hz]
  have hm (z : Vertex N) (hz : exitHarmonic N D z x≠0) :
      |dirichletResidualSlope N root D E x z*t|≤C*T/dirichletClockLS N root E x := by
    rw [dirichletResidualSlope_eq N root D E hDE hroot,abs_mul,abs_div,abs_of_pos hV]
    calc
      _ ≤ (C/dirichletClockLS N root E x)*T := mul_le_mul
        (div_le_div_of_nonneg_right (hcross z hz) hV.le) ht (abs_nonneg t) (div_nonneg hC hV.le)
      _ = _ := by ring
  exact dirichletResidual_conditioned_tail N root D E hDE hroot x hV Q
    (C*T/dirichletClockLS N root E x) t s hQ hvar hm

end TorusCoverTime.Blocks.B
