import Solutions.Blocks.B.KilledPath

/-! Poisson conditioning factors from every real observable of a finite direction prefix. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Classical
open scoped BigOperators ENNReal Topology
namespace TorusCoverTime.Blocks.B

lemma integral_direction_prefix_on_count (hWalk : WalkModelRegular)
    (t : ℝ) (ht : 0 ≤ t) (n : ℕ) (F : (Fin (n + 1) → Fin 4) → ℝ) :
    (∫ ω in {ω : WalkSample | jumpCount ω t = n}, F (fun j => (ω j.val).2) ∂walkLaw) =
      (walkLaw {ω | jumpCount ω t = n}).toReal *
        (∫ ω : WalkSample, F (fun j => (ω j.val).2) ∂walkLaw) := by
  let H := fun ω : WalkSample => fun j : Fin (n + 1) => (ω j.val).1
  let D := fun ω : WalkSample => fun j : Fin (n + 1) => (ω j.val).2
  let fH : (Fin (n + 1) → ℝ) → ℝ := fun u =>
    if (∑ j : Fin n, max (u j.castSucc) 0) ≤ t ∧
        t < ∑ j : Fin (n + 1), max (u j) 0 then 1 else 0
  have hH : Measurable H := by fun_prop
  have hD : Measurable D := by fun_prop
  have hfH : Measurable fH := by
    have hs0 : Measurable (fun u : Fin (n + 1) → ℝ => ∑ j : Fin n, max (u j.castSucc) 0) := by
      fun_prop
    have hs1 : Measurable (fun u : Fin (n + 1) → ℝ => ∑ j : Fin (n + 1), max (u j) 0) := by
      fun_prop
    exact Measurable.ite ((measurableSet_le hs0 measurable_const).inter
      (measurableSet_lt measurable_const hs1)) measurable_const measurable_const
  have hfF : Measurable F := measurable_of_finite _
  have hindep : IndepFun (fun ω : WalkSample => fH (H ω)) (fun ω => F (D ω)) walkLaw :=
    (holding_direction_prefix_independent (n + 1)).comp hfH hfF
  have hfactor := hindep.integral_fun_mul_eq_mul_integral (hfH.comp hH).aestronglyMeasurable
    (hfF.comp hD).aestronglyMeasurable
  have heqH : (fun ω : WalkSample => fH (H ω)) =ᵐ[walkLaw]
      (fun ω => if jumpCount ω t = n then (1 : ℝ) else 0) := by
    filter_upwards [jumpCount_event_ae hWalk t ht n] with ω hω
    have hS0 : (∑ j : Fin n, max ((H ω) j.castSucc) 0) = jumpTime ω n := by
      dsimp [H, jumpTime, holdingTime]
      rw [Fin.sum_univ_eq_sum_range (fun j => max (ω j).1 0)]
    have hS1 : (∑ j : Fin (n + 1), max ((H ω) j) 0) = jumpTime ω (n + 1) := by
      dsimp [H, jumpTime, holdingTime]
      rw [Fin.sum_univ_eq_sum_range (fun j => max (ω j).1 0)]
    dsimp [fH]
    rw [hS0, hS1]
    simp only [← hω]
  have hevent : MeasurableSet {ω : WalkSample | jumpCount ω t = n} :=
    (measurableSet_singleton n).preimage
      (measurable_jumpCount_joint.comp (measurable_prodMk_right (y := t)))
  have hleft : (∫ ω : WalkSample, fH (H ω) * F (D ω) ∂walkLaw) =
      ∫ ω in {ω : WalkSample | jumpCount ω t = n}, F (D ω) ∂walkLaw := by
    rw [← integral_indicator hevent]
    apply integral_congr_ae
    filter_upwards [heqH] with ω hω
    rw [hω]
    split_ifs <;> simp_all [Set.indicator]
  have hprob : (∫ ω : WalkSample, fH (H ω) ∂walkLaw) =
      (walkLaw {ω | jumpCount ω t = n}).toReal := by
    rw [integral_congr_ae heqH]
    simpa [Set.indicator, Measure.real] using integral_indicator_const (μ := walkLaw) (1 : ℝ) hevent
  change (∫ ω : WalkSample, fH (H ω) * F (D ω) ∂walkLaw) =
    (∫ ω : WalkSample, fH (H ω) ∂walkLaw) * (∫ ω : WalkSample, F (D ω) ∂walkLaw) at hfactor
  rw [hleft, hprob] at hfactor
  exact hfactor

def sampleOfDirections {m : ℕ} (d : Fin m → Fin 4) : WalkSample :=
  fun j => (1, if hj : j < m then d ⟨j, hj⟩ else 0)

lemma position_of_direction_prefix (N : Size) (start : Vertex N) (ω : WalkSample)
    (m k : ℕ) (hk : k ≤ m) :
    position N start (sampleOfDirections (fun j : Fin m => (ω j.val).2)) k =
      position N start ω k := by
  unfold position
  congr 1
  apply Finset.sum_congr rfl
  intro j hj
  have hjm : j < m := lt_of_lt_of_le (Finset.mem_range.mp hj) hk
  simp only [sampleOfDirections, hjm, dite_true]

lemma discreteAvoids_of_direction_prefix (N : Size) (start : Vertex N)
    (A : Finset (Vertex N)) (ω : WalkSample) (n : ℕ) :
    discreteAvoids N start A (sampleOfDirections (fun j : Fin (n + 1) => (ω j.val).2)) n ↔
      discreteAvoids N start A ω n := by
  unfold discreteAvoids
  apply forall_congr'
  intro k
  apply forall_congr'
  intro hk
  rw [position_of_direction_prefix N start ω (n + 1) k (by omega)]

def discreteSurvival (N : Size) (start : Vertex N) (A : Finset (Vertex N)) (n : ℕ) : ℝ :=
  ∫ ω : WalkSample, if discreteAvoids N start A ω n then (1 : ℝ) else 0 ∂walkLaw

lemma integral_discreteAvoids_on_count (hWalk : WalkModelRegular)
    (N : Size) (start : Vertex N) (A : Finset (Vertex N))
    (t : ℝ) (ht : 0 ≤ t) (n : ℕ) :
    (∫ ω in {ω : WalkSample | jumpCount ω t = n},
      if discreteAvoids N start A ω n then (1 : ℝ) else 0 ∂walkLaw) =
      (Real.exp (-t) * t ^ n / (n.factorial : ℝ)) * discreteSurvival N start A n := by
  let F : (Fin (n + 1) → Fin 4) → ℝ := fun d =>
    if discreteAvoids N start A (sampleOfDirections d) n then 1 else 0
  have h := integral_direction_prefix_on_count hWalk t ht n F
  dsimp only [F] at h
  simp_rw [discreteAvoids_of_direction_prefix] at h
  rwa [jumpCount_probability hWalk t ht n] at h

lemma killed_survival_poisson_hasSum (hWalk : WalkModelRegular)
    (N : Size) (start : Vertex N) (A : Finset (Vertex N)) (t : ℝ) (ht : 0 ≤ t) :
    HasSum (fun n : ℕ => (Real.exp (-t) * t ^ n / (n.factorial : ℝ)) *
      discreteSurvival N start A n)
      (walkLaw {ω | ∀ a ∈ A, ENNReal.ofReal t < hittingTime N start ω a}).toReal := by
  let events := fun n : ℕ => {ω : WalkSample | jumpCount ω t = n}
  let F : WalkSample → ℝ := fun ω =>
    if discreteAvoids N start A ω (jumpCount ω t) then 1 else 0
  have hcount : Measurable (fun ω : WalkSample => jumpCount ω t) :=
    measurable_jumpCount_joint.comp (measurable_prodMk_right (y := t))
  have hmeas (n : ℕ) : MeasurableSet (events n) := (measurableSet_singleton n).preimage hcount
  have hdisj : Pairwise (fun i j => Disjoint (events i) (events j)) := by
    intro i j hij
    apply Set.disjoint_left.mpr
    intro ω hi hj
    exact hij (hi.symm.trans hj)
  have hunion : (⋃ n : ℕ, events n) = Set.univ := by
    apply Set.eq_univ_of_forall
    intro ω
    exact Set.mem_iUnion.mpr ⟨jumpCount ω t, rfl⟩
  have hF : Measurable F := Measurable.ite (measurableSet_discreteAvoids_count N start A t)
    measurable_const measurable_const
  have hFi : Integrable F walkLaw := Integrable.of_bound hF.aestronglyMeasurable 1
    (Filter.Eventually.of_forall (fun ω => by dsimp [F]; split_ifs <;> norm_num))
  have hsum := hasSum_integral_iUnion hmeas hdisj hFi.integrableOn
  rw [hunion, Measure.restrict_univ] at hsum
  have hterm (n : ℕ) : (∫ ω in events n, F ω ∂walkLaw) =
      (Real.exp (-t) * t ^ n / (n.factorial : ℝ)) * discreteSurvival N start A n := by
    have heq : Set.EqOn F (fun ω => if discreteAvoids N start A ω n then (1 : ℝ) else 0)
        (events n) := by
      intro ω hω
      change jumpCount ω t = n at hω
      simp only [F, hω]
    rw [setIntegral_congr_fun (hmeas n) heq]
    exact integral_discreteAvoids_on_count hWalk N start A t ht n
  simp_rw [hterm] at hsum
  rw [survival_probability_discrete hWalk N start A t ht]
  exact hsum

end TorusCoverTime.Blocks.B
