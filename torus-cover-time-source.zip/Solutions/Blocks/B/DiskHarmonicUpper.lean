import Solutions.Blocks.B.HarmonicCutoff

/-! The upper mean inequality follows from the actual compact Green cutoff
and symmetry of the original generator, without a Harnack hypothesis. -/

noncomputable section
open Classical
namespace TorusCoverTime.Blocks.B

theorem harmonic_cutoff_pairing_zero (N : Size) (c : Vertex N) (R : ℝ) (hR : 0 < R)
    (f : Vertex N → ℝ) (hg : ∀ z ∈ torusDisk N c R, generator N f z = 0) :
    (∑ z, f z * generator N (harmonicCutoff N c R) z) = 0 := by
  have he : dirichletPairing N (harmonicCutoff N c R) f = 0 := by
    unfold dirichletPairing
    apply Finset.sum_eq_zero
    intro z _
    by_cases hz : z ∈ torusDisk N c R
    · rw [hg z hz, neg_zero, mul_zero]
    · have hd : R ≤ periodicDistance z c := not_lt.mp ((mem_torusDisk N c z R).not.mp hz)
      rw [harmonicCutoff_outside N c R hR z hd, zero_mul]
  rw [dirichletPairing_symm] at he
  simp only [dirichletPairing, mul_neg, Finset.sum_neg_distrib, neg_eq_zero] at he
  exact he

theorem disk_harmonic_mean_upper (N : Size) (c : Vertex N) (R : ℝ)
    (hR : 2*harmonicCutoffScale ≤ R) (hRN : R ≤ N.val) (f : Vertex N → ℝ)
    (hf : ∀ z, 0 ≤ f z) (hg : ∀ z ∈ torusDisk N c R, generator N f z = 0) :
    f c ≤ (2*harmonicCutoffSourceConstant/R^2) * (∑ z ∈ torusDisk N c (2*R), f z) := by
  have hL := harmonicCutoffScale_ge_one
  have hR1 : 1 ≤ R := by linarith
  have hR0 : 0 < R := by linarith
  have hC := harmonicCutoffSourceConstant_pos
  have hzero := harmonic_cutoff_pairing_zero N c R hR0 f hg
  have hcent : generator N (harmonicCutoff N c R) c = 1/vertexCount N - 1 := by
    rw [harmonicCutoff_generator_inner N c R hR c (by rw [periodicDistance_self_zero]; positivity), if_pos rfl]
  have hterm (z : Vertex N) : f z*generator N (harmonicCutoff N c R) z +
      (if z = c then (1-1/vertexCount N)*f c else 0) ≤
      (harmonicCutoffSourceConstant/R^2) * (if z ∈ torusDisk N c (2*R) then f z else 0) := by
    by_cases hzc : z = c
    · subst z
      rw [if_pos rfl, hcent]
      have hp : 0 ≤ (harmonicCutoffSourceConstant/R^2) *
          (if c ∈ torusDisk N c (2*R) then f c else 0) := by
        exact mul_nonneg (div_nonneg hC.le (sq_nonneg R)) (by split_ifs; exact hf c; exact le_rfl)
      nlinarith
    · rw [if_neg hzc, add_zero]
      by_cases hz : z ∈ torusDisk N c (2*R)
      · rw [if_pos hz]
        have hh := mul_le_mul_of_nonneg_left (harmonicCutoff_generator_bound N c R hR hRN z hzc) (hf z)
        nlinarith
      · rw [if_neg hz, mul_zero]
        have hd : 2*R ≤ periodicDistance z c := not_lt.mp ((mem_torusDisk N c z (2*R)).not.mp hz)
        rw [harmonicCutoff_generator_outside N c R hR0 z (by linarith), mul_zero]
  have hs := Finset.sum_le_sum (s := (Finset.univ : Finset (Vertex N))) (fun z _ => hterm z)
  simp only [Finset.sum_add_distrib, hzero, Finset.sum_ite_eq', Finset.mem_univ, if_true,
    zero_add, ← Finset.mul_sum] at hs
  have hsum : (∑ z : Vertex N, if z ∈ torusDisk N c (2*R) then f z else 0) =
      ∑ z ∈ torusDisk N c (2*R), f z := by
    rw [← Finset.sum_filter]
    congr 1
    ext z
    simp
  rw [hsum] at hs
  have hn : 2 ≤ vertexCount N := by
    unfold vertexCount
    have hn := size_real_gt_one N
    have hn3 : (3:ℝ) ≤ N.val := by exact_mod_cast (show 3 ≤ N.val by have := N.property; omega)
    nlinarith
  have hhalf : 1/2 ≤ 1-1/vertexCount N := by
    have hh := one_div_le_one_div_of_le (by norm_num : (0:ℝ) < 2) hn
    linarith
  have hm := mul_le_mul_of_nonneg_right hhalf (hf c)
  have hid : 2*harmonicCutoffSourceConstant/R^2 = 2*(harmonicCutoffSourceConstant/R^2) := by ring
  rw [hid]
  nlinarith

end TorusCoverTime.Blocks.B
