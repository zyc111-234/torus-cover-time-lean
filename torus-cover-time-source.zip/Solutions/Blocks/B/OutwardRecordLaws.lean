import Solutions.Blocks.B.SelectedRecordProduct
import Solutions.Blocks.B.R7PathConcentration
import Solutions.Blocks.B.R6CoarseCounts

/-! The internal records selected for replacement have the same occupation
and duration laws as the endpoint-conditioned R6/R7 blocks. Odd indices are
the actual outward traversals in the alternating path decomposition. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

def outwardRecordIndex (m : ℕ) (i : Fin m) : Fin (2*m) := ⟨2*i.val+1,by omega⟩

theorem outwardRecordIndex_injective (m : ℕ) : Function.Injective (outwardRecordIndex m) := by
  intro i j hij
  apply Fin.ext
  have he := congrArg Fin.val hij
  change 2*i.val+1 = 2*j.val+1 at he
  omega

def outwardRecordEquiv (m : ℕ) : Fin m ≃ {j : Fin (2*m) // j.val % 2 = 1} where
  toFun i := ⟨outwardRecordIndex m i,by simp [outwardRecordIndex]⟩
  invFun j := ⟨j.val.val/2,by have := j.val.isLt; omega⟩
  left_inv i := by apply Fin.ext; change (2*i.val+1)/2 = i.val; omega
  right_inv j := by
    apply Subtype.ext
    apply Fin.ext
    have := j.property
    change 2*(j.val.val/2)+1 = j.val.val
    omega

def exactExitRecordProductLaw (N : Size) (D : Finset (Vertex N)) (m : ℕ)
    (a b : Fin m → Vertex N) : Measure (Fin m → ℕ × WalkSample) :=
  Measure.pi (fun i => exactExitRecordLaw N D (a i) (b i))

theorem exactExitProduct_record_law (N : Size) (D : Finset (Vertex N)) (m : ℕ)
    (a b : Fin m → Vertex N) :
    (exactExitProductLaw N D m a b).map (fun ω i => finiteExitRecord N D (a i) (ω i)) =
      exactExitRecordProductLaw N D m a b := by
  exact Measure.pi_map_pi (fun i : Fin m => (finiteExitRecord_measurable N D (a i)).aemeasurable)

def recordProductOccupation (N : Size) (m : ℕ) (a : Fin m → Vertex N)
    (U : Vertex N → ℝ) (p : Fin m → ℕ × WalkSample) : ℝ :=
  ∑ i, excursionRecordCost N (a i) U (p i)

theorem recordProductOccupation_measurable (N : Size) (m : ℕ) (a : Fin m → Vertex N)
    (U : Vertex N → ℝ) : Measurable (recordProductOccupation N m a U) :=
  Finset.measurable_sum _ fun i _ => (excursionRecordCost_measurable N (a i) U).comp (measurable_pi_apply i)

theorem exactExitRecordProduct_occupation_law (N : Size) (D : Finset (Vertex N)) (m : ℕ)
    (a b : Fin m → Vertex N) (U : Vertex N → ℝ) :
    (exactExitRecordProductLaw N D m a b).map (recordProductOccupation N m a U) =
      (exactExitProductLaw N D m a b).map (fun ω => ∑ i, weightedExitOccupation N D (a i) U (ω i)) := by
  have hs : Measurable (fun v : Fin m → ℝ => ∑ i, v i) := by fun_prop
  have hr : Measurable (fun p : Fin m → ℕ × WalkSample => fun i => excursionRecordCost N (a i) U (p i)) :=
    measurable_pi_lambda _ fun i => (excursionRecordCost_measurable N (a i) U).comp (measurable_pi_apply i)
  have hw : Measurable (fun p : Fin m → WalkSample => fun i => weightedExitOccupation N D (a i) U (p i)) :=
    measurable_pi_lambda _ fun i => (weightedExitOccupation_measurable N D (a i) U).comp (measurable_pi_apply i)
  change (Measure.pi (fun i => exactExitRecordLaw N D (a i) (b i))).map
    ((fun v : Fin m → ℝ => ∑ i, v i) ∘ (fun p => fun i => excursionRecordCost N (a i) U (p i))) =
    (Measure.pi (fun i => exactExitLaw N D (a i) (b i))).map
    ((fun v : Fin m → ℝ => ∑ i, v i) ∘ (fun p => fun i => weightedExitOccupation N D (a i) U (p i)))
  rw [← Measure.map_map hs hr, ← Measure.map_map hs hw,
    Measure.pi_map_pi (fun i : Fin m => (excursionRecordCost_measurable N (a i) U).aemeasurable),
    Measure.pi_map_pi (fun i : Fin m => (weightedExitOccupation_measurable N D (a i) U).aemeasurable)]
  simp_rw [exactExitRecord_cost_law]

theorem r7_record_sqrt_upper_concentration (hWalk : WalkModelRegular) (γ : ℝ)
    (hγ : 0 < γ) (hγ1 : γ ≤ 1) :
    ∀ᶠ q : ℝ in atTop, ∀ N : Size, ∀ c : Vertex N, ∀ m : ℕ, ∀ a b : Fin m → Vertex N,
      2*(Real.exp (q+2*q^γ)+1) < N.val →
      (∀ i, |periodicDistance (a i) c-Real.exp (q+q^γ)| ≤ 2) →
      (∀ i, diskExteriorNeighbor N c (Real.exp (q+2*q^γ)) (b i)) →
      ∀ v Δ : ℝ, 0 ≤ v → (m:ℝ)*q^γ ≤ v^2 → 0 ≤ Δ →
      2*r7MeanConstant*Real.exp (-r7MeanExponent*q^γ)*v ≤ Δ → Δ ≤ v →
      (exactExitRecordProductLaw N (torusDisk N c (Real.exp (q+2*q^γ))) m a b).real
        {p | v+Δ < Real.sqrt (recordProductOccupation N m a
          (fun z => diskHarmonicWeight N c (Real.exp (q+1)) z/g) p)} ≤
        2*Real.exp (-(r7ConcentrationConstant/4)*Δ^2/q^γ) := by
  filter_upwards [r7_occupation_sqrt_upper_concentration hWalk γ hγ hγ1] with q hq
  intro N c m a b hsmall ha hb v Δ hv hmv hΔ hlo hhi
  let U := fun z => diskHarmonicWeight N c (Real.exp (q+1)) z/g
  have hE : MeasurableSet {x : ℝ | v+Δ < Real.sqrt x} := measurableSet_lt measurable_const measurable_id.sqrt
  have hh := congrArg (fun μ : Measure ℝ => μ {x | v+Δ < Real.sqrt x})
    (exactExitRecordProduct_occupation_law N (torusDisk N c (Real.exp (q+2*q^γ))) m a b U)
  have hw : Measurable (fun ω : Fin m → WalkSample => ∑ i,
      weightedExitOccupation N (torusDisk N c (Real.exp (q+2*q^γ))) (a i) U (ω i)) :=
    Finset.measurable_sum _ fun i _ => (weightedExitOccupation_measurable N _ (a i) U).comp (measurable_pi_apply i)
  rw [Measure.map_apply (recordProductOccupation_measurable N m a U) hE,Measure.map_apply hw hE] at hh
  have he := congrArg ENNReal.toReal hh
  change (exactExitRecordProductLaw N (torusDisk N c (Real.exp (q+2*q^γ))) m a b).real _ =
    (exactExitProductLaw N (torusDisk N c (Real.exp (q+2*q^γ))) m a b).real
      {ω | v+Δ < Real.sqrt (harmonicExitBlockSum N c (Real.exp (q+1)) (Real.exp (q+2*q^γ)) m a ω)} at he
  exact he.le.trans (hq N c m a b hsmall ha hb v Δ hv hmv hΔ hlo hhi)

theorem exactExitRecordProduct_duration_event (N : Size) (D : Finset (Vertex N)) (m : ℕ)
    (a b : Fin m → Vertex N) (d : ℝ) :
    exactExitRecordProductLaw N D m a b {p | ∃ i, d < excursionRecordDuration (p i)} =
      exactExitProductLaw N D m a b {ω | ∃ i, d < finiteExitDuration N D (a i) (ω i)} := by
  have hE : MeasurableSet {p : Fin m → ℕ × WalkSample | ∃ i, d < excursionRecordDuration (p i)} := by
    simp only [Set.ofPred_exists]
    exact MeasurableSet.iUnion fun i => measurableSet_lt measurable_const
      (excursionRecordDuration_measurable.comp (measurable_pi_apply i))
  have hf : Measurable (fun ω : Fin m → WalkSample => fun i => finiteExitRecord N D (a i) (ω i)) :=
    measurable_pi_lambda _ fun i : Fin m => (finiteExitRecord_measurable N D (a i)).comp (measurable_pi_apply i)
  rw [← exactExitProduct_record_law,Measure.map_apply hf hE]
  congr 1
  ext ω
  simp only [Set.mem_preimage,Set.mem_ofPred_eq,← finiteExitDuration_eq_record]

theorem r6_record_coarse_duration (hWalk : WalkModelRegular) (γ : ℝ)
    (hγ : 0 < γ) (hγ1 : γ ≤ 1) :
    ∀ᶠ N : Size in atTop, ∀ c : Vertex N, ∀ m : ℕ, ∀ a b : Fin m → Vertex N, ∀ q : ℝ,
      (logSize N)^(16*γ) ≤ q → q ≤ logSize N-(logSize N)^(16*γ) → (m:ℝ) ≤ (logSize N)^4+1 →
      (∀ i, |periodicDistance (a i) c-Real.exp (q+q^γ)| ≤ 2) →
      (∀ i, diskExteriorNeighbor N c (Real.exp (q+2*q^γ)) (b i)) →
      exactExitRecordProductLaw N (torusDisk N c (Real.exp (q+2*q^γ))) m a b {p |
        (m:ℝ)*Real.exp (2*logSize N-(logSize N)^(16*γ)) < recordsDuration m p} ≤
        ENNReal.ofReal (Real.exp (-Real.exp ((logSize N)^(16*γ)/2))) := by
  filter_upwards [r6_coarse_unconditioned_duration hWalk γ hγ hγ1] with N hN
  intro c m a b q hq hqL hm ha hb
  have hbound : exactExitRecordProductLaw N (torusDisk N c (Real.exp (q+2*q^γ))) m a b
      {p | ∃ i, Real.exp (2*logSize N-(logSize N)^(16*γ)) < excursionRecordDuration (p i)} ≤
        ENNReal.ofReal (Real.exp (-Real.exp ((logSize N)^(16*γ)/2))) := by
    rw [exactExitRecordProduct_duration_event]
    exact hN c m a b q hq hqL hm ha hb
  exact (measure_mono (fun p hp => record_duration_sum_tail p _ (by simpa [recordsDuration] using hp))).trans hbound

end TorusCoverTime.Blocks.B
