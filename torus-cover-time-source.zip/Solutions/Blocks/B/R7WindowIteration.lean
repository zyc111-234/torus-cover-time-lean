import Solutions.Blocks.B.R7SquareRootConcentration

/-! The deterministic R7.6 window recurrence and R7.9 square-root estimate.
Applying the recurrence to physical loop windows still requires the actual
window-transfer and Gaussian-probe/coarea inputs. -/

noncomputable section
namespace TorusCoverTime.Blocks.B

theorem r7_window_iteration (a : ℕ → ℝ) (J : ℕ) (B ε C₀ p : ℝ)
    (hp : 0 ≤ p) (hp1 : p < 1) (hB : 0 ≤ B+ε)
    (hrec : ∀ j < J, a j ≤ B+p*a (j+1)+ε) (hterminal : a J ≤ C₀) :
    a 0 ≤ (B+ε)/(1-p)+C₀*p^J := by
  induction J generalizing a with
  | zero =>
    simp only [pow_zero, mul_one]
    exact hterminal.trans (le_add_of_nonneg_left (div_nonneg hB (by linarith)))
  | succ J ih =>
    have htail := ih (fun j => a (j+1))
      (fun j hj => hrec (j+1) (by omega)) hterminal
    have hfirst := hrec 0 (by omega)
    have hmul := mul_le_mul_of_nonneg_left htail hp
    have he : B+p*((B+ε)/(1-p)+C₀*p^J)+ε = (B+ε)/(1-p)+C₀*p^(J+1) := by
      rw [pow_succ]
      field_simp [ne_of_gt (sub_pos.mpr hp1)]
      <;> ring
    exact (hfirst.trans (by linarith)).trans_eq he

theorem r7_probe_sqrt_shift (q v Δ C : ℝ) (hq : 0 ≤ q) (hqv : q ≤ v)
    (hΔ : 0 ≤ Δ) (hC : 0 ≤ C) :
    Real.sqrt ((v+Δ)^2+C*q) ≤ v+Δ+C/2 := by
  apply Real.sqrt_le_iff.mpr
  refine ⟨by linarith, ?_⟩
  nlinarith [mul_nonneg hC (show 0 ≤ v+Δ-q by linarith), sq_nonneg C]

end TorusCoverTime.Blocks.B
