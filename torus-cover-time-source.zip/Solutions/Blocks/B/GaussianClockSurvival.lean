import Solutions.Blocks.B.GaussianClockIndependence
import Solutions.Blocks.C.C4.Base.PinnedSurvivalSmoothing

/-! The discrete affine killed-weight budget, starting at zero, for any exact
finite Gaussian clock path.  Killing is only at the finitely many coordinates. -/

noncomputable section
open MeasureTheory ProbabilityTheory Classical Set
open scoped ENNReal NNReal
namespace TorusCoverTime.Blocks.B.GaussianClockPath
variable {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
variable {n : ℕ} (W : GaussianClockPath μ n)

def survival (a : ℝ) (cut : Fin (n + 1)) : Set Ω :=
  {ω | ∀ i, i ≤ cut → W.path ω i ≤ a}

def survivalMoment (a C : ℝ) (cut : Fin (n + 1)) : ℝ≥0∞ :=
  ∫⁻ ω in W.survival a cut, ENNReal.ofReal (a - W.path ω cut + C) ∂μ

theorem survival_measurable (a : ℝ) (cut : Fin (n + 1)) : MeasurableSet (W.survival a cut) := by
  unfold survival
  rw [Set.ofPred_forall]
  apply MeasurableSet.iInter
  intro i
  by_cases hi : i ≤ cut
  · simpa only [hi, true_implies] using measurableSet_le (W.measurable_coord i) measurable_const
  · simp [hi]

theorem survival_antitone (a : ℝ) : Antitone (W.survival a) :=
  fun _ _ hij _ hω k hk => hω k (hk.trans hij)

theorem survivalMoment_zero (a C : ℝ) (ha : 0 ≤ a) :
    W.survivalMoment a C 0 = ENNReal.ofReal (a + C) := by
  have hs : W.survival a 0 = univ := by
    ext ω
    simp only [mem_univ, iff_true]
    intro i hi
    have he : i = 0 := le_antisymm hi (Fin.zero_le i)
    simpa only [he, W.start_zero] using ha
  simp only [survivalMoment, hs, W.start_zero, sub_zero, Measure.restrict_univ,
    lintegral_const, measure_univ, mul_one]

theorem survivalMoment_step (k : Fin n) (a C : ℝ)
    (hv : W.clock k.castSucc < W.clock k.succ)
    (hC : 2 * Real.sqrt (W.clock k.succ - W.clock k.castSucc) ≤ C) :
    W.survivalMoment a C k.succ ≤ W.survivalMoment a C k.castSucc := by
  let L := fun ω (i : {i : Fin (n + 1) // i ≤ k.castSucc}) => W.path ω i.val
  let G := fun ω => -(W.path ω k.succ - W.path ω k.castSucc)
  let S : Set ({i : Fin (n + 1) // i ≤ k.castSucc} → ℝ) := {f | ∀ i, f i ≤ a}
  let u := fun f : {i : Fin (n + 1) // i ≤ k.castSucc} → ℝ => a - f ⟨k.castSucc, le_rfl⟩
  have hidx : k.castSucc ≤ k.succ := by change k.val ≤ k.val + 1; omega
  have hL : Measurable L := by fun_prop
  have hG : Measurable G := by fun_prop
  have hu : Measurable u := by fun_prop
  have hS : MeasurableSet S := by
    change MeasurableSet {f : {i : Fin (n + 1) // i ≤ k.castSucc} → ℝ | ∀ i, f i ≤ a}
    rw [Set.ofPred_forall]
    exact MeasurableSet.iInter (fun i => measurableSet_le (measurable_pi_apply i) measurable_const)
  have hind : IndepFun L G μ := by
    simpa only [Function.comp_def, id_eq] using
      (W.past_indep_increment k.castSucc k.succ hidx).comp measurable_id measurable_neg
  have hLaw : HasLaw G (gaussianReal 0 (W.clock k.succ - W.clock k.castSucc).toNNReal) μ := by
    refine ⟨hG.aemeasurable, ?_⟩
    calc
      _ = (μ.map (fun ω => W.path ω k.succ - W.path ω k.castSucc)).map (fun z : ℝ => -z) :=
        (Measure.map_map measurable_neg
          (show Measurable (fun ω => W.path ω k.succ - W.path ω k.castSucc) by fun_prop)).symm
      _ = _ := by rw [(W.increment_hasLaw k.castSucc k.succ hidx).map_eq, gaussianReal_map_neg, neg_zero]
  have hvpos := sub_pos.mpr hv
  have hCn : 2 * Real.sqrt ((W.clock k.succ - W.clock k.castSucc).toNNReal : ℝ) ≤ C := by
    rwa [Real.coe_toNNReal _ hvpos.le]
  have h := Blocks.C.C4.independent_killed_weight_le μ L G hL hG hind
    (Real.toNNReal_pos.mpr hvpos).ne' hLaw u hu S hS
    (fun f hf => sub_nonneg.mpr (hf ⟨k.castSucc, le_rfl⟩)) C hCn
  have hprev : W.survival a k.castSucc = L ⁻¹' S := by
    ext ω
    exact ⟨fun h i => h i.val i.property, fun h i hi => h ⟨i, hi⟩⟩
  have hnext : W.survival a k.succ = (L ⁻¹' S) ∩ {ω | W.path ω k.succ ≤ a} := by
    ext ω
    constructor
    · intro hω
      exact ⟨fun i => hω i.val (i.property.trans hidx), hω k.succ le_rfl⟩
    · rintro ⟨hp, hn⟩ i hi
      by_cases hik : i ≤ k.castSucc
      · exact hp ⟨i, hik⟩
      · have he : i = k.succ := by
          change i.val ≤ k.val + 1 at hi
          change ¬ i.val ≤ k.val at hik
          apply Fin.ext
          change i.val = k.val + 1
          omega
        rw [he]
        exact hn
  have he (ω : Ω) : u (L ω) + G ω = a - W.path ω k.succ := by dsimp [u, L, G]; ring
  have hm : W.survivalMoment a C k.succ =
      ∫⁻ ω in L ⁻¹' S, Blocks.C.C4.nonnegativeAffineWeight C (u (L ω) + G ω) ∂μ := by
    unfold survivalMoment
    rw [hnext, ← lintegral_indicator ((hL hS).inter (measurableSet_le (W.measurable_coord _) measurable_const)),
      ← lintegral_indicator (hL hS)]
    apply lintegral_congr
    intro ω
    by_cases hp : ω ∈ L ⁻¹' S <;> by_cases hn : W.path ω k.succ ≤ a <;>
      simp [Blocks.C.C4.nonnegativeAffineWeight, hp, hn, sub_nonneg, he]
  rw [hm]
  change _ ≤ ∫⁻ ω in W.survival a k.castSucc, _ ∂μ
  rw [hprev]
  exact h

theorem survivalMoment_le (a C : ℝ) (ha : 0 ≤ a)
    (hv : ∀ k : Fin n, W.clock k.castSucc < W.clock k.succ)
    (hC : ∀ k : Fin n, 2 * Real.sqrt (W.clock k.succ - W.clock k.castSucc) ≤ C)
    (i : Fin (n + 1)) : W.survivalMoment a C i ≤ ENNReal.ofReal (a + C) := by
  induction i using Fin.induction with
  | zero => rw [W.survivalMoment_zero a C ha]
  | succ k ih => exact (W.survivalMoment_step k a C (hv k) (hC k)).trans ih

end TorusCoverTime.Blocks.B.GaussianClockPath
