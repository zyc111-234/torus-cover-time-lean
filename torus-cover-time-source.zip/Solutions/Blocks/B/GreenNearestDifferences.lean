import Solutions.Blocks.B.AnnularDecay
import Solutions.Blocks.B.DyadicDecay

/-! First and second nearest-neighbor Green differences, uniformly on all finite tori. -/

noncomputable section
open Classical
open scoped BigOperators
namespace TorusCoverTime.Blocks.B

lemma periodicTransform_finset_sum {ι : Type*} (N : Size) (s : Finset ι)
    (a : ι → Vertex N → ℂ) (z : Vertex N) :
    periodicTransform N (fun k => ∑ j ∈ s, a j k) z = ∑ j ∈ s, periodicTransform N (a j) z := by
  simp only [periodicTransform, Finset.sum_mul]
  rw [Finset.sum_comm]

lemma greenStepArray_spatial_decay (ds : List (Fin 4)) (hs : ds.length = 1 ∨ ds.length = 2) :
    ∃ C : ℝ, 0 < C ∧ ∀ N : Size, ∀ z : Vertex N, 0 < periodicDistance z 0 →
      ‖periodicTransform N (greenStepArray N ds) z‖ ≤ C / periodicDistance z 0 ^ ds.length := by
  obtain ⟨C, hC, hb⟩ := annularArray_spatial_envelope ds
  refine ⟨4 * C, by positivity, ?_⟩
  intro N z hd
  have hN : 0 < (N.val : ℝ) := lt_trans zero_lt_one (size_real_gt_one N)
  obtain ⟨J, hJ⟩ := greenStepArray_finite_partition N ds
  have hf := funext hJ
  rw [hf, periodicTransform_finset_sum]
  calc
    _ ≤ ∑ j ∈ Finset.range (J + 1), ‖periodicTransform N (annularArray N (dyadicFrequencyRadius j) ds) z‖ :=
      norm_sum_le _ _
    _ ≤ ∑ j ∈ Finset.range (J + 1), C * (dyadicFrequencyRadius j / N.val) ^ ds.length *
        min 1 (1 / (dyadicFrequencyRadius j / N.val * periodicDistance z 0) ^ 3) :=
      Finset.sum_le_sum (fun j _ => hb N _ (dyadicFrequencyRadius_lower j) z hd)
    _ = C * ∑ j ∈ Finset.range (J + 1), ((1 / (2 * N.val)) * (2 : ℝ) ^ j) ^ ds.length *
        min 1 (1 / ((1 / (2 * N.val)) * (2 : ℝ) ^ j * periodicDistance z 0) ^ 3) := by
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro j _
      rw [show dyadicFrequencyRadius j / N.val = (1 / (2 * N.val)) * (2 : ℝ) ^ j by
        dsimp [dyadicFrequencyRadius]; ring]
      ring
    _ ≤ C * (4 / periodicDistance z 0 ^ ds.length) :=
      mul_le_mul_of_nonneg_left (dyadic_spatial_envelope_sum _ _ (by positivity) hd _ hs (J + 1)) hC.le
    _ = _ := by ring

lemma green_nearest_differences :
    ∃ C : ℝ, 0 < C ∧ ∀ N : Size, ∀ z : Vertex N, 0 < periodicDistance z 0 → ∀ d d' : Fin 4,
      |greenKernel N (z + direction N d) 0 - greenKernel N z 0| ≤ C / periodicDistance z 0 ∧
      |greenKernel N (z + direction N d + direction N d') 0 -
        greenKernel N (z + direction N d) 0 - greenKernel N (z + direction N d') 0 + greenKernel N z 0| ≤
        C / periodicDistance z 0 ^ 2 := by
  have h1 (d : Fin 4) := greenStepArray_spatial_decay [d] (by simp)
  have h2 (d d' : Fin 4) := greenStepArray_spatial_decay [d, d'] (by simp)
  choose C1 hC1 hb1 using h1
  choose C2 hC2 hb2 using h2
  let C := (∑ d : Fin 4, C1 d) + ∑ d : Fin 4, ∑ d' : Fin 4, C2 d d'
  have hpos1 : 0 < ∑ d : Fin 4, C1 d := Finset.sum_pos (fun d _ => hC1 d) Finset.univ_nonempty
  have hnonneg2 : 0 ≤ ∑ d : Fin 4, ∑ d' : Fin 4, C2 d d' :=
    Finset.sum_nonneg fun d _ => Finset.sum_nonneg fun d' _ => (hC2 d d').le
  have hc1 (d : Fin 4) : C1 d ≤ C := by
    have h := Finset.single_le_sum (fun i _ => (hC1 i).le) (Finset.mem_univ d)
    dsimp [C]
    linarith
  have hc2 (d d' : Fin 4) : C2 d d' ≤ C := by
    have hi := Finset.single_le_sum (fun j _ => (hC2 d j).le) (Finset.mem_univ d')
    have hj := Finset.single_le_sum (s := Finset.univ) (a := d)
      (f := fun i => ∑ j : Fin 4, C2 i j)
      (fun i _ => Finset.sum_nonneg fun j _ => (hC2 i j).le) (Finset.mem_univ d)
    dsimp [C]
    linarith
  refine ⟨C, add_pos_of_pos_of_nonneg hpos1 hnonneg2, ?_⟩
  intro N z hd d d'
  constructor
  · rw [green_difference_transform]
    have h := hb1 d N z hd
    rw [show greenStepArray N [d] =
      (fun k => greenMultiplier N k * (finiteCharacter N k (direction N d) - 1)) by
        funext k; simp [greenStepArray]] at h
    simp only [List.length_cons, List.length_nil, zero_add, pow_one] at h
    exact (Complex.abs_re_le_norm _).trans (h.trans (div_le_div_of_nonneg_right (hc1 d) hd.le))
  · rw [green_second_difference_transform]
    have h := hb2 d d' N z hd
    rw [show greenStepArray N [d, d'] =
      (fun k => greenMultiplier N k * (finiteCharacter N k (direction N d) - 1) *
        (finiteCharacter N k (direction N d') - 1)) by
          funext k; simp [greenStepArray, mul_assoc]] at h
    change ‖periodicTransform N _ z‖ ≤ C2 d d' / periodicDistance z 0 ^ 2 at h
    exact (Complex.abs_re_le_norm _).trans (h.trans (div_le_div_of_nonneg_right (hc2 d d') (by positivity)))

end TorusCoverTime.Blocks.B
