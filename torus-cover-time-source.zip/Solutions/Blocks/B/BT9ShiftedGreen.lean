import Solutions.Blocks.B.R8SingleParameters

/-! Sharp entrance Green value at the displaced second site, using the
already proved second-variable difference with the finite-volume correction cancelled. -/
noncomputable section
open Filter Classical
namespace TorusCoverTime.Blocks.B

def bt9EntranceConstant : ℝ := r7GreenCenterConstant+64*r7GreenDifferenceConstant/g

theorem bt9EntranceConstant_pos : 0 < bt9EntranceConstant := by
  have := r7GreenCenterConstant_pos
  have := r7GreenDifferenceConstant_pos
  have hg : 0 < g := by unfold g; positivity
  have hC := r7GreenDifferenceConstant_pos
  unfold bt9EntranceConstant
  positivity

theorem bt9_shifted_green_explicit (N : Size) (c a b z : Vertex N) (q h : ℝ)
    (hq : 64 ≤ q) (hh : Real.log 8 ≤ h) (hhq : h ≤ q)
    (hsmall : 2*(Real.exp (q+2*h)+1) < N.val)
    (ha : |periodicDistance a c-Real.exp (q+h)| ≤ 2)
    (hb : diskExteriorNeighbor N c (Real.exp (q+2*h)) b)
    (hz : z ∈ torusDisk N c (Real.exp q)) :
    |diskGreen N c (Real.exp (q+2*h)) a z/g-h| ≤
      bt9EntranceConstant*Real.exp (-h/4) := by
  have hg : 0 < g := by unfold g; positivity
  have hC := r7GreenDifferenceConstant_pos
  have hh0 : 0 ≤ h := (Real.log_nonneg (by norm_num : (1:ℝ) ≤ 8)).trans hh
  have hgeom := r6_green_geometry N c a c q h (by linarith) hh ha
    ((mem_torusDisk N c c _).mpr (by rw [periodicDistance_self_zero]; positivity))
  have hE : 8*Real.exp q ≤ Real.exp (q+h) := by
    have hh8 : 8 ≤ Real.exp h := by
      simpa only [Real.exp_log (by norm_num : (0:ℝ) < 8)] using Real.exp_le_exp.mpr hh
    rw [Real.exp_add]
    nlinarith [Real.exp_pos q]
  have hzc := (mem_torusDisk N c z _).mp hz
  have hρR : Real.exp (q+h)/2 ≤ Real.exp (q+2*h) := by
    have := Real.exp_le_exp.mpr (show q+h ≤ q+2*h by linarith)
    linarith [Real.exp_pos (q+h)]
  have hd := diskGreen_second_difference_of_nearest r7GreenDifferenceConstant
    r7GreenDifferenceConstant_pos r7GreenDifferenceConstant_control N c _ (Real.exp (q+h)/2)
    (half_pos (Real.exp_pos _)) hρR hsmall a z hgeom.2.1 hgeom.2.2.2.2.2.1 (by linarith)
  have hdb : |diskGreen N c (Real.exp (q+2*h)) a z/g-
      diskGreen N c (Real.exp (q+2*h)) a c/g| ≤
      (64*r7GreenDifferenceConstant/g)*Real.exp (-h/4) := by
    rw [← sub_div, abs_div, abs_of_pos hg]
    apply (div_le_div_of_nonneg_right hd hg.le).trans
    calc
      _ ≤ (32*r7GreenDifferenceConstant*Real.exp q/(Real.exp (q+h)/2))/g := by
        gcongr
      _ = (64*r7GreenDifferenceConstant/g)*Real.exp (-h) := by
        rw [show -h = q-(q+h) by ring, Real.exp_sub]
        ring
      _ ≤ _ := mul_le_mul_of_nonneg_left (Real.exp_le_exp.mpr (by linarith)) (by positivity)
  have hc := r7_green_center_explicit N c a b q h hq hh hhq hsmall ha hb
  exact (abs_sub_le _ _ _).trans ((add_le_add hdb hc).trans_eq (by unfold bt9EntranceConstant; ring))

theorem bt9_shifted_green (γ : ℝ) (hγ : 0 < γ) (hγ1 : γ < 1) :
    ∀ᶠ q : ℝ in atTop, ∀ N : Size, ∀ c a b z : Vertex N,
      2*(Real.exp (q+2*q^γ)+1) < N.val →
      |periodicDistance a c-Real.exp (q+q^γ)| ≤ 2 →
      diskExteriorNeighbor N c (Real.exp (q+2*q^γ)) b →
      z ∈ torusDisk N c (Real.exp q) →
      |diskGreen N c (Real.exp (q+2*q^γ)) a z/g-q^γ| ≤ 1/q := by
  have hdec := (polynomial_times_stretched_exp_tendsto_zero γ (1/4) 1 hγ
    (by norm_num)).const_mul bt9EntranceConstant
  simp only [mul_zero] at hdec
  have hsmall := hdec.eventually_le_const (by norm_num : (0:ℝ) < 1)
  filter_upwards [eventually_ge_atTop (64:ℝ),
    (tendsto_rpow_atTop hγ).eventually_ge_atTop (Real.log 8), hsmall]
    with q hq hh he
  intro N c a b z hN ha hb hz
  have hq0 : 0 < q := by linarith
  apply (bt9_shifted_green_explicit N c a b z q (q^γ) hq hh
    (by simpa only [Real.rpow_one] using
      Real.rpow_le_rpow_of_exponent_le (show 1 ≤ q by linarith) hγ1.le) hN ha hb hz).trans
  apply (le_div_iff₀ hq0).mpr
  simp only [Real.rpow_one] at he
  convert he using 1 <;> ring

end TorusCoverTime.Blocks.B
