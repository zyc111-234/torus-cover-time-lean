import Solutions.Blocks.B.FourierOccupation

/-! Jump-count events and the initial exponential waiting-time law.
The full Poisson law is not yet asserted here. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter
open scoped ENNReal Topology

namespace TorusCoverTime.Blocks.B

lemma jumpCount_eq_iff_on_regular_sample {ω : WalkSample}
    (hpos : ∀ j, 0 < (ω j).1) (hNonexplosive : Tendsto (jumpTime ω) atTop atTop)
    (t : ℝ) (ht : 0 ≤ t) (n : ℕ) :
    jumpCount ω t = n ↔ jumpTime ω n ≤ t ∧ t < jumpTime ω (n + 1) := by
  classical
  obtain ⟨j, hj⟩ := (hNonexplosive.eventually (eventually_gt_atTop t)).exists
  have hmono := jumpTime_strictMono hpos
  have hex : ∃ k : ℕ, t < jumpTime ω (k + 1) :=
    ⟨j, hj.trans (hmono (Nat.lt_succ_self j))⟩
  constructor
  · intro heq
    refine ⟨?_, ?_⟩
    · simpa only [heq] using jumpTime_jumpCount_le hpos hNonexplosive ht
    · have h := Nat.find_spec hex
      rw [jumpCount, dif_pos hex] at heq
      simpa only [heq] using h
  · rintro ⟨hlo, hhi⟩
    rw [jumpCount, dif_pos hex]
    exact (Nat.find_eq_iff hex).mpr ⟨hhi, fun m hm =>
      not_lt.mpr ((hmono.monotone (Nat.succ_le_of_lt hm)).trans hlo)⟩

lemma jumpCount_event_ae (hWalk : WalkModelRegular) (t : ℝ) (ht : 0 ≤ t) (n : ℕ) :
    ∀ᵐ ω ∂walkLaw,
      jumpCount ω t = n ↔ jumpTime ω n ≤ t ∧ t < jumpTime ω (n + 1) := by
  filter_upwards [hWalk.1] with ω hω
  exact jumpCount_eq_iff_on_regular_sample hω.1 hω.2 t ht n

lemma holding_coordinate_law (j : ℕ) :
    walkLaw.map (fun ω : WalkSample => (ω j).1) = holdingLaw := by
  change walkLaw.map (Prod.fst ∘ (fun ω : WalkSample => ω j)) = _
  rw [← Measure.map_map measurable_fst (measurable_pi_apply j), walkLaw,
    Measure.infinitePi_map_eval, stepLaw, Measure.map_fst_prod]
  simp

lemma holding_tail_probability (j : ℕ) (t : ℝ) (ht : 0 ≤ t) :
    (walkLaw {ω : WalkSample | t < (ω j).1}).toReal = Real.exp (-t) := by
  have hm : Measurable (fun ω : WalkSample => (ω j).1) := (measurable_pi_apply j).fst
  have hmap := congrArg (fun μ : Measure ℝ => μ.real (Set.Ioi t)) (holding_coordinate_law j)
  rw [map_measureReal_apply hm measurableSet_Ioi] at hmap
  change walkLaw.real {ω : WalkSample | t < (ω j).1} = holdingLaw.real (Set.Ioi t) at hmap
  have hCDF : holdingLaw.real (Set.Iic t) = 1 - Real.exp (-t) := by
    let : IsProbabilityMeasure (expMeasure 1) := isProbabilityMeasure_expMeasure (by norm_num)
    have h := cdf_expMeasure_eq (by norm_num : (0 : ℝ) < 1) t
    rw [cdf_eq_real] at h
    simpa only [holdingLaw, if_pos ht, one_mul] using h
  change walkLaw.real {ω : WalkSample | t < (ω j).1} = _
  rw [hmap, ← Set.compl_Iic, probReal_compl_eq_one_sub measurableSet_Iic, hCDF]
  ring

lemma zero_jump_probability (hWalk : WalkModelRegular) (t : ℝ) (ht : 0 ≤ t) :
    (walkLaw {ω | jumpCount ω t = 0}).toReal = Real.exp (-t) := by
  have heq : {ω : WalkSample | jumpCount ω t = 0} =ᵐ[walkLaw]
      {ω : WalkSample | t < (ω 0).1} := by
    filter_upwards [hWalk.1] with ω hω
    change (jumpCount ω t = 0) = (t < (ω 0).1)
    apply propext
    have h := jumpCount_eq_iff_on_regular_sample hω.1 hω.2 t ht 0
    simpa [jumpTime, holdingTime, ht, max_eq_left (hω.1 0).le] using h
  exact (measureReal_congr heq).trans (holding_tail_probability 0 t ht)

end TorusCoverTime.Blocks.B
