import Solutions.Blocks.B.LowHarmonicWindow
import Solutions.Blocks.B.R7WindowIteration

/-! R7's physical-window recurrence with its low term expressed using actual
harmonic local time. All integrals are finite, so the real-valued iteration
applies without discarding any infinite-valued exceptional expression. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

theorem path_window_lintegral_le_length (F : WalkSample → ℝ → ℝ≥0∞) (l r : ℝ)
    (hF : ∀ ω t, F ω t ≤ if t ∈ Icc l r then 1 else 0) :
    (∫⁻ ω, ∫⁻ t in Ioi (0 : ℝ), F ω t ∂volume ∂walkLaw) ≤ ENNReal.ofReal (r-l) := by
  calc
    _ ≤ ∫⁻ ω, ∫⁻ t in Ioi (0 : ℝ), (if t ∈ Icc l r then (1 : ℝ≥0∞) else 0) ∂volume ∂walkLaw :=
      lintegral_mono (fun ω => lintegral_mono (hF ω))
    _ ≤ ∫⁻ _ : WalkSample, ∫⁻ t : ℝ, (if t ∈ Icc l r then (1 : ℝ≥0∞) else 0) ∂volume ∂walkLaw :=
      lintegral_mono (fun _ => lintegral_mono' Measure.restrict_le_self le_rfl)
    _ = _ := by
      have he : (fun t : ℝ => if t ∈ Icc l r then (1 : ℝ≥0∞) else 0) = (Icc l r).indicator (fun _ => 1) := by
        funext t
        simp [Set.indicator]
      rw [he,lintegral_indicator measurableSet_Icc]
      simp [Real.volume_Icc]

theorem countedLoopWindowMass_le_length (N : Size) (I O : Finset (Vertex N)) (root : Vertex N)
    (M : ℕ) (l r : ℝ) : countedLoopWindowMass N I O root M l r ≤ ENNReal.ofReal (r-l) := by
  apply path_window_lintegral_le_length
  intro ω t
  split_ifs <;> simp_all

theorem lowHarmonicLoopWindowMass_le_length (N : Size) (c root : Vertex N) (q a l r : ℝ) :
    lowHarmonicLoopWindowMass N c root q a l r ≤ ENNReal.ofReal (r-l) := by
  apply path_window_lintegral_le_length
  intro ω t
  split_ifs <;> simp_all

theorem countedLoopWindowMass_ne_top (N : Size) (I O : Finset (Vertex N)) (root : Vertex N)
    (M : ℕ) (l r : ℝ) : countedLoopWindowMass N I O root M l r ≠ ∞ :=
  ne_of_lt ((countedLoopWindowMass_le_length N I O root M l r).trans_lt ENNReal.ofReal_lt_top)

theorem lowHarmonicLoopWindowMass_ne_top (N : Size) (c root : Vertex N) (q a l r : ℝ) :
    lowHarmonicLoopWindowMass N c root q a l r ≠ ∞ :=
  ne_of_lt ((lowHarmonicLoopWindowMass_le_length N c root q a l r).trans_lt ENNReal.ofReal_lt_top)

theorem r7_physical_window_recurrence (hWalk : WalkModelRegular) (γ : ℝ) (hγ : 0 < γ) (hγ1 : γ ≤ 1) :
    ∀ᶠ N : Size in atTop, ∀ c root : Vertex N, ∀ M : ℕ, ∀ q : ℝ,
      (logSize N)^(16*γ) ≤ q → q ≤ logSize N-(logSize N)^(16*γ) → (M:ℝ) ≤ (logSize N)^4+1 →
      root ∉ torusDisk N c (Real.exp (q+2*q^γ)) →
      ∀ v Δ : ℝ, 0 ≤ v → (M:ℝ)*q^γ ≤ v^2 → 0 ≤ Δ →
      2*r7MeanConstant*Real.exp (-r7MeanExponent*q^γ)*v ≤ Δ → Δ ≤ v → ∀ l r : ℝ,
      let I := torusDisk N c (Real.exp (q+q^γ))
      let O := torusDisk N c (Real.exp (q+2*q^γ))
      let d := (M:ℝ)*Real.exp (2*logSize N-(logSize N)^(16*γ))
      countedLoopWindowMass N I O root M l r ≤ lowHarmonicLoopWindowMass N c root q (v+Δ) l r +
        2*ENNReal.ofReal (2*Real.exp (-(r7ConcentrationConstant/4)*Δ^2/q^γ)) *
          countedLoopWindowMass N I O root M (l-d) (r+d) +
        ((M+1:ℕ):ℝ≥0∞)*ENNReal.ofReal (r-l)*ENNReal.ofReal (Real.exp (-Real.exp ((logSize N)^(16*γ)/2))) := by
  have hQ := (tendsto_rpow_atTop (by positivity : 0 < 16*γ)).comp blockB_logSize_tendsto
  have hW := (tendsto_rpow_atTop hγ).comp hQ
  filter_upwards [r7_counted_window_recurrence hWalk γ hγ hγ1,hW.eventually_ge_atTop 2] with N hN hlarge
  intro c root M q hq hqL hM hr v Δ hv hMv hΔ hlo hhi l r
  dsimp only
  have hq0 : 0 ≤ q := (Real.rpow_nonneg (logSize_pos N).le _).trans hq
  have hw : 2 ≤ q^γ := hlarge.trans (Real.rpow_le_rpow
    (Real.rpow_nonneg (logSize_pos N).le _) hq hγ.le)
  have hIO : torusDisk N c (Real.exp (q+q^γ)) ⊆ torusDisk N c (Real.exp (q+2*q^γ)) := by
    intro z hz
    exact (mem_torusDisk N c z _).mpr (((mem_torusDisk N c z _).mp hz).trans_le
      (Real.exp_le_exp.mpr (by linarith)))
  have hlow := lowWordWindowSum_le_harmonic N c root _ _ hIO
    (torusDisk_nonempty N c _ (Real.exp_pos _)) hr M q v Δ l r
    (r7_harmonicWeight_supported_in_traversal_inner N c q (q^γ) hq0 hw)
  exact (hN c root M q hq hqL hM hr v Δ hv hMv hΔ hlo hhi l r).trans
    (add_le_add (add_le_add hlow le_rfl) le_rfl)

theorem finite_window_recurrence_real (a b c : ℝ≥0∞) (p ε : ℝ)
    (ha : a ≠ ∞) (hb : b ≠ ∞) (hc : c ≠ ∞) (hp : 0 ≤ p) (hε : 0 ≤ ε)
    (h : a ≤ b+ENNReal.ofReal p*c+ENNReal.ofReal ε) :
    a.toReal ≤ b.toReal+p*c.toReal+ε := by
  have ht : b+ENNReal.ofReal p*c+ENNReal.ofReal ε ≠ ∞ := by finiteness
  have hh := ENNReal.toReal_mono ht h
  rw [ENNReal.toReal_add (by finiteness) ENNReal.ofReal_ne_top,
    ENNReal.toReal_add hb (by finiteness),ENNReal.toReal_mul,
    ENNReal.toReal_ofReal hp,ENNReal.toReal_ofReal hε] at hh
  exact hh

theorem physical_window_iteration (N : Size) (I O : Finset (Vertex N)) (root : Vertex N)
    (M J : ℕ) (l r d B ε p : ℝ) (hd : 0 ≤ d) (hlr : l ≤ r)
    (hp : 0 ≤ p) (hp1 : p < 1) (hB : 0 ≤ B) (hε : 0 ≤ ε)
    (hrec : ∀ j < J,
      countedLoopWindowMass N I O root M (l-(j:ℝ)*d) (r+(j:ℝ)*d) ≤ ENNReal.ofReal B +
        ENNReal.ofReal p * countedLoopWindowMass N I O root M (l-((j+1:ℕ):ℝ)*d) (r+((j+1:ℕ):ℝ)*d) +
          ENNReal.ofReal ε) :
    (countedLoopWindowMass N I O root M l r).toReal ≤
      (B+ε)/(1-p)+(r-l+2*(J:ℝ)*d)*p^J := by
  let a := fun j : ℕ => (countedLoopWindowMass N I O root M (l-(j:ℝ)*d) (r+(j:ℝ)*d)).toReal
  have ha (j : ℕ) : countedLoopWindowMass N I O root M (l-(j:ℝ)*d) (r+(j:ℝ)*d) ≠ ∞ :=
    countedLoopWindowMass_ne_top N I O root M _ _
  have hstep (j : ℕ) (hj : j < J) : a j ≤ B+p*a (j+1)+ε := by
    simpa only [ENNReal.toReal_ofReal hB] using
      finite_window_recurrence_real _ _ _ p ε (ha j) ENNReal.ofReal_ne_top (ha (j+1)) hp hε (hrec j hj)
  have hterminal : a J ≤ r-l+2*(J:ℝ)*d := by
    have hh := ENNReal.toReal_mono ENNReal.ofReal_ne_top
      (countedLoopWindowMass_le_length N I O root M (l-(J:ℝ)*d) (r+(J:ℝ)*d))
    rw [ENNReal.toReal_ofReal (by nlinarith [mul_nonneg (Nat.cast_nonneg J) hd])] at hh
    exact hh.trans_eq (by ring)
  have hh := r7_window_iteration a J B ε _ p hp hp1 (add_nonneg hB hε) hstep hterminal
  simpa only [a,Nat.cast_zero,zero_mul,sub_zero,add_zero] using hh

end TorusCoverTime.Blocks.B
