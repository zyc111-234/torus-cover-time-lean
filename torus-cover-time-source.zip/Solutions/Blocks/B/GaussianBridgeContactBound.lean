import Solutions.Blocks.B.GaussianBridgeMiddleContact
import Solutions.Blocks.B.GaussianBridgeSurvival

/-! B.26 for every nonempty middle range, including r=1,2 and bridges
of length two. Constants depend only on the variance-table upper bound
after normalizing its lower bound to one. -/

noncomputable section
open MeasureTheory ProbabilityTheory Set
open scoped ENNReal
namespace TorusCoverTime.Blocks.B

def bridgeContactConstant (U : ℝ) : ℝ := 32*1024^2*(bridgeDensityConstant U+1)

theorem bridgeContactConstant_bounds (U : ℝ) :
    32 ≤ bridgeContactConstant U ∧ 2048*bridgeDensityConstant U ≤ bridgeContactConstant U ∧
      32*1024^2*bridgeDensityConstant U ≤ bridgeContactConstant U := by
  have hh : 0 ≤ bridgeDensityConstant U := by unfold bridgeDensityConstant; positivity
  unfold bridgeContactConstant
  constructor
  · nlinarith
  constructor <;> nlinarith

namespace GaussianClockPath
variable {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
variable {n : ℕ} (W : GaussianClockPath μ n)

theorem bridge_middle_contact_bound {U : ℝ} (h : W.ClockBounds U)
    (r : ℕ) (hr : 1 ≤ r) (hrn : 2*r ≤ n) (H b : ℝ) (hH : 0 ≤ H) (hb : 0 ≤ b) :
    μ (W.middleContact H b r) ≤ ENNReal.ofReal
      (bridgeContactConstant U*(H+bridgeBarrierPadding U)^2*(b+bridgeBarrierPadding U)^3 /
        ((n : ℝ)*Real.sqrt r)) := by
  have hp := bridgeBarrierPadding_ge_two U
  have hC := bridgeContactConstant_bounds U
  have hC0 : 0 ≤ bridgeContactConstant U := by linarith [hC.1]
  have hD : 0 ≤ bridgeDensityConstant U := by unfold bridgeDensityConstant; positivity
  have hh1 : 1 ≤ (H+bridgeBarrierPadding U)^2 := by nlinarith
  have hb1 : 1 ≤ (b+bridgeBarrierPadding U)^3 := by
    exact one_le_pow₀ (by linarith)
  have hn0 : (0 : ℝ)<n := by exact_mod_cast (show 0<n by omega)
  have hr0 : (0 : ℝ)<r := by exact_mod_cast (show 0<r by omega)
  by_cases hr3 : 3 ≤ r
  · refine (W.bridge_middle_contact_ge_three h r hr3 hrn H b hH hb).trans (ENNReal.ofReal_le_ofReal ?_)
    apply div_le_div_of_nonneg_right _ (by positivity)
    calc
      _ = (32*1024^2*bridgeDensityConstant U)*(H+bridgeBarrierPadding U)^2*(b+bridgeBarrierPadding U)^3 := by
        unfold bridgeContactCoefficient
        ring
      _ ≤ _ := mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right hC.2.2 (sq_nonneg _)) (by positivity)
  by_cases hn3 : 3 ≤ n
  · have hs : Real.sqrt (r : ℝ) ≤ 2 := by
      have hrr : (r : ℝ) ≤ 2 := by exact_mod_cast (show r≤2 by omega)
      nlinarith [Real.sq_sqrt hr0.le,Real.sqrt_nonneg (r : ℝ)]
    have hcoef : 1024*bridgeDensityConstant U*Real.sqrt r ≤ bridgeContactConstant U*(b+bridgeBarrierPadding U)^3 := by
      calc
        _ ≤ 1024*bridgeDensityConstant U*2 := mul_le_mul_of_nonneg_left hs (by positivity)
        _ ≤ bridgeContactConstant U := by nlinarith [hC.2.1]
        _ ≤ _ := le_mul_of_one_le_right hC0 hb1
    refine ((measure_mono (show W.middleContact H b r ⊆ {ω | ∀ i, W.bridge ω i ≤ H} from fun _ hω => hω.1)).trans
      (W.bridge_survival_le h hn3 H hH)).trans (ENNReal.ofReal_le_ofReal ?_)
    calc
      _ = (1024*bridgeDensityConstant U*Real.sqrt r)*(H+bridgeBarrierPadding U)^2/((n : ℝ)*Real.sqrt r) := by
        have hs0 := (Real.sqrt_pos.mpr hr0).ne'
        field_simp
      _ ≤ (bridgeContactConstant U*(b+bridgeBarrierPadding U)^3)*(H+bridgeBarrierPadding U)^2/((n : ℝ)*Real.sqrt r) :=
        div_le_div_of_nonneg_right (mul_le_mul_of_nonneg_right hcoef (sq_nonneg _)) (by positivity)
      _ = _ := by ring
  · have hn2 : n=2 := by omega
    have hr1 : r=1 := by omega
    have hbig : 2 ≤ bridgeContactConstant U*(H+bridgeBarrierPadding U)^2*(b+bridgeBarrierPadding U)^3 := by
      calc
        2 ≤ bridgeContactConstant U := by linarith [hC.1]
        _ ≤ bridgeContactConstant U*(H+bridgeBarrierPadding U)^2 := le_mul_of_one_le_right hC0 hh1
        _ ≤ _ := le_mul_of_one_le_right (mul_nonneg hC0 (sq_nonneg _)) hb1
    calc
      _ ≤ 1 := by simpa only [measure_univ] using (measure_mono (μ := μ) (Set.subset_univ (W.middleContact H b r)))
      _ = ENNReal.ofReal (1 : ℝ) := by simp
      _ ≤ _ := by
        apply ENNReal.ofReal_le_ofReal
        rw [hn2,hr1]
        norm_num only [Nat.cast_ofNat,Real.sqrt_one,mul_one]
        linarith

end GaussianClockPath
end TorusCoverTime.Blocks.B
