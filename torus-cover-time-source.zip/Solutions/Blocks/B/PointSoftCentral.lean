import Solutions.Blocks.B.PointSoftProbability
import Solutions.Blocks.B.PointSoftScale

/-! The sharp single-site, specified-endpoint estimate B.6 in every bounded
central window (in fact uniformly for every later physical time). -/
noncomputable section
open MeasureTheory Filter Set Classical
open scoped ENNReal Topology BigOperators
namespace TorusCoverTime.Blocks.B

def pointSoftConstant (u H : ℝ) : ℝ := 2*Real.exp (u+pointSoftExponentConstant H)

def pointSoftJointBound (N : Size) (u H : ℝ) : ℝ :=
  pointSoftConstant u H*(logSize N)^(3/2:ℝ)/(vertexCount N)^2

theorem pointSoftConstant_pos (u H : ℝ) : 0 < pointSoftConstant u H := by
  unfold pointSoftConstant
  positivity

theorem pointSoftJointBound_nonneg (N : Size) (u H : ℝ) : 0 ≤ pointSoftJointBound N u H := by
  have := logSize_pos N
  have := pointSoftConstant_pos u H
  unfold pointSoftJointBound
  positivity

theorem point_soft_joint_central (hWalk : WalkModelRegular) (u H : ℝ) (hH : 0 ≤ H) :
    ∀ᶠ N : Size in atTop, ∀ c a b : Vertex N, ∀ t : ℝ,
      phaseACenter N-H*timeScale N ≤ t →
      walkLaw.real {ω | localTime N a ω t c ≤ u ∧ walk N a ω t = b} ≤ pointSoftJointBound N u H := by
  filter_upwards [point_soft_joint_after_mixing hWalk,point_soft_phaseA_rate_eventually H hH] with N hmix htime
  intro c a b t ht
  obtain ⟨hmt,he⟩ := htime t ht
  apply (hmix.2 c a b t u hmt).trans
  have h := mul_le_mul_of_nonneg_left (Real.exp_le_exp.mpr (neg_le_neg he))
    (show 0 ≤ Real.exp u*(2/vertexCount N) by have := vertexCount_pos N; positivity)
  simp only [neg_mul]
  apply h.trans_eq
  rw [point_soft_exp_center]
  unfold pointSoftJointBound pointSoftConstant
  rw [Real.exp_add]
  ring

theorem point_soft_joint_central_ennreal (hWalk : WalkModelRegular) (u H : ℝ) (hH : 0 ≤ H) :
    ∀ᶠ N : Size in atTop, ∀ c a b : Vertex N, ∀ t : ℝ,
      phaseACenter N-H*timeScale N ≤ t →
      walkLaw {ω | localTime N a ω t c ≤ u ∧ walk N a ω t = b} ≤
        ENNReal.ofReal (pointSoftJointBound N u H) := by
  filter_upwards [point_soft_joint_central hWalk u H hH] with N hN
  intro c a b t ht
  have h := ENNReal.ofReal_le_ofReal (hN c a b t ht)
  simpa only [Measure.real,ENNReal.ofReal_toReal (measure_ne_top _ _)] using h

end TorusCoverTime.Blocks.B
