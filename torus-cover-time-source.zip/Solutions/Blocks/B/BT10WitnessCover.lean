import Solutions.Blocks.B.BT10Marginal
import Solutions.Blocks.B.BT10ScaleGeometry

/-! Extract a distance scale and the actual traversal count from a wide
witness outside the B-T8 contact set. The global good event is then dropped. -/
noncomputable section
open MeasureTheory Filter Set Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

def bt10AllSliceEvent (N : Size) (root : Vertex N) (γ U : ℝ) : Set (WalkSample × ℝ) :=
  ⋃ q∈r8InteriorIntegerScales N γ, ⋃ x : Vertex N, ⋃ y∈torusDisk N x (Real.exp (q:ℝ)),
    ⋃ m∈r8ModerateCounts (logSize N), bt10SliceEvent N x y root γ q U m

def bt10AllSliceMass (N : Size) (γ U l r : ℝ) : ℝ≥0∞ :=
  ∑ q∈r8InteriorIntegerScales N γ, ∑ x : Vertex N, ∑ y∈torusDisk N x (Real.exp (q:ℝ)),
    ∑ m∈r8ModerateCounts (logSize N), bt10SliceMass N x y γ q U m l r

theorem bt10WitnessEvent_measurable (N : Size) (root : Vertex N) (γ u : ℝ) :
    MeasurableSet (bt10WitnessEvent N root γ u) := by
  unfold bt10WitnessEvent
  simp only [Set.ofPred_and,Set.ofPred_exists]
  exact (bt8Good_measurable N root γ u).inter (MeasurableSet.iUnion fun x => MeasurableSet.iUnion fun y =>
    (MeasurableSet.const _).inter ((measurableSet_le (localTime_joint_measurable N root x) measurable_const).inter
      ((measurableSet_le (localTime_joint_measurable N root y) measurable_const).inter
        (by simpa only [Set.compl_ofPred] using (bt8SoftPoint_measurable N root x γ u).compl))))

theorem bt10AllSliceEvent_measurable (N : Size) (root : Vertex N) (γ U : ℝ) :
    MeasurableSet (bt10AllSliceEvent N root γ U) := by
  exact MeasurableSet.biUnion (Set.to_countable _) fun q _ => MeasurableSet.iUnion fun x =>
    MeasurableSet.biUnion (Set.to_countable _) fun y _ => MeasurableSet.biUnion (Set.to_countable _) fun m _ =>
      bt10SliceEvent_measurable N x y root γ q U m

theorem bt10_witness_cover (γ : ℝ) (hγ : 0<γ) (hγhi : 32*γ<1/10) :
    ∀ᶠ N : Size in atTop, ∀ root : Vertex N, ∀ u : ℝ,
      bt10WitnessEvent N root γ u ⊆ bt10AllSliceEvent N root γ (2*u/g) := by
  filter_upwards [bt10_witness_scale_bounds γ hγ hγhi,
    blockB_logSize_tendsto.eventually_ge_atTop 1] with N hscale hL
  intro root u z hz
  obtain ⟨hg,x,y,hwide,hx,hy,hnot⟩ := hz
  obtain ⟨hxy,hlo,hhi,hqlo,hqhi,hqmem⟩ := hscale x y hwide
  let q := bt10WitnessScale N x y
  let m := completedTraversalCount N (torusDisk N x (Real.exp ((q:ℝ)+(q:ℝ)^γ)))
    (torusDisk N x (Real.exp ((q:ℝ)+2*(q:ℝ)^γ))) root z.1 z.2
  have hqr := (mem_r8InteriorIntegerScales N γ q).mp hqmem
  have hcontrol := bt1_r8_all_soft_control N root x γ u z hg.2 (q:ℤ)
    (by simpa using hqr.1) (by simpa using hqr.2) hx
  have hv : Real.sqrt ((q:ℝ)^γ*(m:ℝ))≤10*logSize N := by simpa [r7TraversalRadius,m] using hcontrol.1
  have hq1 : 1≤(q:ℝ) := (Real.one_le_rpow hL (by norm_num : (0:ℝ)≤1/10)).trans hqlo
  have hm : m∈r8ModerateCounts (logSize N) := r8_moderate_count_mem _ _ _ (Real.one_le_rpow hq1 hγ.le) hv
  have hlarge : (logSize N)^(8*γ)≤Real.sqrt ((q:ℝ)^γ*(m:ℝ))-Real.sqrt 2*(q:ℝ) := by
    have hgt : Real.sqrt 2*(q:ℝ)+(logSize N)^(8*γ)<r7TraversalRadius N x root γ q z := by
      apply lt_of_not_ge
      intro hbound
      exact hnot ⟨hx,q,hqlo,hqhi,hbound⟩
    change _<Real.sqrt ((q:ℝ)^γ*(m:ℝ)) at hgt
    linarith
  have hfar : (N.val:ℝ)*Real.exp (-((logSize N)^(16*γ))/2)≤periodicDistance x root := by
    have ht := bt8Good_far N root x γ u z hg hx
    have hp : 0≤(N.val:ℝ)*Real.exp (-((logSize N)^(16*γ))/2) := by positivity
    linarith
  have hsoft : (localTime N root z.1 z.2 x+localTime N root z.1 z.2 y)/g≤2*u/g :=
    div_le_div_of_nonneg_right (by linarith) (by unfold g; positivity)
  simp only [bt10AllSliceEvent,mem_iUnion]
  exact ⟨q,hqmem,x,y,(bt9_site_geometry N x y q hxy hhi).2,m,hm,
    hxy,hlo,hhi,hlarge,hv,⟨hfar,rfl⟩,hsoft⟩

theorem bt10_all_slice_union_bound (N : Size) (γ U l r : ℝ) :
    r7LoopEventMass N (fun root => bt10AllSliceEvent N root γ U) l r ≤ bt10AllSliceMass N γ U l r := by
  apply (r7LoopEventMass_biUnion_le N (r8InteriorIntegerScales N γ) _ (by
    intro q hq root
    exact MeasurableSet.iUnion fun x => MeasurableSet.biUnion (Set.to_countable _) fun y _ =>
      MeasurableSet.biUnion (Set.to_countable _) fun m _ => bt10SliceEvent_measurable N x y root γ q U m) l r).trans
  apply Finset.sum_le_sum
  intro q hq
  have hx := r7LoopEventMass_biUnion_le N (Finset.univ : Finset (Vertex N))
    (fun x root => ⋃ y∈torusDisk N x (Real.exp (q:ℝ)), ⋃ m∈r8ModerateCounts (logSize N),
      bt10SliceEvent N x y root γ q U m)
    (fun x _ root => MeasurableSet.biUnion (Set.to_countable _) fun y _ =>
      MeasurableSet.biUnion (Set.to_countable _) fun m _ => bt10SliceEvent_measurable N x y root γ q U m) l r
  simp only [Finset.mem_univ,iUnion_true] at hx
  apply hx.trans
  apply Finset.sum_le_sum
  intro x _
  apply (r7LoopEventMass_biUnion_le N (torusDisk N x (Real.exp (q:ℝ))) _
    (fun y _ root => MeasurableSet.biUnion (Set.to_countable _) fun m _ =>
      bt10SliceEvent_measurable N x y root γ q U m) l r).trans
  apply Finset.sum_le_sum
  intro y hy
  exact r7LoopEventMass_biUnion_le N (r8ModerateCounts (logSize N)) _
    (fun m _ root => bt10SliceEvent_measurable N x y root γ q U m) l r

end TorusCoverTime.Blocks.B
