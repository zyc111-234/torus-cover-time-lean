import Solutions.Blocks.B.AnnularSymbol
import Mathlib.Analysis.Normed.Group.Bounded

/-! Compactness gives scale-uniform bounds on all derivatives of the annular reciprocal symbol. -/

noncomputable section
open Filter Function
open scoped Topology ContDiff
namespace TorusCoverTime.Blocks.B

lemma uniform_slab_derivative_bound {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
    (F : ℝ × (ℝ × ℝ) → E)
    (hsmooth : ∀ a x y : ℝ, |a| ≤ 1 / 7 → |x| ≤ 3 → |y| ≤ 3 →
      ContDiffAt ℝ ∞ F (a, x, y))
    (hzero : ∀ a x y : ℝ, 2 ≤ |x| ∨ 2 ≤ |y| → F (a, x, y) = 0)
    (p : ℕ) :
    ∃ C : ℝ, 0 < C ∧ ∀ a x y : ℝ, |a| ≤ 1 / 8 →
      ‖iteratedFDeriv ℝ p F (a, x, y)‖ ≤ C := by
  let K : Set (ℝ × (ℝ × ℝ)) := Set.Icc (-(1 / 8)) (1 / 8) ×ˢ
    (Set.Icc (-3) 3 ×ˢ Set.Icc (-3) 3)
  have hK : IsCompact K := isCompact_Icc.prod (isCompact_Icc.prod isCompact_Icc)
  have hcont : ContinuousOn (iteratedFDeriv ℝ p F) K := by
    rintro ⟨a, x, y⟩ h
    have ha : |a| ≤ 1 / 8 := abs_le.mpr h.1
    have hx : |x| ≤ 3 := abs_le.mpr h.2.1
    have hy : |y| ≤ 3 := abs_le.mpr h.2.2
    exact ((hsmooth a x y (by linarith) hx hy).continuousAt_iteratedFDeriv (k := p)
      (by exact_mod_cast (le_top : (p : ℕ∞) ≤ ⊤))).continuousWithinAt
  obtain ⟨B, hB⟩ := hK.exists_bound_of_continuousOn hcont
  let S : Set (ℝ × (ℝ × ℝ)) := Set.univ ×ˢ (Set.Icc (-2) 2 ×ˢ Set.Icc (-2) 2)
  have hS : IsClosed S := isClosed_univ.prod (isClosed_Icc.prod isClosed_Icc)
  have hsupp : support F ⊆ S := by
    rintro ⟨a, x, y⟩ hv
    have hx : |x| ≤ 2 := by
      by_contra hx
      exact hv (hzero a x y (Or.inl (le_of_lt (lt_of_not_ge hx))))
    have hy : |y| ≤ 2 := by
      by_contra hy
      exact hv (hzero a x y (Or.inr (le_of_lt (lt_of_not_ge hy))))
    exact ⟨Set.mem_univ _, abs_le.mp hx, abs_le.mp hy⟩
  have htsupp : tsupport F ⊆ S := closure_minimal hsupp hS
  have hdsupp : support (iteratedFDeriv ℝ p F) ⊆ S :=
    (support_iteratedFDeriv_subset p).trans htsupp
  refine ⟨max 1 B, lt_of_lt_of_le zero_lt_one (le_max_left _ _), ?_⟩
  intro a x y ha
  by_cases hxy : |x| ≤ 3 ∧ |y| ≤ 3
  · exact (hB (a, x, y) ⟨abs_le.mp ha, abs_le.mp hxy.1, abs_le.mp hxy.2⟩).trans (le_max_right _ _)
  · have hnot : (a, x, y) ∉ S := by
      intro h
      exact hxy ⟨by have := abs_le.mpr h.2.1; linarith,
        by have := abs_le.mpr h.2.2; linarith⟩
    have hval : iteratedFDeriv ℝ p F (a, x, y) = 0 := by
      by_contra hne
      exact hnot (hdsupp hne)
    rw [hval, norm_zero]
    exact le_trans zero_le_one (le_max_left _ _)

lemma annularReciprocal_derivative_bound (p : ℕ) :
    ∃ C : ℝ, 0 < C ∧ ∀ a x y : ℝ, |a| ≤ 1 / 8 →
      ‖iteratedFDeriv ℝ p (fun v : ℝ × (ℝ × ℝ) => annularReciprocal v.1 v.2.1 v.2.2)
        (a, x, y)‖ ≤ C :=
  uniform_slab_derivative_bound _ annularReciprocal_contDiffAt annularReciprocal_zero_outer p

end TorusCoverTime.Blocks.B
