import Solutions.Blocks.B.R8PairRootSum
import Solutions.Blocks.B.R8PairHarmonicBudget
import Solutions.Blocks.B.R8PairNestedBudget
import Solutions.Blocks.B.R8PairSoftBudget

/-! All three actual normalized pair budgets, ready for the already-proved B.20 and scalar exponent summation. -/
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B


theorem r8_integrated_pair_harmonic_budget (hWalk : WalkModelRegular) (γ U : ℝ)
    (hγ : 0 < γ) (hγ1 : γ < 1) (hU : 0 ≤ U) :
    ∀ᶠ N : Size in atTop, ∀ c : Vertex N, ∀ m n : ℕ, ∀ q : ℝ,
      2*(logSize N)^(16*γ) ≤ q → q ≤ logSize N-2*(logSize N)^(16*γ) →
      (n:ℝ) ≤ (logSize N)^4+1 →
      q ≤ Real.sqrt ((m:ℝ)*q^γ) → Real.sqrt ((m:ℝ)*q^γ) ≤ 10*logSize N → ∀ l r : ℝ,
      let d₁ := r8PairWindowShift N γ n
      let d₂ := r8PairWindowShift N γ m
      r8PairIntegratedWindow N c γ q U m n l r ≤
        r8PairSoftFactor γ q U n*r8PairHarmonicFactor N γ*
          r8ExactCountMass N c γ q m (l-d₁-d₂) (r+d₁+d₂) +
        (ENNReal.ofReal (timeScale N))⁻¹*(Fintype.card (Vertex N):ℝ≥0∞)*
          (r8PairSoftFactor γ q U n*r8PairDurationError N γ (l-d₁) (r+d₁)+r8PairDurationError N γ l r) := by
  filter_upwards [r8_pair_harmonic_budget hWalk γ U hγ hγ1 hU,r7_far_root_outside γ hγ] with N hpair hout
  intro c m n q hq hqL hn hv hvL l r
  apply r8PairIntegratedWindow_of_root_bound
  intro root hfar
  have hQ0 := Real.rpow_nonneg (logSize_pos N).le (16*γ)
  have hr := hout c root q (by linarith) (by linarith) hfar
  simpa only [add_assoc] using hpair c root m n q hq hqL hn hr hv hvL l r

theorem r8_integrated_pair_nested_budget (hWalk : WalkModelRegular) (γ U : ℝ)
    (hγ : 0 < γ) (hγ1 : γ < 1) (hU : 0 ≤ U) :
    ∀ᶠ N : Size in atTop, ∀ c : Vertex N, ∀ m n : ℕ, ∀ q : ℝ,
      2*(logSize N)^(16*γ) ≤ q → q ≤ logSize N-2*(logSize N)^(16*γ) →
      (n:ℝ) ≤ (logSize N)^4+1 →
      Real.sqrt ((m:ℝ)*q^γ) ≤ 10*logSize N →
      (logSize N)^(5*γ) ≤ Real.sqrt ((m:ℝ)*q^γ)-Real.sqrt (((r8NestedScale γ q)^γ)*(n:ℝ)) →
      ∀ l r : ℝ,
      let d₁ := r8PairWindowShift N γ n
      let d₂ := r8PairWindowShift N γ m
      r8PairIntegratedWindow N c γ q U m n l r ≤
        r8PairSoftFactor γ q U n*r8PairNestedFactor γ q m n*
          r8ExactCountMass N c γ q m (l-d₁-d₂) (r+d₁+d₂) +
        (ENNReal.ofReal (timeScale N))⁻¹*(Fintype.card (Vertex N):ℝ≥0∞)*
          (r8PairSoftFactor γ q U n*r8PairDurationError N γ (l-d₁) (r+d₁)+r8PairDurationError N γ l r) := by
  filter_upwards [r8_pair_nested_budget hWalk γ U hγ hγ1 hU,r7_far_root_outside γ hγ] with N hpair hout
  intro c m n q hq hqL hn hvL hgap l r
  apply r8PairIntegratedWindow_of_root_bound
  intro root hfar
  have hQ0 := Real.rpow_nonneg (logSize_pos N).le (16*γ)
  have hr := hout c root q (by linarith) (by linarith) hfar
  simpa only [add_assoc] using hpair c root m n q hq hqL hn hr hvL hgap l r

theorem r8_integrated_pair_soft_budget (hWalk : WalkModelRegular) (γ U : ℝ)
    (hγ : 0 < γ) (hγ1 : γ < 1) (hU : 0 ≤ U) :
    ∀ᶠ N : Size in atTop, ∀ c : Vertex N, ∀ m n : ℕ, ∀ q : ℝ,
      2*(logSize N)^(16*γ) ≤ q → q ≤ logSize N-2*(logSize N)^(16*γ) →
      (n:ℝ) ≤ (logSize N)^4+1 → ∀ l r : ℝ,
      let d := r8PairWindowShift N γ n
      r8PairIntegratedWindow N c γ q U m n l r ≤
        r8PairSoftFactor γ q U n*r8ExactCountMass N c γ q m (l-d) (r+d) +
        (ENNReal.ofReal (timeScale N))⁻¹*(Fintype.card (Vertex N):ℝ≥0∞)*r8PairDurationError N γ l r := by
  filter_upwards [r8_pair_soft_budget hWalk γ U hγ hγ1 hU,r7_far_root_outside γ hγ] with N hpair hout
  intro c m n q hq hqL hn l r
  apply r8PairIntegratedWindow_of_root_bound
  intro root hfar
  have hQ0 := Real.rpow_nonneg (logSize_pos N).le (16*γ)
  exact hpair c root m n q hq hqL hn (hout c root q (by linarith) (by linarith) hfar) l r


end TorusCoverTime.Blocks.B

