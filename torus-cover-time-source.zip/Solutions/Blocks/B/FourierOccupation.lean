import Solutions.Blocks.B.FourierTail
import Solutions.Core.WalkMeasurability
import Mathlib.MeasureTheory.Integral.Prod

/-! Joint measurability and the occupation-time identity for the concrete walk. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter
open scoped BigOperators Topology ENNReal

namespace TorusCoverTime.Blocks.B

lemma measurable_jumpCount_joint :
    Measurable (fun p : WalkSample × ℝ => jumpCount p.1 p.2) := by
  classical
  let S : Set (WalkSample × ℝ) := {p | ∃ k : ℕ, p.2 < jumpTime p.1 (k + 1)}
  have hS : MeasurableSet S := by
    simp only [S, Set.ofPred_exists]
    exact MeasurableSet.iUnion (fun k => measurableSet_lt measurable_snd
      ((measurable_jumpTime (k + 1)).comp measurable_fst))
  have hfind : Measurable (fun p : S => Nat.find p.property) := by
    apply measurable_find
    intro k
    exact measurableSet_lt (measurable_snd.comp measurable_subtype_coe)
      ((measurable_jumpTime (k + 1)).comp (measurable_fst.comp measurable_subtype_coe))
  exact hfind.dite (measurable_const (a := (0 : ℕ))) hS

lemma measurable_walk_eq_joint (N : Size) (start y : Vertex N) :
    Measurable (fun p : WalkSample × ℝ => walk N start p.1 p.2 = y) := by
  classical
  have hpos : Measurable (fun p : (WalkSample × ℝ) × ℕ => position N start p.1.1 p.2 = y) :=
    measurable_from_prod_countable_left (fun n =>
      (measurable_position_eq N start y n).comp measurable_fst)
  have hpos' := hpos.comp (measurable_id.prodMk measurable_jumpCount_joint)
  have h : Measurable (fun p : WalkSample × ℝ => if p.2 < 0 then start = y
      else position N start p.1 (jumpCount p.1 p.2) = y) :=
    Measurable.ite (measurableSet_lt measurable_snd measurable_const)
      measurable_const hpos'
  convert! h using 1
  ext p
  by_cases ht : p.2 < 0 <;> simp [walk, ht]

lemma measurable_walk_indicator_joint (N : Size) (start y : Vertex N) :
    Measurable (fun p : WalkSample × ℝ => if walk N start p.1 p.2 = y then (1 : ℝ) else 0) := by
  classical
  exact Measurable.ite (measurable_walk_eq_joint N start y).setOf measurable_const measurable_const

lemma localTime_integrable_and_expectation (N : Size) (start y : Vertex N) (t : ℝ) :
    Integrable (fun ω => localTime N start ω t y) walkLaw ∧
    (∫ ω, localTime N start ω t y ∂walkLaw) =
      ∫ s in Set.Icc 0 t, transitionProbability N start y s := by
  classical
  let f : WalkSample × ℝ → ℝ := fun p => if walk N start p.1 p.2 = y then 1 else 0
  have hf : Integrable f (walkLaw.prod (volume.restrict (Set.Icc 0 t))) := by
    apply Integrable.of_bound (measurable_walk_indicator_joint N start y).aestronglyMeasurable 1
    exact Filter.Eventually.of_forall (fun p => by dsimp [f]; split_ifs <;> norm_num)
  refine ⟨hf.integral_prod_left, ?_⟩
  change (∫ ω, (∫ s in Set.Icc 0 t, f (ω, s)) ∂walkLaw) = _
  rw [integral_integral_swap hf]
  apply integral_congr_ae
  exact Filter.Eventually.of_forall (fun s => by
    have hs := ((measurable_walk_eq_joint N start y).comp (measurable_prodMk_right (y := s))).setOf
    have hid := integral_indicator_const (μ := walkLaw) (1 : ℝ) hs
    simpa [f, Set.indicator, transitionProbability, Measure.real] using hid)

lemma integral_exp_neg_mul_Icc {lam : ℝ} (hlam : 0 < lam) (t : ℝ) (ht : 0 ≤ t) :
    (∫ s in Set.Icc 0 t, Real.exp (-s * lam)) = (1 - Real.exp (-t * lam)) / lam := by
  have h := intervalIntegral.integral_Ici_sub_Ici'
    (integrableOn_exp_neg_mul_Ici hlam 0) (integrableOn_exp_neg_mul_Ici hlam t)
  rw [intervalIntegral.integral_of_le ht, ← integral_Icc_eq_integral_Ioc,
    integral_exp_neg_mul_Ici hlam 0, integral_exp_neg_mul_Ici hlam t] at h
  simpa [sub_div] using h.symm

lemma fourier_occupation_from_transition
    (hTransition : ∀ N : Size, ∀ t : ℝ, 0 ≤ t → ∀ x y : Vertex N,
      vertexCount N * transitionProbability N x y t = 1 +
        ∑ k ∈ nonzeroFrequencies N, Real.exp (-t * finiteEigenvalue N k) *
          finiteCosine N k (x - y))
    (N : Size) (t : ℝ) (ht : 0 ≤ t) (x y : Vertex N) :
    Integrable (fun ω => localTime N x ω t y) walkLaw ∧
    (∫ ω, localTime N x ω t y ∂walkLaw) =
      t / vertexCount N + greenKernel N x y - tailGreen N t x y := by
  have hlocal := localTime_integrable_and_expectation N x y t
  refine ⟨hlocal.1, ?_⟩
  rw [hlocal.2]
  let mode := fun (k : Vertex N) (s : ℝ) =>
    Real.exp (-s * finiteEigenvalue N k) * finiteCosine N k (x - y)
  have hint (k : Vertex N) (hk : k ∈ nonzeroFrequencies N) :
      IntegrableOn (mode k) (Set.Icc 0 t) :=
    ((integrableOn_exp_neg_mul_Ici (eigenvalue_pos_of_nonzero N hk) 0).mono_set
      Set.Icc_subset_Ici_self).mul_const _
  have heq : Set.EqOn (fun s => transitionProbability N x y s)
      (fun s => (1 + ∑ k ∈ nonzeroFrequencies N, mode k s) / vertexCount N) (Set.Icc 0 t) := by
    intro s hs
    apply (eq_div_iff (vertexCount_pos N).ne').mpr
    simpa only [mode, mul_comm] using hTransition N s hs.1 x y
  rw [setIntegral_congr_fun measurableSet_Icc heq, integral_div,
    integral_add (integrable_const 1) (integrable_finsetSum _ hint), integral_finsetSum _ hint]
  have hone : (∫ s : ℝ in Set.Icc 0 t, (1 : ℝ)) = t := by
    simp [ht]
  rw [hone]
  have hmode : (∑ k ∈ nonzeroFrequencies N, ∫ s in Set.Icc 0 t, mode k s) =
      (∑ k ∈ nonzeroFrequencies N, finiteCosine N k (x - y) / finiteEigenvalue N k) -
      (∑ k ∈ nonzeroFrequencies N, Real.exp (-t * finiteEigenvalue N k) *
        finiteCosine N k (x - y) / finiteEigenvalue N k) := by
    rw [← Finset.sum_sub_distrib]
    apply Finset.sum_congr rfl
    intro k hk
    dsimp [mode]
    rw [integral_mul_const, integral_exp_neg_mul_Icc (eigenvalue_pos_of_nonzero N hk) t ht]
    ring
  rw [hmode]
  unfold greenKernel tailGreen
  ring

end TorusCoverTime.Blocks.B
