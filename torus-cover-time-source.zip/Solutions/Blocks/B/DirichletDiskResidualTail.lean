import Solutions.Blocks.B.DirichletDiskResidualBounds

/-! Single-scale conditional residual tail for the actual disk field and
actual exit circle. All spatial bounds are proved in the preceding module. -/

noncomputable section
open MeasureTheory ProbabilityTheory
open scoped BigOperators
namespace TorusCoverTime.Blocks.B

theorem dirichlet_disk_residual_tail (N : Size) (root c x : Vertex N) (R r : ℝ)
    (hr : 1≤r) (hsmall : 2*(R+1)<N.val) (hroot : root∉torusDisk N c R)
    (hdeep : periodicDistance x c+(r+1)≤R/2) (T t s : ℝ) (ht : |t|≤T) :
    (finiteFieldLaw N).real {ξ | 8*dirichletResidualVarianceBound r*s ≤
      ∑ z, exitHarmonic N (torusDisk N x r) z x*
        (dirichletResidualAtEndpoint N root (torusDisk N x r) (torusDisk N c R) x t ξ z)^2} ≤
      2*Real.exp ((dirichletResidualCrossBound*T/dirichletClockLS N root (torusDisk N c R) x)^2/
        (4*dirichletResidualVarianceBound r)-s) := by
  have hh := dirichlet_disk_residual_Green_bounds N root c x R r hr hsmall hroot hdeep
  have hxE : x∈torusDisk N c R := by
    apply (mem_torusDisk N c x R).mpr
    have hnon : 0≤periodicDistance x c := by unfold periodicDistance; positivity
    linarith
  have hV : 0<dirichletClockLS N root (torusDisk N c R) x := by
    apply div_pos
    · exact zero_lt_one.trans_le (Blocks.C.C4.pinnedDomainKernel_diagonal N root _ hroot x hxE)
    · unfold g; positivity
  have hQ : 0<dirichletResidualVarianceBound r := by
    have hp := dirichletLogError_pos
    have hl := Real.log_nonneg hr
    have hl3 : 0<Real.log 3 := Real.log_pos (by norm_num)
    unfold dirichletResidualVarianceBound
    linarith
  have hC : 0≤dirichletResidualCrossBound := by
    have hp := dirichletLogError_pos
    have hl3 : 0<Real.log 3 := Real.log_pos (by norm_num)
    unfold dirichletResidualCrossBound
    linarith
  exact dirichletResidual_conditioned_Green_tail N root _ _ hh.1 hroot x hV
    (dirichletResidualVarianceBound r) dirichletResidualCrossBound T t s hQ hC ht
    (fun z hz => (hh.2 z hz).1) (fun z hz => (hh.2 z hz).2)

end TorusCoverTime.Blocks.B
