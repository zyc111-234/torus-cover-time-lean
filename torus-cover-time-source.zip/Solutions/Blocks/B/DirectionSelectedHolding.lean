import Solutions.Blocks.B.HoldingDirections
import Mathlib.Probability.Independence.Process.Basic

/-! A holding time is independent of the entire direction sequence, including events
that select an exit or a visit at an unbounded direction-dependent index. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Classical
open scoped ENNReal Topology BigOperators
namespace TorusCoverTime.Blocks.B

def walkDirections (ω : WalkSample) : ℕ → Fin 4 := fun j => (ω j).2

lemma measurable_walkDirections : Measurable walkDirections := by
  unfold walkDirections
  fun_prop

lemma holdingTime_independent_directions (j : ℕ) :
    IndepFun (fun ω : WalkSample => holdingTime ω j) walkDirections walkLaw := by
  apply IndepFun.indepFun_process (measurable_holdingTime j)
    (fun i => (measurable_pi_apply i).comp measurable_walkDirections)
  intro I
  let n := max (j + 1) (I.sup id + 1)
  let ji : Fin n := ⟨j, (Nat.lt_succ_self j).trans_le (le_max_left _ _)⟩
  let lift : I → Fin n := fun i => ⟨i.val,
    (Nat.lt_succ_of_le (Finset.le_sup (f := id) i.property)).trans_le (le_max_right _ _)⟩
  exact (holding_direction_prefix_independent n).comp
    (show Measurable (fun H : Fin n → ℝ => max (H ji) 0) by fun_prop)
    (show Measurable (fun d : Fin n → Fin 4 => fun i : I => d (lift i)) by fun_prop)

lemma integral_exp_neg_holdingLaw :
    (∫ s, Real.exp (-max s 0) ∂holdingLaw) = (1 / 2 : ℝ) := by
  rw [integral_holdingLaw]
  have heq : Set.EqOn (fun s => Real.exp (-s) * Real.exp (-max s 0))
      (fun s => Real.exp (-s * 2)) (Set.Ici 0) := by
    intro s hs
    dsimp only
    rw [max_eq_left hs, ← Real.exp_add]
    congr 1
    ring
  rw [setIntegral_congr_fun measurableSet_Ici heq,
    integral_exp_neg_mul_Ici (by norm_num : (0 : ℝ) < 2) 0]
  norm_num

lemma integral_exp_neg_holdingTime (j : ℕ) :
    (∫ ω, Real.exp (-holdingTime ω j) ∂walkLaw) = (1 / 2 : ℝ) := by
  have hm : Measurable (fun s : ℝ => Real.exp (-max s 0)) := by fun_prop
  have hc : Measurable (fun ω : WalkSample => (ω j).1) := by fun_prop
  have hmap := integral_map hc.aemeasurable hm.aestronglyMeasurable (μ := walkLaw)
  rw [holding_coordinate_law] at hmap
  exact hmap.symm.trans integral_exp_neg_holdingLaw

lemma integrable_exp_neg_holdingTime (j : ℕ) :
    Integrable (fun ω : WalkSample => Real.exp (-holdingTime ω j)) walkLaw := by
  apply Integrable.of_bound (measurable_holdingTime j).neg.exp.aestronglyMeasurable 1
  exact Eventually.of_forall fun ω => by
    rw [Real.norm_eq_abs, abs_of_pos (Real.exp_pos _)]
    apply Real.exp_le_one_iff.mpr
    simp [holdingTime]

lemma integral_exp_neg_holdingTime_direction_event
    (j : ℕ) (E : Set (ℕ → Fin 4)) (hE : MeasurableSet E) :
    (∫ ω in walkDirections ⁻¹' E, Real.exp (-holdingTime ω j) ∂walkLaw) =
      (1 / 2 : ℝ) * walkLaw.real (walkDirections ⁻¹' E) := by
  have hmE := hE.preimage measurable_walkDirections
  have hfE : Measurable (E.indicator (fun _ => (1 : ℝ))) := measurable_const.indicator hE
  have hi := (holdingTime_independent_directions j).comp
    (show Measurable (fun s : ℝ => Real.exp (-s)) by fun_prop)
    hfE
  have hp := hi.integral_fun_mul_eq_mul_integral
    (measurable_holdingTime j).neg.exp.aestronglyMeasurable
    (hfE.comp measurable_walkDirections).aestronglyMeasurable
  dsimp only [Function.comp_def] at hp
  change (∫ ω, Real.exp (-holdingTime ω j) *
    E.indicator (fun _ => (1 : ℝ)) (walkDirections ω) ∂walkLaw) = _ at hp
  have heq : (fun ω => Real.exp (-holdingTime ω j) *
      E.indicator (fun _ => (1 : ℝ)) (walkDirections ω)) =
      (walkDirections ⁻¹' E).indicator (fun ω => Real.exp (-holdingTime ω j)) := by
    funext ω
    simp only [Set.indicator, Set.mem_preimage]
    split_ifs <;> simp
  rw [heq, integral_indicator hmE, integral_exp_neg_holdingTime j] at hp
  have hind : (∫ ω, E.indicator (fun _ => (1 : ℝ)) (walkDirections ω) ∂walkLaw) =
      walkLaw.real (walkDirections ⁻¹' E) := by
    change (∫ ω, (walkDirections ⁻¹' E).indicator (fun _ => (1 : ℝ)) ω ∂walkLaw) = _
    simp [integral_indicator hmE, Measure.real]
  simpa only [hind] using hp

def directionSelectedHolding (J : (ℕ → Fin 4) → ℕ) (ω : WalkSample) : ℝ :=
  holdingTime ω (J (walkDirections ω))

lemma measurable_directionSelectedHolding (J : (ℕ → Fin 4) → ℕ) (hJ : Measurable J) :
    Measurable (directionSelectedHolding J) := by
  have hm : Measurable (fun p : WalkSample × ℕ => holdingTime p.1 p.2) :=
    measurable_from_prod_countable_left fun j => measurable_holdingTime j
  exact hm.comp (measurable_id.prodMk (hJ.comp measurable_walkDirections))

lemma integrable_exp_neg_directionSelectedHolding (J : (ℕ → Fin 4) → ℕ)
    (hJ : Measurable J) :
    Integrable (fun ω => Real.exp (-directionSelectedHolding J ω)) walkLaw := by
  apply Integrable.of_bound (measurable_directionSelectedHolding J hJ).neg.exp.aestronglyMeasurable 1
  exact Eventually.of_forall fun ω => by
    rw [Real.norm_eq_abs, abs_of_pos (Real.exp_pos _)]
    apply Real.exp_le_one_iff.mpr
    simp [directionSelectedHolding, holdingTime]

lemma integral_directionSelectedHolding_direction_event
    (J : (ℕ → Fin 4) → ℕ) (hJ : Measurable J)
    (E : Set (ℕ → Fin 4)) (hE : MeasurableSet E) :
    (∫ ω in walkDirections ⁻¹' E, Real.exp (-directionSelectedHolding J ω) ∂walkLaw) =
      (1 / 2 : ℝ) * walkLaw.real (walkDirections ⁻¹' E) := by
  let S : ℕ → Set WalkSample := fun j => walkDirections ⁻¹' (E ∩ J ⁻¹' {j})
  have hm (j : ℕ) : MeasurableSet (S j) :=
    (hE.inter ((measurableSet_singleton j).preimage hJ)).preimage measurable_walkDirections
  have hd : Pairwise (fun i j => Disjoint (S i) (S j)) := by
    intro i j hij
    apply Set.disjoint_left.mpr
    intro ω hi hj
    have hi' : J (walkDirections ω) = i := hi.2
    have hj' : J (walkDirections ω) = j := hj.2
    exact hij (hi'.symm.trans hj')
  have hUnion : (⋃ j, S j) = walkDirections ⁻¹' E := by
    ext ω
    simp [S]
  have hterm (j : ℕ) :
      (∫ ω in S j, Real.exp (-directionSelectedHolding J ω) ∂walkLaw) =
        ∫ _ in S j, (1 / 2 : ℝ) ∂walkLaw := by
    have heq : Set.EqOn (fun ω => Real.exp (-directionSelectedHolding J ω))
        (fun ω => Real.exp (-holdingTime ω j)) (S j) := by
      intro ω hω
      have hj : J (walkDirections ω) = j := hω.2
      simp [directionSelectedHolding, hj]
    rw [setIntegral_congr_fun (hm j) heq,
      integral_exp_neg_holdingTime_direction_event j (E ∩ J ⁻¹' {j})
        (hE.inter ((measurableSet_singleton j).preimage hJ))]
    simp [S, Measure.real, mul_comm]
  have hs := hasSum_integral_iUnion hm hd
    (integrable_exp_neg_directionSelectedHolding J hJ).integrableOn
  simp_rw [hterm] at hs
  have hs' := hasSum_integral_iUnion hm hd
    ((integrable_const (1 / 2 : ℝ) : Integrable (fun _ : WalkSample => (1 / 2 : ℝ)) walkLaw).integrableOn)
  have heq := hs.unique hs'
  rw [hUnion] at heq
  simpa [Measure.real, mul_comm] using heq

end TorusCoverTime.Blocks.B
