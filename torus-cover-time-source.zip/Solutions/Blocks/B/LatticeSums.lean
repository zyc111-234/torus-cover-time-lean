import Mathlib.NumberTheory.Harmonic.Bounds
import Solutions.Blocks.B.GreenApproximation

/-! Square-shell estimates for the two-dimensional reciprocal quadratic symbol. -/

noncomputable section
open MeasureTheory
open scoped BigOperators
namespace TorusCoverTime.Blocks.B

lemma sum_reciprocal_squares (n : ℕ) :
    (∑ j ∈ Finset.range n, 1 / ((j : ℝ) + 1) ^ 2) ≤ 2 - 2 / ((n : ℝ) + 1) := by
  induction n with
  | zero => norm_num
  | succ n ih =>
    rw [Finset.sum_range_succ]
    have ha : 0 < (n : ℝ) + 1 := by positivity
    have hb : 0 < (n : ℝ) + 2 := by positivity
    have hterm : 1 / ((n : ℝ) + 1) ^ 2 ≤
        2 / ((n : ℝ) + 1) - 2 / ((n : ℝ) + 2) := by
      rw [show 2 / ((n : ℝ) + 1) - 2 / ((n : ℝ) + 2) =
        2 / (((n : ℝ) + 1) * ((n : ℝ) + 2)) by field_simp; ring]
      apply (div_le_div_iff₀ (sq_pos_of_pos ha) (mul_pos ha hb)).mpr
      nlinarith [Nat.cast_nonneg (α := ℝ) n]
    push_cast
    rw [show (n : ℝ) + 1 + 1 = n + 2 by ring]
    linarith

lemma sum_reciprocal_squares_le_two (n : ℕ) :
    (∑ j ∈ Finset.range n, 1 / ((j : ℝ) + 1) ^ 2) ≤ 2 :=
  (sum_reciprocal_squares n).trans (sub_le_self _ (by positivity))

lemma reciprocal_quadratic_antitone (r : ℝ) (hr : 0 < r) :
    AntitoneOn (fun x : ℝ => 1 / (r ^ 2 + x ^ 2)) (Set.Ici 0) := by
  intro x hx y hy hxy
  apply one_div_le_one_div_of_le (by positivity)
  have := pow_le_pow_left₀ hx hxy 2
  linarith

lemma lattice_row_integral (r : ℝ) (hr : 0 < r) :
    (∫ x : ℝ in 0..r, 1 / (r ^ 2 + x ^ 2)) = Real.pi / (4 * r) := by
  simp only [one_div]
  rw [integral_inv_sq_add_sq hr.ne']
  simp only [div_self hr.ne', zero_div, Real.arctan_one, Real.arctan_zero, sub_zero]
  ring

lemma lattice_row_bounds (n : ℕ) (hn : 0 < n) :
    Real.pi / (4 * n) ≤ (∑ j ∈ Finset.range n, 1 / ((n : ℝ) ^ 2 + (j : ℝ) ^ 2)) ∧
    (∑ j ∈ Finset.range n, 1 / ((n : ℝ) ^ 2 + (j : ℝ) ^ 2)) ≤
      Real.pi / (4 * n) + 1 / (n : ℝ) ^ 2 := by
  have hnR : 0 < (n : ℝ) := by exact_mod_cast hn
  have hanti : AntitoneOn (fun x : ℝ => 1 / ((n : ℝ) ^ 2 + x ^ 2))
      (Set.Icc 0 (0 + (n : ℝ))) :=
    (reciprocal_quadratic_antitone n hnR).mono (fun _ hx => hx.1)
  have hlo := hanti.integral_le_sum (a := n) (x₀ := 0)
  have hhi := hanti.sum_le_integral (a := n) (x₀ := 0)
  simp only [zero_add, lattice_row_integral n hnR] at hlo hhi
  refine ⟨hlo, ?_⟩
  have hid := Finset.sum_range_succ' (fun j : ℕ => 1 / ((n : ℝ) ^ 2 + (j : ℝ) ^ 2)) n
  rw [Finset.sum_range_succ] at hid
  simp only [Nat.cast_zero, zero_pow (by decide : 2 ≠ 0), add_zero] at hid
  have hlast : 0 ≤ 1 / ((n : ℝ) ^ 2 + (n : ℝ) ^ 2) := by positivity
  linarith

def quadrantReciprocalSum (n : ℕ) : ℝ :=
  ∑ i ∈ Finset.range (n + 1), ∑ j ∈ Finset.range (n + 1),
    1 / ((i : ℝ) ^ 2 + (j : ℝ) ^ 2)

lemma quadrantReciprocalSum_zero : quadrantReciprocalSum 0 = 0 := by
  norm_num [quadrantReciprocalSum]

lemma double_sum_range_succ (f : ℕ → ℕ → ℝ) (m : ℕ) :
    (∑ i ∈ Finset.range (m + 1), ∑ j ∈ Finset.range (m + 1), f i j) =
      (∑ i ∈ Finset.range m, ∑ j ∈ Finset.range m, f i j) +
      (∑ i ∈ Finset.range m, f i m) + (∑ j ∈ Finset.range m, f m j) + f m m := by
  rw [Finset.sum_range_succ (fun i => ∑ j ∈ Finset.range (m + 1), f i j) m]
  simp_rw [Finset.sum_range_succ (n := m)]
  rw [Finset.sum_add_distrib]
  ring

lemma quadrantReciprocalSum_succ (n : ℕ) :
    quadrantReciprocalSum (n + 1) = quadrantReciprocalSum n +
      2 * (∑ j ∈ Finset.range (n + 1), 1 / (((n : ℝ) + 1) ^ 2 + (j : ℝ) ^ 2)) +
      1 / (2 * ((n : ℝ) + 1) ^ 2) := by
  unfold quadrantReciprocalSum
  rw [double_sum_range_succ _ (n + 1)]
  simp only [Nat.cast_add, Nat.cast_one]
  have hs : (∑ i ∈ Finset.range (n + 1), 1 / ((i : ℝ) ^ 2 + ((n : ℝ) + 1) ^ 2)) =
      ∑ j ∈ Finset.range (n + 1), 1 / (((n : ℝ) + 1) ^ 2 + (j : ℝ) ^ 2) := by
    apply Finset.sum_congr rfl
    intro _ _
    rw [add_comm]
  rw [hs, show ((n : ℝ) + 1) ^ 2 + ((n : ℝ) + 1) ^ 2 = 2 * ((n : ℝ) + 1) ^ 2 by ring]
  ring

lemma quadrantReciprocalSum_harmonic_error (n : ℕ) :
    0 ≤ quadrantReciprocalSum n - (Real.pi / 2) * (harmonic n : ℝ) ∧
    quadrantReciprocalSum n - (Real.pi / 2) * (harmonic n : ℝ) ≤
      3 * ∑ j ∈ Finset.range n, 1 / ((j : ℝ) + 1) ^ 2 := by
  induction n with
  | zero => norm_num [quadrantReciprocalSum_zero]
  | succ n ih =>
    have hrow := lattice_row_bounds (n + 1) (by omega)
    rw [quadrantReciprocalSum_succ, harmonic_succ,
      Finset.sum_range_succ (fun j : ℕ => 1 / ((j : ℝ) + 1) ^ 2) n]
    push_cast
    push_cast at hrow
    have hhalf : 1 / (2 * ((n : ℝ) + 1) ^ 2) =
        (1 / ((n : ℝ) + 1) ^ 2) / 2 := by simp only [div_eq_mul_inv, mul_inv_rev]; ring
    have hpi : Real.pi / 2 * ((n : ℝ) + 1)⁻¹ = Real.pi / (2 * ((n : ℝ) + 1)) := by
      simp only [div_eq_mul_inv, mul_inv_rev]; ring
    have hpihalf : 2 * (Real.pi / (4 * ((n : ℝ) + 1))) =
        Real.pi / (2 * ((n : ℝ) + 1)) := by simp only [div_eq_mul_inv, mul_inv_rev]; ring
    have hnonneg : 0 ≤ 1 / ((n : ℝ) + 1) ^ 2 := by positivity
    have hmain : Real.pi / 2 * ((harmonic n : ℝ) + ((n : ℝ) + 1)⁻¹) =
        Real.pi / 2 * (harmonic n : ℝ) + Real.pi / (2 * ((n : ℝ) + 1)) := by
      rw [mul_add, hpi]
    simp only [hhalf, hmain]
    constructor <;> nlinarith [hrow.1, hrow.2, hpihalf]

lemma quadrantReciprocalSum_log_error (n : ℕ) (hn : 0 < n) :
    |quadrantReciprocalSum n - (Real.pi / 2) * Real.log n| ≤ 6 + Real.pi / 2 := by
  have hh := quadrantReciprocalSum_harmonic_error n
  have hsq := sum_reciprocal_squares_le_two n
  have hlo : Real.log n ≤ (harmonic n : ℝ) := by
    apply le_trans _ (log_add_one_le_harmonic n)
    exact Real.log_le_log (by exact_mod_cast hn) (by exact_mod_cast Nat.le_succ n)
  have hhi := harmonic_le_one_add_log n
  have hp : 0 ≤ Real.pi / 2 := by positivity
  have hlomul := mul_le_mul_of_nonneg_left hlo hp
  have hhimul := mul_le_mul_of_nonneg_left hhi hp
  rw [abs_of_nonneg (by linarith : 0 ≤ quadrantReciprocalSum n - Real.pi / 2 * Real.log n)]
  nlinarith

end TorusCoverTime.Blocks.B
