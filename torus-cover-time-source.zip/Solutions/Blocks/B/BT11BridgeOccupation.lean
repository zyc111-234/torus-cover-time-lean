import Solutions.Blocks.B.BT11ShortParameters

/-! The short bridge pays only a fixed occupation allowance of one at
each selected site. The bound is joint with its exact terminal vertex. -/
noncomputable section
open MeasureTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

theorem bt11_added_occupation_joint (N : Size) (c a b : Vertex N) (T : ℝ) (hT : 0≤T) :
    walkLaw.real {ω | 1<localTime N a ω T c ∧ walk N a ω T=b}≤
      2*(transitionProbability N a b T-pointKillingKernel N c T a b) := by
  let E : Set WalkSample := {ω | 1<localTime N a ω T c ∧ walk N a ω T=b}
  let R : Set WalkSample := {ω | walk N a ω T=b}
  have hR : MeasurableSet R := ((measurable_walk_eq_joint N a b).comp (measurable_id.prodMk measurable_const)).setOf
  have hE : MeasurableSet E := (measurableSet_lt measurable_const
    ((localTime_joint_measurable N a c).comp (measurable_id.prodMk measurable_const))).inter hR
  have hpoint (ω : WalkSample) : E.indicator (fun _ => (1:ℝ)) ω≤
      2*(R.indicator (fun _ => (1:ℝ)) ω-pointOccupationWeight N c a b T ω) := by
    by_cases he : ω∈E
    · rw [indicator_of_mem he,indicator_of_mem (show ω∈R from he.2),pointOccupationWeight,if_pos he.2]
      have hexp : Real.exp (-localTime N a ω T c)≤(1/2:ℝ) := by
        rw [Real.exp_neg]
        apply (inv_le_comm₀ (Real.exp_pos _) (by norm_num)).mpr
        norm_num
        linarith [Real.add_one_le_exp (localTime N a ω T c),he.1]
      linarith
    · rw [indicator_of_notMem he]
      have hb := pointOccupationWeight_le_indicator N c a b T ω
      have hb' : pointOccupationWeight N c a b T ω≤R.indicator (fun _ => (1:ℝ)) ω := by
        simpa only [R,Set.indicator,mem_setOf_eq] using hb
      linarith
  have hi : Integrable (R.indicator (fun _ => (1:ℝ))) walkLaw := (integrable_const (1:ℝ)).indicator hR
  have h := integral_mono ((integrable_const (1:ℝ)).indicator hE)
    ((hi.sub (pointOccupationWeight_integrable N c a b T)).const_mul 2) hpoint
  rw [integral_indicator_const _ hE,smul_eq_mul,mul_one,integral_const_mul] at h
  simp only [Pi.sub_apply] at h
  rw [integral_sub hi (pointOccupationWeight_integrable N c a b T),
    integral_indicator_const _ hR,smul_eq_mul,mul_one] at h
  rw [pointKillingKernel_eq_occupation N c a b T hT]
  exact h

theorem bt11_short_bridge_site (hWalk : WalkModelRegular) :
    ∀ᶠ N : Size in atTop, ∀ T : ℝ, bt11ShortTime N≤T → T≤2*bt11ShortTime N →
      ∀ a b c : Vertex N, bt11FarRadius N≤periodicDistance a c →
      bt11FarRadius N≤periodicDistance b c →
        walkLaw.real {ω | 1<localTime N a ω T c ∧ walk N a ω T=b}≤1/(32*vertexCount N) := by
  filter_upwards [bt11_short_rows hWalk,bt11_short_mixing hWalk] with N hrow hmix
  intro T hlo hhi a b c hac hbc
  have hT := (bt11ShortTime_pos N).le.trans hlo
  have h := bt11_bridge_kernel_deficit N c a b T (fun x y => (hmix T hlo x y).2.2)
    (hmix T hlo a b).2.1 hT (hrow a c hac (T/2) (by linarith) (by linarith))
    (hrow b c hbc (T/2) (by linarith) (by linarith))
  apply (bt11_added_occupation_joint N c a b T hT).trans
  have hh := mul_le_mul_of_nonneg_left h (by norm_num : (0:ℝ)≤2)
  convert hh using 1 <;> ring

theorem bt11_short_bridge_pair (hWalk : WalkModelRegular) :
    ∀ᶠ N : Size in atTop, ∀ T : ℝ, bt11ShortTime N≤T → T≤2*bt11ShortTime N →
      ∀ a b x y : Vertex N,
      bt11FarRadius N≤periodicDistance a x → bt11FarRadius N≤periodicDistance b x →
      bt11FarRadius N≤periodicDistance a y → bt11FarRadius N≤periodicDistance b y →
      walkLaw.real {ω | (1<localTime N a ω T x ∨ 1<localTime N a ω T y) ∧ walk N a ω T=b}≤
        1/(16*vertexCount N) := by
  filter_upwards [bt11_short_bridge_site hWalk] with N hN
  intro T hlo hhi a b x y hax hbx hay hby
  have he : {ω | (1<localTime N a ω T x ∨ 1<localTime N a ω T y) ∧ walk N a ω T=b}=
      {ω | 1<localTime N a ω T x ∧ walk N a ω T=b}∪{ω | 1<localTime N a ω T y ∧ walk N a ω T=b} := by
    ext ω; simp only [mem_setOf_eq,mem_union]; tauto
  rw [he]
  exact (measureReal_union_le _ _).trans ((add_le_add (hN T hlo hhi a b x hax hbx)
    (hN T hlo hhi a b y hay hby)).trans_eq (by ring))

end TorusCoverTime.Blocks.B
