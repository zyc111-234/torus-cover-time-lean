import Solutions.Blocks.B.PhysicalLoopWindowAlgebra
import Solutions.Blocks.B.ExteriorCountHarmonicTest

/-! Swap the two actual count indices before the second resampling, without an independence assumption. -/
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B


theorem physicalCountWindow_swap (N : Size) (I J Q O : Finset (Vertex N)) (root : Vertex N)
    (m k : ℕ) (F : WalkSample × ℝ → ℝ≥0∞) (l r : ℝ) :
    physicalCountWindow N I J root m
      (fun z => if completedTraversalCount N Q O root z.1 z.2 = k then F z else 0) l r =
    physicalCountWindow N Q O root k
      (fun z => if completedTraversalCount N I J root z.1 z.2 = m then F z else 0) l r := by
  apply lintegral_congr
  intro ω
  apply lintegral_congr
  intro t
  dsimp only
  split_ifs <;> simp_all

theorem physicalCountWindow_outer_harmonic_le (N : Size) (I J Q O : Finset (Vertex N))
    (c root : Vertex N) (m k : ℕ) (q v Δ l r : ℝ) :
    physicalCountWindow N I J root m (outerCountHarmonicTest N Q O c root k q v Δ) l r ≤
      physicalCountWindow N Q O root k
        (fun z => if Δ < |Real.sqrt (harmonicPathOccupation N c root q z)-v| then 1 else 0) l r := by
  have he : outerCountHarmonicTest N Q O c root k q v Δ =
      fun z => if completedTraversalCount N Q O root z.1 z.2 = k then
        (if Δ < |Real.sqrt (harmonicPathOccupation N c root q z)-v| then 1 else 0) else 0 := by
    funext z
    unfold outerCountHarmonicTest
    split_ifs <;> simp_all
  rw [he,physicalCountWindow_swap]
  apply physicalCountWindow_mono
  intro z
  split_ifs <;> simp_all

theorem physicalCountWindow_outer_harmonic_le_low_inner (N : Size) (I J Q O : Finset (Vertex N))
    (c root : Vertex N) (m k : ℕ) (q v Δ l r : ℝ) :
    physicalCountWindow N I J root m (outerCountHarmonicTest N Q O c root k q v Δ) l r ≤
      physicalCountWindow N Q O root k
        (fun z => if completedTraversalCount N I J root z.1 z.2 ≤ m then 1 else 0) l r := by
  have he : outerCountHarmonicTest N Q O c root k q v Δ =
      fun z => if completedTraversalCount N Q O root z.1 z.2 = k then
        (if Δ < |Real.sqrt (harmonicPathOccupation N c root q z)-v| then 1 else 0) else 0 := by
    funext z
    unfold outerCountHarmonicTest
    split_ifs <;> simp_all
  rw [he,physicalCountWindow_swap]
  apply physicalCountWindow_mono
  intro z
  split_ifs <;> simp_all

theorem physicalCountWindow_outer_harmonic_le_marginal (N : Size) (I J Q O : Finset (Vertex N))
    (c root : Vertex N) (m k : ℕ) (q v Δ l r : ℝ) :
    physicalCountWindow N I J root m (outerCountHarmonicTest N Q O c root k q v Δ) l r ≤
      physicalCountWindow N Q O root k (fun _ => 1) l r :=
  (physicalCountWindow_outer_harmonic_le N I J Q O c root m k q v Δ l r).trans
    (physicalCountWindow_mono N Q O root k _ _ (fun z => by split_ifs <;> simp) l r)


end TorusCoverTime.Blocks.B

