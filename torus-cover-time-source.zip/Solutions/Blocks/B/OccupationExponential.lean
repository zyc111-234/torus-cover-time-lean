import Solutions.Blocks.B.ExitKhasminskii
import Solutions.Blocks.B.ExitOccupationLaplace

/-! The exponential bound is transferred to the original physical local
times, including null conditioning events. No integrability is assumed. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

def exitOccupation (N : Size) (D : Finset (Vertex N)) (U : Vertex N → ℝ)
    (a : Vertex N) (ω : WalkSample) : ℝ :=
  ∑ z, U z*localTime N a ω (finiteExitDuration N D a ω) z

theorem measurable_exitOccupation (N : Size) (D : Finset (Vertex N)) (U : Vertex N → ℝ)
    (a : Vertex N) : Measurable (exitOccupation N D U a) :=
  Finset.measurable_sum _ (fun z _ =>
    (localTime_measurable_random_time N a z _ (measurable_finiteExitDuration N D a)).const_mul (U z))

theorem exitOccupation_nonneg (N : Size) (D : Finset (Vertex N)) (U : Vertex N → ℝ)
    (hU : ∀ z, 0 ≤ U z) (a : Vertex N) (ω : WalkSample) : 0 ≤ exitOccupation N D U a ω :=
  Finset.sum_nonneg (fun z _ => mul_nonneg (hU z) (localTime_nonneg N a z ω _))

theorem exitExpWeight_eq_physical_ae (hWalk : WalkModelRegular) (N : Size)
    (D : Finset (Vertex N)) (b : Vertex N) (U : Vertex N → ℝ) (θ : ℝ) (a : Vertex N) :
    exitExpWeight N D b U θ a =ᵐ[walkLaw] (exitsThrough N D a b).indicator
      (fun ω => ENNReal.ofReal (Real.exp (θ*exitOccupation N D U a ω))) := by
  filter_upwards [hWalk.1] with ω hω
  simp only [exitExpWeight, Set.indicator]
  split_ifs
  · rw [holdingPotentialSum_eq_localTime N U a hω.1 hω.2]
    rfl
  · rfl

theorem disk_conditioned_occupation_exp_lintegral (hWalk : WalkModelRegular)
    (N : Size) (c : Vertex N) (R : ℝ) (hR : 0 ≤ R) (hsmall : 2*(R+1) < N.val)
    (b : Vertex N) (U : Vertex N → ℝ) (hU : ∀ z, 0 ≤ U z) (K θ : ℝ) (hK : 0 ≤ K)
    (hθ : 0 ≤ θ) (hθK : θ*K ≤ 1/2)
    (hpositive : ∀ z ∈ torusDisk N c R, U z ≠ 0 → 0 < exitHarmonic N (torusDisk N c R) b z)
    (hbound : ∀ z ∈ torusDisk N c R, U z ≠ 0 →
      exitPotentialMean N (torusDisk N c R) b U z ≤ K*exitHarmonic N (torusDisk N c R) b z)
    (a : Vertex N) :
    (∫⁻ ω, ENNReal.ofReal (Real.exp (θ*exitOccupation N (torusDisk N c R) U a ω))
      ∂exactExitLaw N (torusDisk N c R) a b) ≤ 2 := by
  let D := torusDisk N c R
  let E := exitsThrough N D a b
  have hE := measurableSet_exitsThrough N D a b
  have hp : ENNReal.ofReal (exitHarmonic N D b a) = walkLaw E :=
    ENNReal.ofReal_toReal (measure_ne_top walkLaw E)
  rw [exactExitLaw, ProbabilityTheory.cond, lintegral_smul_measure, smul_eq_mul,
    ← lintegral_indicator hE, ← lintegral_congr_ae (exitExpWeight_eq_physical_ae hWalk N D b U θ a)]
  calc
    _ ≤ (walkLaw E)⁻¹*ENNReal.ofReal (2*exitHarmonic N D b a) :=
      mul_le_mul' le_rfl (disk_exitExpWeight_bound N c R hR hsmall b U hU K θ hK hθ hθK hpositive hbound a)
    _ = 2*((walkLaw E)⁻¹*walkLaw E) := by
      rw [ENNReal.ofReal_mul (by norm_num : (0:ℝ)≤2), hp]
      simpa only [ENNReal.ofReal_ofNat] using
        (mul_left_comm (walkLaw E)⁻¹ (2:ℝ≥0∞) (walkLaw E))
    _ ≤ 2 := by simpa only [mul_one] using mul_le_mul' (le_refl (2:ℝ≥0∞)) (ENNReal.inv_mul_le_one _)

end TorusCoverTime.Blocks.B
