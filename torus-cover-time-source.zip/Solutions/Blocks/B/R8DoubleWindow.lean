import Solutions.Blocks.B.R8CountPairSupport
import Solutions.Blocks.B.R7EnlargedWindows

/-! Two resampling enlargements at actual moderate counts fit in one
additional central-window unit. Both clocks and both interval endpoints are kept. -/
noncomputable section
open Filter
open scoped Topology
namespace TorusCoverTime.Blocks.B

theorem r8_count_pair_total_cutoff (L : ℝ) (hL : 20 ≤ L) (m n : ℕ)
    (hm : m ∈ r8ModerateCounts L) (hn : n ∈ r8ModerateCounts L) :
    ((m+n:ℕ):ℝ) ≤ L^4+1 := by
  have hm' : (m:ℝ) ≤ 100*L^2 :=
    (Nat.le_floor_iff (by positivity : 0 ≤ 100*L^2)).mp
      (Nat.lt_succ_iff.mp (Finset.mem_range.mp hm))
  have hn' : (n:ℝ) ≤ 100*L^2 :=
    (Nat.le_floor_iff (by positivity : 0 ≤ 100*L^2)).mp
      (Nat.lt_succ_iff.mp (Finset.mem_range.mp hn))
  have hq : 0 ≤ L^2-202 := by nlinarith
  have hp := mul_nonneg hq (sq_nonneg L)
  push_cast
  nlinarith

theorem r8_two_window_steps_small (γ : ℝ) (hγ : 0 < γ) :
    ∀ᶠ N : Size in atTop, ∀ p ∈ r8CountPairs (logSize N),
      r7WindowStep N γ p.1+r7WindowStep N γ p.2 ≤ timeScale N := by
  filter_upwards [r7_enlarged_window_size γ hγ,blockB_logSize_tendsto.eventually_ge_atTop 20] with N hN hL
  intro p hp
  have hm := r8_count_pair_total_cutoff (logSize N) hL p.1 p.2
    (Finset.mem_product.mp hp).1 (Finset.mem_product.mp hp).2
  have hJ : 1 ≤ (r7IterationLength N:ℝ) := by
    have ht : (logSize N)^2 ≤ (r7IterationLength N:ℝ) := Nat.le_ceil _
    nlinarith
  have hs := (le_mul_of_one_le_left (r7WindowStep_nonneg N γ (p.1+p.2)) hJ).trans (hN (p.1+p.2) hm)
  simpa only [r7WindowStep,Nat.cast_add,add_mul] using hs

theorem r8_two_windows_central (N : Size) (γ H l r : ℝ) (m n : ℕ)
    (hsmall : r7WindowStep N γ m+r7WindowStep N γ n ≤ timeScale N)
    (hlo : phaseACenter N-H*timeScale N ≤ l) (hhi : r ≤ phaseACenter N+H*timeScale N) :
    phaseACenter N-(H+1)*timeScale N ≤ (l-r7WindowStep N γ m)-r7WindowStep N γ n ∧
      (r+r7WindowStep N γ m)+r7WindowStep N γ n ≤ phaseACenter N+(H+1)*timeScale N := by
  constructor <;> linarith

theorem r8_first_window_error_length (N : Size) (γ H l r : ℝ) (m n : ℕ)
    (hsmall : r7WindowStep N γ m+r7WindowStep N γ n ≤ timeScale N)
    (hlen : r-l ≤ 2*H*timeScale N) :
    (r+r7WindowStep N γ m)-(l-r7WindowStep N γ m) ≤ 2*(H+1)*timeScale N := by
  have hn := r7WindowStep_nonneg N γ n
  linarith

end TorusCoverTime.Blocks.B
