import Solutions.Blocks.B.PeriodicSampling
import Solutions.Blocks.B.AnnularSupport

/-! Uniform pointwise and summable frequency differences of the actual annular array. -/

noncomputable section
open Function
open scoped Topology ContDiff BigOperators
namespace TorusCoverTime.Blocks.B

lemma annularArray_axis_sample (N : Size) (R : ℝ) (hR : R ≠ 0) (ds : List (Fin 4))
    (axis : Bool) (q : ZMod N.val) :
    (fun b => annularArray N R ds (axisPoint N axis q b)) =
      fun b => (((R / N.val) ^ ds.length / R ^ 2 : ℝ) : ℂ) *
        cyclicSample N R (annularSlice ds (R / N.val) axis ((q.valMinAbs : ℝ) / R)) b := by
  funext b
  rw [annularArray_scaled N R hR]
  cases axis <;> rfl

lemma annularArray_pointwise_difference_bound (ds : List (Fin 4)) (p : ℕ) :
    ∃ C : ℝ, 0 < C ∧ ∀ N : Size, ∀ R : ℝ, 0 < R → R / N.val ≤ 2 →
      ∀ axis : Bool, ∀ k : Vertex N,
      ‖((frequencyDifference N (axisUnit N axis))^[p] (annularArray N R ds)) k‖ ≤
        (R / N.val) ^ ds.length / R ^ 2 * (C / R ^ p) := by
  obtain ⟨C, hC, hb⟩ := annularSlice_uniform_difference_bound ds p
  refine ⟨C, hC, ?_⟩
  intro N R hR ha axis k
  have hN : 0 < (N.val : ℝ) := lt_trans zero_lt_one (size_real_gt_one N)
  have hpos : 0 < R / N.val := div_pos hR hN
  have hc : 0 ≤ (R / N.val) ^ ds.length / R ^ 2 := by positivity
  have hpoint (q b : ZMod N.val) :
      ‖((frequencyDifference N (axisUnit N axis))^[p] (annularArray N R ds))
        (axisPoint N axis q b)‖ ≤ (R / N.val) ^ ds.length / R ^ 2 * (C / R ^ p) := by
    let f := annularSlice ds (R / N.val) axis ((q.valMinAbs : ℝ) / R)
    have hp : Periodic f ((N.val : ℝ) / R) := by
      have ht : 1 / (R / N.val) = (N.val : ℝ) / R := by field_simp
      rw [← ht]
      exact annularSlice_periodic ds (R / N.val) hpos.ne' axis _
    rw [frequencyDifference_restrict_axis, annularArray_axis_sample N R hR.ne',
      cyclicDifference_const_mul_iterate, cyclicDifference_sample_iterate N R f hp]
    change ‖(((R / N.val) ^ ds.length / R ^ 2 : ℝ) : ℂ) *
      ((realDifference (1 / R))^[p] f) ((b.valMinAbs : ℝ) / R)‖ ≤ _
    rw [norm_mul, Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg hc]
    exact mul_le_mul_of_nonneg_left (hb (R / N.val) hpos ha R hR axis _ _) hc
  rcases k with ⟨x, y⟩
  cases axis
  · exact hpoint y x
  · exact hpoint x y

lemma annularArray_l1_difference_bound (ds : List (Fin 4)) (p : ℕ) :
    ∃ C : ℝ, 0 < C ∧ ∀ N : Size, ∀ R : ℝ, 1 / 4 ≤ R → R / N.val ≤ 2 →
      ∀ axis : Bool,
      (∑ k : Vertex N, ‖((frequencyDifference N (axisUnit N axis))^[p] (annularArray N R ds)) k‖) ≤
        C * (R / N.val) ^ ds.length / R ^ p := by
  obtain ⟨C, hC, hb⟩ := annularArray_pointwise_difference_bound ds p
  refine ⟨144 * 2 ^ p * C, by positivity, ?_⟩
  intro N R hR ha axis
  have hRp : 0 < R := by linarith
  have hN : 0 < (N.val : ℝ) := lt_trans zero_lt_one (size_real_gt_one N)
  have hc : 0 ≤ (R / N.val) ^ ds.length / R ^ 2 * (C / R ^ p) := by positivity
  have hcard : ((frequencySupport N
      ((frequencyDifference N (axisUnit N axis))^[p] (annularArray N R ds))).card : ℝ) ≤
        2 ^ p * (144 * R ^ 2) := by
    have h := frequencySupport_iterate_card N (axisUnit N axis) (annularArray N R ds) p
    have hr : ((frequencySupport N
      ((frequencyDifference N (axisUnit N axis))^[p] (annularArray N R ds))).card : ℝ) ≤
        2 ^ p * ((frequencySupport N (annularArray N R ds)).card : ℝ) := by exact_mod_cast h
    exact hr.trans (mul_le_mul_of_nonneg_left (annularArray_support_card N R hR ds) (by positivity))
  calc
    _ ≤ ((frequencySupport N
        ((frequencyDifference N (axisUnit N axis))^[p] (annularArray N R ds))).card : ℝ) *
        ((R / N.val) ^ ds.length / R ^ 2 * (C / R ^ p)) :=
      sum_norm_le_support_card N _ _ (hb N R hRp ha axis)
    _ ≤ (2 ^ p * (144 * R ^ 2)) * ((R / N.val) ^ ds.length / R ^ 2 * (C / R ^ p)) :=
      mul_le_mul_of_nonneg_right hcard hc
    _ = (144 * 2 ^ p * C) * (R / N.val) ^ ds.length / R ^ p := by field_simp

end TorusCoverTime.Blocks.B
