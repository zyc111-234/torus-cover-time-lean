import Solutions.Blocks.B.ExactExitProduct
import Mathlib.Combinatorics.SimpleGraph.Connectivity.Connected

/-! Loop erasure turns actual core-avoiding connectivity into the short exit word required by R1. -/

noncomputable section
open Classical
namespace TorusCoverTime.Blocks.B

def reversedDirection (d : Fin 4) : Fin 4 :=
  if d = 0 then 1 else if d = 1 then 0 else if d = 2 then 3 else 2

lemma direction_reversed (N : Size) (d : Fin 4) :
    direction N (reversedDirection d) = -direction N d := by
  fin_cases d <;> simp [reversedDirection, direction]

def torusNeighborGraph (N : Size) : SimpleGraph (Vertex N) where
  Adj x y := x ≠ y ∧ ∃ d : Fin 4, y = x + direction N d
  symm := by
    constructor
    rintro x y ⟨hne, d, hd⟩
    refine ⟨hne.symm, reversedDirection d, ?_⟩
    rw [direction_reversed, hd]
    simp
  loopless := ⟨by intro x h; exact h.1 rfl⟩

lemma directions_of_graph_walk (N : Size) (W : Finset (Vertex N)) (a b : W)
    (p : ((torusNeighborGraph N).induce (W : Set (Vertex N))).Walk a b) :
    ∃ d : Fin p.length → Fin 4, ∀ j ≤ p.length,
      position N a.val (sampleOfDirections d) j = (p.getVert j).val := by
  have hdir (i : Fin p.length) : ∃ d : Fin 4,
      (p.getVert (i.val + 1)).val = (p.getVert i.val).val + direction N d :=
    (p.adj_getVert_succ i.isLt).2
  choose d hd using hdir
  refine ⟨d, ?_⟩
  intro j
  induction j with
  | zero => intro _; simp
  | succ j ih =>
    intro hj
    have hlt : j < p.length := by omega
    have hs : position N a.val (sampleOfDirections d) (j + 1) =
        position N a.val (sampleOfDirections d) j + direction N (d ⟨j, hlt⟩) := by
      simp only [position, Finset.sum_range_succ, sampleOfDirections, dif_pos hlt, add_assoc]
    rw [hs, ih (by omega)]
    exact (hd ⟨j, hlt⟩).symm

lemma feasibleAvoidingExit_of_graph_reachable (N : Size) (D K W : Finset (Vertex N))
    (a b : W) (hb : b.val ∉ D) (hK : ∀ x ∈ W, x ∉ K)
    (hW : ∀ x ∈ W, x ≠ b.val → x ∈ D) (hcard : W.card ≤ D.card + 1)
    (hr : ((torusNeighborGraph N).induce (W : Set (Vertex N))).Reachable a b) :
    FeasibleAvoidingExit N D K a.val b.val := by
  obtain ⟨p, hp⟩ := hr.exists_isPath
  obtain ⟨d, hd⟩ := directions_of_graph_walk N W a b p
  refine ⟨p.length, ?_, d, ⟨hb, ?_, ?_⟩, ?_⟩
  · have hcw : Fintype.card (W : Set (Vertex N)) = W.card :=
      Fintype.card_of_finset' W (fun _ => Iff.rfl)
    have hlen := hp.length_lt
    rw [hcw] at hlen
    omega
  · rw [hd p.length le_rfl, p.getVert_length]
  · intro j
    rw [hd j.val j.isLt.le]
    apply hW _ (p.getVert j.val).property
    intro heq
    have hj := (hp.getVert_eq_end_iff j.isLt.le).mp (Subtype.ext heq)
    omega
  · intro j hj
    rw [hd j hj]
    exact hK _ (p.getVert j).property

def exitAllowedSet (N : Size) (D K : Finset (Vertex N)) (b : Vertex N) : Finset (Vertex N) :=
  insert b (D \ K)

lemma exitAllowedSet_card (N : Size) (D K : Finset (Vertex N)) (b : Vertex N) :
    (exitAllowedSet N D K b).card ≤ D.card + 1 :=
  (Finset.card_insert_le _ _).trans (Nat.add_le_add_right (Finset.card_le_card Finset.sdiff_subset) 1)

lemma exitAllowedSet_avoids (N : Size) (D K : Finset (Vertex N)) (b : Vertex N)
    (hKD : K ⊆ D) (hb : b ∉ D) : ∀ x ∈ exitAllowedSet N D K b, x ∉ K := by
  intro x hx
  rcases Finset.mem_insert.mp hx with rfl | hx
  · exact fun h => hb (hKD h)
  · exact (Finset.mem_sdiff.mp hx).2

lemma feasibleAvoidingExit_of_allowed_reachable (N : Size) (D K : Finset (Vertex N))
    (a b : Vertex N) (ha : a ∈ D \ K) (hKD : K ⊆ D) (hb : b ∉ D)
    (hr : ((torusNeighborGraph N).induce (exitAllowedSet N D K b : Set (Vertex N))).Reachable
      ⟨a, Finset.mem_insert_of_mem ha⟩ ⟨b, Finset.mem_insert_self _ _⟩) :
    FeasibleAvoidingExit N D K a b := by
  apply feasibleAvoidingExit_of_graph_reachable N D K (exitAllowedSet N D K b)
    ⟨a, Finset.mem_insert_of_mem ha⟩ ⟨b, Finset.mem_insert_self _ _⟩ hb
    (exitAllowedSet_avoids N D K b hKD hb) _ (exitAllowedSet_card N D K b) hr
  intro x hx hxb
  exact (Finset.mem_sdiff.mp ((Finset.mem_insert.mp hx).resolve_left hxb)).1

lemma feasibleAvoidingExit_of_connected_core_complement (N : Size) (D K : Finset (Vertex N))
    (a b : Vertex N) (ha : a ∈ D \ K) (hKD : K ⊆ D) (hb : b ∉ D)
    (hconn : ((torusNeighborGraph N).induce ((D \ K : Finset (Vertex N)) : Set (Vertex N))).Preconnected)
    (hc : ∃ c ∈ D \ K, (torusNeighborGraph N).Adj c b) : FeasibleAvoidingExit N D K a b := by
  obtain ⟨c, hc, hcb⟩ := hc
  apply feasibleAvoidingExit_of_allowed_reachable N D K a b ha hKD hb
  have hinc : ((D \ K : Finset (Vertex N)) : Set (Vertex N)) ⊆ (exitAllowedSet N D K b : Set (Vertex N)) :=
    fun _ hx => Finset.mem_insert_of_mem hx
  have hr := (hconn ⟨a, ha⟩ ⟨c, hc⟩).map ((torusNeighborGraph N).induceHomOfLE hinc).toHom
  have hedge : ((torusNeighborGraph N).induce (exitAllowedSet N D K b : Set (Vertex N))).Adj
      ⟨c, Finset.mem_insert_of_mem hc⟩ ⟨b, Finset.mem_insert_self _ _⟩ := hcb
  exact hr.trans hedge.reachable

end TorusCoverTime.Blocks.B
