import Solutions.Blocks.B.PeriodicAnnularBounds
import Solutions.Blocks.B.PeriodicCore
import Solutions.Blocks.B.AffineDerivatives

/-! Uniform derivatives and finite differences of the periodic coordinate slices. -/

noncomputable section
open Function
open scoped Topology ContDiff
namespace TorusCoverTime.Blocks.B

def annularSlice (ds : List (Fin 4)) (a : ℝ) (axis : Bool) (q t : ℝ) : ℂ :=
  if axis then periodicAnnularCore ds a q t else periodicAnnularCore ds a t q

@[fun_prop] lemma annularSlice_contDiff (ds : List (Fin 4)) (a : ℝ) (axis : Bool) (q : ℝ) :
    ContDiff ℝ ∞ (annularSlice ds a axis q) := by
  cases axis
  · change ContDiff ℝ ∞ (fun t => periodicAnnularCore ds a t q)
    simpa only [Function.comp_def] using (periodicAnnularCore_contDiff ds).comp
      (show ContDiff ℝ ∞ (fun t : ℝ => (a, t, q)) from
        contDiff_const.prodMk (contDiff_id.prodMk contDiff_const))
  · change ContDiff ℝ ∞ (fun t => periodicAnnularCore ds a q t)
    simpa only [Function.comp_def] using (periodicAnnularCore_contDiff ds).comp
      (show ContDiff ℝ ∞ (fun t : ℝ => (a, q, t)) from
        contDiff_const.prodMk (contDiff_const.prodMk contDiff_id))

lemma annularSlice_periodic (ds : List (Fin 4)) (a : ℝ) (ha : a ≠ 0) (axis : Bool) (q : ℝ) :
    Periodic (annularSlice ds a axis q) (1 / a) := by
  cases axis
  · exact periodicAnnularCore_periodic_x ds a ha q
  · exact periodicAnnularCore_periodic_y ds a ha q

lemma annularSlice_parameter_periodic (ds : List (Fin 4)) (a : ℝ) (ha : a ≠ 0)
    (axis : Bool) (t : ℝ) : Periodic (fun q => annularSlice ds a axis q t) (1 / a) := by
  cases axis
  · exact periodicAnnularCore_periodic_y ds a ha t
  · exact periodicAnnularCore_periodic_x ds a ha t

lemma annularSlice_norm_derivative_fundamental (ds : List (Fin 4)) (p : ℕ) :
    ∃ C : ℝ, 0 < C ∧ ∀ a : ℝ, |a| ≤ 2 → ∀ axis : Bool, ∀ q t : ℝ,
      |a * q| ≤ 1 / 2 → |a * t| ≤ 1 / 2 →
      ‖iteratedDeriv p (annularSlice ds a axis q) t‖ ≤ C := by
  obtain ⟨C, hC, hb⟩ := periodicAnnularCore_fundamental_derivative_bound ds p
  refine ⟨C, hC, ?_⟩
  intro a ha axis q t hq ht
  let F := fun v : ℝ × (ℝ × ℝ) => periodicAnnularCore ds v.1 v.2.1 v.2.2
  cases axis
  · have hline := norm_iteratedDeriv_affine_line_le F (periodicAnnularCore_contDiff ds)
      (a, 0, q) (0, 1, 0) p t
    have hn : ‖iteratedDeriv p (annularSlice ds a false q) t‖ ≤
        ‖iteratedFDeriv ℝ p F (a, t, q)‖ := by
      change ‖iteratedDeriv p (fun t => periodicAnnularCore ds a t q) t‖ ≤ _
      simpa [F, Prod.norm_def] using hline
    exact hn.trans (hb a t q ha ht hq)
  · have hline := norm_iteratedDeriv_affine_line_le F (periodicAnnularCore_contDiff ds)
      (a, q, 0) (0, 0, 1) p t
    have hn : ‖iteratedDeriv p (annularSlice ds a true q) t‖ ≤
        ‖iteratedFDeriv ℝ p F (a, q, t)‖ := by
      change ‖iteratedDeriv p (fun t => periodicAnnularCore ds a q t) t‖ ≤ _
      simpa [F, Prod.norm_def] using hline
    exact hn.trans (hb a q t ha hq ht)

lemma annularSlice_uniform_derivative_bound (ds : List (Fin 4)) (p : ℕ) :
    ∃ C : ℝ, 0 < C ∧ ∀ a : ℝ, 0 < a → a ≤ 2 → ∀ axis : Bool, ∀ q t : ℝ,
      ‖iteratedDeriv p (annularSlice ds a axis q) t‖ ≤ C := by
  obtain ⟨C, hC, hb⟩ := annularSlice_norm_derivative_fundamental ds p
  refine ⟨C, hC, ?_⟩
  intro a ha ha8 axis q t
  obtain ⟨m, hm⟩ := exists_fundamental_translate a q ha.ne'
  obtain ⟨n, hn⟩ := exists_fundamental_translate a t ha.ne'
  have hq : annularSlice ds a axis (q - (m : ℝ) * (1 / a)) = annularSlice ds a axis q := by
    funext x
    exact (annularSlice_parameter_periodic ds a ha.ne' axis x).sub_int_mul_eq m
  have ht := (periodic_iteratedDeriv _ _ (annularSlice_periodic ds a ha.ne' axis q) p).sub_int_mul_eq
    (x := t) n
  rw [← ht, ← hq]
  exact hb a (by rwa [abs_of_pos ha]) axis _ _ hm hn

lemma annularSlice_uniform_difference_bound (ds : List (Fin 4)) (p : ℕ) :
    ∃ C : ℝ, 0 < C ∧ ∀ a : ℝ, 0 < a → a ≤ 2 → ∀ R : ℝ, 0 < R →
      ∀ axis : Bool, ∀ q t : ℝ,
      ‖((realDifference (1 / R))^[p] (annularSlice ds a axis q)) t‖ ≤ C / R ^ p := by
  obtain ⟨C, hC, hb⟩ := annularSlice_uniform_derivative_bound ds p
  refine ⟨C, hC, ?_⟩
  intro a ha ha8 R hR axis q t
  exact norm_realDifference_scaled_le R hR p _ (annularSlice_contDiff ds a axis q)
    C (hb a ha ha8 axis q) t

end TorusCoverTime.Blocks.B
