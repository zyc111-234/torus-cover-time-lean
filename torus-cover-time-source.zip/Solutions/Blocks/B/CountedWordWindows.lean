import Solutions.Blocks.B.R7ActualWordRecurrence
import Solutions.Blocks.B.TraversalCountPartition

/-! Finite-count loop mass is exactly the sum over its actual endpoint words.
All summands use the original physical clock and the same window. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

def traversalWordMass (N : Size) (I O : Finset (Vertex N)) (root : Vertex N) (m : ℕ)
    (w : Fin (2*m) → Vertex N) : ℝ≥0∞ :=
  walkLaw {ω | adaptiveExitWord N (alternatingDomain N I O) root (2*m) ω = w}

theorem traversalWordMass_sum (N : Size) (I O : Finset (Vertex N)) (root : Vertex N) (m : ℕ) :
    (∑ w, traversalWordMass N I O root m w) = 1 := by
  have hm := adaptiveExitWord_measurable N (alternatingDomain N I O) root (2*m)
  have hs := sum_measure_preimage_singleton (μ := walkLaw) (f := adaptiveExitWord N (alternatingDomain N I O) root (2*m))
    Finset.univ (fun w _ => hm (measurableSet_singleton w))
  have he (w : Fin (2*m) → Vertex N) :
      adaptiveExitWord N (alternatingDomain N I O) root (2*m) ⁻¹' {w} =
        {ω | adaptiveExitWord N (alternatingDomain N I O) root (2*m) ω = w} := by
    ext ω
    simp
  simp_rw [he] at hs
  simpa [traversalWordMass] using hs

def countedLoopWindowMass (N : Size) (I O : Finset (Vertex N)) (root : Vertex N) (M : ℕ) (l r : ℝ) : ℝ≥0∞ :=
  ∫⁻ ω, ∫⁻ t in Ioi (0 : ℝ), if completedTraversalCount N I O root ω t ≤ M ∧
    walk N root ω t = root ∧ t ∈ Icc l r then 1 else 0 ∂volume ∂walkLaw

theorem countedLoopWindowMass_word_sum (N : Size) (I O : Finset (Vertex N)) (hIO : I ⊆ O)
    (hI : I.Nonempty) (root : Vertex N) (hr : root ∉ O) (M : ℕ) (l r : ℝ) :
    countedLoopWindowMass N I O root M l r =
      ∑ m ∈ Finset.range (M+1), ∑ w : Fin (2*m) → Vertex N,
        traversalWordMass N I O root m w * conditionalTraversalSlice N I O root m w (fun _ => 1) l r := by
  let F := fun z : WalkSample × ℝ => if z.2 ∈ Icc l r then (1 : ℝ≥0∞) else 0
  have hF : Measurable F := measurable_const.ite (measurable_snd measurableSet_Icc) measurable_const
  have hh := loop_count_window_partition N I O hIO hI root hr M F hF
  have he (ω : WalkSample) (t : ℝ) :
      (if completedTraversalCount N I O root ω t ≤ M ∧ walk N root ω t = root then F (ω,t) else 0) =
      if completedTraversalCount N I O root ω t ≤ M ∧ walk N root ω t = root ∧ t ∈ Icc l r then 1 else 0 := by
    dsimp only [F]
    split_ifs <;> simp_all
  simp_rw [he] at hh
  rw [countedLoopWindowMass,hh]
  apply Finset.sum_congr rfl
  intro m _
  rw [adaptiveExitWord_conditional_partition N (alternatingDomain N I O) root (2*m)]
  apply Finset.sum_congr rfl
  intro w _
  congr 1
  apply lintegral_congr
  intro ω
  apply lintegral_congr
  intro t
  dsimp only [F]
  split_ifs <;> simp_all

theorem conditionalTraversalSlice_mono_window (N : Size) (I O : Finset (Vertex N)) (root : Vertex N)
    (m : ℕ) (w : Fin (2*m) → Vertex N) (F : (Fin (2*m) → ℕ × WalkSample) → ℝ≥0∞)
    (l r l' r' : ℝ) (hl : l' ≤ l) (hr : r ≤ r') :
    conditionalTraversalSlice N I O root m w F l r ≤ conditionalTraversalSlice N I O root m w F l' r' := by
  apply lintegral_mono
  intro ω
  apply lintegral_mono
  intro t
  by_cases ht : t < adaptiveExitTime N (alternatingDomain N I O) root (2*m+1) ω ∧
      walk N root ω t = root ∧ t ∈ Icc l r
  · have ht' : t < adaptiveExitTime N (alternatingDomain N I O) root (2*m+1) ω ∧
        walk N root ω t = root ∧ t ∈ Icc l' r' := ⟨ht.1,ht.2.1,hl.trans ht.2.2.1,ht.2.2.2.trans hr⟩
    simp only [if_pos ht,if_pos ht',le_refl]
  · simp only [if_neg ht]
    exact bot_le

theorem weighted_finite_recurrence {ι : Type*} [Fintype ι]
    (p a b c : ι → ℝ≥0∞) (ρ ε : ℝ≥0∞) (hp : ∑ i, p i = 1)
    (h : ∀ i, p i ≠ 0 → a i ≤ b i+ρ*c i+ε) :
    (∑ i, p i*a i) ≤ (∑ i, p i*b i)+ρ*(∑ i, p i*c i)+ε := by
  calc
    _ ≤ ∑ i, p i*(b i+ρ*c i+ε) := by
      apply Finset.sum_le_sum
      intro i _
      by_cases hi : p i = 0
      · simp [hi]
      · exact mul_le_mul' le_rfl (h i hi)
    _ = _ := by
      simp only [mul_add,Finset.sum_add_distrib]
      have he (i : ι) : p i*(ρ*c i) = ρ*(p i*c i) := by ac_rfl
      simp_rw [he]
      rw [← Finset.mul_sum,← Finset.sum_mul,hp,one_mul]

def lowWordWindowSum (N : Size) (c root : Vertex N) (I O : Finset (Vertex N))
    (M : ℕ) (q v Δ l r : ℝ) : ℝ≥0∞ :=
  ∑ m ∈ Finset.range (M+1), ∑ w : Fin (2*m) → Vertex N,
    traversalWordMass N I O root m w * conditionalTraversalSlice N I O root m w
      (lowOutwardRecordTest m (r7WordHighOccupation N c root m w q v Δ)) l r

end TorusCoverTime.Blocks.B
