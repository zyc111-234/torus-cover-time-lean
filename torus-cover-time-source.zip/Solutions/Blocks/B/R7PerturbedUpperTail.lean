import Solutions.Blocks.B.R7PerturbedConcentrationRate
import Solutions.Blocks.B.R7SquareRootConcentration

/-! The perturbed-radius upper tail, including v < Δ and the empty product.
Only an upper tail is required by the grid/window argument. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

theorem square_root_bernstein_scale_all (m : ℕ) (hm : 0 < m) (w v Δ : ℝ)
    (hw : 0 < w) (hv : 0 ≤ v) (hΔ : 0 ≤ Δ) (hmv : (m:ℝ)*w ≤ v^2) :
    Δ^2/(4*w) ≤ min (((v+Δ)*Δ/2)^2/((m:ℝ)*w^2)) (((v+Δ)*Δ/2)/w) := by
  have hm0 : 0 < (m:ℝ) := by exact_mod_cast hm
  apply le_min
  · apply (div_le_div_iff₀ (by positivity : 0 < 4*w) (by positivity : 0 < (m:ℝ)*w^2)).mpr
    have hsq : v^2 ≤ (v+Δ)^2 := by nlinarith [mul_nonneg hv hΔ]
    nlinarith [mul_le_mul_of_nonneg_right (hmv.trans hsq) (mul_nonneg (sq_nonneg Δ) hw.le)]
  · calc
      _ = (Δ^2/4)/w := by ring
      _ ≤ ((v+Δ)*Δ/2)/w := div_le_div_of_nonneg_right
        (by nlinarith [mul_nonneg hv hΔ]) hw.le

theorem sqrt_bernstein_upper_tail_all {Ω : Type*} [MeasurableSpace Ω]
    (μ : Measure Ω) [IsFiniteMeasure μ] (S : Ω → ℝ) (M : ℝ)
    (m : ℕ) (hm : 0 < m) (w v Δ c : ℝ) (hw : 0 < w) (hv : 0 ≤ v)
    (hmv : (m:ℝ)*w ≤ v^2) (hΔ : 0 ≤ Δ) (hc : 0 ≤ c)
    (hS : ∀ ω, 0 ≤ S ω) (hmean : M ≤ v^2+v*Δ/2)
    (htail : ∀ z : ℝ, 0 ≤ z → μ.real {ω | z < |S ω-M|} ≤
      2*Real.exp (-c*min (z^2/((m:ℝ)*w^2)) (z/w))) :
    μ.real {ω | v+Δ < Real.sqrt (S ω)} ≤ 2*Real.exp (-(c/4)*Δ^2/w) := by
  have hset : {ω | v+Δ < Real.sqrt (S ω)} ⊆ {ω | (v+Δ)*Δ/2 < |S ω-M|} := by
    intro ω hω
    have hs : (v+Δ)^2 < S ω := by
      have ht := mul_self_lt_mul_self (add_nonneg hv hΔ) hω
      nlinarith [Real.sq_sqrt (hS ω)]
    have ht : (v+Δ)*Δ/2 < S ω-M := by nlinarith [mul_nonneg hv hΔ]
    exact ht.trans_le (le_abs_self _)
  apply (measureReal_mono (μ := μ) hset).trans ((htail _ (by positivity)).trans _)
  apply mul_le_mul_of_nonneg_left _ (by norm_num : (0:ℝ) ≤ 2)
  apply Real.exp_le_exp.mpr
  have he := mul_le_mul_of_nonneg_left (square_root_bernstein_scale_all m hm w v Δ hw hv hΔ hmv) hc
  rw [show c*(Δ^2/(4*w)) = (c/4)*Δ^2/w by ring] at he
  simpa only [neg_mul,neg_div] using neg_le_neg he

theorem r7_perturbed_mean_sum_center (hWalk : WalkModelRegular) (γ : ℝ)
    (hγ : 0 < γ) (hγ1 : γ < 1) :
    ∀ᶠ q : ℝ in atTop, ∀ N : Size, ∀ c : Vertex N, ∀ m : ℕ,
      ∀ a b : Fin m → Vertex N,
      2*(r7PerturbedOuter q (q^γ)+1) < N.val →
      (∀ i, |periodicDistance (a i) c-r7PerturbedInner q (q^γ)| ≤ 2) →
      (∀ i, diskExteriorNeighbor N c (r7PerturbedOuter q (q^γ)) (b i)) →
      |harmonicExitMeanSum N c (Real.exp (q+1)) (r7PerturbedOuter q (q^γ)) m a b-
        (m:ℝ)*r7PerturbedWidth q (q^γ)| ≤
        (r7PerturbedMeanConstant*Real.exp (-r7MeanExponent*q^γ))*((m:ℝ)*r7PerturbedWidth q (q^γ)) := by
  filter_upwards [r7_perturbed_mean_center hWalk γ hγ hγ1,
    r7_perturbed_parameter_geometry γ hγ hγ1] with q hm hg
  intro N c m a b hsmall ha hb
  have he : (m:ℝ)*r7PerturbedWidth q (q^γ) = ∑ _i : Fin m, r7PerturbedWidth q (q^γ) := by simp
  rw [he,harmonicExitMeanSum,← Finset.sum_sub_distrib]
  apply (Finset.abs_sum_le_sum_abs _ _).trans
  calc
    _ ≤ ∑ _i : Fin m, r7PerturbedMeanConstant*q^γ*Real.exp (-r7MeanExponent*q^γ) :=
      Finset.sum_le_sum (fun i _ => hm N c (a i) (b i) hsmall (ha i) (hb i))
    _ ≤ ∑ _i : Fin m, r7PerturbedMeanConstant*r7PerturbedWidth q (q^γ)*Real.exp (-r7MeanExponent*q^γ) := by
      apply Finset.sum_le_sum
      intro i _
      exact mul_le_mul_of_nonneg_right
        (mul_le_mul_of_nonneg_left hg.2.2.2.2.2.2.1 r7PerturbedMeanConstant_pos.le) (Real.exp_pos _).le
    _ = _ := by simp; ring

theorem r7_perturbed_exactExitProduct_probability (γ : ℝ) (hγ : 0 < γ) (hγ1 : γ < 1) :
    ∀ᶠ q : ℝ in atTop, ∀ N : Size, ∀ c : Vertex N, ∀ m : ℕ,
      ∀ a b : Fin m → Vertex N,
      2*(r7PerturbedOuter q (q^γ)+1) < N.val →
      (∀ i, |periodicDistance (a i) c-r7PerturbedInner q (q^γ)| ≤ 2) →
      (∀ i, diskExteriorNeighbor N c (r7PerturbedOuter q (q^γ)) (b i)) →
      IsProbabilityMeasure (exactExitProductLaw N (torusDisk N c (r7PerturbedOuter q (q^γ))) m a b) := by
  filter_upwards [r7_perturbed_endpoint_probability γ hγ hγ1] with q hp
  intro N c m a b hsmall ha hb
  have hi (i : Fin m) : IsProbabilityMeasure
      (exactExitLaw N (torusDisk N c (r7PerturbedOuter q (q^γ))) (a i) (b i)) :=
    cond_isProbabilityMeasure (hp N c (a i) (b i) hsmall (ha i) (hb i)).ne'
  unfold exactExitProductLaw
  infer_instance

theorem r7_perturbed_occupation_sqrt_upper (hWalk : WalkModelRegular) (γ : ℝ)
    (hγ : 0 < γ) (hγ1 : γ < 1) :
    ∀ᶠ q : ℝ in atTop, ∀ N : Size, ∀ c : Vertex N, ∀ m : ℕ,
      ∀ a b : Fin m → Vertex N,
      2*(r7PerturbedOuter q (q^γ)+1) < N.val →
      (∀ i, |periodicDistance (a i) c-r7PerturbedInner q (q^γ)| ≤ 2) →
      (∀ i, diskExteriorNeighbor N c (r7PerturbedOuter q (q^γ)) (b i)) →
      ∀ v Δ : ℝ, 0 ≤ v → (m:ℝ)*r7PerturbedWidth q (q^γ) ≤ v^2 → 0 ≤ Δ →
      2*r7PerturbedMeanConstant*Real.exp (-r7MeanExponent*q^γ)*v ≤ Δ →
      (exactExitProductLaw N (torusDisk N c (r7PerturbedOuter q (q^γ))) m a b).real
        {ω | v+Δ < Real.sqrt (harmonicExitBlockSum N c (Real.exp (q+1)) (r7PerturbedOuter q (q^γ)) m a ω)} ≤
        2*Real.exp (-(r7PerturbedConcentrationConstant/4)*Δ^2/q^γ) := by
  filter_upwards [r7_perturbed_mean_sum_center hWalk γ hγ hγ1,
    r7_perturbed_occupation_concentration hWalk γ hγ hγ1,
    r7_perturbed_exactExitProduct_probability γ hγ hγ1,
    r7_perturbed_parameter_geometry γ hγ hγ1,
    (tendsto_rpow_atTop hγ).eventually_ge_atTop (1:ℝ)] with q hm hc hp hg hw
  intro N c m a b hsmall ha hb v Δ hv hmv hΔ hlower
  by_cases hm0 : m = 0
  · subst m
    have hn : ¬ v+Δ < 0 := not_lt_of_ge (add_nonneg hv hΔ)
    simp only [harmonicExitBlockSum,Finset.univ_eq_empty,Finset.sum_empty,Real.sqrt_zero,
      hn,Set.ofPred_false,measureReal_empty]
    positivity
  · have hw0 : 0 < q^γ := by linarith
    have hmean := (abs_le.mp (hm N c m a b hsmall ha hb)).2
    have hmean' : harmonicExitMeanSum N c (Real.exp (q+1)) (r7PerturbedOuter q (q^γ)) m a b ≤ v^2+v*Δ/2 := by
      have hε : 0 ≤ r7PerturbedMeanConstant*Real.exp (-r7MeanExponent*q^γ) :=
        mul_nonneg r7PerturbedMeanConstant_pos.le (Real.exp_pos _).le
      have hh := mul_le_mul_of_nonneg_left hmv hε
      have hlow := mul_le_mul_of_nonneg_right hlower hv
      nlinarith
    have hmv' : (m:ℝ)*q^γ ≤ v^2 :=
      (mul_le_mul_of_nonneg_left hg.2.2.2.2.2.2.1 (Nat.cast_nonneg m)).trans hmv
    have : IsProbabilityMeasure (exactExitProductLaw N (torusDisk N c (r7PerturbedOuter q (q^γ))) m a b) :=
      hp N c m a b hsmall ha hb
    exact sqrt_bernstein_upper_tail_all _ _ _ m (Nat.pos_of_ne_zero hm0) _ v Δ _ hw0 hv hmv' hΔ
      r7PerturbedConcentrationConstant_pos.le (harmonicExitBlockSum_nonneg N c _ _ m a) hmean'
      (hc N c m a b hsmall ha hb)

end TorusCoverTime.Blocks.B
