import Solutions.Blocks.B.BT11Goal

/-! Translation acts on the actual same path sample. Defect cardinality is
independent of the starting vertex, so no mixing loss is needed for this goal. -/
noncomputable section
open MeasureTheory Filter Set Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

theorem bt11_walk_translate (N : Size) (a e : Vertex N) (ω : WalkSample) (t : ℝ) :
    walk N (a+e) ω t=walk N a ω t+e := by
  unfold walk position
  split_ifs <;> abel

theorem bt11_localTime_translate (N : Size) (a x e : Vertex N) (ω : WalkSample) (t : ℝ) :
    localTime N (a+e) ω t (x+e)=localTime N a ω t x := by
  simp only [localTime,bt11_walk_translate,add_left_inj]

theorem bt11_softSet_translate (N : Size) (a e : Vertex N) (ω : WalkSample) (u t : ℝ) :
    softSet N (a+e) ω u t=(softSet N a ω u t).image (fun x => x+e) := by
  ext x
  simp only [softSet,Finset.mem_filter,Finset.mem_univ,true_and,Finset.mem_image]
  constructor
  · intro hx
    refine ⟨x-e,?_,sub_add_cancel x e⟩
    have he := bt11_localTime_translate N a (x-e) e ω t
    rw [sub_add_cancel] at he
    exact he ▸ hx
  · rintro ⟨y,hy,rfl⟩
    simpa only [bt11_localTime_translate] using hy

theorem bt11_wideDefects_translate (N : Size) (U : Finset (Vertex N)) (e : Vertex N) :
    wideDefects N (U.image (fun x => x+e))=(wideDefects N U).image (fun x => x+e) := by
  ext x
  simp only [wideDefects,Finset.mem_filter,Finset.mem_image]
  constructor
  · rintro ⟨⟨a,ha,rfl⟩,y,⟨b,hb,rfl⟩,hlo,hhi⟩
    exact ⟨a,⟨ha,b,hb,by simpa only [periodicDistance_translate] using hlo,
      by simpa only [periodicDistance_translate] using hhi⟩,rfl⟩
  · rintro ⟨a,⟨ha,b,hb,hlo,hhi⟩,rfl⟩
    exact ⟨⟨a,ha,rfl⟩,b+e,⟨b,hb,rfl⟩,by simpa only [periodicDistance_translate] using hlo,
      by simpa only [periodicDistance_translate] using hhi⟩

theorem bt11_defectCount_translate (N : Size) (a e : Vertex N) (ω : WalkSample) (u t : ℝ) :
    bt10DefectCount N (a+e) u (ω,t)=bt10DefectCount N a u (ω,t) := by
  unfold bt10DefectCount
  rw [bt11_softSet_translate,bt11_wideDefects_translate,Finset.card_image_of_injective]
  exact add_left_injective e

theorem bt11Bad_start_eq (N : Size) (a b : Vertex N) (u η t : ℝ) :
    bt11Bad N a u η t=bt11Bad N b u η t := by
  ext ω
  have he := bt11_defectCount_translate N b (a-b) ω u t
  rw [add_sub_cancel] at he
  simp only [bt11Bad,mem_setOf_eq,he]

theorem bt11_iSup_bad (N : Size) (u η t : ℝ) :
    (⨆ a : Vertex N, walkLaw (bt11Bad N a u η t))=walkLaw (bt11Bad N 0 u η t) := by
  simp only [bt11Bad_start_eq N _ 0,iSup_const]

theorem bt11_of_fixed_time
    (h : ∀ u : ℝ, 0<u → ∀ W : ℝ, 0≤W → ∀ η : ℝ, 0<η →
      Tendsto (fun N : Size => walkLaw (bt11Bad N 0 u η (phaseACenter N-W*timeScale N)))
        atTop (𝓝 0)) : BT11Conclusion := by
  apply wideDefectLimit_iff_earliest.mpr
  intro u hu W hW η hη
  simpa only [← bt11Bad_eq_earliest,bt11_iSup_bad] using h u hu W hW η hη

end TorusCoverTime.Blocks.B
