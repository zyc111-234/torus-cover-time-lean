import Solutions.Blocks.B.ExitOccupationRenewal

/-! Positive exponential occupation weights: exact one-step integration
on the original rate-one holding and direction sample. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

theorem holdingLaw_exp_lintegral (t : ℝ) (ht : t < 1) :
    (∫⁻ s, ENNReal.ofReal (Real.exp (t*max s 0)) ∂holdingLaw) = ENNReal.ofReal (1/(1-t)) := by
  have hr : 0 < 1-t := by linarith
  change (∫⁻ s, ENNReal.ofReal (Real.exp (t*max s 0)) ∂volume.withDensity (exponentialPDF 1)) = _
  rw [lintegral_withDensity_eq_lintegral_mul _
    (show Measurable (exponentialPDF 1) from (measurable_exponentialPDFReal 1).ennreal_ofReal)
    (by fun_prop)]
  simp only [Pi.mul_apply]
  have heq (s : ℝ) : exponentialPDF 1 s*ENNReal.ofReal (Real.exp (t*max s 0)) =
      ENNReal.ofReal (1/(1-t))*exponentialPDF (1-t) s := by
    by_cases hs : 0 ≤ s
    · rw [exponentialPDF_of_nonneg hs, exponentialPDF_of_nonneg hs, max_eq_left hs, one_mul,
        ← ENNReal.ofReal_mul (Real.exp_pos _).le,
        ← ENNReal.ofReal_mul (by positivity : 0 ≤ 1/(1-t))]
      congr 1
      rw [← Real.exp_add, show -(1*s)+t*s = -((1-t)*s) by ring]
      field_simp
    · simp only [exponentialPDF_eq, if_neg hs, ENNReal.ofReal_zero, zero_mul, mul_zero]
  simp_rw [heq]
  rw [lintegral_const_mul' _ _ ENNReal.ofReal_ne_top, lintegral_exponentialPDF_eq_one hr, mul_one]

theorem lintegral_uniform_direction (F : Fin 4 → ℝ≥0∞) :
    (∫⁻ d, F d ∂uniformOn (Set.univ : Set (Fin 4))) = (∑ d, F d)/4 := by
  have hu : uniformOn (Set.univ : Set (Fin 4)) = (4:ℝ≥0∞)⁻¹ • Measure.count := by
    ext s
    simp [uniformOn_univ, div_eq_mul_inv, mul_comm]
  rw [hu, lintegral_smul_measure, lintegral_count, tsum_fintype]
  simp only [smul_eq_mul, div_eq_mul_inv, mul_comm]

theorem lintegral_first_step_exp (t : ℝ) (ht : t < 1)
    (F : Fin 4 → WalkSample → ℝ≥0∞) (hF : ∀ d, Measurable (F d)) :
    (∫⁻ ω, ENNReal.ofReal (Real.exp (t*holdingTime ω 0))*F (ω 0).2 (walkTail ω) ∂walkLaw) =
      ENNReal.ofReal (1/(1-t))*((∑ d, ∫⁻ ω, F d ω ∂walkLaw)/4) := by
  let G := fun p : (ℝ × Fin 4) × WalkSample => ENNReal.ofReal (Real.exp (t*max p.1.1 0))*F p.1.2 p.2
  have hf : Measurable (fun p : Fin 4 × WalkSample => F p.1 p.2) :=
    measurable_from_prod_countable_right hF
  have hG : Measurable G := (show Measurable (fun p : (ℝ × Fin 4) × WalkSample =>
    ENNReal.ofReal (Real.exp (t*max p.1.1 0))) by fun_prop).mul
      (hf.comp (measurable_fst.snd.prodMk measurable_snd))
  have hmap := lintegral_map' hG.aemeasurable
    ((measurable_pi_apply 0).prodMk measurable_walkTail).aemeasurable (μ := walkLaw)
  rw [first_step_tail_law, lintegral_prod _ hG.aemeasurable] at hmap
  change _ = ∫⁻ ω, ENNReal.ofReal (Real.exp (t*holdingTime ω 0))*F (ω 0).2 (walkTail ω) ∂walkLaw at hmap
  rw [← hmap]
  simp only [G, lintegral_const_mul' _ _ ENNReal.ofReal_ne_top]
  let L := fun d => ∫⁻ ω, F d ω ∂walkLaw
  have hm : Measurable (fun p : ℝ × Fin 4 => ENNReal.ofReal (Real.exp (t*max p.1 0))*L p.2) :=
    (show Measurable (fun p : ℝ × Fin 4 => ENNReal.ofReal (Real.exp (t*max p.1 0))) by fun_prop).mul
      ((measurable_of_finite L).comp measurable_snd)
  rw [show stepLaw = holdingLaw.prod (uniformOn (Set.univ : Set (Fin 4))) from rfl,
    lintegral_prod _ hm.aemeasurable]
  simp_rw [lintegral_const_mul' _ _ ENNReal.ofReal_ne_top, lintegral_uniform_direction]
  rw [lintegral_mul_const _ (by fun_prop), holdingLaw_exp_lintegral t ht]

end TorusCoverTime.Blocks.B
