import Solutions.Blocks.B.PinnedSlabMoments
import Solutions.Blocks.B.DiskHarmonicMeasure

/-! A concrete coarse Gaussian probe, with both local and full source energy
cutoffs. Its probability is bounded below using the actual pinned covariance,
not a conditional-moment assumption. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal NNReal
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

theorem coarseProbe_g_pos : 0 < g := by unfold g; positivity

def coarseProbeRadialConstant : ℝ := (8*greenIncrementConstant+4)/g

theorem coarseProbeRadialConstant_pos : 0 < coarseProbeRadialConstant := by
  have := greenIncrementConstant_pos
  have := coarseProbe_g_pos
  unfold coarseProbeRadialConstant
  positivity

def pinnedWeightedEnergy (N : Size) (root : Vertex N) (U : Vertex N → ℝ) (ξ : FiniteFieldSample N) : ℝ :=
  (∑ z, U z*D.pinnedField N root ξ z^2)/(2*g)

theorem pinned_square_integrable (N : Size) (root z : Vertex N) :
    Integrable (fun ξ => D.pinnedField N root ξ z^2) (finiteFieldLaw N) := by
  have hh := (D.pinnedField_memLp N root z).integrable_mul (D.pinnedField_memLp N root z)
  change Integrable (fun ξ => D.pinnedField N root ξ z*D.pinnedField N root ξ z) (finiteFieldLaw N) at hh
  simpa only [pow_two] using hh

theorem pinnedWeightedEnergy_integrable (N : Size) (root : Vertex N) (U : Vertex N → ℝ) :
    Integrable (pinnedWeightedEnergy N root U) (finiteFieldLaw N) :=
  (integrable_finsetSum _ fun z _ => (pinned_square_integrable N root z).const_mul (U z)).div_const (2*g)

theorem pinnedWeightedEnergy_measurable (N : Size) (root : Vertex N) (U : Vertex N → ℝ) :
    Measurable (pinnedWeightedEnergy N root U) :=
  (Finset.measurable_sum _ fun z _ => ((pinned_coordinate_measurable N root z).pow_const 2).const_mul (U z)).div_const (2*g)

theorem pinnedWeightedEnergy_nonneg (N : Size) (root : Vertex N) (U : Vertex N → ℝ)
    (hU : ∀ z, 0 ≤ U z) (ξ : FiniteFieldSample N) : 0 ≤ pinnedWeightedEnergy N root U ξ :=
  div_nonneg (Finset.sum_nonneg fun z _ => mul_nonneg (hU z) (sq_nonneg _)) (by have := coarseProbe_g_pos; positivity)

theorem pinned_weighted_slab_integral (N : Size) (root x : Vertex N) (U : Vertex N → ℝ)
    (hU : ∀ z, 0 ≤ U z) (hsum : ∑ z, U z = 1) (q : ℝ) (hq : 1 ≤ q)
    (hlocal : ∀ z, U z ≠ 0 → Real.log (2+periodicDistance z x) ≤ q+3)
    (hV : 1 ≤ pinnedCoordinateVariance N root x) (hVG : greenDiagonal N ≤ pinnedCoordinateVariance N root x) :
    (∫ ξ in pinnedSlab N root x, pinnedWeightedEnergy N root U ξ ∂finiteFieldLaw N) ≤
      coarseProbeRadialConstant*q*(finiteFieldLaw N).real (pinnedSlab N root x) := by
  let P := (finiteFieldLaw N).real (pinnedSlab N root x)
  let K := 4*greenIncrementConstant*(q+3)+8
  have hVp : 0 < pinnedCoordinateVariance N root x := by linarith
  have hratio : greenDiagonal N/pinnedCoordinateVariance N root x ≤ 1 :=
    (div_le_one hVp).mpr hVG
  have hterm (z : Vertex N) : U z*(∫ ξ in pinnedSlab N root x, D.pinnedField N root ξ z^2 ∂finiteFieldLaw N) ≤ U z*(K*P) := by
    by_cases hz : U z = 0
    · simp [hz]
    · apply mul_le_mul_of_nonneg_left _ (hU z)
      apply (pinned_slab_square_integral N root x z hVp).trans
      apply mul_le_mul_of_nonneg_right _ measureReal_nonneg
      have hl := mul_le_mul_of_nonneg_left (hlocal z hz) (by have := greenIncrementConstant_pos; positivity : 0 ≤ 4*greenIncrementConstant)
      have he : 8*greenDiagonal N/pinnedCoordinateVariance N root x = 8*(greenDiagonal N/pinnedCoordinateVariance N root x) := by ring
      rw [he]
      dsimp only [K]
      linarith
  have hK : K/(2*g) ≤ coarseProbeRadialConstant*q := by
    apply (div_le_iff₀ (by have := coarseProbe_g_pos; positivity : 0 < 2*g)).mpr
    have he : coarseProbeRadialConstant*q*(2*g) = 2*(8*greenIncrementConstant+4)*q := by
      unfold coarseProbeRadialConstant
      field_simp [coarseProbe_g_pos.ne']
      <;> ring
    rw [he]
    dsimp only [K]
    nlinarith [greenIncrementConstant_pos]
  unfold pinnedWeightedEnergy
  rw [integral_div,integral_finsetSum _ (fun z _ => ((pinned_square_integrable N root z).const_mul (U z)).integrableOn)]
  simp_rw [integral_const_mul]
  calc
    _ ≤ (∑ z, U z*(K*P))/(2*g) := div_le_div_of_nonneg_right
      (Finset.sum_le_sum (fun z _ => hterm z)) (by have := coarseProbe_g_pos; positivity)
    _ = (K/(2*g))*P := by rw [← Finset.sum_mul,hsum,one_mul]; ring
    _ ≤ _ := mul_le_mul_of_nonneg_right hK measureReal_nonneg

def pinnedCoarseProbe (N : Size) (root x : Vertex N) (U : Vertex N → ℝ) (q : ℝ) : Set (FiniteFieldSample N) :=
  {ξ | |D.pinnedField N root ξ x| ≤ 1 ∧
    pinnedWeightedEnergy N root U ξ ≤ 4*(coarseProbeRadialConstant*q) ∧
      D.pinnedEnergy N root ξ ≤ 4*(8*vertexCount N*greenDiagonal N)}

theorem pinnedCoarseProbe_measurable (N : Size) (root x : Vertex N) (U : Vertex N → ℝ) (q : ℝ) :
    MeasurableSet (pinnedCoarseProbe N root x U q) :=
  (pinnedSlab_measurable N root x).inter
    ((measurableSet_le (pinnedWeightedEnergy_measurable N root U) measurable_const).inter
      (measurableSet_le (Finset.measurable_sum _ fun z _ => (pinned_coordinate_measurable N root z).pow_const 2) measurable_const))

theorem pinned_coarse_probe_half_slab (N : Size) (root x : Vertex N) (U : Vertex N → ℝ)
    (hU : ∀ z, 0 ≤ U z) (hsum : ∑ z, U z = 1) (q : ℝ) (hq : 1 ≤ q)
    (hlocal : ∀ z, U z ≠ 0 → Real.log (2+periodicDistance z x) ≤ q+3)
    (hV : 1 ≤ pinnedCoordinateVariance N root x) (hVG : greenDiagonal N ≤ pinnedCoordinateVariance N root x) :
    (finiteFieldLaw N).real (pinnedSlab N root x)/2 ≤ (finiteFieldLaw N).real (pinnedCoarseProbe N root x U q) := by
  let S := pinnedSlab N root x
  let A := coarseProbeRadialConstant*q
  let B := 8*vertexCount N*greenDiagonal N
  have he : ((finiteFieldLaw N).restrict S).real univ = (finiteFieldLaw N).real S := by
    simp only [Measure.real,Measure.restrict_apply MeasurableSet.univ,univ_inter]
  have hWm : Measurable (D.pinnedEnergy N root) :=
    Finset.measurable_sum _ fun z _ => (pinned_coordinate_measurable N root z).pow_const 2
  have hWi : Integrable (D.pinnedEnergy N root) (finiteFieldLaw N) :=
    integrable_finsetSum _ fun z _ => pinned_square_integrable N root z
  have hVA : (∫ ξ, pinnedWeightedEnergy N root U ξ ∂(finiteFieldLaw N).restrict S) ≤ A*((finiteFieldLaw N).restrict S).real univ := by
    rw [he]
    exact pinned_weighted_slab_integral N root x U hU hsum q hq hlocal hV hVG
  have hWB : (∫ ξ, D.pinnedEnergy N root ξ ∂(finiteFieldLaw N).restrict S) ≤ B*((finiteFieldLaw N).restrict S).real univ := by
    rw [he]
    exact pinned_slab_energy_integral N root x hV
  have hh := two_quadratic_cutoffs_mass ((finiteFieldLaw N).restrict S) (pinnedWeightedEnergy N root U)
    (D.pinnedEnergy N root) (pinnedWeightedEnergy_integrable N root U).integrableOn hWi.integrableOn
    (pinnedWeightedEnergy_measurable N root U) hWm (pinnedWeightedEnergy_nonneg N root U hU)
    (D.pinnedEnergy_nonneg N root) A B (by dsimp [A]; have := coarseProbeRadialConstant_pos; positivity)
    (by dsimp [B]; have := vertexCount_pos N; have := greenDiagonal_pos N; positivity) hVA hWB
  rw [he] at hh
  have hE : MeasurableSet {ξ | pinnedWeightedEnergy N root U ξ ≤ 4*A ∧ D.pinnedEnergy N root ξ ≤ 4*B} :=
    (measurableSet_le (pinnedWeightedEnergy_measurable N root U) measurable_const).inter
      (measurableSet_le hWm measurable_const)
  have hset : {ξ | pinnedWeightedEnergy N root U ξ ≤ 4*A ∧ D.pinnedEnergy N root ξ ≤ 4*B} ∩ S =
      pinnedCoarseProbe N root x U q := by ext ξ; simp [S,A,B,pinnedSlab,pinnedCoarseProbe,and_comm,and_left_comm]
  simpa only [Measure.real,Measure.restrict_apply hE,hset] using hh

theorem pinned_coarse_probe_mass (N : Size) (root x : Vertex N) (U : Vertex N → ℝ)
    (hU : ∀ z, 0 ≤ U z) (hsum : ∑ z, U z = 1) (q : ℝ) (hq : 1 ≤ q)
    (hlocal : ∀ z, U z ≠ 0 → Real.log (2+periodicDistance z x) ≤ q+3)
    (hV : 1 ≤ pinnedCoordinateVariance N root x) (hVG : greenDiagonal N ≤ pinnedCoordinateVariance N root x) :
    Real.exp (-(1:ℝ)/2)/Real.sqrt (2*Real.pi*pinnedCoordinateVariance N root x) ≤
      (finiteFieldLaw N).real (pinnedCoarseProbe N root x U q) := by
  have h1 := pinned_slab_mass N root x hV
  have h2 := pinned_coarse_probe_half_slab N root x U hU hsum q hq hlocal hV hVG
  have he : 2*Real.exp (-(1:ℝ)/2)/Real.sqrt (2*Real.pi*pinnedCoordinateVariance N root x) =
      2*(Real.exp (-(1:ℝ)/2)/Real.sqrt (2*Real.pi*pinnedCoordinateVariance N root x)) := by ring
  rw [he] at h1
  linarith

end TorusCoverTime.Blocks.B
