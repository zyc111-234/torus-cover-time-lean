import Solutions.Blocks.B.KilledHilbert

/-! Exact spectral expansion of the actual stationary hitting-time survival probability. -/

noncomputable section
open Classical Filter
open scoped BigOperators ENNReal RealInnerProductSpace
namespace TorusCoverTime.Blocks.B

def killedStart (N : Size) (A : Finset (Vertex N)) : KilledSpace N A :=
  killedLift N A (complementIndicator N A) (by intro x hx; simp [complementIndicator, hx])

lemma killedStart_inner (N : Size) (A : Finset (Vertex N)) (f : KilledSpace N A) :
    ⟪killedStart N A, f⟫ = ∑ x : Vertex N, killedValue f x := by
  rw [killed_inner]
  apply Finset.sum_congr rfl
  intro x _
  change (if x ∈ A then (0 : ℝ) else 1) * killedValue f x = _
  split_ifs with hx
  · rw [killedValue_vanishes f x hx, mul_zero]
  · exact one_mul _

lemma killedStart_inner_self (N : Size) (A : Finset (Vertex N)) :
    ⟪killedStart N A, killedStart N A⟫ = vertexCount N - A.card := by
  rw [killedStart_inner]
  change (∑ x : Vertex N, if x ∈ A then (0 : ℝ) else 1) = _
  have hterm (x : Vertex N) : (if x ∈ A then (0 : ℝ) else 1) =
      1 - if x ∈ A then 1 else 0 := by split_ifs <;> norm_num
  simp only [hterm, Finset.sum_sub_distrib]
  simp [vertexCount, Fintype.card_prod, ZMod.card, pow_two]

lemma killedTransition_iterate_value (N : Size) (A : Finset (Vertex N)) (n : ℕ) :
    killedValue ((killedTransition N A)^[n] (killedStart N A)) =
      fun x => discreteSurvival N x A n := by
  rw [discreteSurvival_eq_iterate]
  induction n with
  | zero => rfl
  | succ n ih =>
    rw [Function.iterate_succ_apply', Function.iterate_succ_apply',
      killedTransition_value, ih]

lemma killedBasis_inner_iterate (N : Size) (A : Finset (Vertex N))
    (i : Fin (Module.finrank ℝ (KilledSpace N A))) (f : KilledSpace N A) (n : ℕ) :
    ⟪killedBasis N A i, (killedTransition N A)^[n] f⟫ =
      (1 - killedModeRate N A i) ^ n * ⟪killedBasis N A i, f⟫ := by
  induction n with
  | zero => simp
  | succ n ih =>
    calc
      ⟪killedBasis N A i, (killedTransition N A)^[n + 1] f⟫ =
          ⟪killedTransition N A (killedBasis N A i), (killedTransition N A)^[n] f⟫ := by
        rw [Function.iterate_succ_apply']
        exact ((killedTransition_symmetric N A) _ _).symm
      _ = (1 - killedModeRate N A i) *
          ⟪killedBasis N A i, (killedTransition N A)^[n] f⟫ := by
        rw [killedBasis_eigen]
        exact real_inner_smul_left (killedBasis N A i)
          ((killedTransition N A)^[n] f) (1 - killedModeRate N A i)
      _ = _ := by rw [ih, pow_succ]; ring

lemma killed_inner_iterate (N : Size) (A : Finset (Vertex N))
    (f : KilledSpace N A) (n : ℕ) :
    ⟪f, (killedTransition N A)^[n] f⟫ =
      ∑ i, ⟪killedBasis N A i, f⟫ ^ 2 * (1 - killedModeRate N A i) ^ n := by
  rw [← (killedBasis N A).sum_inner_mul_inner f ((killedTransition N A)^[n] f)]
  apply Finset.sum_congr rfl
  intro i _
  rw [killedBasis_inner_iterate, real_inner_comm f (killedBasis N A i)]
  ring

def killedWeight (N : Size) (A : Finset (Vertex N))
    (i : Fin (Module.finrank ℝ (KilledSpace N A))) : ℝ :=
  ⟪killedBasis N A i, killedStart N A⟫ ^ 2 / vertexCount N

lemma killedWeight_nonneg (N : Size) (A : Finset (Vertex N))
    (i : Fin (Module.finrank ℝ (KilledSpace N A))) : 0 ≤ killedWeight N A i :=
  div_nonneg (sq_nonneg _) (vertexCount_pos N).le

lemma killedWeight_sum (N : Size) (A : Finset (Vertex N)) :
    (∑ i, killedWeight N A i) = 1 - (A.card : ℝ) / vertexCount N := by
  simp only [killedWeight, ← Finset.sum_div]
  rw [(killedBasis N A).sum_sq_inner_right, ← real_inner_self_eq_norm_sq,
    killedStart_inner_self, sub_div, div_self (vertexCount_pos N).ne']

lemma poisson_real_hasSum (t lam c : ℝ) :
    HasSum (fun n : ℕ => (Real.exp (-t) * t ^ n / (n.factorial : ℝ)) *
      (c * (1 - lam) ^ n)) (c * Real.exp (-lam * t)) := by
  have h := (NormedSpace.expSeries_div_hasSum_exp (t * (1 - lam))).mul_left
    (c * Real.exp (-t))
  have hterm (n : ℕ) : (Real.exp (-t) * t ^ n / (n.factorial : ℝ)) *
      (c * (1 - lam) ^ n) =
      (c * Real.exp (-t)) * ((t * (1 - lam)) ^ n / (n.factorial : ℝ)) := by
    rw [mul_pow]
    ring
  have hlimit : (c * Real.exp (-t)) * NormedSpace.exp (t * (1 - lam)) =
      c * Real.exp (-lam * t) := by
    rw [← Real.exp_eq_exp_ℝ, mul_assoc, ← Real.exp_add]
    congr 2
    ring
  simpa only [hterm, hlimit] using h

lemma stationary_survival_poisson_hasSum (hWalk : WalkModelRegular)
    (N : Size) (A : Finset (Vertex N)) (t : ℝ) (ht : 0 ≤ t) :
    HasSum (fun n : ℕ => (Real.exp (-t) * t ^ n / (n.factorial : ℝ)) *
      (⟪killedStart N A, (killedTransition N A)^[n] (killedStart N A)⟫ / vertexCount N))
      (stationarySurvival N A t) := by
  have hs := (hasSum_sum (s := (Finset.univ : Finset (Vertex N)))
    (fun x _ => killed_survival_poisson_hasSum hWalk N x A t ht)).div_const (vertexCount N)
  have hterm (n : ℕ) :
      (∑ x : Vertex N, (Real.exp (-t) * t ^ n / (n.factorial : ℝ)) *
        discreteSurvival N x A n) / vertexCount N =
      (Real.exp (-t) * t ^ n / (n.factorial : ℝ)) *
        (⟪killedStart N A, (killedTransition N A)^[n] (killedStart N A)⟫ / vertexCount N) := by
    rw [killedStart_inner, killedTransition_iterate_value, ← Finset.mul_sum, mul_div_assoc]
  simpa only [hterm, stationarySurvival] using hs

lemma stationary_survival_spectral (hWalk : WalkModelRegular)
    (N : Size) (A : Finset (Vertex N)) (t : ℝ) (ht : 0 ≤ t) :
    stationarySurvival N A t =
      ∑ i, killedWeight N A i * Real.exp (-killedModeRate N A i * t) := by
  have hs := hasSum_sum (s := Finset.univ)
    (fun i _ => poisson_real_hasSum t (killedModeRate N A i) (killedWeight N A i))
  have hterm (n : ℕ) : (∑ i, (Real.exp (-t) * t ^ n / (n.factorial : ℝ)) *
      (killedWeight N A i * (1 - killedModeRate N A i) ^ n)) =
      (Real.exp (-t) * t ^ n / (n.factorial : ℝ)) *
        (⟪killedStart N A, (killedTransition N A)^[n] (killedStart N A)⟫ / vertexCount N) := by
    rw [killed_inner_iterate, Finset.sum_div, Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro i _
    unfold killedWeight
    ring
  simp only [hterm] at hs
  exact (stationary_survival_poisson_hasSum hWalk N A t ht).unique hs

end TorusCoverTime.Blocks.B
