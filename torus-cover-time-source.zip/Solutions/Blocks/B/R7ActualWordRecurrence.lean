import Solutions.Blocks.B.TraversalWordWindowRecurrence

/-! R7 enlarged-window recurrence with the actual R6/R7 constants, for every
positive physical traversal word in the coarse range. No duration or
concentration bound is retained as an unproved hypothesis. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

def r7WordHighOccupation (N : Size) (c root : Vertex N) (m : ℕ) (w : Fin (2*m) → Vertex N)
    (q v Δ : ℝ) : Set ({j : Fin (2*m) // j.val % 2 = 1} → ℕ × WalkSample) :=
  {p | v+Δ < Real.sqrt (traversalWordOutwardOccupation N root m w
    (fun z => diskHarmonicWeight N c (Real.exp (q+1)) z/g) p)}

theorem r7WordHighOccupation_measurable (N : Size) (c root : Vertex N) (m : ℕ)
    (w : Fin (2*m) → Vertex N) (q v Δ : ℝ) : MeasurableSet (r7WordHighOccupation N c root m w q v Δ) :=
  measurableSet_lt measurable_const (traversalWordOutwardOccupation_measurable N root m w _).sqrt

theorem r6_superexponential_error_le_half (Q : ℝ) (hQ : 0 ≤ Q) :
    ENNReal.ofReal (Real.exp (-Real.exp (Q/2))) ≤ (1 : ℝ≥0∞)/2 := by
  have h1 : 1 ≤ Real.exp (Q/2) := Real.one_le_exp_iff.mpr (by positivity)
  have h2 : (2:ℝ) ≤ Real.exp 1 := by linarith [Real.add_one_le_exp (1:ℝ)]
  have he : Real.exp (-Real.exp (Q/2)) ≤ (1:ℝ)/2 := by
    calc
      _ ≤ Real.exp (-1) := Real.exp_le_exp.mpr (by linarith)
      _ = 1/Real.exp 1 := by rw [Real.exp_neg,one_div]
      _ ≤ _ := one_div_le_one_div_of_le (by norm_num) h2
  calc
    _ ≤ ENNReal.ofReal ((1:ℝ)/2) := ENNReal.ofReal_le_ofReal he
    _ = _ := by simp

theorem r7_actual_word_recurrence (hWalk : WalkModelRegular) (γ : ℝ) (hγ : 0 < γ) (hγ1 : γ ≤ 1) :
    ∀ᶠ N : Size in atTop, ∀ c root : Vertex N, ∀ m : ℕ, ∀ w : Fin (2*m) → Vertex N, ∀ q : ℝ,
      (logSize N)^(16*γ) ≤ q → q ≤ logSize N-(logSize N)^(16*γ) → (m:ℝ) ≤ (logSize N)^4+1 →
      root ∉ torusDisk N c (Real.exp (q+2*q^γ)) →
      walkLaw {ω | adaptiveExitWord N (alternatingDomain N (torusDisk N c (Real.exp (q+q^γ)))
        (torusDisk N c (Real.exp (q+2*q^γ)))) root (2*m) ω = w} ≠ 0 →
      ∀ v Δ : ℝ, 0 ≤ v → (m:ℝ)*q^γ ≤ v^2 → 0 ≤ Δ →
      2*r7MeanConstant*Real.exp (-r7MeanExponent*q^γ)*v ≤ Δ → Δ ≤ v → ∀ l r : ℝ,
      let I := torusDisk N c (Real.exp (q+q^γ))
      let O := torusDisk N c (Real.exp (q+2*q^γ))
      let d := (m:ℝ)*Real.exp (2*logSize N-(logSize N)^(16*γ))
      conditionalTraversalSlice N I O root m w (fun _ => 1) l r ≤
        conditionalTraversalSlice N I O root m w (lowOutwardRecordTest m (r7WordHighOccupation N c root m w q v Δ)) l r +
        2*ENNReal.ofReal (2*Real.exp (-(r7ConcentrationConstant/4)*Δ^2/q^γ)) *
          conditionalTraversalSlice N I O root m w (fun _ => 1) (l-d) (r+d) +
        ENNReal.ofReal (r-l)*ENNReal.ofReal (Real.exp (-Real.exp ((logSize N)^(16*γ)/2))) := by
  obtain ⟨q0,hq0⟩ := eventually_atTop.mp (r7_positive_word_upper hWalk γ hγ hγ1)
  have hQ := (tendsto_rpow_atTop (by positivity : 0 < 16*γ)).comp blockB_logSize_tendsto
  filter_upwards [r6_positive_word_duration hWalk γ hγ hγ1,r6_disk_radius_embedding γ hγ,
    hQ.eventually_ge_atTop q0] with N htail hsmall hqbase
  intro c root m w q hq hqL hm hr hw v Δ hv hmv hΔ hlo hhi l r
  dsimp only
  have hq0' : 0 ≤ q := (Real.rpow_nonneg (logSize_pos N).le _).trans hq
  have hI := torusDisk_nonempty N c (Real.exp (q+q^γ)) (Real.exp_pos _)
  have := traversalWordOutwardLaw_probability N (torusDisk N c (Real.exp (q+q^γ)))
    (torusDisk N c (Real.exp (q+2*q^γ))) root hI hr m w hw
  have hbad := hq0 q (hqbase.trans hq) N c root m w hr (hsmall q hq0' hqL) hw v Δ hv hmv hΔ hlo hhi
  have hb : traversalWordOutwardLaw N (torusDisk N c (Real.exp (q+q^γ)))
      (torusDisk N c (Real.exp (q+2*q^γ))) root m w (r7WordHighOccupation N c root m w q v Δ) ≤
        ENNReal.ofReal (2*Real.exp (-(r7ConcentrationConstant/4)*Δ^2/q^γ)) :=
    (ENNReal.le_ofReal_iff_toReal_le (measure_ne_top _ _) (by positivity)).mpr hbad
  exact actual_word_window_recurrence N _ _ root hI hr m w hw _
    (r7WordHighOccupation_measurable N c root m w q v Δ) l r _ _ _ hb
    (htail c root m w q hq hqL hm hr hw)
    (r6_superexponential_error_le_half _ (Real.rpow_nonneg (logSize_pos N).le _))

end TorusCoverTime.Blocks.B
