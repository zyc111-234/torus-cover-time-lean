import Solutions.Blocks.B.PeriodicBindingLS
import Solutions.Blocks.B.DirichletMassBounds

noncomputable section
open MeasureTheory ProbabilityTheory Classical
open scoped BigOperators
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

theorem periodicFieldLS_variance (N : Size) (x : Vertex N) :
    Var[fun ξ => periodicFieldLS N ξ x;finiteFieldLaw N]=greenDiagonal N/(2*g) := by
  rw [← covariance_self (periodicFieldLS_gaussian N x).aemeasurable]
  unfold periodicFieldLS
  rw [covariance_fun_div_left,covariance_fun_div_right,
    covariance_eq_sub (Blocks.C.finiteGaussianField_memLp N x) (Blocks.C.finiteGaussianField_memLp N x),
    Blocks.C.finiteGaussianField_mean,zero_mul,sub_zero]
  simp only [Pi.mul_apply]
  rw [Blocks.C.finiteGaussianField_covariance,
    greenKernel_diagonal,div_div,← sq,Real.sq_sqrt (by unfold g; positivity)]

theorem harmonicBindingLS_variance (N : Size) (root : Vertex N) (D : Finset (Vertex N))
    (hroot : root∉D) (x : Vertex N) :
    Var[fun ξ => harmonicBindingLS N root D ξ x;finiteFieldLaw N]=
      greenDiagonal N/(2*g)-dirichletClockLS N root D x+
        2*dirichletRowMass N root D x/vertexCount N-
        dirichletMassVariance N root D/(vertexCount N)^2 := by
  let X := fun ξ => dirichletFieldLS N root D ξ x-dirichletMass N root D ξ/vertexCount N
  let Y := fun ξ => harmonicBindingLS N root D ξ x
  have hm : MemLp (fun ξ => dirichletMass N root D ξ/vertexCount N) 2 (finiteFieldLaw N) := by
    simpa only [div_eq_mul_inv] using (dirichletMass_gaussian N root D).memLp_two.mul_const (vertexCount N)⁻¹
  have hX : MemLp X 2 (finiteFieldLaw N) :=
    (dirichletFieldLS_memLp N root D x).sub hm
  have hY : MemLp Y 2 (finiteFieldLaw N) := (harmonicBindingLS_gaussian N root D x).memLp_two
  have hi : IndepFun X Y (finiteFieldLaw N) :=
    (dirichletFieldLS_indep_harmonicBinding N root D hroot).comp
      (show Measurable (fun f : Vertex N → ℝ => f x-(∑ z, f z)/vertexCount N) by fun_prop)
      (measurable_pi_apply x)
  have hs := hi.variance_fun_add hX hY
  have he : (fun ξ => X ξ+Y ξ)=fun ξ => periodicFieldLS N ξ x :=
    funext (fun ξ => (periodicFieldLS_decomposition N root D ξ x).symm)
  rw [he,periodicFieldLS_variance] at hs
  have hv : Var[X;finiteFieldLaw N]=dirichletClockLS N root D x-
      2*dirichletRowMass N root D x/vertexCount N+dirichletMassVariance N root D/(vertexCount N)^2 := by
    dsimp only [X]
    rw [variance_fun_sub (dirichletFieldLS_memLp N root D x) hm,
      dirichletFieldLS_variance N root D hroot,covariance_fun_div_right,dirichletFieldLS_cov_mass N root D hroot]
    simp_rw [div_eq_mul_inv]
    rw [variance_mul_const,dirichletMass_variance N root D hroot]
    ring
  rw [hv] at hs
  dsimp only [Y] at hs
  linarith

def bt7BindingVarianceBound (ρ : ℝ) : ℝ :=
  greenDiagonalErrorConstant/(2*g)+bt6ClockError ρ+1/g+1

theorem bt7BindingVarianceBound_pos (ρ : ℝ) : 0<bt7BindingVarianceBound ρ := by
  have hg : 0<g := by unfold g; positivity
  have hc := greenDiagonalErrorConstant_pos
  have hd := bt6ClockError_pos ρ
  unfold bt7BindingVarianceBound
  positivity

theorem harmonicBindingLS_macroscopic_variance (N : Size) (root c x : Vertex N) (ρ : ℝ)
    (hρ : 0<ρ) (hR : 1≤ρ*(N.val:ℝ)) (hsmall : 2*(ρ*(N.val:ℝ)+1)<N.val)
    (hroot : root∉torusDisk N c (ρ*(N.val:ℝ))) (hx : periodicDistance x c≤ρ*(N.val:ℝ)/2) :
    Var[fun ξ => harmonicBindingLS N root (torusDisk N c (ρ*(N.val:ℝ))) ξ x;finiteFieldLaw N]≤
      bt7BindingVarianceBound ρ := by
  have hg : 0<g := by unfold g; positivity
  have hn := zero_lt_one.trans (size_real_gt_one N)
  have hn2 : 0<vertexCount N := by unfold vertexCount; positivity
  have hv0 : 0≤dirichletMassVariance N root (torusDisk N c (ρ*(N.val:ℝ))) := by
    rw [← dirichletMass_variance N root _ hroot]
    exact variance_nonneg _ _
  have hu := (dirichletRowMass_disk_bounds N root c (ρ*(N.val:ℝ)) (by linarith) hsmall hroot x).2
  have hrad : (ρ*(N.val:ℝ)+1)^2≤vertexCount N := by unfold vertexCount; nlinarith
  have hu' : dirichletRowMass N root (torusDisk N c (ρ*(N.val:ℝ))) x≤vertexCount N/(2*g) :=
    hu.trans (div_le_div_of_nonneg_right hrad (by positivity))
  have hm : 2*dirichletRowMass N root (torusDisk N c (ρ*(N.val:ℝ))) x/vertexCount N≤1/g := by
    apply (div_le_iff₀ hn2).mpr
    have hh := mul_le_mul_of_nonneg_left hu' (by norm_num : (0:ℝ)≤2)
    convert hh using 1 <;> ring
  have hd := (abs_le.mp (dirichlet_macroscopic_clock N root c x ρ hρ hR hsmall hroot hx)).1
  have hp := div_le_div_of_nonneg_right (abs_le.mp (greenDiagonal_log_error N)).2 (show 0≤2*g by positivity)
  have hp' : greenDiagonal N/(2*g)≤logSize N/2+greenDiagonalErrorConstant/(2*g) := by
    calc
      _ ≤ (greenDiagonalErrorConstant+g*logSize N)/(2*g) := by
        apply div_le_div_of_nonneg_right _ (by positivity)
        linarith [(abs_le.mp (greenDiagonal_log_error N)).2]
      _ = _ := by field_simp [hg.ne'] <;> ring
  rw [harmonicBindingLS_variance N root _ hroot]
  unfold bt7BindingVarianceBound
  have hh : 0≤dirichletMassVariance N root (torusDisk N c (ρ*(N.val:ℝ)))/(vertexCount N)^2 :=
    div_nonneg hv0 (sq_nonneg _)
  linarith

end TorusCoverTime.Blocks.B
