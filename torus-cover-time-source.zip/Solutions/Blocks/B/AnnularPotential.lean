import Solutions.Blocks.B.AnnularExit
import Solutions.Blocks.B.DiskGreenLogarithm

/-! The corrected actual torus potential is harmonic throughout a disk
annulus. Its logarithmic boundary values control the actual core-exit probability. -/

noncomputable section
open MeasureTheory Classical
namespace TorusCoverTime.Blocks.B

def diskPotential (N : Size) (c : Vertex N) (R : ℝ) (x : Vertex N) : ℝ :=
  greenDiagonal N - greenKernel N x c - (1 / vertexCount N) * diskBarrier N c R x

theorem diskPotential_harmonic (N : Size) (c : Vertex N) (R : ℝ) (hR : 0 ≤ R)
    (hsmall : 2*(R+1) < N.val) (x : Vertex N) (hx : x ∈ torusDisk N c R) (hxc : x ≠ c) :
    generator N (diskPotential N c R) x = 0 := by
  have hg := greenKernel_generator N x c
  rw [if_neg hxc] at hg
  have hb := diskBarrier_generator N c R hR hsmall x hx
  change generator N (((fun _ => greenDiagonal N) - (fun z => greenKernel N z c)) -
    (fun z => (1/vertexCount N) * diskBarrier N c R z)) x = 0
  rw [generator_sub, generator_sub, generator_const, generator_mul_left,
    show generator N (diskBarrier N c R) x = -1 by linarith]
  linarith

def annularPotentialError : ℝ := greenDiagonalErrorConstant + greenLogErrorConstant + 1

theorem diskPotential_log_error (N : Size) (c : Vertex N) (R : ℝ) (hR : 0 ≤ R)
    (hsmall : 2*(R+1) < N.val) (x : Vertex N) (hxc : x ≠ c) :
    |diskPotential N c R x - g*Real.log (periodicDistance x c)| ≤ annularPotentialError := by
  have hg := green_increment_log_error N x c hxc
  rw [greenKernel_diagonal] at hg
  have hb : |(1 / vertexCount N) * diskBarrier N c R x| ≤ 1 := by
    rw [abs_of_nonneg (mul_nonneg (one_div_nonneg.mpr (vertexCount_pos N).le) (diskBarrier_nonneg N c R x))]
    apply (mul_le_mul_of_nonneg_left (diskBarrier_le N c R x) (one_div_nonneg.mpr (vertexCount_pos N).le)).trans
    rw [one_div_mul_eq_div]
    apply (div_le_one (vertexCount_pos N)).mpr
    unfold vertexCount
    have hN : 0 < (N.val : ℝ) := zero_lt_one.trans (size_real_gt_one N)
    nlinarith
  unfold diskPotential annularPotentialError
  rw [show greenDiagonal N - greenKernel N x c - (1/vertexCount N)*diskBarrier N c R x -
      g*Real.log (periodicDistance x c) =
      (greenDiagonal N - greenKernel N x c - g*Real.log (periodicDistance x c)) -
        (1/vertexCount N)*diskBarrier N c R x by ring]
  exact (abs_sub _ _).trans (add_le_add hg hb)

def annularBoundaryError : ℝ := annularPotentialError + g*Real.log 3

theorem annularBoundaryError_pos : 0 < annularBoundaryError := by
  have := greenDiagonalErrorConstant_pos
  have := greenLogErrorConstant_pos
  have hl : 0 < Real.log 3 := Real.log_pos (by norm_num)
  unfold annularBoundaryError annularPotentialError g
  positivity

theorem diskPotential_radius_error (N : Size) (c : Vertex N) (R s : ℝ) (hR : 0 ≤ R)
    (hsmall : 2*(R+1) < N.val) (hs : 0 < s) (b : Vertex N)
    (hlo : s/2 ≤ periodicDistance b c) (hhi : periodicDistance b c ≤ 3*s) :
    |diskPotential N c R b - g*Real.log s| ≤ annularBoundaryError := by
  have hd : 0 < periodicDistance b c := (half_pos hs).trans_le hlo
  have hbc : b ≠ c := by intro he; subst b; rw [periodicDistance_self_zero] at hd; linarith
  have hg := diskPotential_log_error N c R hR hsmall b hbc
  have hl := log_comparable_radius s (periodicDistance b c) hs hlo hhi
  have hl' : |g*Real.log (periodicDistance b c)-g*Real.log s| ≤ g*Real.log 3 := by
    rw [← mul_sub, abs_mul, abs_of_pos (by unfold g; positivity)]
    exact mul_le_mul_of_nonneg_left hl (by unfold g; positivity)
  calc
    _ = |(diskPotential N c R b-g*Real.log (periodicDistance b c)) +
        (g*Real.log (periodicDistance b c)-g*Real.log s)| := by congr 1; ring
    _ ≤ _ := abs_add_le _ _
    _ ≤ _ := add_le_add hg hl'

theorem exitExtension_uniform_error (N : Size) (D : Finset (Vertex N)) (hD : D ≠ Finset.univ)
    (a : Vertex N) (f g : Vertex N → ℝ) (C : ℝ)
    (hf : ∀ b, exitHarmonic N D b a ≠ 0 → |f b - g b| ≤ C) :
    |exitExtension N D f a - exitExtension N D g a| ≤ C := by
  have he : exitExtension N D (f-g) a = exitExtension N D f a - exitExtension N D g a := by
    simp only [exitExtension, Pi.sub_apply, sub_mul, Finset.sum_sub_distrib]
  have h := exitExtension_abs_error N D hD a (f-g) 0 C (by simpa only [Pi.sub_apply, sub_zero] using hf)
  rwa [sub_zero, he] at h

theorem exitExtension_two_values (N : Size) (D K : Finset (Vertex N)) (hD : D ≠ Finset.univ)
    (a : Vertex N) (l u : ℝ) :
    exitExtension N D (fun b => if b ∈ K then l else u) a =
      u + (l-u) * walkLaw.real (exitsInto N D K a) := by
  rw [exitsInto_probability_sum]
  have hh (b : Vertex N) : (if b ∈ K then l else u)*exitHarmonic N D b a =
      u*exitHarmonic N D b a + (l-u)*(if b ∈ K then exitHarmonic N D b a else 0) := by
    split_ifs <;> ring
  unfold exitExtension
  simp only [hh, Finset.sum_add_distrib, ← Finset.mul_sum]
  rw [exitHarmonic_sum_one N D hD a, mul_one]
  congr 2
  simp

theorem annular_core_probability_balance (N : Size) (c : Vertex N) (r R : ℝ)
    (hr : 2 ≤ r) (hrR : r < R) (hsmall : 2*(R+1) < N.val) (a : Vertex N)
    (ha : a ∈ torusDisk N c R \ torusDisk N c r) :
    |g*(Real.log R-Real.log r)*
        walkLaw.real (exitsInto N (torusDisk N c R \ torusDisk N c r) (torusDisk N c r) a) -
      g*(Real.log R-Real.log (periodicDistance a c))| ≤ 2*annularBoundaryError := by
  let D := torusDisk N c R \ torusDisk N c r
  let F := diskPotential N c R
  let U := fun b => if b ∈ torusDisk N c r then g*Real.log r else g*Real.log R
  have hR0 : 0 < R := by linarith
  have hproper : D ≠ Finset.univ := proper_sdiff N _ _ (torusDisk_proper N c R hR0.le hsmall)
  have hF : ∀ b ∈ D, generator N F b = 0 := by
    intro b hb
    have hbc : b ≠ c := by
      intro he
      subst b
      have hmem : c ∈ torusDisk N c r := (mem_torusDisk N c c r).mpr (by rw [periodicDistance_self_zero]; linarith)
      exact (Finset.mem_sdiff.mp hb).2 hmem
    exact diskPotential_harmonic N c R hR0.le hsmall b (Finset.mem_sdiff.mp hb).1 hbc
  have hb : ∀ b, exitHarmonic N D b a ≠ 0 → |F b-U b| ≤ annularBoundaryError := by
    intro b hb
    have hs := exitHarmonic_annulus_geometry N c r R a b ha hb
    dsimp [F, U]
    split_ifs with hbK
    · have hbr := (mem_torusDisk N c b r).mp hbK
      have hbl := hs.1 hbK
      exact diskPotential_radius_error N c R r hR0.le hsmall (by linarith) b (by linarith) (by linarith)
    · have he := diskExteriorNeighbor_radius N c R b (hs.2 hbK)
      exact diskPotential_radius_error N c R R hR0.le hsmall hR0 b (by linarith [he.1]) (by linarith [he.2])
  have havg := exitExtension_uniform_error N D hproper a F U annularBoundaryError hb
  rw [← congrFun (harmonic_exit_representation N D hproper F hF) a,
    exitExtension_two_values N D (torusDisk N c r) hproper a (g*Real.log r) (g*Real.log R)] at havg
  have har : r ≤ periodicDistance a c := le_of_not_gt (fun h =>
    (Finset.mem_sdiff.mp ha).2 ((mem_torusDisk N c a r).mpr h))
  have hac : a ≠ c := by intro he; subst a; rw [periodicDistance_self_zero] at har; linarith
  have haerr := diskPotential_log_error N c R hR0.le hsmall a hac
  have hC : annularPotentialError ≤ annularBoundaryError := by
    have hl : 0 ≤ Real.log 3 := Real.log_nonneg (by norm_num)
    have hg : 0 ≤ g := by unfold g; positivity
    unfold annularBoundaryError
    linarith [mul_nonneg hg hl]
  have heq : g*(Real.log R-Real.log r)*walkLaw.real (exitsInto N D (torusDisk N c r) a) -
      g*(Real.log R-Real.log (periodicDistance a c)) =
      (F a - (g*Real.log R+(g*Real.log r-g*Real.log R)*walkLaw.real (exitsInto N D (torusDisk N c r) a))) -
      (F a-g*Real.log (periodicDistance a c)) := by ring
  change |g*(Real.log R-Real.log r)*walkLaw.real (exitsInto N D (torusDisk N c r) a) -
      g*(Real.log R-Real.log (periodicDistance a c))| ≤ _
  rw [heq]
  exact (abs_sub _ _).trans ((add_le_add havg (haerr.trans hC)).trans (by linarith))

end TorusCoverTime.Blocks.B
