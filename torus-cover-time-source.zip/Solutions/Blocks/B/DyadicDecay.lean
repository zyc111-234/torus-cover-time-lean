import Solutions.Blocks.B.FourierMixing

/-! Uniform summation of dyadic spatial-decay envelopes, with constants independent of cutoffs. -/

noncomputable section
open scoped BigOperators
namespace TorusCoverTime.Blocks.B

lemma dyadic_reciprocal_tail (a : ℝ) (ha : 0 < a) (m n : ℕ)
    (hm : 1 ≤ a * (2 : ℝ) ^ m) :
    (∑ j ∈ Finset.range n, 1 / (a * (2 : ℝ) ^ (m + j))) ≤ 2 := by
  have hg : (∑ j ∈ Finset.range n, (1 / 2 : ℝ) ^ j) ≤ 2 := by
    have h := (geom_sum_Ico_le_of_lt_one (m := 0) (n := n)
      (by norm_num : (0 : ℝ) ≤ 1 / 2) (by norm_num : (1 / 2 : ℝ) < 1))
    norm_num at h ⊢
    exact h
  have heq : (∑ j ∈ Finset.range n, 1 / (a * (2 : ℝ) ^ (m + j))) =
      (1 / (a * (2 : ℝ) ^ m)) * ∑ j ∈ Finset.range n, (1 / 2 : ℝ) ^ j := by
    rw [Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro j _
    rw [pow_add, div_pow]
    ring
  rw [heq]
  calc
    _ ≤ (1 / (a * (2 : ℝ) ^ m)) * 2 :=
      mul_le_mul_of_nonneg_left hg (by positivity)
    _ ≤ 2 := by
      have hr : 1 / (a * (2 : ℝ) ^ m) ≤ 1 :=
        (div_le_one (by positivity)).mpr hm
      linarith

lemma exists_dyadic_split (a : ℝ) (ha : 0 < a) :
    ∃ m : ℕ, 1 ≤ a * (2 : ℝ) ^ m ∧
      (∑ j ∈ Finset.range m, a * (2 : ℝ) ^ j) ≤ 2 := by
  by_cases ha1 : 1 ≤ a
  · exact ⟨0, by simpa using ha1, by norm_num⟩
  · have hsmall : a < 1 := lt_of_not_ge ha1
    have hinv : 1 ≤ 1 / a := (le_div_iff₀ ha).mpr (by linarith)
    obtain ⟨n, hn, hn'⟩ := exists_nat_pow_near hinv (by norm_num : (1 : ℝ) < 2)
    have hlo : 1 < a * (2 : ℝ) ^ (n + 1) := by
      have h := (div_lt_iff₀ ha).mp hn'
      nlinarith
    have hhi : a * (2 : ℝ) ^ (n + 1) ≤ 2 := by
      have h := (le_div_iff₀ ha).mp hn
      rw [pow_succ]
      nlinarith
    refine ⟨n + 1, hlo.le, ?_⟩
    rw [← Finset.mul_sum, geom_sum_eq (by norm_num : (2 : ℝ) ≠ 1)]
    norm_num
    nlinarith

lemma dyadic_min_sum (a : ℝ) (ha : 0 < a) (J : ℕ) :
    (∑ j ∈ Finset.range J, min (a * (2 : ℝ) ^ j) (1 / (a * (2 : ℝ) ^ j))) ≤ 4 := by
  obtain ⟨m, hm, hlow⟩ := exists_dyadic_split a ha
  have hlow' : (∑ j ∈ Finset.range m, min (a * (2 : ℝ) ^ j)
      (1 / (a * (2 : ℝ) ^ j))) ≤ 2 :=
    (Finset.sum_le_sum (fun j _ => min_le_left _ _)).trans hlow
  by_cases hJ : J ≤ m
  · have hsub : (∑ j ∈ Finset.range J, min (a * (2 : ℝ) ^ j)
        (1 / (a * (2 : ℝ) ^ j))) ≤
        ∑ j ∈ Finset.range m, min (a * (2 : ℝ) ^ j) (1 / (a * (2 : ℝ) ^ j)) := by
      apply Finset.sum_le_sum_of_subset_of_nonneg (Finset.range_mono hJ)
      intro j _ _
      positivity
    linarith
  · have hsum : J = m + (J - m) := by omega
    rw [hsum, Finset.sum_range_add]
    have htail : (∑ j ∈ Finset.range (J - m), min (a * (2 : ℝ) ^ (m + j))
        (1 / (a * (2 : ℝ) ^ (m + j)))) ≤ 2 :=
      (Finset.sum_le_sum (fun j _ => min_le_right _ _)).trans
        (dyadic_reciprocal_tail a ha m (J - m) hm)
    linarith

lemma cubic_envelope_le_min (q : ℝ) (hq : 0 < q) (s : ℕ) (hs : s = 1 ∨ s = 2) :
    q ^ s * min 1 (1 / q ^ 3) ≤ min q (1 / q) := by
  by_cases hq1 : q ≤ 1
  · have hqq : q ≤ 1 / q := (le_div_iff₀ hq).mpr (by nlinarith)
    rw [min_eq_left hqq]
    apply (mul_le_mul_of_nonneg_left (min_le_left (1 : ℝ) (1 / q ^ 3))
      (pow_nonneg hq.le s)).trans
    rcases hs with rfl | rfl <;> simp only [pow_one, mul_one] <;> nlinarith
  · have h1q : 1 ≤ q := le_of_lt (lt_of_not_ge hq1)
    have hqq : 1 / q ≤ q := (div_le_iff₀ hq).mpr (by nlinarith)
    rw [min_eq_right hqq]
    apply (mul_le_mul_of_nonneg_left (min_le_right (1 : ℝ) (1 / q ^ 3))
      (pow_nonneg hq.le s)).trans
    rw [mul_one_div]
    apply (div_le_div_iff₀ (pow_pos hq 3) hq).mpr
    rcases hs with rfl | rfl
    · simp only [pow_one, one_mul]
      nlinarith [mul_nonneg (sq_nonneg q) (sub_nonneg.mpr h1q)]
    · simp only [one_mul]
      nlinarith [show q ^ 2 * q = q ^ 3 by ring]

lemma dyadic_spatial_envelope_sum (a d : ℝ) (ha : 0 < a) (hd : 0 < d)
    (s : ℕ) (hs : s = 1 ∨ s = 2) (J : ℕ) :
    (∑ j ∈ Finset.range J, (a * (2 : ℝ) ^ j) ^ s *
      min 1 (1 / (a * (2 : ℝ) ^ j * d) ^ 3)) ≤ 4 / d ^ s := by
  apply (le_div_iff₀ (pow_pos hd s)).mpr
  rw [Finset.sum_mul]
  calc
    _ = ∑ j ∈ Finset.range J, (a * d * (2 : ℝ) ^ j) ^ s *
        min 1 (1 / (a * d * (2 : ℝ) ^ j) ^ 3) := by
      apply Finset.sum_congr rfl
      intro j _
      rw [show a * (2 : ℝ) ^ j * d = a * d * (2 : ℝ) ^ j by ring]
      simp only [mul_pow]
      ring
    _ ≤ ∑ j ∈ Finset.range J, min (a * d * (2 : ℝ) ^ j)
        (1 / (a * d * (2 : ℝ) ^ j)) := by
      apply Finset.sum_le_sum
      intro j _
      exact cubic_envelope_le_min _ (by positivity) s hs
    _ ≤ 4 := dyadic_min_sum (a * d) (mul_pos ha hd) J

end TorusCoverTime.Blocks.B
