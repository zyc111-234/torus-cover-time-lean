import Solutions.Blocks.B.ScaledSymbol
import Mathlib.Analysis.Calculus.BumpFunction.InnerProduct

/-! A fixed smooth annular cutoff and a nonsingular extension of its reciprocal walk symbol. -/

noncomputable section
open Filter
open scoped Topology ContDiff
namespace TorusCoverTime.Blocks.B

def frequencyBump : ContDiffBump (0 : ℝ) := ⟨1, 2, by norm_num, by norm_num⟩

@[fun_prop] lemma frequencyBump_contDiff : ContDiff ℝ ∞ (fun x : ℝ => frequencyBump x) :=
  frequencyBump.contDiff

lemma frequencyBump_one (x : ℝ) (hx : |x| ≤ 1) : frequencyBump x = 1 := by
  apply frequencyBump.one_of_mem_closedBall
  simpa [frequencyBump, Real.dist_eq] using hx

lemma frequencyBump_zero (x : ℝ) (hx : 2 ≤ |x|) : frequencyBump x = 0 := by
  apply frequencyBump.zero_of_le_dist
  simpa [frequencyBump, Real.dist_eq] using hx

def rectangleCutoff (x y : ℝ) : ℝ := frequencyBump x * frequencyBump y

def annularCutoff (x y : ℝ) : ℝ := rectangleCutoff x y - rectangleCutoff (2 * x) (2 * y)

lemma rectangleCutoff_nonneg (x y : ℝ) : 0 ≤ rectangleCutoff x y :=
  mul_nonneg frequencyBump.nonneg frequencyBump.nonneg

lemma rectangleCutoff_zero (x y : ℝ) (hxy : 2 ≤ |x| ∨ 2 ≤ |y|) : rectangleCutoff x y = 0 := by
  rcases hxy with hx | hy
  · simp [rectangleCutoff, frequencyBump_zero x hx]
  · simp [rectangleCutoff, frequencyBump_zero y hy]

lemma annularCutoff_zero_inner (x y : ℝ) (hx : |x| ≤ 1 / 2) (hy : |y| ≤ 1 / 2) :
    annularCutoff x y = 0 := by
  have hx' : |2 * x| ≤ 1 := by rw [abs_mul, abs_of_pos (by norm_num : (0 : ℝ) < 2)]; linarith
  have hy' : |2 * y| ≤ 1 := by rw [abs_mul, abs_of_pos (by norm_num : (0 : ℝ) < 2)]; linarith
  simp [annularCutoff, rectangleCutoff, frequencyBump_one x (by linarith),
    frequencyBump_one y (by linarith), frequencyBump_one (2 * x) hx', frequencyBump_one (2 * y) hy']

lemma annularCutoff_zero_outer (x y : ℝ) (hxy : 2 ≤ |x| ∨ 2 ≤ |y|) :
    annularCutoff x y = 0 := by
  have hscaled : 2 ≤ |2 * x| ∨ 2 ≤ |2 * y| := by
    simp only [abs_mul, abs_of_pos (by norm_num : (0 : ℝ) < 2)]
    rcases hxy with hx | hy
    · exact Or.inl (by linarith)
    · exact Or.inr (by linarith)
  rw [annularCutoff, rectangleCutoff_zero x y hxy,
    rectangleCutoff_zero (2 * x) (2 * y) hscaled, sub_self]

lemma annular_corrector_eq_zero (x y : ℝ) (hxy : annularCutoff x y ≠ 0) :
    rectangleCutoff (4 * x) (4 * y) = 0 := by
  apply rectangleCutoff_zero
  by_cases hx : 1 / 2 ≤ |x|
  · exact Or.inl (by rw [abs_mul, abs_of_pos (by norm_num : (0 : ℝ) < 4)]; linarith)
  · have hy : 1 / 2 ≤ |y| := by
      by_contra hy
      exact hxy (annularCutoff_zero_inner x y (le_of_not_ge hx) (le_of_not_ge hy))
    exact Or.inr (by rw [abs_mul, abs_of_pos (by norm_num : (0 : ℝ) < 4)]; linarith)

def annularDenominator (a x y : ℝ) : ℝ :=
  scaledSymbol a x y + rectangleCutoff (4 * x) (4 * y)

lemma scaled_argument_lt_pi (a x : ℝ) (ha : |a| ≤ 1 / 7) (hx : |x| ≤ 3) :
    |Real.pi * a * x| < Real.pi := by
  have h := mul_le_mul ha hx (abs_nonneg x) (by norm_num : (0 : ℝ) ≤ 1 / 7)
  have hp := mul_le_mul_of_nonneg_left h Real.pi_pos.le
  rw [abs_mul, abs_mul, abs_of_pos Real.pi_pos]
  nlinarith [Real.pi_pos]

lemma annularDenominator_pos (a x y : ℝ) (ha : |a| ≤ 1 / 7)
    (hx : |x| ≤ 3) (hy : |y| ≤ 3) : 0 < annularDenominator a x y := by
  by_cases hxy : x = 0 ∧ y = 0
  · simp [annularDenominator, scaledSymbol, rectangleCutoff, hxy.1, hxy.2,
      frequencyBump_one 0 (by norm_num)]
  · have hne : x ≠ 0 ∨ y ≠ 0 := by tauto
    exact add_pos_of_pos_of_nonneg
      (scaledSymbol_pos a x y (scaled_argument_lt_pi a x ha hx) (scaled_argument_lt_pi a y ha hy) hne)
      (rectangleCutoff_nonneg _ _)

@[fun_prop] lemma rectangleCutoff_contDiff :
    ContDiff ℝ ∞ (fun v : ℝ × ℝ => rectangleCutoff v.1 v.2) := by
  exact (frequencyBump.contDiff.comp contDiff_fst).mul (frequencyBump.contDiff.comp contDiff_snd)

@[fun_prop] lemma annularCutoff_contDiff :
    ContDiff ℝ ∞ (fun v : ℝ × ℝ => annularCutoff v.1 v.2) := by
  unfold annularCutoff rectangleCutoff
  fun_prop

@[fun_prop] lemma annularDenominator_contDiff :
    ContDiff ℝ ∞ (fun v : ℝ × (ℝ × ℝ) => annularDenominator v.1 v.2.1 v.2.2) := by
  unfold annularDenominator rectangleCutoff scaledSymbol
  fun_prop

def annularReciprocal (a x y : ℝ) : ℝ := annularCutoff x y / annularDenominator a x y

lemma annularReciprocal_eq (a x y : ℝ) :
    annularReciprocal a x y = annularCutoff x y / scaledSymbol a x y := by
  by_cases hxy : annularCutoff x y = 0
  · simp [annularReciprocal, hxy]
  · simp [annularReciprocal, annularDenominator, annular_corrector_eq_zero x y hxy]

lemma annularReciprocal_contDiffAt (a x y : ℝ) (ha : |a| ≤ 1 / 7)
    (hx : |x| ≤ 3) (hy : |y| ≤ 3) :
    ContDiffAt ℝ ∞ (fun v : ℝ × (ℝ × ℝ) => annularReciprocal v.1 v.2.1 v.2.2) (a, x, y) := by
  exact (annularCutoff_contDiff.comp contDiff_snd).contDiffAt.div
    annularDenominator_contDiff.contDiffAt (annularDenominator_pos a x y ha hx hy).ne'

lemma annularReciprocal_zero_outer (a x y : ℝ) (hxy : 2 ≤ |x| ∨ 2 ≤ |y|) :
    annularReciprocal a x y = 0 := by
  simp [annularReciprocal, annularCutoff_zero_outer x y hxy]

end TorusCoverTime.Blocks.B
