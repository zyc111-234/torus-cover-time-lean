import Solutions.Blocks.B.ExteriorOccupationIdentity
import Solutions.Blocks.B.NestedHarmonicSupport

/-! Actual harmonic averages after an inner traversal have a complete measurable exterior representation. -/
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B


def exteriorHarmonicOccupation (N : Size) (c root : Vertex N) (m : ℕ)
    (w : Fin (2*m) → Vertex N) (q : ℝ) : TraversalExteriorSample m × ℝ → ℝ :=
  exteriorOccupation N root m w (fun x => diskHarmonicWeight N c (Real.exp (q+1)) x/g)

theorem exteriorHarmonicOccupation_measurable (N : Size) (c root : Vertex N) (m : ℕ)
    (w : Fin (2*m) → Vertex N) (q : ℝ) : Measurable (exteriorHarmonicOccupation N c root m w q) :=
  exteriorOccupation_measurable N root m w _

theorem nested_harmonic_exterior_identity (N : Size) (c root : Vertex N) (γ q : ℝ)
    (hsep : r8NestedScale γ q+2*(r8NestedScale γ q)^γ < q)
    (hr : root ∉ torusDisk N c (Real.exp (r8NestedScale γ q+2*(r8NestedScale γ q)^γ)))
    (m : ℕ) (w : Fin (2*m) → Vertex N) :
    let I := torusDisk N c (Real.exp (r8NestedScale γ q+(r8NestedScale γ q)^γ))
    let O := torusDisk N c (Real.exp (r8NestedScale γ q+2*(r8NestedScale γ q)^γ))
    ∀ᵐ ω ∂walkLaw[|{ω | adaptiveExitWord N (alternatingDomain N I O) root (2*m) ω = w}],
      ∀ t, adaptiveExitTime N (alternatingDomain N I O) root (2*m) ω ≤ t →
      harmonicPathOccupation N c root q (ω,t) =
        exteriorHarmonicOccupation N c root m w q
          (traversalExteriorData N I O root m ω,t-adaptiveExitTime N (alternatingDomain N I O) root (2*m) ω) :=
  exteriorOccupation_actual_ae N _ _ (torusDisk_nonempty N c _ (Real.exp_pos _)) root hr _
    (nested_harmonic_potential_zero N c γ q hsep) m w


end TorusCoverTime.Blocks.B

