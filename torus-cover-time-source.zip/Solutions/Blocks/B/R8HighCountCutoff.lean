import Solutions.Blocks.B.R8SoftCoarseParameters
import Solutions.Blocks.B.R7CountObservable

/-! A deterministic prefix length selected solely by N and q. High actual
traversal counts contain this prefix; no soft block is selected adaptively. -/
noncomputable section
open Filter
open scoped Topology
namespace TorusCoverTime.Blocks.B

def r8HighCountCutoff (L q γ : ℝ) : ℕ := ⌈100*L^2/q^γ⌉₊

theorem r8_high_count_cutoff_lower (L q γ : ℝ) (hq : 0 < q) :
    100*L^2 ≤ (r8HighCountCutoff L q γ:ℝ)*q^γ :=
  (div_le_iff₀ (Real.rpow_pos_of_pos hq γ)).mp (Nat.le_ceil _)

theorem r8_high_count_cutoff_le (L q γ : ℝ) (m : ℕ) (hL : 0 ≤ L) (hq : 0 < q)
    (hY : 10*L < Real.sqrt (q^γ*(m:ℝ))) : r8HighCountCutoff L q γ ≤ m := by
  apply Nat.ceil_le.mpr
  apply (div_le_iff₀ (Real.rpow_pos_of_pos hq γ)).mpr
  have hs := Real.sq_sqrt (mul_nonneg (Real.rpow_pos_of_pos hq γ).le (Nat.cast_nonneg m))
  have hp := pow_le_pow_left₀ (by positivity : 0 ≤ 10*L) hY.le 2
  nlinarith only [hs,hp]

theorem r8_high_count_cutoff_upper (L q γ : ℝ) (hL : 10 ≤ L) (hq : 1 ≤ q^γ) :
    (r8HighCountCutoff L q γ:ℝ) ≤ L^4+1 := by
  have hw : 0 < q^γ := by linarith
  have hceil := (Nat.ceil_lt_add_one (div_nonneg (by positivity : 0 ≤ 100*L^2) hw.le)).le
  change (r8HighCountCutoff L q γ:ℝ) ≤ 100*L^2/q^γ+1 at hceil
  have hdiv : 100*L^2/q^γ ≤ 100*L^2 := (div_le_iff₀ hw).mpr (by nlinarith [mul_nonneg (show 0 ≤ q^γ-1 by linarith) (sq_nonneg L)])
  have hs : 100 ≤ L^2 := by nlinarith
  have hm := mul_le_mul_of_nonneg_right hs (sq_nonneg L)
  nlinarith only [hceil,hdiv,hm]

end TorusCoverTime.Blocks.B
