import Solutions.Blocks.B.ExitChainOccupationLaw

/-! R7.4/5 on selected occupation increments of one actual path, conditional
on a compatible finite endpoint word. Intermediate return segments are kept.
The time-integrated loop resampling and enlarged-window recursion are separate. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

theorem exitChain_selected_occupation_event (N : Size) (D : ℕ → Finset (Vertex N))
    (hD : ∀ k, ∃ b : Vertex N, b ∉ D k) (a b : ℕ → Vertex N) (n m : ℕ)
    (hp : ∀ j : Fin n, walkLaw (exitsThrough N (D j.val) (a j.val) (b j.val)) ≠ 0)
    (hab : ∀ k < n, b k = a (k+1)) (s : Fin m → Fin n) (hs : Function.Injective s)
    (U : Vertex N → ℝ) (D₀ : Finset (Vertex N)) (hDs : ∀ i, D (s i).val = D₀)
    (E : Set ℝ) (hE : MeasurableSet E) :
    (walkLaw[|exitChainEndpoints N D a b n]).real
      {ω | exitChainSelectedOccupation N D a U n m s ω ∈ E} =
      (exactExitProductLaw N D₀ m (fun i => a (s i).val) (fun i => b (s i).val)).real
        {ω | (∑ i, weightedExitOccupation N D₀ (a (s i).val) U (ω i)) ∈ E} := by
  have hm : Measurable (fun ω : Fin m → WalkSample =>
      ∑ i, weightedExitOccupation N D₀ (a (s i).val) U (ω i)) :=
    Finset.measurable_sum _ fun i _ => (weightedExitOccupation_measurable N D₀ (a (s i).val) U).comp
      (measurable_pi_apply i)
  have hh := congrArg (fun ν : Measure ℝ => ν E)
    (exitChain_selected_occupation_law N D hD a b n m hp hab s hs U D₀ hDs)
  rw [Measure.map_apply (exitChainSelectedOccupation_measurable N D hD a U n m s) hE,
    Measure.map_apply hm hE] at hh
  exact congrArg ENNReal.toReal hh

theorem r7_exitChain_sqrt_upper_concentration (hWalk : WalkModelRegular) (γ : ℝ)
    (hγ : 0 < γ) (hγ1 : γ ≤ 1) :
    ∀ᶠ q : ℝ in atTop, ∀ N : Size, ∀ c : Vertex N,
      ∀ D : ℕ → Finset (Vertex N), (∀ k, ∃ b : Vertex N, b ∉ D k) →
      ∀ a b : ℕ → Vertex N, ∀ n m : ℕ,
      (∀ j : Fin n, walkLaw (exitsThrough N (D j.val) (a j.val) (b j.val)) ≠ 0) →
      (∀ k < n, b k = a (k+1)) →
      ∀ s : Fin m → Fin n, Function.Injective s →
      (∀ i, D (s i).val = torusDisk N c (Real.exp (q+2*q^γ))) →
      2*(Real.exp (q+2*q^γ)+1) < N.val →
      (∀ i, |periodicDistance (a (s i).val) c-Real.exp (q+q^γ)| ≤ 2) →
      (∀ i, diskExteriorNeighbor N c (Real.exp (q+2*q^γ)) (b (s i).val)) →
      ∀ v Δ : ℝ, 0 ≤ v → (m:ℝ)*q^γ ≤ v^2 → 0 ≤ Δ →
      2*r7MeanConstant*Real.exp (-r7MeanExponent*q^γ)*v ≤ Δ → Δ ≤ v →
      (walkLaw[|exitChainEndpoints N D a b n]).real
        {ω | v+Δ < Real.sqrt (exitChainSelectedOccupation N D a
          (fun z => diskHarmonicWeight N c (Real.exp (q+1)) z/g) n m s ω)} ≤
        2*Real.exp (-(r7ConcentrationConstant/4)*Δ^2/q^γ) := by
  filter_upwards [r7_occupation_sqrt_upper_concentration hWalk γ hγ hγ1] with q hc
  intro N c D hD a b n m hp hab s hs hDs hsmall ha hb v Δ hv hmv hΔ hlo hhi
  have hE : MeasurableSet {x : ℝ | v+Δ < Real.sqrt x} :=
    measurableSet_lt measurable_const measurable_id.sqrt
  have he := exitChain_selected_occupation_event N D hD a b n m hp hab s hs
    (fun z => diskHarmonicWeight N c (Real.exp (q+1)) z/g) _ hDs _ hE
  change (walkLaw[|exitChainEndpoints N D a b n]).real _ =
    (exactExitProductLaw N (torusDisk N c (Real.exp (q+2*q^γ))) m
      (fun i => a (s i).val) (fun i => b (s i).val)).real
      {ω | v+Δ < Real.sqrt (harmonicExitBlockSum N c (Real.exp (q+1))
        (Real.exp (q+2*q^γ)) m (fun i => a (s i).val) ω)} at he
  simp only [Set.mem_ofPred_eq] at he
  rw [he]
  exact hc N c m (fun i => a (s i).val) (fun i => b (s i).val) hsmall ha hb v Δ hv hmv hΔ hlo hhi

theorem r7_exitChain_sqrt_concentration (hWalk : WalkModelRegular) (γ : ℝ)
    (hγ : 0 < γ) (hγ1 : γ ≤ 1) :
    ∀ᶠ q : ℝ in atTop, ∀ N : Size, ∀ c : Vertex N,
      ∀ D : ℕ → Finset (Vertex N), (∀ k, ∃ b : Vertex N, b ∉ D k) →
      ∀ a b : ℕ → Vertex N, ∀ n m : ℕ,
      (∀ j : Fin n, walkLaw (exitsThrough N (D j.val) (a j.val) (b j.val)) ≠ 0) →
      (∀ k < n, b k = a (k+1)) →
      ∀ s : Fin m → Fin n, Function.Injective s →
      (∀ i, D (s i).val = torusDisk N c (Real.exp (q+2*q^γ))) →
      2*(Real.exp (q+2*q^γ)+1) < N.val →
      (∀ i, |periodicDistance (a (s i).val) c-Real.exp (q+q^γ)| ≤ 2) →
      (∀ i, diskExteriorNeighbor N c (Real.exp (q+2*q^γ)) (b (s i).val)) →
      let Y := Real.sqrt ((m:ℝ)*q^γ)
      ∀ Δ : ℝ, 0 ≤ Δ → 2*r7MeanConstant*Real.exp (-r7MeanExponent*q^γ)*Y ≤ Δ → Δ ≤ Y →
      (walkLaw[|exitChainEndpoints N D a b n]).real
        {ω | Δ < |Real.sqrt (exitChainSelectedOccupation N D a
          (fun z => diskHarmonicWeight N c (Real.exp (q+1)) z/g) n m s ω)-Y|} ≤
        2*Real.exp (-(r7ConcentrationConstant/4)*Δ^2/q^γ) := by
  filter_upwards [r7_occupation_sqrt_concentration hWalk γ hγ hγ1] with q hc
  intro N c D hD a b n m hp hab s hs hDs hsmall ha hb
  dsimp only
  intro Δ hΔ hlo hhi
  let Y := Real.sqrt ((m:ℝ)*q^γ)
  have hE : MeasurableSet {x : ℝ | Δ < |Real.sqrt x-Y|} :=
    measurableSet_lt measurable_const (measurable_id.sqrt.sub measurable_const).abs
  have he := exitChain_selected_occupation_event N D hD a b n m hp hab s hs
    (fun z => diskHarmonicWeight N c (Real.exp (q+1)) z/g) _ hDs _ hE
  change (walkLaw[|exitChainEndpoints N D a b n]).real _ =
    (exactExitProductLaw N (torusDisk N c (Real.exp (q+2*q^γ))) m
      (fun i => a (s i).val) (fun i => b (s i).val)).real
      {ω | Δ < |Real.sqrt (harmonicExitBlockSum N c (Real.exp (q+1))
        (Real.exp (q+2*q^γ)) m (fun i => a (s i).val) ω)-Y|} at he
  simp only [Set.mem_ofPred_eq, Y] at he
  rw [he]
  exact hc N c m (fun i => a (s i).val) (fun i => b (s i).val) hsmall ha hb Δ hΔ hlo hhi

end TorusCoverTime.Blocks.B
