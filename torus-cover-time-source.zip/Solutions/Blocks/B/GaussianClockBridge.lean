import Solutions.Blocks.B.GaussianClockContact
import Solutions.Blocks.C.C4.Base.GaussianMeanShift

/-! A finite bridge independent of its endpoint.  A positive endpoint interval
transfers the two-sided contact bound without ever dividing by the probability
of a null endpoint singleton. -/

noncomputable section
open MeasureTheory ProbabilityTheory Classical Set
open scoped ENNReal NNReal
namespace TorusCoverTime.Blocks.B.GaussianClockPath
variable {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
variable {n : ℕ} (W : GaussianClockPath μ n)

def bridge (ω : Ω) (i : Fin (n+1)) : ℝ :=
  W.path ω i - (W.clock i / W.clock (Fin.last n)) * W.path ω (Fin.last n)

@[fun_prop] theorem bridge_measurable : Measurable W.bridge := by
  unfold bridge
  fun_prop

theorem bridge_gaussian : HasGaussianLaw W.bridge μ :=
  W.gaussian.map_fun (ContinuousLinearMap.pi (fun i : Fin (n+1) =>
    (ContinuousLinearMap.proj i : (Fin (n+1) → ℝ) →L[ℝ] ℝ) -
      (W.clock i / W.clock (Fin.last n)) • ContinuousLinearMap.proj (Fin.last n)))

theorem bridge_covariance_endpoint (hv : 0 < W.clock (Fin.last n)) (i : Fin (n+1)) :
    cov[fun ω => W.bridge ω i, fun ω => W.path ω (Fin.last n); μ] = 0 := by
  unfold bridge
  rw [covariance_fun_sub_left (W.memLp _) ((W.memLp _).const_mul _) (W.memLp _),
    covariance_const_mul_left, W.covariance, W.covariance, min_eq_left (Fin.le_last i), min_self,
    div_mul_cancel₀ _ hv.ne', sub_self]

theorem bridge_indep_endpoint (hv : 0 < W.clock (Fin.last n)) :
    IndepFun W.bridge (fun ω => W.path ω (Fin.last n)) μ := by
  let L := ContinuousLinearMap.pi (fun i : Fin (n+1) =>
    (ContinuousLinearMap.proj i : (Fin (n+1) → ℝ) →L[ℝ] ℝ) -
      (W.clock i / W.clock (Fin.last n)) • ContinuousLinearMap.proj (Fin.last n))
  let R := ContinuousLinearMap.pi (fun _ : Unit =>
    (ContinuousLinearMap.proj (Fin.last n) : (Fin (n+1) → ℝ) →L[ℝ] ℝ))
  have hi := W.linear_indep L R (fun i _ => W.bridge_covariance_endpoint hv i)
  have hh := hi.comp measurable_id (measurable_pi_apply ())
  change IndepFun (fun ω => L (W.path ω)) (fun ω => W.path ω (Fin.last n)) μ at hh
  have he : (fun ω => L (W.path ω)) = W.bridge := by funext ω i; rfl
  rwa [he] at hh

theorem bridge_contact_mul_interval (hv : 0 < W.clock (Fin.last n))
    (k : Fin (n+1)) (H b : ℝ) :
    μ {ω | (∀ i, W.bridge ω i ≤ H) ∧ H-b ≤ W.bridge ω k} *
      gaussianReal 0 (W.clock (Fin.last n)).toNNReal (Icc (-1) 0) ≤
    μ {ω | W.path ω (Fin.last n) ∈ Icc (-1) 0 ∧
      (∀ i, W.path ω i ≤ H) ∧ H-(b+1) ≤ W.path ω k} := by
  let S : Set (Fin (n+1) → ℝ) := {f | (∀ i, f i ≤ H) ∧ H-b ≤ f k}
  have hS : MeasurableSet S := by
    apply MeasurableSet.inter ?_ (measurableSet_le measurable_const (measurable_pi_apply k))
    change MeasurableSet {f : Fin (n+1) → ℝ | ∀ i, f i ≤ H}
    rw [Set.ofPred_forall]
    exact MeasurableSet.iInter (fun i => measurableSet_le (measurable_pi_apply i) measurable_const)
  have hend : μ ((fun ω => W.path ω (Fin.last n)) ⁻¹' Icc (-1) 0) =
      gaussianReal 0 (W.clock (Fin.last n)).toNNReal (Icc (-1) 0) := by
    rw [← Measure.map_apply (W.measurable_coord _) measurableSet_Icc, (W.coordinate_hasLaw _).map_eq]
  have he := (W.bridge_indep_endpoint hv).measure_inter_preimage_eq_mul S (Icc (-1) 0) hS measurableSet_Icc
  rw [hend] at he
  change μ (W.bridge ⁻¹' S) * _ ≤ _
  rw [← he]
  apply measure_mono
  intro ω hω
  have hB : (∀ i, W.bridge ω i ≤ H) ∧ H-b ≤ W.bridge ω k := hω.1
  have ht : -1 ≤ W.path ω (Fin.last n) ∧ W.path ω (Fin.last n) ≤ 0 := hω.2
  have hcoef (i : Fin (n+1)) : 0 ≤ W.clock i / W.clock (Fin.last n) ∧
      W.clock i / W.clock (Fin.last n) ≤ 1 :=
    ⟨div_nonneg (W.clock_nonneg i) hv.le, (div_le_one hv).mpr (W.clock_mono (Fin.le_last i))⟩
  have hprod (i : Fin (n+1)) : -1 ≤ (W.clock i / W.clock (Fin.last n))*W.path ω (Fin.last n) ∧
      (W.clock i / W.clock (Fin.last n))*W.path ω (Fin.last n) ≤ 0 := by
    constructor
    · nlinarith [hcoef i, mul_nonneg (hcoef i).1 (show 0 ≤ W.path ω (Fin.last n)+1 by linarith)]
    · exact mul_nonpos_of_nonneg_of_nonpos (hcoef i).1 ht.2
  refine ⟨ht, ?_, ?_⟩
  · intro i
    have hi := hB.1 i
    unfold bridge at hi
    linarith [(hprod i).2]
  · have hk := hB.2
    unfold bridge at hk
    linarith [(hprod k).1]

theorem bridge_contact_bound_with_density {U : ℝ} (h : W.ClockBounds U)
    (k : Fin (n+1)) (hk : 3 ≤ k.val) (hrest : 3 ≤ n-k.val)
    (H b : ℝ) (hH : 0 ≤ H) (hb : 0 ≤ b) :
    μ {ω | (∀ i, W.bridge ω i ≤ H) ∧ H-b ≤ W.bridge ω k} ≤
      (ENNReal.ofReal (1024*(b+1)*(H+2*Real.sqrt U+1)*(b+1+2*Real.sqrt U+1) /
        ((k.val : ℝ)*Real.sqrt k.val)) *
       ENNReal.ofReal (1024*(b+1+2*Real.sqrt U+1)*(H+1+2*Real.sqrt U+1) /
        (((n-k.val : ℕ) : ℝ)*Real.sqrt ((n-k.val : ℕ) : ℝ)))) /
      ENNReal.ofReal (Real.exp (-(1/(2*W.clock (Fin.last n)))) /
        Real.sqrt (2*Real.pi*W.clock (Fin.last n))) := by
  have hnv : (n : ℝ) ≤ W.clock (Fin.last n) := by
    simpa only [Fin.val_last, Fin.val_zero, Nat.cast_zero, sub_zero, W.clock_zero] using
      h.lower 0 (Fin.last n) (Fin.zero_le _)
  have hv : 0 < W.clock (Fin.last n) := by
    have hn : (0 : ℝ) < n := by exact_mod_cast (show 0<n by omega)
    exact hn.trans_le hnv
  have hfloor := Blocks.C.C4.gaussianReal_Icc_ge_density_floor
    (v := (W.clock (Fin.last n)).toNNReal) (Real.toNNReal_pos.mpr hv).ne' (-1) 0 1
    (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  rw [Real.coe_toNNReal _ hv.le] at hfloor
  norm_num only [sub_neg_eq_add, zero_add, one_pow, mul_one] at hfloor
  rw [show (1 / Real.sqrt (2*Real.pi*W.clock (Fin.last n))) *
      Real.exp (-(1:ℝ)/(2*W.clock (Fin.last n))) =
      Real.exp (-(1/(2*W.clock (Fin.last n)))) / Real.sqrt (2*Real.pi*W.clock (Fin.last n)) by
    rw [neg_div]; ring] at hfloor
  have he := W.bridge_contact_mul_interval hv k H b
  have hp := W.path_contact_interval_le h k hk hrest H (b+1) hH (by linarith)
  have hc : 0 < ENNReal.ofReal (Real.exp (-(1/(2*W.clock (Fin.last n)))) /
      Real.sqrt (2*Real.pi*W.clock (Fin.last n))) := ENNReal.ofReal_pos.mpr (by positivity)
  apply (ENNReal.le_div_iff_mul_le (.inl hc.ne') (.inl ENNReal.ofReal_ne_top)).mpr
  exact (mul_le_mul' le_rfl hfloor).trans (he.trans hp)

end TorusCoverTime.Blocks.B.GaussianClockPath
