import Solutions.Blocks.B.FiniteDomainSpectrum
import Solutions.Blocks.B.FiniteExitDuration

/-! An unconditional tail bound for the actual finite exit duration.
The domain-cardinality prefactor is kept explicit for the R1 application. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Classical
open scoped ENNReal Topology BigOperators
namespace TorusCoverTime.Blocks.B

lemma complement_card_real (N : Size) (A : Finset (Vertex N)) :
    ((Finset.univ \ A).card : ℝ) + A.card = vertexCount N := by
  have h := congrArg (fun n : ℕ => (n : ℝ))
    (Finset.card_sdiff_add_card_eq_card (Finset.subset_univ A))
  simpa [vertexCount, Fintype.card_prod, ZMod.card, pow_two] using h

lemma survival_point_le_principal (hWalk : WalkModelRegular)
    (N : Size) (A : Finset (Vertex N)) (hA : A ≠ Finset.univ)
    (a : Vertex N) (t : ℝ) (ht : 0 ≤ t) :
    (walkLaw {ω | ∀ x ∈ A, ENNReal.ofReal t < hittingTime N a ω x}).toReal ≤
      ((Finset.univ \ A).card : ℝ) * Real.exp (-killedEigenvalue N A * t) := by
  have hspec := stationary_survival_spectral hWalk N A t ht
  have hbound : stationarySurvival N A t ≤
      (1 - (A.card : ℝ) / vertexCount N) * Real.exp (-killedEigenvalue N A * t) := by
    rw [hspec, ← killedWeight_sum, Finset.sum_mul]
    apply Finset.sum_le_sum
    intro i _
    apply mul_le_mul_of_nonneg_left _ (killedWeight_nonneg N A i)
    apply Real.exp_le_exp.mpr
    have h := mul_le_mul_of_nonneg_right (killedModeRate_ge_principal N A hA i) ht
    linarith
  have hm := mul_le_mul_of_nonneg_left hbound (vertexCount_pos N).le
  have hsum : vertexCount N * stationarySurvival N A t =
      ∑ start : Vertex N, (walkLaw {ω | ∀ x ∈ A, ENNReal.ofReal t < hittingTime N start ω x}).toReal := by
    rw [stationarySurvival, mul_div_cancel₀ _ (vertexCount_pos N).ne']
  have hcard : vertexCount N * ((1 - (A.card : ℝ) / vertexCount N) *
      Real.exp (-killedEigenvalue N A * t)) =
      ((Finset.univ \ A).card : ℝ) * Real.exp (-killedEigenvalue N A * t) := by
    calc
      _ = (vertexCount N - A.card) * Real.exp (-killedEigenvalue N A * t) := by
        rw [← mul_assoc, mul_sub, mul_one, mul_div_cancel₀ _ (vertexCount_pos N).ne']
      _ = _ := by rw [show vertexCount N - A.card = ((Finset.univ \ A).card : ℝ) by
        linarith [complement_card_real N A]]
  rw [hsum, hcard] at hm
  exact (Finset.single_le_sum (f := fun start : Vertex N =>
      (walkLaw {ω | ∀ x ∈ A, ENNReal.ofReal t < hittingTime N start ω x}).toReal)
    (fun _ _ => ENNReal.toReal_nonneg)
    (Finset.mem_univ a)).trans hm

lemma duration_tail_implies_survival (N : Size) (D : Finset (Vertex N)) (a : Vertex N)
    {ω : WalkSample} (hpos : ∀ j, 0 < (ω j).1)
    (hnon : Tendsto (jumpTime ω) atTop atTop) (t : ℝ) (ht : 0 ≤ t)
    (hτ : t < finiteExitDuration N D a ω) :
    ∀ x ∈ Finset.univ \ D, ENNReal.ofReal t < hittingTime N a ω x := by
  apply (survival_iff_discreteAvoids N a (Finset.univ \ D) hpos hnon t ht).mpr
  have he : ∃ n : ℕ, position N a ω n ∉ D := by
    by_contra he
    simp only [finiteExitDuration, finiteExitIndex, dif_neg he, jumpTime_zero] at hτ
    exact (not_lt_of_ge ht) hτ
  have hj : jumpCount ω t < Nat.find he := by
    have hlow := jumpTime_jumpCount_le hpos hnon ht
    simp only [finiteExitDuration, finiteExitIndex, dif_pos he] at hτ
    by_contra hj
    have hh := (jumpTime_strictMono hpos).monotone (le_of_not_gt hj)
    linarith
  intro k hk
  have hm := Nat.find_min he (hk.trans_lt hj)
  simpa only [Finset.mem_sdiff, Finset.mem_univ, true_and] using hm

lemma finiteExitDuration_tail_le_survival (hWalk : WalkModelRegular)
    (N : Size) (D : Finset (Vertex N)) (a : Vertex N) (t : ℝ) (ht : 0 ≤ t) :
    walkLaw {ω | t < finiteExitDuration N D a ω} ≤
      walkLaw {ω | ∀ x ∈ Finset.univ \ D, ENNReal.ofReal t < hittingTime N a ω x} := by
  apply measure_mono_ae
  filter_upwards [hWalk.1] with ω hω
  exact duration_tail_implies_survival N D a hω.1 hω.2 t ht

lemma finiteExitDuration_tail_bound (hWalk : WalkModelRegular)
    (N : Size) (D : Finset (Vertex N)) (hD : D.Nonempty) (hproper : D ≠ Finset.univ)
    (a : Vertex N) (t : ℝ) (ht : 0 ≤ t) :
    walkLaw {ω | t < finiteExitDuration N D a ω} ≤
      ENNReal.ofReal ((D.card : ℝ) * Real.exp (-t / (4 * greenDiagonal N * D.card))) := by
  let A := Finset.univ \ D
  have hA : A ≠ Finset.univ := by
    obtain ⟨x, hx⟩ := hD
    intro heq
    have hm : x ∈ A := heq ▸ Finset.mem_univ x
    exact (Finset.mem_sdiff.mp hm).2 hx
  have hne : A.Nonempty := by
    by_contra hn
    apply hproper
    apply Finset.eq_univ_iff_forall.mpr
    intro x
    by_contra hx
    exact hn ⟨x, Finset.mem_sdiff.mpr ⟨Finset.mem_univ x, hx⟩⟩
  have hc : Finset.univ \ A = D := by ext x; simp [A]
  have hden : 0 < 4 * greenDiagonal N * (D.card : ℝ) :=
    mul_pos (mul_pos (by norm_num) (greenDiagonal_pos N)) (Nat.cast_pos.mpr hD.card_pos)
  have hr : 1 / (4 * greenDiagonal N * D.card) ≤ killedEigenvalue N A := by
    apply (div_le_iff₀ hden).mpr
    have h := killedEigenvalue_domain_bound N A hne hA
    rw [hc] at h
    nlinarith
  have hreal := survival_point_le_principal hWalk N A hA a t ht
  rw [hc] at hreal
  have hprob := (ENNReal.toReal_mono (measure_ne_top walkLaw _)
    (finiteExitDuration_tail_le_survival hWalk N D a t ht)).trans hreal
  apply (ENNReal.le_ofReal_iff_toReal_le (measure_ne_top walkLaw _) (by positivity)).mpr
  apply hprob.trans
  apply mul_le_mul_of_nonneg_left _ (Nat.cast_nonneg _)
  apply Real.exp_le_exp.mpr
  have hm := mul_le_mul_of_nonneg_right hr ht
  calc
    _ ≤ -(1 / (4 * greenDiagonal N * D.card) * t) := by linarith
    _ = _ := by ring

end TorusCoverTime.Blocks.B
