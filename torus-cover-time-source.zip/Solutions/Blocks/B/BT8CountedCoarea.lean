import Solutions.Blocks.B.BT8SourceImage

noncomputable section
open MeasureTheory Filter Set Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

def bt8SourceWeight (N : Size) (root x : Vertex N) (γ u l r : ℝ) (a : D.LoopSource) : ℝ≥0∞ :=
  if a.1∈Icc l r ∧ bt8Good N root γ u (a.2,a.1) ∧ bt8SoftPoint N root x γ u (a.2,a.1) then 1 else 0

def bt8GoodCountMass (N : Size) (γ u l r : ℝ) : ℝ≥0∞ :=
  (ENNReal.ofReal (timeScale N))⁻¹*∑ root,
    ∫⁻ a, ∑ x, bt8SourceWeight N root x γ u l r a ∂D.rootedLoopMeasure N root

def bt8ImageTest (N : Size) (γ u l r : ℝ) (y : D.CoareaImage N) : ℝ≥0∞ :=
  if y.1∈Icc l (r+(64*g)*vertexCount N*logSize N/2) then bt8ImageCount N γ u y else 0

theorem bt8SourceWeight_measurable (N : Size) (root x : Vertex N) (γ u l r : ℝ) :
    Measurable (bt8SourceWeight N root x γ u l r) :=
  measurable_const.ite ((measurable_fst measurableSet_Icc).inter
    (((bt8Good_measurable N root γ u).preimage measurable_swap).inter
      ((bt8SoftPoint_measurable N root x γ u).preimage measurable_swap))) measurable_const

theorem bt8ImageTest_measurable (N : Size) (γ u l r : ℝ) : Measurable (bt8ImageTest N γ u l r) :=
  (bt8ImageCount_measurable N γ u).ite (measurable_fst measurableSet_Icc) measurable_const

theorem bt8_counted_coarea (γ : ℝ) (hγ : 0<γ) (hγhi : 32*γ<1/10) :
    ∀ᶠ N : Size in atTop, ∀ root : Vertex N, ∀ u l r : ℝ,
      ENNReal.ofReal (coarseProbeProbabilityConstant/Real.sqrt (logSize N))*
        (∫⁻ a, ∑ x, bt8SourceWeight N root x γ u l r a ∂D.rootedLoopMeasure N root)≤
      ∫⁻ y, bt8ImageTest N γ u l r y ∂D.rootedShellImageMeasure N root := by
  filter_upwards [bt8_probe_mass γ hγ hγhi,bt8_parameters γ hγ hγhi] with N hm hp
  intro root u l r
  let w := fun x => bt8SourceWeight N root x γ u l r
  let b := fun x (z : D.LoopSource × FiniteFieldSample N) => if bt8Probe N root x γ z then (1:ℝ≥0∞) else 0
  let p := ENNReal.ofReal (coarseProbeProbabilityConstant/Real.sqrt (logSize N))
  have hw (x : Vertex N) : Measurable (w x) := bt8SourceWeight_measurable N root x γ u l r
  have hb (x : Vertex N) : Measurable (b x) := measurable_const.ite (bt8Probe_measurable N root x γ) measurable_const
  have hprob (x : Vertex N) (a : D.LoopSource) (ha : w x a≠0) :
      p≤∫⁻ ξ, b x (a,ξ) ∂finiteFieldLaw N := by
    have hs : a.1∈Icc l r ∧ bt8Good N root γ u (a.2,a.1) ∧ bt8SoftPoint N root x γ u (a.2,a.1) := by
      by_contra hs; exact ha (if_neg hs)
    exact hm root x u a hs.2.1 hs.2.2
  have hmajor (z : D.LoopSource × FiniteFieldSample N) :
      (∑ x, w x z.1*b x z)≤bt8ImageTest N γ u l r (D.sourceCoareaImage N root z) := by
    have hterm (x : Vertex N) : w x z.1*b x z≤
        if (D.sourceCoareaImage N root z).1∈Icc l (r+(64*g)*vertexCount N*logSize N/2) ∧
          bt8ImageBad N γ u x (D.sourceCoareaImage N root z) then 1 else 0 := by
      by_cases hs : z.1.1∈Icc l r ∧ bt8Good N root γ u (z.1.2,z.1.1) ∧ bt8SoftPoint N root x γ u (z.1.2,z.1.1)
      · by_cases hb' : bt8Probe N root x γ z
        · have hi := bt8_source_image N root x γ u hp.2.1 hp.2.2.1 hp.2.2.2.1 hp.2.2.2.2.1 hp.2.2.2.2.2
            z hs.2.1 hs.2.2.1 hb'
          have ht := D.coarea_source_time_window N root z l r _ hs.1 hi.2
          simp only [w,bt8SourceWeight,hs,if_true,b,hb',one_mul,ht,hi.1,and_self,le_refl]
        · simp only [b,hb',if_false,mul_zero]; exact bot_le
      · simp only [w,bt8SourceWeight,hs,if_false,zero_mul]; exact bot_le
    have hh := Finset.sum_le_sum (fun x (_ : x∈(Finset.univ:Finset (Vertex N))) => hterm x)
    refine hh.trans_eq ?_
    by_cases ht : (D.sourceCoareaImage N root z).1∈Icc l (r+(64*g)*vertexCount N*logSize N/2)
    · simp only [ht,true_and,bt8ImageTest,if_true,bt8ImageCount]
    · simp only [ht,false_and,if_false,Finset.sum_const_zero,bt8ImageTest]
  have hh := s5_counted_probe_transfer N root Finset.univ w (fun _ => p) b (bt8ImageTest N γ u l r)
    (fun x _ => hw x) (fun x _ => hb x) (bt8ImageTest_measurable N γ u l r)
    (fun x _ a ha => hprob x a ha) hmajor
  simp_rw [← Finset.sum_mul] at hh
  rw [lintegral_mul_const p (Finset.measurable_sum _ (fun x _ => hw x)),mul_comm] at hh
  exact hh

end TorusCoverTime.Blocks.B
