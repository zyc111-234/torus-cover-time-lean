import Solutions.Blocks.B.AdaptivePrefixEvent
import Solutions.Blocks.B.NestedTraversalCount

/-! Traversal counts computed from finite records, without reading the padded
tail. On the original regular path they agree with the physical count at the
record's last jump, including an exit that occurs exactly at that jump. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

def finiteTraversalRecordCount (N : Size) (I J : Finset (Vertex N)) (a : Vertex N)
    (p : ℕ × WalkSample) : ℕ :=
  (Finset.range (p.1+1)).sup fun k =>
    if p.2 ∈ adaptivePrefixEvent N (alternatingDomain N I J) a p.1 (2*k) then k else 0

theorem finiteTraversalRecordCount_measurable (N : Size) (I J : Finset (Vertex N))
    (a : Vertex N) : Measurable (finiteTraversalRecordCount N I J a) := by
  apply measurable_from_prod_countable_right
  intro n
  change Measurable (fun ω => (Finset.range (n+1)).sup fun k =>
    if ω ∈ adaptivePrefixEvent N (alternatingDomain N I J) a n (2*k) then k else 0)
  have hs (s : Finset ℕ) : Measurable (fun ω => s.sup fun k =>
      if ω ∈ adaptivePrefixEvent N (alternatingDomain N I J) a n (2*k) then k else 0) := by
    induction s using Finset.induction with
    | empty => simp only [Finset.sup_empty]; exact measurable_const
    | @insert k s hk ih =>
      simp only [Finset.sup_insert]
      exact (measurable_const.ite (adaptivePrefixEvent_measurable N _ a n (2*k)) measurable_const).sup ih
  exact hs _

theorem finiteTraversalRecordCount_prefix (N : Size) (I J : Finset (Vertex N))
    (a : Vertex N) (n : ℕ) {ω η : WalkSample} (hp : ∀ i < n, η i = ω i) :
    finiteTraversalRecordCount N I J a (n,η) = finiteTraversalRecordCount N I J a (n,ω) := by
  unfold finiteTraversalRecordCount
  simp only [adaptivePrefixEvent_prefix N (alternatingDomain N I J) a n _ hp]

theorem finiteTraversalRecordCount_eq_physical (N : Size) (I J : Finset (Vertex N))
    (a : Vertex N) (ω : WalkSample)
    (hi : StrictMono (fun k => adaptiveExitIndex N (alternatingDomain N I J) a k ω))
    (hs : ∀ j, ∃ t : ℕ, position N (adaptiveExitStart N (alternatingDomain N I J) a j ω)
      (adaptiveExitTail N (alternatingDomain N I J) a j ω) t ∉ alternatingDomain N I J j)
    (hp : ∀ i, 0 < (ω i).1) (hd : Tendsto (jumpTime ω) atTop atTop) (n : ℕ) :
    finiteTraversalRecordCount N I J a (n,ω) = completedTraversalCount N I J a ω (jumpTime ω n) := by
  let D := alternatingDomain N I J
  let T := fun k => adaptiveExitTime N D a k ω
  let K := completedTraversalCount N I J a ω (jumpTime ω n)
  have hT : StrictMono T := (jumpTime_strictMono hp).comp hi
  have hT0 : T 0 = 0 := by simp [T, adaptiveExitTime]
  have hdiv : Tendsto T atTop atTop := hd.comp hi.tendsto_atTop
  have hb := physicalSegmentCount_bounds T hT0 hdiv (jumpTime ω n) (jumpTime_nonneg ω n)
  have hidx : adaptiveExitIndex N D a (2*K) ω ≤ n := by
    have hk : 2*K ≤ physicalSegmentCount T (jumpTime ω n) := by
      change 2*(physicalSegmentCount T (jumpTime ω n)/2) ≤ _
      omega
    exact (jumpTime_strictMono hp).le_iff_le.mp ((hT.monotone hk).trans hb.1)
  have hid : ∀ k, k ≤ adaptiveExitIndex N D a k ω := by
    intro k
    induction k with
    | zero => simp
    | succ k ih => exact Nat.succ_le_of_lt (lt_of_le_of_lt ih (hi (Nat.lt_succ_self k)))
  have hKn : K ≤ n := le_trans (by omega : K ≤ 2*K) ((hid (2*K)).trans hidx)
  have hcert : ω ∈ adaptivePrefixEvent N D a n (2*K) := ⟨hidx, fun j _ => hs j⟩
  apply le_antisymm
  · change (Finset.range (n+1)).sup _ ≤ K
    apply Finset.sup_le_iff.mpr
    intro k hk
    split_ifs with hc
    · have ht : T (2*k) ≤ jumpTime ω n := (jumpTime_strictMono hp).monotone hc.1
      have hseg := physicalSegmentCount_ge_of_time T hT.monotone hT0 hdiv
        (jumpTime ω n) (jumpTime_nonneg ω n) (2*k) ht
      change k ≤ physicalSegmentCount T (jumpTime ω n)/2
      omega
    · exact Nat.zero_le _
  · change K ≤ (Finset.range (n+1)).sup _
    apply Finset.le_sup_of_le (Finset.mem_range.mpr (by omega : K < n+1))
    change K ≤ if ω ∈ adaptivePrefixEvent N D a n (2*K) then K else 0
    rw [if_pos hcert]

theorem finiteTraversalRecordCount_eq_physical_ae (N : Size) (I J : Finset (Vertex N))
    (hIJ : I ⊆ J) (hI : I.Nonempty) (a : Vertex N) (ha : a ∉ J) :
    ∀ᵐ ω ∂walkLaw, ∀ n : ℕ, finiteTraversalRecordCount N I J a (n,ω) =
      completedTraversalCount N I J a ω (jumpTime ω n) := by
  filter_upwards [alternatingExitIndex_strictMono_ae N I J hIJ hI a ha,
    adaptiveExit_spec_ae N _ (alternatingDomain_proper N I J hI ⟨a,ha⟩) a,
    A.holding_positive_and_nonexplosive] with ω hi hs hreg
  apply finiteTraversalRecordCount_eq_physical N I J a ω hi _ hreg.1 hreg.2
  intro j
  exact ⟨_, (hs j).2.1 ▸ (hs j).1⟩

theorem finiteTraversalRecordCount_exit_ae (N : Size) (O I J : Finset (Vertex N))
    (hIJ : I ⊆ J) (hI : I.Nonempty) (a : Vertex N) (ha : a ∉ J) :
    ∀ᵐ ω ∂walkLaw, finiteTraversalRecordCount N I J a (finiteExitRecord N O a ω) =
      nestedTraversalCount N O I J a ω := by
  filter_upwards [finiteTraversalRecordCount_eq_physical_ae N I J hIJ hI a ha] with ω hω
  calc
    _ = finiteTraversalRecordCount N I J a (finiteExitIndex N O a ω,ω) :=
      finiteTraversalRecordCount_prefix N I J a _ (finiteExitRecord_agrees N O a ω)
    _ = _ := hω _

end TorusCoverTime.Blocks.B
