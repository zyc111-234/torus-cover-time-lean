import Solutions.Blocks.B.BridgeDensityNormalization

/-! A finite bridge survival bound, used to include the two short contact
segments omitted by the three-part killed-density estimate. -/

noncomputable section
open MeasureTheory ProbabilityTheory Set
open scoped ENNReal NNReal
namespace TorusCoverTime.Blocks.B.GaussianClockPath
variable {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
variable {n : ℕ} (W : GaussianClockPath μ n)

theorem bridge_zero (ω : Ω) : W.bridge ω 0 = 0 := by
  simp only [bridge,W.start_zero,W.clock_zero,zero_div,zero_mul,sub_zero]

theorem bridge_survival_mul_interval (hv : 0 < W.clock (Fin.last n)) (H : ℝ) :
    μ {ω | ∀ i, W.bridge ω i ≤ H}*gaussianReal 0 (W.clock (Fin.last n)).toNNReal (Icc (-1) 0) ≤
      μ {ω | W.path ω (Fin.last n) ∈ Icc (-1) 0 ∧ ∀ i, W.path ω i ≤ H} := by
  have hh := W.bridge_contact_mul_interval hv 0 H H
  have hl : {ω | (∀ i, W.bridge ω i ≤ H) ∧ H-H ≤ W.bridge ω 0} = {ω | ∀ i, W.bridge ω i ≤ H} := by
    simp only [W.bridge_zero,sub_self,le_refl,and_true]
  rw [hl] at hh
  exact hh.trans (measure_mono (fun ω hω => ⟨hω.1,hω.2.1⟩))

theorem bridge_survival_le {U : ℝ} (h : W.ClockBounds U) (hn : 3 ≤ n)
    (H : ℝ) (hH : 0 ≤ H) :
    μ {ω | ∀ i, W.bridge ω i ≤ H} ≤
      ENNReal.ofReal (1024*bridgeDensityConstant U*(H+bridgeBarrierPadding U)^2/(n : ℝ)) := by
  have he := h.endpoint_bounds W
  have hn0 : (0 : ℝ)<n := by exact_mod_cast (show 0<n by omega)
  have hv : 0<W.clock (Fin.last n) := hn0.trans_le he.1
  let d := Real.exp (-(1/(2*W.clock (Fin.last n))))/Real.sqrt (2*Real.pi*W.clock (Fin.last n))
  have hd : 0<d := by dsimp [d]; positivity
  have hfloor := Blocks.C.C4.gaussianReal_Icc_ge_density_floor
    (v := (W.clock (Fin.last n)).toNNReal) (Real.toNNReal_pos.mpr hv).ne' (-1) 0 1
    (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  rw [Real.coe_toNNReal _ hv.le] at hfloor
  norm_num only [sub_neg_eq_add,zero_add,one_pow,mul_one] at hfloor
  have hfloor' : ENNReal.ofReal d ≤ gaussianReal 0 (W.clock (Fin.last n)).toNNReal (Icc (-1) 0) := by
    convert hfloor using 1
    dsimp [d]
    rw [neg_div]
    ring
  have hpath := W.flat_ballot_thirds h hn H (-1) 0 hH (by linarith) (by norm_num)
  norm_num only [sub_neg_eq_add,zero_add,mul_one] at hpath
  have hdiv : μ {ω | ∀ i, W.bridge ω i ≤ H} ≤
      ENNReal.ofReal (1024*(H+2*Real.sqrt U+1)*(H+1+2*Real.sqrt U+1)/((n : ℝ)*Real.sqrt n)) / ENNReal.ofReal d := by
    apply (ENNReal.le_div_iff_mul_le (.inl (ENNReal.ofReal_pos.mpr hd).ne') (.inl ENNReal.ofReal_ne_top)).mpr
    exact (mul_le_mul' le_rfl hfloor').trans ((W.bridge_survival_mul_interval hv H).trans hpath)
  rw [← ENNReal.ofReal_div_of_pos hd] at hdiv
  refine hdiv.trans (ENNReal.ofReal_le_ofReal ?_)
  have hi := bridge_density_inverse_le (n : ℝ) _ U (by exact_mod_cast (show 1≤n by omega)) he.1 he.2
  have hnum : 1024*(H+2*Real.sqrt U+1)*(H+1+2*Real.sqrt U+1)/((n : ℝ)*Real.sqrt n) ≤
      1024*(H+bridgeBarrierPadding U)^2/((n : ℝ)*Real.sqrt n) := by
    unfold bridgeBarrierPadding
    calc
      _ ≤ 1024*(H+(2*Real.sqrt U+2))*(H+(2*Real.sqrt U+2))/((n : ℝ)*Real.sqrt n) := by
        rw [show H+1+2*Real.sqrt U+1 = H+(2*Real.sqrt U+2) by ring]
        apply div_le_div_of_nonneg_right _ (by positivity)
        apply mul_le_mul_of_nonneg_right _ (by positivity)
        exact mul_le_mul_of_nonneg_left (by linarith : H+2*Real.sqrt U+1≤H+(2*Real.sqrt U+2)) (by norm_num)
      _ = _ := by ring
  calc
    _ = (1024*(H+2*Real.sqrt U+1)*(H+1+2*Real.sqrt U+1)/((n : ℝ)*Real.sqrt n))*(1/d) := by ring
    _ ≤ (1024*(H+bridgeBarrierPadding U)^2/((n : ℝ)*Real.sqrt n))*(bridgeDensityConstant U*Real.sqrt n) :=
      mul_le_mul hnum hi (by positivity) (by positivity)
    _ = _ := by
      have hs : Real.sqrt (n : ℝ) ≠ 0 := (Real.sqrt_pos.mpr hn0).ne'
      field_simp

end TorusCoverTime.Blocks.B.GaussianClockPath
