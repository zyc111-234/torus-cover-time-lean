import Solutions.Blocks.B.RootShellTV

/-! The actual field marginal after averaging the root. Its density retains
both shell branches and the original normalization. -/

noncomputable section
open MeasureTheory Filter Classical
open scoped ENNReal Topology BigOperators
namespace TorusCoverTime.Blocks.B

def averagedFieldDensity (N : Size) (B : ℝ) (ξ : FiniteFieldSample N) : ℝ :=
  vertexCount N * (Blocks.D.averagedShellDensity N B (ξ, true) +
    Blocks.D.averagedShellDensity N B (ξ, false)).toReal

lemma averagedShellDensity_lt_top (N : Size) (B : ℝ) (z : FiniteFieldSample N × Bool) :
    Blocks.D.averagedShellDensity N B z < ∞ := by
  unfold Blocks.D.averagedShellDensity
  split_ifs <;> simp

lemma averagedFieldDensity_nonneg (N : Size) (B : ℝ) (ξ : FiniteFieldSample N) :
    0 ≤ averagedFieldDensity N B ξ := mul_nonneg (vertexCount_pos N).le ENNReal.toReal_nonneg

lemma averagedFieldDensity_measurable (N : Size) (B : ℝ) : Measurable (averagedFieldDensity N B) :=
  (((Blocks.D.averagedShellDensity_measurable N B).comp (measurable_id.prodMk measurable_const)).add
    ((Blocks.D.averagedShellDensity_measurable N B).comp (measurable_id.prodMk measurable_const))).ennreal_toReal.const_mul _

lemma averagedShellDensity_sum_measurable (N : Size) (B : ℝ) :
    Measurable (fun ξ : FiniteFieldSample N => Blocks.D.averagedShellDensity N B (ξ, true) +
      Blocks.D.averagedShellDensity N B (ξ, false)) :=
  ((Blocks.D.averagedShellDensity_measurable N B).comp (measurable_id.prodMk measurable_const)).add
    ((Blocks.D.averagedShellDensity_measurable N B).comp (measurable_id.prodMk measurable_const))

lemma averagedFieldDensity_ofReal (N : Size) (B : ℝ) (ξ : FiniteFieldSample N) :
    ENNReal.ofReal (averagedFieldDensity N B ξ) = ENNReal.ofReal (vertexCount N) *
      (Blocks.D.averagedShellDensity N B (ξ, true) + Blocks.D.averagedShellDensity N B (ξ, false)) := by
  rw [averagedFieldDensity, ENNReal.ofReal_mul (vertexCount_pos N).le, ENNReal.ofReal_toReal]
  exact (ENNReal.add_lt_top.mpr ⟨averagedShellDensity_lt_top N B _, averagedShellDensity_lt_top N B _⟩).ne

lemma averagedFieldDensity_integrable (N : Size) (B : ℝ) (hB : 0 ≤ B) :
    Integrable (averagedFieldDensity N B) (finiteFieldLaw N) := by
  apply Integrable.const_mul
  apply integrable_toReal_of_lintegral_ne_top (averagedShellDensity_sum_measurable N B).aemeasurable
  rw [← Blocks.D.averagedShellMass_eq]
  exact (Blocks.D.averagedShellMass_lt_top N B hB).ne

lemma averagedFieldDensity_integral (N : Size) (B : ℝ) :
    (∫ ξ, averagedFieldDensity N B ξ ∂finiteFieldLaw N) =
      vertexCount N * (Blocks.D.averagedShellMass N B).toReal := by
  unfold averagedFieldDensity
  rw [integral_const_mul, integral_toReal (averagedShellDensity_sum_measurable N B).aemeasurable
    (Eventually.of_forall fun ξ => ENNReal.add_lt_top.mpr
      ⟨averagedShellDensity_lt_top N B _, averagedShellDensity_lt_top N B _⟩),
    ← Blocks.D.averagedShellMass_eq]

lemma averagedFieldDensity_measure (N : Size) (B : ℝ) :
    (finiteFieldLaw N).withDensity (fun ξ => ENNReal.ofReal (averagedFieldDensity N B ξ)) =
      ENNReal.ofReal (vertexCount N) • (Blocks.D.averagedShellMeasure N B).map Prod.fst := by
  ext E hE
  rw [withDensity_apply _ hE, Measure.smul_apply, Measure.map_apply measurable_fst hE]
  have hpre : MeasurableSet (Prod.fst ⁻¹' E : Set (FiniteFieldSample N × Bool)) := hE.preimage measurable_fst
  rw [← lintegral_indicator_one hpre,
    Blocks.D.averagedShell_lintegral N B ((Prod.fst ⁻¹' E).indicator (1 : FiniteFieldSample N × Bool → ℝ≥0∞))
      (by exact measurable_const.indicator hpre)]
  simp only [smul_eq_mul]
  simp_rw [averagedFieldDensity_ofReal]
  rw [lintegral_const_mul' _ _ ENNReal.ofReal_ne_top, ← lintegral_indicator hE]
  congr 1
  apply lintegral_congr
  intro ξ
  by_cases hξ : ξ ∈ E <;> simp [hξ]

lemma averagedFieldDensity_normalization (N : Size) (B : ℝ) (hB : 0 ≤ B) :
    realDensityProbability (finiteFieldLaw N) (averagedFieldDensity N B) =
      (Blocks.D.normalizedAveragedShell N B).map Prod.fst := by
  rw [realDensityProbability, averagedFieldDensity_integral, averagedFieldDensity_measure,
    ENNReal.ofReal_mul (vertexCount_pos N).le,
    ENNReal.ofReal_toReal (Blocks.D.averagedShellMass_lt_top N B hB).ne, smul_smul,
    Blocks.D.normalizedAveragedShell, Measure.map_smul]
  congr 1
  have hn := ENNReal.ofReal_ne_zero_iff.mpr (vertexCount_pos N)
  rw [ENNReal.mul_inv (Or.inl hn) (Or.inl ENNReal.ofReal_ne_top), mul_right_comm,
    ENNReal.inv_mul_cancel hn ENNReal.ofReal_ne_top, one_mul]

lemma averagedFieldDensity_mass_lower (N : Size) (B : ℝ) (hB : 20 * greenDiagonal N ≤ B) :
    (1 / 4 : ℝ) ≤ ∫ ξ, averagedFieldDensity N B ξ ∂finiteFieldLaw N := by
  rw [averagedFieldDensity_integral, ← fixedRootShellMass_eq_averaged N (0 : Vertex N) B,
    ← rootScaledDensity_integral]
  exact rootScaledDensity_mass_lower N 0 B hB

lemma averagedFieldDensity_eq (N : Size) (B : ℝ) (ξ : FiniteFieldSample N)
    (hQ : Blocks.D.fieldMeanSquare N ξ < B) :
    averagedFieldDensity N B ξ = 1 +
      (∑ r, max (|finiteGaussianField N ξ r| - Blocks.D.shellAmplitude N B ξ) 0) /
        (vertexCount N * Blocks.D.shellAmplitude N B ξ) := by
  have hA : 0 < Blocks.D.shellAmplitude N B ξ := Real.sqrt_pos.mpr (sub_pos.mpr hQ)
  rw [averagedFieldDensity, Blocks.D.averagedShellDensity_sum, if_pos hQ,
    ENNReal.toReal_ofReal (add_nonneg
      (Blocks.D.shellBranchWeight_nonneg N _ hA.le true)
      (Blocks.D.shellBranchWeight_nonneg N _ hA.le false)),
    Blocks.D.shellBranchWeight_sum_eq N _ (Blocks.D.finiteGaussianField_sum_zero N ξ) hA]
  field_simp [(vertexCount_pos N).ne', hA.ne']

lemma averagedFieldDensity_zero (N : Size) (B : ℝ) (ξ : FiniteFieldSample N)
    (hQ : B ≤ Blocks.D.fieldMeanSquare N ξ) : averagedFieldDensity N B ξ = 0 := by
  simp [averagedFieldDensity, Blocks.D.averagedShellDensity, not_lt.mpr hQ]

lemma averagedFieldDensity_energy_integral (N : Size) (B a : ℝ) (hB : 0 ≤ B) :
    (∫ ξ in {ξ | a ≤ Blocks.D.fieldMeanSquare N ξ}, averagedFieldDensity N B ξ ∂finiteFieldLaw N) =
      vertexCount N * (Blocks.D.averagedShellMeasure N B).real
        {z | a ≤ Blocks.D.fieldMeanSquare N z.1} := by
  have hm : MeasurableSet {ξ : FiniteFieldSample N | a ≤ Blocks.D.fieldMeanSquare N ξ} :=
    measurableSet_le measurable_const (Blocks.D.fieldMeanSquare_measurable N)
  rw [← realDensity_apply _ _ (averagedFieldDensity_integrable N B hB)
    (averagedFieldDensity_nonneg N B) _ hm, averagedFieldDensity_measure,
    measureReal_ennreal_smul_apply, ENNReal.toReal_ofReal (vertexCount_pos N).le,
    measureReal_def, Measure.map_apply measurable_fst hm]
  rfl

end TorusCoverTime.Blocks.B
