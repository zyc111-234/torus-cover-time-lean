import Solutions.Blocks.B.DiskExitSupport

/-! The actual finite-domain Green operator: symmetry, inversion, positivity,
domain monotonicity, and the exact row-mass/Poisson-barrier identity. -/

noncomputable section
open Classical
namespace TorusCoverTime.Blocks.B

theorem domainGreenFromBarrier_pairing (N : Size) (D : Finset (Vertex N)) (b : Vertex N → ℝ)
    (hb : ∀ x ∈ D, -generator N b x = 1) (u v : Vertex N) :
    dirichletPairing N (fun z => domainGreenFromBarrier N D b z u)
      (fun z => domainGreenFromBarrier N D b z v) = domainGreenFromBarrier N D b v u := by
  unfold dirichletPairing
  have ht (x : Vertex N) : domainGreenFromBarrier N D b x u *
      (-generator N (fun z => domainGreenFromBarrier N D b z v) x) =
      domainGreenFromBarrier N D b x u * (if x = v then 1 else 0) := by
    by_cases hx : x ∈ D
    · rw [domainGreenFromBarrier_generator N D b hb x v hx]
    · rw [domainGreenFromBarrier_boundary N D b x u hx, zero_mul, zero_mul]
  simp only [ht, mul_ite, mul_one, mul_zero]
  simp

theorem domainGreenFromBarrier_symm (N : Size) (D : Finset (Vertex N)) (b : Vertex N → ℝ)
    (hb : ∀ x ∈ D, -generator N b x = 1) (u v : Vertex N) :
    domainGreenFromBarrier N D b u v = domainGreenFromBarrier N D b v u := by
  have h := dirichletPairing_symm N (fun z => domainGreenFromBarrier N D b z v)
    (fun z => domainGreenFromBarrier N D b z u)
  rwa [domainGreenFromBarrier_pairing N D b hb, domainGreenFromBarrier_pairing N D b hb] at h

theorem domainGreenFromBarrier_boundary_right (N : Size) (D : Finset (Vertex N)) (b : Vertex N → ℝ)
    (hb : ∀ x ∈ D, -generator N b x = 1) (x y : Vertex N) (hy : y ∉ D) :
    domainGreenFromBarrier N D b x y = 0 := by
  rw [domainGreenFromBarrier_symm N D b hb x y]
  exact domainGreenFromBarrier_boundary N D b y x hy

theorem domainGreenFromBarrier_nonneg_all (N : Size) (D : Finset (Vertex N)) (b : Vertex N → ℝ)
    (hb : ∀ x ∈ D, -generator N b x = 1) (x y : Vertex N) :
    0 ≤ domainGreenFromBarrier N D b x y := by
  by_cases hy : y ∈ D
  · exact domainGreenFromBarrier_nonneg N D b hb x y hy
  · rw [domainGreenFromBarrier_boundary_right N D b hb x y hy]

theorem domainGreenFromBarrier_solves (N : Size) (D : Finset (Vertex N)) (b : Vertex N → ℝ)
    (hb : ∀ x ∈ D, -generator N b x = 1) (f : Vertex N → ℝ) (x : Vertex N) (hx : x ∈ D) :
    -generator N (fun z => ∑ y, f y * domainGreenFromBarrier N D b z y) x = f x := by
  rw [generator_sum, ← Finset.sum_neg_distrib]
  simp only [generator_mul_left, neg_mul_eq_mul_neg, domainGreenFromBarrier_generator N D b hb x _ hx]
  simp

theorem domainGreenFromBarrier_solution (N : Size) (D : Finset (Vertex N)) (hD : D ≠ Finset.univ)
    (b : Vertex N → ℝ) (hb : ∀ x ∈ D, -generator N b x = 1)
    (f U : Vertex N → ℝ) (hU : ∀ x, x ∉ D → U x = 0)
    (hgen : ∀ x ∈ D, -generator N U x = f x) :
    U = fun z => ∑ y, f y * domainGreenFromBarrier N D b z y := by
  apply domain_harmonic_unique N D hD
  · intro x hx
    simp only [hU x hx, domainGreenFromBarrier_boundary N D b x _ hx, mul_zero, Finset.sum_const_zero]
  · intro x hx
    have h := domainGreenFromBarrier_solves N D b hb f x hx
    have h' := hgen x hx
    linarith

theorem domainGreenFromBarrier_mass (N : Size) (D : Finset (Vertex N)) (hD : D ≠ Finset.univ)
    (b : Vertex N → ℝ) (hb : ∀ x ∈ D, -generator N b x = 1) (x : Vertex N) :
    (∑ y, domainGreenFromBarrier N D b x y) = b x - exitExtension N D b x := by
  have hU : ∀ z, z ∉ D → (b-exitExtension N D b) z = 0 := by
    intro z hz
    simp only [Pi.sub_apply, exitExtension_boundary N D b z hz, sub_self]
  have hg : ∀ z ∈ D, -generator N (b-exitExtension N D b) z = 1 := by
    intro z hz
    rw [generator_sub, exitExtension_generator N D b z hz, sub_zero]
    exact hb z hz
  have h := congrFun (domainGreenFromBarrier_solution N D hD b hb (fun _ => 1)
    (b-exitExtension N D b) hU hg) x
  simpa only [Pi.sub_apply, one_mul] using h.symm

theorem exitHarmonic_zero_inside (N : Size) (D : Finset (Vertex N)) (a b : Vertex N) (hb : b ∈ D) :
    exitHarmonic N D b a = 0 := by
  have he : exitsThrough N D a b = ∅ := by
    apply Set.eq_empty_iff_forall_notMem.mpr
    rintro ω ⟨n, hn⟩
    exact hn.1 hb
  unfold exitHarmonic
  rw [he, MeasureTheory.measureReal_empty]

theorem domain_harmonic_nonnegative (N : Size) (D : Finset (Vertex N)) (hD : D ≠ Finset.univ)
    (f : Vertex N → ℝ) (hf : ∀ x ∈ D, generator N f x = 0)
    (hb : ∀ x, x ∉ D → 0 ≤ f x) (x : Vertex N) : 0 ≤ f x := by
  rw [congrFun (harmonic_exit_representation N D hD f hf) x]
  apply Finset.sum_nonneg
  intro y _
  by_cases hy : y ∈ D
  · rw [exitHarmonic_zero_inside N D x y hy, mul_zero]
  · exact mul_nonneg (hb y hy) (exitHarmonic_nonneg N D y x)

theorem domainGreenFromBarrier_mono (N : Size) (D E : Finset (Vertex N)) (hD : D ≠ Finset.univ)
    (hDE : D ⊆ E) (b d : Vertex N → ℝ)
    (hb : ∀ x ∈ D, -generator N b x = 1) (hd : ∀ x ∈ E, -generator N d x = 1)
    (x y : Vertex N) : domainGreenFromBarrier N D b x y ≤ domainGreenFromBarrier N E d x y := by
  have hg : ∀ z ∈ D, generator N ((fun a => domainGreenFromBarrier N E d a y) -
      (fun a => domainGreenFromBarrier N D b a y)) z = 0 := by
    intro z hz
    rw [generator_sub]
    have he := domainGreenFromBarrier_generator N E d hd z y (hDE hz)
    have hh := domainGreenFromBarrier_generator N D b hb z y hz
    linarith
  have hn := domain_harmonic_nonnegative N D hD _ hg (by
    intro z hz
    simp only [Pi.sub_apply, domainGreenFromBarrier_boundary N D b z y hz, sub_zero]
    exact domainGreenFromBarrier_nonneg_all N E d hd z y) x
  exact sub_nonneg.mp hn

theorem diskGreen_symm (N : Size) (c : Vertex N) (R : ℝ) (hR : 0 ≤ R)
    (hsmall : 2*(R+1) < N.val) (x y : Vertex N) : diskGreen N c R x y = diskGreen N c R y x :=
  domainGreenFromBarrier_symm N _ _ (fun z hz => diskBarrier_generator N c R hR hsmall z hz) x y

theorem diskGreen_mass_bound (N : Size) (c : Vertex N) (R : ℝ) (hR : 0 ≤ R)
    (hsmall : 2*(R+1) < N.val) (x : Vertex N) :
    (∑ y, diskGreen N c R x y) ≤ (R+1)^2 := by
  have he := domainGreenFromBarrier_mass N (torusDisk N c R) (torusDisk_proper N c R hR hsmall)
    (diskBarrier N c R) (fun z hz => diskBarrier_generator N c R hR hsmall z hz) x
  change (∑ y, diskGreen N c R x y) = _ at he
  rw [he]
  have hnon : 0 ≤ exitExtension N (torusDisk N c R) (diskBarrier N c R) x :=
    Finset.sum_nonneg fun y _ => mul_nonneg (diskBarrier_nonneg N c R y) (exitHarmonic_nonneg N _ y x)
  have hb := diskBarrier_le N c R x
  linarith

end TorusCoverTime.Blocks.B
