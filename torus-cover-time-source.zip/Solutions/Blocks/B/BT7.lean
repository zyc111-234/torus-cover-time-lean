import Solutions.Blocks.B.BT7Conclusion

/-! B-T7 entry point: the expected number of bad points for either sign of the
actual mean-zero periodic field tends to zero, at the paper's parameter values.
The final results are `bt7_conclusion` and `bt7_paper_gamma`. -/
