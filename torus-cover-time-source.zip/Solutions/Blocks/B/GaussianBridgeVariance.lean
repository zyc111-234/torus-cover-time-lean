import Solutions.Blocks.B.GaussianBridgeContactBound
import Solutions.Blocks.B.HarmonicGaussianTail

noncomputable section
open MeasureTheory ProbabilityTheory
namespace TorusCoverTime.Blocks.B.GaussianClockPath
variable {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
variable {n : ℕ} (W : GaussianClockPath μ n)

theorem bridge_mean_zero (i : Fin (n+1)) : (∫ ω, W.bridge ω i ∂μ)=0 := by
  unfold bridge
  rw [integral_sub (W.integrable i) ((W.integrable _).const_mul _),integral_const_mul,
    W.mean_zero,W.mean_zero,mul_zero,sub_self]

theorem bridge_memLp (i : Fin (n+1)) : MemLp (fun ω => W.bridge ω i) 2 μ :=
  (W.bridge_gaussian.map_fun (ContinuousLinearMap.proj i)).memLp_two

theorem bridge_covariance (hv : 0<W.clock (Fin.last n)) (i j : Fin (n+1)) :
    cov[fun ω => W.bridge ω i,fun ω => W.bridge ω j;μ]=
      W.clock (min i j)-W.clock i*W.clock j/W.clock (Fin.last n) := by
  change cov[fun ω => W.bridge ω i,fun ω => W.path ω j-(W.clock j/W.clock (Fin.last n))*W.path ω (Fin.last n);μ]=_
  rw [covariance_fun_sub_right (W.bridge_memLp i) (W.memLp j) ((W.memLp _).const_mul _),
    covariance_const_mul_right,W.bridge_covariance_endpoint hv,mul_zero,sub_zero]
  unfold bridge
  rw [covariance_fun_sub_left (W.memLp i) ((W.memLp _).const_mul _) (W.memLp j),
    covariance_const_mul_left,W.covariance,W.covariance,min_eq_right (Fin.le_last j)]
  ring

theorem bridge_variance (hv : 0<W.clock (Fin.last n)) (i : Fin (n+1)) :
    Var[fun ω => W.bridge ω i;μ]=W.clock i-(W.clock i)^2/W.clock (Fin.last n) := by
  rw [← covariance_self (W.bridge_memLp i).aemeasurable,W.bridge_covariance hv,min_self]
  ring

theorem bridge_variance_le_ends (hv : 0<W.clock (Fin.last n)) (i : Fin (n+1)) :
    Var[fun ω => W.bridge ω i;μ]≤W.clock i ∧
      Var[fun ω => W.bridge ω i;μ]≤W.clock (Fin.last n)-W.clock i := by
  rw [W.bridge_variance hv]
  constructor
  · exact sub_le_self _ (div_nonneg (sq_nonneg _) hv.le)
  · apply (mul_le_mul_iff_of_pos_right hv).mp
    rw [sub_mul,div_mul_cancel₀ _ hv.ne',sub_mul]
    nlinarith [sq_nonneg (W.clock (Fin.last n)-W.clock i)]

theorem bridge_increment_gaussian (i j : Fin (n+1)) :
    HasGaussianLaw (fun ω => W.bridge ω j-W.bridge ω i) μ :=
  W.bridge_gaussian.map_fun ((ContinuousLinearMap.proj j : (Fin (n+1) → ℝ) →L[ℝ] ℝ)-ContinuousLinearMap.proj i)

theorem bridge_increment_mean (i j : Fin (n+1)) :
    (∫ ω, W.bridge ω j-W.bridge ω i ∂μ)=0 := by
  rw [integral_sub ((W.bridge_memLp j).integrable (by norm_num)) ((W.bridge_memLp i).integrable (by norm_num)),
    W.bridge_mean_zero,W.bridge_mean_zero,sub_self]

theorem bridge_increment_variance (hv : 0<W.clock (Fin.last n)) (i j : Fin (n+1)) (hij : i≤j) :
    Var[fun ω => W.bridge ω j-W.bridge ω i;μ]=
      (W.clock j-W.clock i)-(W.clock j-W.clock i)^2/W.clock (Fin.last n) := by
  rw [variance_fun_sub (W.bridge_memLp j) (W.bridge_memLp i),W.bridge_variance hv,W.bridge_variance hv,
    W.bridge_covariance hv,min_eq_right hij]
  ring

theorem bridge_increment_abs_tail (hv : 0<W.clock (Fin.last n)) (i j : Fin (n+1))
    (hij : i≤j) (V a : ℝ) (hV : 0<V) (ha : 0≤a) (hclock : W.clock j-W.clock i≤V) :
    μ.real {ω | a≤|W.bridge ω j-W.bridge ω i|}≤2*Real.exp (-a^2/(2*V)) := by
  apply centered_gaussian_abs_tail μ _ (W.bridge_increment_gaussian i j) (W.bridge_increment_mean i j) V a hV ha
  rw [W.bridge_increment_variance hv i j hij]
  exact (sub_le_self _ (div_nonneg (sq_nonneg _) hv.le)).trans hclock

def subsample {m : ℕ} (f : Fin (m+1) → Fin (n+1)) (hf : Monotone f) (hzero : f 0=0) : GaussianClockPath μ m where
  path ω i := W.path ω (f i)
  clock i := W.clock (f i)
  measurable := by fun_prop
  gaussian := W.gaussian.map_fun (ContinuousLinearMap.pi (fun i => ContinuousLinearMap.proj (f i)))
  mean_zero i := W.mean_zero (f i)
  covariance i j := by rw [W.covariance,← hf.map_min]
  clock_zero := by rw [hzero,W.clock_zero]
  clock_mono := W.clock_mono.comp hf
  start_zero ω := by rw [hzero,W.start_zero]

theorem subsample_bridge {m : ℕ} (f : Fin (m+1) → Fin (n+1)) (hf : Monotone f) (hzero : f 0=0)
    (hlast : f (Fin.last m)=Fin.last n) (ω : Ω) (i : Fin (m+1)) :
    (W.subsample f hf hzero).bridge ω i=W.bridge ω (f i) := by
  simp only [bridge,subsample,hlast]

theorem neg_bridge (ω : Ω) (i : Fin (n+1)) : W.neg.bridge ω i = -W.bridge ω i := by
  dsimp [neg,bridge]
  ring

end TorusCoverTime.Blocks.B.GaussianClockPath
