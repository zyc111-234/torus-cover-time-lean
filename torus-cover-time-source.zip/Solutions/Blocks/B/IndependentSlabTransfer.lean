import Solutions.Blocks.B.DirichletFreshNormal

noncomputable section
open MeasureTheory ProbabilityTheory Classical Set
namespace TorusCoverTime.Blocks.B
variable {Ω F : Type*} [MeasurableSpace Ω] [MeasurableSpace F]
variable {μ : Measure Ω} [IsProbabilityMeasure μ]

theorem real_prod_integral_sections (S : Set (Ω × Ω)) (hS : MeasurableSet S) :
    (μ.prod μ).real S=∫ y, μ.real {x | (x,y)∈S} ∂μ := by
  have hi : Integrable (S.indicator (fun _ => (1:ℝ))) (μ.prod μ) := (integrable_const _).indicator hS
  rw [← integral_indicator_one hS]
  change (∫ v, S.indicator (fun _ => (1:ℝ)) v ∂μ.prod μ)=_
  rw [integral_prod_symm _ hi]
  apply integral_congr_ae
  exact Filter.Eventually.of_forall (fun y => by
    have hy : MeasurableSet {x | (x,y)∈S} := hS.preimage (measurable_id.prodMk measurable_const)
    simpa only [Set.indicator,Set.mem_ofPred_eq,Pi.one_apply] using integral_indicator_one (μ := μ) hy)

/-- The fixed-probability auxiliary slab is imposed before dropping it. The
joint distribution hypothesis explicitly retains independence from the envelope. -/
theorem independent_slab_transfer (A S : Set Ω) (hA : MeasurableSet A) (hS : MeasurableSet S)
    (R : Ω × Ω → F) (X : Ω → F) (H : Ω → ℝ) (hX : Measurable X) (hH : Measurable H)
    (E : Set (F × ℝ)) (hE : MeasurableSet E)
    (hj : IdentDistrib (fun v : Ω × Ω => (R v,H v.1)) (fun v : Ω × Ω => (X v.1,H v.2)) (μ.prod μ) (μ.prod μ))
    (hsub : ∀ x∈A, ∀ y∈S, (R (x,y),H x)∈E)
    (p : ℝ) (hp : p≤μ.real S) (B : Ω → ℝ) (hB : Integrable B μ)
    (hbound : ∀ y, μ.real {x | (X x,H y)∈E}≤B y) :
    p*μ.real A≤∫ y, B y ∂μ := by
  let T := {v : Ω × Ω | (X v.1,H v.2)∈E}
  have hT : MeasurableSet T := hE.preimage ((hX.comp measurable_fst).prodMk (hH.comp measurable_snd))
  have hdist := congrArg ENNReal.toReal (hj.measure_mem_eq hE)
  have hmono : (μ.prod μ).real (A ×ˢ S)≤(μ.prod μ).real T := by
    apply (measureReal_mono (μ := μ.prod μ) (show A ×ˢ S⊆(fun v : Ω × Ω => (R v,H v.1)) ⁻¹' E from ?_)).trans_eq hdist
    rintro ⟨x,y⟩ ⟨hx,hy⟩
    exact hsub x hx y hy
  rw [measureReal_prod_prod] at hmono
  have hsection : Integrable (fun y => μ.real {x | (X x,H y)∈E}) μ := by
    have hm := (measurable_measure_prodMk_right (μ := μ) hT).ennreal_toReal
    apply (integrable_const (1:ℝ)).mono' hm.aestronglyMeasurable
    exact Filter.Eventually.of_forall (fun y => by
      rw [Real.norm_eq_abs,abs_of_nonneg ENNReal.toReal_nonneg]
      change μ.real ((fun x => (x,y)) ⁻¹' T)≤1
      exact measureReal_le_one)
  calc
    _ ≤ μ.real A*μ.real S := by nlinarith only [mul_le_mul_of_nonneg_right hp (measureReal_nonneg (μ := μ) (s := A))]
    _ ≤ (μ.prod μ).real T := hmono
    _ = ∫ y, μ.real {x | (X x,H y)∈E} ∂μ := real_prod_integral_sections T hT
    _ ≤ _ := integral_mono hsection hB hbound

end TorusCoverTime.Blocks.B
