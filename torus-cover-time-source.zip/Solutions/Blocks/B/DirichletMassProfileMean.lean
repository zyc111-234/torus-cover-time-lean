import Solutions.Blocks.B.DirichletMassBounds

noncomputable section
open scoped BigOperators
namespace TorusCoverTime.Blocks.B

theorem dirichletMassProfile_sum (N : Size) (root : Vertex N) (D : Finset (Vertex N))
    (hV : 0<dirichletMassVariance N root D) :
    (∑ x, dirichletMassProfile N root D x)=Real.sqrt (dirichletMassVariance N root D) := by
  unfold dirichletMassProfile
  rw [← Finset.sum_div]
  change dirichletMassVariance N root D/Real.sqrt (dirichletMassVariance N root D)=_
  exact (div_eq_iff (Real.sqrt_pos.mpr hV).ne').mpr (by rw [← sq,Real.sq_sqrt hV.le])

theorem dirichletMassProfile_centered_bound (N : Size) (root c : Vertex N) (R : ℝ)
    (hR : 1≤R) (hsmall : 2*(R+1)<N.val) (hroot : root∉torusDisk N c R) (x : Vertex N) :
    |dirichletMassProfile N root (torusDisk N c R) x-
      Real.sqrt (dirichletMassVariance N root (torusDisk N c R))/vertexCount N|≤2*dirichletMassProfileBound := by
  have hg : 0<g := by unfold g; positivity
  have hV : 0<dirichletMassVariance N root (torusDisk N c R) :=
    lt_of_lt_of_le (by positivity) (dirichletMassVariance_disk_lower N root c R (by linarith) hsmall hroot)
  have hq := dirichletMassProfile_disk_bound N root c R hR hsmall hroot
  have hsum := Finset.sum_le_sum (fun z (_ : z∈Finset.univ) => (hq z).2)
  rw [dirichletMassProfile_sum N root _ hV,sum_const_vertex] at hsum
  have hn : 0<vertexCount N := vertexCount_pos N
  have hm : Real.sqrt (dirichletMassVariance N root (torusDisk N c R))/vertexCount N≤dirichletMassProfileBound :=
    (div_le_iff₀ hn).mpr (by nlinarith only [hsum])
  have hm0 : 0≤Real.sqrt (dirichletMassVariance N root (torusDisk N c R))/vertexCount N := by positivity
  have hQ : 0≤dirichletMassProfileBound := by unfold dirichletMassProfileBound; positivity
  exact abs_le.mpr ⟨by linarith [(hq x).1],by linarith [(hq x).2]⟩

end TorusCoverTime.Blocks.B
