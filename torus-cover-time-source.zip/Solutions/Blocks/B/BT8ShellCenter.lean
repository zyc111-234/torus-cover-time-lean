import Solutions.Blocks.B.BT8Measurable

noncomputable section
open MeasureTheory Filter Set Classical
open scoped Topology
namespace TorusCoverTime.Blocks.B

def bt8ShellCenterError (H : ℝ) : ℝ :=
  ((g+greenDiagonalErrorConstant+2*H*g)/Real.sqrt g)/Real.sqrt (2*g)

theorem bt8ShellCenterError_nonneg (H : ℝ) (hH : 0≤H) : 0≤bt8ShellCenterError H := by
  unfold bt8ShellCenterError
  positivity [coarseProbe_g_pos,greenDiagonalErrorConstant_pos]

theorem bt8_shell_center (H : ℝ) (hH : 0≤H) :
    ∀ᶠ N : Size in atTop, ∀ θ : ℝ, |θ|≤H →
      |Real.sqrt (D.shellEnergyParameter N θ-greenDiagonal N)/Real.sqrt (2*g)-
        harmonicExtremeCenter N|≤bt8ShellCenterError H := by
  filter_upwards [blockB_logSize_tendsto.eventually_ge_atTop 1,
    blockB_logSize_tendsto.eventually_ge_atTop (4*H)] with N hL hHL
  intro θ hθ
  have hg := coarseProbe_g_pos
  have hsg := Real.sqrt_pos.mpr hg
  have hd : 0<Real.sqrt (2*g) := by positivity
  have hv := D.shellEnergyParameter_bounds N H θ hH hθ hL hHL
  let k := 2*logSize N-3/4*Real.log (logSize N)
  let x := Real.sqrt g*k
  let y := Real.sqrt (D.shellEnergyParameter N θ-greenDiagonal N)
  let C := g+greenDiagonalErrorConstant+2*H*g
  let E := C/Real.sqrt g
  have hk : logSize N≤k := by dsimp [k]; linarith [Real.log_le_self (logSize_pos N).le]
  have hx : Real.sqrt g*logSize N≤x := mul_le_mul_of_nonneg_left hk hsg.le
  have hy : Real.sqrt g*logSize N≤y := by
    calc
      _ = Real.sqrt (g*logSize N^2) := by rw [Real.sqrt_mul hg.le,Real.sqrt_sq (logSize_pos N).le]
      _ ≤ _ := Real.sqrt_le_sqrt hv.1
  have hx2 : x^2=g*k^2 := by dsimp [x]; rw [mul_pow,Real.sq_sqrt hg.le]
  have hy2 : y^2=g*k^2+greenDiagonal N+2*θ*g*logSize N := by
    dsimp [y]
    rw [Real.sq_sqrt ((show 0≤g*logSize N^2 by positivity).trans hv.1),D.shellEnergyParameter_square]
    dsimp [k]
    ring
  have hG := D.greenDiagonal_le_log_multiple N hL
  have hθlo := mul_le_mul_of_nonneg_right (abs_le.mp hθ).1
    (show 0≤2*g*logSize N by positivity)
  have hθhi := mul_le_mul_of_nonneg_right (abs_le.mp hθ).2
    (show 0≤2*g*logSize N by positivity)
  have hC : 0≤C := by dsimp [C]; positivity [greenDiagonalErrorConstant_pos]
  have hE : 0≤E := div_nonneg hC hsg.le
  have he : E*(Real.sqrt g*logSize N)=C*logSize N := by dsimp [E]; field_simp
  have hsum : Real.sqrt g*logSize N≤x+y := by
    have := Real.sqrt_nonneg (D.shellEnergyParameter N θ-greenDiagonal N)
    change 0≤y at this
    linarith
  have hprod := mul_le_mul_of_nonneg_left hsum hE
  rw [he] at hprod
  have hsumpos : 0<x+y := (by positivity : 0<Real.sqrt g*logSize N).trans_le hsum
  have hb : |y-x|≤E := by
    apply abs_le.mpr
    constructor
    · by_contra hh
      have hm := mul_pos (show 0<x-y-E by linarith) hsumpos
      dsimp only [C] at hprod
      nlinarith [greenDiagonal_pos N]
    · by_contra hh
      have hm := mul_pos (show 0<y-x-E by linarith) hsumpos
      dsimp only [C] at hprod
      nlinarith
  have hid : x/Real.sqrt (2*g)=harmonicExtremeCenter N := by
    dsimp [x,k,harmonicExtremeCenter]
    rw [Real.sqrt_mul (by norm_num : (0:ℝ)≤2)]
    field_simp [hsg.ne']
  rw [← hid,← sub_div,abs_div,abs_of_pos hd]
  exact div_le_div_of_nonneg_right hb hd.le

def bt8CenterConstant (H u : ℝ) : ℝ :=
  bt8ShellCenterError H+Real.sqrt (2*u+1)/Real.sqrt (2*g)+1

theorem bt8CenterConstant_nonneg (H u : ℝ) (hH : 0≤H) : 0≤bt8CenterConstant H u := by
  unfold bt8CenterConstant
  positivity [bt8ShellCenterError_nonneg H hH]

theorem bt8_amplitude_window (H u ε : ℝ) (hH : 0≤H) :
    ∀ᶠ N : Size in atTop, ∀ θ a : ℝ, |θ|≤H →
      |a-Real.sqrt (D.shellEnergyParameter N θ-greenDiagonal N)|≤
        (ε*Real.sqrt (2*g))*Real.log (logSize N) →
      |a/Real.sqrt (2*g)-harmonicExtremeCenter N|≤ε*Real.log (logSize N)+bt8CenterConstant H u := by
  filter_upwards [bt8_shell_center H hH] with N hN
  intro θ a hθ ha
  have hd : 0<Real.sqrt (2*g) := by positivity [coarseProbe_g_pos]
  have hh := div_le_div_of_nonneg_right ha hd.le
  have habs : |a/Real.sqrt (2*g)-Real.sqrt (D.shellEnergyParameter N θ-greenDiagonal N)/Real.sqrt (2*g)|=
      |a-Real.sqrt (D.shellEnergyParameter N θ-greenDiagonal N)|/Real.sqrt (2*g) := by
    rw [← sub_div,abs_div,abs_of_pos hd]
  rw [← habs] at hh
  have he : (ε*Real.sqrt (2*g))*Real.log (logSize N)/Real.sqrt (2*g)=ε*Real.log (logSize N) := by
    field_simp
  rw [he] at hh
  have ht := abs_sub_le (a/Real.sqrt (2*g)) (Real.sqrt (D.shellEnergyParameter N θ-greenDiagonal N)/Real.sqrt (2*g))
    (harmonicExtremeCenter N)
  have hC : bt8ShellCenterError H≤bt8CenterConstant H u := by
    unfold bt8CenterConstant
    have : 0≤Real.sqrt (2*u+1)/Real.sqrt (2*g) := by positivity
    linarith
  linarith [hN θ hθ]

end TorusCoverTime.Blocks.B
