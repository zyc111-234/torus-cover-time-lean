import Solutions.Blocks.B.PhysicalWordWindow
import Solutions.Blocks.B.R8SoftPhysicalExterior

/-! Transport any proved exterior representation, preserving the original soft-site event. -/
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B


theorem physicalWordWindow_eq_exterior (N : Size) (I O : Finset (Vertex N)) (root : Vertex N)
    (m : ℕ) (w : Fin (2*m) → Vertex N) (F : WalkSample × ℝ → ℝ≥0∞)
    (E : TraversalExteriorSample m × ℝ → ℝ≥0∞)
    (he : ∀ᵐ ω ∂walkLaw[|{ω | adaptiveExitWord N (alternatingDomain N I O) root (2*m) ω = w}],
      ∀ t, adaptiveExitTime N (alternatingDomain N I O) root (2*m) ω ≤ t →
        F (ω,t) = E (traversalExteriorData N I O root m ω,t-adaptiveExitTime N (alternatingDomain N I O) root (2*m) ω))
    (l r : ℝ) :
    physicalWordWindow N I O root m w F l r = conditionalTraversalExteriorSlice N I O root m w univ E l r := by
  apply lintegral_congr_ae
  filter_upwards [he] with ω hω
  apply lintegral_congr_ae
  filter_upwards [ae_restrict_mem (measurableSet_Ioi
    (a := adaptiveExitTime N (alternatingDomain N I O) root (2*m) ω))] with t ht
  unfold traversalExteriorMarkedTest
  dsimp only
  simp only [mem_univ,if_true]
  split_ifs
  · exact hω t ht.le
  · rfl

theorem physicalWordWindow_soft_eq_exterior (N : Size) (I O : Finset (Vertex N)) (c root : Vertex N)
    (m : ℕ) (w : Fin (2*m) → Vertex N) (U : ℝ) (F : WalkSample × ℝ → ℝ≥0∞)
    (E : TraversalExteriorSample m × ℝ → ℝ≥0∞)
    (he : ∀ᵐ ω ∂walkLaw[|{ω | adaptiveExitWord N (alternatingDomain N I O) root (2*m) ω = w}],
      ∀ t, adaptiveExitTime N (alternatingDomain N I O) root (2*m) ω ≤ t →
        F (ω,t) = E (traversalExteriorData N I O root m ω,t-adaptiveExitTime N (alternatingDomain N I O) root (2*m) ω))
    (l r : ℝ) :
    physicalWordWindow N I O root m w (fun z => if localTime N root z.1 z.2 c/g ≤ U then F z else 0) l r =
      r8SoftPhysicalExteriorSlice N I O c root m w U E l r := by
  apply lintegral_congr_ae
  filter_upwards [he] with ω hω
  apply lintegral_congr_ae
  filter_upwards [ae_restrict_mem (measurableSet_Ioi
    (a := adaptiveExitTime N (alternatingDomain N I O) root (2*m) ω))] with t ht
  split_ifs
  · exact hω t ht.le
  · rfl
  · rfl


end TorusCoverTime.Blocks.B
