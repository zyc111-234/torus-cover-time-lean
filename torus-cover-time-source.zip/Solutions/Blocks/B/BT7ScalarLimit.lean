import Solutions.Blocks.B.BT7Parameters
import Solutions.Blocks.B.R10WitnessAlgebra

noncomputable section
open Filter Asymptotics
open scoped Topology
namespace TorusCoverTime.Blocks.B

theorem bt7_polylog_negative_power (ε B r : ℝ) (hr : r<0) :
    Tendsto (fun L : ℝ => (ε*Real.log L+B+1)*L^r) atTop (𝓝 0) := by
  have hl := (isLittleO_log_rpow_atTop (neg_pos.mpr hr)).tendsto_div_nhds_zero
  have hp := tendsto_rpow_neg_atTop (neg_pos.mpr hr)
  have he : Tendsto (fun L : ℝ => ε*(Real.log L/L^(-r))+(B+1)*L^r) atTop (𝓝 0) := by
    simpa only [neg_neg,mul_zero,add_zero] using (hl.const_mul ε).add (hp.const_mul (B+1))
  apply he.congr'
  filter_upwards [eventually_ge_atTop (0:ℝ)] with L hL
  rw [Real.rpow_neg hL,div_inv_eq_mul]
  ring

theorem bt7_log_squared_exponential (M : ℝ) :
    Tendsto (fun L : ℝ => L^M*Real.exp (-(Real.log L)^2/4)) atTop (𝓝 0) := by
  apply squeeze_zero' (by filter_upwards [eventually_ge_atTop (0:ℝ)] with L hL; positivity) ?_ tendsto_inv_atTop_zero
  filter_upwards [eventually_gt_atTop (0:ℝ),Real.tendsto_log_atTop.eventually_ge_atTop (max 0 (4*(M+1)))] with L hL hl
  have hl0 : 0≤Real.log L := (le_max_left _ _).trans hl
  have hlM : 4*(M+1)≤Real.log L := (le_max_right _ _).trans hl
  rw [Real.rpow_def_of_pos hL,← Real.exp_add,← Real.exp_log hL,← Real.exp_neg]
  apply Real.exp_le_exp.mpr
  simp only [Real.log_exp]
  nlinarith [mul_nonneg hl0 (sub_nonneg.mpr hlM)]

theorem bt7_polylog_exponential (ε B M : ℝ) :
    Tendsto (fun L : ℝ => (ε*Real.log L+B+1)*L^M*Real.exp (-(Real.log L)^2/4)) atTop (𝓝 0) := by
  have hlog : Tendsto (fun L : ℝ => (ε*Real.log L+B+1)/L) atTop (𝓝 0) := by
    have hh := bt7_polylog_negative_power ε B (-1) (by norm_num)
    simpa only [Real.rpow_neg_one,div_eq_mul_inv] using hh
  have hh := hlog.mul (bt7_log_squared_exponential (M+1))
  simp only [mul_zero] at hh
  apply hh.congr'
  filter_upwards [eventually_gt_atTop (0:ℝ)] with L hL
  rw [Real.rpow_add hL,Real.rpow_one]
  field_simp
  <;> ring

theorem bt7_polylog_stretched_exponential (ε B M a c : ℝ) (ha : 0<a) (hc : 0<c) :
    Tendsto (fun L : ℝ => (ε*Real.log L+B+1)*L^M*Real.exp (-c*L^a)) atTop (𝓝 0) := by
  have hlog : Tendsto (fun L : ℝ => (ε*Real.log L+B+1)/L) atTop (𝓝 0) := by
    simpa only [Real.rpow_neg_one,div_eq_mul_inv] using bt7_polylog_negative_power ε B (-1) (by norm_num)
  have hh := hlog.mul (polynomial_times_stretched_exp_tendsto_zero a c (M+1) ha hc)
  simp only [mul_zero] at hh
  apply hh.congr'
  filter_upwards [eventually_gt_atTop (0:ℝ)] with L hL
  rw [Real.rpow_add hL,Real.rpow_one]
  field_simp
  <;> ring

def bt7ScalarBound (L γ ε B K F : ℝ) : ℝ :=
  (ε*Real.log L+B+1)*Real.exp (8*(ε*Real.log L+B))*
    (F*L^(160*γ)/Real.sqrt (L^(1/10:ℝ))+F*L*Real.exp (-(Real.log L)^2/4)+
      L*Real.exp (-(L^(12*γ))^2/(2*K)))

theorem bt7ScalarBound_tendsto_zero (γ ε B K F : ℝ) (hγ : 0<γ) (hK : 0<K)
    (hmargin : 8*ε+160*γ<1/20) :
    Tendsto (fun L : ℝ => bt7ScalarBound L γ ε B K F) atTop (𝓝 0) := by
  have h1 := (bt7_polylog_negative_power ε B (8*ε+160*γ-1/20) (by linarith)).const_mul F
  have h2 := (bt7_polylog_exponential ε B (8*ε+1)).const_mul F
  have h3 := bt7_polylog_stretched_exponential ε B (8*ε+1) (24*γ) (1/(2*K)) (by linarith) (by positivity)
  have hh := ((h1.add h2).add h3).const_mul (Real.exp (8*B))
  simp only [mul_zero,add_zero] at hh
  apply hh.congr'
  filter_upwards [eventually_gt_atTop (0:ℝ)] with L hL
  have he : Real.exp (8*(ε*Real.log L+B))=Real.exp (8*B)*L^(8*ε) := by
    rw [Real.rpow_def_of_pos hL,← Real.exp_add]
    congr 1
    ring
  have hs : Real.sqrt (L^(1/10:ℝ))=L^(1/20:ℝ) := by
    rw [Real.sqrt_eq_rpow,← Real.rpow_mul hL.le]
    norm_num
  have hp : L^(8*ε)*L^(160*γ)/Real.sqrt (L^(1/10:ℝ))=L^(8*ε+160*γ-1/20) := by
    rw [hs,← Real.rpow_add hL,← Real.rpow_sub hL]
  have hp2 : L^(8*ε)*L=L^(8*ε+1) := by rw [Real.rpow_add hL,Real.rpow_one]
  have hp3 : -(L^(12*γ))^2/(2*K)=-(1/(2*K))*L^(24*γ) := by
    rw [← Real.rpow_mul_natCast hL.le]
    have hx : 12*γ*(2:ℕ)=24*γ := by ring
    rw [hx]
    ring
  unfold bt7ScalarBound
  rw [he,hp3]
  calc
    _ = Real.exp (8*B)*
        (F*(ε*Real.log L+B+1)*(L^(8*ε)*L^(160*γ)/Real.sqrt (L^(1/10:ℝ)))+
          F*(ε*Real.log L+B+1)*(L^(8*ε)*L)*Real.exp (-(Real.log L)^2/4)+
          (ε*Real.log L+B+1)*(L^(8*ε)*L)*Real.exp (-(1/(2*K))*L^(24*γ))) := by rw [hp,hp2]; ring
    _ = _ := by ring

end TorusCoverTime.Blocks.B
