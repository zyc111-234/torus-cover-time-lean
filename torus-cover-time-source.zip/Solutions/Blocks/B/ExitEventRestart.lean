import Solutions.Blocks.B.ConditionedExitRestart
import Solutions.Blocks.B.AnnularConditioning
import Solutions.Blocks.B.RootExcursionSeries

/-! Restart a measurable path event at the actual finite exit. The endpoint
is summed, rather than prescribed independently of the stopped path. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

def exitRestartEvent (N : Size) (D : Finset (Vertex N)) (a : Vertex N)
    (E : Vertex N → Set WalkSample) : Set WalkSample :=
  ⋃ z, exitsThrough N D a z ∩ finiteExitTail N D a ⁻¹' E z

theorem exitRestartEvent_measurable (N : Size) (D : Finset (Vertex N)) (a : Vertex N)
    (E : Vertex N → Set WalkSample) (hE : ∀ z, MeasurableSet (E z)) :
    MeasurableSet (exitRestartEvent N D a E) :=
  MeasurableSet.iUnion fun z => (measurableSet_exitsThrough N D a z).inter
    ((hE z).preimage (finiteExitTail_measurable N D a))

theorem exitRestartEvent_probability (N : Size) (D : Finset (Vertex N))
    (hD : ∃ z : Vertex N, z ∉ D) (a : Vertex N)
    (E : Vertex N → Set WalkSample) (hE : ∀ z, MeasurableSet (E z)) :
    walkLaw.real (exitRestartEvent N D a E) =
      ∑ z, exitHarmonic N D z a * walkLaw.real (E z) := by
  unfold exitRestartEvent
  rw [measureReal_iUnion_fintype]
  · apply Finset.sum_congr rfl
    intro z _
    have he := (finiteExitRecord_tail_independent N D hD a).measure_inter_preimage_eq_mul
      (exitRecordEvent N D a z) (E z) (exitRecordEvent_measurable N D a z) (hE z)
    rw [← exitsThrough_eq_record_preimage,
      (finiteExitTail_measurePreserving N D hD a).measure_preimage (hE z).nullMeasurableSet] at he
    exact congrArg ENNReal.toReal he |>.trans ENNReal.toReal_mul
  · intro z y hzy
    exact (exitsThrough_disjoint N D a z y hzy).mono inter_subset_left inter_subset_left
  · intro z
    exact (measurableSet_exitsThrough N D a z).inter
      ((hE z).preimage (finiteExitTail_measurable N D a))

theorem exitsThroughAt_append (N : Size) (D O : Finset (Vertex N)) (hDO : D ⊆ O)
    (a z b : Vertex N) (ω : WalkSample) (m n : ℕ)
    (hm : exitsThroughAt N D a z ω m)
    (hn : exitsThroughAt N O z b (fun j => ω (m+j)) n) :
    exitsThroughAt N O a b ω (m+n) := by
  refine ⟨hn.1, ?_, ?_⟩
  · rw [position_shift_sample, hm.2.1]
    exact hn.2.1
  · intro j
    by_cases hj : j.val < m
    · exact hDO (hm.2.2 ⟨j.val,hj⟩)
    · have he : j.val = m+(j.val-m) := by omega
      rw [he, position_shift_sample, hm.2.1]
      exact hn.2.2 ⟨j.val-m,by omega⟩

theorem exitRestartEvent_subset_exit (N : Size) (D O : Finset (Vertex N)) (hDO : D ⊆ O)
    (a b : Vertex N) (E : Vertex N → Set WalkSample)
    (hE : ∀ z, E z ⊆ exitsThrough N O z b) :
    exitRestartEvent N D a E ⊆ exitsThrough N O a b := by
  intro ω hω
  obtain ⟨z,hz,hη⟩ := mem_iUnion.mp hω
  obtain ⟨m,hm⟩ := hz
  obtain ⟨n,hn⟩ := hE z hη
  have ht : finiteExitTail N D a ω = fun j => ω (m+j) := by
    change (fun j => ω (finiteExitIndex N D a ω+j)) = _
    rw [finiteExitIndex_of_exit_word N D a z ω m hm]
  rw [ht] at hn
  exact ⟨m+n,exitsThroughAt_append N D O hDO a z b ω m n hm hn⟩

theorem exactExitLaw_real_of_subset (N : Size) (D : Finset (Vertex N)) (a b : Vertex N)
    (E : Set WalkSample) (hE : E ⊆ exitsThrough N D a b) :
    (exactExitLaw N D a b).real E = walkLaw.real E / exitHarmonic N D b a := by
  have he := cond_apply (μ := walkLaw) (measurableSet_exitsThrough N D a b) E
  rw [inter_eq_right.mpr hE] at he
  have hr := congrArg ENNReal.toReal he
  simpa only [exactExitLaw, measureReal_def, ENNReal.toReal_mul, ENNReal.toReal_inv,
    exitHarmonic, div_eq_mul_inv, mul_comm] using hr

end TorusCoverTime.Blocks.B
