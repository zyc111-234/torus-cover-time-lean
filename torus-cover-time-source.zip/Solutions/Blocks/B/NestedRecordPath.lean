import Solutions.Blocks.B.NestedRecordLaw
import Solutions.Blocks.B.NestedTraversalInjection
import Solutions.Blocks.B.AdaptiveExitDisintegration

/-! Identification of every finite outward-record count with its actual
path block, and domination by the full inner count on a fixed outer slice. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

theorem all_shifts_finiteTraversalRecordCount_ae (N : Size) (O I J : Finset (Vertex N))
    (hIJ : I ⊆ J) (hI : I.Nonempty) :
    ∀ᵐ ω ∂walkLaw, ∀ s : ℕ, ∀ a : Vertex N, a ∉ J →
      finiteTraversalRecordCount N I J a (finiteExitRecord N O a (fun i => ω (s+i))) =
        nestedTraversalCount N O I J a (fun i => ω (s+i)) := by
  apply ae_all_iff.mpr
  intro s
  apply ae_all_iff.mpr
  intro a
  by_cases ha : a ∈ J
  · exact Eventually.of_forall fun _ hn => False.elim (hn ha)
  · filter_upwards [(fixedShift_measurePreserving s).quasiMeasurePreserving.ae
      (finiteTraversalRecordCount_exit_ae N O I J hIJ hI a ha)] with ω hω
    exact fun _ => hω

theorem outerBlockNestedCount_record_ae (N : Size) (Q O I J : Finset (Vertex N))
    (hIJ : I ⊆ J) (hI : I.Nonempty) (root : Vertex N)
    (hentry : ∀ᵐ ω ∂walkLaw, ∀ j : ℕ,
      adaptiveExitStart N (alternatingDomain N Q O) root (2*j+1) ω ∉ J) :
    ∀ᵐ ω ∂walkLaw, ∀ j : ℕ,
      finiteTraversalRecordCount N I J
        (adaptiveExitStart N (alternatingDomain N Q O) root (2*j+1) ω)
        (adaptiveExitRecord N (alternatingDomain N Q O) root (2*j+1) ω) =
        outerBlockNestedCount N Q O I J root j ω := by
  filter_upwards [all_shifts_finiteTraversalRecordCount_ae N O I J hIJ hI, hentry] with ω hω he
  intro j
  dsimp only [adaptiveExitRecord,outerBlockNestedCount,adaptiveExitTail]
  rw [alternatingDomain_odd]
  exact hω (adaptiveExitIndex N (alternatingDomain N Q O) root (2*j+1) ω)
      (adaptiveExitStart N (alternatingDomain N Q O) root (2*j+1) ω) (he j)

def wordRecordNestedCount (N : Size) (I J : Finset (Vertex N)) (root : Vertex N)
    (m : ℕ) (w : Fin (2*m) → Vertex N) (p : Fin (2*m) → ℕ × WalkSample) : ℝ :=
  recordProductNestedCount N I J m (fun i => endpointWordStart root w (2*i.val+1))
    (fun i => p (outwardRecordIndex m i))

theorem wordRecordNestedCount_measurable (N : Size) (I J : Finset (Vertex N)) (root : Vertex N)
    (m : ℕ) (w : Fin (2*m) → Vertex N) : Measurable (wordRecordNestedCount N I J root m w) :=
  (recordProductNestedCount_measurable N I J m _).comp
    (measurable_pi_lambda _ fun i => measurable_pi_apply (outwardRecordIndex m i))

theorem wordRecordNestedCount_actual_ae (N : Size) (Q O I J : Finset (Vertex N))
    (hIJ : I ⊆ J) (hI : I.Nonempty) (root : Vertex N) (m : ℕ) (w : Fin (2*m) → Vertex N)
    (hentry : ∀ᵐ ω ∂walkLaw, ∀ j : ℕ,
      adaptiveExitStart N (alternatingDomain N Q O) root (2*j+1) ω ∉ J) :
    ∀ᵐ ω ∂walkLaw[|{ω | adaptiveExitWord N (alternatingDomain N Q O) root (2*m) ω = w}],
      wordRecordNestedCount N I J root m w
        (fun j : Fin (2*m) => adaptiveExitRecord N (alternatingDomain N Q O) root j.val ω) =
        ∑ i : Fin m, (outerBlockNestedCount N Q O I J root i.val ω:ℝ) := by
  have hac : walkLaw[|{ω | adaptiveExitWord N (alternatingDomain N Q O) root (2*m) ω = w}] ≪
      walkLaw := cond_absolutelyContinuous
  filter_upwards [hac.ae_le (outerBlockNestedCount_record_ae N Q O I J hIJ hI root hentry),
    ae_cond_mem (μ := walkLaw)
      ((adaptiveExitWord_measurable N (alternatingDomain N Q O) root (2*m)) (measurableSet_singleton w))]
    with ω hc hw
  change adaptiveExitWord N (alternatingDomain N Q O) root (2*m) ω = w at hw
  unfold wordRecordNestedCount recordProductNestedCount
  apply Finset.sum_congr rfl
  intro i _
  have hci := hc i.val
  rw [adaptiveExitStart_of_word N _ root (2*m) w ω hw (2*i.val+1) (by omega)] at hci
  exact congrArg (fun k : ℕ => (k:ℝ)) hci

theorem wordRecordNestedCount_path_le_ae (N : Size) (Q O I J : Finset (Vertex N))
    (hQO : Q ⊆ O) (hQ : Q.Nonempty) (hIJ : I ⊆ J) (hI : I.Nonempty)
    (hJO : J ⊆ O) (root : Vertex N) (hr : root ∉ O) (m : ℕ) (w : Fin (2*m) → Vertex N)
    (hentry : ∀ᵐ ω ∂walkLaw, ∀ j : ℕ,
      adaptiveExitStart N (alternatingDomain N Q O) root (2*j+1) ω ∉ J) :
    ∀ᵐ ω ∂walkLaw[|{ω | adaptiveExitWord N (alternatingDomain N Q O) root (2*m) ω = w}],
      ∀ t : ℝ, 0 ≤ t → completedTraversalCount N Q O root ω t = m →
      wordRecordNestedCount N I J root m w
        (fun j : Fin (2*m) => adaptiveExitRecord N (alternatingDomain N Q O) root j.val ω) ≤
        (completedTraversalCount N I J root ω t:ℝ) := by
  have hac : walkLaw[|{ω | adaptiveExitWord N (alternatingDomain N Q O) root (2*m) ω = w}] ≪
      walkLaw := cond_absolutelyContinuous
  filter_upwards [wordRecordNestedCount_actual_ae N Q O I J hIJ hI root m w hentry,
    hac.ae_le (sum_outerBlockNestedCount_le_ae N Q O I J hQO hQ hIJ hI hJO root hr hentry)]
    with ω he hc
  intro t ht hm
  rw [he]
  have hsum : (∑ i : Fin m, (outerBlockNestedCount N Q O I J root i.val ω:ℝ)) =
      ((∑ j ∈ Finset.range m, outerBlockNestedCount N Q O I J root j ω):ℕ) := by
    rw [Nat.cast_sum]
    exact Fin.sum_univ_eq_sum_range (fun j => (outerBlockNestedCount N Q O I J root j ω:ℝ)) m
  rw [hsum]
  have hh := hc t ht
  rw [hm] at hh
  exact_mod_cast hh

end TorusCoverTime.Blocks.B
