import Solutions.Blocks.B.DirichletIntegerChain
import Solutions.Blocks.B.SparseIntegerGrid

noncomputable section
namespace TorusCoverTime.Blocks.B

theorem bt6IntegerPath_clock_error (N : Size) (root c x : Vertex N) (ρ : ℝ) (M : ℕ)
    (hρ : 0<ρ) (hR : 1≤ρ*(N.val:ℝ)) (hsmall : 2*(ρ*(N.val:ℝ)+1)<N.val)
    (hdeep : periodicDistance x c+(Real.exp ((M:ℝ)+1)+1)≤ρ*(N.val:ℝ)/2)
    (hroot : root∉torusDisk N c (ρ*(N.val:ℝ))) (i : Fin (M+2)) :
    |(bt6IntegerPath N root c x (ρ*(N.val:ℝ)) M hdeep hroot).clock i-
      sparseClockTime (logSize N) 1 (M+1) i/2|≤bt6ClockError ρ := by
  by_cases hi0 : i.val=0
  · have he : i=0 := Fin.ext hi0
    rw [he,GaussianClockPath.clock_zero]
    simp only [sparseClockTime,Fin.val_zero,show ¬(0=M+1) by omega,if_false,Nat.cast_one,
      Nat.cast_zero,mul_zero,zero_div,sub_zero,abs_zero]
    exact (bt6ClockError_pos ρ).le
  by_cases hil : i.val=M+1
  · have he : i=Fin.last (M+1) := Fin.ext hil
    rw [he,bt6IntegerPath_clock,bt6IntegerDomain_last]
    simp only [sparseClockTime,Fin.val_last,if_true]
    apply dirichlet_macroscopic_clock N root c x ρ hρ hR hsmall hroot
    have hh := Real.exp_pos ((M:ℝ)+1)
    linarith
  · have hh := bt6IntegerPath_interior_clock N root c x (ρ*(N.val:ℝ)) M hdeep hroot hsmall i hi0 hil
    simp only [sparseClockTime,if_neg hil,Nat.cast_one,one_mul]
    refine hh.trans ?_
    unfold bt6ClockError
    linarith [abs_nonneg (Real.log ρ)]

theorem bt6_subsample_clock_error (N : Size) (root c x : Vertex N) (ρ : ℝ) (K M n : ℕ)
    (hρ : 0<ρ) (hR : 1≤ρ*(N.val:ℝ)) (hsmall : 2*(ρ*(N.val:ℝ)+1)<N.val)
    (hdeep : periodicDistance x c+(Real.exp ((M:ℝ)+1)+1)≤ρ*(N.val:ℝ)/2)
    (hroot : root∉torusDisk N c (ρ*(N.val:ℝ))) (hK : 0<K) (hn : 0<n) (hlo : K*(n-1)≤M)
    (i : Fin (n+1)) :
    |(bt6IntegerPath N root c x (ρ*(N.val:ℝ)) M hdeep hroot).clock (bt6GridIndex K M n hK hn hlo i)-
      sparseClockTime (logSize N) K n i/2|≤bt6ClockError ρ := by
  have hh := bt6IntegerPath_clock_error N root c x ρ M hρ hR hsmall hdeep hroot (bt6GridIndex K M n hK hn hlo i)
  have he : sparseClockTime (logSize N) 1 (M+1) (bt6GridIndex K M n hK hn hlo i)=
      sparseClockTime (logSize N) K n i := by
    by_cases hil : i.val=n
    · simp [sparseClockTime,bt6GridIndex,hil]
    · have hiM : K*i.val≤M := (Nat.mul_le_mul_left K (show i.val≤n-1 by have := i.isLt; omega)).trans hlo
      simp only [sparseClockTime,bt6GridIndex,if_neg hil,if_neg (show K*i.val≠M+1 by omega),
        Nat.cast_one,one_mul,Nat.cast_mul]
  rwa [he] at hh

theorem bt6_clock_nearest_gap {Ω : Type*} [MeasurableSpace Ω] {μ : MeasureTheory.Measure Ω}
    [MeasureTheory.IsProbabilityMeasure μ] (K M n : ℕ) (W : GaussianClockPath μ (M+1))
    (hK : 0<K) (hn : 0<n) (hlo : K*(n-1)≤M) (hhi : M<K*n) (L C : ℝ)
    (hsize : 4*C≤(K:ℝ)) (herr : ∀ i, |W.clock i-sparseClockTime L 1 (M+1) i/2|≤C)
    (j : Fin (M+2)) :
    W.clock j-W.clock (bt6GridIndex K M n hK hn hlo (bt6NearestGrid K M n hK hhi j))≤K := by
  let f := bt6GridIndex K M n hK hn hlo
  let g := bt6NearestGrid K M n hK hhi
  change W.clock j-W.clock (f (g j))≤K
  have hg := bt6_nearest_grid_gap K M n hK hn hlo hhi j
  by_cases hlast : j.val=M+1
  · have he : f (g j)=j := by
      apply Fin.ext
      simp [f,g,bt6NearestGrid,bt6GridIndex,hlast]
    rw [he,sub_self]
    positivity
  · have hfLast : (f (g j)).val≠M+1 := by
      have hjM : j.val≤M := by have := j.isLt; omega
      have hle : (f (g j)).val≤j.val := hg.1
      omega
    have hj := abs_le.mp (herr j)
    have hf := abs_le.mp (herr (f (g j)))
    simp only [sparseClockTime,if_neg hlast,Nat.cast_one,one_mul] at hj
    simp only [sparseClockTime,if_neg hfLast,Nat.cast_one,one_mul] at hf
    have hd : (j.val:ℝ)-(f (g j)).val≤K := by
      have hc : ((j.val-(f (g j)).val:ℕ):ℝ)=(j.val:ℝ)-(f (g j)).val := Nat.cast_sub hg.1
      rw [← hc]
      exact_mod_cast hg.2.le
    linarith

end TorusCoverTime.Blocks.B
