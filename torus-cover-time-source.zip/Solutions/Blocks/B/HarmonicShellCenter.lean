import Solutions.Blocks.B.HarmonicShellTail

/-! A deterministic lower center for all compact central shells. This is the
paper's m_L, with the original Phase A time center and its logarithmic term. -/

noncomputable section
open MeasureTheory Filter Set Classical
open scoped ENNReal NNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

def harmonicExtremeCenter (N : Size) : ℝ :=
  (2*logSize N-3/4*Real.log (logSize N))/Real.sqrt 2

def harmonicShellCenterError (H : ℝ) : ℝ := 2*H*Real.sqrt g/Real.sqrt (2*g)

theorem harmonicShellCenterError_nonneg (H : ℝ) (hH : 0 ≤ H) :
    0 ≤ harmonicShellCenterError H := by unfold harmonicShellCenterError; positivity

theorem shell_center_lower (N : Size) (H θ : ℝ) (hH : 0 ≤ H)
    (hθ : |θ| ≤ H) (hL : 1 ≤ logSize N) (hHL : 4*H ≤ logSize N) :
    harmonicExtremeCenter N-harmonicShellCenterError H ≤
      Real.sqrt (D.shellEnergyParameter N θ-greenDiagonal N)/Real.sqrt (2*g) := by
  have hg := coarseProbe_g_pos
  have hs := D.shellEnergyParameter_bounds N H θ hH hθ hL hHL
  let k := 2*logSize N-3/4*Real.log (logSize N)
  let x := Real.sqrt g*k
  let y := Real.sqrt (D.shellEnergyParameter N θ-greenDiagonal N)
  have hk : logSize N ≤ k := by
    dsimp [k]
    linarith [Real.log_le_self (logSize_pos N).le]
  have hy : Real.sqrt g*logSize N ≤ y := by
    calc
      _ = Real.sqrt (g*logSize N^2) := by rw [Real.sqrt_mul hg.le,Real.sqrt_sq (logSize_pos N).le]
      _ ≤ _ := Real.sqrt_le_sqrt hs.1
  have hx : Real.sqrt g*logSize N ≤ x := mul_le_mul_of_nonneg_left hk (Real.sqrt_nonneg _)
  have hx2 : x^2 = g*k^2 := by dsimp [x]; rw [mul_pow,Real.sq_sqrt hg.le]
  have hy2 : y^2 = g*k^2+greenDiagonal N+2*θ*g*logSize N := by
    dsimp [y]
    rw [Real.sq_sqrt ((show 0 ≤ g*logSize N^2 by positivity).trans hs.1),D.shellEnergyParameter_square]
    dsimp [k]
    ring
  have hθmul := mul_le_mul_of_nonneg_right (abs_le.mp hθ).1
    (show 0 ≤ 2*g*logSize N by positivity)
  have ht : 0 ≤ 2*H*Real.sqrt g := by positivity
  have hprod := mul_le_mul_of_nonneg_left hy ht
  have hsqrt := Real.sq_sqrt hg.le
  have hprod' : 2*H*g*logSize N ≤ (2*H*Real.sqrt g)*(x+y) := by
    have hx0 : 0 ≤ x := le_trans (by positivity) hx
    have he : (2*H*Real.sqrt g)*(Real.sqrt g*logSize N) = 2*H*g*logSize N := by
      calc
        _ = 2*H*(Real.sqrt g)^2*logSize N := by ring
        _ = _ := by rw [hsqrt]
    rw [he] at hprod
    nlinarith
  have hxy : x-2*H*Real.sqrt g ≤ y := by
    have hp : 0 < x+y := by have := logSize_pos N; have := Real.sqrt_pos.mpr hg; nlinarith
    by_contra hb
    have hm := mul_pos (show 0 < x-y-2*H*Real.sqrt g by linarith) hp
    nlinarith [greenDiagonal_pos N]
  have hdiv := div_le_div_of_nonneg_right hxy (Real.sqrt_nonneg (2*g))
  have he : x/Real.sqrt (2*g) = harmonicExtremeCenter N := by
    dsimp [x,k,harmonicExtremeCenter]
    rw [Real.sqrt_mul (by norm_num : (0:ℝ) ≤ 2)]
    field_simp [(Real.sqrt_pos.mpr hg).ne']
  rw [sub_div,he] at hdiv
  exact hdiv

theorem shell_center_lower_uniform (H : ℝ) (hH : 0 ≤ H) :
    ∀ᶠ N : Size in atTop, ∀ θ : ℝ, |θ| ≤ H →
      harmonicExtremeCenter N-harmonicShellCenterError H ≤
        Real.sqrt (D.shellEnergyParameter N θ-greenDiagonal N)/Real.sqrt (2*g) := by
  filter_upwards [blockB_logSize_tendsto.eventually_ge_atTop 1,
    blockB_logSize_tendsto.eventually_ge_atTop (4*H)] with N hL hHL
  intro θ hθ
  exact shell_center_lower N H θ hH hθ hL hHL

theorem negative_square_exp_antitone (a b V : ℝ) (ha : 0 ≤ a) (hab : a ≤ b) (hV : 0 ≤ V) :
    Real.exp (-b^2/V) ≤ Real.exp (-a^2/V) := by
  apply Real.exp_le_exp.mpr
  exact div_le_div_of_nonneg_right (by nlinarith) hV

def harmonicShellTailShift (H : ℝ) : ℝ := harmonicShellCenterError H+1/Real.sqrt (2*g)

theorem harmonic_shell_tail_uniform (H : ℝ) (hH : 0 ≤ H) :
    ∃ c₀ C : ℝ, 0 < c₀ ∧ 0 < C ∧ ∀ᶠ N : Size in atTop,
      ∀ θ : ℝ, |θ| ≤ H → ∀ c : Vertex N, ∀ q v : ℝ,
        0 ≤ q → q ≤ logSize N → 2*(Real.exp (q+1)+1) < N.val →
        harmonicShellMass N θ c q v ≤
          ENNReal.ofReal (4*C*Real.exp (-(max
            (harmonicExtremeCenter N-v-harmonicShellTailShift H*Real.log (logSize N)) 0)^2 /
                (logSize N-q+2*harmonicVarianceErrorConstant))) +
          ENNReal.ofReal (C*vertexCount N*logSize N^2*
            Real.exp (-c₀*logSize N*Real.log (logSize N))) := by
  obtain ⟨c₀,C,hc,hC,hbound⟩ := harmonic_shell_tail H 1 hH zero_lt_one
  have hl := Real.tendsto_log_atTop.comp blockB_logSize_tendsto
  refine ⟨c₀,C,hc,hC,?_⟩
  filter_upwards [hbound,shell_center_lower_uniform H hH,hl.eventually_ge_atTop 1] with N hN hs hlog
  intro θ hθ c q v hq hqL hsmall
  have hh := hN θ hθ c q v hq hqL hsmall
  simp only [one_mul,mul_one] at hh
  apply hh.trans
  apply add_le_add _ le_rfl
  apply ENNReal.ofReal_le_ofReal
  apply mul_le_mul_of_nonneg_left _ (by positivity : 0 ≤ 4*C)
  apply negative_square_exp_antitone _ _ _ (le_max_right _ _)
  · apply max_le_max _ le_rfl
    have hm := mul_le_mul_of_nonneg_left hlog (harmonicShellCenterError_nonneg H hH)
    change harmonicShellCenterError H*1 ≤ harmonicShellCenterError H*Real.log (logSize N) at hm
    dsimp [harmonicShellTailShift]
    have hcN := hs θ hθ
    rw [add_mul,one_div_mul_eq_div]
    linarith
  · have := harmonicVarianceErrorConstant_pos
    linarith

end TorusCoverTime.Blocks.B
