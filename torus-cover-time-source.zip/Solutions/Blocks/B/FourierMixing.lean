import Solutions.Blocks.B.FixedCapacity
import Mathlib.Algebra.Order.Field.GeomSum

/-! Uniform Fourier mixing bounds by finite geometric sums. -/

noncomputable section
open Filter
open scoped BigOperators Topology

namespace TorusCoverTime.Blocks.B

lemma sum_nonzero_zmod_powers (N : Size) (q : ℝ) (hq : 0 ≤ q) (hq1 : q < 1) :
    (∑ a ∈ (Finset.univ.erase (0 : ZMod N.val)), q ^ a.val) ≤ q / (1 - q) := by
  classical
  have heq : (∑ a ∈ (Finset.univ.erase (0 : ZMod N.val)), q ^ a.val) =
      ∑ j ∈ Finset.Ico 1 N.val, q ^ j := by
    apply Finset.sum_bij (fun a _ => a.val)
    · intro a ha
      exact Finset.mem_Ico.mpr ⟨ZMod.val_pos.mpr (Finset.mem_erase.mp ha).1, ZMod.val_lt a⟩
    · intro a _ b _ hab
      exact ZMod.val_injective N.val hab
    · intro j hj
      have hj' := Finset.mem_Ico.mp hj
      refine ⟨(j : ZMod N.val), ?_, ZMod.val_cast_of_lt hj'.2⟩
      apply Finset.mem_erase.mpr
      refine ⟨?_, Finset.mem_univ _⟩
      intro heq
      have hv := congrArg ZMod.val heq
      rw [ZMod.val_cast_of_lt hj'.2, ZMod.val_zero] at hv
      omega
    · intro a _
      rfl
  rw [heq]
  simpa using (geom_sum_Ico_le_of_lt_one (m := 1) (n := N.val) hq hq1)

lemma sum_nonzero_neg (N : Size) (f : ZMod N.val → ℝ) :
    (∑ a ∈ (Finset.univ.erase (0 : ZMod N.val)), f (-a)) =
      ∑ a ∈ (Finset.univ.erase (0 : ZMod N.val)), f a := by
  classical
  apply Finset.sum_bij (fun a _ => -a)
  · intro a ha
    simpa using ha
  · intro a _ b _ hab
    exact neg_injective hab
  · intro b hb
    exact ⟨-b, by simpa using hb, by simp⟩
  · intro a _
    rfl

lemma coordinate_gaussian_bound (N : Size) (r : ℝ) (hr : 0 ≤ r)
    (a : ZMod N.val) (ha : a ≠ 0) :
    Real.exp (-r * (coordinateDistance a 0) ^ 2) ≤
      Real.exp (-r) ^ a.val + Real.exp (-r) ^ (-a).val := by
  let : NeZero a := ⟨ha⟩
  have ha1 : (1 : ℝ) ≤ a.val := by exact_mod_cast ZMod.val_pos.mpr ha
  have haN : (a.val : ℝ) + 1 ≤ N.val := by exact_mod_cast ZMod.val_lt a
  have hneg : ((-a).val : ℝ) = (N.val : ℝ) - a.val := by
    rw [ZMod.val_neg_of_ne_zero a, Nat.cast_sub (ZMod.val_lt a).le]
  rw [coordinateDistance_zero_eq_min]
  by_cases hleft : (a.val : ℝ) ≤ (N.val : ℝ) - a.val
  · rw [min_eq_left hleft]
    calc
      _ ≤ Real.exp (-r * (a.val : ℝ)) := by
        apply Real.exp_le_exp.mpr
        nlinarith [mul_nonneg hr (show 0 ≤ (a.val : ℝ) ^ 2 - a.val by nlinarith)]
      _ = Real.exp (-r) ^ a.val := by rw [← Real.exp_nat_mul]; congr 1; ring
      _ ≤ _ := le_add_of_nonneg_right (by positivity)
  · rw [min_eq_right (le_of_not_ge hleft)]
    calc
      _ ≤ Real.exp (-r * ((N.val : ℝ) - a.val)) := by
        apply Real.exp_le_exp.mpr
        nlinarith [mul_nonneg hr
          (show 0 ≤ ((N.val : ℝ) - a.val) ^ 2 - ((N.val : ℝ) - a.val) by nlinarith)]
      _ = Real.exp (-r) ^ (-a).val := by rw [← Real.exp_nat_mul, hneg]; congr 1; ring
      _ ≤ _ := le_add_of_nonneg_left (by positivity)

lemma coordinate_gaussian_sum (N : Size) (r : ℝ) (hr : 0 ≤ r)
    (hq : Real.exp (-r) ≤ 1 / 2) :
    (∑ a : ZMod N.val, Real.exp (-r * (coordinateDistance a 0) ^ 2)) ≤
      1 + 4 * Real.exp (-r) := by
  classical
  have hq0 := (Real.exp_pos (-r)).le
  have hq1 : Real.exp (-r) < 1 := by linarith
  have hsum : (∑ a ∈ (Finset.univ.erase (0 : ZMod N.val)),
      Real.exp (-r * (coordinateDistance a 0) ^ 2)) ≤ 4 * Real.exp (-r) := by
    calc
      _ ≤ ∑ a ∈ (Finset.univ.erase (0 : ZMod N.val)),
          (Real.exp (-r) ^ a.val + Real.exp (-r) ^ (-a).val) := by
        apply Finset.sum_le_sum
        intro a ha
        exact coordinate_gaussian_bound N r hr a (Finset.mem_erase.mp ha).1
      _ = 2 * ∑ a ∈ (Finset.univ.erase (0 : ZMod N.val)), Real.exp (-r) ^ a.val := by
        rw [Finset.sum_add_distrib, sum_nonzero_neg N (fun a => Real.exp (-r) ^ a.val)]
        ring
      _ ≤ 2 * (Real.exp (-r) / (1 - Real.exp (-r))) :=
        mul_le_mul_of_nonneg_left (sum_nonzero_zmod_powers N _ hq0 hq1) (by norm_num)
      _ ≤ 4 * Real.exp (-r) := by
        have h := (div_le_iff₀ (by linarith : 0 < 1 - Real.exp (-r))).mpr
          (show Real.exp (-r) ≤ (2 * Real.exp (-r)) * (1 - Real.exp (-r)) by
            nlinarith [mul_nonneg hq0 (show 0 ≤ 1 - 2 * Real.exp (-r) by linarith)])
        linarith
  have hid := Finset.sum_erase_add (s := (Finset.univ : Finset (ZMod N.val)))
    (fun a => Real.exp (-r * (coordinateDistance a 0) ^ 2)) (Finset.mem_univ 0)
  have hz : Real.exp (-r * (coordinateDistance (0 : ZMod N.val) 0) ^ 2) = 1 := by
    simp [coordinateDistance]
  rw [hz] at hid
  linarith

lemma torus_gaussian_sum (N : Size) (r : ℝ) (hr : 0 ≤ r)
    (hq : Real.exp (-r) ≤ 1 / 2) :
    (∑ k ∈ nonzeroFrequencies N, Real.exp (-r * frequencyNormSq N k)) ≤
      16 * Real.exp (-r) := by
  classical
  have hprod : (∑ k : Vertex N, Real.exp (-r * frequencyNormSq N k)) =
      (∑ a : ZMod N.val, Real.exp (-r * (coordinateDistance a 0) ^ 2)) ^ 2 := by
    rw [Fintype.sum_prod_type]
    simp_rw [frequencyNormSq, mul_add, Real.exp_add]
    rw [← Finset.sum_mul_sum, pow_two]
  have hsum0 : 0 ≤ ∑ a : ZMod N.val, Real.exp (-r * (coordinateDistance a 0) ^ 2) :=
    Finset.sum_nonneg (fun _ _ => (Real.exp_pos _).le)
  have hsq := pow_le_pow_left₀ hsum0 (coordinate_gaussian_sum N r hr hq) 2
  have hid := Finset.sum_erase_add (s := (Finset.univ : Finset (Vertex N)))
    (fun k => Real.exp (-r * frequencyNormSq N k)) (Finset.mem_univ 0)
  have hz : Real.exp (-r * frequencyNormSq N 0) = 1 := by
    simp [frequencyNormSq, coordinateDistance]
  rw [hz, hprod] at hid
  have hq0 := (Real.exp_pos (-r)).le
  change (∑ k ∈ Finset.univ.erase 0, Real.exp (-r * frequencyNormSq N k)) ≤ _
  nlinarith [mul_nonneg hq0 (show 0 ≤ 1 / 2 - Real.exp (-r) by linarith)]

lemma eigenmode_sum_bound (N : Size) (t : ℝ) (ht : 0 ≤ t)
    (hq : Real.exp (-(4 * t / vertexCount N)) ≤ 1 / 2) :
    (∑ k ∈ nonzeroFrequencies N, Real.exp (-t * finiteEigenvalue N k)) ≤
      16 * Real.exp (-(4 * t / vertexCount N)) := by
  calc
    _ ≤ ∑ k ∈ nonzeroFrequencies N,
        Real.exp (-(4 * t / vertexCount N) * frequencyNormSq N k) := by
      apply Finset.sum_le_sum
      intro k _
      apply Real.exp_le_exp.mpr
      have h := mul_le_mul_of_nonneg_left (eigenvalue_frequency_bounds N k).1 ht
      have heq : t * (4 * frequencyNormSq N k / vertexCount N) =
          (4 * t / vertexCount N) * frequencyNormSq N k := by ring
      rw [heq] at h
      linarith
    _ ≤ _ := torus_gaussian_sum N _
      (div_nonneg (mul_nonneg (by norm_num) ht) (vertexCount_pos N).le) hq

lemma tailGreen_abs_le_eigenmode_sum (N : Size) (t : ℝ) (x y : Vertex N) :
    |tailGreen N t x y| ≤ ∑ k ∈ nonzeroFrequencies N, Real.exp (-t * finiteEigenvalue N k) := by
  unfold tailGreen
  rw [abs_div, abs_of_pos (vertexCount_pos N)]
  apply (div_le_iff₀ (vertexCount_pos N)).mpr
  rw [Finset.sum_mul]
  apply (Finset.abs_sum_le_sum_abs _ _).trans
  apply Finset.sum_le_sum
  intro k hk
  have hlambda := eigenvalue_pos_of_nonzero N hk
  have hnl : 1 ≤ vertexCount N * finiteEigenvalue N k := by
    have hg := vertexCount_mul_spectralGap_ge_four N
    have hmul := mul_le_mul_of_nonneg_left
      (spectralGap_le_eigenvalue N k (Finset.mem_erase.mp hk).1) (vertexCount_pos N).le
    linarith
  rw [abs_div, abs_mul, abs_of_pos (Real.exp_pos _), abs_of_pos hlambda]
  apply (div_le_iff₀ hlambda).mpr
  calc
    _ ≤ Real.exp (-t * finiteEigenvalue N k) := by
      simpa [finiteCosine] using mul_le_mul_of_nonneg_left (Real.abs_cos_le_one (fourierAngle N k (x - y)))
        (Real.exp_pos (-t * finiteEigenvalue N k)).le
    _ ≤ Real.exp (-t * finiteEigenvalue N k) *
        (vertexCount N * finiteEigenvalue N k) :=
      le_mul_of_one_le_right (Real.exp_pos _).le hnl
    _ = _ := by ring

lemma fourier_sum_abs_le_eigenmode_sum (N : Size) (t : ℝ) (x y : Vertex N) :
    |∑ k ∈ nonzeroFrequencies N, Real.exp (-t * finiteEigenvalue N k) *
      finiteCosine N k (x - y)| ≤ ∑ k ∈ nonzeroFrequencies N,
      Real.exp (-t * finiteEigenvalue N k) := by
  apply (Finset.abs_sum_le_sum_abs _ _).trans
  apply Finset.sum_le_sum
  intro k _
  rw [abs_mul, abs_of_pos (Real.exp_pos _)]
  simpa [finiteCosine] using mul_le_mul_of_nonneg_left (Real.abs_cos_le_one (fourierAngle N k (x - y)))
    (Real.exp_pos (-t * finiteEigenvalue N k)).le

lemma eventual_fourier_mixing_bounds :
    ∀ᶠ N : Size in atTop, ∀ t : ℝ, mixingTime N ≤ t → ∀ x y : Vertex N,
      |∑ k ∈ nonzeroFrequencies N, Real.exp (-t * finiteEigenvalue N k) *
        finiteCosine N k (x - y)| ≤ (logSize N) ^ (-8 : ℝ) ∧
      |tailGreen N t x y| ≤ (logSize N) ^ (-8 : ℝ) := by
  have hlim : Tendsto (fun N : Size => (logSize N) ^ (-8 : ℝ)) atTop (𝓝 0) := by
    simpa only [Function.comp_def] using
      (tendsto_rpow_neg_atTop (by norm_num : (0 : ℝ) < 8)).comp blockB_logSize_tendsto
  have hsmall : ∀ᶠ N : Size in atTop, (logSize N) ^ (-8 : ℝ) ≤ 1 / 16 :=
    (hlim.eventually (gt_mem_nhds (by norm_num : (0 : ℝ) < 1 / 16))).mono
      (fun _ h => le_of_lt h)
  filter_upwards [blockB_logSize_tendsto.eventually (eventually_ge_atTop 1), hsmall] with N hL he
  intro t ht x y
  have hn := (vertexCount_pos N).ne'
  have hm : 0 ≤ mixingTime N := by
    unfold mixingTime
    exact mul_nonneg (mul_nonneg (by norm_num) (vertexCount_pos N).le) (Real.log_nonneg hL)
  have ht0 := hm.trans ht
  have hid : (logSize N) ^ (-16 : ℝ) = ((logSize N) ^ (-8 : ℝ)) ^ 2 := by
    rw [pow_two, ← Real.rpow_add (logSize_pos N)]
    norm_num
  have he0 := Real.rpow_nonneg (logSize_pos N).le (-8 : ℝ)
  have hq : Real.exp (-(4 * t / vertexCount N)) ≤ (logSize N) ^ (-16 : ℝ) := by
    rw [Real.rpow_def_of_pos (logSize_pos N)]
    apply Real.exp_le_exp.mpr
    have h := div_le_div_of_nonneg_right
      (mul_le_mul_of_nonneg_left ht (by norm_num : (0 : ℝ) ≤ 4)) (vertexCount_pos N).le
    have hmEq : 4 * mixingTime N / vertexCount N = 16 * Real.log (logSize N) := by
      unfold mixingTime
      field_simp
      ring
    rw [hmEq] at h
    linarith
  have hqhalf : Real.exp (-(4 * t / vertexCount N)) ≤ 1 / 2 := by
    rw [hid] at hq
    nlinarith [sq_nonneg ((1 / 16 : ℝ) - (logSize N) ^ (-8 : ℝ)),
      mul_nonneg he0 (show 0 ≤ 1 / 16 - (logSize N) ^ (-8 : ℝ) by linarith)]
  have hsum : (∑ k ∈ nonzeroFrequencies N, Real.exp (-t * finiteEigenvalue N k)) ≤
      (logSize N) ^ (-8 : ℝ) := by
    have hbound := eigenmode_sum_bound N t ht0 hqhalf
    rw [hid] at hq
    nlinarith [mul_nonneg he0 (show 0 ≤ 1 / 16 - (logSize N) ^ (-8 : ℝ) by linarith)]
  exact ⟨(fourier_sum_abs_le_eigenmode_sum N t x y).trans hsum,
    (tailGreen_abs_le_eigenmode_sum N t x y).trans hsum⟩

end TorusCoverTime.Blocks.B
