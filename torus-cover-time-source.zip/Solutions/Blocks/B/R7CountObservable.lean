import Solutions.Blocks.B.R7LowCountMass

/-! Exact identification of the cutoff mass with the manuscript's actual
square-root completed traversal count. -/

noncomputable section
open MeasureTheory Filter Set Classical
open scoped ENNReal NNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

def r7TraversalRadius (N : Size) (c root : Vertex N) (γ q : ℝ) (z : WalkSample × ℝ) : ℝ :=
  Real.sqrt (q^γ*(completedTraversalCount N (torusDisk N c (Real.exp (q+q^γ)))
    (torusDisk N c (Real.exp (q+2*q^γ))) root z.1 z.2:ℝ))

theorem r7TraversalRadius_measurable (N : Size) (c root : Vertex N) (γ q : ℝ) :
    Measurable (r7TraversalRadius N c root γ q) :=
  (((measurable_from_nat : Measurable (fun n : ℕ => (n:ℝ))).comp
    (completedTraversalCount_measurable N _ _ root)).const_mul (q^γ)).sqrt

def r7IntegratedLowCount (N : Size) (c : Vertex N) (γ q v l r : ℝ) : ℝ≥0∞ :=
  (ENNReal.ofReal (timeScale N))⁻¹ * ∑ root : Vertex N,
    ∫⁻ ω, ∫⁻ t in Ioi (0:ℝ), if
      (N.val:ℝ)*Real.exp (-((logSize N)^(16*γ))/2) ≤ periodicDistance c root ∧
      r7TraversalRadius N c root γ q (ω,t) ≤ v ∧ walk N root ω t = root ∧ t ∈ Icc l r
      then 1 else 0 ∂volume ∂walkLaw

theorem r7IntegratedLowCount_eq_cutoff (N : Size) (c : Vertex N) (γ q v l r : ℝ)
    (hq : 0 < q) (hv : 0 ≤ v) :
    r7IntegratedLowCount N c γ q v l r =
      normalizedFarRootCountedMass N c γ q (r7LowCountCutoff q γ v) l r := by
  unfold r7IntegratedLowCount normalizedFarRootCountedMass farRootCountedMass
  congr 1
  apply Finset.sum_congr rfl
  intro root _
  by_cases hfar : (N.val:ℝ)*Real.exp (-((logSize N)^(16*γ))/2) ≤ periodicDistance c root
  · rw [if_pos hfar]
    unfold countedLoopWindowMass
    apply lintegral_congr
    intro ω
    apply lintegral_congr
    intro t
    simp only [r7_low_count_cutoff_iff q γ v _ hq hv,hfar,true_and,r7TraversalRadius]
  · simp only [hfar,false_and,if_false,lintegral_zero]

end TorusCoverTime.Blocks.B
