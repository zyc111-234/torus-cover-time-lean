import Solutions.Blocks.B.DirichletFreshNormal

noncomputable section
open MeasureTheory ProbabilityTheory Classical
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

/-- The recovered ordinary Dirichlet field is independent of the entire
original binding data, including the envelope, despite depending on the fresh normal. -/
theorem freshDirichletField_indep_bindingData (N : Size) (root : Vertex N) (D : Finset (Vertex N))
    (hroot : root∉D) (hV : 0<dirichletMassVariance N root D) :
    IndepFun (freshDirichletField N root D)
      (fun v : FiniteFieldSample N × FiniteFieldSample N => periodicBindingData N root D v.1)
      ((finiteFieldLaw N).prod (finiteFieldLaw N)) := by
  let : IsGaussian (finiteFieldLaw N) := by
    have hh := (Blocks.D.finiteFieldSample_gaussian N).isGaussian_map
    simpa only [Measure.map_id] using hh
  have hpair : HasGaussianLaw (id : FiniteFieldSample N × FiniteFieldSample N → _)
      ((finiteFieldLaw N).prod (finiteFieldLaw N)) := IsGaussian.hasGaussianLaw_id
  let fstMap := ContinuousLinearMap.fst ℝ (FiniteFieldSample N) (FiniteFieldSample N)
  let sndMap := ContinuousLinearMap.snd ℝ (FiniteFieldSample N) (FiniteFieldSample N)
  let A := ContinuousLinearMap.pi (fun x => (massZeroCoordinateMap N root D x).comp fstMap+
    dirichletMassProfile N root D x • (periodicBindingDataMap N root D none).comp sndMap)
  let B := ContinuousLinearMap.pi (fun i => (periodicBindingDataMap N root D i).comp fstMap)
  have hj : HasGaussianLaw (fun v : FiniteFieldSample N × FiniteFieldSample N =>
      (freshDirichletField N root D v,periodicBindingData N root D v.1)) ((finiteFieldLaw N).prod (finiteFieldLaw N)) := by
    apply (hpair.map_fun (A.prod B)).congr
    exact Filter.Eventually.of_forall (fun v => by
      apply Prod.ext <;> funext i <;>
        simp [A,B,fstMap,sndMap,massZeroCoordinateMap_apply,periodicBindingDataMap_apply,
          freshDirichletField,periodicBindingData])
  have hi0 := massZeroFieldLS_indep_bindingData N root D hroot hV
  have hilift : IndepFun (fun v : FiniteFieldSample N × FiniteFieldSample N => massZeroFieldLS N root D v.1)
      (fun v : FiniteFieldSample N × FiniteFieldSample N => periodicBindingData N root D v.1)
      ((finiteFieldLaw N).prod (finiteFieldLaw N)) :=
    indepFun_of_identDistrib_pair hi0 (identDistrib_fst_self (finiteFieldLaw N)
      (fun ξ => (massZeroFieldLS N root D ξ,periodicBindingData N root D ξ))
        ((massZeroFieldLS_measurable N root D).prodMk (periodicBindingData_measurable N root D))).symm
  apply hj.indepFun_of_covariance_eval
  intro x i
  have hX := (massZeroFieldLS_gaussian N root D x).memLp_two.comp_fst (finiteFieldLaw N)
  have hZ := (periodicBindingData_gaussian N root D none).memLp_two.comp_snd (finiteFieldLaw N)
  change MemLp (fun v : FiniteFieldSample N × FiniteFieldSample N => normalizedDirichletMass N root D v.2) 2
    ((finiteFieldLaw N).prod (finiteFieldLaw N)) at hZ
  have hB := (periodicBindingData_gaussian N root D i).memLp_two.comp_fst (finiteFieldLaw N)
  have hc := (hilift.comp (measurable_pi_apply x) (measurable_pi_apply i)).covariance_eq_zero hX hB
  have hz : cov[fun v : FiniteFieldSample N × FiniteFieldSample N => normalizedDirichletMass N root D v.2,
      fun v => periodicBindingData N root D v.1 i;(finiteFieldLaw N).prod (finiteFieldLaw N)]=0 := by
    rw [covariance_comm]
    exact covariance_fst_snd_prod (periodicBindingData_gaussian N root D i).memLp_two
      (periodicBindingData_gaussian N root D none).memLp_two
  unfold freshDirichletField
  change cov[(fun v : FiniteFieldSample N × FiniteFieldSample N => massZeroFieldLS N root D v.1 x)+
    (fun v => dirichletMassProfile N root D x*normalizedDirichletMass N root D v.2),
    fun v => periodicBindingData N root D v.1 i;(finiteFieldLaw N).prod (finiteFieldLaw N)]=0
  rw [covariance_add_left hX (hZ.const_mul (dirichletMassProfile N root D x)) hB,covariance_const_mul_left,hz,mul_zero,add_zero]
  change cov[fun v : FiniteFieldSample N × FiniteFieldSample N => massZeroFieldLS N root D v.1 x,
    fun v => periodicBindingData N root D v.1 i;(finiteFieldLaw N).prod (finiteFieldLaw N)]=0
  simpa only [Function.comp_def] using hc

theorem freshDirichletField_indep_envelope (N : Size) (root c : Vertex N) (ρ : ℝ)
    (hroot : root∉torusDisk N c (ρ*(N.val:ℝ)))
    (hV : 0<dirichletMassVariance N root (torusDisk N c (ρ*(N.val:ℝ)))) :
    IndepFun (freshDirichletField N root (torusDisk N c (ρ*(N.val:ℝ))))
      (fun v : FiniteFieldSample N × FiniteFieldSample N => periodicBindingEnvelope N root c ρ v.1)
      ((finiteFieldLaw N).prod (finiteFieldLaw N)) := by
  exact (freshDirichletField_indep_bindingData N root _ hroot hV).comp measurable_id
    (show Measurable (fun b : Option (Vertex N) → ℝ => bt7EnvelopeMultiplier*(|b none|+
      ∑ z, diskHarmonicWeight N c (ρ*(N.val:ℝ)/4) z*|b (some z)|)) by fun_prop)

theorem freshDirichletField_envelope_joint_law (N : Size) (root c : Vertex N) (ρ : ℝ)
    (hroot : root∉torusDisk N c (ρ*(N.val:ℝ)))
    (hV : 0<dirichletMassVariance N root (torusDisk N c (ρ*(N.val:ℝ)))) :
    IdentDistrib
      (fun v : FiniteFieldSample N × FiniteFieldSample N =>
        (freshDirichletField N root (torusDisk N c (ρ*(N.val:ℝ))) v,periodicBindingEnvelope N root c ρ v.1))
      (fun v : FiniteFieldSample N × FiniteFieldSample N =>
        (dirichletFieldLS N root (torusDisk N c (ρ*(N.val:ℝ))) v.1,periodicBindingEnvelope N root c ρ v.2))
      ((finiteFieldLaw N).prod (finiteFieldLaw N)) ((finiteFieldLaw N).prod (finiteFieldLaw N)) := by
  have hd : Measurable (dirichletFieldLS N root (torusDisk N c (ρ*(N.val:ℝ)))) := by
    apply measurable_pi_lambda
    exact dirichletFieldLS_measurable N root _
  have ht := periodicBindingEnvelope_measurable N root c ρ
  exact ((freshDirichletField_identDistrib N root _ hroot hV).trans
      (identDistrib_fst_self (finiteFieldLaw N) _ hd).symm).prodMk
    ((identDistrib_fst_self (finiteFieldLaw N) _ ht).trans (identDistrib_snd_self (finiteFieldLaw N) _ ht).symm)
    (freshDirichletField_indep_envelope N root c ρ hroot hV) (indepFun_prod hd ht)

end TorusCoverTime.Blocks.B
