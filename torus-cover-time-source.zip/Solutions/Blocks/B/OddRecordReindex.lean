import Solutions.Blocks.B.OutwardRecordLaws
import Solutions.Blocks.B.EndpointWordSupport

/-! The odd-coordinate product in the full path disintegration is exactly
the finite independent outward-block product used in R6 and R7. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

def outwardRecordProjection (m : ℕ) (p : {j : Fin (2*m) // j.val % 2 = 1} → ℕ × WalkSample) :
    Fin m → ℕ × WalkSample := fun i => p (outwardRecordEquiv m i)

theorem outwardRecordProjection_measurable (m : ℕ) : Measurable (outwardRecordProjection m) := by
  exact measurable_pi_lambda _ fun i => measurable_pi_apply (outwardRecordEquiv m i)

theorem outwardRecordProjection_duration (m : ℕ)
    (p : {j : Fin (2*m) // j.val % 2 = 1} → ℕ × WalkSample) :
    recordsDuration m (outwardRecordProjection m p) = ∑ j, excursionRecordDuration (p j) :=
  (outwardRecordEquiv m).sum_comp (fun j => excursionRecordDuration (p j))

theorem outwardRecordProjection_law (N : Size) (I O : Finset (Vertex N)) (root : Vertex N)
    (hI : I.Nonempty) (hr : root ∉ O) (m : ℕ) (w : Fin (2*m) → Vertex N)
    (hw : walkLaw {ω | adaptiveExitWord N (alternatingDomain N I O) root (2*m) ω = w} ≠ 0) :
    (Measure.pi fun j : {j : Fin (2*m) // j.val % 2 = 1} =>
      exactExitRecordLaw N (alternatingDomain N I O j.val.val)
        (endpointWordStart root w j.val.val) (endpointWordEnd root w j.val.val)).map
          (outwardRecordProjection m) =
      exactExitRecordProductLaw N O m (fun i => endpointWordStart root w (2*i.val+1))
        (fun i => endpointWordEnd root w (2*i.val+1)) := by
  have hp := adaptiveExitWord_positive_factors N _ (alternatingDomain_proper N I O hI ⟨root,hr⟩) root (2*m) w hw
  have (j : Fin (2*m)) : IsProbabilityMeasure (exactExitLaw N (alternatingDomain N I O j.val)
      (endpointWordStart root w j.val) (endpointWordEnd root w j.val)) := cond_isProbabilityMeasure (hp j)
  have (j : Fin (2*m)) : IsProbabilityMeasure (exactExitRecordLaw N (alternatingDomain N I O j.val)
      (endpointWordStart root w j.val) (endpointWordEnd root w j.val)) :=
    Measure.isProbabilityMeasure_map (finiteExitRecord_measurable N _ _).aemeasurable
  unfold outwardRecordProjection
  rw [pi_select_law _ _ (outwardRecordEquiv m).injective]
  simp only [outwardRecordEquiv,outwardRecordIndex,Equiv.coe_fn_mk,alternatingDomain_odd]
  rfl

theorem probability_short_duration_of_tail {Ω : Type*} [MeasurableSpace Ω]
    (μ : Measure Ω) [IsProbabilityMeasure μ] (V : Ω → ℝ) (hV : Measurable V)
    (d : ℝ) (h : μ {x | d < V x} ≤ (1 : ℝ≥0∞)/2) :
    (1 : ℝ≥0∞)/2 ≤ μ {x | V x ≤ d} := by
  let T := {x | V x ≤ d}
  have hT : MeasurableSet T := measurableSet_le hV measurable_const
  have he : Tᶜ = {x | d < V x} := by ext x; simp [T]
  have hsum := measure_add_measure_compl hT (μ := μ)
  rw [measure_univ,he] at hsum
  have hr := congrArg ENNReal.toReal hsum
  rw [ENNReal.toReal_add (measure_ne_top μ T) (measure_ne_top μ _), ENNReal.toReal_one] at hr
  have hh := ENNReal.toReal_mono (by norm_num : (1 : ℝ≥0∞)/2 ≠ ∞) h
  have hhalf : ((1 : ℝ≥0∞)/2).toReal = (1:ℝ)/2 := by simp
  rw [hhalf] at hh
  apply (ENNReal.toReal_le_toReal (by norm_num) (measure_ne_top μ T)).mp
  rw [hhalf]
  linarith

end TorusCoverTime.Blocks.B
