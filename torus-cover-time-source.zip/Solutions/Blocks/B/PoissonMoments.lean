import Solutions.Blocks.B.JumpCount
import Mathlib.Probability.Independence.InfinitePi
import Mathlib.Probability.Independence.Integration

/-! Truncated exponential moments of successive jump times. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter
open scoped BigOperators ENNReal Topology

namespace TorusCoverTime.Blocks.B

lemma measurable_holdingTime (j : ℕ) : Measurable (fun ω : WalkSample => holdingTime ω j) := by
  unfold holdingTime
  fun_prop

lemma independent_holdingTimes :
    iIndepFun (fun j : ℕ => fun ω : WalkSample => holdingTime ω j) walkLaw := by
  exact iIndepFun_infinitePi (P := fun _ : ℕ => stepLaw)
    (X := fun _ => fun z : ℝ × Fin 4 => max z.1 0) (by fun_prop)

lemma jumpTime_independent_next_holding (n : ℕ) :
    IndepFun (fun ω : WalkSample => jumpTime ω n) (fun ω => holdingTime ω n) walkLaw := by
  have h := independent_holdingTimes.indepFun_sum_range_succ measurable_holdingTime n
  have hid : (∑ j ∈ Finset.range n, fun ω : WalkSample => holdingTime ω j) =
      (fun ω => jumpTime ω n) := by
    funext ω
    simp [jumpTime]
  rw [hid] at h
  exact h

lemma holdingTime_law (hWalk : WalkModelRegular) (j : ℕ) :
    walkLaw.map (fun ω : WalkSample => holdingTime ω j) = holdingLaw := by
  have heq : (fun ω : WalkSample => holdingTime ω j) =ᵐ[walkLaw] (fun ω => (ω j).1) := by
    filter_upwards [hWalk.1] with ω hω
    exact max_eq_left (hω.1 j).le
  rw [Measure.map_congr heq]
  exact holding_coordinate_law j

lemma integral_holdingLaw (f : ℝ → ℝ) :
    (∫ s, f s ∂holdingLaw) = ∫ s in Set.Ici 0, Real.exp (-s) * f s := by
  change (∫ s, f s ∂volume.withDensity (exponentialPDF 1)) = _
  have hpdf : Measurable (exponentialPDF 1) := (measurable_exponentialPDFReal 1).ennreal_ofReal
  rw [integral_withDensity_eq_integral_toReal_smul
    hpdf
    (Filter.Eventually.of_forall (fun _ => ENNReal.ofReal_lt_top))]
  rw [← integral_indicator measurableSet_Ici]
  apply integral_congr_ae
  exact Filter.Eventually.of_forall (fun s => by
    by_cases hs : 0 ≤ s
    · simp [exponentialPDF_eq, hs, ENNReal.toReal_ofReal (Real.exp_pos (-s)).le,
        Set.indicator, smul_eq_mul]
    · simp [exponentialPDF_eq, hs, Set.indicator])

def truncatedJumpMoment (n : ℕ) (t : ℝ) : ℝ :=
  ∫ ω : WalkSample, if jumpTime ω n ≤ t then Real.exp (jumpTime ω n) else 0 ∂walkLaw

lemma integrable_truncatedJumpMoment (n : ℕ) (t : ℝ) :
    Integrable (fun ω : WalkSample => if jumpTime ω n ≤ t then Real.exp (jumpTime ω n) else 0)
      walkLaw := by
  classical
  apply Integrable.of_bound
    ((measurable_jumpTime n).exp.ite (measurableSet_le (measurable_jumpTime n) measurable_const)
      measurable_const).aestronglyMeasurable (Real.exp t)
  filter_upwards [] with ω
  split_ifs with h
  · rw [Real.norm_eq_abs, abs_of_pos (Real.exp_pos _)]
    exact Real.exp_le_exp.mpr h
  · simp only [norm_zero]
    positivity

lemma truncatedJumpMoment_zero (t : ℝ) (ht : 0 ≤ t) : truncatedJumpMoment 0 t = 1 := by
  simp [truncatedJumpMoment, ht]

lemma truncatedJumpMoment_of_neg (n : ℕ) (t : ℝ) (ht : t < 0) : truncatedJumpMoment n t = 0 := by
  have hfalse (ω : WalkSample) : ¬ jumpTime ω n ≤ t := by
    have h := jumpTime_nonneg ω n
    linarith
  simp [truncatedJumpMoment, hfalse]

lemma integral_jumpTime_next (hWalk : WalkModelRegular) (n : ℕ)
    (f : ℝ → ℝ) (hf : Measurable f) (M : ℝ) (hbound : ∀ s, ‖f s‖ ≤ M) :
    (∫ ω : WalkSample, f (jumpTime ω n + holdingTime ω n) ∂walkLaw) =
      ∫ s, (∫ ω : WalkSample, f (jumpTime ω n + s) ∂walkLaw) ∂holdingLaw := by
  let law := walkLaw.map (fun ω => jumpTime ω n)
  let : IsProbabilityMeasure law := Measure.isProbabilityMeasure_map (measurable_jumpTime n).aemeasurable
  have hpair : Measurable (fun ω : WalkSample => (jumpTime ω n, holdingTime ω n)) :=
    (measurable_jumpTime n).prodMk (measurable_holdingTime n)
  have hfun : Measurable (fun p : ℝ × ℝ => f (p.1 + p.2)) := hf.comp (measurable_fst.add measurable_snd)
  have hprod : Integrable (fun p : ℝ × ℝ => f (p.1 + p.2)) (law.prod holdingLaw) :=
    Integrable.of_bound hfun.aestronglyMeasurable M (Filter.Eventually.of_forall fun p => hbound _)
  have hmap := (jumpTime_independent_next_holding n).map_prod_eq_prod_map_map
    (measurable_jumpTime n).aemeasurable (measurable_holdingTime n).aemeasurable
  rw [holdingTime_law hWalk n] at hmap
  rw [← integral_map hpair.aemeasurable hfun.aestronglyMeasurable, hmap,
    integral_prod_symm _ hprod]
  apply integral_congr_ae
  filter_upwards [] with s
  exact integral_map (measurable_jumpTime n).aemeasurable
    (hf.comp (measurable_id.add_const s)).aestronglyMeasurable

lemma truncatedJumpMoment_succ (hWalk : WalkModelRegular) (n : ℕ) (t : ℝ) :
    truncatedJumpMoment (n + 1) t = ∫ s in Set.Icc 0 t, truncatedJumpMoment n (t - s) := by
  classical
  let f : ℝ → ℝ := fun u => if u ≤ t then Real.exp u else 0
  have hf : Measurable f := Measurable.ite (measurableSet_le measurable_id measurable_const)
    Real.measurable_exp measurable_const
  have hbound (u : ℝ) : ‖f u‖ ≤ Real.exp t := by
    dsimp [f]
    split_ifs with hu
    · rw [abs_of_pos (Real.exp_pos _)]
      exact Real.exp_le_exp.mpr hu
    · simp only [abs_zero]
      positivity
  have hJT (ω : WalkSample) : jumpTime ω (n + 1) = jumpTime ω n + holdingTime ω n := by
    simp [jumpTime, Finset.sum_range_succ]
  have hstart : truncatedJumpMoment (n + 1) t =
      ∫ s, (∫ ω : WalkSample, f (jumpTime ω n + s) ∂walkLaw) ∂holdingLaw := by
    unfold truncatedJumpMoment
    simp_rw [hJT]
    exact integral_jumpTime_next hWalk n f hf (Real.exp t) hbound
  rw [hstart, integral_holdingLaw]
  have hinner (s : ℝ) : (∫ ω : WalkSample, f (jumpTime ω n + s) ∂walkLaw) =
      Real.exp s * truncatedJumpMoment n (t - s) := by
    unfold truncatedJumpMoment
    rw [← integral_const_mul]
    apply integral_congr_ae
    filter_upwards [] with ω
    dsimp [f]
    by_cases hs : jumpTime ω n ≤ t - s
    · have hs' : jumpTime ω n + s ≤ t := by linarith
      simp [hs, hs', Real.exp_add, mul_comm]
    · have hs' : ¬ jumpTime ω n + s ≤ t := by linarith
      simp [hs, hs']
  have hintegrand : Set.EqOn
      (fun s => Real.exp (-s) * ∫ ω : WalkSample, f (jumpTime ω n + s) ∂walkLaw)
      (fun s => truncatedJumpMoment n (t - s)) (Set.Ici 0) := by
    intro s _
    dsimp only
    rw [hinner, ← mul_assoc, ← Real.exp_add]
    simp
  rw [setIntegral_congr_fun measurableSet_Ici hintegrand,
    ← integral_indicator measurableSet_Ici, ← integral_indicator measurableSet_Icc]
  apply integral_congr_ae
  filter_upwards [] with s
  by_cases h0 : 0 ≤ s
  · by_cases hst : s ≤ t
    · simp [Set.indicator, h0, hst]
    · have hz := truncatedJumpMoment_of_neg n (t - s) (by linarith)
      simp [Set.indicator, h0, hst, hz]
  · simp [Set.indicator, h0]

lemma integral_sub_pow_Icc (n : ℕ) (t : ℝ) (ht : 0 ≤ t) :
    (∫ s in Set.Icc 0 t, (t - s) ^ n) = t ^ (n + 1) / (n + 1 : ℝ) := by
  rw [integral_Icc_eq_integral_Ioc, ← intervalIntegral.integral_of_le ht,
    intervalIntegral.integral_comp_sub_left (fun u : ℝ => u ^ n) t]
  simp [integral_pow]

lemma truncatedJumpMoment_eq (hWalk : WalkModelRegular) (n : ℕ) (t : ℝ) (ht : 0 ≤ t) :
    truncatedJumpMoment n t = t ^ n / (n.factorial : ℝ) := by
  induction n generalizing t with
  | zero => simp [truncatedJumpMoment_zero t ht]
  | succ n ih =>
    rw [truncatedJumpMoment_succ hWalk]
    have heq : Set.EqOn (fun s => truncatedJumpMoment n (t - s))
        (fun s => (t - s) ^ n / (n.factorial : ℝ)) (Set.Icc 0 t) := by
      intro s hs
      exact ih (t - s) (by linarith [hs.2])
    rw [setIntegral_congr_fun measurableSet_Icc heq, integral_div, integral_sub_pow_Icc n t ht,
      Nat.factorial_succ]
    push_cast
    field_simp

end TorusCoverTime.Blocks.B
