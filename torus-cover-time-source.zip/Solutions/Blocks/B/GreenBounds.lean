import Solutions.Blocks.B.GreenIncrementWeights

/-! The complete registered GreenEstimates interface, with one uniform positive constant. -/

noncomputable section
open scoped BigOperators
namespace TorusCoverTime.Blocks.B

def greenIncrementConstant : ℝ := 4 * Real.pi ^ 2 * (1 + 2 / Real.log 2)

lemma greenIncrementConstant_pos : 0 < greenIncrementConstant := by
  have hlog : 0 < Real.log 2 := Real.log_pos (by norm_num)
  unfold greenIncrementConstant
  positivity

lemma local_log_comparison (d : ℝ) (hd : 1 ≤ d) :
    2 + Real.log d ≤ (1 + 2 / Real.log 2) * Real.log (2 + d) := by
  have hlog2 : 0 < Real.log 2 := Real.log_pos (by norm_num)
  have h2 : Real.log 2 ≤ Real.log (2 + d) := Real.log_le_log (by norm_num) (by linarith)
  have hmul := mul_le_mul_of_nonneg_left h2 (show 0 ≤ 2 / Real.log 2 by positivity)
  rw [div_mul_cancel₀ _ hlog2.ne'] at hmul
  have hdlog : Real.log d ≤ Real.log (2 + d) :=
    Real.log_le_log (lt_of_lt_of_le zero_lt_one hd) (by linarith)
  nlinarith

lemma green_increment_log_bound (N : Size) (x y : Vertex N) :
    greenKernel N x x - greenKernel N x y ≤ greenIncrementConstant * Real.log (2 + periodicDistance x y) := by
  by_cases hxy : x = y
  · subst y
    have hd0 : periodicDistance x x = 0 := by simp [periodicDistance, coordinateDistance]
    rw [sub_self, hd0, add_zero]
    exact mul_nonneg greenIncrementConstant_pos.le (Real.log_nonneg (by norm_num))
  · let d := periodicDistance (x - y) 0
    let t := (N.val : ℝ) / d
    let c := Real.pi ^ 2 / 2
    have hz : x - y ≠ 0 := sub_ne_zero.mpr hxy
    have hd : 1 ≤ d := periodicDistance_nonzero_ge_one N (x - y) hz
    have hd0 : 0 < d := lt_of_lt_of_le zero_lt_one hd
    have hn : 0 < (N.val : ℝ) := lt_trans zero_lt_one (size_real_gt_one N)
    have ht : 1 ≤ t := (one_le_div hd0).mpr (periodicDistance_le_size N (x - y) 0)
    have hc : 0 ≤ c := by dsimp [c]; positivity
    have hinc : greenKernel N x x - greenKernel N x y ≤
        c * ∑ k ∈ nonzeroFrequencies N, min (1 / t ^ 2) (1 / frequencyNormSq N k) := by
      rw [green_increment_sum, Finset.mul_sum]
      exact Finset.sum_le_sum (fun k hk => green_increment_multiplier N k (x - y) hk hd0)
    have hfreq := local_frequency_sum N t ht
    have hmax : max (((N.val / 2 : ℕ) : ℝ) / t) 1 ≤ d := by
      apply max_le _ hd
      have hrad : ((N.val / 2 : ℕ) : ℝ) ≤ N.val := by exact_mod_cast Nat.div_le_self N.val 2
      calc
        _ = (((N.val / 2 : ℕ) : ℝ) * d) / N.val := by dsimp [t]; field_simp
        _ ≤ d := (div_le_iff₀ hn).mpr (by nlinarith [mul_le_mul_of_nonneg_right hrad hd0.le])
    have hlog := Real.log_le_log (lt_of_lt_of_le zero_lt_one (le_max_right _ _)) hmax
    have hloc := local_log_comparison d hd
    calc
      _ ≤ c * ∑ k ∈ nonzeroFrequencies N, min (1 / t ^ 2) (1 / frequencyNormSq N k) := hinc
      _ ≤ c * (8 * (2 + Real.log (max (((N.val / 2 : ℕ) : ℝ) / t) 1))) :=
        mul_le_mul_of_nonneg_left hfreq hc
      _ ≤ c * (8 * (2 + Real.log d)) := by gcongr
      _ = 4 * Real.pi ^ 2 * (2 + Real.log d) := by dsimp [c]; ring
      _ ≤ 4 * Real.pi ^ 2 * ((1 + 2 / Real.log 2) * Real.log (2 + d)) :=
        mul_le_mul_of_nonneg_left hloc (by positivity)
      _ = _ := by
        dsimp [d, greenIncrementConstant]
        rw [periodicDistance_sub_zero]
        ring

theorem green_estimates (_hFourier : FourierWalkIdentities) : GreenEstimates := by
  let C := greenDiagonalErrorConstant + greenSpatialConstant + greenIncrementConstant + greenFarConstant
  have hD := greenDiagonalErrorConstant_pos
  have hS := greenSpatialConstant_pos
  have hI := greenIncrementConstant_pos
  have hF := greenFarConstant_pos
  have hC : 0 < C := by dsimp [C]; positivity
  have hCD : greenDiagonalErrorConstant ≤ C := by dsimp [C]; linarith
  have hCS : greenSpatialConstant ≤ C := by dsimp [C]; linarith
  have hCI : greenIncrementConstant ≤ C := by dsimp [C]; linarith
  have hCF : greenFarConstant ≤ C := by dsimp [C]; linarith
  refine ⟨C, hC, ?_⟩
  intro N x y
  have hdist : 0 ≤ periodicDistance x y := Real.sqrt_nonneg _
  have hn : (1 : ℝ) ≤ N.val := (size_real_gt_one N).le
  have hmax : max (periodicDistance x y) 1 ≤ N.val := max_le (periodicDistance_le_size N x y) hn
  have hmaxpos : 0 < max (periodicDistance x y) 1 := lt_of_lt_of_le zero_lt_one (le_max_right _ _)
  have hsp : 0 ≤ 1 + Real.log ((N.val : ℝ) / max (periodicDistance x y) 1) := by
    have h := Real.log_nonneg ((one_le_div hmaxpos).mpr hmax)
    linarith
  have hloc : 0 ≤ Real.log (2 + periodicDistance x y) := Real.log_nonneg (by linarith)
  refine ⟨greenKernel_diagonal N x, (greenDiagonal_log_error N).trans hCD,
    (greenKernel_spatial_bound N x y).trans (mul_le_mul_of_nonneg_right hCS hsp),
    green_difference_nonneg N x y,
    (green_increment_log_bound N x y).trans (mul_le_mul_of_nonneg_right hCI hloc), ?_⟩
  intro hfar
  exact (greenKernel_far_bound N x y hfar).trans
    (mul_le_mul_of_nonneg_right hCF (Real.rpow_nonneg (logSize_pos N).le _))

end TorusCoverTime.Blocks.B
