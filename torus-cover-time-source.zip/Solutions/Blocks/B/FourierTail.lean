import Solutions.Blocks.B.FiniteSpectrum
import Definitions.Quantitative
import Mathlib.Analysis.SpecialFunctions.ImproperIntegrals
import Mathlib.Analysis.SpecialFunctions.Log.Basic

/-! S1 tail Green identities from the given transition Fourier formula.
The walk hypothesis is retained exactly as in the registered interface. -/

noncomputable section
open MeasureTheory Filter
open scoped BigOperators Topology

namespace TorusCoverTime.Blocks.B

lemma centered_transition_eq_fourier (hFourier : FourierWalkIdentities)
    (N : Size) (x y : Vertex N) (t : ℝ) (ht : 0 ≤ t) :
    transitionProbability N x y t - 1 / vertexCount N =
      (∑ k ∈ nonzeroFrequencies N, Real.exp (-t * finiteEigenvalue N k) *
        finiteCosine N k (x - y)) / vertexCount N := by
  apply (eq_div_iff (vertexCount_pos N).ne').mpr
  have hf := hFourier.2.1 N t ht x y
  rw [sub_mul, div_mul_cancel₀ _ (vertexCount_pos N).ne']
  nlinarith

lemma integrableOn_exp_neg_mul_Ici {lam : ℝ} (hlam : 0 < lam) (t : ℝ) :
    IntegrableOn (fun s : ℝ => Real.exp (-s * lam)) (Set.Ici t) := by
  apply Iff.mpr integrableOn_Ici_iff_integrableOn_Ioi
  simpa only [neg_mul, mul_neg, mul_comm] using integrableOn_exp_mul_Ioi (neg_neg_of_pos hlam) t

lemma integral_exp_neg_mul_Ici {lam : ℝ} (hlam : 0 < lam) (t : ℝ) :
    (∫ s in Set.Ici t, Real.exp (-s * lam)) = Real.exp (-t * lam) / lam := by
  rw [integral_Ici_eq_integral_Ioi]
  simpa only [neg_mul, mul_neg, mul_comm, neg_div_neg_eq] using integral_exp_mul_Ioi (neg_neg_of_pos hlam) t

lemma exp_mode_hasDerivAt (lam c t : ℝ) (hlam : lam ≠ 0) :
    HasDerivAt (fun s => Real.exp (-s * lam) * c / lam)
      (-(Real.exp (-t * lam) * c)) t := by
  convert! (((Real.hasDerivAt_exp (-t * lam)).comp t
    ((hasDerivAt_id t).neg.mul_const lam)).mul_const c).div_const lam using 1
  field_simp

lemma tailGreen_integrable_and_integral (hFourier : FourierWalkIdentities)
    (N : Size) (x y : Vertex N) (t : ℝ) (ht : 0 ≤ t) :
    IntegrableOn (fun s => transitionProbability N x y s - 1 / vertexCount N) (Set.Ici t) ∧
    tailGreen N t x y = ∫ s in Set.Ici t,
      (transitionProbability N x y s - 1 / vertexCount N) := by
  let mode := fun (k : Vertex N) (s : ℝ) =>
    Real.exp (-s * finiteEigenvalue N k) * finiteCosine N k (x - y)
  have hint (k : Vertex N) (hk : k ∈ nonzeroFrequencies N) :
      IntegrableOn (mode k) (Set.Ici t) :=
    (integrableOn_exp_neg_mul_Ici (eigenvalue_pos_of_nonzero N hk) t).mul_const _
  have hsum : IntegrableOn
      (fun s => (∑ k ∈ nonzeroFrequencies N, mode k s) / vertexCount N) (Set.Ici t) :=
    (integrable_finsetSum _ hint).div_const _
  have heq : Set.EqOn
      (fun s => (∑ k ∈ nonzeroFrequencies N, mode k s) / vertexCount N)
      (fun s => transitionProbability N x y s - 1 / vertexCount N) (Set.Ici t) := by
    intro s hs
    exact (centered_transition_eq_fourier hFourier N x y s (ht.trans hs)).symm
  refine ⟨hsum.congr_fun heq measurableSet_Ici, ?_⟩
  rw [← setIntegral_congr_fun measurableSet_Ici heq, integral_div,
    integral_finsetSum _ hint]
  unfold tailGreen
  congr 1
  apply Finset.sum_congr rfl
  intro k hk
  dsimp [mode]
  rw [integral_mul_const, integral_exp_neg_mul_Ici (eigenvalue_pos_of_nonzero N hk)]
  ring

lemma tailGreen_hasDerivAt (hFourier : FourierWalkIdentities)
    (N : Size) (x y : Vertex N) (t : ℝ) (ht : 0 ≤ t) :
    HasDerivAt (fun s => tailGreen N s x y)
      (-(transitionProbability N x y t - 1 / vertexCount N)) t := by
  have hsum := (HasDerivAt.fun_sum (u := nonzeroFrequencies N) fun k hk =>
    exp_mode_hasDerivAt (finiteEigenvalue N k) (finiteCosine N k (x - y)) t
      (eigenvalue_pos_of_nonzero N hk).ne').div_const (vertexCount N)
  rw [centered_transition_eq_fourier hFourier N x y t ht]
  simpa only [tailGreen, Finset.sum_neg_distrib, neg_div] using hsum

lemma mixingTime_div_timeScale_tendsto :
    Tendsto (fun N => mixingTime N / timeScale N) atTop (𝓝 0) := by
  have hnat : Tendsto (fun N : Size => N.val) atTop atTop := by
    apply tendsto_atTop.2
    intro b
    refine eventually_atTop.2 ⟨⟨max 3 b, le_max_left _ _⟩, ?_⟩
    intro N hN
    exact (le_max_right 3 b).trans hN
  have hreal : Tendsto (fun N : Size => (N.val : ℝ)) atTop atTop :=
    tendsto_natCast_atTop_atTop.comp hnat
  have hlog : Tendsto logSize atTop atTop := Real.tendsto_log_atTop.comp hreal
  have hsmall : Tendsto (fun N => Real.log (logSize N) / logSize N) atTop (𝓝 0) := by
    simpa only [pow_one, one_mul, add_zero, Function.comp_def] using
      (Real.tendsto_pow_log_div_mul_add_atTop 1 0 1 one_ne_zero).comp hlog
  have heq (N : Size) : mixingTime N / timeScale N =
      (2 * Real.pi) * (Real.log (logSize N) / logSize N) := by
    have hN : (N.val : ℝ) ≠ 0 := ne_of_gt (lt_trans zero_lt_one (size_real_gt_one N))
    have hL := (logSize_pos N).ne'
    have hpi := Real.pi_ne_zero
    unfold mixingTime vertexCount timeScale g
    field_simp
    ring
  simp_rw [heq]
  simpa using hsmall.const_mul (2 * Real.pi)

theorem fourier_tail_identities (_hWalk : WalkModelRegular) (hFourier : FourierWalkIdentities) :
    FourierTailIdentities := by
  refine ⟨?_, ?_, ?_, mixingTime_div_timeScale_tendsto⟩
  · intro N x y t ht
    exact ⟨(tailGreen_integrable_and_integral hFourier N x y t ht).1,
      (tailGreen_integrable_and_integral hFourier N x y t ht).2,
      tailGreen_hasDerivAt hFourier N x y t ht⟩
  · intro N
    exact ⟨fun k hk => spectralGap_le_eigenvalue N k (Finset.mem_erase.mp hk).1,
      spectralGap_attained N⟩
  · exact ⟨Real.pi ^ 2 / 3, by positivity, spectralGap_relative_error⟩

end TorusCoverTime.Blocks.B
