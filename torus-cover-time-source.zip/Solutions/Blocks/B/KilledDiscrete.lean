import Solutions.Blocks.B.PoissonPrefix

/-! Finite direction words identify discrete avoidance with the killed transition operator. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Classical
open scoped BigOperators ENNReal Topology
namespace TorusCoverTime.Blocks.B

lemma direction_prefix_law (m : ℕ) :
    walkLaw.map (fun ω : WalkSample => fun j : Fin m => (ω j.val).2) =
      uniformOn (Set.univ : Set (Fin m → Fin 4)) := by
  have h := congrArg
    (fun μ : Measure ((Fin m → ℝ) × (Fin m → Fin 4)) => μ.map Prod.snd)
    (holding_direction_prefix_law m)
  rw [Measure.map_map measurable_snd (by fun_prop), Measure.map_snd_prod] at h
  simpa only [Function.comp_def, measure_univ, one_smul, ← uniformOn_pi,
    Set.pi_univ] using h

lemma integral_direction_prefix (m : ℕ) (F : (Fin m → Fin 4) → ℝ) :
    (∫ ω : WalkSample, F (fun j => (ω j.val).2) ∂walkLaw) =
      (∑ d : Fin m → Fin 4, F d) / (4 : ℝ) ^ m := by
  have hm : Measurable (fun ω : WalkSample => fun j : Fin m => (ω j.val).2) := by
    fun_prop
  have hF : Measurable F := measurable_of_finite _
  rw [← integral_map hm.aemeasurable hF.aestronglyMeasurable, direction_prefix_law]
  have hu : uniformOn (Set.univ : Set (Fin m → Fin 4)) =
      ((4 : ℝ≥0∞) ^ m)⁻¹ • Measure.count := by
    ext s
    simp [uniformOn_univ, div_eq_mul_inv, mul_comm]
  rw [hu, integral_smul_measure, integral_count]
  simp [ENNReal.toReal_pow, div_eq_mul_inv, mul_comm]

lemma position_succ_shift (N : Size) (x : Vertex N) (ω : WalkSample) (k : ℕ) :
    position N x ω (k + 1) =
      position N (x + direction N (ω 0).2) (fun j => ω (j + 1)) k := by
  simp only [position, Finset.sum_range_succ']
  abel

lemma discreteAvoids_succ_shift (N : Size) (x : Vertex N)
    (A : Finset (Vertex N)) (ω : WalkSample) (n : ℕ) :
    discreteAvoids N x A ω (n + 1) ↔ x ∉ A ∧
      discreteAvoids N (x + direction N (ω 0).2) A (fun j => ω (j + 1)) n := by
  constructor
  · intro h
    refine ⟨by simpa using h 0 (by omega), ?_⟩
    intro k hk
    rw [← position_succ_shift]
    exact h (k + 1) (by omega)
  · rintro ⟨hx, h⟩ k hk
    cases k with
    | zero => simpa using hx
    | succ k =>
      rw [position_succ_shift]
      exact h k (by omega)

def killedWord (N : Size) (A : Finset (Vertex N)) :
    (n : ℕ) → Vertex N → (Fin n → Fin 4) → ℝ
  | 0, x, _ => if x ∈ A then 0 else 1
  | n + 1, x, d => if x ∈ A then 0 else
      killedWord N A n (x + direction N (d 0)) (fun j => d j.succ)

lemma killedWord_eq_indicator (N : Size) (A : Finset (Vertex N))
    (n : ℕ) (x : Vertex N) (ω : WalkSample) :
    killedWord N A n x (fun j => (ω j.val).2) =
      if discreteAvoids N x A ω n then 1 else 0 := by
  induction n generalizing x ω with
  | zero => simp [killedWord, discreteAvoids]
  | succ n ih =>
    rw [discreteAvoids_succ_shift]
    by_cases hx : x ∈ A
    · simp [killedWord, hx]
    · simp only [killedWord, hx, if_false, not_false_eq_true, true_and]
      exact ih (x + direction N (ω 0).2) (fun k => ω (k + 1))

lemma discreteSurvival_eq_word_sum (N : Size) (A : Finset (Vertex N))
    (n : ℕ) (x : Vertex N) :
    discreteSurvival N x A n =
      (∑ d : Fin n → Fin 4, killedWord N A n x d) / (4 : ℝ) ^ n := by
  rw [discreteSurvival]
  simp_rw [← killedWord_eq_indicator N A n x]
  exact integral_direction_prefix n _

def killedStep (N : Size) (A : Finset (Vertex N)) (f : Vertex N → ℝ) : Vertex N → ℝ :=
  fun x => if x ∈ A then 0 else (∑ d : Fin 4, f (x + direction N d)) / 4

def complementIndicator (N : Size) (A : Finset (Vertex N)) : Vertex N → ℝ :=
  fun x => if x ∈ A then 0 else 1

lemma discreteSurvival_zero (N : Size) (A : Finset (Vertex N)) (x : Vertex N) :
    discreteSurvival N x A 0 = complementIndicator N A x := by
  simp [discreteSurvival_eq_word_sum, killedWord, complementIndicator]

lemma discreteSurvival_succ (N : Size) (A : Finset (Vertex N)) (n : ℕ) (x : Vertex N) :
    discreteSurvival N x A (n + 1) =
      killedStep N A (fun y => discreteSurvival N y A n) x := by
  rw [discreteSurvival_eq_word_sum]
  have hs : (∑ d : Fin (n + 1) → Fin 4, killedWord N A (n + 1) x d) =
      ∑ a : Fin 4, ∑ d : Fin n → Fin 4, killedWord N A (n + 1) x (Fin.cons a d) := by
    calc
      _ = ∑ p : Fin 4 × (Fin n → Fin 4),
          killedWord N A (n + 1) x (Fin.cons p.1 p.2) :=
        Fintype.sum_equiv (Fin.consEquiv (fun _ : Fin (n + 1) => Fin 4)).symm _ _
          (fun d => by simp [Fin.consEquiv])
      _ = _ := Fintype.sum_prod_type _
  rw [hs]
  by_cases hx : x ∈ A
  · simp [killedWord, killedStep, hx]
  · simp only [killedWord, hx, if_false, Fin.cons_zero, Fin.cons_succ,
      killedStep, discreteSurvival_eq_word_sum]
    rw [← Finset.sum_div, div_div, pow_succ]

lemma discreteSurvival_eq_iterate (N : Size) (A : Finset (Vertex N)) (n : ℕ) :
    (fun x => discreteSurvival N x A n) = (killedStep N A)^[n] (complementIndicator N A) := by
  induction n with
  | zero => funext x; exact discreteSurvival_zero N A x
  | succ n ih =>
    rw [Function.iterate_succ_apply', ← ih]
    funext x
    exact discreteSurvival_succ N A n x

end TorusCoverTime.Blocks.B
