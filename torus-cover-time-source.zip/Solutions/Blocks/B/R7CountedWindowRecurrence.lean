import Solutions.Blocks.B.CountedWordWindows

/-! Actual finite-count enlarged-window recurrence, after summing all endpoint
words and traversal counts. The common enlargement is M times the R6 duration
cutoff; the explicit long-record error includes the finite count sum. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

theorem r7_counted_window_recurrence (hWalk : WalkModelRegular) (γ : ℝ) (hγ : 0 < γ) (hγ1 : γ ≤ 1) :
    ∀ᶠ N : Size in atTop, ∀ c root : Vertex N, ∀ M : ℕ, ∀ q : ℝ,
      (logSize N)^(16*γ) ≤ q → q ≤ logSize N-(logSize N)^(16*γ) → (M:ℝ) ≤ (logSize N)^4+1 →
      root ∉ torusDisk N c (Real.exp (q+2*q^γ)) →
      ∀ v Δ : ℝ, 0 ≤ v → (M:ℝ)*q^γ ≤ v^2 → 0 ≤ Δ →
      2*r7MeanConstant*Real.exp (-r7MeanExponent*q^γ)*v ≤ Δ → Δ ≤ v → ∀ l r : ℝ,
      let I := torusDisk N c (Real.exp (q+q^γ))
      let O := torusDisk N c (Real.exp (q+2*q^γ))
      let d := (M:ℝ)*Real.exp (2*logSize N-(logSize N)^(16*γ))
      countedLoopWindowMass N I O root M l r ≤ lowWordWindowSum N c root I O M q v Δ l r +
        2*ENNReal.ofReal (2*Real.exp (-(r7ConcentrationConstant/4)*Δ^2/q^γ)) *
          countedLoopWindowMass N I O root M (l-d) (r+d) +
        ((M+1:ℕ):ℝ≥0∞)*ENNReal.ofReal (r-l)*ENNReal.ofReal (Real.exp (-Real.exp ((logSize N)^(16*γ)/2))) := by
  filter_upwards [r7_actual_word_recurrence hWalk γ hγ hγ1] with N hN
  intro c root M q hq hqL hM hr v Δ hv hMv hΔ hlo hhi l r
  dsimp only
  let I := torusDisk N c (Real.exp (q+q^γ))
  let O := torusDisk N c (Real.exp (q+2*q^γ))
  let d₀ := Real.exp (2*logSize N-(logSize N)^(16*γ))
  let d := (M:ℝ)*d₀
  let p := 2*ENNReal.ofReal (2*Real.exp (-(r7ConcentrationConstant/4)*Δ^2/q^γ))
  let ε := ENNReal.ofReal (r-l)*ENNReal.ofReal (Real.exp (-Real.exp ((logSize N)^(16*γ)/2)))
  have hq0 : 0 ≤ q := (Real.rpow_nonneg (logSize_pos N).le _).trans hq
  have hIO : I ⊆ O := by
    intro z hz
    exact (mem_torusDisk N c z _).mpr (((mem_torusDisk N c z _).mp hz).trans_le
      (Real.exp_le_exp.mpr (by linarith [Real.rpow_nonneg hq0 γ])))
  have hI := torusDisk_nonempty N c (Real.exp (q+q^γ)) (Real.exp_pos _)
  have hsum (m : ℕ) (hm : m ∈ Finset.range (M+1)) :
      (∑ w : Fin (2*m) → Vertex N, traversalWordMass N I O root m w * conditionalTraversalSlice N I O root m w (fun _ => 1) l r) ≤
        (∑ w : Fin (2*m) → Vertex N, traversalWordMass N I O root m w * conditionalTraversalSlice N I O root m w
          (lowOutwardRecordTest m (r7WordHighOccupation N c root m w q v Δ)) l r) +
        p*(∑ w : Fin (2*m) → Vertex N, traversalWordMass N I O root m w * conditionalTraversalSlice N I O root m w (fun _ => 1) (l-d) (r+d)) + ε := by
    apply weighted_finite_recurrence _ _ _ _ p ε (traversalWordMass_sum N I O root m)
    intro w hw
    have hmM : (m:ℝ) ≤ M := by exact_mod_cast (Nat.le_of_lt_succ (Finset.mem_range.mp hm))
    have hd : (m:ℝ)*d₀ ≤ d := mul_le_mul_of_nonneg_right hmM (Real.exp_pos _).le
    have ht := hN c root m w q hq hqL (hmM.trans hM) hr hw v Δ hv
      ((mul_le_mul_of_nonneg_right hmM (Real.rpow_nonneg hq0 γ)).trans hMv) hΔ hlo hhi l r
    dsimp only at ht
    have hwide := conditionalTraversalSlice_mono_window N I O root m w (fun _ => 1)
      (l-(m:ℝ)*d₀) (r+(m:ℝ)*d₀) (l-d) (r+d) (by linarith) (by linarith)
    exact ht.trans (add_le_add (add_le_add le_rfl (mul_le_mul' le_rfl hwide)) le_rfl)
  rw [mul_assoc ((M+1:ℕ):ℝ≥0∞)]
  change countedLoopWindowMass N I O root M l r ≤ lowWordWindowSum N c root I O M q v Δ l r +
    p*countedLoopWindowMass N I O root M (l-d) (r+d)+((M+1:ℕ):ℝ≥0∞)*ε
  rw [countedLoopWindowMass_word_sum N I O hIO hI root hr M l r,
    countedLoopWindowMass_word_sum N I O hIO hI root hr M (l-d) (r+d)]
  calc
    _ ≤ ∑ m ∈ Finset.range (M+1),
        ((∑ w : Fin (2*m) → Vertex N, traversalWordMass N I O root m w * conditionalTraversalSlice N I O root m w
          (lowOutwardRecordTest m (r7WordHighOccupation N c root m w q v Δ)) l r) +
        p*(∑ w : Fin (2*m) → Vertex N, traversalWordMass N I O root m w * conditionalTraversalSlice N I O root m w (fun _ => 1) (l-d) (r+d)) + ε) :=
      Finset.sum_le_sum hsum
    _ = _ := by
      simp only [Finset.sum_add_distrib,← Finset.mul_sum,Finset.sum_const,Finset.card_range,nsmul_eq_mul]
      rfl

end TorusCoverTime.Blocks.B
