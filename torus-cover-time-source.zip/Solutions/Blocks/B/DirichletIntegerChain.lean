import Solutions.Blocks.B.DirichletMacroscopicClock
import Solutions.Blocks.B.GaussianBridgeVariance

noncomputable section
open MeasureTheory ProbabilityTheory
namespace TorusCoverTime.Blocks.B

def bt6IntegerDomain (N : Size) (c x : Vertex N) (R : ℝ) (M : ℕ) (i : Fin (M+2)) : Finset (Vertex N) :=
  if i.val=0 then ∅ else if i.val=M+1 then torusDisk N c R else torusDisk N x (Real.exp ((i.val:ℝ)+1))

theorem bt6IntegerDomain_zero (N : Size) (c x : Vertex N) (R : ℝ) (M : ℕ) :
    bt6IntegerDomain N c x R M 0=∅ := by simp [bt6IntegerDomain]

theorem bt6IntegerDomain_last (N : Size) (c x : Vertex N) (R : ℝ) (M : ℕ) :
    bt6IntegerDomain N c x R M (Fin.last (M+1))=torusDisk N c R := by simp [bt6IntegerDomain]

theorem bt6IntegerDomain_subset (N : Size) (c x : Vertex N) (R : ℝ) (M : ℕ)
    (hdeep : periodicDistance x c+(Real.exp ((M:ℝ)+1)+1)≤R/2) (i : Fin (M+2)) :
    bt6IntegerDomain N c x R M i⊆torusDisk N c R := by
  have hn : 0≤periodicDistance x c := by unfold periodicDistance; positivity
  have hR : 0<R := by have hh:=Real.exp_pos ((M:ℝ)+1); linarith
  unfold bt6IntegerDomain
  split_ifs with hi0 hil
  · exact Finset.empty_subset _
  · exact Finset.Subset.refl _
  · intro z hz
    have hiM : (i.val:ℝ)≤M := by exact_mod_cast (show i.val≤M by have := i.isLt; omega)
    have he := Real.exp_le_exp.mpr (show (i.val:ℝ)+1≤M+1 by linarith)
    have hdist := (mem_torusDisk N x z _).mp hz
    apply (mem_torusDisk N c z R).mpr
    have ht := periodicDistance_triangle N z x c
    linarith

theorem bt6IntegerDomain_mono (N : Size) (c x : Vertex N) (R : ℝ) (M : ℕ)
    (hdeep : periodicDistance x c+(Real.exp ((M:ℝ)+1)+1)≤R/2) : Monotone (bt6IntegerDomain N c x R M) := by
  intro i j hij
  by_cases hj : j.val=M+1
  · have he : j=Fin.last (M+1) := Fin.ext hj
    rw [he,bt6IntegerDomain_last]
    exact bt6IntegerDomain_subset N c x R M hdeep i
  by_cases hi : i.val=0
  · simp only [bt6IntegerDomain,hi,if_true]; exact Finset.empty_subset _
  have hj0 : j.val≠0 := by change i.val≤j.val at hij; omega
  have hil : i.val≠M+1 := by have := j.isLt; change i.val≤j.val at hij; omega
  simp only [bt6IntegerDomain,if_neg hi,if_neg hj0,if_neg hil,if_neg hj]
  have hh : (i.val:ℝ)≤j.val := by exact_mod_cast hij
  intro z hz
  apply (mem_torusDisk N x z _).mpr
  exact ((mem_torusDisk N x z _).mp hz).trans_le (Real.exp_le_exp.mpr (by linarith))

def bt6IntegerPath (N : Size) (root c x : Vertex N) (R : ℝ) (M : ℕ)
    (hdeep : periodicDistance x c+(Real.exp ((M:ℝ)+1)+1)≤R/2) (hroot : root∉torusDisk N c R) :
    GaussianClockPath (finiteFieldLaw N) (M+1) :=
  dirichletLSClockPath N root (M+1) (bt6IntegerDomain N c x R M) (bt6IntegerDomain_mono N c x R M hdeep)
    (fun i hh => hroot (bt6IntegerDomain_subset N c x R M hdeep i hh)) (bt6IntegerDomain_zero N c x R M) x

theorem bt6IntegerPath_clock (N : Size) (root c x : Vertex N) (R : ℝ) (M : ℕ)
    (hdeep : periodicDistance x c+(Real.exp ((M:ℝ)+1)+1)≤R/2) (hroot : root∉torusDisk N c R) (i : Fin (M+2)) :
    (bt6IntegerPath N root c x R M hdeep hroot).clock i=dirichletClockLS N root (bt6IntegerDomain N c x R M i) x :=
  dirichlet_normalized_clock N root _ _ _ _ x i

theorem bt6IntegerPath_interior_clock (N : Size) (root c x : Vertex N) (R : ℝ) (M : ℕ)
    (hdeep : periodicDistance x c+(Real.exp ((M:ℝ)+1)+1)≤R/2) (hroot : root∉torusDisk N c R)
    (hsmall : 2*(R+1)<N.val) (i : Fin (M+2)) (hi0 : i.val≠0) (hil : i.val≠M+1) :
    |(bt6IntegerPath N root c x R M hdeep hroot).clock i-(i.val:ℝ)/2|≤dirichletLogError+1/2 := by
  have hsub := bt6IntegerDomain_subset N c x R M hdeep i
  simp only [bt6IntegerDomain,if_neg hi0,if_neg hil] at hsub
  rw [bt6IntegerPath_clock]
  simp only [bt6IntegerDomain,if_neg hi0,if_neg hil]
  apply dirichlet_LS_log_scale_clock N root x i.val (by positivity)
  · have hiM : (i.val:ℝ)≤M := by exact_mod_cast (show i.val≤M by have := i.isLt; omega)
    have he := Real.exp_le_exp.mpr (show (i.val:ℝ)+1≤M+1 by linarith)
    have hn : 0≤periodicDistance x c := by unfold periodicDistance; positivity
    linarith
  · exact fun hh => hroot (hsub hh)

end TorusCoverTime.Blocks.B
