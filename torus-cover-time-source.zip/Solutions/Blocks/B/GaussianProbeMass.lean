import Solutions.Blocks.B.GaussianSlabMoments

/-! A quantitative Gaussian slab probability and simultaneous quadratic
cutoffs under a finite measure. Applying the cutoff lemma to the slab-restricted
measure keeps a fixed fraction of the slab, even at vanishing probability. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal NNReal
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

theorem gaussian_unit_slab_mass (v : ℝ≥0) (hv : 1 ≤ (v : ℝ)) :
    2*Real.exp (-(1:ℝ)/2)/Real.sqrt (2*Real.pi*v) ≤ (gaussianReal 0 v).real (Icc (-1) 1) := by
  have hvp : 0 < (v : ℝ) := by linarith
  have hv0 : v ≠ 0 := by exact_mod_cast hvp.ne'
  have hden : 0 < Real.sqrt (2*Real.pi*v) := Real.sqrt_pos.mpr (by positivity)
  have hpdf (x : ℝ) (hx : x ∈ Icc (-1) 1) :
      Real.exp (-(1:ℝ)/2)/Real.sqrt (2*Real.pi*v) ≤ gaussianPDFReal 0 v x := by
    have hxx : x^2 ≤ 1 := by nlinarith [hx.1,hx.2]
    have hex : -(1:ℝ)/2 ≤ -(x-0)^2/(2*v) := by
      apply (le_div_iff₀ (by positivity : (0:ℝ) < 2*v)).mpr
      nlinarith
    have he := Real.exp_le_exp.mpr hex
    unfold gaussianPDFReal
    calc
      _ = (Real.sqrt (2*Real.pi*v))⁻¹*Real.exp (-(1:ℝ)/2) := by ring
      _ ≤ _ := mul_le_mul_of_nonneg_left he (inv_nonneg.mpr hden.le)
  have hi := setIntegral_mono_on (integrable_const _)
    (integrable_gaussianPDFReal 0 v).integrableOn measurableSet_Icc hpdf
  have hp : 0 ≤ ∫ x in Icc (-1:ℝ) 1, gaussianPDFReal 0 v x :=
    integral_nonneg (fun x => gaussianPDFReal_nonneg 0 v x)
  rw [Measure.real,gaussianReal_apply_eq_integral 0 hv0,ENNReal.toReal_ofReal hp]
  have hc : (∫ _ : ℝ in Icc (-1:ℝ) 1, Real.exp (-(1:ℝ)/2)/Real.sqrt (2*Real.pi*v)) =
      2*Real.exp (-(1:ℝ)/2)/Real.sqrt (2*Real.pi*v) := by
    simp only [integral_const,smul_eq_mul,Measure.real,Real.volume_Icc]
    norm_num
    ring
  exact hc ▸ hi

theorem gaussian_variable_unit_slab_mass {Ω : Type*} [MeasurableSpace Ω]
    (μ : Measure Ω) [IsProbabilityMeasure μ] (X : Ω → ℝ) (hX : Measurable X)
    (hG : HasGaussianLaw X μ) (hX0 : (∫ ω, X ω ∂μ) = 0) (hV : 1 ≤ Var[X;μ]) :
    2*Real.exp (-(1:ℝ)/2)/Real.sqrt (2*Real.pi*Var[X;μ]) ≤ μ.real {ω | |X ω| ≤ 1} := by
  have hh := gaussian_unit_slab_mass (Var[X;μ]).toNNReal (by rw [Real.coe_toNNReal _ (by linarith)]; exact hV)
  have he := congrArg (fun ν : Measure ℝ => ν (Icc (-1:ℝ) 1)) hG.map_eq_gaussianReal
  rw [hX0,Measure.map_apply hX measurableSet_Icc] at he
  have hs : X ⁻¹' Icc (-1:ℝ) 1 = {ω | |X ω| ≤ 1} := by ext ω; simp [abs_le]
  rw [hs] at he
  rw [Measure.real,← he] at hh
  simpa only [Real.coe_toNNReal _ (by linarith : 0 ≤ Var[X;μ]),Measure.real] using hh

theorem two_quadratic_cutoffs_mass {Ω : Type*} [MeasurableSpace Ω]
    (μ : Measure Ω) [IsFiniteMeasure μ] (V W : Ω → ℝ) (hV : Integrable V μ) (hW : Integrable W μ)
    (hVm : Measurable V) (hWm : Measurable W) (hV0 : ∀ ω, 0 ≤ V ω) (hW0 : ∀ ω, 0 ≤ W ω)
    (A B : ℝ) (hA : 0 < A) (hB : 0 < B)
    (hVA : (∫ ω, V ω ∂μ) ≤ A*μ.real univ) (hWB : (∫ ω, W ω ∂μ) ≤ B*μ.real univ) :
    μ.real univ/2 ≤ μ.real {ω | V ω ≤ 4*A ∧ W ω ≤ 4*B} := by
  let E := {ω | V ω ≤ 4*A ∧ W ω ≤ 4*B}
  have hE : MeasurableSet E := (measurableSet_le hVm measurable_const).inter
    (measurableSet_le hWm measurable_const)
  have hpoint (ω : Ω) : (1 : ℝ) ≤ E.indicator (fun _ => (1:ℝ)) ω+V ω/(4*A)+W ω/(4*B) := by
    have hVa := div_nonneg (hV0 ω) (by positivity : 0 ≤ 4*A)
    have hWb := div_nonneg (hW0 ω) (by positivity : 0 ≤ 4*B)
    by_cases hv : V ω ≤ 4*A
    · by_cases hw : W ω ≤ 4*B
      · simp only [Set.indicator_of_mem (show ω ∈ E from ⟨hv,hw⟩)]
        linarith
      · have hbig : 1 ≤ W ω/(4*B) := (le_div_iff₀ (by positivity)).mpr (by linarith)
        simp only [Set.indicator_of_notMem (show ω ∉ E from fun h => hw h.2)]
        linarith
    · have hbig : 1 ≤ V ω/(4*A) := (le_div_iff₀ (by positivity)).mpr (by linarith)
      simp only [Set.indicator_of_notMem (show ω ∉ E from fun h => hv h.1)]
      linarith
  have hi := integral_mono (integrable_const (1:ℝ))
    ((((integrable_const (1:ℝ)).indicator hE).add (hV.div_const (4*A))).add (hW.div_const (4*B))) hpoint
  change (∫ ω : Ω, (1:ℝ) ∂μ) ≤ ∫ ω, E.indicator (fun _ => (1:ℝ)) ω+V ω/(4*A)+W ω/(4*B) ∂μ at hi
  have hIv : Integrable (fun ω => E.indicator (fun _ => (1:ℝ)) ω+V ω/(4*A)) μ :=
    ((integrable_const (1:ℝ)).indicator hE).add (hV.div_const (4*A))
  rw [integral_add hIv (hW.div_const (4*B)),
    integral_add ((integrable_const (1:ℝ)).indicator hE) (hV.div_const (4*A)),
    integral_indicator hE,integral_div,integral_div,integral_const,integral_const] at hi
  simp only [smul_eq_mul,mul_one,Measure.real,Measure.restrict_apply MeasurableSet.univ,univ_inter] at hi
  have hva : (∫ ω, V ω ∂μ)/(4*A) ≤ μ.real univ/4 := by
    apply (div_le_iff₀ (by positivity)).mpr
    nlinarith
  have hwb : (∫ ω, W ω ∂μ)/(4*B) ≤ μ.real univ/4 := by
    apply (div_le_iff₀ (by positivity)).mpr
    nlinarith
  change μ.real univ ≤ μ.real E+(∫ ω, V ω ∂μ)/(4*A)+(∫ ω, W ω ∂μ)/(4*B) at hi
  change μ.real univ/2 ≤ μ.real E
  linarith

end TorusCoverTime.Blocks.B
