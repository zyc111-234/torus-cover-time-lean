import Solutions.Blocks.B.PeriodicAnnularBounds
import Solutions.Blocks.B.FrequencySupport
import Mathlib.Data.Int.Interval

/-! Each scale has at most a constant times its squared radius many nonzero frequencies. -/

noncomputable section
open Classical
open scoped BigOperators
namespace TorusCoverTime.Blocks.B

lemma scaled_centered_fundamental (N : Size) (R : ℝ) (hR : R ≠ 0) (b : ZMod N.val) :
    |(R / N.val) * ((b.valMinAbs : ℝ) / R)| ≤ 1 / 2 := by
  have hN : 0 < (N.val : ℝ) := lt_trans zero_lt_one (size_real_gt_one N)
  rw [show (R / N.val) * ((b.valMinAbs : ℝ) / R) = (b.valMinAbs : ℝ) / N.val by field_simp]
  rw [abs_div, abs_of_pos hN, ← coordinateDistance_eq_abs_centered N b]
  apply (div_le_iff₀ hN).mpr
  linarith [(coordinateDistance_zero_bounds N b).2]

lemma annularArray_support_coordinates (N : Size) (R : ℝ) (hR : 0 < R)
    (ds : List (Fin 4)) (k : Vertex N) (hk : annularArray N R ds k ≠ 0) :
    |(k.1.valMinAbs : ℝ)| ≤ 4 * R ∧ |(k.2.valMinAbs : ℝ)| ≤ 4 * R := by
  have hcore : periodicAnnularCore ds (R / N.val) ((k.1.valMinAbs : ℝ) / R)
      ((k.2.valMinAbs : ℝ) / R) ≠ 0 := by
    intro hz
    exact hk (by rw [annularArray_scaled N R hR.ne' ds k, hz, mul_zero])
  have hs : |sineCoordinate (R / N.val) ((k.1.valMinAbs : ℝ) / R)| ≤ 2 ∧
      |sineCoordinate (R / N.val) ((k.2.valMinAbs : ℝ) / R)| ≤ 2 := by
    constructor
    · by_contra hx
      exact hcore (periodicAnnularCore_zero_outer _ _ _ _ (Or.inl (le_of_lt (lt_of_not_ge hx))))
    · by_contra hy
      exact hcore (periodicAnnularCore_zero_outer _ _ _ _ (Or.inr (le_of_lt (lt_of_not_ge hy))))
  have hc (b : ZMod N.val) (hb : |sineCoordinate (R / N.val) ((b.valMinAbs : ℝ) / R)| ≤ 2) :
      |(b.valMinAbs : ℝ)| ≤ 4 * R := by
    have h := (sineCoordinate_bound_implies_coordinate_bound (R / N.val)
      ((b.valMinAbs : ℝ) / R) (scaled_centered_fundamental N R hR.ne' b) hb).trans Real.pi_le_four
    rw [abs_div, abs_of_pos hR] at h
    exact (div_le_iff₀ hR).mp h
  exact ⟨hc _ hs.1, hc _ hs.2⟩

lemma centered_rectangle_card_bound (N : Size) (R : ℝ) (hR : 1 / 4 ≤ R)
    (s : Finset (Vertex N))
    (hs : ∀ k ∈ s, |(k.1.valMinAbs : ℝ)| ≤ 4 * R ∧ |(k.2.valMinAbs : ℝ)| ≤ 4 * R) :
    (s.card : ℝ) ≤ 144 * R ^ 2 := by
  let L : ℤ := ⌊4 * R⌋
  let I := Finset.Icc (-L) L
  have hL : 0 ≤ L := Int.floor_nonneg.mpr (by linarith)
  have hmem (b : ZMod N.val) (hb : |(b.valMinAbs : ℝ)| ≤ 4 * R) : b.valMinAbs ∈ I := by
    apply Finset.mem_Icc.mpr
    have hu : b.valMinAbs ≤ L := Int.le_floor.mpr ((le_abs_self _).trans hb)
    have hl : -b.valMinAbs ≤ L := Int.le_floor.mpr (by
      simpa only [Int.cast_neg] using (neg_le_abs _).trans hb)
    exact ⟨by omega, hu⟩
  have hcard : s.card ≤ (I ×ˢ I).card := by
    apply Finset.card_le_card_of_injOn (fun k : Vertex N => (k.1.valMinAbs, k.2.valMinAbs))
    · intro k hk
      exact Finset.mem_product.mpr ⟨hmem _ (hs k hk).1, hmem _ (hs k hk).2⟩
    · intro k _ l _ hkl
      exact Prod.ext (ZMod.injective_valMinAbs (congrArg Prod.fst hkl))
        (ZMod.injective_valMinAbs (congrArg Prod.snd hkl))
  have hI : (I.card : ℝ) = 2 * (L : ℝ) + 1 := by
    have hi : (I.card : ℤ) = L + 1 - -L := Int.card_Icc_of_le (-L) L (by omega)
    have hr : (I.card : ℝ) = (L : ℝ) + 1 - -(L : ℝ) := by exact_mod_cast hi
    linarith
  have hcardR : (s.card : ℝ) ≤ (2 * (L : ℝ) + 1) ^ 2 := by
    have h := (show (s.card : ℝ) ≤ ((I ×ˢ I).card : ℝ) by exact_mod_cast hcard)
    simpa only [Finset.card_product, Nat.cast_mul, hI, pow_two] using h
  have hfloor : (L : ℝ) ≤ 4 * R := Int.floor_le _
  have hLr : (0 : ℝ) ≤ L := by exact_mod_cast hL
  calc
    (s.card : ℝ) ≤ (2 * (L : ℝ) + 1) ^ 2 := hcardR
    _ ≤ (12 * R) ^ 2 := by gcongr; linarith
    _ = 144 * R ^ 2 := by ring

lemma annularArray_support_card (N : Size) (R : ℝ) (hR : 1 / 4 ≤ R) (ds : List (Fin 4)) :
    ((frequencySupport N (annularArray N R ds)).card : ℝ) ≤ 144 * R ^ 2 := by
  apply centered_rectangle_card_bound N R hR
  intro k hk
  exact annularArray_support_coordinates N R (by linarith) ds k ((mem_frequencySupport N _ k).mp hk)

end TorusCoverTime.Blocks.B
