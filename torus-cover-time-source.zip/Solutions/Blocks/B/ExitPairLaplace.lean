import Solutions.Blocks.B.ExitSinglePointLaplace

/-! B-T9 / bridge (B.43a): the two-site all-return Laplace bound.
The two-dimensional inverse comparison is proved by a minimum principle.
Its quantitative Green bounds remain explicit geometric inputs. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

theorem two_point_massive_minimum (A B C D e u X Y : ℝ)
    (hB : 0 ≤ B) (hC : 0 ≤ C) (he : 0 < e) (hu : 0 ≤ u)
    (hr₁ : e ≤ A-B) (hr₂ : e ≤ D-C)
    (h₁ : (A+u)*X-B*Y = A-B) (h₂ : (D+u)*Y-C*X = D-C) :
    e/(e+u) ≤ X ∧ e/(e+u) ≤ Y := by
  have hden : 0 < e+u := add_pos_of_pos_of_nonneg he hu
  have lower (r z : ℝ) (hr : e ≤ r) (hz : r ≤ (r+u)*z) : e/(e+u) ≤ z := by
    have hr0 : 0 < r := he.trans_le hr
    have hru : 0 < r+u := add_pos_of_pos_of_nonneg hr0 hu
    have hz' : r/(r+u) ≤ z := (div_le_iff₀ hru).mpr (by nlinarith [hz])
    apply le_trans ?_ hz'
    apply (div_le_div_iff₀ hden hru).mpr
    nlinarith [mul_nonneg (sub_nonneg.mpr hr) hu]
  rcases le_total X Y with hXY | hYX
  · have hx := lower (A-B) X hr₁ (by nlinarith [mul_le_mul_of_nonneg_left hXY hB])
    exact ⟨hx, hx.trans hXY⟩
  · have hy := lower (D-C) Y hr₂ (by nlinarith [mul_le_mul_of_nonneg_left hYX hC])
    exact ⟨hy.trans hYX, hy⟩

theorem two_point_resolvent_lower (A B C D e u X Y : ℝ)
    (hB : 0 ≤ B) (hC : 0 ≤ C) (he : 0 < e) (hu : 0 ≤ u)
    (hdet : 0 < A*D-B*C) (hr₁ : e*(A*D-B*C) ≤ D-B)
    (hr₂ : e*(A*D-B*C) ≤ A-C)
    (h₁ : (1+u*A)*X+u*B*Y = 1) (h₂ : u*C*X+(1+u*D)*Y = 1) :
    e/(e+u) ≤ X ∧ e/(e+u) ≤ Y := by
  have h₁' : (D+u*(A*D-B*C))*X-B*Y = D-B := by
    linear_combination D*h₁-B*h₂
  have h₂' : (A+u*(A*D-B*C))*Y-C*X = A-C := by
    linear_combination A*h₂-C*h₁
  have hl := two_point_massive_minimum D B C A (e*(A*D-B*C)) (u*(A*D-B*C)) X Y
    hB hC (mul_pos he hdet) (mul_nonneg hu hdet.le) hr₁ hr₂ h₁' h₂'
  have hratio : e*(A*D-B*C)/(e*(A*D-B*C)+u*(A*D-B*C)) = e/(e+u) := by
    rw [← add_mul, mul_div_mul_right _ _ hdet.ne']
  rwa [hratio] at hl

def conditionedDiskGreen (N : Size) (c : Vertex N) (R : ℝ) (b a x : Vertex N) : ℝ :=
  diskGreen N c R a x * exitHarmonic N (torusDisk N c R) b x /
    exitHarmonic N (torusDisk N c R) b a

theorem conditionedDiskGreen_nonneg (N : Size) (c : Vertex N) (R : ℝ)
    (hR : 0 ≤ R) (hsmall : 2*(R+1) < N.val) (b a x : Vertex N) :
    0 ≤ conditionedDiskGreen N c R b a x :=
  div_nonneg (mul_nonneg (diskGreen_nonneg N c R hR hsmall a x)
    (exitHarmonic_nonneg N _ b x)) (exitHarmonic_nonneg N _ b a)

theorem disk_conditioned_pair_resolvent (N : Size) (c : Vertex N) (R : ℝ)
    (hR : 0 ≤ R) (hsmall : 2*(R+1) < N.val) (b x y : Vertex N)
    (hx : 0 < exitHarmonic N (torusDisk N c R) b x)
    (hy : 0 < exitHarmonic N (torusDisk N c R) b y)
    (u : ℝ) (hu : 0 ≤ u) (a : Vertex N)
    (ha : 0 < exitHarmonic N (torusDisk N c R) b a) :
    let U : Vertex N → ℝ := fun z => (if z=x then u else 0)+(if z=y then u else 0)
    let F : Vertex N → ℝ := fun z => exitLaplace N (torusDisk N c R) b U z /
      exitHarmonic N (torusDisk N c R) b z
    F a = 1-u*(conditionedDiskGreen N c R b a x*F x+
      conditionedDiskGreen N c R b a y*F y) := by
  dsimp only
  let U : Vertex N → ℝ := fun z => (if z=x then u else 0)+(if z=y then u else 0)
  have hU : ∀ z, 0 ≤ U z := by intro z; dsimp only [U]; split_ifs <;> positivity
  have h := disk_exitLaplace_resolvent N c R hR hsmall b U hU a
  simp only [U, add_mul, Finset.sum_add_distrib, ite_mul, zero_mul,
    Finset.sum_ite_eq', Finset.mem_univ, if_true] at h
  change exitLaplace N (torusDisk N c R) b U a /
      exitHarmonic N (torusDisk N c R) b a = _
  rw [h]
  unfold conditionedDiskGreen
  field_simp
  <;> ring

theorem disk_conditioned_pair_laplace_upper (hWalk : WalkModelRegular)
    (N : Size) (c : Vertex N) (R : ℝ) (hR : 0 ≤ R) (hsmall : 2*(R+1) < N.val)
    (a b x y : Vertex N)
    (ha : 0 < exitHarmonic N (torusDisk N c R) b a)
    (hx : 0 < exitHarmonic N (torusDisk N c R) b x)
    (hy : 0 < exitHarmonic N (torusDisk N c R) b y) (e : ℝ) (he : 0 < e)
    (hdet : 0 < conditionedDiskGreen N c R b x x*conditionedDiskGreen N c R b y y-
      conditionedDiskGreen N c R b x y*conditionedDiskGreen N c R b y x)
    (hrow₁ : e*(conditionedDiskGreen N c R b x x*conditionedDiskGreen N c R b y y-
      conditionedDiskGreen N c R b x y*conditionedDiskGreen N c R b y x) ≤
        conditionedDiskGreen N c R b y y-conditionedDiskGreen N c R b x y)
    (hrow₂ : e*(conditionedDiskGreen N c R b x x*conditionedDiskGreen N c R b y y-
      conditionedDiskGreen N c R b x y*conditionedDiskGreen N c R b y x) ≤
        conditionedDiskGreen N c R b x x-conditionedDiskGreen N c R b y x)
    (u : ℝ) (hu : 0 ≤ u) :
    (∫ ω, Real.exp (-u*(localTime N a ω (finiteExitDuration N (torusDisk N c R) a ω) x+
      localTime N a ω (finiteExitDuration N (torusDisk N c R) a ω) y))
        ∂exactExitLaw N (torusDisk N c R) a b) ≤
      1-(e*(conditionedDiskGreen N c R b a x+conditionedDiskGreen N c R b a y))*u/(e+u) := by
  let U : Vertex N → ℝ := fun z => (if z=x then u else 0)+(if z=y then u else 0)
  let F : Vertex N → ℝ := fun z => exitLaplace N (torusDisk N c R) b U z /
    exitHarmonic N (torusDisk N c R) b z
  have hres (z : Vertex N) (hz : 0 < exitHarmonic N (torusDisk N c R) b z) :
      F z = 1-u*(conditionedDiskGreen N c R b z x*F x+
        conditionedDiskGreen N c R b z y*F y) :=
    disk_conditioned_pair_resolvent N c R hR hsmall b x y hx hy u hu z hz
  have h₁ : (1+u*conditionedDiskGreen N c R b x x)*F x+
      u*conditionedDiskGreen N c R b x y*F y = 1 := by nlinarith [hres x hx]
  have h₂ : u*conditionedDiskGreen N c R b y x*F x+
      (1+u*conditionedDiskGreen N c R b y y)*F y = 1 := by nlinarith [hres y hy]
  have hl := two_point_resolvent_lower _ _ _ _ e u (F x) (F y)
    (conditionedDiskGreen_nonneg N c R hR hsmall b x y)
    (conditionedDiskGreen_nonneg N c R hR hsmall b y x) he hu hdet hrow₁ hrow₂ h₁ h₂
  have hphys : (∫ ω, Real.exp (-u*(localTime N a ω (finiteExitDuration N (torusDisk N c R) a ω) x+
      localTime N a ω (finiteExitDuration N (torusDisk N c R) a ω) y))
        ∂exactExitLaw N (torusDisk N c R) a b) = F a := by
    have hp := conditioned_exitOccupation_laplace hWalk N (torusDisk N c R) a b U
    simp only [exitOccupation, U, add_mul, Finset.sum_add_distrib, ite_mul, zero_mul,
      Finset.sum_ite_eq', Finset.mem_univ, if_true] at hp
    convert hp using 1
    congr 1
    funext ω
    congr 1
    ring
  rw [hphys, hres a ha]
  have hsum := add_le_add
    (mul_le_mul_of_nonneg_left hl.1 (conditionedDiskGreen_nonneg N c R hR hsmall b a x))
    (mul_le_mul_of_nonneg_left hl.2 (conditionedDiskGreen_nonneg N c R hR hsmall b a y))
  have hb := mul_le_mul_of_nonneg_left hsum hu
  calc
    _ ≤ 1-u*(conditionedDiskGreen N c R b a x*(e/(e+u))+
        conditionedDiskGreen N c R b a y*(e/(e+u))) := by linarith
    _ = _ := by ring

end TorusCoverTime.Blocks.B
