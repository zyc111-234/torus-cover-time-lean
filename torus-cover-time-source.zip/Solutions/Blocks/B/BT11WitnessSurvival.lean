import Solutions.Blocks.B.BT11FiniteLoss
import Solutions.Blocks.B.BT11Splice

/-! Preserve at least half of the distinct defect vertices. Witnesses
may repeat and their loss events may be dependent. -/
noncomputable section
open MeasureTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

def bt11GoodPrefix (N : Size) (a : Vertex N) (u t : ℝ) : Set WalkSample :=
  {ω | (ω,t)∉pointNearSoftEvent N a a (bt11FarRadius N) u ∧
    (ω,t)∉pointNearTerminalEvent N a (bt11FarRadius N) u}

theorem bt11GoodPrefix_measurable (N : Size) (a : Vertex N) (u t : ℝ) :
    MeasurableSet (bt11GoodPrefix N a u t) :=
  (((pointNearSoftEvent_measurable N a a _ u).preimage (measurable_id.prodMk measurable_const)).compl).inter
    (((pointNearTerminalEvent_measurable N a _ u).preimage (measurable_id.prodMk measurable_const)).compl)

theorem bt11_good_far (N : Size) (a x : Vertex N) (u t : ℝ) (ω : WalkSample)
    (hgood : ω∈bt11GoodPrefix N a u t) (hx : x∈softSet N a ω u t) :
    bt11FarRadius N≤periodicDistance a x ∧ bt11FarRadius N≤periodicDistance (walk N a ω t) x := by
  have hsoft := (Finset.mem_filter.mp hx).2
  constructor
  · by_contra! h
    exact hgood.1 ⟨x,(mem_torusDisk N a x _).mpr (by simpa only [periodicDistance_comm] using h),hsoft⟩
  · by_contra! h
    exact hgood.2 ⟨x,(mem_torusDisk N (walk N a ω t) x _).mpr
      (by simpa only [periodicDistance_comm] using h),hsoft⟩

theorem bt11_witness_function (N : Size) (U : Finset (Vertex N)) :
    ∃ w : Vertex N → Vertex N, ∀ x∈wideDefects N U, w x∈U ∧ bt10Wide N x (w x) := by
  have h : ∀ x : Vertex N, ∃ y : Vertex N, x∈wideDefects N U → y∈U ∧ bt10Wide N x y := by
    intro x
    by_cases hx : x∈wideDefects N U
    · obtain ⟨_,y,hy,hlo,hhi⟩ := Finset.mem_filter.mp hx
      exact ⟨y,fun _ => ⟨hy,hlo,hhi⟩⟩
    · exact ⟨x,fun h => (hx h).elim⟩
  choose w hw using h
  exact ⟨w,hw⟩

theorem bt11_retained_card {Ω : Type*} (N : Size) (U V : Finset (Vertex N))
    (w : Vertex N → Vertex N) (F : Vertex N → Set Ω) (ω : Ω)
    (hw : ∀ x∈wideDefects N U,w x∈U ∧ bt10Wide N x (w x))
    (hkeep : ∀ x∈wideDefects N U,ω∉F x → x∈V ∧ w x∈V) :
    ((wideDefects N U).card:ℝ)-bt11LossCount (wideDefects N U) F ω≤((wideDefects N V).card:ℝ) := by
  have hsub : (wideDefects N U).filter (fun x => ω∉F x)⊆wideDefects N V := by
    intro x hx
    obtain ⟨hx,hF⟩ := Finset.mem_filter.mp hx
    have hp := hkeep x hx hF
    exact Finset.mem_filter.mpr ⟨hp.1,w x,hp.2,(hw x hx).2⟩
  have hc := Finset.card_le_card hsub
  have hsum := Finset.card_filter_add_card_filter_not (s := wideDefects N U) (p := fun x => ω∈F x)
  have hr : (((wideDefects N U).filter (fun x => ω∈F x)).card:ℝ)+
      (((wideDefects N U).filter (fun x => ω∉F x)).card:ℝ)=((wideDefects N U).card:ℝ) := by exact_mod_cast hsum
  rw [bt11LossCount_card]
  have hc' : (((wideDefects N U).filter (fun x => ω∉F x)).card:ℝ)≤((wideDefects N V).card:ℝ) := by exact_mod_cast hc
  linarith

theorem bt11_glue_good_past (N : Size) (a : Vertex N) (n : ℕ)
    {p : A.WalkPrefix n} (hp : ∀ j,0<(p j).1) (s : ℝ) (hs : A.prefixTime n p≤s)
    {η : WalkSample} (hη : ∀ j,0<(η j).1) (hnon : Tendsto (jumpTime η) atTop atTop) (u : ℝ) :
    A.glueAt n p s η∈bt11GoodPrefix N a u s ↔ A.glueAt n p s A.regularSample∈bt11GoodPrefix N a u s := by
  simp only [bt11GoodPrefix,mem_setOf_eq,pointNearSoftEvent,pointNearTerminalEvent,
    A.walk_glueAt_observation N a n hp s hs hη hnon,
    A.walk_glueAt_observation N a n hp s hs A.regularSample_spec.1 A.regularSample_spec.2,
    bt11_glue_localTime_past N a _ n hp s hs hη hnon]

theorem bt11_prefix_extension (hWalk : WalkModelRegular) :
    ∀ᶠ N : Size in atTop, ∀ a : Vertex N, ∀ u η s T : ℝ, 0<η →
    bt11ShortTime N≤T → T≤2*bt11ShortTime N → ∀ n : ℕ, ∀ p : A.WalkPrefix n,
    (∀ j,0<(p j).1) → A.prefixTime n p≤s →
    A.glueAt n p s A.regularSample∈bt11Bad N a u η s∩bt11GoodPrefix N a u s →
    ENNReal.ofReal (1/(4*vertexCount N))≤
      ∫⁻ ξ, if A.glueAt n p s ξ∈bt11Bad N a (u+1) (η/2) (s+T) ∧
        walk N a (A.glueAt n p s ξ) (s+T)=a then (1:ℝ≥0∞) else 0 ∂walkLaw := by
  filter_upwards [bt11_short_bridge_pair hWalk,bt11_short_mixing hWalk] with N hpair hmix
  intro a u η s T hη hlo hhi n p hp hs hgood
  let ω₀ := A.glueAt n p s A.regularSample
  let b := A.prefixPosition N a n p
  let U := softSet N a ω₀ u s
  let S := wideDefects N U
  have hM : 0<(S.card:ℝ) := (mul_pos hη (Real.sqrt_pos.mpr (logSize_pos N))).trans hgood.1
  have hS : S.Nonempty := Finset.card_pos.mp (by exact_mod_cast hM)
  obtain ⟨w,hw⟩ := bt11_witness_function N U
  let F := fun x : Vertex N => {ξ : WalkSample | 1<localTime N b ξ T x ∨ 1<localTime N b ξ T (w x)}
  let R : Set WalkSample := {ξ | walk N b ξ T=a}
  have hF (x : Vertex N) : MeasurableSet (F x) :=
    (measurableSet_lt measurable_const (localTime_measurable_in_sample N b x T)).union
      (measurableSet_lt measurable_const (localTime_measurable_in_sample N b (w x) T))
  have hR : MeasurableSet R := ((measurable_walk_eq_joint N b a).comp (measurable_id.prodMk measurable_const)).setOf
  have hb (x : Vertex N) (hx : x∈U) : bt11FarRadius N≤periodicDistance b x ∧ bt11FarRadius N≤periodicDistance a x := by
    have h := bt11_good_far N a x u s ω₀ hgood.2 hx
    have he : walk N a ω₀ s=b :=
      A.walk_glueAt_observation N a n hp s hs A.regularSample_spec.1 A.regularSample_spec.2
    rw [he] at h
    exact h.symm
  have hloss := bt11_finite_loss walkLaw S hS F hF R hR (1/(16*vertexCount N)) (fun x hx =>
    hpair T hlo hhi b a x (w x) (hb x (Finset.mem_filter.mp hx).1).1
      (hb x (Finset.mem_filter.mp hx).1).2 (hb (w x) (hw x hx).1).1 (hb (w x) (hw x hx).1).2)
  let G : Set WalkSample := {ξ | ξ∈R ∧ bt11LossCount S F ξ≤(S.card:ℝ)/2}
  have hG : MeasurableSet G := hR.inter (measurableSet_le (bt11LossCount_measurable S F hF) measurable_const)
  have hpR : 1/(2*vertexCount N)≤walkLaw.real R := (hmix T hlo b a).1
  have hmass : 1/(4*vertexCount N)≤walkLaw.real G := by
    have he : 1/(4*vertexCount N)≤1/(2*vertexCount N)-2*(1/(16*vertexCount N)) := by
      calc
        _ = (1/4:ℝ)*(vertexCount N)⁻¹ := by ring
        _ ≤ (3/8:ℝ)*(vertexCount N)⁻¹ := mul_le_mul_of_nonneg_right (by norm_num)
          (inv_nonneg.mpr (vertexCount_pos N).le)
        _ = _ := by ring
    change walkLaw.real R-2*(1/(16*vertexCount N))≤walkLaw.real G at hloss
    linarith
  have hsub : ∀ᵐ ξ ∂walkLaw, G.indicator (fun _ => (1:ℝ≥0∞)) ξ≤
      if A.glueAt n p s ξ∈bt11Bad N a (u+1) (η/2) (s+T) ∧
        walk N a (A.glueAt n p s ξ) (s+T)=a then 1 else 0 := by
    filter_upwards [hWalk.1] with ξ hξ
    by_cases hξG : ξ∈G
    · rw [indicator_of_mem hξG]
      have hT := (bt11ShortTime_pos N).le.trans hlo
      have hcount := bt11_retained_card N U (softSet N a (A.glueAt n p s ξ) (u+1) (s+T)) w F ξ hw (by
        intro x hx hkeep
        have hf : localTime N b ξ T x≤1 ∧ localTime N b ξ T (w x)≤1 := by
          simpa only [F,mem_setOf_eq,not_or,not_lt] using hkeep
        constructor
        · apply Finset.mem_filter.mpr
          refine ⟨Finset.mem_univ _,?_⟩
          rw [bt11_glue_localTime_add N a x n hp s hs hξ.1 hξ.2 T hT]
          have hpast := (Finset.mem_filter.mp (Finset.mem_filter.mp hx).1).2
          change localTime N a ω₀ s x≤u at hpast
          linarith [hf.1]
        · apply Finset.mem_filter.mpr
          refine ⟨Finset.mem_univ _,?_⟩
          rw [bt11_glue_localTime_add N a (w x) n hp s hs hξ.1 hξ.2 T hT]
          have hpast := (Finset.mem_filter.mp (hw x hx).1).2
          change localTime N a ω₀ s (w x)≤u at hpast
          linarith [hf.2])
      have hbad : A.glueAt n p s ξ∈bt11Bad N a (u+1) (η/2) (s+T) := by
        change (η/2)*Real.sqrt (logSize N)<_ 
        have hpre : η*Real.sqrt (logSize N)<(S.card:ℝ) := hgood.1
        change (S.card:ℝ)-bt11LossCount S F ξ≤bt10DefectCount N a (u+1) (A.glueAt n p s ξ,s+T) at hcount
        dsimp only [bt11Bad,mem_setOf_eq,bt10DefectCount] at *
        linarith [hξG.2]
      have hend : walk N a (A.glueAt n p s ξ) (s+T)=a :=
        (A.walk_glueAt_future N a n hp s hs hξ.1 hξ.2 T hT).trans hξG.1
      rw [if_pos ⟨hbad,hend⟩]
    · rw [indicator_of_notMem hξG]
      exact bot_le
  have hh := ENNReal.ofReal_le_ofReal hmass
  rw [Measure.real,ENNReal.ofReal_toReal (measure_ne_top _ _)] at hh
  exact hh.trans ((le_of_eq (lintegral_indicator_one hG).symm).trans (lintegral_mono_ae hsub))

end TorusCoverTime.Blocks.B
