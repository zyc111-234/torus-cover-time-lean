import Solutions.Blocks.B.DiskGreenSquare

/-! A scale-uniform lower mean inequality for nonnegative harmonic functions
on actual Euclidean torus disks. No Harnack inequality is assumed. -/

noncomputable section
open Classical
namespace TorusCoverTime.Blocks.B

def diskGreenInnerScale : ℝ := 4*Real.exp ((diskGreenLogErrorConstant+2)/g)

theorem diskGreenInnerScale_ge_four : 4 ≤ diskGreenInnerScale := by
  have hg : 0 < g := by unfold g; positivity
  have hC := diskGreenLogErrorConstant_pos
  have he := Real.one_le_exp_iff.mpr (show 0 ≤ (diskGreenLogErrorConstant+2)/g by positivity)
  unfold diskGreenInnerScale
  linarith

theorem diskGreen_inner_lower (N : Size) (c : Vertex N) (R : ℝ) (hR : 1 ≤ R)
    (hsmall : 2*(R+1) < N.val) (x y : Vertex N)
    (hx : periodicDistance x c ≤ R/(2*diskGreenInnerScale))
    (hy : periodicDistance y c ≤ R/(2*diskGreenInnerScale)) : 1 ≤ diskGreen N c R x y := by
  have hL := diskGreenInnerScale_ge_four
  have hL0 : 0 < diskGreenInnerScale := by linarith
  have hR0 : 0 < R := by linarith
  have hs : R/(2*diskGreenInnerScale) ≤ R/2 :=
    div_le_div_of_nonneg_left hR0.le (by norm_num) (by linarith)
  have hxD : x ∈ torusDisk N c R := (mem_torusDisk N c x R).mpr (by linarith)
  by_cases hxy : x = y
  · subst y
    exact diskGreen_diagonal N c R hR0.le hsmall x hxD
  · have ht := periodicDistance_triangle N x c y
    rw [periodicDistance_comm c y] at ht
    have hd : periodicDistance x y ≤ R/diskGreenInnerScale := by
      have he : R/(2*diskGreenInnerScale)+R/(2*diskGreenInnerScale) = R/diskGreenInnerScale := by ring
      linarith
    have he := diskGreen_lower_of_distance N c R hR hsmall x y hxD (hy.trans hs) hxy
      (R/diskGreenInnerScale) hd
    have hid : R/(R/diskGreenInnerScale) = diskGreenInnerScale := by field_simp
    rw [hid] at he
    have hg : 0 < g := by unfold g; positivity
    have hlog : g*Real.log diskGreenInnerScale - diskGreenLogErrorConstant ≥ 2 := by
      unfold diskGreenInnerScale
      rw [Real.log_mul (by norm_num) (Real.exp_pos _).ne', Real.log_exp]
      have hc : g*((diskGreenLogErrorConstant+2)/g) = diskGreenLogErrorConstant+2 := by field_simp
      have hp := mul_nonneg hg.le (Real.log_nonneg (by norm_num : (1:ℝ) ≤ 4))
      nlinarith
    linarith

theorem disk_harmonic_mean_lower (N : Size) (c : Vertex N) (R : ℝ) (hR : 1 ≤ R)
    (hsmall : 4*(R+1) < N.val) (f : Vertex N → ℝ) (hf : ∀ x, 0 ≤ f x)
    (hg : ∀ x ∈ torusDisk N c R, generator N f x = 0)
    (x : Vertex N) (hx : periodicDistance x c ≤ R/(2*diskGreenInnerScale)) :
    (∑ y ∈ torusDisk N c (R/(2*diskGreenInnerScale)), f y) ≤
      4*diskGreenConvolutionConstant*R^2*f x := by
  have hR0 : 0 < R := by linarith
  have hC := diskGreenConvolutionConstant_pos
  have hL := diskGreenInnerScale_ge_four
  have hs : 2*(R+1) < N.val := by linarith
  let μ := 1/(2*diskGreenConvolutionConstant*R^2)
  have hμ : 0 < μ := by dsimp [μ]; positivity
  have hhalf : R/(2*diskGreenInnerScale) ≤ R/2 :=
    div_le_div_of_nonneg_left hR0.le (by norm_num) (by linarith)
  have he := harmonic_average_from_green N (torusDisk N c R) (torusDisk_proper N c R hR0.le hs)
    (diskBarrier N c R) (fun z hz => diskBarrier_generator N c R hR0.le hs z hz)
    μ hμ (torusDisk N c (R/(2*diskGreenInnerScale))) 1 (diskGreenConvolutionConstant*R^2)
    f hf hg x (by
      intro y hy
      have hy' := (mem_torusDisk N c y _).mp hy
      exact diskGreen_inner_lower N c R hR hs x y hx hy'.le) (by
      intro y hy
      have hy' := (mem_torusDisk N c y _).mp hy
      exact diskGreen_convolution_bound N c R hR hsmall x y (hx.trans hhalf) (hy'.le.trans hhalf))
  have hid : μ*(1-μ*(diskGreenConvolutionConstant*R^2)) =
      1/(4*diskGreenConvolutionConstant*R^2) := by dsimp [μ]; field_simp; ring
  rw [hid] at he
  have hp : 0 < 4*diskGreenConvolutionConstant*R^2 := by positivity
  have hh := (div_le_iff₀ hp).mp (by simpa only [one_div_mul_eq_div] using he)
  nlinarith

end TorusCoverTime.Blocks.B
