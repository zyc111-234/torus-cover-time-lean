import Solutions.Blocks.B.OccupationExponential

/-! B-T3 / bridge (B.13a--b): the exact Laplace transform of ALL occupation
before the specified exit. The first-step identity retains the entire tail
weight, and the existing finite-domain Green inverse gives the resolvent. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

def exitLaplaceWeight (N : Size) (D : Finset (Vertex N)) (b : Vertex N)
    (U : Vertex N → ℝ) (a : Vertex N) (ω : WalkSample) : ℝ :=
  if ω ∈ exitsThrough N D a b then
    Real.exp (-holdingPotentialSum N U a ω (finiteExitIndex N D a ω)) else 0

theorem measurable_exitLaplaceWeight (N : Size) (D : Finset (Vertex N)) (b : Vertex N)
    (U : Vertex N → ℝ) (a : Vertex N) : Measurable (exitLaplaceWeight N D b U a) := by
  have hm : Measurable (fun p : WalkSample × ℕ => holdingPotentialSum N U a p.1 p.2) :=
    measurable_from_prod_countable_left (measurable_holdingPotentialSum N U a)
  exact ((hm.comp (measurable_id.prodMk (measurable_finiteExitIndex N D a))).neg.exp).ite
    (measurableSet_exitsThrough N D a b) measurable_const

theorem exitLaplaceWeight_nonneg (N : Size) (D : Finset (Vertex N)) (b : Vertex N)
    (U : Vertex N → ℝ) (a : Vertex N) (ω : WalkSample) :
    0 ≤ exitLaplaceWeight N D b U a ω := by
  unfold exitLaplaceWeight
  split_ifs <;> positivity

theorem exitLaplaceWeight_norm_le_one (N : Size) (D : Finset (Vertex N)) (b : Vertex N)
    (U : Vertex N → ℝ) (hU : ∀ x, 0 ≤ U x) (a : Vertex N) (ω : WalkSample) :
    ‖exitLaplaceWeight N D b U a ω‖ ≤ 1 := by
  rw [Real.norm_eq_abs, abs_of_nonneg (exitLaplaceWeight_nonneg N D b U a ω)]
  unfold exitLaplaceWeight
  split_ifs
  · exact Real.exp_le_one_iff.mpr (neg_nonpos.mpr (holdingPotentialSum_nonneg N U hU a ω _))
  · norm_num

theorem exitLaplaceWeight_boundary (N : Size) (D : Finset (Vertex N)) (b : Vertex N)
    (U : Vertex N → ℝ) (a : Vertex N) (ha : a ∉ D) (ω : WalkSample) :
    exitLaplaceWeight N D b U a ω = if a = b then 1 else 0 := by
  have hj : finiteExitIndex N D a ω = 0 := finiteExitIndex_of_exit_word N D a a ω 0
    ⟨ha, by simp [position], by intro i; exact Fin.elim0 i⟩
  simp only [exitLaplaceWeight, hj, exitsThrough_outside N D a b ha ω,
    holdingPotentialSum, Finset.range_zero, Finset.sum_empty, neg_zero, Real.exp_zero]

theorem exitLaplaceWeight_first_step (N : Size) (D : Finset (Vertex N)) (b : Vertex N)
    (U : Vertex N → ℝ) (a : Vertex N) (ha : a ∈ D) (ω : WalkSample) :
    exitLaplaceWeight N D b U a ω = Real.exp (-U a * holdingTime ω 0) *
      exitLaplaceWeight N D b U (a + direction N (ω 0).2) (walkTail ω) := by
  by_cases he : ω ∈ exitsThrough N D a b
  · obtain ⟨n, hn⟩ := (exitsThrough_shift N D a b ha ω).mp he
    have hi := finiteExitIndex_of_exit_word N D a b ω (n+1)
      ((exitsThroughAt_succ_shift N D a b ω n).mpr ⟨ha, hn⟩)
    have hit := finiteExitIndex_of_exit_word N D (a+direction N (ω 0).2) b (walkTail ω) n hn
    simp only [exitLaplaceWeight, if_pos he, if_pos (show walkTail ω ∈
      exitsThrough N D (a+direction N (ω 0).2) b from ⟨n,hn⟩), hi, hit,
      holdingPotentialSum_succ_shift, neg_add, Real.exp_add, neg_mul]
  · have ht := mt (exitsThrough_shift N D a b ha ω).mpr he
    simp only [exitLaplaceWeight, if_neg he, if_neg ht, mul_zero]

def exitLaplace (N : Size) (D : Finset (Vertex N)) (b : Vertex N)
    (U : Vertex N → ℝ) (a : Vertex N) : ℝ :=
  ∫ ω, exitLaplaceWeight N D b U a ω ∂walkLaw

theorem exitLaplace_nonneg (N : Size) (D : Finset (Vertex N)) (b : Vertex N)
    (U : Vertex N → ℝ) (a : Vertex N) : 0 ≤ exitLaplace N D b U a :=
  integral_nonneg (exitLaplaceWeight_nonneg N D b U a)

theorem exitLaplace_boundary (N : Size) (D : Finset (Vertex N)) (b : Vertex N)
    (U : Vertex N → ℝ) (a : Vertex N) (ha : a ∉ D) :
    exitLaplace N D b U a = if a = b then 1 else 0 := by
  simp [exitLaplace, exitLaplaceWeight_boundary N D b U a ha]

theorem exitLaplace_first_step (N : Size) (D : Finset (Vertex N)) (b : Vertex N)
    (U : Vertex N → ℝ) (hU : ∀ x, 0 ≤ U x) (a : Vertex N) (ha : a ∈ D) :
    exitLaplace N D b U a =
      (∑ d : Fin 4, exitLaplace N D b U (a+direction N d))/(4*(1+U a)) := by
  unfold exitLaplace
  simp_rw [exitLaplaceWeight_first_step N D b U a ha]
  exact integral_first_step_weighted (U a) (hU a)
    (fun d => exitLaplaceWeight N D b U (a+direction N d))
    (fun d => measurable_exitLaplaceWeight N D b U _)
    (fun d => exitLaplaceWeight_norm_le_one N D b U hU _)

theorem exitLaplace_generator (N : Size) (D : Finset (Vertex N)) (b : Vertex N)
    (U : Vertex N → ℝ) (hU : ∀ x, 0 ≤ U x) (a : Vertex N) (ha : a ∈ D) :
    generator N (exitLaplace N D b U) a = U a * exitLaplace N D b U a := by
  have h := exitLaplace_first_step N D b U hU a ha
  have hd : 0 < 4*(1+U a) := by have := hU a; positivity
  have he := (eq_div_iff hd.ne').mp h
  simp only [generator, Finset.sum_sub_distrib, Finset.sum_const, Finset.card_univ,
    Fintype.card_fin, nsmul_eq_mul, Nat.cast_ofNat]
  nlinarith

theorem disk_exitLaplace_resolvent (N : Size) (c : Vertex N) (R : ℝ)
    (hR : 0 ≤ R) (hsmall : 2*(R+1) < N.val) (b : Vertex N)
    (U : Vertex N → ℝ) (hU : ∀ x, 0 ≤ U x) (a : Vertex N) :
    exitLaplace N (torusDisk N c R) b U a = exitHarmonic N (torusDisk N c R) b a -
      ∑ z, U z * exitLaplace N (torusDisk N c R) b U z * diskGreen N c R a z := by
  let D := torusDisk N c R
  let f := exitHarmonic N D b - exitLaplace N D b U
  have hboundary : ∀ z, z ∉ D → f z = 0 := by
    intro z hz
    simp only [f, Pi.sub_apply, exitHarmonic_boundary N D b z hz,
      exitLaplace_boundary N D b U z hz, sub_self]
  have hgenerator : ∀ z ∈ D, -generator N f z = U z * exitLaplace N D b U z := by
    intro z hz
    rw [show f = exitHarmonic N D b - exitLaplace N D b U from rfl,
      generator_sub, exitHarmonic_generator N D b z hz,
      exitLaplace_generator N D b U hU z hz]
    ring
  have h := congrFun (domainGreenFromBarrier_solution N D (torusDisk_proper N c R hR hsmall)
    (diskBarrier N c R) (fun z hz => diskBarrier_generator N c R hR hsmall z hz)
    (fun z => U z * exitLaplace N D b U z) f hboundary hgenerator) a
  change exitHarmonic N D b a - exitLaplace N D b U a =
    ∑ z, U z * exitLaplace N D b U z * diskGreen N c R a z at h
  linarith

theorem exitLaplaceWeight_eq_physical_ae (hWalk : WalkModelRegular) (N : Size)
    (D : Finset (Vertex N)) (b : Vertex N) (U : Vertex N → ℝ) (a : Vertex N) :
    exitLaplaceWeight N D b U a =ᵐ[walkLaw]
      (exitsThrough N D a b).indicator (fun ω => Real.exp (-exitOccupation N D U a ω)) := by
  filter_upwards [hWalk.1] with ω hω
  simp only [exitLaplaceWeight, Set.indicator]
  split_ifs
  · rw [holdingPotentialSum_eq_localTime N U a hω.1 hω.2]
    rfl
  · rfl

theorem conditioned_exitOccupation_laplace (hWalk : WalkModelRegular) (N : Size)
    (D : Finset (Vertex N)) (a b : Vertex N) (U : Vertex N → ℝ) :
    (∫ ω, Real.exp (-exitOccupation N D U a ω) ∂exactExitLaw N D a b) =
      exitLaplace N D b U a / exitHarmonic N D b a := by
  rw [exactExitLaw, ProbabilityTheory.cond, integral_smul_measure,
    ← integral_indicator (measurableSet_exitsThrough N D a b),
    ← integral_congr_ae (exitLaplaceWeight_eq_physical_ae hWalk N D b U a)]
  change _ * exitLaplace N D b U a = _
  rw [ENNReal.toReal_inv]
  unfold exitHarmonic Measure.real
  ring

end TorusCoverTime.Blocks.B
