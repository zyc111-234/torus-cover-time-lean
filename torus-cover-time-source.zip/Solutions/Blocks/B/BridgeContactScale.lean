import Solutions.Blocks.B.BridgeDensityNormalization

/-! The existing actual finite-bridge single-contact estimate, with its
positive density denominator paid and its height factors made uniform. -/

noncomputable section
open MeasureTheory ProbabilityTheory Set
open scoped ENNReal
namespace TorusCoverTime.Blocks.B

def bridgeContactCoefficient (U H b : ℝ) : ℝ :=
  1024^2*bridgeDensityConstant U*(H+bridgeBarrierPadding U)^2*(b+bridgeBarrierPadding U)^3

theorem bridgeContactCoefficient_nonneg (U H b : ℝ) (hb : 0 ≤ b) : 0 ≤ bridgeContactCoefficient U H b := by
  unfold bridgeContactCoefficient bridgeDensityConstant bridgeBarrierPadding
  positivity

namespace GaussianClockPath
variable {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
variable {n : ℕ} (W : GaussianClockPath μ n)

theorem bridge_contact_single_scale {U : ℝ} (h : W.ClockBounds U)
    (k : Fin (n+1)) (hk : 3 ≤ k.val) (hr : 3 ≤ n-k.val)
    (H b : ℝ) (hH : 0 ≤ H) (hb : 0 ≤ b) :
    μ {ω | (∀ i, W.bridge ω i ≤ H) ∧ H-b ≤ W.bridge ω k} ≤
      ENNReal.ofReal (bridgeContactCoefficient U H b*Real.sqrt n /
        (((k.val : ℝ)*Real.sqrt k.val)*(((n-k.val : ℕ) : ℝ)*Real.sqrt ((n-k.val : ℕ) : ℝ)))) := by
  have hn : 1 ≤ n := by omega
  have he := h.endpoint_bounds W
  have hn0 : (0 : ℝ)<n := by exact_mod_cast (show 0<n by omega)
  have hv : 0 < W.clock (Fin.last n) := hn0.trans_le he.1
  let d := Real.exp (-(1/(2*W.clock (Fin.last n))))/Real.sqrt (2*Real.pi*W.clock (Fin.last n))
  have hd : 0<d := by dsimp [d]; positivity
  let l := (k.val : ℝ)*Real.sqrt k.val
  let r := ((n-k.val : ℕ) : ℝ)*Real.sqrt ((n-k.val : ℕ) : ℝ)
  have hl : 0<l := by dsimp [l]; positivity
  have hrr : 0<r := by dsimp [r]; positivity
  let p := bridgeBarrierPadding U
  have hp : 2 ≤ p := bridgeBarrierPadding_ge_two U
  have hc1 : 0 ≤ 1024*(b+1)*(H+2*Real.sqrt U+1)*(b+1+2*Real.sqrt U+1)/l := by positivity
  have hb1 : 1024*(b+1)*(H+2*Real.sqrt U+1)*(b+1+2*Real.sqrt U+1)/l ≤
      1024*(H+p)*(b+p)^2/l := by
    have hs : 0 ≤ Real.sqrt U := Real.sqrt_nonneg _
    dsimp only [p,bridgeBarrierPadding]
    calc
      _ ≤ 1024*(b+(2*Real.sqrt U+2))*(H+(2*Real.sqrt U+2))*(b+(2*Real.sqrt U+2))/l := by
        rw [show b+1+2*Real.sqrt U+1 = b+(2*Real.sqrt U+2) by ring]
        apply div_le_div_of_nonneg_right _ hl.le
        apply mul_le_mul_of_nonneg_right _ (by positivity)
        exact mul_le_mul (mul_le_mul_of_nonneg_left (by linarith : b+1≤b+(2*Real.sqrt U+2)) (by norm_num))
          (by linarith : H+2*Real.sqrt U+1≤H+(2*Real.sqrt U+2)) (by positivity) (by positivity)
      _ = _ := by ring
  have hb2 : 1024*(b+1+2*Real.sqrt U+1)*(H+1+2*Real.sqrt U+1)/r = 1024*(b+p)*(H+p)/r := by dsimp [p,bridgeBarrierPadding]; ring
  have hi : 1/d ≤ bridgeDensityConstant U*Real.sqrt n :=
    bridge_density_inverse_le (n : ℝ) _ U (by exact_mod_cast hn) he.1 he.2
  have ht := W.bridge_contact_bound_with_density h k hk hr H b hH hb
  change _ ≤ (ENNReal.ofReal _*ENNReal.ofReal _)/ENNReal.ofReal d at ht
  rw [← ENNReal.ofReal_mul hc1,← ENNReal.ofReal_div_of_pos hd] at ht
  refine ht.trans (ENNReal.ofReal_le_ofReal ?_)
  change ((1024*(b+1)*(H+2*Real.sqrt U+1)*(b+1+2*Real.sqrt U+1)/l)*
      (1024*(b+1+2*Real.sqrt U+1)*(H+1+2*Real.sqrt U+1)/r))/d ≤ _
  rw [hb2,div_eq_mul_one_div]
  calc
    _ ≤ ((1024*(H+p)*(b+p)^2/l)*(1024*(b+p)*(H+p)/r))*(bridgeDensityConstant U*Real.sqrt n) := by
      apply mul_le_mul
      · exact mul_le_mul_of_nonneg_right hb1 (by positivity)
      · exact hi
      · positivity
      · positivity
    _ = _ := by dsimp only [bridgeContactCoefficient,p,l,r]; ring

end GaussianClockPath
end TorusCoverTime.Blocks.B
