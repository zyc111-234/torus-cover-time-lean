import Solutions.Blocks.B.DiscreteFourier
import Solutions.Blocks.B.PoissonCount

/-! Independence of the holding-time and direction data in every finite walk prefix. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter
open scoped BigOperators ENNReal Topology

namespace TorusCoverTime.Blocks.B

lemma step_prefix_law (m : ℕ) :
    walkLaw.map (fun ω : WalkSample => fun j : Fin m => ω j.val) =
      Measure.pi (fun _ : Fin m => stepLaw) := by
  have h := (iIndepFun_infinitePi (P := fun _ : ℕ => stepLaw)
    (X := fun _ => id) (fun _ => measurable_id)).precomp
      (show Function.Injective (fun j : Fin m => j.val) from Fin.val_injective)
  have hmap := h.map_fun_eq_pi_map (fun j => (measurable_pi_apply j.val).aemeasurable)
  simpa only [walkLaw, id_eq, Measure.infinitePi_map_eval] using hmap

lemma holding_direction_prefix_law (m : ℕ) :
    walkLaw.map (fun ω : WalkSample =>
      ((fun j : Fin m => (ω j.val).1), (fun j : Fin m => (ω j.val).2))) =
      (Measure.pi (fun _ : Fin m => holdingLaw)).prod
        (Measure.pi (fun _ : Fin m => uniformOn (Set.univ : Set (Fin 4)))) := by
  let split := MeasurableEquiv.arrowProdEquivProdArrow ℝ (Fin 4) (Fin m)
  have heq : (fun ω : WalkSample =>
      ((fun j : Fin m => (ω j.val).1), (fun j : Fin m => (ω j.val).2))) =
      split ∘ (fun ω : WalkSample => fun j : Fin m => ω j.val) := rfl
  rw [heq, ← Measure.map_map split.measurable (by fun_prop), step_prefix_law]
  exact (measurePreserving_arrowProdEquivProdArrow ℝ (Fin 4) (Fin m)
    (fun _ => holdingLaw) (fun _ => uniformOn (Set.univ : Set (Fin 4)))).map_eq

lemma holding_direction_prefix_independent (m : ℕ) :
    IndepFun (fun ω : WalkSample => fun j : Fin m => (ω j.val).1)
      (fun ω : WalkSample => fun j : Fin m => (ω j.val).2) walkLaw := by
  let H := fun ω : WalkSample => fun j : Fin m => (ω j.val).1
  let D := fun ω : WalkSample => fun j : Fin m => (ω j.val).2
  have hH : Measurable H := by fun_prop
  have hD : Measurable D := by fun_prop
  have hmap := holding_direction_prefix_law m
  have hmapH : walkLaw.map H = Measure.pi (fun _ : Fin m => holdingLaw) := by
    have h := congrArg (fun μ : Measure ((Fin m → ℝ) × (Fin m → Fin 4)) => μ.map Prod.fst) hmap
    rw [Measure.map_map measurable_fst (hH.prodMk hD), Measure.map_fst_prod] at h
    simpa only [Function.comp_def, measure_univ, one_smul] using h
  have hmapD : walkLaw.map D =
      Measure.pi (fun _ : Fin m => uniformOn (Set.univ : Set (Fin 4))) := by
    have h := congrArg (fun μ : Measure ((Fin m → ℝ) × (Fin m → Fin 4)) => μ.map Prod.snd) hmap
    rw [Measure.map_map measurable_snd (hH.prodMk hD), Measure.map_snd_prod] at h
    simpa only [Function.comp_def, measure_univ, one_smul] using h
  apply (indepFun_iff_map_prod_eq_prod_map_map hH.aemeasurable hD.aemeasurable).mpr
  rw [hmapH, hmapD]
  exact hmap

end TorusCoverTime.Blocks.B
