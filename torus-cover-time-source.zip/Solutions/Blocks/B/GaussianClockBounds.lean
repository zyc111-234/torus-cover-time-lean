import Solutions.Blocks.B.GaussianClockBallot

/-! Uniform clock hypotheses and their preservation under contiguous
subsegments and reversal. These bounds describe variances, not probabilities. -/

noncomputable section
open MeasureTheory ProbabilityTheory
open scoped ENNReal NNReal
namespace TorusCoverTime.Blocks.B.GaussianClockPath
variable {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
variable {n : ℕ} (W : GaussianClockPath μ n)

structure ClockBounds (U : ℝ) : Prop where
  lower : ∀ i j, i ≤ j → (j.val : ℝ) - i.val ≤ W.clock j - W.clock i
  upper : ∀ i j, i ≤ j → W.clock j - W.clock i ≤ U * ((j.val : ℝ) - i.val)

theorem rev_index_gap (i j : Fin (n + 1)) :
    (i.rev.val : ℝ) - j.rev.val = (j.val : ℝ) - i.val := by
  simp only [Fin.val_rev, Nat.succ_sub_succ_eq_sub]
  rw [Nat.cast_sub (Nat.le_of_lt_succ i.isLt), Nat.cast_sub (Nat.le_of_lt_succ j.isLt)]
  ring

theorem ClockBounds.reverse {U : ℝ} (h : W.ClockBounds U) : W.reverse.ClockBounds U := by
  constructor
  · intro i j hij
    have hh := h.lower j.rev i.rev (Fin.rev_le_rev.mpr hij)
    rw [rev_index_gap] at hh
    change (j.val : ℝ) - i.val ≤ (W.clock (Fin.last n) - W.clock j.rev) -
      (W.clock (Fin.last n) - W.clock i.rev)
    linarith
  · intro i j hij
    have hh := h.upper j.rev i.rev (Fin.rev_le_rev.mpr hij)
    rw [rev_index_gap] at hh
    change (W.clock (Fin.last n) - W.clock j.rev) - (W.clock (Fin.last n) - W.clock i.rev) ≤ _
    linarith

theorem ClockBounds.segment {U : ℝ} (h : W.ClockBounds U) {m : ℕ}
    (f : Fin (m + 1) → Fin (n + 1)) (hf : Monotone f)
    (hindex : ∀ i j, ((f j).val : ℝ) - (f i).val = (j.val : ℝ) - i.val) :
    (W.segment f hf).ClockBounds U := by
  constructor
  · intro i j hij
    have hh := h.lower (f i) (f j) (hf hij)
    rw [hindex] at hh
    change (j.val : ℝ) - i.val ≤ (W.clock (f j) - W.clock (f 0)) - (W.clock (f i) - W.clock (f 0))
    linarith
  · intro i j hij
    have hh := h.upper (f i) (f j) (hf hij)
    rw [hindex] at hh
    change (W.clock (f j) - W.clock (f 0)) - (W.clock (f i) - W.clock (f 0)) ≤ _
    linarith

theorem bounded_survival_le {U : ℝ} (h : W.ClockBounds U)
    (a : ℝ) (ha : 0 ≤ a) (i : Fin (n + 1)) (hi : 0 < i.val) :
    μ (W.survival a i) ≤ ENNReal.ofReal (8 * (a + 2 * Real.sqrt U + 1) / Real.sqrt (i.val : ℝ)) := by
  apply W.survival_probability_le (2 * Real.sqrt U) (by positivity) h.lower
    (fun k => ?_) a ha i hi
  apply mul_le_mul_of_nonneg_left (Real.sqrt_le_sqrt ?_) (by norm_num)
  have hh := h.upper k.castSucc k.succ (by change k.val ≤ k.val + 1; omega)
  simpa only [Fin.val_succ, Fin.val_castSucc, Nat.cast_add, Nat.cast_one, add_sub_cancel_left, mul_one] using hh

def prefixIndex (k : Fin (n + 1)) (i : Fin (k.val + 1)) : Fin (n + 1) :=
  ⟨i.val, (Nat.le_of_lt_succ i.isLt).trans_lt k.isLt⟩

theorem prefixIndex_mono (k : Fin (n + 1)) : Monotone (prefixIndex k) :=
  fun _ _ hij => hij

def suffixIndex (k : Fin (n + 1)) (i : Fin (n - k.val + 1)) : Fin (n + 1) :=
  ⟨k.val + i.val, by have := i.isLt; have := k.isLt; omega⟩

theorem suffixIndex_mono (k : Fin (n + 1)) : Monotone (suffixIndex k) :=
  fun _ _ hij => Nat.add_le_add_left hij _

def prefixPath (k : Fin (n + 1)) : GaussianClockPath μ k.val := W.segment (prefixIndex k) (prefixIndex_mono k)

def suffix (k : Fin (n + 1)) : GaussianClockPath μ (n - k.val) := W.segment (suffixIndex k) (suffixIndex_mono k)

theorem ClockBounds.prefixPath {U : ℝ} (h : W.ClockBounds U) (k : Fin (n + 1)) :
    (W.prefixPath k).ClockBounds U :=
  ClockBounds.segment (W := W) h (prefixIndex k) (prefixIndex_mono k) (fun _ _ => rfl)

theorem ClockBounds.suffix {U : ℝ} (h : W.ClockBounds U) (k : Fin (n + 1)) :
    (W.suffix k).ClockBounds U := by
  apply ClockBounds.segment (W := W) h (suffixIndex k) (suffixIndex_mono k)
  intro i j
  dsimp [suffixIndex]
  push_cast
  ring

end TorusCoverTime.Blocks.B.GaussianClockPath
