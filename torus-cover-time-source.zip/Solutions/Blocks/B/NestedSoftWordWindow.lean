import Solutions.Blocks.B.ExteriorCountHarmonicTest
import Solutions.Blocks.B.ExteriorPhysicalTransfer

/-! First R8 resampling for actual outer counts and harmonic deviations; all exterior identities are proved. -/
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B


theorem r8_nested_soft_word_window (hWalk : WalkModelRegular) (γ U : ℝ)
    (hγ : 0 < γ) (hγ1 : γ < 1) (hU : 0 ≤ U) :
    ∀ᶠ N : Size in atTop, ∀ c root : Vertex N, ∀ m : ℕ, ∀ w : Fin (2*m) → Vertex N, ∀ q : ℝ,
      2*(logSize N)^(16*γ) ≤ q → q ≤ logSize N-2*(logSize N)^(16*γ) →
      (m:ℝ) ≤ (logSize N)^4+1 → root ∉ torusDisk N c (Real.exp (q+2*q^γ)) →
      walkLaw {ω | adaptiveExitWord N (alternatingDomain N
        (torusDisk N c (Real.exp (r8NestedScale γ q+(r8NestedScale γ q)^γ)))
        (torusDisk N c (Real.exp (r8NestedScale γ q+2*(r8NestedScale γ q)^γ)))) root (2*m) ω = w} ≠ 0 →
      ∀ k : ℕ, ∀ v Δ l r : ℝ,
      let I := torusDisk N c (Real.exp (r8NestedScale γ q+(r8NestedScale γ q)^γ))
      let J := torusDisk N c (Real.exp (r8NestedScale γ q+2*(r8NestedScale γ q)^γ))
      let Q := torusDisk N c (Real.exp (q+q^γ))
      let O := torusDisk N c (Real.exp (q+2*q^γ))
      let F := outerCountHarmonicTest N Q O c root k q v Δ
      let d := (m:ℝ)*Real.exp (2*logSize N-(logSize N)^(16*γ))
      physicalWordWindow N I J root m w (fun z => if localTime N root z.1 z.2 c/g ≤ U then F z else 0) l r ≤
        2*ENNReal.ofReal (r8SoftLaplaceEnvelope (r8NestedScale γ q) γ U m)*
          physicalWordWindow N I J root m w F (l-d) (r+d) +
        ENNReal.ofReal (r-l)*ENNReal.ofReal (Real.exp (-Real.exp ((logSize N)^(16*γ)/2))) := by
  filter_upwards [r8_nested_coarse_range γ hγ hγ1,r8_physical_soft_exterior_window hWalk γ U hγ hγ1 hU]
    with N hgeom hsoft
  intro c root m w q hq hqL hm hr hw k v Δ l r
  dsimp only
  have hs := hgeom q hq hqL
  have hQ0 := Real.rpow_nonneg (logSize_pos N).le (16*γ)
  have hl0 := hQ0.trans hs.1
  have hq0 : 0 ≤ q := by linarith
  have hi := r8_nested_disk_inclusions N c γ q hq0 hl0 hs.2.2.2.2
  have hrJ : root ∉ torusDisk N c (Real.exp (r8NestedScale γ q+2*(r8NestedScale γ q)^γ)) :=
    fun h => hr (hi.2.2 (hi.2.1 h))
  let E := exteriorCountHarmonicTest N (torusDisk N c (Real.exp (q+q^γ)))
    (torusDisk N c (Real.exp (q+2*q^γ))) c root m w k q v Δ
  have hrep := exteriorCountHarmonicTest_actual N _ _ _ _ hi.1 (torusDisk_nonempty N c _ (Real.exp_pos _))
    hi.2.1 hi.2.2 c root
    ((mem_torusDisk N c c _).mpr (by rw [periodicDistance_self_zero]; positivity)) hr m w k q v Δ
    (nested_harmonic_potential_zero N c γ q hs.2.2.2.2)
  rw [physicalWordWindow_soft_eq_exterior N _ _ c root m w U _ E hrep l r,
    physicalWordWindow_eq_exterior N _ _ root m w _ E hrep]
  exact hsoft c root m w (r8NestedScale γ q) hs.1 hs.2.1 hm hrJ hw E
    (exteriorCountHarmonicTest_measurable N _ _ c root m w k q v Δ)
    (fun y u => exteriorCountHarmonicTest_le_one N _ _ c root m w k q v Δ (y,u)) l r


end TorusCoverTime.Blocks.B

