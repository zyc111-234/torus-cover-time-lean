import Solutions.Blocks.B.CenteredPhysicalWordWindow
import Solutions.Blocks.B.WordWindowMixture

/-! The actual full-threshold harmonic deviation after averaging endpoint words. -/
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B


theorem r8_centered_count_window (hWalk : WalkModelRegular) (γ : ℝ) (hγ : 0 < γ) (hγ1 : γ ≤ 1) :
    ∀ᶠ N : Size in atTop, ∀ c root : Vertex N, ∀ m : ℕ, ∀ q : ℝ,
      (logSize N)^(16*γ) ≤ q → q ≤ logSize N-(logSize N)^(16*γ) →
      root ∉ torusDisk N c (Real.exp (q+2*q^γ)) →
      q ≤ Real.sqrt ((m:ℝ)*q^γ) → Real.sqrt ((m:ℝ)*q^γ) ≤ 10*logSize N → ∀ l r : ℝ,
      let I := torusDisk N c (Real.exp (q+q^γ))
      let O := torusDisk N c (Real.exp (q+2*q^γ))
      let d := (m:ℝ)*Real.exp (2*logSize N-(logSize N)^(16*γ))
      physicalCountWindow N I O root m (fun z =>
        if (logSize N)^(4*γ) < |Real.sqrt (harmonicPathOccupation N c root q z)-Real.sqrt ((m:ℝ)*q^γ)|
          then 1 else 0) l r ≤
        2*ENNReal.ofReal (2*Real.exp (-(r7ConcentrationConstant/16)*(logSize N)^(7*γ)))*
          physicalCountWindow N I O root m (fun _ => 1) (l-d) (r+d) +
        ENNReal.ofReal (r-l)*ENNReal.ofReal (Real.exp (-Real.exp ((logSize N)^(16*γ)/2))) := by
  filter_upwards [r8_centered_physical_word_window hWalk γ hγ hγ1] with N hN
  intro c root m q hq hqL hr hv hvL l r
  have hq0 := (Real.rpow_nonneg (logSize_pos N).le (16*γ)).trans hq
  have hIO := torusDisk_subset N c (Real.exp (q+q^γ)) (Real.exp (q+2*q^γ))
    (Real.exp_le_exp.mpr (by linarith [Real.rpow_nonneg hq0 γ]))
  apply physicalCountWindow_of_word_bound N _ _ hIO (torusDisk_nonempty N c _ (Real.exp_pos _)) root hr m
  intro w hw
  have hb := hN c root m w q hq hqL hr hw hv hvL l r
  apply le_trans (physicalWordWindow_mono N _ _ root m w _ _ ?_ l r) hb
  intro z
  split_ifs with h hhalf hhalf
  · rfl
  · exact False.elim (hhalf (by linarith [Real.rpow_nonneg (logSize_pos N).le (4*γ)]))
  · exact bot_le
  · rfl


end TorusCoverTime.Blocks.B
