import Solutions.Blocks.B.PeriodicAbel

/-! Support counting for finite periodic differences; constants depend only on the order. -/

noncomputable section
open Classical
open scoped BigOperators
namespace TorusCoverTime.Blocks.B

def frequencySupport (N : Size) (a : Vertex N → ℂ) : Finset (Vertex N) :=
  Finset.univ.filter fun k => a k ≠ 0

lemma mem_frequencySupport (N : Size) (a : Vertex N → ℂ) (k : Vertex N) :
    k ∈ frequencySupport N a ↔ a k ≠ 0 := by simp [frequencySupport]

lemma frequencySupport_difference_card (N : Size) (e : Vertex N) (a : Vertex N → ℂ) :
    (frequencySupport N (frequencyDifference N e a)).card ≤ 2 * (frequencySupport N a).card := by
  have hs : frequencySupport N (frequencyDifference N e a) ⊆
      (frequencySupport N a).image (fun k => k - e) ∪ frequencySupport N a := by
    intro k hk
    rw [mem_frequencySupport] at hk
    by_cases hz : a k = 0
    · apply Finset.mem_union_left
      apply Finset.mem_image.mpr
      refine ⟨k + e, (mem_frequencySupport N a _).mpr ?_, by abel⟩
      simpa [frequencyDifference, hz] using hk
    · exact Finset.mem_union_right _ ((mem_frequencySupport N a k).mpr hz)
  calc
    _ ≤ ((frequencySupport N a).image (fun k => k - e) ∪ frequencySupport N a).card :=
      Finset.card_le_card hs
    _ ≤ ((frequencySupport N a).image (fun k => k - e)).card + (frequencySupport N a).card :=
      Finset.card_union_le _ _
    _ ≤ (frequencySupport N a).card + (frequencySupport N a).card :=
      Nat.add_le_add_right (Finset.card_image_le) _
    _ = _ := by omega

lemma frequencySupport_iterate_card (N : Size) (e : Vertex N) (a : Vertex N → ℂ) (p : ℕ) :
    (frequencySupport N ((frequencyDifference N e)^[p] a)).card ≤
      2 ^ p * (frequencySupport N a).card := by
  induction p with
  | zero => simp
  | succ p ih =>
    rw [Function.iterate_succ_apply']
    exact (frequencySupport_difference_card N e _).trans (by
      calc
        _ ≤ 2 * (2 ^ p * (frequencySupport N a).card) := Nat.mul_le_mul_left 2 ih
        _ = _ := by rw [pow_succ]; ring)

lemma sum_norm_le_support_card (N : Size) (a : Vertex N → ℂ) (C : ℝ)
    (hC : ∀ k, ‖a k‖ ≤ C) :
    (∑ k : Vertex N, ‖a k‖) ≤ (frequencySupport N a).card * C := by
  have hs : (∑ k ∈ frequencySupport N a, ‖a k‖) = ∑ k : Vertex N, ‖a k‖ := by
    apply Finset.sum_subset (Finset.subset_univ _)
    intro k _ hk
    have hz : a k = 0 := by simpa only [mem_frequencySupport, not_not] using hk
    simp [hz]
  rw [← hs]
  calc
    _ ≤ ∑ _k ∈ frequencySupport N a, C := Finset.sum_le_sum fun k _ => hC k
    _ = _ := by simp

end TorusCoverTime.Blocks.B
