import Solutions.Blocks.B.BT8ShellEnvelope

noncomputable section
open MeasureTheory Filter Set Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

theorem bt8_envelope_mean (N : Size) (γ ε C₀ : ℝ) :
    twoSignEnvelopeMean N (fun z => ENNReal.ofReal (bt7BadCount N γ ε C₀ 4 z.1))=
      2*ENNReal.ofReal (∫ ξ, bt7BadCount N γ ε C₀ 4 ξ ∂finiteFieldLaw N) := by
  unfold twoSignEnvelopeMean
  rw [lintegral_add_left (bt7BadCount_measurable N γ ε C₀ 4).ennreal_ofReal,
    ← ofReal_integral_eq_lintegral_ofReal (bt7BadCount_integrable N γ ε C₀ 4)
      (Eventually.of_forall (fun ξ => (bt7BadCount_bounds N γ ε C₀ 4 ξ).1))]
  exact (two_mul _).symm

theorem bt8_shell_count_limit (γ u H : ℝ) (hγ : 0<γ) (hmargin : 160*γ<1/20) (hH : 0≤H) :
    Tendsto (fun N => shellCountWindow N H (fun _ => bt8ShellTest N γ u)) atTop (𝓝 0) := by
  let C₀ := bt8CenterConstant H u
  have hC₀ : 0≤C₀ := bt8CenterConstant_nonneg H u hH
  have hcenter : Real.sqrt (2*u+1)/Real.sqrt (2*g)≤C₀ := by
    dsimp [C₀,bt8CenterConstant]
    linarith [bt8ShellCenterError_nonneg H hH]
  obtain ⟨ε,hε,hlim⟩ := bt7_conclusion γ C₀ 4 hγ hmargin hC₀ (by norm_num)
  let δ := ε*Real.sqrt (2*g)
  have hδ : 0<δ := by dsimp [δ]; positivity [coarseProbe_g_pos]
  let M := fun (N : Size) (z : FiniteFieldSample N × Bool) => ENNReal.ofReal (bt7BadCount N γ ε C₀ 4 z.1)
  have hM (N : Size) : Measurable (M N) := ((bt7BadCount_measurable N γ ε C₀ 4).comp measurable_fst).ennreal_ofReal
  have hmean : Tendsto (fun N => twoSignEnvelopeMean N (M N)) atTop (𝓝 0) := by
    simp_rw [show ∀ N, twoSignEnvelopeMean N (M N)=
      2*ENNReal.ofReal (∫ ξ, bt7BadCount N γ ε C₀ 4 ξ ∂finiteFieldLaw N) from fun N => bt8_envelope_mean N γ ε C₀]
    have ht := ENNReal.Tendsto.const_mul (ENNReal.tendsto_ofReal hlim)
      (a := (2:ℝ≥0∞)) (Or.inr (by norm_num : (2:ℝ≥0∞)≠∞))
    simpa only [ENNReal.ofReal_zero,mul_zero] using ht
  obtain ⟨c,C,hc,hC,htransfer⟩ := D.energy_shell_count_transfer H hH δ hδ
  have hbound : ∀ᶠ N : Size in atTop,
      shellCountWindow N H (fun _ => bt8ShellTest N γ u)≤
        ENNReal.ofReal C*twoSignEnvelopeMean N (M N)+
          ENNReal.ofReal (C*vertexCount N*logSize N^2*Real.exp (-c*δ*logSize N*Real.log (logSize N))) := by
    filter_upwards [htransfer,bt8_amplitude_window H u ε hH] with N ht ha
    apply iSup_le
    intro θ
    exact (ht θ.1 θ.2).2.2 (bt8ShellTest N γ u) (bt8ShellTest_measurable N γ u) (bt8ShellTest_le N γ u)
      (M N) (hM N) (fun ξ a σ hband => bt8_shell_envelope N γ u ε C₀ a ξ σ (ha θ.1 a θ.2 hband) hcenter)
  have hmain : Tendsto (fun N => ENNReal.ofReal C*twoSignEnvelopeMean N (M N)) atTop (𝓝 0) := by
    simpa only [mul_zero] using ENNReal.Tendsto.const_mul hmean (Or.inr ENNReal.ofReal_ne_top)
  have herr := D.energy_shell_remainder_ofReal_tendsto c C δ hc hδ
  exact tendsto_of_tendsto_of_tendsto_of_le_of_le' tendsto_const_nhds
    (by simpa only [zero_add] using hmain.add herr) (Eventually.of_forall (fun _ => bot_le)) hbound

end TorusCoverTime.Blocks.B
