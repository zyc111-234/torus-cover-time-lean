import Solutions.Blocks.B.ExitGreenOccupation
import Solutions.Blocks.B.ExitOccupationLaplace
import Solutions.Blocks.B.DiskHarmonicMeasure
import Solutions.Blocks.B.R6OscillationRate

/-! The actual R7 harmonic occupation and its exact specified-exit Green
expectation. The exit-conditioning error has the R6.5 exponential rate.
The sharper centering of the remaining unconditioned Green value is a
separate obligation, not asserted by the bounded-error corollary here. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

def harmonicExitOccupation (N : Size) (c : Vertex N) (r R : ℝ) (a : Vertex N) (ω : WalkSample) : ℝ :=
  ∑ z, (diskHarmonicWeight N c r z/g)*localTime N a ω (finiteExitDuration N (torusDisk N c R) a ω) z

theorem harmonicExitOccupation_nonneg (N : Size) (c : Vertex N) (r R : ℝ) (a : Vertex N)
    (ω : WalkSample) : 0 ≤ harmonicExitOccupation N c r R a ω :=
  Finset.sum_nonneg fun z _ => mul_nonneg
    (div_nonneg (diskHarmonicWeight_nonneg N c r z) (by unfold g; positivity)) (localTime_nonneg N a z ω _)

theorem harmonicExitOccupation_integrable (hWalk : WalkModelRegular) (N : Size) (c : Vertex N)
    (r R : ℝ) (hR : 0 ≤ R) (hsmall : 2*(R+1) < N.val) (a b : Vertex N) :
    Integrable (harmonicExitOccupation N c r R a) (exactExitLaw N (torusDisk N c R) a b) :=
  disk_conditioned_occupation_integrable hWalk N c R hR hsmall a b
    (fun z => diskHarmonicWeight N c r z/g)
    (fun z => div_nonneg (diskHarmonicWeight_nonneg N c r z) (by unfold g; positivity))

theorem harmonicExitOccupation_mean (hWalk : WalkModelRegular) (N : Size) (c : Vertex N)
    (r R : ℝ) (hR : 0 ≤ R) (hsmall : 2*(R+1) < N.val) (a b : Vertex N) :
    (∫ ω, harmonicExitOccupation N c r R a ω ∂exactExitLaw N (torusDisk N c R) a b) =
      ∑ z, (diskHarmonicWeight N c r z*diskGreen N c R a z/g)*
        (exitHarmonic N (torusDisk N c R) b z/exitHarmonic N (torusDisk N c R) b a) := by
  rw [show harmonicExitOccupation N c r R a =
      (fun ω => ∑ z, (diskHarmonicWeight N c r z/g)*
        localTime N a ω (finiteExitDuration N (torusDisk N c R) a ω) z) from rfl,
    disk_conditioned_occupation_green hWalk N c R hR hsmall a b _
      (fun z => div_nonneg (diskHarmonicWeight_nonneg N c r z) (by unfold g; positivity)),
    Finset.sum_div]
  apply Finset.sum_congr rfl
  intro z _
  ring

theorem harmonicExitOccupation_mean_error (hWalk : WalkModelRegular) (N : Size) (c : Vertex N)
    (r R : ℝ) (hr : 0 ≤ r) (hrR : r ≤ R) (hsmall : 2*(R+1) < N.val)
    (a b : Vertex N) (ha : a ∉ torusDisk N c r) (ε : ℝ) (hε : 0 ≤ ε)
    (hratio : ∀ z, diskHarmonicWeight N c r z ≠ 0 →
      |exitHarmonic N (torusDisk N c R) b z/exitHarmonic N (torusDisk N c R) b a-1| ≤ ε) :
    |(∫ ω, harmonicExitOccupation N c r R a ω ∂exactExitLaw N (torusDisk N c R) a b)-
        diskGreen N c R a c/g| ≤ ε*(diskGreen N c R a c/g) := by
  have hR := hr.trans hrR
  let v := fun z => diskHarmonicWeight N c r z*diskGreen N c R a z/g
  have hv : ∀ z, 0 ≤ v z := fun z => div_nonneg (mul_nonneg
    (diskHarmonicWeight_nonneg N c r z) (diskGreen_nonneg N c R hR hsmall a z)) (by unfold g; positivity)
  have hsum : (∑ z, v z) = diskGreen N c R a c/g := by
    rw [← Finset.sum_div, diskHarmonicWeight_green_average_outside N c r R hr hrR hsmall a ha]
  rw [harmonicExitOccupation_mean hWalk N c r R hR hsmall a b, ← hsum, ← Finset.sum_sub_distrib]
  apply (Finset.abs_sum_le_sum_abs _ _).trans
  calc
    _ ≤ ∑ z, ε*v z := by
      apply Finset.sum_le_sum
      intro z _
      change |v z*(exitHarmonic N (torusDisk N c R) b z/exitHarmonic N (torusDisk N c R) b a)-v z| ≤ _
      by_cases hz : diskHarmonicWeight N c r z = 0
      · simp [v, hz]
      · rw [← mul_sub_one, abs_mul, abs_of_nonneg (hv z)]
        exact (mul_le_mul_of_nonneg_left (hratio z hz) (hv z)).trans_eq (mul_comm _ _)
    _ = _ := (Finset.mul_sum ..).symm

theorem r7_probe_geometry (γ : ℝ) (hγ : 0 < γ) :
    ∀ᶠ q : ℝ in atTop, ∀ N : Size, ∀ c a : Vertex N,
      |periodicDistance a c-Real.exp (q+q^γ)| ≤ 2 →
      Real.exp (q+1) ≤ Real.exp (q+2*q^γ) ∧
      a ∉ torusDisk N c (Real.exp (q+1)) ∧
      a ∈ torusDisk N c (2*Real.exp (q+q^γ)) ∧
      ∀ z, diskHarmonicWeight N c (Real.exp (q+1)) z ≠ 0 →
        z ∈ torusDisk N c (2*Real.exp (q+q^γ)) := by
  filter_upwards [eventually_ge_atTop (1:ℝ),
    (tendsto_rpow_atTop hγ).eventually_ge_atTop (1+Real.log 4)] with q hq hw
  intro N c a ha
  have hw1 : 1 ≤ q^γ := by linarith [Real.log_nonneg (by norm_num : (1:ℝ)≤4)]
  have hr1 : 1 ≤ Real.exp (q+1) := Real.one_le_exp_iff.mpr (by linarith)
  have he : 4 ≤ Real.exp (q^γ-1) := by
    have hh := Real.exp_le_exp.mpr (show Real.log 4 ≤ q^γ-1 by linarith)
    simpa only [Real.exp_log (by norm_num : (0:ℝ)<4)] using hh
  have hρ : 4*Real.exp (q+1) ≤ Real.exp (q+q^γ) := by
    rw [show q+q^γ = (q+1)+(q^γ-1) by ring, Real.exp_add (q+1) (q^γ-1)]
    nlinarith [Real.exp_pos (q+1)]
  have hab := abs_le.mp ha
  refine ⟨Real.exp_le_exp.mpr (by linarith), ?_, ?_, ?_⟩
  · intro haI
    have hd := (mem_torusDisk N c a _).mp haI
    linarith
  · exact (mem_torusDisk N c a _).mpr (by linarith)
  · intro z hz
    have hd := (diskExteriorNeighbor_radius N c _ z
      (diskHarmonicWeight_support N c _ (Real.exp_pos _) z hz)).2
    exact (mem_torusDisk N c z _).mpr (by linarith)

theorem r7_mean_conditioning_error (hWalk : WalkModelRegular) (γ : ℝ) (hγ : 0 < γ) :
    ∀ᶠ q : ℝ in atTop, ∀ N : Size, ∀ c a b : Vertex N,
      2*(Real.exp (q+2*q^γ)+1) < N.val →
      |periodicDistance a c-Real.exp (q+q^γ)| ≤ 2 →
      diskExteriorNeighbor N c (Real.exp (q+2*q^γ)) b →
      |(∫ ω, harmonicExitOccupation N c (Real.exp (q+1)) (Real.exp (q+2*q^γ)) a ω
        ∂exactExitLaw N (torusDisk N c (Real.exp (q+2*q^γ))) a b)-
        diskGreen N c (Real.exp (q+2*q^γ)) a c/g| ≤
        diskExitOscillationConstant*Real.exp (-diskExitOscillationExponent*q^γ)*
          (diskGreen N c (Real.exp (q+2*q^γ)) a c/g) := by
  filter_upwards [r7_probe_geometry γ hγ, r6_exit_ratio_exponential γ hγ] with q hgeom hrat
  intro N c a b hsmall ha hb
  obtain ⟨hrR,haI,haP,hzP⟩ := hgeom N c a ha
  exact harmonicExitOccupation_mean_error hWalk N c _ _ (Real.exp_pos _).le hrR hsmall a b haI
    _ (mul_nonneg diskExitOscillationConstant_pos.le (Real.exp_pos _).le)
    (fun z hz => hrat N c b z a hsmall hb (hzP z hz) haP)

end TorusCoverTime.Blocks.B
