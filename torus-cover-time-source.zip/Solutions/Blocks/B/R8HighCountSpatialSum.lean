import Solutions.Blocks.B.R8HighCountWindow

/-! Both spatial multiplicities are included: first the roots and then
the possible soft centers. A fixed prefix has enough exponential gain. -/
noncomputable section
open MeasureTheory Filter Set Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

theorem r8_high_count_spatial_sum (hWalk : WalkModelRegular) (γ U H : ℝ)
    (hγ : 0 < γ) (hγ1 : γ < 1) (hU : 0 ≤ U) (hH : 0 ≤ H) :
    ∀ᶠ N : Size in atTop, ∀ q l r : ℝ,
      (logSize N)^(16*γ) ≤ q → q ≤ logSize N-(logSize N)^(16*γ) →
      r-l ≤ 2*H*timeScale N →
      (∑ c : Vertex N, r8HighCountWindowMass N c γ q U l r) ≤
        ENNReal.ofReal (2*H*Real.exp (-36*logSize N)) := by
  filter_upwards [r8_high_count_window_bound hWalk γ U hγ hγ1 hU] with N hN
  intro q l r hq hqL hlen
  have hr : vertexCount N*(r-l)/timeScale N ≤ 2*H*vertexCount N := by
    apply (div_le_iff₀ (timeScale_pos N)).mpr
    nlinarith [mul_le_mul_of_nonneg_left hlen (vertexCount_pos N).le]
  calc
    _ ≤ ∑ _c : Vertex N, ENNReal.ofReal (2*H*vertexCount N)*ENNReal.ofReal (Real.exp (-40*logSize N)) := by
      apply Finset.sum_le_sum
      intro c _
      exact (hN c q hq hqL l r).trans (mul_le_mul' (ENNReal.ofReal_le_ofReal hr) le_rfl)
    _ = _ := by
      rw [Finset.sum_const,Finset.card_univ,nsmul_eq_mul]
      rw [show (Fintype.card (Vertex N):ℝ≥0∞) = ENNReal.ofReal (vertexCount N) by rw [D.vertexCount_eq_card,ENNReal.ofReal_natCast]]
      rw [← mul_assoc,← ENNReal.ofReal_mul (vertexCount_pos N).le,
        ← ENNReal.ofReal_mul (mul_nonneg (vertexCount_pos N).le (mul_nonneg (mul_nonneg (by norm_num) hH) (vertexCount_pos N).le))]
      congr 1
      rw [D.vertexCount_eq_exp_two_logSize]
      calc
        _ = 2*H*(Real.exp (2*logSize N)*Real.exp (2*logSize N)*Real.exp (-40*logSize N)) := by ring
        _ = _ := by rw [← Real.exp_add,← Real.exp_add]; congr 2; ring

end TorusCoverTime.Blocks.B
