import Solutions.Blocks.B.DirichletHarmonicBridge

/-! Exact weighted-square decomposition for the original exit measure.  The
weights are probabilities; this identity is valid sample by sample and keeps
the amplitude as a free parameter. -/

noncomputable section
open Classical
open scoped BigOperators
namespace TorusCoverTime.Blocks.B

theorem weighted_square_residual {I : Type*} [Fintype I] (w f : I → ℝ)
    (hw : ∑ i, w i = 1) (a : ℝ) :
    (∑ i, w i * (f i - a)^2) =
      ((∑ i, w i * f i) - a)^2 + ∑ i, w i * (f i - ∑ j, w j * f j)^2 := by
  let M := ∑ i, w i * f i
  have he (c : ℝ) : (∑ i, w i * (f i - c)^2) =
      (∑ i, w i * f i ^ 2) - 2*c*M + c^2 := by
    simp_rw [show ∀ i, w i * (f i - c)^2 = w i * f i^2 - (2*c)*(w i*f i) + c^2*w i by
      intro i; ring]
    rw [Finset.sum_add_distrib, Finset.sum_sub_distrib, ← Finset.mul_sum, ← Finset.mul_sum, hw, mul_one]
  change _ = (M - a)^2 + ∑ i, w i * (f i - M)^2
  rw [he a, he M]
  ring

theorem dirichlet_exit_square_residual (N : Size) (root : Vertex N)
    (D E : Finset (Vertex N)) (hDE : D ⊆ E) (hroot : root ∉ E)
    (ξ : FiniteFieldSample N) (x : Vertex N) (a : ℝ) :
    let M := Blocks.C.C4.pinnedDomainField N root E ξ x - Blocks.C.C4.pinnedDomainField N root D ξ x
    (∑ z, exitHarmonic N D z x * (Blocks.C.C4.pinnedDomainField N root E ξ z - a)^2) =
      (M-a)^2 + ∑ z, exitHarmonic N D z x * (Blocks.C.C4.pinnedDomainField N root E ξ z - M)^2 := by
  have hD := Blocks.C.C4.domain_proper_of_root_outside N root D (fun h => hroot (hDE h))
  have h := weighted_square_residual (fun z => exitHarmonic N D z x)
    (Blocks.C.C4.pinnedDomainField N root E ξ) (exitHarmonic_sum_one N D hD x) a
  rwa [dirichlet_harmonic_average N root D E hDE hroot] at h

end TorusCoverTime.Blocks.B
