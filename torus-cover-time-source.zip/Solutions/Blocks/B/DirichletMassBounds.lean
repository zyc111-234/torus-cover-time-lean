import Solutions.Blocks.B.DirichletMassRegression
import Solutions.Blocks.B.DiskTorsionBounds
import Solutions.Blocks.B.DiskCardinalityLower

noncomputable section
open Classical
open scoped BigOperators
namespace TorusCoverTime.Blocks.B

theorem dirichletRowMass_disk (N : Size) (root c : Vertex N) (R : ℝ) (hR : 0<R)
    (hsmall : 2*(R+1)<N.val) (hroot : root∉torusDisk N c R) (x : Vertex N) :
    dirichletRowMass N root (torusDisk N c R) x=(∑ z, diskGreen N c R x z)/(2*g) := by
  unfold dirichletRowMass dirichletKernelLS
  have he (z : Vertex N) : Blocks.C.C4.pinnedDomainKernel N root (torusDisk N c R) x z=diskGreen N c R x z :=
    congrFun (Blocks.C.C4.pinnedDomainKernel_eq_diskGreen N root c R hR.le hsmall hroot z) x
  simp_rw [he]
  rw [Finset.sum_div]

theorem dirichletRowMass_disk_bounds (N : Size) (root c : Vertex N) (R : ℝ) (hR : 0<R)
    (hsmall : 2*(R+1)<N.val) (hroot : root∉torusDisk N c R) (x : Vertex N) :
    0≤dirichletRowMass N root (torusDisk N c R) x ∧
      dirichletRowMass N root (torusDisk N c R) x≤(R+1)^2/(2*g) := by
  rw [dirichletRowMass_disk N root c R hR hsmall hroot]
  have hg : 0<g := by unfold g; positivity
  constructor
  · apply div_nonneg _ (by positivity)
    exact Finset.sum_nonneg (fun z _ => diskGreen_nonneg N c R hR.le hsmall x z)
  · exact div_le_div_of_nonneg_right (diskGreen_mass_bound N c R hR.le hsmall x) (by positivity)

theorem dirichletMassVariance_disk_lower (N : Size) (root c : Vertex N) (R : ℝ) (hR : 0<R)
    (hsmall : 2*(R+1)<N.val) (hroot : root∉torusDisk N c R) :
    3*R^4/(128*g)≤dirichletMassVariance N root (torusDisk N c R) := by
  have hg : 0<g := by unfold g; positivity
  have hcard := torusDisk_card_lower N c (R/2) (by positivity) (by linarith)
  have hl (x : Vertex N) (hx : x∈torusDisk N c (R/2)) :
      (3*R^2/4)/(2*g)≤dirichletRowMass N root (torusDisk N c R) x := by
    rw [dirichletRowMass_disk N root c R hR hsmall hroot]
    exact div_le_div_of_nonneg_right
      (diskGreen_mass_deep_lower N c R hR hsmall x ((mem_torusDisk N c x _).mp hx).le) (by positivity)
  have hsum := Finset.sum_le_sum (fun x hx => hl x hx)
  have hsub : (∑ x∈torusDisk N c (R/2), dirichletRowMass N root (torusDisk N c R) x)≤
      dirichletMassVariance N root (torusDisk N c R) := by
    apply Finset.sum_le_sum_of_subset_of_nonneg (Finset.subset_univ _)
    intro x _ _
    exact (dirichletRowMass_disk_bounds N root c R hR hsmall hroot x).1
  have hc := mul_le_mul_of_nonneg_right hcard (show 0≤(3*R^2/4)/(2*g) by positivity)
  simp only [Finset.sum_const,nsmul_eq_mul] at hsum
  calc
    _ = ((R/2)^2/4)*((3*R^2/4)/(2*g)) := by ring
    _ ≤ _ := hc
    _ ≤ _ := hsum.trans hsub

def dirichletMassProfileBound : ℝ := 512/g+1

theorem dirichletMassProfile_disk_bound (N : Size) (root c : Vertex N) (R : ℝ) (hR : 1≤R)
    (hsmall : 2*(R+1)<N.val) (hroot : root∉torusDisk N c R) (x : Vertex N) :
    0≤dirichletMassProfile N root (torusDisk N c R) x ∧
      dirichletMassProfile N root (torusDisk N c R) x≤dirichletMassProfileBound := by
  have hr0 : 0<R := by linarith
  have hg : 0<g := by unfold g; positivity
  let V := dirichletMassVariance N root (torusDisk N c R)
  let u := dirichletRowMass N root (torusDisk N c R) x
  have hu := dirichletRowMass_disk_bounds N root c R hr0 hsmall hroot x
  have hv := dirichletMassVariance_disk_lower N root c R hr0 hsmall hroot
  have hv0 : 0<V := lt_of_lt_of_le (by positivity) hv
  have hu0 : 0≤u := hu.1
  have hu1 : u≤2*R^2/g := by
    have hh : (R+1)^2≤4*R^2 := by nlinarith
    exact hu.2.trans (by apply (div_le_iff₀ (by positivity : 0<2*g)).mpr; field_simp; nlinarith)
  have hsq : (u/Real.sqrt V)^2≤512/g := by
    rw [div_pow,Real.sq_sqrt hv0.le]
    apply (div_le_iff₀ hv0).mpr
    have hh := mul_le_mul_of_nonneg_left hv (show 0≤512/g by positivity)
    have hh2 : u^2≤(2*R^2/g)^2 := by nlinarith
    have hh3 : (2*R^2/g)^2≤(512/g)*(3*R^4/(128*g)) := by
      field_simp
      nlinarith [sq_nonneg (R^2)]
    exact hh2.trans (hh3.trans hh)
  have hq0 : 0≤u/Real.sqrt V := by positivity
  refine ⟨hq0,?_⟩
  change u/Real.sqrt V≤512/g+1
  have hk : 0≤512/g := by positivity
  nlinarith [sq_nonneg (u/Real.sqrt V-1)]

end TorusCoverTime.Blocks.B
