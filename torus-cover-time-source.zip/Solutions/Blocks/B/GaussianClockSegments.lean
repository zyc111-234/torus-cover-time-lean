import Solutions.Blocks.B.GaussianClockPath

/-! Exact subpaths and reversed subpaths retain the actual, possibly irregular,
variance table.  Both orientations start at the deterministic value zero. -/

noncomputable section
open MeasureTheory ProbabilityTheory
namespace TorusCoverTime.Blocks.B.GaussianClockPath
variable {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
variable {n : ℕ} (W : GaussianClockPath μ n)

def segment {m : ℕ} (f : Fin (m + 1) → Fin (n + 1)) (hf : Monotone f) :
    GaussianClockPath μ m where
  path ω i := W.path ω (f i) - W.path ω (f 0)
  clock i := W.clock (f i) - W.clock (f 0)
  measurable := by fun_prop
  gaussian := W.gaussian.map_fun (ContinuousLinearMap.pi (fun i : Fin (m + 1) =>
    (ContinuousLinearMap.proj (f i) : (Fin (n + 1) → ℝ) →L[ℝ] ℝ) -
      ContinuousLinearMap.proj (f 0)))
  mean_zero i := by
    rw [integral_sub (W.integrable _) (W.integrable _), W.mean_zero, W.mean_zero, sub_self]
  covariance i j := by
    rw [W.increment_covariance]
    rw [min_eq_right (hf (Fin.zero_le i)), min_eq_left (hf (Fin.zero_le j)), min_self,
      ← hf.map_min]
    ring
  clock_zero := sub_self _
  clock_mono := fun i j hij => sub_le_sub_right (W.clock_mono (hf hij)) _
  start_zero ω := sub_self _

def reverse : GaussianClockPath μ n where
  path ω i := W.path ω i.rev - W.path ω (Fin.last n)
  clock i := W.clock (Fin.last n) - W.clock i.rev
  measurable := by fun_prop
  gaussian := W.gaussian.map_fun (ContinuousLinearMap.pi (fun i : Fin (n + 1) =>
    (ContinuousLinearMap.proj i.rev : (Fin (n + 1) → ℝ) →L[ℝ] ℝ) -
      ContinuousLinearMap.proj (Fin.last n)))
  mean_zero i := by
    rw [integral_sub (W.integrable _) (W.integrable _), W.mean_zero, W.mean_zero, sub_self]
  covariance i j := by
    rw [W.increment_covariance]
    simp only [min_eq_left (Fin.le_last i.rev), min_eq_right (Fin.le_last j.rev), min_self]
    rcases le_total i j with hij | hji
    · rw [min_eq_left hij, min_eq_right (Fin.rev_le_rev.mpr hij)]
      ring
    · rw [min_eq_right hji, min_eq_left (Fin.rev_le_rev.mpr hji)]
      ring
  clock_zero := by simp
  clock_mono := fun _ _ hij => sub_le_sub_left (W.clock_mono (Fin.rev_le_rev.mpr hij)) _
  start_zero ω := by simp

def neg : GaussianClockPath μ n where
  path ω i := -W.path ω i
  clock := W.clock
  measurable := by fun_prop
  gaussian := W.gaussian.map_fun (-ContinuousLinearMap.id ℝ (Fin (n + 1) → ℝ))
  mean_zero i := by rw [integral_neg, W.mean_zero, neg_zero]
  covariance i j := by rw [covariance_fun_neg_left, covariance_fun_neg_right, neg_neg, W.covariance]
  clock_zero := W.clock_zero
  clock_mono := W.clock_mono
  start_zero ω := by rw [W.start_zero, neg_zero]

end TorusCoverTime.Blocks.B.GaussianClockPath
