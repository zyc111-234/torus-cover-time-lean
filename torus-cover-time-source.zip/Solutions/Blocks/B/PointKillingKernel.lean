import Solutions.Blocks.B.PointKillingSpectrum
import Mathlib.Analysis.SpecialFunctions.ExpDeriv

/-! A finite spectral kernel for the point-killing operator, with its
initial condition, generator equation, and exact diagonal decay. -/
noncomputable section
open Classical
open scoped BigOperators RealInnerProductSpace
namespace TorusCoverTime.Blocks.B

def pointKillingDelta (N : Size) (a : Vertex N) : EuclideanSpace ℝ (Vertex N) :=
  WithLp.toLp 2 (Pi.single a 1)

theorem pointKillingDelta_inner (N : Size) (a : Vertex N) (f : EuclideanSpace ℝ (Vertex N)) :
    ⟪pointKillingDelta N a,f⟫ = f a := by
  rw [pointKilling_inner]
  simp [pointKillingDelta,Pi.single_apply]

theorem pointKillingBasis_resolution (N : Size) (c a b : Vertex N) :
    (∑ i : PointKillingIndex N, pointKillingBasis N c i a*pointKillingBasis N c i b) =
      if a=b then 1 else 0 := by
  have h := (pointKillingBasis N c).sum_inner_mul_inner (pointKillingDelta N a) (pointKillingDelta N b)
  have hr (f : EuclideanSpace ℝ (Vertex N)) : ⟪f,pointKillingDelta N b⟫ = f b := by
    rw [real_inner_comm]
    exact pointKillingDelta_inner N b f
  simp only [hr,pointKillingDelta_inner] at h
  simpa [pointKillingDelta,eq_comm] using h

def pointKillingKernel (N : Size) (c : Vertex N) (t : ℝ) (a b : Vertex N) : ℝ :=
  ∑ i : PointKillingIndex N,
    Real.exp (-pointKillingModeRate N c i*t)*pointKillingBasis N c i a*pointKillingBasis N c i b

theorem pointKillingKernel_symm (N : Size) (c : Vertex N) (t : ℝ) (a b : Vertex N) :
    pointKillingKernel N c t a b = pointKillingKernel N c t b a := by
  apply Finset.sum_congr rfl
  intro i _
  ring

theorem pointKillingKernel_zero (N : Size) (c a b : Vertex N) :
    pointKillingKernel N c 0 a b = if a=b then 1 else 0 := by
  simpa only [pointKillingKernel,mul_zero,Real.exp_zero,one_mul] using pointKillingBasis_resolution N c a b

theorem pointKillingKernel_continuous (N : Size) (c a b : Vertex N) :
    Continuous (fun t => pointKillingKernel N c t a b) := by
  unfold pointKillingKernel
  fun_prop

theorem pointKillingBasis_generator (N : Size) (c : Vertex N) (i : PointKillingIndex N) (a : Vertex N) :
    generator N (pointKillingBasis N c i) a-(if a=c then pointKillingBasis N c i a else 0) =
      -pointKillingModeRate N c i*pointKillingBasis N c i a := by
  have h := congrArg (fun f : EuclideanSpace ℝ (Vertex N) => f a) (pointKillingBasis_eigen N c i)
  change pointKillingStep N c (pointKillingBasis N c i) a =
    (1-pointKillingModeRate N c i/2)*pointKillingBasis N c i a at h
  unfold pointKillingStep at h
  linarith

theorem pointKillingKernel_hasDerivAt (N : Size) (c a b : Vertex N) (t : ℝ) :
    HasDerivAt (fun s => pointKillingKernel N c s a b)
      (generator N (fun x => pointKillingKernel N c t x b) a-
        (if a=c then pointKillingKernel N c t a b else 0)) t := by
  have hd := HasDerivAt.fun_sum (u := Finset.univ) (fun i _ =>
    (((hasDerivAt_id t).const_mul (-pointKillingModeRate N c i)).exp.mul_const
      (pointKillingBasis N c i a)).mul_const (pointKillingBasis N c i b))
  simp only [id_eq,mul_one] at hd
  convert hd using 1 <;> try rfl
  unfold pointKillingKernel
  rw [generator_sum]
  have hg (i : PointKillingIndex N) :
      generator N (fun x => Real.exp (-pointKillingModeRate N c i*t)*
        pointKillingBasis N c i x*pointKillingBasis N c i b) a =
      (Real.exp (-pointKillingModeRate N c i*t)*pointKillingBasis N c i b)*
        generator N (pointKillingBasis N c i) a := by
    have he : (fun x => Real.exp (-pointKillingModeRate N c i*t)*
        pointKillingBasis N c i x*pointKillingBasis N c i b) =
        fun x => (Real.exp (-pointKillingModeRate N c i*t)*pointKillingBasis N c i b)*pointKillingBasis N c i x := by
      funext x
      ring
    rw [he,generator_mul_left]
  simp only [hg]
  by_cases hac : a=c
  · rw [if_pos hac,← Finset.sum_sub_distrib]
    apply Finset.sum_congr rfl
    intro i _
    have hi := pointKillingBasis_generator N c i a
    rw [if_pos hac] at hi
    rw [sub_eq_iff_eq_add.mp hi]
    ring
  · rw [if_neg hac,sub_zero]
    apply Finset.sum_congr rfl
    intro i _
    have hi := pointKillingBasis_generator N c i a
    rw [if_neg hac,sub_zero] at hi
    rw [hi]
    ring

theorem pointKillingKernel_diag_nonneg (N : Size) (c a : Vertex N) (t : ℝ) :
    0 ≤ pointKillingKernel N c t a a := by
  apply Finset.sum_nonneg
  intro i _
  have h : Real.exp (-pointKillingModeRate N c i*t)*pointKillingBasis N c i a*pointKillingBasis N c i a =
      Real.exp (-pointKillingModeRate N c i*t)*(pointKillingBasis N c i a)^2 := by ring
  rw [h]
  positivity

theorem pointKillingKernel_diag_decay (N : Size) (c a : Vertex N) (s t : ℝ) (hst : s ≤ t) :
    pointKillingKernel N c t a a ≤ Real.exp (-pointKillingRate N*(t-s))*pointKillingKernel N c s a a := by
  unfold pointKillingKernel
  rw [Finset.mul_sum]
  apply Finset.sum_le_sum
  intro i _
  have he : Real.exp (-pointKillingModeRate N c i*t) ≤
      Real.exp (-pointKillingRate N*(t-s))*Real.exp (-pointKillingModeRate N c i*s) := by
    rw [← Real.exp_add]
    apply Real.exp_le_exp.mpr
    have h := mul_le_mul_of_nonneg_right (pointKillingModeRate_lower N c i) (sub_nonneg.mpr hst)
    nlinarith only [h]
  have h := mul_le_mul_of_nonneg_right he (sq_nonneg (pointKillingBasis N c i a))
  nlinarith only [h]

theorem pointKillingKernel_cauchy (N : Size) (c a b : Vertex N) (t : ℝ) :
    (pointKillingKernel N c t a b)^2 ≤ pointKillingKernel N c t a a*pointKillingKernel N c t b b := by
  have he (i : PointKillingIndex N) : (Real.exp (-pointKillingModeRate N c i*t/2))^2 =
      Real.exp (-pointKillingModeRate N c i*t) := by
    rw [pow_two,← Real.exp_add]
    congr 1
    ring
  have h := Finset.sum_mul_sq_le_sq_mul_sq (Finset.univ:Finset (PointKillingIndex N))
    (fun i => Real.exp (-pointKillingModeRate N c i*t/2)*pointKillingBasis N c i a)
    (fun i => Real.exp (-pointKillingModeRate N c i*t/2)*pointKillingBasis N c i b)
  have hp (i : PointKillingIndex N) (x y : Vertex N) :
      (Real.exp (-pointKillingModeRate N c i*t/2)*pointKillingBasis N c i x)*
        (Real.exp (-pointKillingModeRate N c i*t/2)*pointKillingBasis N c i y) =
      Real.exp (-pointKillingModeRate N c i*t)*pointKillingBasis N c i x*pointKillingBasis N c i y := by
    calc
      _ = (Real.exp (-pointKillingModeRate N c i*t/2))^2*pointKillingBasis N c i x*pointKillingBasis N c i y := by ring
      _ = _ := by rw [he]
  simpa only [pow_two,hp,pointKillingKernel] using h

theorem pointKillingKernel_norm_le_one (N : Size) (c a b : Vertex N) (t : ℝ) (ht : 0 ≤ t) :
    ‖pointKillingKernel N c t a b‖ ≤ 1 := by
  have hd (x : Vertex N) : pointKillingKernel N c t x x ≤ 1 := by
    have h := pointKillingKernel_diag_decay N c x 0 t ht
    rw [pointKillingKernel_zero,if_pos rfl,mul_one,sub_zero] at h
    apply h.trans
    apply Real.exp_le_one_iff.mpr
    exact mul_nonpos_of_nonpos_of_nonneg (neg_nonpos.mpr (pointKillingRate_pos N).le) ht
  have h := (pointKillingKernel_cauchy N c a b t).trans
    (mul_le_mul (hd a) (hd b) (pointKillingKernel_diag_nonneg N c b t) zero_le_one)
  rw [Real.norm_eq_abs]
  exact abs_le.mpr ⟨by nlinarith,by nlinarith⟩

end TorusCoverTime.Blocks.B
