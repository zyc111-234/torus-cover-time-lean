import Solutions.Blocks.B.QuadraticFourierTail

/-! The low-frequency real part equals the logarithmic lattice mass up to
a quadratic phase error, with an explicit cutoff-cardinality factor. -/

noncomputable section
open scoped BigOperators
namespace TorusCoverTime.Blocks.B

theorem quadraticSquareCore_double (N : Size) (m : ℕ) (z : Vertex N) :
    quadraticSquareCore N m z =
      ∑ b ∈ centeredCore N m, ∑ a ∈ centeredCore N m,
        ((1 / frequencyNormSq N (a,b) : ℝ) : ℂ) * finiteCharacter N (a,b) z := by
  unfold quadraticSquareCore quadraticRowCore
  simp only [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro b _
  apply Finset.sum_congr rfl
  intro a _
  simp only [frequencyNormSq, finiteCharacter, coordinateCharacter_add]
  rw [add_comm (coordinateDistance a 0 ^ 2) (coordinateDistance b 0 ^ 2)]
  ring

theorem quadraticSquareCore_re (N : Size) (m : ℕ) (z : Vertex N) :
    (quadraticSquareCore N m z).re =
      ∑ b ∈ centeredCore N m, ∑ a ∈ centeredCore N m,
        finiteCosine N (a,b) z / frequencyNormSq N (a,b) := by
  rw [quadraticSquareCore_double]
  simp only [Complex.re_sum, Complex.mul_re, Complex.ofReal_re, Complex.ofReal_im,
    zero_mul, sub_zero, finiteCharacter_re]
  apply Finset.sum_congr rfl
  intro b _
  apply Finset.sum_congr rfl
  intro a _
  ring

theorem centeredCore_quadratic_mass (N : Size) (m : ℕ) (hm : m ≤ (N.val - 1) / 2) :
    (∑ b ∈ centeredCore N m, ∑ a ∈ centeredCore N m, 1 / frequencyNormSq N (a,b)) =
      symmetricLatticeSum m := by
  unfold frequencyNormSq
  have hin (b : ZMod N.val) :
      (∑ a ∈ centeredCore N m, 1 / (coordinateDistance a 0 ^ 2 + coordinateDistance b 0 ^ 2)) =
      symmetricCoordinateSum m (fun x => 1 / (coordinateDistance b 0 ^ 2 + x ^ 2)) := by
    simp_rw [add_comm (coordinateDistance _ 0 ^ 2) (coordinateDistance b 0 ^ 2)]
    exact sum_centeredCore_distance N m hm (fun x => 1 / (coordinateDistance b 0 ^ 2 + x ^ 2))
  simp only [hin]
  exact sum_centeredCore_distance N m hm (fun y => symmetricCoordinateSum m (fun x => 1 / (y ^ 2 + x ^ 2)))

theorem quadratic_phase_error (N : Size) (k z : Vertex N) :
    0 ≤ (1 - finiteCosine N k z) / frequencyNormSq N k ∧
      (1 - finiteCosine N k z) / frequencyNormSq N k ≤
        2 * Real.pi ^ 2 * periodicDistance z 0 ^ 2 / vertexCount N := by
  have hq : 0 ≤ frequencyNormSq N k := by unfold frequencyNormSq; positivity
  have hnum : 0 ≤ 1 - finiteCosine N k z := by
    exact sub_nonneg.mpr (Real.cos_le_one _)
  refine ⟨div_nonneg hnum hq, ?_⟩
  rcases eq_or_lt_of_le hq with hzero | hpos
  · rw [← hzero, div_zero]
    have hn := vertexCount_pos N
    positivity
  · apply (div_le_iff₀ hpos).mpr
    calc
      _ ≤ 2 * Real.pi ^ 2 * frequencyNormSq N k * periodicDistance z 0 ^ 2 / vertexCount N :=
        finiteCosine_increment_quadratic N k z
      _ = _ := by ring

theorem quadraticSquareCore_error (N : Size) (m : ℕ) (hm : m ≤ (N.val - 1) / 2)
    (z : Vertex N) :
    |(quadraticSquareCore N m z).re - symmetricLatticeSum m| ≤
      (2 * (m : ℝ) + 1)^2 * (2 * Real.pi ^ 2 * periodicDistance z 0 ^ 2 / vertexCount N) := by
  have he : symmetricLatticeSum m - (quadraticSquareCore N m z).re =
      ∑ b ∈ centeredCore N m, ∑ a ∈ centeredCore N m,
        (1 - finiteCosine N (a,b) z) / frequencyNormSq N (a,b) := by
    rw [← centeredCore_quadratic_mass N m hm, quadraticSquareCore_re,
      ← Finset.sum_sub_distrib]
    apply Finset.sum_congr rfl
    intro b _
    rw [← Finset.sum_sub_distrib]
    apply Finset.sum_congr rfl
    intro a _
    ring
  have hp : 0 ≤ symmetricLatticeSum m - (quadraticSquareCore N m z).re := by
    rw [he]
    exact Finset.sum_nonneg fun b _ => Finset.sum_nonneg fun a _ => (quadratic_phase_error N (a,b) z).1
  rw [abs_sub_comm, abs_of_nonneg hp, he]
  calc
    _ ≤ ∑ _b ∈ centeredCore N m, ∑ _a ∈ centeredCore N m,
        2 * Real.pi ^ 2 * periodicDistance z 0 ^ 2 / vertexCount N :=
      Finset.sum_le_sum fun b _ => Finset.sum_le_sum fun a _ => (quadratic_phase_error N (a,b) z).2
    _ = _ := by simp only [Finset.sum_const, nsmul_eq_mul, centeredCore_card N m hm]; ring

theorem quadraticFourierSum_cutoff_error (N : Size) (m : ℕ)
    (hm0 : 0 < m) (hm : m ≤ (N.val - 1) / 2) (z : Vertex N) (hz : z.1 ≠ 0) :
    |(quadraticFourierSum N z).re - 2 * Real.pi * Real.log m| ≤
      10 * ((N.val : ℝ) / coordinateDistance z.1 0) / ((m : ℝ) + 1) +
      (2 * (m : ℝ) + 1)^2 * (2 * Real.pi ^ 2 * periodicDistance z 0 ^ 2 / vertexCount N) +
      (32 + 2 * Real.pi) := by
  have ht : |(quadraticFourierSum N z).re - (quadraticSquareCore N m z).re| ≤
      10 * ((N.val : ℝ) / coordinateDistance z.1 0) / ((m : ℝ) + 1) :=
    (Complex.abs_re_le_norm (quadraticFourierSum N z - quadraticSquareCore N m z)).trans
      (quadraticSquareCore_tail N m hm z hz)
  calc
    _ = |((quadraticFourierSum N z).re - (quadraticSquareCore N m z).re) +
        ((quadraticSquareCore N m z).re - symmetricLatticeSum m) +
        (symmetricLatticeSum m - 2 * Real.pi * Real.log m)| := by congr 1; ring
    _ ≤ _ := (abs_add_le _ _).trans (add_le_add (abs_add_le _ _) le_rfl)
    _ ≤ _ := add_le_add (add_le_add ht (quadraticSquareCore_error N m hm z))
      (symmetricLatticeSum_log_error m hm0)

end TorusCoverTime.Blocks.B
