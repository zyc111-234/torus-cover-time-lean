import Solutions.Blocks.B.BridgeContactScale
import Solutions.Blocks.B.BridgeContactConvolution

/-! All middle contact scales of the same finite bridge, retaining the
original common survival event. This is B.26 for r >= 3, the regime used
by the eventual large-scale application. Short end segments are separate. -/

noncomputable section
open MeasureTheory ProbabilityTheory Set Classical
open scoped ENNReal BigOperators
namespace TorusCoverTime.Blocks.B.GaussianClockPath
variable {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
variable {n : ℕ} (W : GaussianClockPath μ n)

def middleContact (H b : ℝ) (r : ℕ) : Set Ω :=
  {ω | (∀ i, W.bridge ω i ≤ H) ∧ ∃ k : Fin (n+1), r ≤ k.val ∧ r ≤ n-k.val ∧ H-b ≤ W.bridge ω k}

theorem middleContact_measurable (H b : ℝ) (r : ℕ) : MeasurableSet (W.middleContact H b r) := by
  unfold middleContact
  change MeasurableSet ({ω | ∀ i, W.bridge ω i ≤ H} ∩
    {ω | ∃ k : Fin (n+1), r ≤ k.val ∧ r ≤ n-k.val ∧ H-b ≤ W.bridge ω k})
  apply MeasurableSet.inter
  · change MeasurableSet {ω | ∀ i, W.bridge ω i ≤ H}
    rw [Set.ofPred_forall]
    exact MeasurableSet.iInter (fun i => measurableSet_le ((measurable_pi_apply i).comp W.bridge_measurable) measurable_const)
  · change MeasurableSet {ω | ∃ k : Fin (n+1), r ≤ k.val ∧ r ≤ n-k.val ∧ H-b ≤ W.bridge ω k}
    rw [Set.ofPred_exists]
    apply MeasurableSet.iUnion
    intro k
    exact (MeasurableSet.const _).inter ((MeasurableSet.const _).inter
      (measurableSet_le measurable_const ((measurable_pi_apply k).comp W.bridge_measurable)))

theorem bridge_middle_contact_ge_three {U : ℝ} (h : W.ClockBounds U)
    (r : ℕ) (hr : 3 ≤ r) (hrn : 2*r ≤ n) (H b : ℝ) (hH : 0 ≤ H) (hb : 0 ≤ b) :
    μ (W.middleContact H b r) ≤
      ENNReal.ofReal (32*bridgeContactCoefficient U H b/((n : ℝ)*Real.sqrt r)) := by
  let E (k : ℕ) : Set Ω := {ω | ∃ i : Fin (n+1), i.val=k ∧ (∀ j, W.bridge ω j ≤ H) ∧ H-b ≤ W.bridge ω i}
  let f (k : ℕ) : ℝ := Real.sqrt (n : ℝ)/
    (((k : ℝ)*Real.sqrt k)*(((n-k : ℕ) : ℝ)*Real.sqrt ((n-k : ℕ) : ℝ)))
  have hC := bridgeContactCoefficient_nonneg U H b hb
  have hsub : W.middleContact H b r ⊆ ⋃ k ∈ Finset.Icc r (n-r), E k := by
    rintro ω ⟨hs,k,hk,hl,hc⟩
    apply Set.mem_iUnion.mpr
    refine ⟨k.val,Set.mem_iUnion.mpr ⟨Finset.mem_Icc.mpr ⟨hk,by have := k.isLt; omega⟩,?_⟩⟩
    exact ⟨k,rfl,hs,hc⟩
  have hp (k : ℕ) (hk : k ∈ Finset.Icc r (n-r)) : μ (E k) ≤ ENNReal.ofReal (bridgeContactCoefficient U H b*f k) := by
    have hkr := Finset.mem_Icc.mp hk
    let i : Fin (n+1) := ⟨k,by omega⟩
    have he : E k = {ω | (∀ j, W.bridge ω j ≤ H) ∧ H-b ≤ W.bridge ω i} := by
      ext ω
      constructor
      · rintro ⟨j,hj,hs,hc⟩
        have hji : j=i := Fin.ext hj
        exact hji ▸ ⟨hs,hc⟩
      · intro hh
        exact ⟨i,rfl,hh⟩
    rw [he]
    have hh := W.bridge_contact_single_scale h i (by dsimp [i]; omega) (by dsimp [i]; omega) H b hH hb
    convert hh using 1
    dsimp [f,i]
    ring
  calc
    _ ≤ ∑ k ∈ Finset.Icc r (n-r), μ (E k) := (measure_mono hsub).trans (measure_biUnion_finset_le _ _)
    _ ≤ ∑ k ∈ Finset.Icc r (n-r), ENNReal.ofReal (bridgeContactCoefficient U H b*f k) := Finset.sum_le_sum hp
    _ = ENNReal.ofReal (∑ k ∈ Finset.Icc r (n-r), bridgeContactCoefficient U H b*f k) := by
      rw [ENNReal.ofReal_sum_of_nonneg]
      intro k hk
      exact mul_nonneg hC (by dsimp [f]; positivity)
    _ = ENNReal.ofReal (bridgeContactCoefficient U H b*∑ k ∈ Finset.Icc r (n-r), f k) := by rw [Finset.mul_sum]
    _ ≤ ENNReal.ofReal (bridgeContactCoefficient U H b*(32/((n : ℝ)*Real.sqrt r))) :=
      ENNReal.ofReal_le_ofReal (mul_le_mul_of_nonneg_left (bridge_contact_convolution n r (by omega) hrn) hC)
    _ = _ := by congr 1; ring

end TorusCoverTime.Blocks.B.GaussianClockPath
