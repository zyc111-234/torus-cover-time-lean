import Solutions.Blocks.B.R8HighCountLimit

/-! An actual simultaneous good event: every far-root soft center has
bounded count at every coarse integer scale. -/
noncomputable section
open MeasureTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

def r8HighCountFailure (N : Size) (root : Vertex N) (γ U : ℝ) : Set (WalkSample × ℝ) :=
  ⋃ k ∈ r7CoarseIntegerScales N γ, ⋃ c : Vertex N, r8FarHighCountSoftEvent N c root γ k U

theorem r8HighCountFailure_measurable (N : Size) (root : Vertex N) (γ U : ℝ) :
    MeasurableSet (r8HighCountFailure N root γ U) :=
  MeasurableSet.biUnion (r7CoarseIntegerScales N γ).countable_toSet
    (fun k _ => MeasurableSet.iUnion fun c => r8FarHighCountSoftEvent_measurable N c root γ k U)

theorem r8HighCountFailure_compl_iff (N : Size) (root : Vertex N) (γ U : ℝ) (z : WalkSample × ℝ) :
    z ∉ r8HighCountFailure N root γ U ↔ ∀ k : ℕ,
      (logSize N)^(16*γ) ≤ (k:ℝ) → (k:ℝ) ≤ logSize N-(logSize N)^(16*γ) → ∀ c : Vertex N,
      (N.val:ℝ)*Real.exp (-((logSize N)^(16*γ))/2) ≤ periodicDistance c root →
      localTime N root z.1 z.2 c/g ≤ U → r7TraversalRadius N c root γ k z ≤ 10*logSize N := by
  simp only [r8HighCountFailure,mem_iUnion,mem_r7CoarseIntegerScales,r8FarHighCountSoftEvent,
    r8HighCountSoftEvent,mem_ofPred_eq]
  constructor
  · intro h k hlo hhi c hfar hsoft
    by_contra hn
    exact h ⟨k,⟨hlo,hhi⟩,c,hfar,lt_of_not_ge hn,hsoft⟩
  · rintro h ⟨k,hk,c,hfar,hcount,hsoft⟩
    exact not_lt_of_ge (h k hk.1 hk.2 c hfar hsoft) hcount

theorem r8_high_count_failure_mass_le (N : Size) (γ U l r : ℝ) :
    r7LoopEventMass N (fun root => r8HighCountFailure N root γ U) l r ≤ r8AllHighCountMass N γ U l r := by
  apply (r7LoopEventMass_biUnion_le N (r7CoarseIntegerScales N γ)
    (fun k root => ⋃ c : Vertex N, r8FarHighCountSoftEvent N c root γ k U)
    (fun k _ root => MeasurableSet.iUnion fun c => r8FarHighCountSoftEvent_measurable N c root γ k U) l r).trans
  apply Finset.sum_le_sum
  intro k _
  have hh := r7LoopEventMass_biUnion_le N (Finset.univ : Finset (Vertex N))
    (fun c root => r8FarHighCountSoftEvent N c root γ k U)
    (fun c _ root => r8FarHighCountSoftEvent_measurable N c root γ k U) l r
  simpa only [Finset.mem_univ,iUnion_true,r8HighCountWindowMass] using hh

end TorusCoverTime.Blocks.B
