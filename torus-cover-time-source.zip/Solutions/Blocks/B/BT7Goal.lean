import Solutions.Blocks.B.BT6
import Solutions.Blocks.C.C4.Base.PeriodicDomainDecomposition

/-! Fixed B-T7 target: the actual mean-zero periodic Gaussian field,
both signs, the full existential amplitude, and expected bad-point count. -/
noncomputable section
open MeasureTheory Filter Classical
open scoped Topology BigOperators
namespace TorusCoverTime.Blocks.B

def periodicFieldLS (N : Size) (ξ : FiniteFieldSample N) (x : Vertex N) : ℝ :=
  finiteGaussianField N ξ x/Real.sqrt (2*g)

def bt7BadPoint (N : Size) (γ ε C₀ C₁ : ℝ) (f : Vertex N → ℝ) (x : Vertex N) : Prop :=
  ∃ a : ℝ, |a-harmonicExtremeCenter N|≤ε*Real.log (logSize N)+C₀ ∧ |f x-a|≤C₀ ∧
    (∀ q : ℕ, (logSize N)^(32*γ)≤(q:ℝ) → (q:ℝ)≤logSize N-(logSize N)^(32*γ) →
      Real.sqrt 2*(q:ℝ)-C₁*(logSize N)^(8*γ)≤bt6ExitNorm N x q f a) ∧
    ∃ q : ℕ, (logSize N)^(1/10:ℝ)≤(q:ℝ) ∧ (q:ℝ)≤logSize N-(logSize N)^(1/10:ℝ) ∧
      bt6ExitNorm N x q f a≤Real.sqrt 2*(q:ℝ)+C₁*(logSize N)^(8*γ)

def bt7BadCount (N : Size) (γ ε C₀ C₁ : ℝ) (ξ : FiniteFieldSample N) : ℝ :=
  ∑ x, if bt7BadPoint N γ ε C₀ C₁ (periodicFieldLS N ξ) x ∨
    bt7BadPoint N γ ε C₀ C₁ (fun z => -periodicFieldLS N ξ z) x then 1 else 0

def BT7Conclusion (γ C₀ C₁ : ℝ) : Prop :=
  ∃ ε : ℝ, 0<ε ∧ Tendsto (fun N : Size => ∫ ξ, bt7BadCount N γ ε C₀ C₁ ξ ∂finiteFieldLaw N) atTop (𝓝 0)

end TorusCoverTime.Blocks.B
