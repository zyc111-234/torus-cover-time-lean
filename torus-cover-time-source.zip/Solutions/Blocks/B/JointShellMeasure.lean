import Solutions.Blocks.B.SharpShellWindow

/-! The joint root/field/sign shell is the uniform mixture of the actual
fixed-root shells. Exact equality of their masses identifies its averaged
field/sign marginal with the existing D shell measure. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Classical
open scoped ENNReal Topology BigOperators
namespace TorusCoverTime.Blocks.B

def uniformRootMixture {α : Type*} [MeasurableSpace α] (N : Size)
    (μ : Vertex N → Measure α) : Measure (Vertex N × α) :=
  (ENNReal.ofReal (vertexCount N))⁻¹ • Measure.sum (fun r => (μ r).map (Prod.mk r))

lemma uniformRoot_measure (N : Size) :
    uniformOn (Set.univ : Set (Vertex N)) =
      (ENNReal.ofReal (vertexCount N))⁻¹ • Measure.count := by
  ext E
  rw [uniformOn_univ, Measure.smul_apply, Blocks.D.vertexCount_eq_card, ENNReal.ofReal_natCast]
  exact ENNReal.div_eq_inv_mul

lemma uniformRootMixture_apply {α : Type*} [MeasurableSpace α] (N : Size)
    (μ : Vertex N → Measure α) (E : Set (Vertex N × α)) (hE : MeasurableSet E) :
    uniformRootMixture N μ E = (ENNReal.ofReal (vertexCount N))⁻¹ *
      ∑ r, μ r (Prod.mk r ⁻¹' E) := by
  rw [uniformRootMixture, Measure.smul_apply, Measure.sum_apply _ hE]
  simp_rw [Measure.map_apply measurable_prodMk_left hE]
  rw [tsum_fintype]
  rfl

lemma uniformRootMixture_const {α : Type*} [MeasurableSpace α] (N : Size)
    (μ : Measure α) [SFinite μ] :
    uniformRootMixture N (fun _ => μ) = (uniformOn (Set.univ : Set (Vertex N))).prod μ := by
  rw [uniformRootMixture, uniformRoot_measure, Measure.prod_smul_left, Measure.count, Measure.prod_sum_left]
  congr 1
  apply congrArg Measure.sum
  funext r
  exact (Measure.dirac_prod r).symm

lemma uniformRootMixture_probability {α : Type*} [MeasurableSpace α] (N : Size)
    (μ : Vertex N → Measure α) (hμ : ∀ r, IsProbabilityMeasure (μ r)) :
    IsProbabilityMeasure (uniformRootMixture N μ) := by
  let (r : Vertex N) : IsProbabilityMeasure (μ r) := hμ r
  constructor
  rw [uniformRootMixture_apply N μ Set.univ MeasurableSet.univ]
  simp only [Set.preimage_univ, measure_univ, Finset.sum_const, Finset.card_univ, nsmul_eq_mul, mul_one]
  rw [← ENNReal.ofReal_natCast, ← Blocks.D.vertexCount_eq_card]
  exact ENNReal.inv_mul_cancel (ENNReal.ofReal_ne_zero_iff.mpr (vertexCount_pos N)) ENNReal.ofReal_ne_top

lemma uniformRootMixture_real_apply {α : Type*} [MeasurableSpace α] (N : Size)
    (μ : Vertex N → Measure α) (hμ : ∀ r, IsFiniteMeasure (μ r))
    (E : Set (Vertex N × α)) (hE : MeasurableSet E) :
    (uniformRootMixture N μ).real E = (∑ r, (μ r).real (Prod.mk r ⁻¹' E)) / vertexCount N := by
  let (r : Vertex N) : IsFiniteMeasure (μ r) := hμ r
  rw [measureReal_def, uniformRootMixture_apply N μ E hE, ENNReal.toReal_mul,
    ENNReal.toReal_inv, ENNReal.toReal_ofReal (vertexCount_pos N).le,
    ENNReal.toReal_sum (fun r _ => measure_ne_top _ _)]
  simp only [measureReal_def, div_eq_mul_inv, mul_comm]

lemma uniformRootMixture_event_error {α : Type*} [MeasurableSpace α] (N : Size)
    (μ : Vertex N → Measure α) (ν : Measure α) [IsFiniteMeasure ν]
    (hμ : ∀ r, IsFiniteMeasure (μ r)) (ε : ℝ)
    (hbound : ∀ r E, MeasurableSet E → |(μ r).real E - ν.real E| ≤ ε)
    (E : Set (Vertex N × α)) (hE : MeasurableSet E) :
    |(uniformRootMixture N μ).real E -
      ((uniformOn (Set.univ : Set (Vertex N))).prod ν).real E| ≤ ε := by
  rw [← uniformRootMixture_const, uniformRootMixture_real_apply N μ hμ E hE,
    uniformRootMixture_real_apply N (fun _ => ν) (fun _ => inferInstance) E hE,
    ← sub_div, ← Finset.sum_sub_distrib, abs_div, abs_of_pos (vertexCount_pos N)]
  calc
    _ ≤ (∑ r, |(μ r).real (Prod.mk r ⁻¹' E) - ν.real (Prod.mk r ⁻¹' E)|) / vertexCount N :=
      div_le_div_of_nonneg_right (Finset.abs_sum_le_sum_abs _ _) (vertexCount_pos N).le
    _ ≤ (∑ _ : Vertex N, ε) / vertexCount N :=
      div_le_div_of_nonneg_right (Finset.sum_le_sum fun r _ =>
        hbound r _ (hE.preimage measurable_prodMk_left)) (vertexCount_pos N).le
    _ = ε := by
      rw [Finset.sum_const, Finset.card_univ, nsmul_eq_mul, ← Blocks.D.vertexCount_eq_card]
      exact mul_div_cancel_left₀ ε (vertexCount_pos N).ne'

def jointRootShell (N : Size) (B : ℝ) : Measure (Vertex N × (FiniteFieldSample N × Bool)) :=
  uniformRootMixture N (fun root => normalizedFixedRootShell N root B)

theorem jointRootShell_probability (N : Size) (B : ℝ) (hB : 20 * greenDiagonal N ≤ B) :
    IsProbabilityMeasure (jointRootShell N B) :=
  uniformRootMixture_probability N _ (fun r => normalizedFixedRootShell_probability N r B hB)

lemma uniformRoot_lintegral {N : Size} (f : Vertex N → ℝ≥0∞) :
    (∫⁻ r, f r ∂uniformOn (Set.univ : Set (Vertex N))) =
      (ENNReal.ofReal (vertexCount N))⁻¹ * ∑ r, f r := by
  rw [uniformRoot_measure, lintegral_smul_measure, lintegral_count, tsum_fintype]
  rfl

theorem jointRootShell_density (N : Size) (B : ℝ) :
    jointRootShell N B =
      ((uniformOn (Set.univ : Set (Vertex N))).prod ((finiteFieldLaw N).prod Measure.count)).withDensity
        (fun p => (Blocks.D.averagedShellMass N B)⁻¹ * fixedRootShellDensity N p.1 B p.2) := by
  have hd : Measurable (fun p : Vertex N × (FiniteFieldSample N × Bool) =>
      (Blocks.D.averagedShellMass N B)⁻¹ * fixedRootShellDensity N p.1 B p.2) :=
    measurable_const.mul (measurable_from_prod_countable_right fun r => fixedRootShellDensity_measurable N r B)
  ext E hE
  rw [jointRootShell, uniformRootMixture_apply N _ E hE, withDensity_apply _ hE,
    ← lintegral_indicator hE, lintegral_prod _ (hd.indicator hE).aemeasurable, uniformRoot_lintegral]
  congr 1
  apply Finset.sum_congr rfl
  intro r _
  have hpre := hE.preimage (measurable_prodMk_left (x := r))
  rw [normalizedFixedRootShell, Measure.smul_apply, fixedRootShellMass_eq_averaged,
    fixedRootShellMeasure, withDensity_apply _ hpre, smul_eq_mul, ← lintegral_indicator hpre,
    ← lintegral_const_mul _ ((fixedRootShellDensity_measurable N r B).indicator hpre)]
  apply lintegral_congr
  intro z
  by_cases hz : (r, z) ∈ E <;> simp [hz]

/-- Exactly the paper's b/Z density relative to uniform root, Gaussian field,
and counting measure on the two signs. -/
theorem jointRootShell_scaled_density (N : Size) (B : ℝ) :
    jointRootShell N B =
      ((uniformOn (Set.univ : Set (Vertex N))).prod ((finiteFieldLaw N).prod Measure.count)).withDensity
        (fun p => (ENNReal.ofReal (vertexCount N) * Blocks.D.averagedShellMass N B)⁻¹ *
          ENNReal.ofReal (rootScaledDensity N p.1 B p.2)) := by
  rw [jointRootShell_density]
  congr 1
  funext p
  rw [rootScaledDensity_ofReal, ← mul_assoc]
  have hn := ENNReal.ofReal_ne_zero_iff.mpr (vertexCount_pos N)
  have he : (ENNReal.ofReal (vertexCount N) * Blocks.D.averagedShellMass N B)⁻¹ *
      ENNReal.ofReal (vertexCount N) = (Blocks.D.averagedShellMass N B)⁻¹ := by
    rw [ENNReal.mul_inv (Or.inl hn) (Or.inl ENNReal.ofReal_ne_top), mul_right_comm,
      ENNReal.inv_mul_cancel hn ENNReal.ofReal_ne_top, one_mul]
  rw [he]

lemma fixedRootShell_sum_measure (N : Size) (B : ℝ) :
    (∑ r, fixedRootShellMeasure N r B) = ENNReal.ofReal (vertexCount N) • Blocks.D.averagedShellMeasure N B := by
  ext E hE
  rw [Measure.finsetSum_apply, Measure.smul_apply]
  have h := fixedRootShell_sum_lintegral N B (E.indicator (1 : FiniteFieldSample N × Bool → ℝ≥0∞))
    (by exact measurable_const.indicator hE)
  simpa only [lintegral_indicator_one hE, smul_eq_mul] using h

lemma normalizedFixedRootShell_sum_measure (N : Size) (B : ℝ) :
    (∑ r, normalizedFixedRootShell N r B) =
      ENNReal.ofReal (vertexCount N) • Blocks.D.normalizedAveragedShell N B := by
  ext E hE
  have hs := congrArg (fun μ : Measure (FiniteFieldSample N × Bool) => μ E) (fixedRootShell_sum_measure N B)
  simp only [Measure.finsetSum_apply, Measure.smul_apply, smul_eq_mul] at hs ⊢
  simp only [normalizedFixedRootShell, Measure.smul_apply, fixedRootShellMass_eq_averaged,
    smul_eq_mul, ← Finset.mul_sum, hs, Blocks.D.normalizedAveragedShell]
  ac_rfl

/-- Exact identification with the existing root-averaged shell, not an approximation. -/
theorem jointRootShell_field_sign_marginal (N : Size) (B : ℝ) :
    (jointRootShell N B).map Prod.snd = Blocks.D.normalizedAveragedShell N B := by
  ext E hE
  rw [Measure.map_apply measurable_snd hE, jointRootShell,
    uniformRootMixture_apply N _ _ (hE.preimage measurable_snd)]
  have hs := congrArg (fun μ : Measure (FiniteFieldSample N × Bool) => μ E)
    (normalizedFixedRootShell_sum_measure N B)
  simp only [Measure.finsetSum_apply, Measure.smul_apply, smul_eq_mul] at hs
  change (ENNReal.ofReal (vertexCount N))⁻¹ * (∑ r, normalizedFixedRootShell N r B E) = _
  rw [hs, ← mul_assoc, ENNReal.inv_mul_cancel
    (ENNReal.ofReal_ne_zero_iff.mpr (vertexCount_pos N)) ENNReal.ofReal_ne_top, one_mul]

theorem jointRootShell_field_marginal (N : Size) (B : ℝ) :
    (jointRootShell N B).map (fun p => p.2.1) =
      (Blocks.D.normalizedAveragedShell N B).map Prod.fst := by
  rw [← jointRootShell_field_sign_marginal N B, Measure.map_map measurable_fst measurable_snd]
  rfl

theorem jointRootShell_negative_mass (N : Size) (B : ℝ) :
    (jointRootShell N B).real {p | p.2.2 = false} =
      (Blocks.D.normalizedAveragedShell N B).real {z | z.2 = false} := by
  rw [← jointRootShell_field_sign_marginal N B]
  simp only [measureReal_def]
  rw [Measure.map_apply measurable_snd (measurableSet_eq_fun measurable_snd measurable_const)]
  rfl

/-- The real root label is retained in the shell law throughout R5.TV2. -/
theorem joint_root_shell_sharp_uniform (H : ℝ) (hH : 0 ≤ H) :
    ∃ c C : ℝ, 0 < c ∧ 0 < C ∧ ∀ᶠ N : Size in atTop,
      ∀ θ : ℝ, |θ| ≤ H →
      (|vertexCount N * (Blocks.D.averagedShellMass N (Blocks.D.shellEnergyParameter N θ)).toReal - 1| +
          (jointRootShell N (Blocks.D.shellEnergyParameter N θ)).real {p | p.2.2 = false} ≤
        C * Real.exp (-c * logSize N)) ∧
      (∀ E : Set (FiniteFieldSample N), MeasurableSet E →
        |((jointRootShell N (Blocks.D.shellEnergyParameter N θ)).map (fun p => p.2.1)).real E -
          (finiteFieldLaw N).real E| ≤ C * Real.exp (-c * logSize N)) := by
  simpa only [jointRootShell_negative_mass, jointRootShell_field_marginal] using sharp_shell_errors_uniform H hH

/-- R5.TV1 on every measurable event of the joint root/field/sign law. -/
theorem joint_root_shell_tv_uniform (H : ℝ) (hH : 0 ≤ H) :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ N : Size in atTop,
      ∀ θ : ℝ, |θ| ≤ H →
      ∀ E : Set (Vertex N × (FiniteFieldSample N × Bool)), MeasurableSet E →
        |(jointRootShell N (Blocks.D.shellEnergyParameter N θ)).real E -
          ((uniformOn (Set.univ : Set (Vertex N))).prod
            ((finiteFieldLaw N).prod (Measure.dirac true))).real E| ≤ C / Real.sqrt (logSize N) := by
  obtain ⟨C, hC, hbound⟩ := fixed_root_shell_tv_uniform H hH
  refine ⟨C, hC, ?_⟩
  filter_upwards [hbound, shellEnergy_twenty_variance_eventually H hH] with N hb hN
  intro θ hθ E hE
  exact uniformRootMixture_event_error N _ _
    (fun r => by
      let := normalizedFixedRootShell_probability N r _ (hN θ hθ)
      infer_instance)
    _ (hb θ hθ) E hE

end TorusCoverTime.Blocks.B
