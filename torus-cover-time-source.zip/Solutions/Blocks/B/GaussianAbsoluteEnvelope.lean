import Solutions.Blocks.B.HarmonicSupSquare

noncomputable section
open MeasureTheory ProbabilityTheory Classical
open scoped BigOperators
namespace TorusCoverTime.Blocks.B
variable {I Ω : Type*} [Fintype I] [MeasurableSpace Ω]
variable {μ : Measure Ω} [IsProbabilityMeasure μ]

def gaussianAbsoluteEnvelope (w : I → ℝ) (X : Ω → ℝ) (Y : I → Ω → ℝ) (ω : Ω) : ℝ :=
  |X ω|+∑ i, w i*|Y i ω|

theorem gaussian_absolute_envelope_exp (w : I → ℝ) (X : Ω → ℝ) (Y : I → Ω → ℝ)
    (hw : ∀ i, 0≤w i) (hs : ∑ i, w i=1) (hX : Measurable X) (hY : ∀ i, Measurable (Y i))
    (hgX : HasGaussianLaw X μ) (hgY : ∀ i, HasGaussianLaw (Y i) μ)
    (hmX : (∫ ω, X ω ∂μ)=0) (hmY : ∀ i, (∫ ω, Y i ω ∂μ)=0)
    (V : ℝ) (hV : 0<V) (hvX : Var[X;μ]≤V) (hvY : ∀ i, w i≠0 → Var[Y i;μ]≤V) :
    Integrable (fun ω => Real.exp (gaussianAbsoluteEnvelope w X Y ω^2/(32*V))) μ ∧
      (∫ ω, Real.exp (gaussianAbsoluteEnvelope w X Y ω^2/(32*V)) ∂μ)≤2 := by
  let v : Option I → ℝ := fun i => i.elim (1/2) (fun j => w j/2)
  let Z : Option I → Ω → ℝ := fun i => i.elim X Y
  have hv : ∀ i, 0≤v i := by
    intro i
    cases i with
    | none => norm_num [v]
    | some j => exact div_nonneg (hw j) (by norm_num)
  have hvs : ∑ i, v i=1 := by simp [v,Fintype.sum_option,← Finset.sum_div,hs]; norm_num
  have hz : ∀ i, Measurable (Z i) := by intro i; cases i; exact hX; exact hY _
  have hgz : ∀ i, HasGaussianLaw (Z i) μ := by intro i; cases i; exact hgX; exact hgY _
  have hmz : ∀ i, (∫ ω, Z i ω ∂μ)=0 := by intro i; cases i; exact hmX; exact hmY _
  have hvz : ∀ i, v i≠0 → Var[Z i;μ]≤V := by
    intro i hi
    cases i with
    | none => exact hvX
    | some j => exact hvY j (by intro hh; apply hi; simp [v,hh])
  obtain ⟨hint,hbound⟩ := weighted_gaussian_residual_exp v (fun _ => 0) Z hv hvs hz hgz hmz V 0 hV hvz (by simp)
  have hpoint (ω : Ω) : Real.exp (gaussianAbsoluteEnvelope w X Y ω^2/(32*V))≤
      Real.exp (weightedShiftedSquares v (fun _ => 0) Z ω/(8*V)) := by
    apply Real.exp_le_exp.mpr
    have ha := weighted_abs_square_le v (fun i => Z i ω) hv hvs
    have he : ∑ i, v i*|Z i ω|=gaussianAbsoluteEnvelope w X Y ω/2 := by
      simp only [Fintype.sum_option,v,Z,Option.elim_none,Option.elim_some,gaussianAbsoluteEnvelope]
      rw [add_div,Finset.sum_div]
      congr 1
      · ring
      · apply Finset.sum_congr rfl; intro i _; ring
    rw [he] at ha
    simp only [weightedShiftedSquares,add_zero]
    apply (div_le_div_iff₀ (by positivity : 0<32*V) (by positivity : 0<8*V)).mpr
    nlinarith [mul_le_mul_of_nonneg_right ha hV.le]
  have hi : Integrable (fun ω => Real.exp (gaussianAbsoluteEnvelope w X Y ω^2/(32*V))) μ :=
    hint.mono' (by unfold gaussianAbsoluteEnvelope; fun_prop)
      (Filter.Eventually.of_forall (fun ω => by rw [Real.norm_eq_abs,abs_of_pos (Real.exp_pos _)]; exact hpoint ω))
  refine ⟨hi,(integral_mono hi hint hpoint).trans ?_⟩
  simpa using hbound

end TorusCoverTime.Blocks.B
