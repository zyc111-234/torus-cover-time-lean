import Solutions.Blocks.B.RootShellWeights
import Solutions.Blocks.C.Base.PeriodicTranslations

/-! Exact spatial translation invariance of the concrete finite Fourier field.
The change of variables rotates the existing independent Gaussian pairs. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Classical
open scoped ENNReal Topology BigOperators
namespace TorusCoverTime.Blocks.B

def finiteFieldTranslation (N : Size) (a : Vertex N) (ξ : FiniteFieldSample N) :
    FiniteFieldSample N := fun k =>
  Blocks.C.gaussianPairRotation (finiteCosine N k a) (finiteSine N k a) (ξ k)

lemma finiteFieldTranslation_preserving (N : Size) (a : Vertex N) :
    MeasurePreserving (finiteFieldTranslation N a) (finiteFieldLaw N) (finiteFieldLaw N) := by
  apply measurePreserving_pi
  intro k
  apply Blocks.C.gaussianPairRotation_preserving
  exact Real.cos_sq_add_sin_sq (fourierAngle N k a)

lemma finiteGaussianField_translation (N : Size) (a x : Vertex N) (ξ : FiniteFieldSample N) :
    finiteGaussianField N (finiteFieldTranslation N a ξ) x = finiteGaussianField N ξ (a + x) := by
  unfold finiteGaussianField
  apply Finset.sum_congr rfl
  intro k hk
  have hc := congrArg Complex.re (finiteCharacter_add N k a x)
  have hs := congrArg Complex.im (finiteCharacter_add N k a x)
  simp only [finiteCharacter_re, finiteCharacter_im, Complex.mul_re, Complex.mul_im] at hc hs
  simp only [finiteFieldTranslation, Blocks.C.gaussianPairRotation, hc, hs]
  ring

lemma fieldMeanSquare_translation (N : Size) (a : Vertex N) (ξ : FiniteFieldSample N) :
    Blocks.D.fieldMeanSquare N (finiteFieldTranslation N a ξ) = Blocks.D.fieldMeanSquare N ξ := by
  unfold Blocks.D.fieldMeanSquare
  simp_rw [finiteGaussianField_translation]
  congr 1
  exact Fintype.sum_equiv (Equiv.addLeft a) _ _ (fun _ => rfl)

lemma shellAmplitude_translation (N : Size) (a : Vertex N) (B : ℝ) (ξ : FiniteFieldSample N) :
    Blocks.D.shellAmplitude N B (finiteFieldTranslation N a ξ) = Blocks.D.shellAmplitude N B ξ := by
  rw [Blocks.D.shellAmplitude, fieldMeanSquare_translation]
  rfl

lemma fixedRootShellDensity_translation (N : Size) (root a : Vertex N) (B : ℝ)
    (ξ : FiniteFieldSample N) (σ : Bool) :
    fixedRootShellDensity N root B (finiteFieldTranslation N a ξ, σ) =
      fixedRootShellDensity N (a + root) B (ξ, σ) := by
  simp only [fixedRootShellDensity, rootEnergyWeight, fieldMeanSquare_translation,
    shellAmplitude_translation, finiteGaussianField_translation]

/-- Root weights may be averaged inside an energy-dependent integral because the
joint law of the root value and the actual energy is translation invariant. -/
theorem root_energy_lintegral_equal (N : Size) (root root' : Vertex N)
    (F : ℝ × ℝ → ℝ≥0∞) (hF : Measurable F) :
    (∫⁻ ξ, F (Blocks.D.fieldMeanSquare N ξ, finiteGaussianField N ξ root) ∂finiteFieldLaw N) =
      ∫⁻ ξ, F (Blocks.D.fieldMeanSquare N ξ, finiteGaussianField N ξ root') ∂finiteFieldLaw N := by
  have hm : Measurable (fun ξ => F (Blocks.D.fieldMeanSquare N ξ, finiteGaussianField N ξ root)) :=
    hF.comp ((Blocks.D.fieldMeanSquare_measurable N).prodMk (by unfold finiteGaussianField; fun_prop))
  have hi := lintegral_map' (μ := finiteFieldLaw N) hm.aemeasurable
    (finiteFieldTranslation_preserving N (root' - root)).measurable.aemeasurable
  rw [(finiteFieldTranslation_preserving N (root' - root)).map_eq] at hi
  simpa only [fieldMeanSquare_translation, finiteGaussianField_translation, sub_add_cancel] using hi

theorem fixedRootShellMass_eq_root (N : Size) (root root' : Vertex N) (B : ℝ) :
    fixedRootShellMass N root B = fixedRootShellMass N root' B := by
  let F := fun ξ : FiniteFieldSample N =>
    fixedRootShellDensity N root B (ξ, true) + fixedRootShellDensity N root B (ξ, false)
  have hm : Measurable F :=
    ((fixedRootShellDensity_measurable N root B).comp (measurable_id.prodMk measurable_const)).add
      ((fixedRootShellDensity_measurable N root B).comp (measurable_id.prodMk measurable_const))
  have hi := lintegral_map' (μ := finiteFieldLaw N) hm.aemeasurable
    (finiteFieldTranslation_preserving N (root' - root)).measurable.aemeasurable
  rw [(finiteFieldTranslation_preserving N (root' - root)).map_eq] at hi
  simpa only [F, fixedRootShellMass_eq, fixedRootShellDensity_translation, sub_add_cancel] using hi

end TorusCoverTime.Blocks.B
