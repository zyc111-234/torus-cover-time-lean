import Solutions.Blocks.B.ExitSharpSoftness
import Solutions.Blocks.B.ExitPairLaplace

/-! Independent specified-exit blocks; the two sites inside one block are
never assumed independent. Occupation includes every return before exit. -/
noncomputable section
open MeasureTheory ProbabilityTheory Filter Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

structure PairExitParameters (N : Size) (c : Vertex N) (R : ℝ)
    (a b x y : Vertex N) (p lam : ℝ) where
  entry_pos : 0 < exitHarmonic N (torusDisk N c R) b a
  left_pos : 0 < exitHarmonic N (torusDisk N c R) b x
  right_pos : 0 < exitHarmonic N (torusDisk N c R) b y
  e : ℝ
  e_pos : 0 < e
  det_pos : 0 < conditionedDiskGreen N c R b x x*conditionedDiskGreen N c R b y y-
    conditionedDiskGreen N c R b x y*conditionedDiskGreen N c R b y x
  row_left : e*(conditionedDiskGreen N c R b x x*conditionedDiskGreen N c R b y y-
    conditionedDiskGreen N c R b x y*conditionedDiskGreen N c R b y x) ≤
      conditionedDiskGreen N c R b y y-conditionedDiskGreen N c R b x y
  row_right : e*(conditionedDiskGreen N c R b x x*conditionedDiskGreen N c R b y y-
    conditionedDiskGreen N c R b x y*conditionedDiskGreen N c R b y x) ≤
      conditionedDiskGreen N c R b x x-conditionedDiskGreen N c R b y x
  entrance : p ≤ e*(conditionedDiskGreen N c R b a x+conditionedDiskGreen N c R b a y)
  rate : g*e ≤ lam

theorem pair_exit_normalized_laplace (hWalk : WalkModelRegular)
    (N : Size) (c : Vertex N) (R : ℝ) (hR : 0 ≤ R) (hsmall : 2*(R+1) < N.val)
    (a b x y : Vertex N) (p lam : ℝ) (hp : 0 ≤ p)
    (h : PairExitParameters N c R a b x y p lam) (t : ℝ) (ht : 0 ≤ t) :
    (∫ ω, Real.exp (-t*((localTime N a ω (finiteExitDuration N (torusDisk N c R) a ω) x+
      localTime N a ω (finiteExitDuration N (torusDisk N c R) a ω) y)/g))
        ∂exactExitLaw N (torusDisk N c R) a b) ≤ 1-p+p*lam/(lam+t) := by
  have hg : 0 < g := by unfold g; positivity
  have hl := disk_conditioned_pair_laplace_upper hWalk N c R hR hsmall a b x y
    h.entry_pos h.left_pos h.right_pos h.e h.e_pos h.det_pos h.row_left h.row_right
    (t/g) (div_nonneg ht hg.le)
  have he : (∫ ω, Real.exp (-(t/g)*(localTime N a ω (finiteExitDuration N (torusDisk N c R) a ω) x+
      localTime N a ω (finiteExitDuration N (torusDisk N c R) a ω) y))
        ∂exactExitLaw N (torusDisk N c R) a b) =
      (∫ ω, Real.exp (-t*((localTime N a ω (finiteExitDuration N (torusDisk N c R) a ω) x+
      localTime N a ω (finiteExitDuration N (torusDisk N c R) a ω) y)/g))
        ∂exactExitLaw N (torusDisk N c R) a b) := by congr 1; funext ω; congr 1; ring
  rw [he] at hl
  have heq (P : ℝ) : P*(t/g)/(h.e+t/g) = P*t/(g*h.e+t) := by field_simp
  rw [heq] at hl
  exact hl.trans (bernoulli_laplace_envelope_mono p _ (g*h.e) lam t hp
    h.entrance (mul_pos hg h.e_pos) h.rate ht)

theorem disk_exitBlock_pair_softness_bound (hWalk : WalkModelRegular)
    (N : Size) (c : Vertex N) (R : ℝ) (hR : 0 ≤ R) (hsmall : 2*(R+1) < N.val)
    (m : ℕ) (a b : Fin m → Vertex N) (x y : Vertex N) (p lam U : ℝ)
    (hp : 0 ≤ p) (hlam : 0 < lam) (hU : 0 ≤ U)
    (hparam : ∀ i, PairExitParameters N c R (a i) (b i) x y p lam) :
    (exactExitProductLaw N (torusDisk N c R) m a b).real
      {ω | (exitBlockOccupation N (torusDisk N c R) m a ω x+
        exitBlockOccupation N (torusDisk N c R) m a ω y)/g ≤ U} ≤
      Real.exp (-((max (Real.sqrt ((m:ℝ)*p)-Real.sqrt (lam*U)) 0)^2)) := by
  let D := torusDisk N c R
  let ν := fun i => exactExitLaw N D (a i) (b i)
  have (i : Fin m) : IsProbabilityMeasure (ν i) := cond_isProbabilityMeasure
    (ENNReal.toReal_pos_iff.mp (hparam i).entry_pos).1.ne'
  let μ := Measure.pi ν
  let X := fun (i : Fin m) (ω : WalkSample) =>
    (localTime N (a i) ω (finiteExitDuration N D (a i) ω) x+
      localTime N (a i) ω (finiteExitDuration N D (a i) ω) y)/g
  let V := fun (i : Fin m) (ω : Fin m → WalkSample) => X i (ω i)
  have hg : 0 < g := by unfold g; positivity
  have hm (i : Fin m) : Measurable (X i) :=
    ((localTime_measurable_random_time N (a i) x _ (measurable_finiteExitDuration N D (a i))).add
      (localTime_measurable_random_time N (a i) y _ (measurable_finiteExitDuration N D (a i)))).div_const g
  have hV (i : Fin m) : Measurable (V i) := (hm i).comp (measurable_pi_apply i)
  have hV0 (i : Fin m) : ∀ᵐ ω ∂μ, 0 ≤ V i ω := Eventually.of_forall fun ω =>
    div_nonneg (add_nonneg (localTime_nonneg N (a i) x (ω i) _)
      (localTime_nonneg N (a i) y (ω i) _)) hg.le
  have hind : iIndepFun V μ := iIndepFun_pi (fun i => (hm i).aemeasurable)
  have hmean (i : Fin m) (t : ℝ) :
      (∫ ω, Real.exp (-t*V i ω) ∂μ) = ∫ ω, Real.exp (-t*X i ω) ∂ν i := by
    have hi := integral_map (μ := μ) (φ := fun ω : Fin m → WalkSample => ω i)
      (f := fun ω : WalkSample => Real.exp (-t*X i ω))
      (measurable_pi_apply i).aemeasurable ((hm i).const_mul (-t)).exp.aestronglyMeasurable
    rw [(measurePreserving_eval ν i).map_eq] at hi
    exact hi.symm
  have hlap (i : Fin m) (t : ℝ) (ht : 0 ≤ t) :
      (∫ ω, Real.exp (-t*V i ω) ∂μ) ≤ 1-p+p*lam/(lam+t) := by
    rw [hmean]
    exact pair_exit_normalized_laplace hWalk N c R hR hsmall (a i) (b i) x y p lam hp (hparam i) t ht
  have h := chernoff_optimize_sqrt_gap _ ((m:ℝ)*p) lam U
    (mul_nonneg (Nat.cast_nonneg m) hp) hlam hU measureReal_le_one
    (fun t ht => bernoulli_exponential_chernoff μ m V hV hV0 hind p lam U t
      hlam ht (fun i => hlap i t ht))
  simpa only [V, X, ← Finset.sum_div, Finset.sum_add_distrib, μ, ν, D,
    exitBlockOccupation, exactExitProductLaw] using h

end TorusCoverTime.Blocks.B
