import Solutions.Blocks.B.R8DeviationEvents
import Solutions.Blocks.B.R8ExactCountMarginal

/-! Finite decomposition of the actual deviation event after extracting
Theta's scalar consequences. Each slice also embeds into the proved B.20 marginal. -/
noncomputable section
open MeasureTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

def r8ModerateDeviationSlice (N : Size) (c root : Vertex N) (γ q U : ℝ) (p : ℕ × ℕ) :
    Set (WalkSample × ℝ) :=
  {z | 2*((N.val:ℝ)*Real.exp (-((logSize N)^(16*γ))/2)) ≤ periodicDistance c root ∧
    z ∈ r8DeviationEvent N c root γ q U ∧ z ∈ r8CountPairEvent N c root γ q p ∧
    -(logSize N)^(3*γ) ≤ Real.sqrt (q^γ*(p.1:ℝ))-Real.sqrt 2*q ∧
    -(logSize N)^(3*γ) ≤ Real.sqrt ((r8NestedScale γ q)^γ*(p.2:ℝ))-Real.sqrt 2*r8NestedScale γ q}

theorem r8ModerateDeviationSlice_measurable (N : Size) (c root : Vertex N) (γ q U : ℝ) (p : ℕ × ℕ) :
    MeasurableSet (r8ModerateDeviationSlice N c root γ q U p) :=
  (MeasurableSet.const _).inter ((r8DeviationEvent_measurable N c root γ q U).inter
    ((r8CountPairEvent_measurable N c root γ q p).inter ((MeasurableSet.const _).inter (MeasurableSet.const _))))

theorem r8_actual_deviation_pair_cover (γ : ℝ) (hγ : 0 < γ) (hγ1 : γ < 1) :
    ∀ᶠ N : Size in atTop, ∀ c root : Vertex N, ∀ k ∈ r8InteriorIntegerScales N γ, ∀ U : ℝ,
      ∀ z : WalkSample × ℝ, r7LowerBarrier N root γ z →
      2*((N.val:ℝ)*Real.exp (-((logSize N)^(16*γ))/2)) ≤ periodicDistance c root →
      z ∈ r8DeviationEvent N c root γ k U →
      r7TraversalRadius N c root γ k z ≤ 10*logSize N →
      r7TraversalRadius N c root γ (r8NestedScale γ k) z ≤ 10*logSize N →
      ∃ p ∈ r8CountPairs (logSize N), z ∈ r8ModerateDeviationSlice N c root γ k U p := by
  filter_upwards [r8_nested_coarse_range γ hγ hγ1,r8_two_barrier_scalar_bounds γ hγ hγ1,
    blockB_logSize_tendsto.eventually_ge_atTop 1] with N hrange hscalar hL
  intro c root k hk U z hΘ hfar hdev hv hv'
  have hk' := (mem_r8InteriorIntegerScales N γ k).mp hk
  have hinner := hrange k hk'.1 hk'.2
  have hQ1 : 1 ≤ (logSize N)^(16*γ) := Real.one_le_rpow hL (by positivity)
  have hk1 : 1 ≤ (k:ℝ) := by linarith [Real.rpow_nonneg (logSize_pos N).le (16*γ)]
  have hl1 : 1 ≤ r8NestedScale γ k := hQ1.trans hinner.1
  obtain ⟨p,hp,hpair⟩ := r8_actual_count_pair_cover N c root γ k z
    (Real.one_le_rpow hk1 hγ.le) (Real.one_le_rpow hl1 hγ.le) hv hv'
  have hs := hscalar c root k hk z hΘ hfar
  have he := r8_count_pair_radii N c root γ k p z hpair
  refine ⟨p,hp,hfar,hdev,hpair,?_,?_⟩
  · simpa only [he.1] using hs.1
  · simpa only [he.2] using hs.2

theorem r8_deviation_slice_le_exact_count (N : Size) (c : Vertex N) (γ q U l r : ℝ) (p : ℕ × ℕ) :
    r7LoopEventMass N (fun root => r8ModerateDeviationSlice N c root γ q U p) l r ≤
      r8ExactCountMass N c γ q p.1 l r := by
  apply r7LoopEventMass_mono_ae
  intro root
  exact Eventually.of_forall (by
    intro ω t ht hz
    refine ⟨?_,hz.2.2.1.1⟩
    have hR : 0 ≤ (N.val:ℝ)*Real.exp (-((logSize N)^(16*γ))/2) := by positivity
    linarith [hz.1])

end TorusCoverTime.Blocks.B
