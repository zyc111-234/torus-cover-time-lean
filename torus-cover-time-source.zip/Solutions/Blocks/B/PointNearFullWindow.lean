import Solutions.Blocks.B.PointNearProbability

/-! A fixed root neighborhood is empty of soft sites simultaneously throughout
the window, by occupation monotonicity. This does not assert the analogous
moving-terminal supremum, which would be a different event. -/
noncomputable section
open MeasureTheory Filter Set Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

theorem pointNearSoftEvent_antitone (N : Size) (a root : Vertex N) (R u s t : ℝ)
    (hst : s ≤ t) (ω : WalkSample) (h : (ω,t) ∈ pointNearSoftEvent N a root R u) :
    (ω,s) ∈ pointNearSoftEvent N a root R u := by
  obtain ⟨c,hc,hu⟩ := h
  exact ⟨c,hc,(localTime_mono_time N a ω c hst).trans hu⟩

theorem point_near_full_window_eq (N : Size) (a root : Vertex N) (R u l r : ℝ) (hlr : l ≤ r) :
    {ω | ∃ t ∈ Icc l r, (ω,t) ∈ pointNearSoftEvent N a root R u} =
      {ω | (ω,l) ∈ pointNearSoftEvent N a root R u} := by
  ext ω
  constructor
  · rintro ⟨t,ht,h⟩
    exact pointNearSoftEvent_antitone N a root R u l t ht.1 ω h
  · intro h
    exact ⟨l,⟨le_rfl,hlr⟩,h⟩

theorem point_near_full_window_measurable (N : Size) (a root : Vertex N) (R u l r : ℝ) (hlr : l ≤ r) :
    MeasurableSet {ω | ∃ t ∈ Icc l r, (ω,t) ∈ pointNearSoftEvent N a root R u} := by
  rw [point_near_full_window_eq N a root R u l r hlr]
  exact (pointNearSoftEvent_measurable N a root R u).preimage (measurable_id.prodMk measurable_const)

theorem point_near_full_window_uniform (hWalk : WalkModelRegular) (γ C u H : ℝ)
    (hγ : 0 < γ) (hC : 0 ≤ C) (hH : 0 ≤ H) :
    ∀ ε : ℝ, 0 < ε → ∀ᶠ N : Size in atTop, ∀ a root : Vertex N, ∀ l r : ℝ,
      l ≤ r → phaseACenter N-H*timeScale N ≤ l →
      walkLaw.real {ω | ∃ t ∈ Icc l r,
        (ω,t) ∈ pointNearSoftEvent N a root (pointNearRadius N γ C) u} ≤ ε := by
  intro ε hε
  filter_upwards [point_near_central_uniform hWalk γ C u H hγ hC hH ε hε] with N hN
  intro a root l r hlr hlo
  rw [point_near_full_window_eq N a root _ u l r hlr]
  exact (hN a root l hlo).1

end TorusCoverTime.Blocks.B
