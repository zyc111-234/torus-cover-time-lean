import Solutions.Blocks.B.ShiftedAnnulusGeometry

/-! Moving to the explicit grid changes the logarithmic annulus width by
O(exp(-w)). This statement concerns the actual perturbed radii. -/

noncomputable section
open Filter
open scoped Topology
namespace TorusCoverTime.Blocks.B

theorem log_radius_relative_tolerance (r R d : ℝ) (hR : 0 < R) (hr : R/2 ≤ r)
    (hd : |r-R| ≤ d) : |Real.log r-Real.log R| ≤ 2*d/R := by
  have hr0 : 0 < r := (half_pos hR).trans_le hr
  have hh := log_near_one_abs (r/R) ((le_div_iff₀ hR).mpr (by linarith))
  rw [Real.log_div hr0.ne' hR.ne',show r/R-1 = (r-R)/R by field_simp <;> ring,
    abs_div,abs_of_pos hR] at hh
  have hm := mul_le_mul_of_nonneg_left (div_le_div_of_nonneg_right hd hR.le) (by norm_num : (0:ℝ) ≤ 2)
  exact (hh.trans hm).trans_eq (by ring)

theorem shifted_annulus_width_bound (ρ R d : ℝ) (hρ : 0 < ρ) (hρR : ρ ≤ R)
    (hd : 0 ≤ d) (hdρ : d ≤ ρ/2) :
    0 ≤ (Real.log (R+d)-Real.log (ρ-d))-(Real.log R-Real.log ρ) ∧
      (Real.log (R+d)-Real.log (ρ-d))-(Real.log R-Real.log ρ) ≤ 4*d/ρ := by
  have hR : 0 < R := hρ.trans_le hρR
  have hinner : 0 < ρ-d := by linarith
  have ho := log_radius_relative_tolerance (R+d) R d hR (by linarith) (by simp [abs_of_nonneg hd])
  have hi := log_radius_relative_tolerance (ρ-d) ρ d hρ (by linarith)
    (by simpa only [sub_sub_cancel_left,abs_neg,abs_of_nonneg hd] using le_refl d)
  have hs := abs_sub (Real.log (R+d)-Real.log R) (Real.log (ρ-d)-Real.log ρ)
  have he : Real.log (R+d)-Real.log R-(Real.log (ρ-d)-Real.log ρ) =
      (Real.log (R+d)-Real.log (ρ-d))-(Real.log R-Real.log ρ) := by ring
  rw [he] at hs
  have hdiv := div_le_div_of_nonneg_left (mul_nonneg (by norm_num : (0:ℝ) ≤ 2) hd) hρ hρR
  constructor
  · have hl1 := Real.log_le_log hR (show R ≤ R+d by linarith)
    have hl2 := Real.log_le_log hinner (show ρ-d ≤ ρ by linarith)
    linarith
  · have ha := le_abs_self ((Real.log (R+d)-Real.log (ρ-d))-(Real.log R-Real.log ρ))
    have hsum : 2*d/ρ+2*d/ρ = 4*d/ρ := by ring
    linarith

theorem r7_grid_annulus_width (q w : ℝ) (hw : Real.log 4 ≤ w) :
    0 < Real.exp (q+w)-2*Real.exp q ∧
    w ≤ Real.log (Real.exp (q+2*w)+2*Real.exp q)-Real.log (Real.exp (q+w)-2*Real.exp q) ∧
    Real.log (Real.exp (q+2*w)+2*Real.exp q)-Real.log (Real.exp (q+w)-2*Real.exp q) ≤ w+8*Real.exp (-w) := by
  have h4 : (4:ℝ) ≤ Real.exp w := by simpa only [Real.exp_log (by norm_num : (0:ℝ) < 4)] using Real.exp_le_exp.mpr hw
  have hw0 : 0 ≤ w := by have := Real.log_nonneg (by norm_num : (1:ℝ) ≤ 4); linarith
  have hd : 2*Real.exp q ≤ Real.exp (q+w)/2 := by
    rw [Real.exp_add]
    have hm := mul_le_mul_of_nonneg_left h4 (Real.exp_pos q).le
    linarith
  have hρR := Real.exp_le_exp.mpr (show q+w ≤ q+2*w by linarith)
  have hh := shifted_annulus_width_bound (Real.exp (q+w)) (Real.exp (q+2*w)) (2*Real.exp q)
    (Real.exp_pos _) hρR (by positivity) hd
  simp only [Real.log_exp] at hh
  have he : 4*(2*Real.exp q)/Real.exp (q+w) = 8*Real.exp (-w) := by
    rw [Real.exp_add,Real.exp_neg]
    field_simp <;> ring
  rw [he] at hh
  exact ⟨by have := Real.exp_pos (q+w); linarith,by linarith [hh.1],by linarith [hh.2]⟩

end TorusCoverTime.Blocks.B
