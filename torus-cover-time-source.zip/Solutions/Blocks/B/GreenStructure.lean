import Solutions.Blocks.B.FiniteSpectrum

/-! Basic Green-kernel facts used before the quantitative spatial estimates. -/

noncomputable section
open scoped BigOperators

namespace TorusCoverTime.Blocks.B

@[simp] lemma finiteCosine_zero (N : Size) (k : Vertex N) :
    finiteCosine N k 0 = 1 := by
  simp [finiteCosine, fourierAngle]

lemma greenKernel_diagonal (N : Size) (x : Vertex N) :
    greenKernel N x x = greenDiagonal N := by
  simp [greenKernel, greenDiagonal]

lemma greenDiagonal_eq_sum (N : Size) :
    greenDiagonal N = (∑ k ∈ nonzeroFrequencies N, 1 / finiteEigenvalue N k) / vertexCount N := by
  simp [greenDiagonal, greenKernel]

lemma greenDiagonal_pos (N : Size) : 0 < greenDiagonal N := by
  rw [greenDiagonal_eq_sum]
  apply div_pos _ (vertexCount_pos N)
  obtain ⟨k, hk, _⟩ := spectralGap_attained N
  exact Finset.sum_pos' (fun i hi => (one_div_pos.mpr (eigenvalue_pos_of_nonzero N hi)).le)
    ⟨k, hk, one_div_pos.mpr (eigenvalue_pos_of_nonzero N hk)⟩

lemma abs_greenKernel_le_diagonal (N : Size) (x y : Vertex N) :
    |greenKernel N x y| ≤ greenDiagonal N := by
  rw [greenKernel, greenDiagonal_eq_sum, abs_div, abs_of_pos (vertexCount_pos N)]
  apply div_le_div_of_nonneg_right _ (vertexCount_pos N).le
  apply (Finset.abs_sum_le_sum_abs _ _).trans
  apply Finset.sum_le_sum
  intro k hk
  rw [abs_div, abs_of_pos (eigenvalue_pos_of_nonzero N hk)]
  exact div_le_div_of_nonneg_right (Real.abs_cos_le_one _) (eigenvalue_pos_of_nonzero N hk).le

lemma green_difference_nonneg (N : Size) (x y : Vertex N) :
    0 ≤ greenKernel N x x - greenKernel N x y := by
  rw [greenKernel_diagonal]
  exact sub_nonneg.mpr ((le_abs_self _).trans (abs_greenKernel_le_diagonal N x y))

end TorusCoverTime.Blocks.B
