import Solutions.Blocks.B.DirichletIntegerClockBounds

noncomputable section
open MeasureTheory ProbabilityTheory Classical
open scoped BigOperators
namespace TorusCoverTime.Blocks.B

theorem finite_event_probability_bound {Ω I : Type*} [MeasurableSpace Ω] [Fintype I]
    {μ : Measure Ω} [IsProbabilityMeasure μ] (E : I → Set Ω) (d : ℝ)
    (h : ∀ i, μ.real (E i)≤d) : μ.real {ω | ∃ i, ω∈E i}≤(Fintype.card I:ℝ)*d := by
  rw [Set.ofPred_exists]
  calc
    _ ≤ ∑ i, μ.real (E i) := measureReal_iUnion_fintype_le E
    _ ≤ ∑ _i : I, d := Finset.sum_le_sum (fun i _ => h i)
    _ = _ := by simp

namespace GaussianClockPath
variable {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
variable {M : ℕ} (W : GaussianClockPath μ (M+1))

theorem bridge_variance_from_clock_error (L C : ℝ) (hv : 0<W.clock (Fin.last (M+1)))
    (herr : ∀ i, |W.clock i-sparseClockTime L 1 (M+1) i/2|≤C) (i : Fin (M+2)) (hi : i.val≤M) :
    Var[fun ω => W.bridge ω i;μ]≤(i.val:ℝ)/2+C ∧
      Var[fun ω => W.bridge ω i;μ]≤(L-i.val)/2+2*C := by
  have hx := abs_le.mp (herr i)
  have hlast := abs_le.mp (herr (Fin.last (M+1)))
  simp only [sparseClockTime,if_neg (show i.val≠M+1 by omega),Nat.cast_one,one_mul] at hx
  simp only [sparseClockTime,Fin.val_last,if_true] at hlast
  have hh := W.bridge_variance_le_ends hv i
  constructor <;> linarith

theorem bridge_negative_upper_tail (i : Fin (M+2)) (V a : ℝ) (hV : 0<V) (ha : 0≤a)
    (hvar : Var[fun ω => W.bridge ω i;μ]≤V) :
    μ.real {ω | a≤-W.bridge ω i}≤Real.exp (-a^2/(2*V)) := by
  have hg := (W.bridge_gaussian.map_fun (ContinuousLinearMap.proj i)).neg
  have hm : (∫ ω, -W.bridge ω i ∂μ)=0 := by rw [integral_neg,W.bridge_mean_zero,neg_zero]
  exact centered_gaussian_upper_tail μ (fun ω => -W.bridge ω i) hg hm V a hV ha
    (by simpa only [variance_fun_neg] using hvar)

def oppositeBranch (A : ℝ) : Set Ω :=
  {ω | ∃ i : Fin (M+2), i.val≤M ∧ A≤(i.val:ℝ) ∧ W.bridge ω i≤-(i.val:ℝ)}

def endpointOvershoot (L A : ℝ) : Set Ω :=
  {ω | ∃ i : Fin (M+2), i.val≤M ∧ ((i.val:ℝ)<A ∨ L-A<(i.val:ℝ)) ∧ 2*A≤-W.bridge ω i}

theorem oppositeBranch_bound (L C A : ℝ) (hA : 0<A) (hC : 2*C≤A)
    (hv : 0<W.clock (Fin.last (M+1)))
    (herr : ∀ i, |W.clock i-sparseClockTime L 1 (M+1) i/2|≤C) :
    μ.real (W.oppositeBranch A)≤(M+2:ℕ)*Real.exp (-A/2) := by
  have hb := finite_event_probability_bound (μ := μ) (fun i : Fin (M+2) =>
    {ω | i.val≤M ∧ A≤(i.val:ℝ) ∧ W.bridge ω i≤-(i.val:ℝ)}) (Real.exp (-A/2))
  simp only [Fintype.card_fin,Set.mem_ofPred_eq] at hb
  unfold oppositeBranch
  apply hb
  intro i
  by_cases hi : i.val≤M ∧ A≤(i.val:ℝ)
  · have hi0 : (0:ℝ) < i.val := hA.trans_le hi.2
    have hvb : Var[fun ω => W.bridge ω i;μ] ≤ i.val := by
      have hh := (W.bridge_variance_from_clock_error L C hv herr i hi.1).1
      linarith
    have hh := W.bridge_negative_upper_tail i i.val i.val hi0 hi0.le hvb
    have hsub : {ω | i.val≤M ∧ A≤(i.val:ℝ) ∧ W.bridge ω i≤-(i.val:ℝ)}⊆{ω | (i.val:ℝ)≤-W.bridge ω i} := by
      rintro ω ⟨_,_,hω⟩
      change (i.val:ℝ)≤-W.bridge ω i
      linarith
    refine ((measureReal_mono (μ := μ) hsub).trans hh).trans (Real.exp_le_exp.mpr ?_)
    have he : -((i.val:ℝ)^2)/(2*i.val)=-(i.val:ℝ)/2 := by field_simp [hi0.ne']
    rw [he]
    linarith [hi.2]
  · have he : {ω : Ω | i.val≤M ∧ A≤(i.val:ℝ) ∧ W.bridge ω i≤-(i.val:ℝ)}=∅ := by
      ext ω; simp only [Set.mem_ofPred_eq,Set.mem_empty_iff_false,iff_false]; intro hh; exact hi ⟨hh.1,hh.2.1⟩
    rw [he,measureReal_empty]
    positivity

theorem endpointOvershoot_bound (L C A : ℝ) (hA : 0<A) (hC : 4*C≤A)
    (hv : 0<W.clock (Fin.last (M+1)))
    (herr : ∀ i, |W.clock i-sparseClockTime L 1 (M+1) i/2|≤C) :
    μ.real (W.endpointOvershoot L A)≤(M+2:ℕ)*Real.exp (-A/2) := by
  have hb := finite_event_probability_bound (μ := μ) (fun i : Fin (M+2) =>
    {ω | i.val≤M ∧ ((i.val:ℝ)<A ∨ L-A<(i.val:ℝ)) ∧ 2*A≤-W.bridge ω i}) (Real.exp (-A/2))
  simp only [Fintype.card_fin,Set.mem_ofPred_eq] at hb
  unfold endpointOvershoot
  apply hb
  intro i
  by_cases hi : i.val≤M ∧ ((i.val:ℝ)<A ∨ L-A<(i.val:ℝ))
  · have hvb : Var[fun ω => W.bridge ω i;μ]≤A := by
      have hh := W.bridge_variance_from_clock_error L C hv herr i hi.1
      rcases hi.2 with h | h <;> linarith
    have hh := W.bridge_negative_upper_tail i A (2*A) hA (by linarith) hvb
    have hsub : {ω | i.val≤M ∧ ((i.val:ℝ)<A ∨ L-A<(i.val:ℝ)) ∧ 2*A≤-W.bridge ω i}⊆
        {ω | 2*A≤-W.bridge ω i} := fun _ hω => hω.2.2
    refine ((measureReal_mono (μ := μ) hsub).trans hh).trans (Real.exp_le_exp.mpr ?_)
    have he : -(2*A)^2/(2*A)=-2*A := by field_simp [hA.ne']
    rw [he]
    linarith
  · have he : {ω : Ω | i.val≤M ∧ ((i.val:ℝ)<A ∨ L-A<(i.val:ℝ)) ∧ 2*A≤-W.bridge ω i}=∅ := by
      ext ω; simp only [Set.mem_ofPred_eq,Set.mem_empty_iff_false,iff_false]; intro hh; exact hi ⟨hh.1,hh.2.1⟩
    rw [he,measureReal_empty]
    positivity

end GaussianClockPath
end TorusCoverTime.Blocks.B
