import Solutions.Blocks.B.FiniteTraversalRecord
import Solutions.Blocks.B.OutwardRecordLaws

/-! Exact specified-exit record laws for nested traversal counts. These are
pushforwards of the original path counts, not counts of a padded infinite path. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

theorem exactExitRecord_nestedCount_law (N : Size) (O I J : Finset (Vertex N))
    (hIJ : I ⊆ J) (hI : I.Nonempty) (a b : Vertex N) (ha : a ∉ J) :
    (exactExitRecordLaw N O a b).map (finiteTraversalRecordCount N I J a) =
      (exactExitLaw N O a b).map (nestedTraversalCount N O I J a) := by
  rw [exactExitRecordLaw, Measure.map_map (finiteTraversalRecordCount_measurable N I J a)
    (finiteExitRecord_measurable N O a)]
  apply Measure.map_congr
  exact (show exactExitLaw N O a b ≪ walkLaw from cond_absolutelyContinuous).ae_le
    (finiteTraversalRecordCount_exit_ae N O I J hIJ hI a ha)

def recordProductNestedCount (N : Size) (I J : Finset (Vertex N)) (m : ℕ)
    (a : Fin m → Vertex N) (p : Fin m → ℕ × WalkSample) : ℝ :=
  ∑ i, (finiteTraversalRecordCount N I J (a i) (p i):ℝ)

theorem recordProductNestedCount_measurable (N : Size) (I J : Finset (Vertex N))
    (m : ℕ) (a : Fin m → Vertex N) : Measurable (recordProductNestedCount N I J m a) :=
  Finset.measurable_sum _ fun i _ =>
    ((measurable_of_countable (fun k : ℕ => (k:ℝ))).comp
      (finiteTraversalRecordCount_measurable N I J (a i))).comp (measurable_pi_apply i)

theorem exactExitRecordProduct_nestedCount_law (N : Size) (O I J : Finset (Vertex N))
    (hIJ : I ⊆ J) (hI : I.Nonempty) (m : ℕ) (a b : Fin m → Vertex N)
    (ha : ∀ i, a i ∉ J) :
    (exactExitRecordProductLaw N O m a b).map (recordProductNestedCount N I J m a) =
      (exactExitProductLaw N O m a b).map
        (fun ω => ∑ i, (nestedTraversalCount N O I J (a i) (ω i):ℝ)) := by
  let castSum := fun v : Fin m → ℕ => ∑ i, (v i:ℝ)
  have hs : Measurable castSum := measurable_of_countable _
  have hr : Measurable (fun p : Fin m → ℕ × WalkSample =>
      fun i => finiteTraversalRecordCount N I J (a i) (p i)) :=
    measurable_pi_lambda _ fun i =>
      (finiteTraversalRecordCount_measurable N I J (a i)).comp (measurable_pi_apply i)
  have hw : Measurable (fun ω : Fin m → WalkSample =>
      fun i => nestedTraversalCount N O I J (a i) (ω i)) :=
    measurable_pi_lambda _ fun i =>
      (nestedTraversalCount_measurable N O I J (a i)).comp (measurable_pi_apply i)
  change (Measure.pi (fun i => exactExitRecordLaw N O (a i) (b i))).map
      (castSum ∘ (fun p i => finiteTraversalRecordCount N I J (a i) (p i))) =
    (Measure.pi (fun i => exactExitLaw N O (a i) (b i))).map
      (castSum ∘ (fun ω i => nestedTraversalCount N O I J (a i) (ω i)))
  rw [← Measure.map_map hs hr, ← Measure.map_map hs hw,
    Measure.pi_map_pi (fun i : Fin m => (finiteTraversalRecordCount_measurable N I J (a i)).aemeasurable),
    Measure.pi_map_pi (fun i : Fin m => (nestedTraversalCount_measurable N O I J (a i)).aemeasurable)]
  simp_rw [exactExitRecord_nestedCount_law N O I J hIJ hI _ _ (ha _)]

theorem exactExitRecordProduct_nestedCount_event (N : Size) (O I J : Finset (Vertex N))
    (hIJ : I ⊆ J) (hI : I.Nonempty) (m : ℕ) (a b : Fin m → Vertex N)
    (ha : ∀ i, a i ∉ J) (h U : ℝ) :
    (exactExitRecordProductLaw N O m a b).real {p | h*recordProductNestedCount N I J m a p ≤ U} =
      (exactExitProductLaw N O m a b).real
        {ω | h*(∑ i, (nestedTraversalCount N O I J (a i) (ω i):ℝ)) ≤ U} := by
  have hE : MeasurableSet {x : ℝ | h*x ≤ U} :=
    measurableSet_le (measurable_id.const_mul h) measurable_const
  have hw : Measurable (fun ω : Fin m → WalkSample =>
      ∑ i, (nestedTraversalCount N O I J (a i) (ω i):ℝ)) :=
    Finset.measurable_sum _ fun i _ =>
      ((measurable_of_countable (fun k : ℕ => (k:ℝ))).comp
        (nestedTraversalCount_measurable N O I J (a i))).comp (measurable_pi_apply i)
  have he := congrArg (fun μ : Measure ℝ => μ {x | h*x ≤ U})
    (exactExitRecordProduct_nestedCount_law N O I J hIJ hI m a b ha)
  rw [Measure.map_apply (recordProductNestedCount_measurable N I J m a) hE,
    Measure.map_apply hw hE] at he
  exact congrArg ENNReal.toReal he

end TorusCoverTime.Blocks.B
