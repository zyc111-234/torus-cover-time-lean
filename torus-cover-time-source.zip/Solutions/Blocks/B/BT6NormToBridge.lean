import Solutions.Blocks.B.BT6NormBridgeData
import Solutions.Blocks.B.GaussianBridgeGridTransfer

noncomputable section
open MeasureTheory ProbabilityTheory Classical
namespace TorusCoverTime.Blocks.B

def bt6BarrierEvent (N : Size) (root : Vertex N) (E : Finset (Vertex N)) (x : Vertex N)
    (A S η δ t : ℝ) : Set (FiniteFieldSample N) :=
  {ξ | ∃ a : ℝ, |a-harmonicExtremeCenter N|≤η ∧
    (∀ q : ℕ, A≤(q:ℝ) → (q:ℝ)≤logSize N-A →
      Real.sqrt 2*(q:ℝ)-δ≤bt6ExitNorm N x q (dirichletConditionedField N root E x t ξ) a) ∧
    ∃ q : ℕ, S≤(q:ℝ) ∧ (q:ℝ)≤logSize N-S ∧
      bt6ExitNorm N x q (dirichletConditionedField N root E x t ξ) a≤Real.sqrt 2*(q:ℝ)+δ}

theorem bt6BarrierEvent_subset (N : Size) (root c x : Vertex N) (ρ : ℝ) (M : ℕ)
    (hρ : 0<ρ) (hR : 1≤ρ*(N.val:ℝ)) (hsmall : 2*(ρ*(N.val:ℝ)+1)<N.val)
    (hdeep : periodicDistance x c+(Real.exp ((M:ℝ)+1)+1)≤ρ*(N.val:ℝ)/2)
    (hroot : root∉torusDisk N c (ρ*(N.val:ℝ))) (hL : 1≤logSize N)
    (hV : 0<dirichletClockLS N root (torusDisk N c (ρ*(N.val:ℝ))) x)
    (A S η δ t : ℝ) (hA : 1≤A) (hAS : A≤S) (hlast : logSize N-S≤M)
    (hη : 0≤η) (hδ : 0≤δ) (ht : |t-harmonicExtremeCenter N|≤η)
    (hbudget : 2*δ+6*bt6BridgeError (logSize N) (bt6ClockError ρ) η≤A) :
    bt6BarrierEvent N root (torusDisk N c (ρ*(N.val:ℝ))) x A S η δ t ⊆
      (bt6IntegerPath N root c x (ρ*(N.val:ℝ)) M hdeep hroot).rawMiddleContact (logSize N) A S ∪
        bt6ResidualFailure N root (torusDisk N c (ρ*(N.val:ℝ))) x M t := by
  let E := torusDisk N c (ρ*(N.val:ℝ))
  let W := bt6IntegerPath N root c x (ρ*(N.val:ℝ)) M hdeep hroot
  let e := bt6BridgeError (logSize N) (bt6ClockError ρ) η
  have heb := bt6BridgeError_bounds (logSize N) (bt6ClockError ρ) η hL (bt6ClockError_pos ρ).le hη
  have he0 : 0≤e := heb.1
  have hs : 1≤Real.sqrt (2:ℝ) := by nlinarith [Real.sq_sqrt (by norm_num : (0:ℝ)≤2),Real.sqrt_nonneg (2:ℝ)]
  intro ξ hbad
  by_cases hres : ξ∈bt6ResidualFailure N root E x M t
  · exact Or.inr hres
  apply Or.inl
  obtain ⟨a,ha,hlower,q,hqS,hqL,hupper⟩ := hbad
  have data (i : Fin (M+2)) (hiM : i.val≤M) (hi0 : 0< i.val) :
      bt6ExitNorm N x i.val (dirichletConditionedField N root E x t ξ) a=
        Real.sqrt ((bt6ConditionedMean N root E x i.val t a ξ)^2+bt6ResidualSquare N root E x i.val t ξ) ∧
      |bt6ConditionedMean N root E x i.val t a ξ+Real.sqrt 2*(i.val:ℝ)+W.bridge ξ i|≤e ∧
      0≤bt6ResidualSquare N root E x i.val t ξ ∧
      bt6ResidualSquare N root E x i.val t ξ≤(Real.sqrt 2*(i.val:ℝ))*e := by
    have hiN : i.val≠M+1 := by omega
    have hiZ : i.val≠0 := by omega
    have hsub := bt6IntegerDomain_subset N c x (ρ*(N.val:ℝ)) M hdeep i
    simp only [bt6IntegerDomain,if_neg hiZ,if_neg hiN] at hsub
    have hr0 := bt6ResidualSquare_nonneg N root E x i.val t ξ
    have hr1 : bt6ResidualSquare N root E x i.val t ξ<dirichletResidualLogScaleConstant*(i.val:ℝ)*(Real.log (logSize N))^2 :=
      lt_of_not_ge (fun hh => hres ⟨i.val,hi0,hiM,hh⟩)
    have hreg := bt6_integer_regression_error N root c x ρ M hρ hR hsmall hdeep hroot hL hV i hiZ hiN η t a ht ha ξ
    refine ⟨bt6_conditioned_norm N root E x i.val hsub hroot hV t a ξ,hreg.trans heb.2.2,hr0,?_⟩
    calc
      _ ≤ (i.val:ℝ)*(dirichletResidualLogScaleConstant*(Real.log (logSize N))^2) := by nlinarith [hr1]
      _ ≤ (i.val:ℝ)*e := mul_le_mul_of_nonneg_left heb.2.1 (by positivity)
      _ ≤ _ := by nlinarith [mul_nonneg (show 0≤Real.sqrt (2:ℝ)-1 by linarith) (mul_nonneg (by positivity : 0≤(i.val:ℝ)) he0)]
  constructor
  · intro i hiM hiA hiL
    have hi0 : 0< i.val := by exact_mod_cast (show (0:ℝ)< i.val by linarith)
    have hd := data i hiM hi0
    have hlo := hlower i.val hiA hiL
    rw [hd.1] at hlo
    have hδq : δ≤(Real.sqrt 2*(i.val:ℝ))/2 := by
      have hh := mul_nonneg (show 0≤Real.sqrt (2:ℝ)-1 by linarith) (show 0≤(i.val:ℝ) by positivity)
      change 2*δ+6*e≤A at hbudget
      linarith
    have hh := norm_lower_bridge_branches (Real.sqrt 2*(i.val:ℝ)) δ e _ (W.bridge ξ i) _
      (by positivity) hδ hδq he0 hd.2.2.1 hd.2.2.2 hlo hd.2.1
    rcases hh with hh | hh
    · left
      change 2*δ+6*e≤A at hbudget
      linarith
    · right
      have hprod := mul_nonneg (show 0≤Real.sqrt (2:ℝ)-1 by linarith) (show 0≤(i.val:ℝ) by positivity)
      change 2*δ+6*e≤A at hbudget
      linarith
  · have hqM : q≤M := by exact_mod_cast (hqL.trans hlast)
    have hq0 : 0<q := by exact_mod_cast (show (0:ℝ)<q by linarith)
    let i : Fin (M+2) := ⟨q,by omega⟩
    have hd := data i hqM hq0
    refine ⟨i,hqM,hqS,hqL,?_⟩
    change bt6ExitNorm N x i.val (dirichletConditionedField N root E x t ξ) a≤_ at hupper
    rw [hd.1] at hupper
    have hh := norm_contact_bridge (Real.sqrt 2*(i.val:ℝ)) δ e _ (W.bridge ξ i) _ hd.2.2.1 he0 hupper hd.2.1
    change 2*δ+6*e≤A at hbudget
    linarith

end TorusCoverTime.Blocks.B

