import Solutions.Blocks.B.MassiveDirichlet

/-! The positive Dirichlet resolvent kernel of the original generator.
All sources and boundary values are proved, including exterior source points. -/

noncomputable section
open Classical
namespace TorusCoverTime.Blocks.B

def massiveGreen (N : Size) (D : Finset (Vertex N)) (μ : ℝ) (hμ : 0 < μ)
    (x y : Vertex N) : ℝ :=
  massiveDirichletSolution N D μ hμ (fun z => if z ∈ D ∧ z = y then 1 else 0) x

theorem massiveGreen_boundary (N : Size) (D : Finset (Vertex N)) (μ : ℝ) (hμ : 0 < μ)
    (x y : Vertex N) (hx : x ∉ D) : massiveGreen N D μ hμ x y = 0 := by
  unfold massiveGreen
  rw [massiveDirichletSolution_boundary N D μ hμ _ x hx]
  simp only [hx, false_and, if_false]

theorem massiveGreen_generator (N : Size) (D : Finset (Vertex N)) (μ : ℝ) (hμ : 0 < μ)
    (x y : Vertex N) (hx : x ∈ D) :
    μ * massiveGreen N D μ hμ x y - generator N (fun z => massiveGreen N D μ hμ z y) x =
      if x = y then 1 else 0 := by
  have h := massiveDirichletSolution_generator N D μ hμ
    (fun z => if z ∈ D ∧ z = y then 1 else 0) x hx
  simpa only [massiveGreen, hx, true_and] using h

theorem massiveGreen_nonneg (N : Size) (D : Finset (Vertex N)) (μ : ℝ) (hμ : 0 < μ)
    (x y : Vertex N) : 0 ≤ massiveGreen N D μ hμ x y :=
  massiveDirichletSolution_nonneg N D μ hμ _ (fun _ => by positivity) x

theorem massiveGreen_pairing (N : Size) (D : Finset (Vertex N)) (μ : ℝ) (hμ : 0 < μ)
    (u v : Vertex N) :
    μ * (∑ z, massiveGreen N D μ hμ z u * massiveGreen N D μ hμ z v) +
      dirichletPairing N (fun z => massiveGreen N D μ hμ z u)
        (fun z => massiveGreen N D μ hμ z v) = massiveGreen N D μ hμ v u := by
  unfold dirichletPairing
  rw [Finset.mul_sum, ← Finset.sum_add_distrib]
  have he (x : Vertex N) :
      μ * (massiveGreen N D μ hμ x u * massiveGreen N D μ hμ x v) +
        massiveGreen N D μ hμ x u * (-generator N (fun z => massiveGreen N D μ hμ z v) x) =
      massiveGreen N D μ hμ x u * (if x = v then 1 else 0) := by
    by_cases hx : x ∈ D
    · have hh := massiveGreen_generator N D μ hμ x v hx
      calc
        _ = massiveGreen N D μ hμ x u * (μ * massiveGreen N D μ hμ x v -
          generator N (fun z => massiveGreen N D μ hμ z v) x) := by ring
        _ = _ := by rw [hh]
    · simp only [massiveGreen_boundary N D μ hμ x _ hx, mul_zero, zero_mul, add_zero]
  simp only [he, mul_ite, mul_one, mul_zero]
  simp

theorem massiveGreen_symm (N : Size) (D : Finset (Vertex N)) (μ : ℝ) (hμ : 0 < μ)
    (x y : Vertex N) : massiveGreen N D μ hμ x y = massiveGreen N D μ hμ y x := by
  rw [← massiveGreen_pairing N D μ hμ y x, ← massiveGreen_pairing N D μ hμ x y]
  rw [dirichletPairing_symm N (fun z => massiveGreen N D μ hμ z y)]
  congr 2
  apply Finset.sum_congr rfl
  intro z _
  ring

theorem massiveGreen_boundary_right (N : Size) (D : Finset (Vertex N)) (μ : ℝ) (hμ : 0 < μ)
    (x y : Vertex N) (hy : y ∉ D) : massiveGreen N D μ hμ x y = 0 := by
  rw [massiveGreen_symm N D μ hμ x y]
  exact massiveGreen_boundary N D μ hμ y x hy

theorem massiveGreen_solves (N : Size) (D : Finset (Vertex N)) (μ : ℝ) (hμ : 0 < μ)
    (f : Vertex N → ℝ) (x : Vertex N) (hx : x ∈ D) :
    μ * (∑ y, f y * massiveGreen N D μ hμ x y) -
      generator N (fun z => ∑ y, f y * massiveGreen N D μ hμ z y) x = f x := by
  rw [generator_sum, Finset.mul_sum, ← Finset.sum_sub_distrib]
  have he (y : Vertex N) :
      μ * (f y * massiveGreen N D μ hμ x y) -
        generator N (fun z => f y * massiveGreen N D μ hμ z y) x =
      f y * (if x = y then 1 else 0) := by
    rw [generator_mul_left]
    calc
      _ = f y * (μ * massiveGreen N D μ hμ x y -
          generator N (fun z => massiveGreen N D μ hμ z y) x) := by ring
      _ = _ := by rw [massiveGreen_generator N D μ hμ x y hx]
  simp only [he, mul_ite, mul_one, mul_zero]
  simp

theorem massiveGreen_solution (N : Size) (D : Finset (Vertex N)) (μ : ℝ) (hμ : 0 < μ)
    (f U : Vertex N → ℝ) (hb : ∀ x, x ∉ D → U x = 0)
    (hg : ∀ x ∈ D, μ * U x - generator N U x = f x) :
    U = fun x => ∑ y, f y * massiveGreen N D μ hμ x y := by
  apply massive_dirichlet_unique N D μ hμ
  · intro x hx
    simp only [hb x hx, massiveGreen_boundary N D μ hμ x _ hx, mul_zero, Finset.sum_const_zero]
  · intro x hx
    rw [hg x hx, massiveGreen_solves N D μ hμ f x hx]

theorem harmonic_massive_average (N : Size) (D : Finset (Vertex N)) (μ : ℝ) (hμ : 0 < μ)
    (f : Vertex N → ℝ) (hf : ∀ x, 0 ≤ f x) (hg : ∀ x ∈ D, generator N f x = 0)
    (x : Vertex N) : μ * (∑ y, massiveGreen N D μ hμ x y * f y) ≤ f x := by
  let U := fun z => ∑ y, (μ * f y) * massiveGreen N D μ hμ z y
  have hU (z : Vertex N) (hz : z ∉ D) : U z = 0 := by
    simp only [U, massiveGreen_boundary N D μ hμ z _ hz, mul_zero, Finset.sum_const_zero]
  have hm := massive_maximum_principle N D μ hμ (f-U) (by
    intro z hz
    simp only [Pi.sub_apply, hU z hz, sub_zero]
    exact hf z) (by
    intro z hz
    have he := massiveGreen_solves N D μ hμ (fun y => μ * f y) z hz
    change μ * U z - generator N U z = μ * f z at he
    rw [Pi.sub_apply, generator_sub, hg z hz]
    linarith) x
  have hu : U x = μ * (∑ y, massiveGreen N D μ hμ x y * f y) := by
    rw [Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro y _
    ring
  simpa only [Pi.sub_apply, hu, sub_nonneg] using hm

theorem massiveGreen_mass_le (N : Size) (D : Finset (Vertex N)) (μ : ℝ) (hμ : 0 < μ)
    (x : Vertex N) : μ * (∑ y, massiveGreen N D μ hμ x y) ≤ 1 := by
  simpa only [mul_one] using harmonic_massive_average N D μ hμ (fun _ => 1)
    (fun _ => zero_le_one) (fun z _ => generator_const N 1 z) x

end TorusCoverTime.Blocks.B
