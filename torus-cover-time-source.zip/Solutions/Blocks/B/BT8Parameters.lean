import Solutions.Blocks.B.BT8GoodControl

noncomputable section
open Filter
namespace TorusCoverTime.Blocks.B

theorem bt8_parameters (γ : ℝ) (hγ : 0<γ) (hγhi : 32*γ<1/10) :
    ∀ᶠ N : Size in atTop,
      1≤logSize N ∧ 2*(logSize N)^(16*γ)≤(logSize N)^(32*γ) ∧
      (logSize N)^(32*γ)≤(logSize N)^(1/10:ℝ) ∧
      (logSize N)^(3*γ)≤(logSize N)^(8*γ) ∧ (logSize N)^(4*γ)≤(logSize N)^(8*γ) ∧
      2*coarseProbeRadialConstant≤(logSize N)^(8*γ) := by
  have ha := bt6_polylog_subpower (32*γ) (16*γ) 2 0 0 0 (by linarith) (by linarith)
  filter_upwards [blockB_logSize_tendsto.eventually_ge_atTop 1,
    blockB_logSize_tendsto.eventually ha,
    ((tendsto_rpow_atTop (by linarith : 0<8*γ)).comp blockB_logSize_tendsto).eventually_ge_atTop
      (2*coarseProbeRadialConstant)] with N hL hA hC
  simp only [zero_mul,add_zero] at hA
  exact ⟨hL,hA,Real.rpow_le_rpow_of_exponent_le hL hγhi.le,
    Real.rpow_le_rpow_of_exponent_le hL (by linarith),
    Real.rpow_le_rpow_of_exponent_le hL (by linarith),hC⟩

end TorusCoverTime.Blocks.B
