import Solutions.Blocks.B.TraversalScanMeasurable

/-! Chronological composition of finite record actions, with prefix congruence and pairing. -/
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B


def finiteActionScan (f : ℕ → ℕ → ℕ) : ℕ → ℕ → ℕ
  | 0, k => k
  | n+1, k => f n (finiteActionScan f n k)

theorem finiteActionScan_congr (f g : ℕ → ℕ → ℕ) (n : ℕ)
    (h : ∀ j < n, ∀ k, f j k = g j k) (k : ℕ) :
    finiteActionScan f n k = finiteActionScan g n k := by
  induction n with
  | zero => rfl
  | succ n ih =>
    simp only [finiteActionScan]
    rw [h n (by omega),ih (fun j hj => h j (by omega))]

theorem finiteActionScan_add (f : ℕ → ℕ → ℕ) (s n k : ℕ) :
    finiteActionScan f (s+n) k =
      finiteActionScan (fun j => f (s+j)) n (finiteActionScan f s k) := by
  induction n with
  | zero => simp [finiteActionScan]
  | succ n ih =>
    rw [show s+(n+1) = s+n+1 by omega,finiteActionScan,ih,finiteActionScan]

theorem finiteActionScan_measurable {Ω : Type*} [MeasurableSpace Ω]
    (f : ℕ → Ω → ℕ → ℕ) (hf : ∀ j k, Measurable (fun ω => f j ω k))
    (n : ℕ) (K : Ω → ℕ) (hK : Measurable K) :
    Measurable (fun ω => finiteActionScan (fun j => f j ω) n (K ω)) := by
  induction n with
  | zero => exact hK
  | succ n ih =>
    have hh : Measurable (fun z : Ω × ℕ => f n z.1 z.2) :=
      measurable_from_prod_countable_left fun k => hf n k
    exact hh.comp (measurable_id.prodMk ih)


end TorusCoverTime.Blocks.B

