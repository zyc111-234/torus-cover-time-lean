import Solutions.Blocks.B.HarmonicShellCenter

/-! The bounded clock errors cause a bounded regression error, uniformly
over the scale. The terminal displacement remains an explicit variable. -/

noncomputable section
namespace TorusCoverTime.Blocks.B

theorem bridge_regression_error (q L v V C m u : ℝ) (hV : 0<V)
    (hv : 0≤v) (hvV : v≤V) (hC : 0≤C)
    (hlocal : |v-q/2|≤C) (hglobal : |V-L/2|≤C) :
    |Real.sqrt 2*q-(v/V)*m+(1-v/V)*u| ≤ 4*Real.sqrt 2*C+|m-Real.sqrt 2*L|+|u| := by
  have hratio : 0≤v/V ∧ v/V≤1 := ⟨div_nonneg hv hV.le,(div_le_one hV).mpr hvV⟩
  have hfirst : |q-2*v|≤2*C := by
    rw [show q-2*v = (-2)*(v-q/2) by ring,abs_mul]
    norm_num only [abs_neg,abs_of_nonneg (by norm_num : (0:ℝ)≤2)]
    exact mul_le_mul_of_nonneg_left hlocal (by norm_num)
  have he : q-(v/V)*L = (q-2*v)+2*(v/V)*(V-L/2) := by
    field_simp
    <;> ring
  have hclock : |q-(v/V)*L|≤4*C := by
    rw [he]
    calc
      _ ≤ |q-2*v|+|2*(v/V)*(V-L/2)| := abs_add_le _ _
      _ ≤ 2*C+2*C := by
        apply add_le_add hfirst
        rw [abs_mul,abs_of_nonneg (by positivity : 0≤2*(v/V))]
        exact (mul_le_mul_of_nonneg_left hglobal (by positivity)).trans
          (mul_le_mul_of_nonneg_right (by linarith [hratio.2]) hC)
      _ = _ := by ring
  have hmid : |(v/V)*(m-Real.sqrt 2*L)| ≤ |m-Real.sqrt 2*L| := by
    rw [abs_mul,abs_of_nonneg hratio.1]
    exact mul_le_of_le_one_left (abs_nonneg _) hratio.2
  have hlast : |(1-v/V)*u|≤|u| := by
    rw [abs_mul,abs_of_nonneg (by linarith [hratio.2])]
    exact mul_le_of_le_one_left (abs_nonneg _) (by linarith [hratio.1])
  rw [show Real.sqrt 2*q-(v/V)*m+(1-v/V)*u =
    (Real.sqrt 2*(q-(v/V)*L)-(v/V)*(m-Real.sqrt 2*L))+(1-v/V)*u by ring]
  calc
    _ ≤ |Real.sqrt 2*(q-(v/V)*L)-(v/V)*(m-Real.sqrt 2*L)|+|(1-v/V)*u| := abs_add_le _ _
    _ ≤ (|Real.sqrt 2*(q-(v/V)*L)|+|(v/V)*(m-Real.sqrt 2*L)|)+|u| :=
      add_le_add (abs_sub _ _) hlast
    _ ≤ (Real.sqrt 2*(4*C)+|m-Real.sqrt 2*L|)+|u| := by
      apply add_le_add_left
      apply add_le_add _ hmid
      rw [abs_mul,abs_of_nonneg (Real.sqrt_nonneg _)]
      exact mul_le_mul_of_nonneg_left hclock (Real.sqrt_nonneg _)
    _ = _ := by ring

theorem harmonicExtremeCenter_log_error (N : Size) (hL : 1≤logSize N) :
    |harmonicExtremeCenter N-Real.sqrt 2*logSize N| ≤ Real.log (logSize N) := by
  have hs : 0<Real.sqrt (2:ℝ) := by positivity
  have hs2 : (Real.sqrt (2:ℝ))^2=2 := Real.sq_sqrt (by norm_num)
  have hs1 : 1≤Real.sqrt (2:ℝ) := by nlinarith [Real.sqrt_nonneg (2:ℝ)]
  have hl : 0≤Real.log (logSize N) := Real.log_nonneg hL
  have he : harmonicExtremeCenter N-Real.sqrt 2*logSize N = -(3/4*Real.log (logSize N))/Real.sqrt 2 := by
    unfold harmonicExtremeCenter
    field_simp
    nlinarith [hs2]
  rw [he,abs_div,abs_neg,abs_of_nonneg (by positivity : 0≤3/4*Real.log (logSize N)),abs_of_pos hs]
  apply (div_le_iff₀ hs).mpr
  nlinarith [mul_nonneg hl (sub_nonneg.mpr hs1)]

end TorusCoverTime.Blocks.B
