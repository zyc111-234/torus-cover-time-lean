import Solutions.Blocks.B.PeriodicBindingVariance

/-! The rare endpoint factor is retained before summing over the N² sites. -/
noncomputable section
open ProbabilityTheory
open scoped NNReal
namespace TorusCoverTime.Blocks.B

theorem bt7_center_bounds (N : Size) (hL : 1≤logSize N) :
    0≤harmonicExtremeCenter N ∧ harmonicExtremeCenter N≤2*logSize N ∧
      2*(logSize N)^2-(3/2)*(logSize N)*Real.log (logSize N)≤(harmonicExtremeCenter N)^2 := by
  have hl0 : 0<logSize N := by linarith
  have hlog := Real.log_le_sub_one_of_pos hl0
  have hlog0 := Real.log_nonneg hL
  have hs : 0<Real.sqrt (2:ℝ) := by positivity
  have hs2 := Real.sq_sqrt (by norm_num : (0:ℝ)≤2)
  have hs1 : 1≤Real.sqrt (2:ℝ) := by nlinarith
  have hm' : 0≤2*logSize N-(3/4)*Real.log (logSize N) := by linarith
  constructor
  · unfold harmonicExtremeCenter; exact div_nonneg hm' hs.le
  constructor
  · unfold harmonicExtremeCenter
    apply (div_le_iff₀ hs).mpr
    nlinarith [mul_nonneg hl0.le (sub_nonneg.mpr hs1)]
  · unfold harmonicExtremeCenter
    rw [div_pow,hs2]
    nlinarith [sq_nonneg (Real.log (logSize N))]

theorem bt7_endpoint_exponent (N : Size) (C V u : ℝ) (hC : 0≤C)
    (hL : 8*(C+1)≤logSize N) (hv : |V-logSize N/2|≤C) :
    -(harmonicExtremeCenter N+u)^2/(2*V)≤
      -2*logSize N+(3/2)*Real.log (logSize N)+8*C+8*|u| := by
  have hb := bt6_clock_comparison (logSize N) C V hC hL hv
  have hv0 := hb.1
  have hl1 : 1≤logSize N := by linarith
  have hc := bt7_center_bounds N hl1
  have hl0 : 0<logSize N := by linarith
  have hlog0 := Real.log_nonneg hl1
  have hlog := Real.log_le_sub_one_of_pos hl0
  have hcenter : 2*logSize N-(3/2)*Real.log (logSize N)-8*C≤(harmonicExtremeCenter N)^2/(2*V) := by
    apply (le_div_iff₀ (by positivity : 0<2*V)).mpr
    by_cases ha : 0≤2*logSize N-(3/2)*Real.log (logSize N)-8*C
    · have hp := mul_le_mul_of_nonneg_left (abs_le.mp hv).2 ha
      have hp' : (2*logSize N-(3/2)*Real.log (logSize N)-8*C)*(2*V)≤
          (2*logSize N-(3/2)*Real.log (logSize N)-8*C)*(logSize N+2*C) := by nlinarith only [hp]
      exact hp'.trans (by nlinarith [mul_nonneg hC hlog0,mul_nonneg hC hl0.le,sq_nonneg C])
    · exact (mul_nonpos_of_nonpos_of_nonneg (le_of_not_ge ha) (by positivity)).trans (sq_nonneg _)
  have hm : harmonicExtremeCenter N≤8*V := by linarith [hc.2.1,hb.2.1]
  have hcross : -(harmonicExtremeCenter N+u)^2/(2*V)≤-(harmonicExtremeCenter N)^2/(2*V)+8*|u| := by
    apply (div_le_iff₀ (by positivity : 0<2*V)).mpr
    have he : (-(harmonicExtremeCenter N)^2/(2*V)+8*|u|)*(2*V)=
        -(harmonicExtremeCenter N)^2+16*V*|u| := by field_simp [hb.1.ne'] <;> ring
    rw [he]
    have hp := mul_le_mul_of_nonneg_left (neg_abs_le u) hc.1
    have hq := mul_le_mul_of_nonneg_right hm (abs_nonneg u)
    nlinarith [sq_nonneg u]
  simp only [neg_div] at hcross ⊢
  linarith

/-- B.34, valid for every displacement u, including the large-envelope regime. -/
theorem bt7_endpoint_density (N : Size) (C : ℝ) (V : ℝ≥0) (u : ℝ) (hC : 0≤C)
    (hL : 8*(C+1)≤logSize N) (hv : |(V:ℝ)-logSize N/2|≤C) :
    gaussianPDFReal 0 V (harmonicExtremeCenter N+u)≤
      Real.exp (8*C)/vertexCount N*logSize N*Real.exp (8*|u|) := by
  have hb := bt6_clock_comparison (logSize N) C V hC hL hv
  have hl0 : 0<logSize N := by linarith
  have hs : Real.sqrt (logSize N)≤Real.sqrt (2*Real.pi*(V:ℝ)) := by
    apply Real.sqrt_le_sqrt
    nlinarith [Real.pi_gt_three]
  have hp : (Real.sqrt (2*Real.pi*(V:ℝ)))⁻¹≤Real.exp (-(Real.log (logSize N)/2)) := by
    rw [Real.exp_neg,Real.exp_half,Real.exp_log hl0]
    exact inv_anti₀ (Real.sqrt_pos.mpr hl0) hs
  have he := Real.exp_le_exp.mpr (bt7_endpoint_exponent N C V u hC hL hv)
  unfold gaussianPDFReal
  rw [sub_zero]
  refine (mul_le_mul hp he (Real.exp_pos _).le (Real.exp_pos _).le).trans_eq ?_
  rw [← Real.exp_add]
  have ha : -(Real.log (logSize N)/2)+(-2*logSize N+(3/2)*Real.log (logSize N)+8*C+8*|u|)=
      8*C-(2*logSize N)+Real.log (logSize N)+8*|u| := by ring
  rw [ha,Real.exp_add,Real.exp_add,Real.exp_sub,Real.exp_log hl0,
    ← Blocks.D.vertexCount_eq_exp_two_logSize]

end TorusCoverTime.Blocks.B
