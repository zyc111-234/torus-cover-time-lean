import Solutions.Blocks.B.KilledBounds

/-! Simplicity below the torus gap and the full orthogonal-complement Rayleigh bound. -/

noncomputable section
open scoped BigOperators
namespace TorusCoverTime.Blocks.B

lemma killed_eigenfunction_sub_smul (N : Size) (A : Finset (Vertex N))
    (f g : Vertex N → ℝ) (c : ℝ)
    (hf : ∀ x, x ∉ A → -generator N f x = killedEigenvalue N A * f x)
    (hg : ∀ x, x ∉ A → -generator N g x = killedEigenvalue N A * g x) :
    ∀ x, x ∉ A → -generator N (f - c • g) x = killedEigenvalue N A * (f - c • g) x := by
  intro x hx
  rw [generator_sub]
  change -(generator N f x - generator N (fun z => c * g z) x) =
    killedEigenvalue N A * (f x - c * g x)
  rw [generator_mul_left]
  have hfx := hf x hx
  have hgx := hg x hx
  rw [show generator N f x = -(killedEigenvalue N A * f x) by linarith,
    show generator N g x = -(killedEigenvalue N A * g x) by linarith]
  ring

lemma killed_eigenspace_simple (N : Size) (A : Finset (Vertex N))
    (hA : A ≠ Finset.univ) (hd : capacityRatio N A < 1)
    (f : Vertex N → ℝ) (hfA : vanishesOn N A f)
    (hf : ∀ x, x ∉ A → -generator N f x = killedEigenvalue N A * f x) :
    ∃ c : ℝ, f = fun x => c * principalMode N A x := by
  let c := spatialMean N f
  let w := f - c • principalMode N A
  have hp := principalMode_valid N A hA
  have hwA : vanishesOn N A w := by
    intro x hx
    simp [w, hfA x hx, hp.1 x hx]
  have hwmean : spatialMean N w = 0 := by
    dsimp only [w]
    rw [spatialMean_sub, spatialMean_smul, hp.2.1, mul_one]
    exact sub_self _
  have hwEig := killed_eigenfunction_sub_smul N A f (principalMode N A) c hf hp.2.2.2
  have hwenergy : energy N w = killedEigenvalue N A * squareSum N w := by
    simpa only [dirichletPairing, energy, squareSum, ← sq] using
      killed_eigenfunction_pairing N A w w hwA hwEig
  have hineq := poincare_zero_mean N w hwmean
  change spectralGap N * squareSum N w ≤ energy N w at hineq
  rw [hwenergy] at hineq
  have hl := killedEigenvalue_lt_gap N A hA hd
  have hw0 : squareSum N w = 0 := by
    have hnonneg := squareSum_nonneg N w
    nlinarith
  have hw := (squareSum_eq_zero N w).mp hw0
  exact ⟨c, sub_eq_zero.mp hw⟩

lemma killed_orthogonal_gap (N : Size) (A : Finset (Vertex N))
    (hA : A ≠ Finset.univ) (hd : capacityRatio N A < 1)
    (f : Vertex N → ℝ) (hfA : vanishesOn N A f)
    (horth : (∑ x : Vertex N, f x * principalMode N A x) = 0) :
    spectralGap N * (∑ x : Vertex N, f x ^ 2) ≤ energy N f := by
  let c := -spatialMean N f
  let w := f + c • principalMode N A
  have hp := principalMode_valid N A hA
  have hwmean : spatialMean N w = 0 := by
    dsimp only [w]
    rw [spatialMean_add, spatialMean_smul, hp.2.1, mul_one]
    exact add_neg_cancel _
  have hpair : dirichletPairing N f (principalMode N A) = 0 := by
    rw [killed_eigenfunction_pairing N A f (principalMode N A) hfA hp.2.2.2, horth, mul_zero]
  have hsum : squareSum N w = squareSum N f + c ^ 2 * squareSum N (principalMode N A) := by
    dsimp only [w]
    rw [squareSum_add_smul, horth, mul_zero, add_zero]
  have henergy : energy N w = energy N f +
      c ^ 2 * (killedEigenvalue N A * squareSum N (principalMode N A)) := by
    dsimp only [w]
    rw [energy_add_smul, hpair, mul_zero, add_zero, principalMode_energy N A hA]
  have hineq := poincare_zero_mean N w hwmean
  change spectralGap N * squareSum N w ≤ energy N w at hineq
  rw [hsum, henergy] at hineq
  have hnonneg : 0 ≤ c ^ 2 * squareSum N (principalMode N A) *
      (spectralGap N - killedEigenvalue N A) :=
    mul_nonneg (mul_nonneg (sq_nonneg _) (squareSum_nonneg N _))
      (sub_pos.mpr (killedEigenvalue_lt_gap N A hA hd)).le
  change spectralGap N * squareSum N f ≤ energy N f
  nlinarith [hineq, hnonneg]

end TorusCoverTime.Blocks.B
