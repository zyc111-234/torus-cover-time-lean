import Solutions.Blocks.B.GreenPositive
import Mathlib.LinearAlgebra.FiniteDimensional.Basic

/-! The unique restricted Green charge, obtained from an injective finite-dimensional map. -/

noncomputable section
open scoped BigOperators
namespace TorusCoverTime.Blocks.B

def chargeExtend (N : Size) (A : Finset (Vertex N)) (q : A → ℝ) (x : Vertex N) : ℝ :=
  if hx : x ∈ A then q ⟨x, hx⟩ else 0

lemma chargeExtend_on (N : Size) (A : Finset (Vertex N)) (q : A → ℝ) (x : A) :
    chargeExtend N A q x = q x := by
  simp [chargeExtend, x.property]

lemma chargeExtend_off (N : Size) (A : Finset (Vertex N)) (q : A → ℝ)
    (x : Vertex N) (hx : x ∉ A) : chargeExtend N A q x = 0 := by
  simp [chargeExtend, hx]

lemma chargeExtend_add (N : Size) (A : Finset (Vertex N)) (q r : A → ℝ) :
    chargeExtend N A (q + r) = chargeExtend N A q + chargeExtend N A r := by
  funext x
  by_cases hx : x ∈ A <;> simp [chargeExtend, hx]

lemma chargeExtend_smul (N : Size) (A : Finset (Vertex N)) (c : ℝ) (q : A → ℝ) :
    chargeExtend N A (c • q) = c • chargeExtend N A q := by
  funext x
  by_cases hx : x ∈ A <;> simp [chargeExtend, hx]

lemma chargeExtend_restrict (N : Size) (A : Finset (Vertex N)) (q : Vertex N → ℝ)
    (hq : ∀ x, x ∉ A → q x = 0) : chargeExtend N A (fun x => q x) = q := by
  funext x
  by_cases hx : x ∈ A
  · simp [chargeExtend, hx]
  · simp [chargeExtend, hx, hq x hx]

def restrictedGreen (N : Size) (A : Finset (Vertex N)) : (A → ℝ) →ₗ[ℝ] (A → ℝ) where
  toFun q x := greenOperator N (chargeExtend N A q) x
  map_add' q r := by
    simp only [chargeExtend_add, greenOperator_add]
    rfl
  map_smul' c q := by
    simp only [chargeExtend_smul, greenOperator_smul]
    rfl

lemma restrictedGreen_injective (N : Size) (A : Finset (Vertex N)) (hA : A ≠ Finset.univ) :
    Function.Injective (restrictedGreen N A) := by
  apply (LinearMap.ker_eq_bot).mp
  apply (LinearMap.ker_eq_bot').mpr
  intro q hq
  have hzero : chargeExtend N A q = 0 := by
    apply supported_green_injective N A hA _ (chargeExtend_off N A q)
    intro x hx
    exact congrFun hq ⟨x, hx⟩
  funext x
  have h := congrFun hzero x
  simpa only [chargeExtend_on, Pi.zero_apply] using h

lemma exists_greenCharge (N : Size) (A : Finset (Vertex N)) (hA : A ≠ Finset.univ) :
    ∃ q : Vertex N → ℝ, greenChargeEquation N A q := by
  obtain ⟨r, hr⟩ := (LinearMap.surjective_of_injective (restrictedGreen_injective N A hA))
    (fun _ : A => (1 : ℝ))
  refine ⟨chargeExtend N A r, chargeExtend_off N A r, ?_⟩
  intro x hx
  exact congrFun hr ⟨x, hx⟩

lemma greenCharge_unique (N : Size) (A : Finset (Vertex N)) (hA : A ≠ Finset.univ)
    (q r : Vertex N → ℝ) (hq : greenChargeEquation N A q) (hr : greenChargeEquation N A r) :
    q = r := by
  have hzero : q - r = 0 := by
    apply supported_green_injective N A hA
    · intro x hx
      simp only [Pi.sub_apply, hq.1 x hx, hr.1 x hx, sub_self]
    · intro x hx
      rw [greenOperator_sub, Pi.sub_apply]
      rw [show greenOperator N q x = 1 from hq.2 x hx,
        show greenOperator N r x = 1 from hr.2 x hx, sub_self]
  exact sub_eq_zero.mp hzero

lemma energy_greenCharge (N : Size) (A : Finset (Vertex N)) (q : Vertex N → ℝ)
    (hq : greenChargeEquation N A q) :
    energy N (greenOperator N q) = ∑ x : Vertex N, q x := by
  rw [energy_greenOperator]
  apply Finset.sum_congr rfl
  intro x _
  by_cases hx : x ∈ A
  · rw [show greenOperator N q x = 1 from hq.2 x hx, mul_one]
  · rw [hq.1 x hx, zero_mul]

lemma greenCharge_ne_zero (N : Size) (A : Finset (Vertex N)) (hne : A.Nonempty)
    (q : Vertex N → ℝ) (hq : greenChargeEquation N A q) : q ≠ 0 := by
  intro hzero
  obtain ⟨x, hx⟩ := hne
  have h := hq.2 x hx
  change greenOperator N q x = 1 at h
  rw [hzero, greenOperator_zero] at h
  norm_num at h

lemma greenCharge_sum_pos (N : Size) (A : Finset (Vertex N)) (hne : A.Nonempty)
    (hA : A ≠ Finset.univ) (q : Vertex N → ℝ) (hq : greenChargeEquation N A q) :
    0 < ∑ x : Vertex N, q x := by
  have h := green_quadratic_pos N A hA q hq.1 (greenCharge_ne_zero N A hne q hq)
  rwa [green_quadratic_eq_energy, energy_greenCharge N A q hq] at h

end TorusCoverTime.Blocks.B
