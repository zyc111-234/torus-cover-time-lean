import Solutions.Blocks.B.BT8Measurable

noncomputable section
open MeasureTheory Filter Set Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

theorem bt8Good_far (N : Size) (root x : Vertex N) (γ u : ℝ) (z : WalkSample × ℝ)
    (hg : bt8Good N root γ u z) (hs : localTime N root z.1 z.2 x≤u) :
    2*((N.val:ℝ)*Real.exp (-((logSize N)^(16*γ))/2))≤periodicDistance x root := by
  simpa only [pointNearRadius,mul_assoc] using
    bt1_soft_site_far N root root x (pointNearRadius N γ 2) u z hg.2.2 hs

theorem bt8Good_harmonic_control (N : Size) (root x : Vertex N) (γ u : ℝ)
    (z : WalkSample × ℝ) (hg : bt8Good N root γ u z)
    (hs : localTime N root z.1 z.2 x≤u) (q : ℕ)
    (hq : 2*(logSize N)^(16*γ)≤(q:ℝ)) (hql : (q:ℝ)≤logSize N-2*(logSize N)^(16*γ)) :
    |Real.sqrt (harmonicPathOccupation N x root q z)-r7TraversalRadius N x root γ q z|≤(logSize N)^(4*γ) := by
  simpa using (bt1_r8_all_soft_control N root x γ u z hg.2 (q:ℤ) (by simpa using hq) (by simpa using hql) hs).2

theorem bt8Good_harmonic_lower (N : Size) (root x : Vertex N) (γ u : ℝ)
    (z : WalkSample × ℝ) (hg : bt8Good N root γ u z)
    (hs : localTime N root z.1 z.2 x≤u) (q : ℕ)
    (hq : 2*(logSize N)^(16*γ)≤(q:ℝ)) (hql : (q:ℝ)≤logSize N-2*(logSize N)^(16*γ)) :
    Real.sqrt 2*(q:ℝ)-(logSize N)^(3*γ)-(logSize N)^(4*γ)≤
      Real.sqrt (harmonicPathOccupation N x root q z) := by
  have hp := Real.rpow_pos_of_pos (logSize_pos N) (16*γ)
  have hb := hg.1 q (by linarith) (by linarith) x (bt8Good_far N root x γ u z hg hs)
  have hc := (abs_le.mp (bt8Good_harmonic_control N root x γ u z hg hs q hq hql)).1
  linarith

theorem bt8Good_failure_le (N : Size) (γ u l r : ℝ) :
    r7LoopEventMass N (fun root => {z | ¬bt8Good N root γ u z}) l r≤
      r7LowerBarrierFailureMass N γ l r+
        r7LoopEventMass N (fun root => {z | ¬bt1R8Good N root γ u z}) l r := by
  have he : (fun root : Vertex N => {z | ¬bt8Good N root γ u z})=
      fun root => {z | ¬r7LowerBarrier N root γ z}∪{z | ¬bt1R8Good N root γ u z} := by
    funext root; ext z; simp only [bt8Good,mem_union,mem_setOf_eq]; tauto
  rw [he]
  exact r7LoopEventMass_union_le N _ _ (fun root => r7LowerBarrier_compl_measurable N root γ)
    (fun root => (bt1R8Good_measurable N root γ u).compl) l r

theorem bt8Good_failure_tendsto (hWalk : WalkModelRegular) (γ u H : ℝ)
    (hγ : 0<γ) (hγ1 : 16*γ<1) (hu : 0≤u) (hH : 0≤H) (l r : Size → ℝ)
    (hwin : ∀ᶠ N : Size in atTop, l N≤r N ∧ phaseACenter N-H*timeScale N≤l N ∧ r N≤phaseACenter N+H*timeScale N) :
    Tendsto (fun N => r7LoopEventMass N (fun root => {z | ¬bt8Good N root γ u z}) (l N) (r N)) atTop (𝓝 0) := by
  have ht := (r7_global_lower_barrier_tendsto hWalk γ H hγ hγ1 hH l r hwin).add
    (bt1_r8_good_failure_tendsto hWalk γ u H hγ hγ1 hu hH l r hwin)
  simp only [add_zero] at ht
  exact tendsto_of_tendsto_of_tendsto_of_le_of_le' tendsto_const_nhds ht
    (Eventually.of_forall (fun _ => bot_le)) (Eventually.of_forall (fun N => bt8Good_failure_le N γ u (l N) (r N)))

end TorusCoverTime.Blocks.B
