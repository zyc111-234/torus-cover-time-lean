import Solutions.Blocks.B.TorusMetric

/-! Quantitative one- and two-parameter telescoping, plus the separation geometry. -/

noncomputable section
open scoped BigOperators
namespace TorusCoverTime.Blocks.B

lemma abs_endpoint_sub_le_steps (f : ℕ → ℝ) (n : ℕ) (C : ℝ)
    (hf : ∀ i < n, |f (i + 1) - f i| ≤ C) : |f n - f 0| ≤ (n : ℝ) * C := by
  induction n with
  | zero => simp
  | succ n ih =>
    have hprev := ih (fun i hi => hf i (by omega))
    calc
      _ = |(f (n + 1) - f n) + (f n - f 0)| := by congr 1; ring
      _ ≤ |f (n + 1) - f n| + |f n - f 0| := abs_add_le _ _
      _ ≤ C + (n : ℝ) * C := add_le_add (hf n (by omega)) hprev
      _ = _ := by push_cast; ring

lemma abs_grid_mixed_le (f : ℕ → ℕ → ℝ) (m n : ℕ) (C : ℝ)
    (hf : ∀ i < m, ∀ j < n,
      |f (i + 1) (j + 1) - f i (j + 1) - f (i + 1) j + f i j| ≤ C) :
    |f m n - f 0 n - f m 0 + f 0 0| ≤ (m : ℝ) * (n : ℝ) * C := by
  have hs (i : ℕ) (hi : i < m) :
      |(f (i + 1) n - f (i + 1) 0) - (f i n - f i 0)| ≤ (n : ℝ) * C := by
    have h := abs_endpoint_sub_le_steps (fun j => f (i + 1) j - f i j) n C (by
      intro j hj
      convert hf i hi j hj using 1 ; ring)
    convert h using 1 ; ring
  have h := abs_endpoint_sub_le_steps (fun i => f i n - f i 0) m ((n : ℝ) * C) hs
  convert h using 1 <;> ring

lemma periodicDistance_add_self (N : Size) (x e : Vertex N) :
    periodicDistance (x + e) x = periodicDistance e 0 := by
  rw [← periodicDistance_sub_zero]
  congr 1
  abel

lemma periodicDistance_perturbation_lower (N : Size) (x y p q : Vertex N) :
    periodicDistance x y - periodicDistance p 0 - periodicDistance q 0 ≤
      periodicDistance (x + p) (y + q) := by
  have hx := periodicDistance_triangle N x (x + p) y
  have hy := periodicDistance_triangle N (x + p) (y + q) y
  rw [periodicDistance_comm x (x + p), periodicDistance_add_self] at hx
  rw [periodicDistance_add_self] at hy
  linarith

lemma direction_neg_exists (N : Size) (d : Fin 4) : ∃ d' : Fin 4, direction N d' = -direction N d := by
  fin_cases d
  · exact ⟨1, by simp [direction]⟩
  · exact ⟨0, by simp [direction]⟩
  · exact ⟨3, by simp [direction]⟩
  · exact ⟨2, by simp [direction]⟩

lemma greenKernel_sub_zero (N : Size) (x y : Vertex N) :
    greenKernel N x y = greenKernel N (x - y) 0 := by simp only [greenKernel, sub_zero]

end TorusCoverTime.Blocks.B
