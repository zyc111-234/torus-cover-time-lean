import Solutions.Blocks.B.R8HighCountCutoff
import Solutions.Blocks.B.R6CoarseCounts

/-! The first high-count prefix has exponentially small single-site softness
under every compatible independent specified-exit law. -/
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

theorem r8_high_count_product_softness (hWalk : WalkModelRegular) (γ U : ℝ)
    (hγ : 0 < γ) (hγ1 : γ < 1) (hU : 0 ≤ U) :
    ∀ᶠ N : Size in atTop, ∀ c : Vertex N, ∀ q : ℝ,
      (logSize N)^(16*γ) ≤ q → q ≤ logSize N-(logSize N)^(16*γ) →
      ∀ m : ℕ, 100*(logSize N)^2 ≤ (m:ℝ)*q^γ → ∀ a b : Fin m → Vertex N,
      (∀ i, |periodicDistance (a i) c-Real.exp (q+q^γ)| ≤ 2) →
      (∀ i, diskExteriorNeighbor N c (Real.exp (q+2*q^γ)) (b i)) →
      (exactExitProductLaw N (torusDisk N c (Real.exp (q+2*q^γ))) m a b).real
        {ω | exitBlockOccupation N (torusDisk N c (Real.exp (q+2*q^γ))) m a ω c/g ≤ U} ≤
          Real.exp (-40*logSize N) := by
  obtain ⟨q0,hq0⟩ := eventually_atTop.mp (r8_single_site_softness hWalk γ hγ hγ1)
  have hQ := (tendsto_rpow_atTop (by positivity : 0 < 16*γ)).comp blockB_logSize_tendsto
  filter_upwards [r8_soft_coarse_parameters γ U hγ hγ1,r6_disk_radius_embedding γ hγ,
    hQ.eventually_ge_atTop q0] with N hp hsmall hbase
  intro c q hq hqL m hm a b ha hb
  have hpar := hp q hq
  have hqpos : 0 < q := by linarith [hpar.1]
  have hqL' := hqL.trans (sub_le_self _ (Real.rpow_nonneg (logSize_pos N).le _))
  exact (hq0 q (hbase.trans hq) N c m a b (hsmall q hqpos.le hqL) ha hb U hU).trans
    (r8_soft_large_count_algebra (logSize N) q γ U m (logSize_pos N) hpar.1 hqL' hU hpar.2.1 hpar.2.2 hm)

end TorusCoverTime.Blocks.B
