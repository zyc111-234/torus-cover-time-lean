import Solutions.Blocks.B.PreciseDiskGreen
import Solutions.Blocks.B.R6GreenEstimates

/-! Explicit core size, entrance tolerance, and exponential error estimates
on the original R7 radii. -/

noncomputable section
open Filter Classical
namespace TorusCoverTime.Blocks.B

def r7GreenCoreSize (q : ℝ) : ℕ := ⌈Real.exp (q/2)⌉₊

theorem r7GreenCoreSize_bounds (q : ℝ) (hq : 0 ≤ q) :
    0 < r7GreenCoreSize q ∧ Real.exp (q/2) ≤ (r7GreenCoreSize q:ℝ) ∧
      (r7GreenCoreSize q:ℝ) ≤ 2*Real.exp (q/2) := by
  have h1 : 1 ≤ Real.exp (q/2) := Real.one_le_exp_iff.mpr (by linarith)
  have hlo := Nat.le_ceil (Real.exp (q/2))
  have hhi := Nat.ceil_lt_add_one (Real.exp_pos (q/2)).le
  have hn : 0 < (r7GreenCoreSize q:ℝ) := (Real.exp_pos _).trans_le hlo
  exact ⟨by exact_mod_cast hn, hlo, by dsimp [r7GreenCoreSize]; linarith⟩

theorem r7_core_separation (q w : ℝ) (hq : 64 ≤ q) (hw : 0 ≤ w) :
    8*(r7GreenCoreSize q:ℝ) ≤ Real.exp (q+w)/2 := by
  have hn := (r7GreenCoreSize_bounds q (by linarith)).2.2
  have he : 32 ≤ Real.exp (q/2+w) := by
    have hh := Real.add_one_le_exp (q/2+w)
    linarith
  have hm := mul_le_mul_of_nonneg_left he (Real.exp_pos (q/2)).le
  rw [← Real.exp_add, show q/2+(q/2+w) = q+w by ring] at hm
  linarith

theorem r7_log_radius_bound (q w : ℝ) (hq : 0 ≤ q) (hw : 0 ≤ w) (hwq : w ≤ q) :
    Real.log (3+2*Real.exp (q+2*w)) ≤ 8*(q+1) := by
  have he : 1 ≤ Real.exp (q+2*w) := Real.one_le_exp_iff.mpr (by linarith)
  have hh := Real.log_le_log (show 0 < 3+2*Real.exp (q+2*w) by positivity)
    (show 3+2*Real.exp (q+2*w) ≤ 5*Real.exp (q+2*w) by linarith)
  rw [Real.log_mul (by norm_num : (5:ℝ) ≠ 0) (Real.exp_pos _).ne', Real.log_exp] at hh
  have h5 := Real.log_le_self (by norm_num : (0:ℝ) ≤ 5)
  linarith

theorem r7_polynomial_exp_absorption (q : ℝ) (hq : 64 ≤ q) :
    (q+1)*Real.exp (-q/2) ≤ Real.exp (-q/4) := by
  have he := Real.pow_div_factorial_le_exp (q/4) (show 0 ≤ q/4 by linarith) 2
  norm_num at he
  have hpoly : q+1 ≤ Real.exp (q/4) := by
    nlinarith [mul_nonneg (show 0 ≤ q-64 by linarith) (show 0 ≤ q by linarith)]
  calc
    _ ≤ Real.exp (q/4)*Real.exp (-q/2) :=
      mul_le_mul_of_nonneg_right hpoly (Real.exp_pos _).le
    _ = _ := by rw [← Real.exp_add]; congr 1; ring

theorem log_radius_tolerance (d E : ℝ) (hE : 0 < E) (hd : E/2 ≤ d)
    (herror : |d-E| ≤ 2) : |Real.log d-Real.log E| ≤ 4/E := by
  have hd0 : 0 < d := (half_pos hE).trans_le hd
  have hh := log_near_one_abs (d/E) ((le_div_iff₀ hE).mpr (by linarith))
  rw [Real.log_div hd0.ne' hE.ne', show d/E-1 = (d-E)/E by field_simp <;> ring,
    abs_div, abs_of_pos hE] at hh
  have hm := mul_le_mul_of_nonneg_left (div_le_div_of_nonneg_right herror hE.le)
    (by norm_num : (0:ℝ) ≤ 2)
  exact (hh.trans hm).trans_eq (by ring)

end TorusCoverTime.Blocks.B
