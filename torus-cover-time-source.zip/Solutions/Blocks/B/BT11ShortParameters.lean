import Solutions.Blocks.B.BT11KernelComposition
import Solutions.Blocks.B.R7CoarseProbe
import Solutions.Blocks.B.PointNearScale
import Solutions.Blocks.B.FourierTail

/-! Fixed positive closing-window length. All geometric errors vanish
before this length is used; no vanishing window is substituted for B.49. -/
noncomputable section
open MeasureTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

def bt11ShortTime (N : Size) : ℝ := timeScale N/16384
def bt11FarRadius (N : Size) : ℝ := pointNearRadius N (1/8192) 1

theorem bt11ShortTime_pos (N : Size) : 0<bt11ShortTime N :=
  div_pos (timeScale_pos N) (by norm_num)

theorem bt11_short_rows (hWalk : WalkModelRegular) :
    ∀ᶠ N : Size in atTop, ∀ a c : Vertex N, bt11FarRadius N≤periodicDistance a c →
      ∀ T : ℝ, 0≤T → T≤2*bt11ShortTime N →
        1-bt11KillAction N c T (fun _ => 1) a≤1/1024 := by
  have hg : 0<g := by unfold g; positivity
  filter_upwards [
    blockB_logSize_tendsto.eventually
      (power_eventually_le_power greenDiagonalErrorConstant 0 1 (g/2) (by norm_num) (by positivity)),
    blockB_logSize_tendsto.eventually
      (power_eventually_le_power (17+greenSpatialConstant) 0 1 (g/8192) (by norm_num) (by positivity)),
    blockB_logSize_tendsto.eventually
      (power_eventually_le_power (greenSpatialConstant/2) (16*(1/8192)) 1 (g/8192) (by norm_num) (by positivity))
    ] with N hd h₁ h₂
  simp only [Real.rpow_zero,Real.rpow_one,mul_one] at hd h₁ h₂
  have hD : g*logSize N/2≤bt11GreenDenom N := by
    have he := (abs_le.mp (greenDiagonal_log_error N)).1
    unfold bt11GreenDenom
    linarith
  intro a c hfar T hT hhi
  have hfar' : (N.val:ℝ)*Real.exp (-((logSize N)^(16*(1/8192:ℝ)))/2)≤periodicDistance a c := by
    simpa only [bt11FarRadius,pointNearRadius,one_mul] using hfar
  have hG := (le_abs_self (greenKernel N a c)).trans (far_root_green_bound N c a _ hfar')
  have htime : T/vertexCount N≤g*logSize N/8192 := by
    apply (div_le_iff₀ (vertexCount_pos N)).mpr
    have he : 2*bt11ShortTime N=(g*logSize N/8192)*vertexCount N := by
      unfold bt11ShortTime timeScale vertexCount
      ring
    exact hhi.trans_eq he
  apply (bt11_killing_row_deficit hWalk N c a T hT).trans
  apply (div_le_iff₀ (bt11GreenDenom_pos N)).mpr
  have hL : 0<g*logSize N := mul_pos hg (logSize_pos N)
  nlinarith

theorem bt11_short_mixing (hWalk : WalkModelRegular) :
    ∀ᶠ N : Size in atTop, ∀ T : ℝ, bt11ShortTime N≤T → ∀ a b : Vertex N,
      1/(2*vertexCount N)≤transitionProbability N a b T ∧
      transitionProbability N a b T≤(1+1/1024)/vertexCount N ∧
      transitionProbability N a b (T/2)≤(1+1/1024)/vertexCount N := by
  have hp : Tendsto (fun N : Size => (logSize N)^(-8:ℝ)) atTop (𝓝 0) :=
    (tendsto_rpow_neg_atTop (by norm_num : (0:ℝ)<8)).comp blockB_logSize_tendsto
  filter_upwards [(fourier_walk_identities hWalk).2.2.2,
    mixingTime_div_timeScale_tendsto.eventually (eventually_lt_nhds (by norm_num : (0:ℝ)<1/32768)),
    hp.eventually (eventually_lt_nhds (by norm_num : (0:ℝ)<1/1024))] with N hmix hs hp
  have hs' : mixingTime N<bt11ShortTime N/2 := by
    have hh := (div_lt_iff₀ (timeScale_pos N)).mp hs
    dsimp only [bt11ShortTime]
    linarith
  intro T hT a b
  have hfull := (abs_le.mp (hmix T (by have := bt11ShortTime_pos N; linarith) a b).1)
  have hhalf := (le_abs_self _).trans (hmix (T/2) (by linarith) a b).1
  refine ⟨(div_le_iff₀ (by have := vertexCount_pos N; positivity)).mpr (by nlinarith),
    (le_div_iff₀ (vertexCount_pos N)).mpr (by nlinarith),
    (le_div_iff₀ (vertexCount_pos N)).mpr (by nlinarith)⟩

end TorusCoverTime.Blocks.B
