import Solutions.Blocks.B.BT6Goal
import Mathlib.Topology.Maps.Proper.Basic

noncomputable section
open MeasureTheory Set Classical
open scoped BigOperators
namespace TorusCoverTime.Blocks.B

@[fun_prop] theorem bt6ExitNorm_continuous (N : Size) (x : Vertex N) (q : ℕ) :
    Continuous (fun v : (Vertex N → ℝ) × ℝ => bt6ExitNorm N x q v.1 v.2) := by
  unfold bt6ExitNorm
  fun_prop

/-- For a fixed contact scale, existential amplitudes are a compact projection.
In particular the amplitude may depend on the entire field. -/
theorem bt6_fixed_contact_closed (N : Size) (x : Vertex N) (γ η δ : ℝ) (q : ℕ) :
    IsClosed {f : Vertex N → ℝ | ∃ a : ℝ, |a-harmonicExtremeCenter N|≤η ∧
      (∀ j : ℕ, (logSize N)^(32*γ)≤(j:ℝ) → (j:ℝ)≤logSize N-(logSize N)^(32*γ) →
        Real.sqrt 2*(j:ℝ)-δ≤bt6ExitNorm N x j f a) ∧
      bt6ExitNorm N x q f a≤Real.sqrt 2*(q:ℝ)+δ} := by
  let I := Set.Icc (harmonicExtremeCenter N-η) (harmonicExtremeCenter N+η)
  let s : Set ((Vertex N → ℝ) × I) := {v |
    (∀ j : ℕ, (logSize N)^(32*γ)≤(j:ℝ) → (j:ℝ)≤logSize N-(logSize N)^(32*γ) →
      Real.sqrt 2*(j:ℝ)-δ≤bt6ExitNorm N x j v.1 v.2.val) ∧
    bt6ExitNorm N x q v.1 v.2.val≤Real.sqrt 2*(q:ℝ)+δ}
  have hc (j : ℕ) : Continuous (fun v : (Vertex N → ℝ) × I => bt6ExitNorm N x j v.1 v.2.val) :=
    (bt6ExitNorm_continuous N x j).comp (continuous_fst.prodMk (continuous_subtype_val.comp continuous_snd))
  have hs : IsClosed s := by
    apply IsClosed.inter
    · have heq : (fun v : (Vertex N → ℝ) × I =>
          ∀ j : ℕ, (logSize N)^(32*γ)≤(j:ℝ) → (j:ℝ)≤logSize N-(logSize N)^(32*γ) →
            Real.sqrt 2*(j:ℝ)-δ≤bt6ExitNorm N x j v.1 v.2.val) =
          ⋂ j : ℕ, ⋂ (_ : (logSize N)^(32*γ)≤(j:ℝ)), ⋂ (_ : (j:ℝ)≤logSize N-(logSize N)^(32*γ)),
            {v : (Vertex N → ℝ) × I | Real.sqrt 2*(j:ℝ)-δ≤bt6ExitNorm N x j v.1 v.2.val} := by
        ext v
        change (∀ j : ℕ, (logSize N)^(32*γ)≤(j:ℝ) → (j:ℝ)≤logSize N-(logSize N)^(32*γ) →
          Real.sqrt 2*(j:ℝ)-δ≤bt6ExitNorm N x j v.1 v.2.val) ↔
          v ∈ ⋂ j : ℕ, ⋂ (_ : (logSize N)^(32*γ)≤(j:ℝ)), ⋂ (_ : (j:ℝ)≤logSize N-(logSize N)^(32*γ)),
            {v : (Vertex N → ℝ) × I | Real.sqrt 2*(j:ℝ)-δ≤bt6ExitNorm N x j v.1 v.2.val}
        simp only [Set.mem_iInter,Set.mem_ofPred_eq]
      rw [heq]
      exact (isClosed_iInter fun j : ℕ =>
        isClosed_iInter fun _ : (logSize N)^(32*γ)≤(j:ℝ) =>
        isClosed_iInter fun _ : (j:ℝ)≤logSize N-(logSize N)^(32*γ) =>
        isClosed_le (f := fun _ => Real.sqrt 2*(j:ℝ)-δ) continuous_const (hc j))
    · exact isClosed_le (hc q) continuous_const
  have him := isClosedMap_fst_of_compactSpace s hs
  convert him using 1
  ext f
  constructor
  · rintro ⟨a,ha,hl,hu⟩
    have hI : a∈I := by have hh := abs_le.mp ha; constructor <;> linarith
    exact ⟨(f,⟨a,hI⟩),⟨hl,hu⟩,rfl⟩
  · rintro ⟨⟨g,a⟩,⟨hl,hu⟩,he⟩
    dsimp only [Prod.fst] at he
    subst g
    refine ⟨a.val,?_,hl,hu⟩
    have hh := a.property
    apply abs_le.mpr
    constructor <;> linarith [hh.1,hh.2]

theorem bt6BadField_measurableSet (N : Size) (x : Vertex N) (γ η δ : ℝ) :
    MeasurableSet {f : Vertex N → ℝ | bt6BadField N x γ η δ f} := by
  have he : {f : Vertex N → ℝ | bt6BadField N x γ η δ f}=
      ⋃ q : ℕ, ⋃ (_ : (logSize N)^(1/10:ℝ)≤(q:ℝ)), ⋃ (_ : (q:ℝ)≤logSize N-(logSize N)^(1/10:ℝ)),
        {f : Vertex N → ℝ | ∃ a : ℝ, |a-harmonicExtremeCenter N|≤η ∧
          (∀ j : ℕ, (logSize N)^(32*γ)≤(j:ℝ) → (j:ℝ)≤logSize N-(logSize N)^(32*γ) →
            Real.sqrt 2*(j:ℝ)-δ≤bt6ExitNorm N x j f a) ∧
          bt6ExitNorm N x q f a≤Real.sqrt 2*(q:ℝ)+δ} := by
    ext f
    simp only [Set.mem_ofPred_eq,bt6BadField,mem_iUnion]
    constructor
    · rintro ⟨a,ha,hl,q,hq,hq',hu⟩
      exact ⟨q,hq,hq',a,ha,hl,hu⟩
    · rintro ⟨q,hq,hq',a,ha,hl,hu⟩
      exact ⟨a,ha,hl,q,hq,hq',hu⟩
  rw [he]
  exact MeasurableSet.iUnion fun q => MeasurableSet.iUnion fun _ => MeasurableSet.iUnion fun _ =>
    (bt6_fixed_contact_closed N x γ η δ q).measurableSet

end TorusCoverTime.Blocks.B
