import Solutions.Blocks.B.GaussianClockSegments

/-! Joint independence of arbitrary finite linear observations follows from
the Gaussian path covariance.  Pairwise independence is not substituted for
independence of the complete past and future. -/

noncomputable section
open MeasureTheory ProbabilityTheory
namespace TorusCoverTime.Blocks.B.GaussianClockPath
variable {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
variable {n : ℕ} (W : GaussianClockPath μ n)

theorem linear_indep {I J : Type*} [Fintype I] [Fintype J]
    (L : (Fin (n + 1) → ℝ) →L[ℝ] (I → ℝ))
    (R : (Fin (n + 1) → ℝ) →L[ℝ] (J → ℝ))
    (hcov : ∀ i j, cov[fun ω => L (W.path ω) i, fun ω => R (W.path ω) j; μ] = 0) :
    IndepFun (fun ω => L (W.path ω)) (fun ω => R (W.path ω)) μ :=
  (W.gaussian.map_fun (L.prod R)).indepFun_of_covariance_eval hcov

theorem past_indep_future (cut : Fin (n + 1)) :
    IndepFun (fun ω (i : {i : Fin (n + 1) // i ≤ cut}) => W.path ω i.val)
      (fun ω (j : {j : Fin (n + 1) // cut ≤ j}) => W.path ω j.val - W.path ω cut) μ := by
  let L := ContinuousLinearMap.pi (fun i : {i : Fin (n + 1) // i ≤ cut} =>
    (ContinuousLinearMap.proj i.val : (Fin (n + 1) → ℝ) →L[ℝ] ℝ))
  let R := ContinuousLinearMap.pi (fun j : {j : Fin (n + 1) // cut ≤ j} =>
    (ContinuousLinearMap.proj j.val : (Fin (n + 1) → ℝ) →L[ℝ] ℝ) - ContinuousLinearMap.proj cut)
  exact W.linear_indep L R (fun i j => W.past_increment_covariance i.val cut j.val i.property j.property)

theorem past_indep_increment (lo hi : Fin (n + 1)) (hlohi : lo ≤ hi) :
    IndepFun (fun ω (i : {i : Fin (n + 1) // i ≤ lo}) => W.path ω i.val)
      (fun ω => W.path ω hi - W.path ω lo) μ := by
  simpa only [Function.comp_def, id_eq] using
    (W.past_indep_future lo).comp measurable_id (measurable_pi_apply ⟨hi, hlohi⟩)

end TorusCoverTime.Blocks.B.GaussianClockPath
