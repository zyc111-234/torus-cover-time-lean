import Solutions.Blocks.B.ExteriorHarmonicIdentity

/-! Concrete bounded tests of the harmonic average, usable in the private physical-window interfaces. -/
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B


def exteriorHarmonicDeviationTest (N : Size) (c root : Vertex N) (m : ℕ)
    (w : Fin (2*m) → Vertex N) (q v Δ : ℝ) (z : TraversalExteriorSample m × ℝ) : ℝ≥0∞ :=
  if Δ < |Real.sqrt (exteriorHarmonicOccupation N c root m w q z)-v| then 1 else 0

theorem exteriorHarmonicDeviationTest_measurable (N : Size) (c root : Vertex N) (m : ℕ)
    (w : Fin (2*m) → Vertex N) (q v Δ : ℝ) :
    Measurable (exteriorHarmonicDeviationTest N c root m w q v Δ) :=
  measurable_const.ite
    (measurableSet_lt measurable_const
      (((exteriorHarmonicOccupation_measurable N c root m w q).sqrt.sub_const v).abs)) measurable_const

theorem exteriorHarmonicDeviationTest_le_one (N : Size) (c root : Vertex N) (m : ℕ)
    (w : Fin (2*m) → Vertex N) (q v Δ : ℝ) (z : TraversalExteriorSample m × ℝ) :
    exteriorHarmonicDeviationTest N c root m w q v Δ z ≤ 1 := by
  unfold exteriorHarmonicDeviationTest
  split_ifs <;> simp

theorem exteriorHarmonicDeviationTest_of_identity (N : Size) (c root : Vertex N) (m : ℕ)
    (w : Fin (2*m) → Vertex N) (q v Δ H : ℝ) (z : TraversalExteriorSample m × ℝ)
    (h : H = exteriorHarmonicOccupation N c root m w q z) :
    exteriorHarmonicDeviationTest N c root m w q v Δ z =
      if Δ < |Real.sqrt H-v| then 1 else 0 := by rw [h]; rfl


end TorusCoverTime.Blocks.B

