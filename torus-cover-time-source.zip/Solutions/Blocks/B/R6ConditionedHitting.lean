import Solutions.Blocks.B.DiskHarnack
import Solutions.Blocks.B.R6GreenEstimates

/-! R6.4 for the actual walk conditioned on its specified exterior endpoint.
The harmonic-measure ratio is now proved, not retained as an input. -/

noncomputable section
open MeasureTheory Filter Classical
open scoped Topology
namespace TorusCoverTime.Blocks.B

theorem disk_exitHarmonic_pos (N : Size) (c : Vertex N) (R : ℝ)
    (hR : 0 < R) (hsmall : 2*R < N.val) (a b : Vertex N)
    (ha : a ∈ torusDisk N c R) (hb : diskExteriorNeighbor N c R b) :
    0 < exitHarmonic N (torusDisk N c R) b a :=
  ENNReal.toReal_pos (disk_exit_probability_pos N c R hR hsmall a b ha hb).ne'
    (measure_ne_top walkLaw _)

theorem r6_harnack_geometry (γ : ℝ) (hγ : 0 < γ) :
    ∀ᶠ q : ℝ in atTop, ∀ N : Size, ∀ c a x : Vertex N,
      |periodicDistance a c - Real.exp (q+q^γ)| ≤ 2 →
      x ∈ torusDisk N c (Real.exp q) →
      3*diskHarnackRadiusThreshold ≤ Real.exp (q+2*q^γ) ∧
      periodicDistance a c ≤ Real.exp (q+2*q^γ)/(12*diskGreenInnerScale) ∧
      periodicDistance x c ≤ Real.exp (q+2*q^γ)/(12*diskGreenInnerScale) := by
  have hL := diskGreenInnerScale_ge_four
  have hL0 : 0 < diskGreenInnerScale := by linarith
  have hT := diskHarnackRadiusThreshold_ge_one
  have hT0 : 0 < 3*diskHarnackRadiusThreshold := by linarith
  filter_upwards [eventually_ge_atTop (1:ℝ), eventually_ge_atTop (Real.log (3*diskHarnackRadiusThreshold)),
    (tendsto_rpow_atTop hγ).eventually_ge_atTop (Real.log (48*diskGreenInnerScale))] with q hq hqt hqw
  intro N c a x ha hx
  have hq0 : 0 < q := by linarith
  have hw0 : 0 < q^γ := Real.rpow_pos_of_pos hq0 γ
  have hqexp : 1 ≤ Real.exp q := Real.one_le_exp_iff.mpr (by linarith)
  have hwexp : 48*diskGreenInnerScale ≤ Real.exp (q^γ) := by
    simpa only [Real.exp_log (by positivity : 0 < 48*diskGreenInnerScale)] using Real.exp_le_exp.mpr hqw
  have hρ : 1 ≤ Real.exp (q+q^γ) := Real.one_le_exp_iff.mpr (by linarith)
  have hR : 48*diskGreenInnerScale*Real.exp (q+q^γ) ≤ Real.exp (q+2*q^γ) := by
    rw [show q+2*q^γ = (q+q^γ)+q^γ by ring, Real.exp_add (q+q^γ) (q^γ)]
    nlinarith [Real.exp_pos (q+q^γ)]
  have hinner : Real.exp q ≤ Real.exp (q+q^γ) := Real.exp_le_exp.mpr (by linarith)
  have hax := (abs_le.mp ha).2
  have hxc := (mem_torusDisk N c x (Real.exp q)).mp hx
  refine ⟨?_, ?_, ?_⟩
  · have he := Real.exp_le_exp.mpr (hqt.trans (by linarith : q ≤ q+2*q^γ))
    rwa [Real.exp_log hT0] at he
  · apply (le_div_iff₀ (by positivity)).mpr
    have hm := mul_le_mul_of_nonneg_right (show periodicDistance a c ≤ 3*Real.exp (q+q^γ) by linarith)
      (show 0 ≤ 12*diskGreenInnerScale by positivity)
    nlinarith [mul_nonneg hL0.le (Real.exp_pos (q+q^γ)).le]
  · apply (le_div_iff₀ (by positivity)).mpr
    have hm := mul_le_mul_of_nonneg_right (hxc.le.trans hinner) (show 0 ≤ 12*diskGreenInnerScale by positivity)
    nlinarith [mul_nonneg hL0.le (Real.exp_pos (q+q^γ)).le]

theorem r6_conditioned_point_hit_lower (hWalk : WalkModelRegular) (γ : ℝ) (hγ : 0 < γ) (hγ1 : γ ≤ 1) :
    ∀ᶠ q : ℝ in atTop, ∀ N : Size, ∀ c a b x : Vertex N,
      2*(Real.exp (q+2*q^γ)+1) < N.val →
      |periodicDistance a c - Real.exp (q+q^γ)| ≤ 2 →
      diskExteriorNeighbor N c (Real.exp (q+2*q^γ)) b →
      x ∈ torusDisk N c (Real.exp q) →
      q^γ/(8*diskHarnackConstant*q) ≤
        (exactExitLaw N (torusDisk N c (Real.exp (q+2*q^γ))) a b).real
          (visitsBeforeExit N (torusDisk N c (Real.exp (q+2*q^γ))) a x) := by
  filter_upwards [r6_point_hit_lower hWalk γ hγ hγ1, r6_harnack_geometry γ hγ,
    eventually_ge_atTop (1:ℝ)] with q hhit hgeom hq
  intro N c a b x hsmall ha hb hx
  let R := Real.exp (q+2*q^γ)
  have hR0 : 0 < R := Real.exp_pos _
  obtain ⟨hR, haR, hxR⟩ := hgeom N c a x ha hx
  have hL := diskGreenInnerScale_ge_four
  have hhalf : R/(12*diskGreenInnerScale) ≤ R/2 :=
    div_le_div_of_nonneg_left hR0.le (by norm_num) (by linarith)
  have haD : a ∈ torusDisk N c R := (mem_torusDisk N c a R).mpr (by linarith)
  have hxD : x ∈ torusDisk N c R := (mem_torusDisk N c x R).mpr (by linarith)
  have hpa := disk_exitHarmonic_pos N c R hR0 (by linarith) a b haD hb
  have hH0 : 0 < diskHarnackConstant := zero_lt_one.trans diskHarnackConstant_gt_one
  have hratio : 1/diskHarnackConstant ≤ exitHarmonic N (torusDisk N c R) b x /
      exitHarmonic N (torusDisk N c R) b a := by
    have hh := disk_harnack_small_torus N c R hR hsmall (exitHarmonic N (torusDisk N c R) b)
      (exitHarmonic_nonneg N _ b) (fun z hz => exitHarmonic_generator N _ b z hz) x a hxR haR
    apply (div_le_div_iff₀ hH0 hpa).mpr
    nlinarith
  have hprob := hhit N c a x hsmall ha hx
  have hq0 : 0 < q := by linarith
  have hbase : 0 ≤ q^γ/(8*q) := by positivity
  have hm := mul_le_mul hprob hratio (one_div_nonneg.mpr hH0.le) measureReal_nonneg
  have hid := disk_exactExit_hit_ratio N c R hR0.le hsmall a b x hxD
  rw [← disk_visit_green_ratio hWalk N c R hR0 hsmall a x hxD] at hid
  change _ ≤ (exactExitLaw N (torusDisk N c R) a b).real _
  rw [hid]
  calc
    _ = (q^γ/(8*q))*(1/diskHarnackConstant) := by field_simp
    _ ≤ walkLaw.real (visitsBeforeExit N (torusDisk N c R) a x) *
        (exitHarmonic N (torusDisk N c R) b x / exitHarmonic N (torusDisk N c R) b a) := hm
    _ = _ := by ring

end TorusCoverTime.Blocks.B
