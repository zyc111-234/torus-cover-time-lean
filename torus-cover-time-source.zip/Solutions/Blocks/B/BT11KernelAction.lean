import Solutions.Blocks.B.PointFeynmanKac
import Solutions.Blocks.B.ContinuousFourier

/-! The point-killed kernel acts on arbitrary finite functions. Its exact
generator identity will give a lower survival estimate from a Green barrier. -/
noncomputable section
open MeasureTheory Filter Set Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

theorem bt11_transition_row_sum (N : Size) (a : Vertex N) (t : ℝ) :
    (∑ b : Vertex N, transitionProbability N a b t)=1 := by
  have hm (b : Vertex N) : MeasurableSet {ω | walk N a ω t=b} :=
    ((measurable_walk_eq_joint N a b).comp (measurable_id.prodMk measurable_const)).setOf
  have hi (b : Vertex N) : Integrable (fun ω => if walk N a ω t=b then (1:ℝ) else 0) walkLaw :=
    Integrable.of_bound (Measurable.ite (hm b) measurable_const measurable_const).aestronglyMeasurable
      1 (Eventually.of_forall fun _ => by split_ifs <;> norm_num)
  have he (b : Vertex N) : transitionProbability N a b t=
      ∫ ω, if walk N a ω t=b then (1:ℝ) else 0 ∂walkLaw := by
    simpa [transitionProbability,Measure.real,Set.indicator] using (integral_indicator_one (hm b)).symm
  simp_rw [he]
  rw [← integral_finsetSum _ (fun b _ => hi b)]
  simp

def bt11KillAction (N : Size) (c : Vertex N) (t : ℝ) (f : Vertex N → ℝ) (a : Vertex N) : ℝ :=
  ∑ b, pointKillingKernel N c t a b*f b

theorem bt11KillAction_zero (N : Size) (c a : Vertex N) (f : Vertex N → ℝ) :
    bt11KillAction N c 0 f a=f a := by
  simp [bt11KillAction,pointKillingKernel_zero]

theorem bt11KillAction_mono (N : Size) (c a : Vertex N) (t : ℝ) (ht : 0≤t)
    {f h : Vertex N → ℝ} (hfh : ∀ x,f x≤h x) :
    bt11KillAction N c t f a≤bt11KillAction N c t h a :=
  Finset.sum_le_sum fun b _ => mul_le_mul_of_nonneg_left (hfh b) (pointKillingKernel_nonneg N c a b t ht)

theorem bt11KillAction_one_le (N : Size) (c a : Vertex N) (t : ℝ) (ht : 0≤t) :
    bt11KillAction N c t (fun _ => 1) a≤1 := by
  simp only [bt11KillAction,mul_one]
  exact (Finset.sum_le_sum fun b _ => pointKillingKernel_le_transition N c a b t ht).trans_eq
    (bt11_transition_row_sum N a t)

theorem bt11_generator_pairing (N : Size) (f h : Vertex N → ℝ) :
    (∑ x, generator N f x*h x)=(∑ x,f x*generator N h x) := by
  have he := dirichletPairing_symm N f h
  simp only [dirichletPairing,mul_neg,Finset.sum_neg_distrib] at he
  simpa only [mul_comm] using (neg_inj.mp he).symm

theorem bt11KillAction_hasDerivAt (N : Size) (c a : Vertex N) (f : Vertex N → ℝ) (t : ℝ) :
    HasDerivAt (fun s => bt11KillAction N c s f a)
      (bt11KillAction N c t (fun b => generator N f b-(if b=c then f b else 0)) a) t := by
  have hd := HasDerivAt.fun_sum (u := Finset.univ) (fun b _ =>
    (pointKillingKernel_hasDerivAt N c b a t).mul_const (f b))
  simp_rw [pointKillingKernel_symm N c _ _ a] at hd
  have he : bt11KillAction N c t (fun b => generator N f b-(if b=c then f b else 0)) a=
      ∑ b, (generator N (fun x => pointKillingKernel N c t a x) b-
        (if b=c then pointKillingKernel N c t a b else 0))*f b := by
    simp only [bt11KillAction,sub_mul,mul_sub,Finset.sum_sub_distrib]
    congr 1
    · exact (bt11_generator_pairing N (fun b => pointKillingKernel N c t a b) f).symm
    · simp only [ite_mul,mul_ite,zero_mul,mul_zero]
  rw [he]
  exact hd

end TorusCoverTime.Blocks.B
