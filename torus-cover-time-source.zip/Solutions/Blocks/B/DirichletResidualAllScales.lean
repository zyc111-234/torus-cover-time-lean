import Solutions.Blocks.B.DirichletDiskResidualTail

/-! B.29's simultaneous residual estimate over any finite family of actual
interior exit circles. The scale count is absorbed into a Gaussian log tail. -/

noncomputable section
open MeasureTheory ProbabilityTheory Classical
open scoped BigOperators
namespace TorusCoverTime.Blocks.B

def dirichletResidualTailConstant (A : ℝ) : ℝ :=
  2*Real.exp ((dirichletResidualCrossBound*A)^2/(4*dirichletResidualVarianceBound 1)+1/2)

theorem dirichlet_disk_residual_all_scales {I : Type*} [Fintype I]
    (N : Size) (root c x : Vertex N) (R : ℝ) (r : I → ℝ)
    (hr : ∀ i, 1≤r i) (hsmall : 2*(R+1)<N.val) (hroot : root∉torusDisk N c R)
    (hdeep : ∀ i, periodicDistance x c+(r i+1)≤R/2)
    (hV : 0<dirichletClockLS N root (torusDisk N c R) x)
    (L A t : ℝ) (hL : 0<L) (hcard : (Fintype.card I : ℝ)≤L)
    (ht : |t|≤A*dirichletClockLS N root (torusDisk N c R) x) :
    (finiteFieldLaw N).real {ξ | ∃ i,
      8*dirichletResidualVarianceBound (r i)*(Real.log L)^2 ≤
        ∑ z, exitHarmonic N (torusDisk N x (r i)) z x*
          (dirichletResidualAtEndpoint N root (torusDisk N x (r i)) (torusDisk N c R) x t ξ z)^2} ≤
      dirichletResidualTailConstant A*Real.exp (-((Real.log L)^2)/2) := by
  let E (i : I) : Set (FiniteFieldSample N) := {ξ |
    8*dirichletResidualVarianceBound (r i)*(Real.log L)^2 ≤
      ∑ z, exitHarmonic N (torusDisk N x (r i)) z x*
        (dirichletResidualAtEndpoint N root (torusDisk N x (r i)) (torusDisk N c R) x t ξ z)^2}
  let p := (dirichletResidualCrossBound*A)^2/(4*dirichletResidualVarianceBound 1)
  have hQ : 0<dirichletResidualVarianceBound 1 := by
    have hp := dirichletLogError_pos
    have hl : 0<Real.log 3 := Real.log_pos (by norm_num)
    unfold dirichletResidualVarianceBound
    rw [Real.log_one]
    linarith
  have hq (i : I) : dirichletResidualVarianceBound 1≤dirichletResidualVarianceBound (r i) := by
    unfold dirichletResidualVarianceBound
    rw [Real.log_one]
    linarith [Real.log_nonneg (hr i)]
  have hp (i : I) : (finiteFieldLaw N).real (E i) ≤ 2*Real.exp (p-(Real.log L)^2) := by
    have hh := dirichlet_disk_residual_tail N root c x R (r i) (hr i) hsmall hroot (hdeep i)
      (A*dirichletClockLS N root (torusDisk N c R) x) t ((Real.log L)^2) ht
    have he : dirichletResidualCrossBound*(A*dirichletClockLS N root (torusDisk N c R) x)/
        dirichletClockLS N root (torusDisk N c R) x=dirichletResidualCrossBound*A := by field_simp
    rw [he] at hh
    refine hh.trans (mul_le_mul_of_nonneg_left (Real.exp_le_exp.mpr ?_) (by norm_num))
    apply sub_le_sub_right
    exact div_le_div_of_nonneg_left (sq_nonneg _) (by positivity) (by linarith [hq i])
  have hsum : (finiteFieldLaw N).real (⋃ i, E i) ≤ L*(2*Real.exp (p-(Real.log L)^2)) := by
    calc
      _ ≤ ∑ i, (finiteFieldLaw N).real (E i) := measureReal_iUnion_fintype_le E
      _ ≤ ∑ _i : I, 2*Real.exp (p-(Real.log L)^2) := Finset.sum_le_sum (fun i _ => hp i)
      _ = (Fintype.card I : ℝ)*(2*Real.exp (p-(Real.log L)^2)) := by simp
      _ ≤ _ := mul_le_mul_of_nonneg_right hcard (by positivity)
  change (finiteFieldLaw N).real {ξ | ∃ i, ξ∈E i} ≤ _
  rw [Set.ofPred_exists]
  refine hsum.trans ?_
  calc
    _ = 2*Real.exp (Real.log L+(p-(Real.log L)^2)) := by
      rw [Real.exp_add,Real.exp_log hL]
      ring
    _ ≤ 2*Real.exp ((p+1/2)+(-((Real.log L)^2)/2)) := by
      apply mul_le_mul_of_nonneg_left (Real.exp_le_exp.mpr _) (by norm_num)
      nlinarith [sq_nonneg (Real.log L-1)]
    _ = _ := by rw [Real.exp_add]; unfold dirichletResidualTailConstant; dsimp [p]; ring

def dirichletResidualLogScaleConstant : ℝ := 8*(2+Real.log 3+4*dirichletLogError)

theorem dirichletResidualVarianceBound_log_scale (q : ℝ) (hq : 1≤q) :
    8*dirichletResidualVarianceBound (Real.exp (q+1))≤dirichletResidualLogScaleConstant*q := by
  have he : 0≤1+Real.log 3+4*dirichletLogError := by
    have hp := dirichletLogError_pos
    have hl : 0<Real.log 3 := Real.log_pos (by norm_num)
    linarith
  unfold dirichletResidualVarianceBound dirichletResidualLogScaleConstant
  rw [Real.log_exp]
  nlinarith [mul_nonneg he (sub_nonneg.mpr hq)]

theorem dirichlet_residual_integer_scales {I : Type*} [Fintype I]
    (N : Size) (root c x : Vertex N) (R : ℝ) (q : I → ℕ)
    (hq : ∀ i, 1≤q i) (hsmall : 2*(R+1)<N.val) (hroot : root∉torusDisk N c R)
    (hdeep : ∀ i, periodicDistance x c+(Real.exp ((q i:ℝ)+1)+1)≤R/2)
    (hV : 0<dirichletClockLS N root (torusDisk N c R) x)
    (L A t : ℝ) (hL : 0<L) (hcard : (Fintype.card I : ℝ)≤L)
    (ht : |t|≤A*dirichletClockLS N root (torusDisk N c R) x) :
    (finiteFieldLaw N).real {ξ | ∃ i,
      dirichletResidualLogScaleConstant*(q i:ℝ)*(Real.log L)^2 ≤
        ∑ z, exitHarmonic N (torusDisk N x (Real.exp ((q i:ℝ)+1))) z x*
          (dirichletResidualAtEndpoint N root (torusDisk N x (Real.exp ((q i:ℝ)+1)))
            (torusDisk N c R) x t ξ z)^2} ≤
      dirichletResidualTailConstant A*Real.exp (-((Real.log L)^2)/2) := by
  have hqr (i : I) : (1:ℝ)≤q i := by exact_mod_cast hq i
  have hh := dirichlet_disk_residual_all_scales N root c x R (fun i => Real.exp ((q i:ℝ)+1))
    (fun i => Real.one_le_exp_iff.mpr (by linarith [hqr i])) hsmall hroot hdeep hV L A t hL hcard ht
  refine (measureReal_mono (μ := finiteFieldLaw N) ?_).trans hh
  rintro ξ ⟨i,hi⟩
  refine ⟨i,?_⟩
  exact (mul_le_mul_of_nonneg_right (dirichletResidualVarianceBound_log_scale (q i) (hqr i))
    (sq_nonneg _)).trans hi

end TorusCoverTime.Blocks.B
