import Solutions.Blocks.B.LogarithmicStencil
import Solutions.Blocks.B.LatticeSums

/-! Quantitative logarithmic flux on a square boundary. The limiting flux
is pi/2 for the rate-one four-neighbor generator. -/

noncomputable section
namespace TorusCoverTime.Blocks.B

theorem log_one_add_quadratic_bounds (u : ℝ) (hu : 0 ≤ u) :
    u-u^2 ≤ Real.log (1+u) ∧ Real.log (1+u) ≤ u := by
  have hd : 0 < 1+u := by linarith
  have hlo := Real.one_sub_inv_le_log_of_pos hd
  have hhi := Real.log_le_sub_one_of_pos hd
  have he : 1-(1+u)⁻¹ = u/(1+u) := by field_simp <;> ring
  rw [he] at hlo
  refine ⟨le_trans ?_ hlo, by linarith⟩
  apply (le_div_iff₀ hd).mpr
  nlinarith [mul_nonneg (sq_nonneg u) hu]

def logBoundaryDifference (r k : ℝ) : ℝ :=
  (Real.log ((r+1)^2+k^2)-Real.log (r^2+k^2))/2

theorem logBoundaryDifference_even (r k : ℝ) : logBoundaryDifference r (-k) = logBoundaryDifference r k := by
  simp only [logBoundaryDifference, neg_sq]

theorem logBoundaryDifference_error (r k : ℝ) (hr : 1 ≤ r) :
    |logBoundaryDifference r k-r/(r^2+k^2)| ≤ 5/r^2 := by
  have hr0 : 0 < r := by linarith
  let d := r^2+k^2
  let u := (2*r+1)/d
  have hd : 0 < d := by dsimp only [d]; positivity
  have hu : 0 ≤ u := by dsimp only [u]; positivity
  have hud : u ≤ 3/r := by
    apply (div_le_div_iff₀ hd hr0).mpr
    dsimp only [d]
    nlinarith [sq_nonneg k, mul_nonneg hr0.le (sub_nonneg.mpr hr)]
  have hu2 := pow_le_pow_left₀ hu hud 2
  have hl := log_one_add_quadratic_bounds u hu
  have he : logBoundaryDifference r k = Real.log (1+u)/2 := by
    unfold logBoundaryDifference
    rw [← Real.log_div (by positivity : 0 < (r+1)^2+k^2).ne' hd.ne']
    congr 2
    dsimp only [u,d]
    field_simp
    <;> ring
  have hmain : u/2-r/d = 1/(2*d) := by dsimp only [u]; field_simp <;> ring
  have hinv : 1/d ≤ 1/r^2 := one_div_le_one_div_of_le (sq_pos_of_pos hr0) (by dsimp only [d]; nlinarith [sq_nonneg k])
  have hu2' : u^2 ≤ 9/r^2 := by
    have heq : (3/r)^2 = 9/r^2 := by rw [div_pow]; norm_num
    exact hu2.trans_eq heq
  have hp : 0 ≤ 1/(2*d) := by positivity
  rw [he]
  change |Real.log (1+u)/2-r/d| ≤ 5/r^2
  apply abs_le.mpr
  have hinv0 : 0 ≤ (r^2)⁻¹ := by positivity
  simp only [div_eq_mul_inv, mul_inv_rev] at hmain hinv hu2' hp ⊢
  constructor <;> nlinarith [hl.1,hl.2]

def logSquareFlux (n : ℕ) : ℝ :=
  2*(∑ j ∈ Finset.range (n+1), logBoundaryDifference n j)-logBoundaryDifference n 0

theorem logSquareFlux_error (n : ℕ) (hn : 0 < n) :
    |logSquareFlux n-Real.pi/2| ≤ 32/(n:ℝ) := by
  have hn0 : 0 < (n:ℝ) := by exact_mod_cast hn
  have hn1 : 1 ≤ (n:ℝ) := by exact_mod_cast hn
  let K := fun j : ℕ => (n:ℝ)/((n:ℝ)^2+(j:ℝ)^2)
  let S := 2*(∑ j ∈ Finset.range (n+1), K j)-K 0
  have hrow := lattice_row_bounds n hn
  have hS : S = 2*(n:ℝ)*(∑ j ∈ Finset.range n, 1/((n:ℝ)^2+(j:ℝ)^2)) := by
    dsimp only [S,K]
    rw [Finset.sum_range_succ]
    simp only [Nat.cast_zero, zero_pow (by decide : 2 ≠ 0), add_zero]
    have he : (n:ℝ)/((n:ℝ)^2+(n:ℝ)^2) = 1/(2*n) := by field_simp <;> ring
    have he0 : (n:ℝ)/(n:ℝ)^2 = 1/n := by field_simp <;> ring
    rw [he,he0]
    simp only [div_eq_mul_inv, mul_inv_rev, one_mul, ← Finset.mul_sum]
    ring
  have hSerr : |S-Real.pi/2| ≤ 2/(n:ℝ) := by
    have hl := mul_le_mul_of_nonneg_left hrow.1 (show 0 ≤ 2*(n:ℝ) by positivity)
    have hu := mul_le_mul_of_nonneg_left hrow.2 (show 0 ≤ 2*(n:ℝ) by positivity)
    have hmain : 2*(n:ℝ)*(Real.pi/(4*n)) = Real.pi/2 := by field_simp <;> ring
    have hupper : 2*(n:ℝ)*(Real.pi/(4*n)+1/(n:ℝ)^2) = Real.pi/2+2/n := by field_simp <;> ring
    rw [hmain] at hl
    rw [hupper] at hu
    rw [hS]
    exact abs_le.mpr ⟨by linarith [div_nonneg (by norm_num : (0:ℝ)≤2) hn0.le], by linarith⟩
  have hsum : |(∑ j ∈ Finset.range (n+1), logBoundaryDifference n j)-∑ j ∈ Finset.range (n+1), K j| ≤
      ((n:ℝ)+1)*(5/(n:ℝ)^2) := by
    rw [← Finset.sum_sub_distrib]
    apply (Finset.abs_sum_le_sum_abs _ _).trans
    calc
      _ ≤ ∑ _j ∈ Finset.range (n+1), 5/(n:ℝ)^2 :=
        Finset.sum_le_sum (fun j _ => logBoundaryDifference_error n j hn1)
      _ = _ := by simp
  have hzero := logBoundaryDifference_error n 0 hn1
  have hdiff : |logSquareFlux n-S| ≤ 25/(n:ℝ) := by
    have htri := abs_add_le (2*((∑ j ∈ Finset.range (n+1), logBoundaryDifference n j)-
        ∑ j ∈ Finset.range (n+1), K j)) (-(logBoundaryDifference n 0-K 0))
    simp only [← sub_eq_add_neg, abs_neg] at htri
    rw [abs_mul, abs_of_pos (by norm_num : (0:ℝ)<2)] at htri
    have he : logSquareFlux n-S = 2*((∑ j ∈ Finset.range (n+1), logBoundaryDifference n j)-
        ∑ j ∈ Finset.range (n+1), K j)-(logBoundaryDifference n 0-K 0) := by dsimp only [logSquareFlux,S]; ring
    rw [he]
    apply htri.trans
    have hnum : (2*((n:ℝ)+1)+1)*(5/(n:ℝ)^2) ≤ 25/(n:ℝ) := by
      rw [← mul_div_assoc]
      apply (div_le_div_iff₀ (sq_pos_of_pos hn0) hn0).mpr
      nlinarith
    calc
      _ ≤ 2*(((n:ℝ)+1)*(5/(n:ℝ)^2))+5/(n:ℝ)^2 := by
        exact add_le_add (mul_le_mul_of_nonneg_left hsum (by norm_num))
          (by simpa only [K,Nat.cast_zero] using hzero)
      _ = (2*((n:ℝ)+1)+1)*(5/(n:ℝ)^2) := by ring
      _ ≤ _ := hnum
  have htri := abs_add_le (logSquareFlux n-S) (S-Real.pi/2)
  rw [show logSquareFlux n-S+(S-Real.pi/2) = logSquareFlux n-Real.pi/2 by ring] at htri
  have hp : 0 ≤ 1/(n:ℝ) := by positivity
  calc
    _ ≤ |logSquareFlux n-S|+|S-Real.pi/2| := htri
    _ ≤ 25/(n:ℝ)+2/(n:ℝ) := add_le_add hdiff hSerr
    _ ≤ _ := by simp only [div_eq_mul_inv] at hp ⊢; linarith

end TorusCoverTime.Blocks.B
