import Solutions.Blocks.B.NestedTraversalCount
import Solutions.Blocks.B.TraversalDomainComparison
import Solutions.Blocks.B.TraversalGeometry

/-! Counts of complete inner traversals in disjoint actual outer blocks
sum to at most the original inner traversal count. The comparison is on
jump indices first, and then on the same physical holding-time clock. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

theorem adaptiveExitIndex_le_restart (N : Size) (D E : ℕ → Finset (Vertex N))
    (a : Vertex N) (ω : WalkSample) (m s : ℕ) (hDE : ∀ j, D (m+j) = E j)
    (hstart : adaptiveExitIndex N D a m ω ≤ s)
    (hspec : ∀ j, exitsThroughAt N (E j)
      (adaptiveExitStart N E (position N a ω s) j (fun i => ω (s+i)))
      (adaptiveExitStart N E (position N a ω s) (j+1) (fun i => ω (s+i)))
      (adaptiveExitTail N E (position N a ω s) j (fun i => ω (s+i)))
      (finiteExitIndex N (E j) (adaptiveExitStart N E (position N a ω s) j (fun i => ω (s+i)))
        (adaptiveExitTail N E (position N a ω s) j (fun i => ω (s+i))))) (k : ℕ) :
    adaptiveExitIndex N D a (m+k) ω ≤
      s+adaptiveExitIndex N E (position N a ω s) k (fun i => ω (s+i)) := by
  induction k with
  | zero => simpa using hstart
  | succ k ih =>
    have hs := ih.trans (Nat.add_le_add_left
      (adaptiveExitIndex_mono N E (position N a ω s) (fun i => ω (s+i)) (Nat.le_succ k)) s)
    have hx : position N a ω
        (s+adaptiveExitIndex N E (position N a ω s) (k+1) (fun i => ω (s+i))) ∉ D (m+k) := by
      rw [position_shift_sample,hDE]
      exact (hspec k).1
    rw [show m+(k+1) = (m+k)+1 by omega,adaptiveExitIndex_succ]
    exact shifted_exit_index_le_of_outside N (D (m+k)) a ω
      (adaptiveExitIndex N D a (m+k) ω) _ hs hx

theorem nestedTraversalCount_index_bound_ae (N : Size) (O I J : Finset (Vertex N))
    (hIJ : I ⊆ J) (hI : I.Nonempty) (a : Vertex N) (ha : a ∉ J) :
    ∀ᵐ ω ∂walkLaw, adaptiveExitIndex N (alternatingDomain N I J) a
      (2*nestedTraversalCount N O I J a ω) ω ≤ finiteExitIndex N O a ω := by
  filter_upwards [alternatingExitTime_regular_ae N I J hIJ hI a ha,
    A.holding_positive_and_nonexplosive] with ω hT hreg
  let T := fun k => adaptiveExitTime N (alternatingDomain N I J) a k ω
  let t := finiteExitDuration N O a ω
  have hb := physicalSegmentCount_bounds T (by simp [T,adaptiveExitTime]) hT.2 t (jumpTime_nonneg ω _)
  have hi : 2*nestedTraversalCount N O I J a ω ≤ physicalSegmentCount T t := by
    change 2*(physicalSegmentCount T t/2) ≤ _
    omega
  have ht := (hT.1.monotone hi).trans hb.1
  exact (jumpTime_strictMono hreg.1).le_iff_le.mp ht

theorem all_shifts_adaptive_spec_ae (N : Size) (D : ℕ → Finset (Vertex N))
    (hD : ∀ k, ∃ z : Vertex N, z ∉ D k) :
    ∀ᵐ ω ∂walkLaw, ∀ s : ℕ, ∀ a : Vertex N, ∀ j : ℕ,
      exitsThroughAt N (D j) (adaptiveExitStart N D a j (fun i => ω (s+i)))
        (adaptiveExitStart N D a (j+1) (fun i => ω (s+i)))
        (adaptiveExitTail N D a j (fun i => ω (s+i)))
        (finiteExitIndex N (D j) (adaptiveExitStart N D a j (fun i => ω (s+i)))
          (adaptiveExitTail N D a j (fun i => ω (s+i)))) := by
  apply ae_all_iff.mpr
  intro s
  apply ae_all_iff.mpr
  intro a
  exact (fixedShift_measurePreserving s).quasiMeasurePreserving.ae (adaptiveExit_spec_ae N D hD a)

theorem all_shifts_nestedCount_index_ae (N : Size) (O I J : Finset (Vertex N))
    (hIJ : I ⊆ J) (hI : I.Nonempty) :
    ∀ᵐ ω ∂walkLaw, ∀ s : ℕ, ∀ a : Vertex N, a ∉ J →
      adaptiveExitIndex N (alternatingDomain N I J) a
        (2*nestedTraversalCount N O I J a (fun i => ω (s+i))) (fun i => ω (s+i)) ≤
        finiteExitIndex N O a (fun i => ω (s+i)) := by
  apply ae_all_iff.mpr
  intro s
  apply ae_all_iff.mpr
  intro a
  by_cases ha : a ∈ J
  · exact Eventually.of_forall fun _ hn => False.elim (hn ha)
  · filter_upwards [(fixedShift_measurePreserving s).quasiMeasurePreserving.ae
      (nestedTraversalCount_index_bound_ae N O I J hIJ hI a ha)] with ω hω
    exact fun _ => hω

def outerBlockNestedCount (N : Size) (Q O I J : Finset (Vertex N)) (a : Vertex N)
    (j : ℕ) (ω : WalkSample) : ℕ :=
  nestedTraversalCount N O I J
    (adaptiveExitStart N (alternatingDomain N Q O) a (2*j+1) ω)
    (adaptiveExitTail N (alternatingDomain N Q O) a (2*j+1) ω)

theorem sum_outerBlockNestedCount_le_ae (N : Size) (Q O I J : Finset (Vertex N))
    (hQO : Q ⊆ O) (hQ : Q.Nonempty) (hIJ : I ⊆ J) (hI : I.Nonempty)
    (hJO : J ⊆ O) (root : Vertex N) (hr : root ∉ O)
    (hentry : ∀ᵐ ω ∂walkLaw, ∀ j : ℕ,
      adaptiveExitStart N (alternatingDomain N Q O) root (2*j+1) ω ∉ J) :
    ∀ᵐ ω ∂walkLaw, ∀ t : ℝ, 0 ≤ t →
      (∑ j ∈ Finset.range (completedTraversalCount N Q O root ω t),
        outerBlockNestedCount N Q O I J root j ω) ≤ completedTraversalCount N I J root ω t := by
  have hrJ : root ∉ J := fun h => hr (hJO h)
  filter_upwards [hentry,all_shifts_nestedCount_index_ae N O I J hIJ hI,
    all_shifts_adaptive_spec_ae N (alternatingDomain N I J)
      (alternatingDomain_proper N I J hI ⟨root,hrJ⟩),
    alternatingExitTime_regular_ae N Q O hQO hQ root hr,
    alternatingExitTime_regular_ae N I J hIJ hI root hrJ,
    A.holding_positive_and_nonexplosive] with ω hent hcount hspec hT hU hreg
  let D := alternatingDomain N Q O
  let E := alternatingDomain N I J
  let K := fun j => outerBlockNestedCount N Q O I J root j ω
  have hindices : ∀ m : ℕ, adaptiveExitIndex N E root
      (2*(∑ j ∈ Finset.range m, K j)) ω ≤ adaptiveExitIndex N D root (2*m) ω := by
    intro m
    induction m with
    | zero => simp
    | succ m ih =>
      let s := adaptiveExitIndex N D root (2*m+1) ω
      let a := adaptiveExitStart N D root (2*m+1) ω
      have hs : adaptiveExitIndex N E root (2*(∑ j ∈ Finset.range m, K j)) ω ≤ s :=
        ih.trans (adaptiveExitIndex_mono N D root ω (by omega))
      have hlocal := hcount s a (hent m)
      have hDE : ∀ j, E (2*(∑ i ∈ Finset.range m, K i)+j) = E j := by
        intro j
        simp [E,alternatingDomain,Nat.add_mod,Nat.mul_mod]
      have hcmp := adaptiveExitIndex_le_restart N E E root ω
        (2*(∑ j ∈ Finset.range m, K j)) s hDE hs (hspec s a) (2*K m)
      have hlast := hcmp.trans (Nat.add_le_add_left hlocal s)
      have hout : s+finiteExitIndex N O a (fun i => ω (s+i)) =
          adaptiveExitIndex N D root (2*(m+1)) ω := by
        rw [show 2*(m+1) = (2*m+1)+1 by omega,adaptiveExitIndex_succ]
        rw [show D (2*m+1) = O from alternatingDomain_odd N Q O m]
        rfl
      rw [hout] at hlast
      simpa only [Finset.sum_range_succ,Nat.mul_add] using hlast
  intro t ht
  let m := completedTraversalCount N Q O root ω t
  have hb := physicalSegmentCount_bounds
    (fun j => adaptiveExitTime N D root j ω) (by simp [adaptiveExitTime]) hT.2 t ht
  have hi : 2*m ≤ physicalSegmentCount (fun j => adaptiveExitTime N D root j ω) t := by
    dsimp only [D]
    change 2*(physicalSegmentCount _ t/2) ≤ _
    omega
  have hclock := ((jumpTime_strictMono hreg.1).monotone (hindices m)).trans
    ((hT.1.monotone hi).trans hb.1)
  have hfinal := physicalSegmentCount_ge_of_time
    (fun j => adaptiveExitTime N E root j ω) hU.1.monotone (by simp [adaptiveExitTime]) hU.2 t ht
    (2*(∑ j ∈ Finset.range m, K j)) hclock
  dsimp only [E] at hfinal
  change (∑ j ∈ Finset.range m, K j) ≤ physicalSegmentCount _ t/2
  omega

theorem disk_sum_outerBlockNestedCount_le_ae (N : Size) (c root : Vertex N)
    (r R u v : ℝ) (hr : 0 < r) (hrR : r ≤ R) (hu : 0 < u) (huv : u ≤ v)
    (hsep : v+2 < r) (hroot : root ∉ torusDisk N c R) :
    ∀ᵐ ω ∂walkLaw, ∀ t : ℝ, 0 ≤ t →
      (∑ j ∈ Finset.range (completedTraversalCount N (torusDisk N c r) (torusDisk N c R) root ω t),
        outerBlockNestedCount N (torusDisk N c r) (torusDisk N c R)
          (torusDisk N c u) (torusDisk N c v) root j ω) ≤
        completedTraversalCount N (torusDisk N c u) (torusDisk N c v) root ω t := by
  apply sum_outerBlockNestedCount_le_ae N _ _ _ _ (torusDisk_subset N c r R hrR)
    ⟨c,(mem_torusDisk N c c r).mpr (by simpa only [periodicDistance_self_zero] using hr)⟩
    (torusDisk_subset N c u v huv)
    ⟨c,(mem_torusDisk N c c u).mpr (by simpa only [periodicDistance_self_zero] using hu)⟩
    (torusDisk_subset N c v R (by linarith)) root hroot
  filter_upwards [diskTraversal_geometry_ae N c root r R hr hrR hroot] with ω hω
  intro j hj
  have hdist := (mem_torusDisk N c _ v).mp hj
  have hent := (abs_le.mp (hω j).1).1
  linarith

end TorusCoverTime.Blocks.B
