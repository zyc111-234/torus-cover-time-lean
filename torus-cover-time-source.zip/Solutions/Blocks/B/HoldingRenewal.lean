import Solutions.Blocks.B.WalkRenewal

/-! Conversion of a rate-one first-holding-time integral to a bounded
Volterra integral. Negative residual times are never used. -/
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

theorem integral_holding_renewal (v δ t : ℝ) (hv : 0 ≤ v) (hδ : ‖δ‖ ≤ 1) (ht : 0 ≤ t)
    (f : ℝ → ℝ) (hf : Measurable f) (hb : ∀ s, 0 ≤ s → ‖f s‖ ≤ 1) :
    (∫ s, if t < max s 0 then Real.exp (-v*t)*δ
      else Real.exp (-v*max s 0)*f (t-max s 0) ∂holdingLaw) =
    Real.exp (-(1+v)*t)*δ + ∫ s in Icc 0 t, Real.exp (-(1+v)*s)*f (t-s) := by
  let H : ℝ → ℝ := fun s => if t < max s 0 then Real.exp (-v*t)*δ
    else Real.exp (-v*max s 0)*f (t-max s 0)
  have hm : Measurable H := by
    apply Measurable.ite (measurableSet_lt measurable_const (by fun_prop)) (by fun_prop)
    exact (by fun_prop : Measurable (fun s : ℝ => Real.exp (-v*max s 0))).mul
      (hf.comp (by fun_prop))
  have he (s : ℝ) (hs : 0 ≤ s) : ‖Real.exp (-v*s)‖ ≤ 1 := by
    rw [Real.norm_eq_abs,abs_of_pos (Real.exp_pos _)]
    exact Real.exp_le_one_iff.mpr (mul_nonpos_of_nonpos_of_nonneg (neg_nonpos.mpr hv) hs)
  have hH (s : ℝ) : ‖H s‖ ≤ 1 := by
    dsimp only [H]
    split_ifs with h
    · rw [norm_mul]
      exact (mul_le_mul (he t ht) hδ (norm_nonneg _) zero_le_one).trans_eq (one_mul 1)
    · rw [norm_mul]
      exact (mul_le_mul (he _ (le_max_right _ _)) (hb _ (sub_nonneg.mpr (le_of_not_gt h)))
        (norm_nonneg _) zero_le_one).trans_eq (one_mul 1)
  have hi : IntegrableOn (fun s => Real.exp (-s)*H s) (Ici 0) := by
    apply (integrableOn_exp_neg_mul_Ici (by norm_num : (0:ℝ)<1) 0).mono'
      ((by fun_prop : Measurable (fun s : ℝ => Real.exp (-s))).mul hm).aestronglyMeasurable
    exact Eventually.of_forall fun s => by
      dsimp only [Pi.mul_apply]
      rw [norm_mul,Real.norm_eq_abs,abs_of_pos (Real.exp_pos _)]
      simpa using mul_le_mul_of_nonneg_left (hH s) (Real.exp_pos (-s)).le
  have hi' : IntegrableOn (fun s => Real.exp (-s)*H s) (Ici t) :=
    hi.mono_set (Ici_subset_Ici.mpr ht)
  have hsplit := intervalIntegral.integral_Ici_sub_Ici' hi hi'
  rw [intervalIntegral.integral_of_le ht,← integral_Icc_eq_integral_Ioc] at hsplit
  have hleft : (∫ s in Icc 0 t, Real.exp (-s)*H s) =
      ∫ s in Icc 0 t, Real.exp (-(1+v)*s)*f (t-s) := by
    apply setIntegral_congr_fun measurableSet_Icc
    intro s hs
    dsimp only [H]
    rw [max_eq_left hs.1,if_neg (not_lt.mpr hs.2),← mul_assoc,← Real.exp_add]
    congr 2
    ring
  have hright : (∫ s in Ici t, Real.exp (-s)*H s) = Real.exp (-(1+v)*t)*δ := by
    rw [integral_Ici_eq_integral_Ioi]
    have heq : EqOn (fun s => Real.exp (-s)*H s)
        (fun s => Real.exp (-s)*(Real.exp (-v*t)*δ)) (Ioi t) := by
      intro s hs
      change t < s at hs
      dsimp only [H]
      rw [max_eq_left (ht.trans hs.le),if_pos hs]
    rw [setIntegral_congr_fun measurableSet_Ioi heq,integral_mul_const,← integral_Ici_eq_integral_Ioi]
    have he : (∫ s in Ici t, Real.exp (-s)) = Real.exp (-t) := by
      simpa using integral_exp_neg_mul_Ici (by norm_num : (0:ℝ)<1) t
    rw [he,← mul_assoc,← Real.exp_add]
    congr 2
    ring
  change (∫ s, H s ∂holdingLaw) = _
  rw [integral_holdingLaw]
  rw [hleft,hright] at hsplit
  linarith only [hsplit]

end TorusCoverTime.Blocks.B
