import Solutions.Blocks.B.DirichletWeightedResidual
import Solutions.Blocks.B.GaussianClockScaling

/-! LS normalization of the actual Dirichlet field and its clock.  The
logarithmic clock estimate below retains the project's original disk radius
exp(q+1), including its bounded offset. -/

noncomputable section
open MeasureTheory ProbabilityTheory Classical
namespace TorusCoverTime.Blocks.B
open Blocks.C.C4

def dirichletFieldLS (N : Size) (root : Vertex N) (E : Finset (Vertex N))
    (ξ : FiniteFieldSample N) (x : Vertex N) : ℝ := pinnedDomainField N root E ξ x / Real.sqrt (2*g)

def dirichletClockLS (N : Size) (root : Vertex N) (E : Finset (Vertex N)) (x : Vertex N) : ℝ :=
  pinnedDomainKernel N root E x x / (2*g)

theorem dirichlet_LS_scale_square : (1 / Real.sqrt (2*g))^2 = 1/(2*g) := by
  rw [div_pow, one_pow, Real.sq_sqrt (by unfold g; positivity)]

theorem dirichlet_normalized_path {n : ℕ} (N : Size) (root : Vertex N)
    (D : Fin (n+1) → Finset (Vertex N)) (hD : Monotone D) (hroot : ∀ i, root ∉ D i)
    (hzero : D 0 = ∅) (x : Vertex N) (ξ : FiniteFieldSample N) (i : Fin (n+1)) :
    ((dirichletClockPath N root n D hD hroot hzero x).scale (1/Real.sqrt (2*g))).path ξ i =
      dirichletFieldLS N root (D i) ξ x := by
  dsimp [GaussianClockPath.scale, dirichletClockPath, pinnedScalePath, dirichletFieldLS]
  ring

theorem dirichlet_normalized_clock {n : ℕ} (N : Size) (root : Vertex N)
    (D : Fin (n+1) → Finset (Vertex N)) (hD : Monotone D) (hroot : ∀ i, root ∉ D i)
    (hzero : D 0 = ∅) (x : Vertex N) (i : Fin (n+1)) :
    ((dirichletClockPath N root n D hD hroot hzero x).scale (1/Real.sqrt (2*g))).clock i =
      dirichletClockLS N root (D i) x := by
  change (1/Real.sqrt (2*g))^2 * pinnedDomainKernel N root (D i) x x = _
  rw [dirichlet_LS_scale_square]
  unfold dirichletClockLS
  ring

theorem dirichlet_LS_disk_clock_log (N : Size) (root c : Vertex N) (R : ℝ)
    (hR : 1 ≤ R) (hsmall : 2*(R+1) < N.val) (hroot : root ∉ torusDisk N c R)
    (x : Vertex N) (hx : periodicDistance x c ≤ R/2) :
    |dirichletClockLS N root (torusDisk N c R) x - Real.log R/2| ≤ diskGreenLogErrorConstant/(2*g) := by
  have hg : 0 < g := by unfold g; positivity
  have hh := diskGreen_diagonal_precise N c R hR hsmall x hx
  unfold dirichletClockLS
  rw [congrFun (pinnedDomainKernel_eq_diskGreen N root c R (by linarith) hsmall hroot x) x]
  have he : diskGreen N c R x x/(2*g) - Real.log R/2 =
      (diskGreen N c R x x-g*Real.log R)/(2*g) := by field_simp
  rw [he, abs_div, abs_of_pos (by positivity : 0<2*g)]
  exact div_le_div_of_nonneg_right hh (by positivity)

theorem dirichlet_LS_log_scale_clock (N : Size) (root x : Vertex N) (q : ℝ)
    (hq : 0 ≤ q) (hsmall : 2*(Real.exp (q+1)+1) < N.val)
    (hroot : root ∉ torusDisk N x (Real.exp (q+1))) :
    |dirichletClockLS N root (torusDisk N x (Real.exp (q+1))) x - q/2| ≤
      diskGreenLogErrorConstant/(2*g)+1/2 := by
  have hh := dirichlet_LS_disk_clock_log N root x (Real.exp (q+1))
    (Real.one_le_exp_iff.mpr (by linarith)) hsmall hroot x
    (by rw [periodicDistance_self_zero]; positivity)
  rw [Real.log_exp] at hh
  calc
    _ = |(dirichletClockLS N root (torusDisk N x (Real.exp (q+1))) x - (q+1)/2) + 1/2| := by
      congr 1
      ring
    _ ≤ _ := (abs_add_le _ _).trans (add_le_add hh (by norm_num))

end TorusCoverTime.Blocks.B
