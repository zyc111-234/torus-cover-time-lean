import Solutions.Blocks.B.ExponentialMoments

/-! A direct centered MGF estimate from one positive exponential moment.
The cancellation uses the exact mean, so it does not assume R7's sharper
deterministic centering. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

theorem exp_quadratic_remainder (x : ℝ) :
    |Real.exp x-1-x| ≤ x^2*Real.exp |x| := by
  have h := Complex.norm_exp_sub_sum_le_norm_mul_exp (x:ℂ) 2
  have he : Complex.exp (x:ℂ)-(∑ m ∈ Finset.range 2, (x:ℂ)^m/m.factorial) =
      ((Real.exp x-1-x:ℝ):ℂ) := by
    simp [Finset.sum_range_succ, Complex.ofReal_sub, Complex.ofReal_exp]
    <;> ring
  rw [he] at h
  simpa only [Complex.norm_real, Real.norm_eq_abs, sq_abs] using h

theorem exp_linear_quadratic_bound (x lam θ : ℝ) (hx : 0 ≤ x) (hlam : 0 < lam)
    (hθ : |θ| ≤ lam/2) :
    Real.exp (θ*x) ≤ 1+θ*x+(8*θ^2/lam^2)*Real.exp (lam*x) := by
  have hp := nonnegative_power_le_exp x (lam/2) hx (by positivity) 2
  norm_num only [Nat.factorial_succ, Nat.factorial_zero, Nat.cast_ofNat] at hp
  have he : (2:ℝ)/(lam/2)^2 = 8/lam^2 := by field_simp; ring
  rw [he] at hp
  have hab : |θ*x| = |θ| * x := by rw [abs_mul, abs_of_nonneg hx]
  have hexp : (lam/2)*x+|θ*x| ≤ lam*x := by
    rw [hab]
    nlinarith [mul_le_mul_of_nonneg_right hθ hx]
  have hr := exp_quadratic_remainder (θ*x)
  have htail : (θ*x)^2*Real.exp |θ*x| ≤ (8*θ^2/lam^2)*Real.exp (lam*x) := by
    calc
      _ = θ^2*(x^2*Real.exp |θ*x|) := by ring
      _ ≤ θ^2*((8/lam^2*Real.exp ((lam/2)*x))*Real.exp |θ*x|) :=
        mul_le_mul_of_nonneg_left (mul_le_mul_of_nonneg_right hp (Real.exp_pos _).le) (sq_nonneg θ)
      _ = (8*θ^2/lam^2)*Real.exp ((lam/2)*x+|θ*x|) := by rw [Real.exp_add]; ring
      _ ≤ _ := mul_le_mul_of_nonneg_left (Real.exp_le_exp.mpr hexp) (by positivity)
  linarith [le_abs_self (Real.exp (θ*x)-1-θ*x)]

theorem centered_exp_bound_of_positive_exp {Ω : Type*} [MeasurableSpace Ω]
    (μ : Measure Ω) [IsProbabilityMeasure μ] (X : Ω → ℝ)
    (hX : Measurable X) (hX0 : ∀ ω, 0 ≤ X ω) (lam : ℝ) (hlam : 0 < lam)
    (hbound : (∫⁻ ω, ENNReal.ofReal (Real.exp (lam*X ω)) ∂μ) ≤ 2)
    (θ : ℝ) (hθ : |θ| ≤ lam/2) :
    Integrable (fun ω => Real.exp (θ*(X ω-∫ ω, X ω ∂μ))) μ ∧
      (∫ ω, Real.exp (θ*(X ω-∫ ω, X ω ∂μ)) ∂μ) ≤ Real.exp ((16/lam^2)*θ^2) := by
  have hb : (∫⁻ ω, ENNReal.ofReal (Real.exp (lam*X ω)) ∂μ) ≤ ENNReal.ofReal (2:ℝ) := by
    simpa only [ENNReal.ofReal_ofNat] using hbound
  have hi := integrable_exp_of_lintegral_bound μ X hX lam 2 hb
  have hm := integral_exp_of_lintegral_bound μ X hX lam 2 (by norm_num) hb
  have hiX : Integrable X μ := by
    simpa only [pow_one] using (power_moments_of_exp_bound μ X hX hX0 lam 2 hlam (by norm_num) hb 1).1
  have hθlam : θ ≤ lam := by linarith [le_abs_self θ]
  have hiθ : Integrable (fun ω => Real.exp (θ*X ω)) μ :=
    hi.mono' (hX.const_mul θ).exp.aestronglyMeasurable (Eventually.of_forall fun ω => by
      rw [Real.norm_eq_abs, abs_of_pos (Real.exp_pos _)]
      exact Real.exp_le_exp.mpr (mul_le_mul_of_nonneg_right hθlam (hX0 ω)))
  let C := 8*θ^2/lam^2
  have hC : 0 ≤ C := by dsimp only [C]; positivity
  have hraw : (∫ ω, Real.exp (θ*X ω) ∂μ) ≤ 1+θ*(∫ ω, X ω ∂μ)+2*C := by
    have hu := integral_mono hiθ (((integrable_const (1:ℝ)).add (hiX.const_mul θ)).add (hi.const_mul C))
      (fun ω => exp_linear_quadratic_bound (X ω) lam θ (hX0 ω) hlam hθ)
    change (∫ ω, Real.exp (θ*X ω) ∂μ) ≤ ∫ ω, (1+θ*X ω)+C*Real.exp (lam*X ω) ∂μ at hu
    rw [integral_add (f := fun ω => 1+θ*X ω) (g := fun ω => C*Real.exp (lam*X ω))
      ((integrable_const (1:ℝ)).add (hiX.const_mul θ)) (hi.const_mul C),
      integral_add (f := fun _ => (1:ℝ)) (g := fun ω => θ*X ω)
        (integrable_const (1:ℝ)) (hiX.const_mul θ), integral_const_mul, integral_const_mul] at hu
    simp only [integral_const, Measure.real, measure_univ, ENNReal.toReal_one, smul_eq_mul, one_mul] at hu
    linarith [mul_le_mul_of_nonneg_left hm hC]
  have heq : (fun ω => Real.exp (θ*(X ω-∫ ω, X ω ∂μ))) =
      (fun ω => Real.exp (-(θ*(∫ ω, X ω ∂μ)))*Real.exp (θ*X ω)) := by
    funext ω
    rw [← Real.exp_add]
    congr 1
    ring
  rw [heq]
  refine ⟨hiθ.const_mul _, ?_⟩
  rw [integral_const_mul]
  calc
    _ ≤ Real.exp (-(θ*(∫ ω, X ω ∂μ)))*(1+θ*(∫ ω, X ω ∂μ)+2*C) :=
      mul_le_mul_of_nonneg_left hraw (Real.exp_pos _).le
    _ ≤ Real.exp (-(θ*(∫ ω, X ω ∂μ)))*Real.exp (θ*(∫ ω, X ω ∂μ)+2*C) :=
      mul_le_mul_of_nonneg_left (by linarith [Real.add_one_le_exp (θ*(∫ ω, X ω ∂μ)+2*C)])
        (Real.exp_pos _).le
    _ = _ := by rw [← Real.exp_add]; congr 1; dsimp only [C]; ring

end TorusCoverTime.Blocks.B

