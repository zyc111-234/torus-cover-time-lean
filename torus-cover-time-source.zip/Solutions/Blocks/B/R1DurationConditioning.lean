import Solutions.Blocks.B.ExactExitSoftness
import Solutions.Blocks.B.FiniteExitTail
import Solutions.Blocks.B.FixedCapacity

/-! A closed finite-torus form of the R1 duration-conditioning estimate.
Every probability input below is proved for the concrete walk. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Classical
open scoped ENNReal Topology BigOperators
namespace TorusCoverTime.Blocks.B

lemma conditioned_duration_bound_actual (hWalk : WalkModelRegular)
    (N : Size) (D K : Finset (Vertex N)) (m : ℕ) (a b : Fin m → Vertex N)
    (hD : D.Nonempty) (hproper : D ≠ Finset.univ)
    (hpath : ∀ i, FeasibleAvoidingExit N D K (a i) (b i))
    (hK : K.Nonempty) (u₀ : ℝ) (hu₀ : 0 ≤ u₀) (d : ℝ) (hd : 0 ≤ d) :
    (exactExitProductLaw N D m a b)[{ω | ∃ i : Fin m, d < finiteExitDuration N D (a i) (ω i)} |
      exitBlockSoftness N D K m a u₀] ≤
      ENNReal.ofReal ((m : ℝ) * D.card * Real.exp
        (-d / (4 * greenDiagonal N * D.card) + ((m : ℝ) + 1) * (D.card + 1) * Real.log 4)) := by
  have hb := duration_union_bound_given_softness hWalk N D K m a b hpath hK u₀ hu₀ d
    (ENNReal.ofReal ((D.card : ℝ) * Real.exp (-d / (4 * greenDiagonal N * D.card))))
    (fun i => finiteExitDuration_tail_bound hWalk N D hD hproper (a i) d hd)
  apply hb.trans_eq
  have hpow : (4 : ℝ) ^ ((m + 1) * (D.card + 1)) =
      Real.exp (((m : ℝ) + 1) * (D.card + 1) * Real.log 4) := by
    conv_lhs =>
      rw [show (4 : ℝ) = Real.exp (Real.log 4) from (Real.exp_log (by norm_num)).symm,
        ← Real.exp_nat_mul]
    congr 1
    push_cast
    ring
  calc
    _ = ENNReal.ofReal (((m : ℝ) * ((D.card : ℝ) *
        Real.exp (-d / (4 * greenDiagonal N * D.card)))) *
        (4 : ℝ) ^ ((m + 1) * (D.card + 1))) := by
      conv_rhs =>
        rw [ENNReal.ofReal_mul (by positivity), ENNReal.ofReal_mul (Nat.cast_nonneg m),
          ENNReal.ofReal_pow (by norm_num : (0 : ℝ) ≤ 4)]
      simp only [ENNReal.ofReal_natCast, ENNReal.ofReal_ofNat]
    _ = _ := by
      rw [hpow, Real.exp_add]
      congr 1
      ring

lemma greenDiagonal_eventually_linear (hGreen : GreenEstimates) :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ N : Size in atTop, greenDiagonal N ≤ C * logSize N := by
  obtain ⟨C, hC, hG⟩ := hGreen
  refine ⟨g + C, add_pos (by unfold g; positivity) hC, ?_⟩
  filter_upwards [blockB_logSize_tendsto.eventually_ge_atTop 1] with N hL
  have hd := (abs_le.mp (hG N 0 0).2.1).2
  nlinarith

lemma conditioned_duration_bound_logarithmic (hWalk : WalkModelRegular)
    (N : Size) (D K : Finset (Vertex N)) (m : ℕ) (a b : Fin m → Vertex N)
    (hD : D.Nonempty) (hproper : D ≠ Finset.univ)
    (hpath : ∀ i, FeasibleAvoidingExit N D K (a i) (b i))
    (hK : K.Nonempty) (u₀ : ℝ) (hu₀ : 0 ≤ u₀) (d : ℝ) (hd : 0 ≤ d)
    (C : ℝ) (hC : 0 < C) (hG : greenDiagonal N ≤ C * logSize N) :
    (exactExitProductLaw N D m a b)[{ω | ∃ i : Fin m, d < finiteExitDuration N D (a i) (ω i)} |
      exitBlockSoftness N D K m a u₀] ≤
      ENNReal.ofReal ((m : ℝ) * D.card * Real.exp
        (-d / (4 * C * logSize N * D.card) + ((m : ℝ) + 1) * (D.card + 1) * Real.log 4)) := by
  apply (conditioned_duration_bound_actual hWalk N D K m a b hD hproper hpath hK u₀ hu₀ d hd).trans
  apply ENNReal.ofReal_le_ofReal
  apply mul_le_mul_of_nonneg_left _ (by positivity)
  apply Real.exp_le_exp.mpr
  apply add_le_add _ le_rfl
  have hd0 : 0 < 4 * greenDiagonal N * (D.card : ℝ) :=
    mul_pos (mul_pos (by norm_num) (greenDiagonal_pos N)) (Nat.cast_pos.mpr hD.card_pos)
  have hden : 4 * greenDiagonal N * (D.card : ℝ) ≤ 4 * C * logSize N * D.card := by
    nlinarith [mul_le_mul_of_nonneg_right hG (show 0 ≤ (D.card : ℝ) by positivity)]
  have hdiv := div_le_div_of_nonneg_left hd hd0 hden
  simpa only [neg_div] using neg_le_neg hdiv

end TorusCoverTime.Blocks.B
