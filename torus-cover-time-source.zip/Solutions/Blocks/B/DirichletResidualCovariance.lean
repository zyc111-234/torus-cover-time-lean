import Solutions.Blocks.B.DirichletLSCovariance
import Solutions.Blocks.B.GaussianSlabMoments

/-! Exact mean and covariance of the original exit-average residual.
The boundary variance formula retains the subtraction of the inner clock. -/

noncomputable section
set_option backward.isDefEq.respectTransparency false
open MeasureTheory ProbabilityTheory
open scoped BigOperators
namespace TorusCoverTime.Blocks.B
open Blocks.C.C4

def dirichletLSResidual (N : Size) (root : Vertex N) (D E : Finset (Vertex N))
    (x z : Vertex N) (ξ : FiniteFieldSample N) : ℝ :=
  dirichletFieldLS N root E ξ z-dirichletLSHarmonicAverage N root D E ξ x

theorem dirichletLSResidual_eq (N : Size) (root : Vertex N) (D E : Finset (Vertex N))
    (hDE : D⊆E) (hroot : root∉E) (x z : Vertex N) (ξ : FiniteFieldSample N) :
    dirichletLSResidual N root D E x z ξ =
      dirichletFieldLS N root E ξ z-(dirichletFieldLS N root E ξ x-dirichletFieldLS N root D ξ x) := by
  rw [dirichletLSResidual,dirichlet_LS_harmonic_average N root D E hDE hroot]

theorem dirichletLSResidual_joint_gaussian (N : Size) (root : Vertex N) (D E : Finset (Vertex N))
    (hDE : D⊆E) (hroot : root∉E) (x z : Vertex N) :
    HasGaussianLaw (fun ξ => (dirichletFieldLS N root E ξ x,dirichletLSResidual N root D E x z ξ))
      (finiteFieldLaw N) := by
  let T := (dirichletLSCoordinateMap N root E x).prod
    (dirichletLSCoordinateMap N root E z-(dirichletLSCoordinateMap N root E x-dirichletLSCoordinateMap N root D x))
  simpa only [T,id_eq,ContinuousLinearMap.prod_apply,sub_apply,dirichletLSCoordinateMap_apply,
    dirichletLSResidual_eq N root D E hDE hroot] using (Blocks.D.finiteFieldSample_gaussian N).map_fun T

theorem dirichletLSResidual_measurable (N : Size) (root : Vertex N) (D E : Finset (Vertex N))
    (hDE : D⊆E) (hroot : root∉E) (x z : Vertex N) : Measurable (dirichletLSResidual N root D E x z) := by
  simp_rw [show dirichletLSResidual N root D E x z = fun ξ =>
    dirichletFieldLS N root E ξ z-(dirichletFieldLS N root E ξ x-dirichletFieldLS N root D ξ x)
    from funext (dirichletLSResidual_eq N root D E hDE hroot x z)]
  fun_prop

theorem dirichletLSResidual_mean (N : Size) (root : Vertex N) (D E : Finset (Vertex N))
    (hDE : D⊆E) (hroot : root∉E) (x z : Vertex N) :
    (∫ ξ, dirichletLSResidual N root D E x z ξ ∂finiteFieldLaw N)=0 := by
  have hM : MemLp (fun ξ => dirichletFieldLS N root E ξ x-dirichletFieldLS N root D ξ x) 2 (finiteFieldLaw N) :=
    (dirichletFieldLS_memLp N root E x).sub (dirichletFieldLS_memLp N root D x)
  simp_rw [dirichletLSResidual_eq N root D E hDE hroot]
  rw [integral_sub ((dirichletFieldLS_memLp N root E z).integrable (by norm_num))
      (hM.integrable (by norm_num)),
    integral_sub ((dirichletFieldLS_memLp N root E x).integrable (by norm_num))
      ((dirichletFieldLS_memLp N root D x).integrable (by norm_num))]
  simp only [dirichletFieldLS_mean,sub_self]

theorem dirichletLSResidual_covariance_endpoint (N : Size) (root : Vertex N) (D E : Finset (Vertex N))
    (hDE : D⊆E) (hroot : root∉E) (x z : Vertex N) :
    cov[dirichletLSResidual N root D E x z,fun ξ => dirichletFieldLS N root E ξ x;finiteFieldLaw N]=
      dirichletKernelLS N root E z x-(dirichletClockLS N root E x-dirichletClockLS N root D x) := by
  have hrD : root∉D := fun hh => hroot (hDE hh)
  have hM : MemLp (fun ξ => dirichletFieldLS N root E ξ x-dirichletFieldLS N root D ξ x) 2 (finiteFieldLaw N) :=
    (dirichletFieldLS_memLp N root E x).sub (dirichletFieldLS_memLp N root D x)
  simp_rw [show dirichletLSResidual N root D E x z = fun ξ =>
    dirichletFieldLS N root E ξ z-(dirichletFieldLS N root E ξ x-dirichletFieldLS N root D ξ x)
    from funext (dirichletLSResidual_eq N root D E hDE hroot x z)]
  rw [covariance_fun_sub_left (dirichletFieldLS_memLp N root E z)
      hM (dirichletFieldLS_memLp N root E x),
    covariance_fun_sub_left (dirichletFieldLS_memLp N root E x)
      (dirichletFieldLS_memLp N root D x) (dirichletFieldLS_memLp N root E x),
    dirichletFieldLS_covariance N root E hroot,dirichletFieldLS_covariance N root E hroot,
    dirichletFieldLS_covariance_nested N root D E hDE hrD]
  rfl

theorem dirichletLSResidual_variance_boundary (N : Size) (root : Vertex N) (D E : Finset (Vertex N))
    (hDE : D⊆E) (hroot : root∉E) (x z : Vertex N) (hz : z∉D) :
    Var[dirichletLSResidual N root D E x z;finiteFieldLaw N]=
      dirichletClockLS N root E z+dirichletClockLS N root E x-
        2*dirichletKernelLS N root E z x-dirichletClockLS N root D x := by
  have hrD : root∉D := fun hh => hroot (hDE hh)
  have hM : MemLp (fun ξ => dirichletFieldLS N root E ξ x-dirichletFieldLS N root D ξ x) 2 (finiteFieldLaw N) :=
    (dirichletFieldLS_memLp N root E x).sub (dirichletFieldLS_memLp N root D x)
  simp_rw [show dirichletLSResidual N root D E x z = fun ξ =>
    dirichletFieldLS N root E ξ z-(dirichletFieldLS N root E ξ x-dirichletFieldLS N root D ξ x)
    from funext (dirichletLSResidual_eq N root D E hDE hroot x z)]
  rw [variance_fun_sub (dirichletFieldLS_memLp N root E z)
      hM,
    variance_fun_sub (dirichletFieldLS_memLp N root E x) (dirichletFieldLS_memLp N root D x),
    covariance_fun_sub_right (dirichletFieldLS_memLp N root E z)
      (dirichletFieldLS_memLp N root E x) (dirichletFieldLS_memLp N root D x),
    dirichletFieldLS_variance N root E hroot,dirichletFieldLS_variance N root E hroot,
    dirichletFieldLS_variance N root D hrD,
    dirichletFieldLS_covariance_nested_rev N root D E hDE hrD,
    dirichletFieldLS_covariance N root E hroot,
    dirichletFieldLS_covariance_nested_rev N root D E hDE hrD]
  have hzK : dirichletKernelLS N root D z x=0 := by
    rw [dirichletKernelLS,pinnedDomainKernel_boundary N root D z x hz,zero_div]
  rw [hzK]
  rw [show dirichletKernelLS N root D x x=dirichletClockLS N root D x from rfl]
  ring

theorem dirichlet_LS_exit_square_residual (N : Size) (root : Vertex N) (D E : Finset (Vertex N))
    (hDE : D⊆E) (hroot : root∉E) (x : Vertex N) (a : ℝ) (ξ : FiniteFieldSample N) :
    (∑ z, exitHarmonic N D z x*(dirichletFieldLS N root E ξ z-a)^2)=
      (dirichletLSHarmonicAverage N root D E ξ x-a)^2+
        ∑ z, exitHarmonic N D z x*(dirichletLSResidual N root D E x z ξ)^2 := by
  exact weighted_square_residual (fun z => exitHarmonic N D z x) (dirichletFieldLS N root E ξ)
    (exitHarmonic_sum_one N D (domain_proper_of_root_outside N root D (fun hh => hroot (hDE hh))) x) a

end TorusCoverTime.Blocks.B
