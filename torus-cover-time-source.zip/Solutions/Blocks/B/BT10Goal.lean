import Solutions.Blocks.B.BT8
import Solutions.Blocks.B.BT9
import Solutions.Blocks.B.DefectWindow

/-! B-T10 fixed target B.49: the registered wide-defect set in the original
root-summed physical loop windows. Ordinary paths remain a separate goal. -/
noncomputable section
open MeasureTheory Filter Set Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

def bt10DefectCount (N : Size) (root : Vertex N) (u : ℝ) (z : WalkSample × ℝ) : ℝ :=
  ((wideDefects N (softSet N root z.1 u z.2)).card:ℝ)

theorem bt10DefectCount_measurable (N : Size) (root : Vertex N) (u : ℝ) :
    Measurable (bt10DefectCount N root u) := by
  have hs : Measurable (fun z : WalkSample × ℝ => softSet N root z.1 u z.2) := by
    apply measurable_finset_iff.mpr
    intro x
    apply measurableSet_setOfPred.mp
    simpa only [softSet,Finset.mem_filter,Finset.mem_univ,true_and] using
      measurableSet_le (localTime_joint_measurable N root x) measurable_const
  exact (measurable_of_countable (fun U : Finset (Vertex N) => ((wideDefects N U).card:ℝ))).comp hs

def BT10Conclusion (u : ℝ) : Prop :=
  ∀ H η : ℝ, 0≤H → 0<η → ∀ l r : Size → ℝ,
    (∀ᶠ N : Size in atTop, l N≤r N ∧ phaseACenter N-H*timeScale N≤l N ∧
      r N≤phaseACenter N+H*timeScale N) →
    Tendsto (fun N => r7LoopEventMass N
      (fun root => {z | η*Real.sqrt (logSize N)<bt10DefectCount N root u z}) (l N) (r N))
      atTop (𝓝 0)

def bt10Wide (N : Size) (x y : Vertex N) : Prop :=
  separationRadius N/2 < periodicDistance x y ∧ periodicDistance x y < 2*distantRadius N

def bt10WitnessEvent (N : Size) (root : Vertex N) (γ u : ℝ) : Set (WalkSample × ℝ) :=
  {z | bt8Good N root γ u z ∧ ∃ x y : Vertex N, bt10Wide N x y ∧
    localTime N root z.1 z.2 x≤u ∧ localTime N root z.1 z.2 y≤u ∧ ¬bt8SoftPoint N root x γ u z}

end TorusCoverTime.Blocks.B
