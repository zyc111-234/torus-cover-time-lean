import Solutions.Blocks.B.BT9Goal
import Solutions.Blocks.B.BT9Parameters

/-! The sharp two-site exponent. The negative quadratic excess is retained
until all errors are absorbed, so the coefficient 4 sqrt(2) is unchanged. -/
noncomputable section
open MeasureTheory ProbabilityTheory Filter Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

def bt9SoftnessConstant (U : ℝ) : ℝ := 8*(bt9ParameterConstant+1)+2*U

theorem bt9SoftnessConstant_pos (U : ℝ) (hU : 0 ≤ U) : 0 < bt9SoftnessConstant U := by
  have := bt9ParameterConstant_pos
  unfold bt9SoftnessConstant
  positivity

theorem bt9_pair_softness_expanded (hWalk : WalkModelRegular)
    (γ : ℝ) (hγ : 0 < γ) (hγ1 : γ < 1) :
    ∀ᶠ q : ℝ in atTop, ∀ N : Size, ∀ x z : Vertex N, ∀ m : ℕ,
      ∀ a b : Fin m → Vertex N,
      x ≠ z → q-2 ≤ Real.log (periodicDistance x z) →
      Real.log (periodicDistance x z) < q →
      2*(Real.exp (q+2*q^γ)+1) < N.val →
      (∀ i, |periodicDistance (a i) x-Real.exp (q+q^γ)| ≤ 2) →
      (∀ i, diskExteriorNeighbor N x (Real.exp (q+2*q^γ)) (b i)) →
      ∀ U : ℝ, 0 ≤ U →
      let s := Real.sqrt ((m:ℝ)*q^γ)-Real.sqrt 2*q;
      (exactExitProductLaw N (torusDisk N x (Real.exp (q+2*q^γ))) m a b).real
        {ω | (exitBlockOccupation N (torusDisk N x (Real.exp (q+2*q^γ))) m a ω x+
          exitBlockOccupation N (torusDisk N x (Real.exp (q+2*q^γ))) m a ω z)/g ≤ U} ≤
        Real.exp (-4*q-4*Real.sqrt 2*s-
          (s^2/q)*(2-bt9SoftnessConstant U*(q^γ/q))+bt9SoftnessConstant U*q^γ) := by
  filter_upwards [bt9_actual_green_parameters γ hγ hγ1,
    bt9_parameter_small_errors γ hγ hγ1] with q hparam herr
  intro N x z m a b hcz hlo hhi hsmall ha hb U hU
  have hq : 0 < q := by linarith [herr.1]
  have hscale : 0 ≤ 1-bt9ParameterConstant*(q^γ/q) := by linarith [herr.2.2.2.2.1]
  have hp : 0 ≤ (2*q^γ/q)*(1-bt9ParameterConstant*(q^γ/q)) := mul_nonneg (by positivity) hscale
  have ht := disk_exitBlock_pair_softness_bound hWalk N x _ (Real.exp_pos _).le hsmall
    m a b x z _ (2/q) U hp (by positivity) hU
    (fun i => Classical.choice (hparam N x (a i) (b i) z hcz hlo hhi hsmall (ha i) (hb i)))
  apply ht.trans
  apply Real.exp_le_exp.mpr
  have hs := Real.sq_sqrt (show 0 ≤ (m:ℝ)*q^γ by positivity)
  have he := bt9_exponent_expanded q (Real.sqrt ((m:ℝ)*q^γ)) (q^γ)
    bt9ParameterConstant U hq herr.2.1 bt9ParameterConstant_pos.le hU hscale
  dsimp only at he ⊢
  rw [hs] at he
  dsimp only [bt9SoftnessConstant]
  convert he using 1 ; congr 3 ; ring

theorem bt9_conclusion (hWalk : WalkModelRegular) (γ U : ℝ)
    (hγ : 0 < γ) (hγ1 : γ < 1) (hU : 0 ≤ U) : BT9Conclusion γ U := by
  have hr := (bt9_scale_ratio_limit γ hγ1).const_mul (bt9SoftnessConstant U)
  simp only [mul_zero] at hr
  refine ⟨bt9SoftnessConstant U,bt9SoftnessConstant_pos U hU,?_⟩
  filter_upwards [bt9_pair_softness_expanded hWalk γ hγ hγ1,
    hr.eventually_le_const (by norm_num : (0:ℝ) < 2), eventually_gt_atTop (0:ℝ)]
    with q hsoft herror hq
  intro N x z m a b hcz hlo hhi hsmall ha hb
  apply (hsoft N x z m a b hcz hlo hhi hsmall ha hb U hU).trans
  apply Real.exp_le_exp.mpr
  have hquad := mul_nonneg (div_nonneg
    (sq_nonneg (Real.sqrt ((m:ℝ)*q^γ)-Real.sqrt 2*q)) hq.le)
    (sub_nonneg.mpr herror)
  linarith

theorem bt9_two_soft_subset (N : Size) (D : Finset (Vertex N)) (m : ℕ)
    (a : Fin m → Vertex N) (x z : Vertex N) (u : ℝ) :
    {ω | exitBlockOccupation N D m a ω x ≤ u ∧ exitBlockOccupation N D m a ω z ≤ u} ⊆
      {ω | (exitBlockOccupation N D m a ω x+exitBlockOccupation N D m a ω z)/g ≤ 2*u/g} := by
  intro ω hω
  have hg : 0 < g := by unfold g; positivity
  exact div_le_div_of_nonneg_right (by linarith [hω.1,hω.2]) hg.le

theorem bt9_two_soft_of_total (γ u : ℝ) (h : BT9Conclusion γ (2*u/g)) :
    BT9TwoSoftConclusion γ u := by
  obtain ⟨K,hK,h⟩ := h
  refine ⟨K,hK,?_⟩
  filter_upwards [h] with q hq
  intro N x z m a b hcz hlo hhi hsmall ha hb
  let D := torusDisk N x (Real.exp (q+2*q^γ))
  have (i : Fin m) : IsZeroOrProbabilityMeasure (exactExitLaw N D (a i) (b i)) := by
    unfold exactExitLaw
    infer_instance
  have : IsFiniteMeasure (exactExitProductLaw N D m a b) := by
    unfold exactExitProductLaw
    infer_instance
  exact (measureReal_mono (μ := exactExitProductLaw N D m a b)
    (bt9_two_soft_subset N D m a x z u)).trans (hq N x z m a b hcz hlo hhi hsmall ha hb)

end TorusCoverTime.Blocks.B
