import Solutions.Blocks.B.PointKillingRenewal

/-! Finite-time Feynman--Kac for the actual torus walk. Bounded Volterra
uniqueness is proved on each finite time interval; no process identity is assumed. -/
noncomputable section
open MeasureTheory Filter Set Classical
open scoped ENNReal Topology BigOperators
namespace TorusCoverTime.Blocks.B

theorem point_renewal_integrable (t v : ℝ) (hv : 0 ≤ v) (f : ℝ → ℝ)
    (hf : Measurable f) (hb : ∀ u, 0 ≤ u → ‖f u‖ ≤ 1) :
    IntegrableOn (fun s => Real.exp (-(1+v)*s)*f (t-s)) (Icc 0 t) volume := by
  apply Integrable.of_bound ((by fun_prop : Measurable (fun s : ℝ => Real.exp (-(1+v)*s))).mul
    (hf.comp (by fun_prop))).aestronglyMeasurable 1
  filter_upwards [ae_restrict_mem measurableSet_Icc] with s hs
  dsimp only [Pi.mul_apply,Function.comp_def]
  rw [norm_mul,Real.norm_eq_abs,abs_of_pos (Real.exp_pos _)]
  have he : Real.exp (-(1+v)*s) ≤ 1 := Real.exp_le_one_iff.mpr
    (mul_nonpos_of_nonpos_of_nonneg (by linarith) hs.1)
  exact (mul_le_mul he (hb _ (sub_nonneg.mpr hs.2)) (norm_nonneg _) zero_le_one).trans_eq (one_mul 1)

theorem pointKillingKernel_eq_occupation (N : Size) (c a b : Vertex N) (T : ℝ) (hT : 0 ≤ T) :
    pointKillingKernel N c T a b = pointOccupationKernel N c T a b := by
  let F := fun s x => pointOccupationKernel N c s x b
  let G := fun s x => pointKillingKernel N c s x b
  let S : Set ℝ := {z | ∃ x : Vertex N, ∃ s : ℝ, 0 ≤ s ∧ s ≤ T ∧ z=‖F s x-G s x‖}
  have hS : S.Nonempty := ⟨‖F 0 a-G 0 a‖,a,0,le_rfl,hT,rfl⟩
  have hbd : BddAbove S := by
    refine ⟨2,?_⟩
    rintro z ⟨x,s,hs,_,rfl⟩
    exact (norm_sub_le _ _).trans (by
      have hF := pointOccupationKernel_norm_le_one N c x b s
      have hG := pointKillingKernel_norm_le_one N c x b s hs
      dsimp only [F,G]
      linarith)
  let D := sSup S
  have hsup (x : Vertex N) (s : ℝ) (hs : 0 ≤ s) (hsT : s ≤ T) : ‖F s x-G s x‖ ≤ D :=
    le_csSup hbd ⟨x,s,hs,hsT,rfl⟩
  have hD : 0 ≤ D := (norm_nonneg _).trans (hsup a 0 le_rfl hT)
  have hcontract (x : Vertex N) (t : ℝ) (ht : 0 ≤ t) (htT : t ≤ T) :
      ‖F t x-G t x‖ ≤ D*(1-Real.exp (-T)) := by
    let v := pointSitePotential N c x
    let AF := fun u => (∑ d : Fin 4, F u (x+direction N d))/4
    let AG := fun u => (∑ d : Fin 4, G u (x+direction N d))/4
    have hmF : Measurable AF :=
      (Finset.measurable_sum _ fun d _ => pointOccupationKernel_measurable N c _ b).div_const 4
    have hmG : Measurable AG :=
      (Finset.measurable_sum _ fun d _ => (pointKillingKernel_continuous N c _ b).measurable).div_const 4
    have hiF := point_renewal_integrable t v (pointSitePotential_nonneg N c x) AF hmF
      (fun u _ => four_direction_average_norm fun d => pointOccupationKernel_norm_le_one N c _ b u)
    have hiG := point_renewal_integrable t v (pointSitePotential_nonneg N c x) AG hmG
      (fun u hu => four_direction_average_norm fun d => pointKillingKernel_norm_le_one N c _ b u hu)
    have hid : F t x-G t x =
        ∫ s in Icc 0 t, (Real.exp (-(1+v)*s)*AF (t-s)-Real.exp (-(1+v)*s)*AG (t-s)) := by
      change pointOccupationKernel N c t x b-pointKillingKernel N c t x b = _
      rw [pointOccupationKernel_renewal N c x b t ht,pointKillingKernel_renewal N c x b t ht]
      rw [add_sub_add_left_eq_sub,integral_sub hiF hiG]
    have hpoint (s : ℝ) (hs : s ∈ Icc 0 t) :
        ‖Real.exp (-(1+v)*s)*AF (t-s)-Real.exp (-(1+v)*s)*AG (t-s)‖ ≤ Real.exp (-s)*D := by
      have hav : ‖AF (t-s)-AG (t-s)‖ ≤ D := by
        have hh : AF (t-s)-AG (t-s) =
            (∑ d : Fin 4, (F (t-s) (x+direction N d)-G (t-s) (x+direction N d)))/4 := by
          simp only [AF,AG,Finset.sum_sub_distrib,sub_div]
        rw [hh,norm_div]
        norm_num
        apply (div_le_iff₀ (by norm_num : (0:ℝ)<4)).mpr
        have h := (norm_sum_le Finset.univ _).trans (Finset.sum_le_sum fun d _ =>
          hsup (x+direction N d) (t-s) (sub_nonneg.mpr hs.2) (by linarith [hs.1]))
        simpa [mul_comm] using h
      have he : Real.exp (-(1+v)*s) ≤ Real.exp (-s) := by
        apply Real.exp_le_exp.mpr
        have h := mul_nonneg (pointSitePotential_nonneg N c x) hs.1
        dsimp only [v]
        nlinarith only [h]
      rw [← mul_sub,norm_mul,Real.norm_eq_abs,abs_of_pos (Real.exp_pos _)]
      exact mul_le_mul he hav (norm_nonneg _) (Real.exp_pos _).le
    have hiB : IntegrableOn (fun s => Real.exp (-s)*D) (Icc 0 t) volume :=
      (by fun_prop : Continuous (fun s : ℝ => Real.exp (-s)*D)).continuousOn.integrableOn_Icc
    have hnorm := (norm_integral_le_integral_norm
      (μ := volume.restrict (Icc 0 t))
      (fun s => Real.exp (-(1+v)*s)*AF (t-s)-Real.exp (-(1+v)*s)*AG (t-s))).trans
      (integral_mono_ae (hiF.sub hiG).norm hiB (by
        filter_upwards [ae_restrict_mem measurableSet_Icc] with s hs
        exact hpoint s hs))
    have hint : (∫ s in Icc 0 t, Real.exp (-s)*D) = D*(1-Real.exp (-t)) := by
      rw [integral_mul_const]
      have he := integral_exp_neg_mul_Icc (by norm_num : (0:ℝ)<1) t ht
      simpa [mul_comm] using congrArg (fun r : ℝ => r*D) he
    rw [hint] at hnorm
    rw [hid]
    apply hnorm.trans
    apply mul_le_mul_of_nonneg_left _ hD
    exact sub_le_sub_left (Real.exp_le_exp.mpr (neg_le_neg htT)) 1
  have hDd : D ≤ D*(1-Real.exp (-T)) := by
    apply csSup_le hS
    rintro z ⟨x,s,hs,hsT,rfl⟩
    exact hcontract x s hs hsT
  have hzero : D=0 := by nlinarith [Real.exp_pos (-T)]
  have h := hsup a T hT le_rfl
  rw [hzero] at h
  exact (sub_eq_zero.mp (norm_le_zero_iff.mp h)).symm

theorem pointKillingKernel_nonneg (N : Size) (c a b : Vertex N) (t : ℝ) (ht : 0 ≤ t) :
    0 ≤ pointKillingKernel N c t a b := by
  rw [pointKillingKernel_eq_occupation N c a b t ht]
  exact pointOccupationKernel_nonneg N c a b t

theorem pointKillingKernel_le_transition (N : Size) (c a b : Vertex N) (t : ℝ) (ht : 0 ≤ t) :
    pointKillingKernel N c t a b ≤ transitionProbability N a b t := by
  rw [pointKillingKernel_eq_occupation N c a b t ht]
  exact pointOccupationKernel_le_transition N c a b t

end TorusCoverTime.Blocks.B
