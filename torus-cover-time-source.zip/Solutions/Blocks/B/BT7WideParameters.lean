import Solutions.Blocks.B.BT6PowerParameters

noncomputable section
open Filter
namespace TorusCoverTime.Blocks.B

/-- Both errors may grow as L^(16γ), comfortably above the binding cutoff
L^(12γ), while remaining below the bridge clearance L^(32γ). -/
theorem bt7_wide_parameters (γ C : ℝ) (K : ℕ) (hγ : 0<γ) (hγhi : 32*γ<1/10) (hC : 0≤C) :
    ∀ᶠ L : ℝ in atTop,
      8*(C+1)≤L ∧ 2*(K:ℝ)≤L ∧
      1≤L^(32*γ) ∧ L^(32*γ)≤L^(1/10:ℝ) ∧ 4*C≤L^(32*γ) ∧
      4*(K:ℝ)≤L^(1/10:ℝ) ∧ L^(1/10:ℝ)≤L/4 ∧
      0≤L^(16*γ) ∧ L^(16*γ)≤L ∧ 0≤L^(16*γ) ∧
      2*L^(16*γ)+6*bt6BridgeError L C (L^(16*γ))≤L^(32*γ) ∧
      (K:ℝ)≤L^(32*γ) ∧ (Real.log L)^2+4*Real.log L≤L^(32*γ) := by
  have ha : 0<32*γ := by linarith
  have hb := bt6_polylog_subpower (32*γ) (16*γ) 14 (6*dirichletResidualLogScaleConstant)
    6 (24*Real.sqrt 2*C) ha (by linarith)
  have hS := bt6_polylog_subpower 1 (1/10) 4 0 0 0 (by norm_num) (by norm_num)
  have htail := bt6_polylog_subpower (32*γ) 0 0 1 4 0 ha ha
  filter_upwards [eventually_ge_atTop (8*(C+1)),eventually_ge_atTop (2*(K:ℝ)),
    (tendsto_rpow_atTop ha).eventually_ge_atTop 1,
    (tendsto_rpow_atTop ha).eventually_ge_atTop (4*C),
    (tendsto_rpow_atTop (by norm_num : (0:ℝ)<1/10)).eventually_ge_atTop (4*(K:ℝ)),
    (tendsto_rpow_atTop ha).eventually_ge_atTop (K:ℝ),hb,hS,htail]
    with L hL hLK hA hAC hSK hAK hbudget hs ht
  have hl1 : 1≤L := by linarith
  have hl0 : 0≤L := by linarith
  simp only [zero_mul,zero_add,add_zero,Real.rpow_one,one_mul] at hs ht
  refine ⟨hL,hLK,hA,Real.rpow_le_rpow_of_exponent_le hl1 hγhi.le,hAC,hSK,by linarith,
    by positivity,?_,by positivity,?_,hAK,ht⟩
  · simpa only [Real.rpow_one] using Real.rpow_le_rpow_of_exponent_le hl1 (show 16*γ≤1 by linarith)
  · unfold bt6BridgeError
    nlinarith only [hbudget]

end TorusCoverTime.Blocks.B
