import Solutions.Blocks.B.OccupationExponential

/-! A finite positive exponential moment proves every power integrable and
gives the factorial moment estimate; neither fact is an input. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

theorem integrable_exp_of_lintegral_bound {Ω : Type*} [MeasurableSpace Ω]
    (μ : Measure Ω) (X : Ω → ℝ) (hX : Measurable X) (θ M : ℝ)
    (hbound : (∫⁻ ω, ENNReal.ofReal (Real.exp (θ*X ω)) ∂μ) ≤ ENNReal.ofReal M) :
    Integrable (fun ω => Real.exp (θ*X ω)) μ := by
  refine ⟨(hX.const_mul θ).exp.aestronglyMeasurable, ?_⟩
  exact (hasFiniteIntegral_iff_ofReal (Eventually.of_forall fun ω => (Real.exp_pos _).le)).mpr
    (hbound.trans_lt ENNReal.ofReal_lt_top)

theorem integral_exp_of_lintegral_bound {Ω : Type*} [MeasurableSpace Ω]
    (μ : Measure Ω) (X : Ω → ℝ) (hX : Measurable X) (θ M : ℝ) (hM : 0 ≤ M)
    (hbound : (∫⁻ ω, ENNReal.ofReal (Real.exp (θ*X ω)) ∂μ) ≤ ENNReal.ofReal M) :
    (∫ ω, Real.exp (θ*X ω) ∂μ) ≤ M := by
  rw [integral_eq_lintegral_of_nonneg_ae (Eventually.of_forall fun ω => (Real.exp_pos _).le)
    (hX.const_mul θ).exp.aestronglyMeasurable]
  exact (ENNReal.toReal_mono ENNReal.ofReal_ne_top hbound).trans_eq (ENNReal.toReal_ofReal hM)

theorem nonnegative_power_le_exp (x θ : ℝ) (hx : 0 ≤ x) (hθ : 0 < θ) (j : ℕ) :
    x^j ≤ (j.factorial:ℝ)/θ^j*Real.exp (θ*x) := by
  have hfact : 0 < (j.factorial:ℝ) := by positivity
  have he := (div_le_iff₀ hfact).mp (Real.pow_div_factorial_le_exp (θ*x) (mul_nonneg hθ.le hx) j)
  rw [mul_pow] at he
  rw [div_mul_eq_mul_div]
  apply (le_div_iff₀ (pow_pos hθ j)).mpr
  nlinarith

theorem power_moments_of_exp_bound {Ω : Type*} [MeasurableSpace Ω]
    (μ : Measure Ω) (X : Ω → ℝ) (hX : Measurable X) (hX0 : ∀ ω, 0 ≤ X ω)
    (θ M : ℝ) (hθ : 0 < θ) (hM : 0 ≤ M)
    (hbound : (∫⁻ ω, ENNReal.ofReal (Real.exp (θ*X ω)) ∂μ) ≤ ENNReal.ofReal M)
    (j : ℕ) : Integrable (fun ω => (X ω)^j) μ ∧
      (∫ ω, (X ω)^j ∂μ) ≤ M*(j.factorial:ℝ)/θ^j := by
  have hi := integrable_exp_of_lintegral_bound μ X hX θ M hbound
  have hm := integral_exp_of_lintegral_bound μ X hX θ M hM hbound
  have hC : 0 ≤ (j.factorial:ℝ)/θ^j := by positivity
  have hpoint := fun ω => nonnegative_power_le_exp (X ω) θ (hX0 ω) hθ j
  have hj : Integrable (fun ω => (X ω)^j) μ :=
    (hi.const_mul ((j.factorial:ℝ)/θ^j)).mono' (hX.pow_const j).aestronglyMeasurable
      (Eventually.of_forall fun ω => by
        rw [Real.norm_eq_abs, abs_of_nonneg (pow_nonneg (hX0 ω) j)]
        exact hpoint ω)
  refine ⟨hj, ?_⟩
  calc
    _ ≤ ∫ ω, ((j.factorial:ℝ)/θ^j)*Real.exp (θ*X ω) ∂μ :=
      integral_mono hj (hi.const_mul _) hpoint
    _ = ((j.factorial:ℝ)/θ^j)*(∫ ω, Real.exp (θ*X ω) ∂μ) := integral_const_mul _ _
    _ ≤ ((j.factorial:ℝ)/θ^j)*M := mul_le_mul_of_nonneg_left hm hC
    _ = _ := by ring

end TorusCoverTime.Blocks.B
