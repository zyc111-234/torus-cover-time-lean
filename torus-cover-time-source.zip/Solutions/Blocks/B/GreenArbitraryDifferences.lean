import Solutions.Blocks.B.GreenNearestDifferences
import Solutions.Blocks.B.RectangularPaths
import Solutions.Blocks.B.GridTelescoping

/-! Off-diagonal Green differences between arbitrary nearby points, by controlled lattice paths. -/

noncomputable section
open scoped BigOperators
namespace TorusCoverTime.Blocks.B

def NearestGreenControl (C : ℝ) : Prop :=
  ∀ N : Size, ∀ z : Vertex N, 0 < periodicDistance z 0 → ∀ d d' : Fin 4,
    |greenKernel N (z + direction N d) 0 - greenKernel N z 0| ≤ C / periodicDistance z 0 ∧
    |greenKernel N (z + direction N d + direction N d') 0 -
      greenKernel N (z + direction N d) 0 - greenKernel N (z + direction N d') 0 + greenKernel N z 0| ≤
      C / periodicDistance z 0 ^ 2

lemma green_step_first {C : ℝ} (hNear : NearestGreenControl C)
    (N : Size) (x y : Vertex N) (hd : 0 < periodicDistance x y) (d : Fin 4) :
    |greenKernel N (x + direction N d) y - greenKernel N x y| ≤ C / periodicDistance x y := by
  rw [greenKernel_sub_zero N (x + direction N d) y, greenKernel_sub_zero N x y,
    show x + direction N d - y = (x - y) + direction N d by abel,
    ← periodicDistance_sub_zero N x y]
  exact (hNear N (x - y) (by rwa [periodicDistance_sub_zero]) d 0).1

lemma green_step_mixed {C : ℝ} (hNear : NearestGreenControl C)
    (N : Size) (x y : Vertex N) (hd : 0 < periodicDistance x y) (d e : Fin 4) :
    |greenKernel N (x + direction N d) (y + direction N e) -
      greenKernel N x (y + direction N e) - greenKernel N (x + direction N d) y + greenKernel N x y| ≤
      C / periodicDistance x y ^ 2 := by
  obtain ⟨e', he⟩ := direction_neg_exists N e
  rw [greenKernel_sub_zero N (x + direction N d) (y + direction N e),
    greenKernel_sub_zero N x (y + direction N e), greenKernel_sub_zero N (x + direction N d) y,
    greenKernel_sub_zero N x y,
    show (x + direction N d) - (y + direction N e) = (x - y) + direction N d + direction N e' by rw [he]; abel,
    show x - (y + direction N e) = (x - y) + direction N e' by rw [he]; abel,
    show x + direction N d - y = (x - y) + direction N d by abel,
    ← periodicDistance_sub_zero N x y]
  have h := (hNear N (x - y) (by rwa [periodicDistance_sub_zero]) d e').2
  convert h using 1 <;> ring

lemma green_arbitrary_differences_of_nearest (C : ℝ) (hC : 0 < C) (hNear : NearestGreenControl C)
    (N : Size) (D : ℝ) (hD : 0 < D) (x x' y y' : Vertex N)
    (hx : periodicDistance x x' ≤ D / 4) (hy : periodicDistance y y' ≤ D / 4)
    (hsep : D ≤ periodicDistance x' y) :
    |greenKernel N x y - greenKernel N x' y| ≤ 16 * C * periodicDistance x x' / D ∧
    |greenKernel N x y - greenKernel N x' y - greenKernel N x y' + greenKernel N x' y'| ≤
      16 * C * periodicDistance x x' * periodicDistance y y' / D ^ 2 := by
  let P := fun i => x' + rectangularPath N (x - x') i
  let Q := fun j => y + rectangularPath N (y' - y) j
  let m := rectangularPathLength N (x - x')
  let n := rectangularPathLength N (y' - y)
  have hP0 : P 0 = x' := by simp [P, rectangularPath_zero]
  have hQ0 : Q 0 = y := by simp [Q, rectangularPath_zero]
  have hPm : P m = x := by simp [P, m, rectangularPath_endpoint]
  have hQn : Q n = y' := by simp [Q, n, rectangularPath_endpoint]
  have hm : (m : ℝ) ≤ 2 * periodicDistance x x' := by
    simpa only [m, periodicDistance_sub_zero] using rectangularPath_length_le N (x - x')
  have hn : (n : ℝ) ≤ 2 * periodicDistance y y' := by
    simpa only [n, periodicDistance_sub_zero, periodicDistance_comm y' y] using
      rectangularPath_length_le N (y' - y)
  have hdist (i j : ℕ) : D / 2 ≤ periodicDistance (P i) (Q j) := by
    have h := periodicDistance_perturbation_lower N x' y (rectangularPath N (x - x') i)
      (rectangularPath N (y' - y) j)
    have hp := rectangularPath_distance_le N (x - x') i
    have hq := rectangularPath_distance_le N (y' - y) j
    rw [periodicDistance_sub_zero] at hp hq
    rw [periodicDistance_comm y' y] at hq
    change periodicDistance x' y - periodicDistance (rectangularPath N (x - x') i) 0 -
      periodicDistance (rectangularPath N (y' - y) j) 0 ≤ periodicDistance (P i) (Q j) at h
    linarith
  have hPstep (i : ℕ) (hi : i < m) : ∃ d : Fin 4, P (i + 1) = P i + direction N d := by
    obtain ⟨d, hd⟩ := rectangularPath_step N (x - x') i hi
    exact ⟨d, by dsimp [P]; rw [hd, add_assoc]⟩
  have hQstep (j : ℕ) (hj : j < n) : ∃ d : Fin 4, Q (j + 1) = Q j + direction N d := by
    obtain ⟨d, hd⟩ := rectangularPath_step N (y' - y) j hj
    exact ⟨d, by dsimp [Q]; rw [hd, add_assoc]⟩
  have hfirst : |greenKernel N (P m) (Q 0) - greenKernel N (P 0) (Q 0)| ≤ (m : ℝ) * (2 * C / D) := by
    apply abs_endpoint_sub_le_steps (fun i => greenKernel N (P i) (Q 0)) m (2 * C / D)
    intro i hi
    obtain ⟨d, hd⟩ := hPstep i hi
    rw [hd]
    have hdpos : 0 < periodicDistance (P i) (Q 0) := (half_pos hD).trans_le (hdist i 0)
    apply (green_step_first hNear N (P i) (Q 0) hdpos d).trans
    calc
      C / periodicDistance (P i) (Q 0) ≤ C / (D / 2) := div_le_div_of_nonneg_left hC.le (half_pos hD) (hdist i 0)
      _ = _ := by ring
  have hmixed : |greenKernel N (P m) (Q n) - greenKernel N (P 0) (Q n) -
      greenKernel N (P m) (Q 0) + greenKernel N (P 0) (Q 0)| ≤ (m : ℝ) * (n : ℝ) * (4 * C / D ^ 2) := by
    apply abs_grid_mixed_le (fun i j => greenKernel N (P i) (Q j)) m n (4 * C / D ^ 2)
    intro i hi j hj
    obtain ⟨d, hd⟩ := hPstep i hi
    obtain ⟨e, he⟩ := hQstep j hj
    rw [hd, he]
    have hdpos : 0 < periodicDistance (P i) (Q j) := (half_pos hD).trans_le (hdist i j)
    apply (green_step_mixed hNear N (P i) (Q j) hdpos d e).trans
    calc
      C / periodicDistance (P i) (Q j) ^ 2 ≤ C / (D / 2) ^ 2 :=
        div_le_div_of_nonneg_left hC.le (by positivity) (pow_le_pow_left₀ (by positivity) (hdist i j) 2)
      _ = _ := by ring
  rw [hPm, hP0, hQ0] at hfirst
  rw [hPm, hP0, hQn, hQ0] at hmixed
  have hdx : 0 ≤ periodicDistance x x' := Real.sqrt_nonneg _
  have hdy : 0 ≤ periodicDistance y y' := Real.sqrt_nonneg _
  constructor
  · calc
      _ ≤ (m : ℝ) * (2 * C / D) := hfirst
      _ ≤ (2 * periodicDistance x x') * (2 * C / D) := mul_le_mul_of_nonneg_right hm (by positivity)
      _ ≤ 16 * C * periodicDistance x x' / D := by
        rw [← mul_div_assoc]
        apply (div_le_div_iff_of_pos_right hD).mpr
        nlinarith [mul_nonneg hC.le hdx]
  · have heq : |greenKernel N x y - greenKernel N x' y - greenKernel N x y' + greenKernel N x' y'| =
        |greenKernel N x y' - greenKernel N x' y' - greenKernel N x y + greenKernel N x' y| := by
      rw [← abs_neg]
      congr 1
      ring
    rw [heq]
    calc
      _ ≤ (m : ℝ) * (n : ℝ) * (4 * C / D ^ 2) := hmixed
      _ ≤ (2 * periodicDistance x x') * (2 * periodicDistance y y') * (4 * C / D ^ 2) :=
        mul_le_mul_of_nonneg_right (mul_le_mul hm hn (Nat.cast_nonneg _) (by positivity)) (by positivity)
      _ = _ := by ring

end TorusCoverTime.Blocks.B
