import Solutions.Blocks.B.FiniteActionScan

/-! All stopped record actions concatenate to the original finite path scanner. -/
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B


def adaptiveRecordScanAction (N : Size) (I O : Finset (Vertex N)) (D : ℕ → Finset (Vertex N))
    (a : Vertex N) (ω : WalkSample) (j k : ℕ) : ℕ :=
  traversalPrefixScan N I O (adaptiveExitStart N D a j ω)
    (adaptiveExitRecord N D a j ω).2 (adaptiveExitRecord N D a j ω).1 k

theorem adaptiveRecordScanAction_eq_tail (N : Size) (I O : Finset (Vertex N))
    (D : ℕ → Finset (Vertex N)) (a : Vertex N) (ω : WalkSample) (j k : ℕ) :
    adaptiveRecordScanAction N I O D a ω j k =
      traversalPrefixScan N I O (adaptiveExitStart N D a j ω) (adaptiveExitTail N D a j ω)
        (finiteExitIndex N (D j) (adaptiveExitStart N D a j ω) (adaptiveExitTail N D a j ω)) k :=
  traversalPrefixScan_prefix N I O _ _ _ _
    (finiteExitRecord_agrees N _ _ _) k

theorem adaptive_record_scan_prefix (N : Size) (I O : Finset (Vertex N))
    (D : ℕ → Finset (Vertex N)) (a : Vertex N) (ω : WalkSample) (n k : ℕ) :
    finiteActionScan (adaptiveRecordScanAction N I O D a ω) n k =
      traversalPrefixScan N I O a ω (adaptiveExitIndex N D a n ω) k := by
  induction n with
  | zero => simp [finiteActionScan]
  | succ n ih =>
    rw [finiteActionScan,ih,adaptiveExitIndex_succ,traversalPrefixScan_add,
      adaptiveRecordScanAction_eq_tail]
    rfl


end TorusCoverTime.Blocks.B

