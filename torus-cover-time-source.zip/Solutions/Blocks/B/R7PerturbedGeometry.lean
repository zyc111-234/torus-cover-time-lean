import Solutions.Blocks.B.R7PerturbedRadii

/-! The unchanged harmonic averaging circle fits inside the perturbed
entrance, and the original oscillation region fits inside the enlarged disk. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

theorem r7_perturbed_probe_geometry (γ : ℝ) (hγ : 0 < γ) (hγ1 : γ < 1) :
    ∀ᶠ q : ℝ in atTop,
      Real.exp (q+1)+3 < r7PerturbedInner q (q^γ) ∧
      r7PerturbedInner q (q^γ)+2 < 2*Real.exp (q+q^γ) ∧
      2*Real.exp (q+q^γ) ≤ r7PerturbedOuter q (q^γ) := by
  filter_upwards [r7_perturbed_scale_conditions γ hγ hγ1] with q hs
  obtain ⟨hq,hh,hl,he,hqh⟩ := hs
  have hexp : (16:ℝ) ≤ Real.exp (q^γ-1) := by
    simpa only [Real.exp_log (by norm_num : (0:ℝ) < 16)] using
      Real.exp_le_exp.mpr (show Real.log 16 ≤ q^γ-1 by linarith)
  have hρ : 16*Real.exp (q+1) ≤ Real.exp (q+q^γ) := by
    have h := mul_le_mul_of_nonneg_left hexp (Real.exp_pos (q+1)).le
    rw [← Real.exp_add] at h
    simpa only [show q+1+(q^γ-1) = q+q^γ by ring,mul_comm] using h
  have heq : Real.exp q ≤ Real.exp (q+1) := Real.exp_le_exp.mpr (by linarith)
  have hr : 1 ≤ Real.exp (q+1) := Real.one_le_exp_iff.mpr (by linarith)
  have h4 : (4:ℝ) ≤ Real.exp (q^γ) := by
    have h1 := Real.exp_le_exp.mpr (show q^γ-1 ≤ q^γ by linarith)
    linarith
  have hR : 4*Real.exp (q+q^γ) ≤ Real.exp (q+2*q^γ) := by
    have h := mul_le_mul_of_nonneg_left h4 (Real.exp_pos (q+q^γ)).le
    rw [← Real.exp_add] at h
    simpa only [show q+q^γ+q^γ = q+2*q^γ by ring,mul_comm] using h
  dsimp only [r7PerturbedInner,r7PerturbedOuter]
  exact ⟨by linarith,by linarith [Real.exp_pos q],by linarith [Real.exp_pos q]⟩

theorem r7_perturbed_exit_ratio (γ : ℝ) (hγ : 0 < γ) :
    ∀ᶠ q : ℝ in atTop, ∀ N : Size, ∀ c b z z' : Vertex N,
      2*(r7PerturbedOuter q (q^γ)+1) < N.val →
      diskExteriorNeighbor N c (r7PerturbedOuter q (q^γ)) b →
      z ∈ torusDisk N c (2*Real.exp (q+q^γ)) →
      z' ∈ torusDisk N c (2*Real.exp (q+q^γ)) →
      |exitHarmonic N (torusDisk N c (r7PerturbedOuter q (q^γ))) b z /
        exitHarmonic N (torusDisk N c (r7PerturbedOuter q (q^γ))) b z'-1| ≤
        diskExitOscillationConstant*Real.exp (-diskExitOscillationExponent*q^γ) := by
  filter_upwards [r6_oscillation_rate_geometry γ hγ] with q hs
  intro N c b z z' hsmall hb hz hz'
  have hR : Real.exp (q+2*q^γ) ≤ r7PerturbedOuter q (q^γ) := by
    unfold r7PerturbedOuter
    linarith [Real.exp_pos q]
  have hscaled : (Real.exp (q+2*q^γ)/(24*diskGreenInnerScale))/
      diskOscillationScale^(diskOscillationSteps (q^γ)) ≤
      (r7PerturbedOuter q (q^γ)/(24*diskGreenInnerScale))/
      diskOscillationScale^(diskOscillationSteps (q^γ)) := by
    have hL : 0 ≤ 24*diskGreenInnerScale := by have := diskGreenInnerScale_ge_four; positivity
    have hS : 0 ≤ diskOscillationScale := by linarith [diskOscillationScale_ge_two]
    exact div_le_div_of_nonneg_right (div_le_div_of_nonneg_right hR hL) (pow_nonneg hS _)
  have hzR := (mem_torusDisk N c z _).mpr (((mem_torusDisk N c z _).mp hz).trans_le (hs.2.2.trans hscaled))
  have hzR' := (mem_torusDisk N c z' _).mpr (((mem_torusDisk N c z' _).mp hz').trans_le (hs.2.2.trans hscaled))
  exact (disk_exit_relative_oscillation N c _ (hs.1.trans hR) hsmall z' b z hb
    (diskOscillationSteps (q^γ)) (hs.2.1.trans hscaled) hzR' hzR).trans (diskOscillationSteps_decay (q^γ))

theorem r7_perturbed_entrance_support (γ : ℝ) (hγ : 0 < γ) (hγ1 : γ < 1) :
    ∀ᶠ q : ℝ in atTop, ∀ N : Size, ∀ c : Vertex N,
      (∀ a : Vertex N, |periodicDistance a c-r7PerturbedInner q (q^γ)| ≤ 2 →
        a ∉ torusDisk N c (Real.exp (q+1)) ∧
        a ∈ torusDisk N c (2*Real.exp (q+q^γ)) ∧
        a ∈ torusDisk N c (r7PerturbedOuter q (q^γ))) ∧
      (∀ z : Vertex N, diskHarmonicWeight N c (Real.exp (q+1)) z ≠ 0 →
        z ∈ torusDisk N c (2*Real.exp (q+q^γ))) ∧
      Real.exp (q+1) ≤ r7PerturbedOuter q (q^γ) := by
  filter_upwards [r7_perturbed_probe_geometry γ hγ hγ1] with q hs
  intro N c
  refine ⟨?_,?_,by linarith⟩
  · intro a ha
    have hlo := (abs_le.mp ha).1
    have hhi := (abs_le.mp ha).2
    refine ⟨?_,(mem_torusDisk N c a _).mpr (by linarith),
      (mem_torusDisk N c a _).mpr (by linarith)⟩
    intro hin
    have := (mem_torusDisk N c a _).mp hin
    linarith
  · intro z hz
    have hd := (diskExteriorNeighbor_radius N c _ z
      (diskHarmonicWeight_support N c _ (Real.exp_pos _) z hz)).2
    exact (mem_torusDisk N c z _).mpr (by linarith)

theorem r7_perturbed_endpoint_probability (γ : ℝ) (hγ : 0 < γ) (hγ1 : γ < 1) :
    ∀ᶠ q : ℝ in atTop, ∀ N : Size, ∀ c a b : Vertex N,
      2*(r7PerturbedOuter q (q^γ)+1) < N.val →
      |periodicDistance a c-r7PerturbedInner q (q^γ)| ≤ 2 →
      diskExteriorNeighbor N c (r7PerturbedOuter q (q^γ)) b →
      0 < walkLaw (exitsThrough N (torusDisk N c (r7PerturbedOuter q (q^γ))) a b) := by
  filter_upwards [r7_perturbed_entrance_support γ hγ hγ1] with q hs
  intro N c a b hsmall ha hb
  have hp := disk_exitHarmonic_pos N c _ (r7PerturbedOuter_pos q (q^γ)) (by linarith)
    a b ((hs N c).1 a ha).2.2 hb
  exact ENNReal.toReal_pos_iff.mp hp |>.1

end TorusCoverTime.Blocks.B
