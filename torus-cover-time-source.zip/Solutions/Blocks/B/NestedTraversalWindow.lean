import Solutions.Blocks.B.NestedRecordPath
import Solutions.Blocks.B.TraversalWordBadWindow
import Solutions.Blocks.B.TraversalCountPartition

/-! Dominate a low inner count on the actual outer loop slice by a bad
event depending only on the completed finite outward records. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

def nestedTraversalSlice (N : Size) (Q O I J : Finset (Vertex N)) (root : Vertex N)
    (m : ℕ) (w : Fin (2*m) → Vertex N) (h U l r : ℝ) : ℝ≥0∞ :=
  ∫⁻ ω, (∫⁻ t in Ioi (adaptiveExitTime N (alternatingDomain N Q O) root (2*m) ω),
    if t < adaptiveExitTime N (alternatingDomain N Q O) root (2*m+1) ω ∧
      walk N root ω t = root ∧ t ∈ Icc l r ∧ h*(completedTraversalCount N I J root ω t:ℝ) ≤ U
      then 1 else 0)
    ∂walkLaw[|{ω | adaptiveExitWord N (alternatingDomain N Q O) root (2*m) ω = w}]

theorem nestedTraversalSlice_le_record_test (N : Size) (Q O I J : Finset (Vertex N))
    (hQO : Q ⊆ O) (hQ : Q.Nonempty) (hIJ : I ⊆ J) (hI : I.Nonempty)
    (hJO : J ⊆ O) (root : Vertex N) (hr : root ∉ O) (m : ℕ) (w : Fin (2*m) → Vertex N)
    (hentry : ∀ᵐ ω ∂walkLaw, ∀ j : ℕ,
      adaptiveExitStart N (alternatingDomain N Q O) root (2*j+1) ω ∉ J)
    (h U l r : ℝ) (hh : 0 ≤ h) :
    nestedTraversalSlice N Q O I J root m w h U l r ≤
      conditionalTraversalSlice N Q O root m w
        (fun p => if h*wordRecordNestedCount N I J root m w p ≤ U then 1 else 0) l r := by
  have hac : walkLaw[|{ω | adaptiveExitWord N (alternatingDomain N Q O) root (2*m) ω = w}] ≪
      walkLaw := cond_absolutelyContinuous
  apply lintegral_mono_ae
  filter_upwards [wordRecordNestedCount_path_le_ae N Q O I J hQO hQ hIJ hI hJO root hr m w hentry,
    hac.ae_le (completedTraversalCount_loop_iff_ae N Q O hQO hQ root hr)] with ω hcount hslice
  apply lintegral_mono_ae
  filter_upwards [ae_restrict_mem (measurableSet_Ioi (a :=
    adaptiveExitTime N (alternatingDomain N Q O) root (2*m) ω))] with t ht
  by_cases hb : t < adaptiveExitTime N (alternatingDomain N Q O) root (2*m+1) ω ∧
      walk N root ω t = root ∧ t ∈ Icc l r ∧ h*(completedTraversalCount N I J root ω t:ℝ) ≤ U
  · have ht0 : 0 ≤ t := (jumpTime_nonneg ω _).trans ht.le
    have hm := (hslice t ht0 hb.2.1 m).mpr ⟨ht.le,hb.1⟩
    have hlow := (mul_le_mul_of_nonneg_left (hcount t ht0 hm) hh).trans hb.2.2.2
    have hwindow : t < adaptiveExitTime N (alternatingDomain N Q O) root (2*m+1) ω ∧
        walk N root ω t = root ∧ t ∈ Icc l r := ⟨hb.1,hb.2.1,hb.2.2.1⟩
    simp only [if_pos hb, if_pos hwindow, if_pos hlow, le_refl]
  · simp only [if_neg hb, zero_le]

end TorusCoverTime.Blocks.B
