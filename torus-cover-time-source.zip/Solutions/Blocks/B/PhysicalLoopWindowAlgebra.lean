import Solutions.Blocks.B.PhysicalCountWindow

/-! Drop count restrictions and take intersections on the original physical-time loop integral. -/
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B


def physicalLoopWindow (N : Size) (root : Vertex N) (F : WalkSample × ℝ → ℝ≥0∞) (l r : ℝ) : ℝ≥0∞ :=
  ∫⁻ ω, ∫⁻ t in Ioi (0:ℝ), if walk N root ω t = root ∧ t ∈ Icc l r then F (ω,t) else 0 ∂volume ∂walkLaw

theorem physicalCountWindow_eq_loop (N : Size) (I O : Finset (Vertex N)) (root : Vertex N) (m : ℕ)
    (F : WalkSample × ℝ → ℝ≥0∞) (l r : ℝ) :
    physicalCountWindow N I O root m F l r = physicalLoopWindow N root
      (fun z => if completedTraversalCount N I O root z.1 z.2 = m then F z else 0) l r := by
  apply lintegral_congr
  intro ω
  apply lintegral_congr
  intro t
  dsimp only
  split_ifs <;> simp_all

theorem physicalCountWindow_le_loop (N : Size) (I O : Finset (Vertex N)) (root : Vertex N) (m : ℕ)
    (F : WalkSample × ℝ → ℝ≥0∞) (l r : ℝ) :
    physicalCountWindow N I O root m F l r ≤ physicalLoopWindow N root F l r := by
  apply lintegral_mono
  intro ω
  apply lintegral_mono
  intro t
  dsimp only
  split_ifs <;> simp_all

theorem physicalLoopWindow_mono (N : Size) (root : Vertex N) (F G : WalkSample × ℝ → ℝ≥0∞)
    (hFG : ∀ z, F z ≤ G z) (l r : ℝ) :
    physicalLoopWindow N root F l r ≤ physicalLoopWindow N root G l r := by
  apply lintegral_mono
  intro ω
  apply lintegral_mono
  intro t
  dsimp only
  split_ifs
  · exact hFG _
  · rfl


end TorusCoverTime.Blocks.B

