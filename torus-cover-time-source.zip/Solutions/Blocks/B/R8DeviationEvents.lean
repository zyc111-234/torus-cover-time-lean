import Solutions.Blocks.B.R8CountPairSupport
import Solutions.Blocks.B.R8ScalarBarrier
import Solutions.Blocks.B.R8HighCountEvent

/-! Original harmonic-radius deviation and its actual two-count slices.
All events read the same continuous-time random-walk sample. -/
noncomputable section
open MeasureTheory Filter Set Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

def r8DeviationEvent (N : Size) (c root : Vertex N) (γ q U : ℝ) : Set (WalkSample × ℝ) :=
  {z | localTime N root z.1 z.2 c/g ≤ U ∧
    (logSize N)^(4*γ) < |Real.sqrt (harmonicPathOccupation N c root q z)-r7TraversalRadius N c root γ q z|}

theorem r8DeviationEvent_measurable (N : Size) (c root : Vertex N) (γ q U : ℝ) :
    MeasurableSet (r8DeviationEvent N c root γ q U) :=
  (measurableSet_le ((localTime_joint_measurable N root c).div_const g) measurable_const).inter
    (measurableSet_lt measurable_const
      (((harmonicPathOccupation_measurable N c root q).sqrt.sub (r7TraversalRadius_measurable N c root γ q)).abs))

def r8CountPairEvent (N : Size) (c root : Vertex N) (γ q : ℝ) (p : ℕ × ℕ) : Set (WalkSample × ℝ) :=
  {z | completedTraversalCount N (torusDisk N c (Real.exp (q+q^γ)))
      (torusDisk N c (Real.exp (q+2*q^γ))) root z.1 z.2 = p.1 ∧
    completedTraversalCount N (torusDisk N c (Real.exp (r8NestedScale γ q+(r8NestedScale γ q)^γ)))
      (torusDisk N c (Real.exp (r8NestedScale γ q+2*(r8NestedScale γ q)^γ))) root z.1 z.2 = p.2}

theorem r8CountPairEvent_measurable (N : Size) (c root : Vertex N) (γ q : ℝ) (p : ℕ × ℕ) :
    MeasurableSet (r8CountPairEvent N c root γ q p) :=
  ((completedTraversalCount_measurable N _ _ root) (measurableSet_singleton p.1)).inter
    ((completedTraversalCount_measurable N _ _ root) (measurableSet_singleton p.2))

theorem r8_count_pair_radii (N : Size) (c root : Vertex N) (γ q : ℝ) (p : ℕ × ℕ)
    (z : WalkSample × ℝ) (hz : z ∈ r8CountPairEvent N c root γ q p) :
    r7TraversalRadius N c root γ q z = Real.sqrt (q^γ*(p.1:ℝ)) ∧
    r7TraversalRadius N c root γ (r8NestedScale γ q) z = Real.sqrt ((r8NestedScale γ q)^γ*(p.2:ℝ)) := by
  exact ⟨congrArg (fun n : ℕ => Real.sqrt (q^γ*(n:ℝ))) hz.1,
    congrArg (fun n : ℕ => Real.sqrt ((r8NestedScale γ q)^γ*(n:ℝ))) hz.2⟩

theorem r8_actual_count_pair_cover (N : Size) (c root : Vertex N) (γ q : ℝ)
    (z : WalkSample × ℝ) (hh : 1 ≤ q^γ) (hh' : 1 ≤ (r8NestedScale γ q)^γ)
    (hv : r7TraversalRadius N c root γ q z ≤ 10*logSize N)
    (hv' : r7TraversalRadius N c root γ (r8NestedScale γ q) z ≤ 10*logSize N) :
    ∃ p ∈ r8CountPairs (logSize N), z ∈ r8CountPairEvent N c root γ q p := by
  let m := completedTraversalCount N (torusDisk N c (Real.exp (q+q^γ)))
    (torusDisk N c (Real.exp (q+2*q^γ))) root z.1 z.2
  let n := completedTraversalCount N (torusDisk N c (Real.exp (r8NestedScale γ q+(r8NestedScale γ q)^γ)))
    (torusDisk N c (Real.exp (r8NestedScale γ q+2*(r8NestedScale γ q)^γ))) root z.1 z.2
  exact ⟨(m,n),r8_count_pair_mem _ _ _ _ _ hh hh' hv hv',rfl,rfl⟩

end TorusCoverTime.Blocks.B
