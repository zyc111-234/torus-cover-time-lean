import Solutions.Blocks.B.DirichletIntegerChain
import Solutions.Blocks.B.FiniteBridgeBarrierAlgebra

noncomputable section
open MeasureTheory ProbabilityTheory
open scoped BigOperators
namespace TorusCoverTime.Blocks.B

theorem dirichlet_conditioned_average_bridge {n : ℕ} (N : Size) (root : Vertex N)
    (D : Fin (n+1) → Finset (Vertex N)) (hD : Monotone D) (hroot : ∀ i, root∉D i)
    (hzero : D 0=∅) (x : Vertex N) (hV : 0<dirichletClockLS N root (D (Fin.last n)) x)
    (t : ℝ) (ξ : FiniteFieldSample N) (i : Fin (n+1)) :
    (∑ z, exitHarmonic N (D i) z x*dirichletConditionedField N root (D (Fin.last n)) x t ξ z)=
      (1-dirichletClockLS N root (D i) x/dirichletClockLS N root (D (Fin.last n)) x)*t-
        (dirichletLSClockPath N root n D hD hroot hzero x).bridge ξ i := by
  rw [dirichletConditionedField_average N root _ _ (hD (Fin.le_last i)) (hroot _) x hV,
    dirichlet_LS_harmonic_bridge N root D hD hroot hzero x ξ i]
  ring

theorem dirichlet_conditioned_bridge_error {n : ℕ} (N : Size) (root : Vertex N)
    (D : Fin (n+1) → Finset (Vertex N)) (hD : Monotone D) (hroot : ∀ i, root∉D i)
    (hzero : D 0=∅) (x : Vertex N) (hV : 0<dirichletClockLS N root (D (Fin.last n)) x)
    (i : Fin (n+1)) (q C η t a : ℝ) (hC : 0≤C) (hL : 1≤logSize N)
    (hlocal : |dirichletClockLS N root (D i) x-q/2|≤C)
    (hglobal : |dirichletClockLS N root (D (Fin.last n)) x-logSize N/2|≤C)
    (ht : |t-harmonicExtremeCenter N|≤η) (ha : |a-harmonicExtremeCenter N|≤η) (ξ : FiniteFieldSample N) :
    |(∑ z, exitHarmonic N (D i) z x*dirichletConditionedField N root (D (Fin.last n)) x t ξ z)-a+
      Real.sqrt 2*q+(dirichletLSClockPath N root n D hD hroot hzero x).bridge ξ i| ≤
      4*Real.sqrt 2*C+Real.log (logSize N)+2*η := by
  let W := dirichletLSClockPath N root n D hD hroot hzero x
  have hv : 0≤dirichletClockLS N root (D i) x := by
    simpa only [W,dirichletLSClockPath,dirichlet_normalized_clock] using W.clock_nonneg i
  have hvV : dirichletClockLS N root (D i) x≤dirichletClockLS N root (D (Fin.last n)) x := by
    simpa only [W,dirichletLSClockPath,dirichlet_normalized_clock] using W.clock_mono (Fin.le_last i)
  have hh := bridge_regression_error q (logSize N) _ _ C (harmonicExtremeCenter N)
    (t-harmonicExtremeCenter N) hV hv hvV hC hlocal hglobal
  rw [dirichlet_conditioned_average_bridge N root D hD hroot hzero x hV t ξ i]
  have he : (1-dirichletClockLS N root (D i) x/dirichletClockLS N root (D (Fin.last n)) x)*t-W.bridge ξ i-a+
      Real.sqrt 2*q+W.bridge ξ i=
      (Real.sqrt 2*q-(dirichletClockLS N root (D i) x/dirichletClockLS N root (D (Fin.last n)) x)*harmonicExtremeCenter N+
        (1-dirichletClockLS N root (D i) x/dirichletClockLS N root (D (Fin.last n)) x)*(t-harmonicExtremeCenter N))+
          (harmonicExtremeCenter N-a) := by ring
  change |(1-_)*t-W.bridge ξ i-a+_+W.bridge ξ i|≤_
  rw [he]
  have ham : |harmonicExtremeCenter N-a|≤η := by rw [abs_sub_comm]; exact ha
  have ht' := (abs_add_le _ _).trans (add_le_add hh ham)
  have hc := harmonicExtremeCenter_log_error N hL
  linarith

theorem dirichlet_conditioned_square_decomposition (N : Size) (root : Vertex N)
    (D E : Finset (Vertex N)) (hDE : D⊆E) (hroot : root∉E) (x : Vertex N)
    (hV : 0<dirichletClockLS N root E x) (t a : ℝ) (ξ : FiniteFieldSample N) :
    (∑ z, exitHarmonic N D z x*(dirichletConditionedField N root E x t ξ z-a)^2)=
      ((∑ z, exitHarmonic N D z x*dirichletConditionedField N root E x t ξ z)-a)^2+
        ∑ z, exitHarmonic N D z x*(dirichletResidualAtEndpoint N root D E x t ξ z)^2 := by
  have hh := weighted_square_residual (fun z => exitHarmonic N D z x)
    (dirichletConditionedField N root E x t ξ)
    (exitHarmonic_sum_one N D (Blocks.C.C4.domain_proper_of_root_outside N root D (fun h => hroot (hDE h))) x) a
  simpa only [dirichletConditionedField_residual N root D E hDE hroot x _ hV] using hh

end TorusCoverTime.Blocks.B
