import Solutions.Blocks.B.ExitOccupationLaplace
import Solutions.Blocks.B.ExactExitSoftness
import Solutions.Blocks.B.BernoulliExponential

/-! R6.7 for products of actual exit blocks: the local occupation lower tail follows
from their actual hitting probabilities. The disk hitting bound remains a separate obligation. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Classical
open scoped ENNReal Topology BigOperators
namespace TorusCoverTime.Blocks.B

lemma exitBlock_occupation_lower_tail (hWalk : WalkModelRegular)
    (N : Size) (D : Finset (Vertex N)) (m : ℕ) (a b : Fin m → Vertex N)
    (hexit : ∀ i, walkLaw (exitsThrough N D (a i) (b i)) ≠ 0)
    (x : Vertex N) (p u : ℝ)
    (hhit : ∀ i, p ≤ (exactExitLaw N D (a i) (b i)).real (visitsBeforeExit N D (a i) x)) :
    (exactExitProductLaw N D m a b).real {ω | exitBlockOccupation N D m a ω x ≤ u} ≤
      Real.exp (u - (m : ℝ) * p / 2) := by
  let ν := fun i => exactExitLaw N D (a i) (b i)
  have (i : Fin m) : IsProbabilityMeasure (ν i) := cond_isProbabilityMeasure (hexit i)
  let μ := Measure.pi ν
  let X := fun (i : Fin m) (ω : WalkSample) =>
    localTime N (a i) ω (finiteExitDuration N D (a i) ω) x
  let V := fun (i : Fin m) (ω : Fin m → WalkSample) => X i (ω i)
  have hm (i : Fin m) : Measurable (X i) :=
    localTime_measurable_random_time N (a i) x _ (measurable_finiteExitDuration N D (a i))
  have hV (i : Fin m) : Measurable (V i) := (hm i).comp (measurable_pi_apply i)
  have hV0 (i : Fin m) : ∀ᵐ ω ∂μ, 0 ≤ V i ω :=
    Eventually.of_forall fun ω => localTime_nonneg N (a i) x (ω i) _
  have hind : iIndepFun V μ := iIndepFun_pi (fun i => (hm i).aemeasurable)
  have hmean (i : Fin m) :
      (∫ ω, Real.exp (-V i ω) ∂μ) = ∫ ω, Real.exp (-X i ω) ∂ν i := by
    have hi := integral_map (μ := μ) (φ := fun ω : Fin m → WalkSample => ω i)
      (f := fun ω : WalkSample => Real.exp (-X i ω))
      (measurable_pi_apply i).aemeasurable (hm i).neg.exp.aestronglyMeasurable
    rw [(measurePreserving_eval ν i).map_eq] at hi
    exact hi.symm
  have hlap (i : Fin m) : (∫ ω, Real.exp (-(1 : ℝ) * V i ω) ∂μ) ≤
      1 - p + p * 1 / (1 + 1) := by
    simp only [neg_one_mul, hmean]
    have h := exit_occupation_laplace_le hWalk N D (a i) (b i) x (hexit i)
    change (∫ ω, Real.exp (-X i ω) ∂ν i) ≤ _ at h
    linarith [hhit i]
  have h := bernoulli_exponential_chernoff μ m V hV hV0 hind p 1 u 1
    (by norm_num) (by norm_num) hlap
  simpa only [one_mul, mul_one, one_add_one_eq_two, V, X, μ, ν,
    exitBlockOccupation, exactExitProductLaw] using h

lemma exitBlock_occupation_lower_tail_physical (hWalk : WalkModelRegular)
    (N : Size) (D : Finset (Vertex N)) (m : ℕ) (a b : Fin m → Vertex N)
    (hexit : ∀ i, walkLaw (exitsThrough N D (a i) (b i)) ≠ 0)
    (x : Vertex N) (p u : ℝ)
    (hhit : ∀ i, p ≤ (exactExitLaw N D (a i) (b i)).real
      {ω | hittingTime N (a i) ω x < domainExitTime N D (a i) ω}) :
    (exactExitProductLaw N D m a b).real {ω | exitBlockOccupation N D m a ω x ≤ u} ≤
      Real.exp (u - (m : ℝ) * p / 2) := by
  apply exitBlock_occupation_lower_tail hWalk N D m a b hexit x p u
  intro i
  rw [visitsBeforeExit_probability_eq_physical hWalk N D (a i) (b i) x]
  exact hhit i

lemma r6_occupation_count_exponent (L q w c u : ℝ) (M : ℕ)
    (hL : 0 < L) (hq : 0 < q) (hqL : q ≤ L) (hw : 1 ≤ w)
    (hc : 0 ≤ c) (hM : L ^ 4 ≤ (M : ℝ)) :
    Real.exp (u - (M : ℝ) * (c * w / q) / 2) ≤ Real.exp (u - c * L ^ 3 / 2) := by
  have hratio : 1 / L ≤ w / q := by
    apply (div_le_div_iff₀ hL hq).mpr
    nlinarith
  have hprod : c * L ^ 3 ≤ (M : ℝ) * (c * w / q) := by
    calc
      _ = L ^ 4 * c * (1 / L) := by field_simp
      _ ≤ (M : ℝ) * c * (w / q) :=
        mul_le_mul (mul_le_mul_of_nonneg_right hM hc) hratio (by positivity) (by positivity)
      _ = _ := by ring
  apply Real.exp_le_exp.mpr
  linarith

theorem r6_occupation_count_of_hit_lower (hWalk : WalkModelRegular)
    (N : Size) (D : Finset (Vertex N)) (M : ℕ) (a b : Fin M → Vertex N)
    (hexit : ∀ i, walkLaw (exitsThrough N D (a i) (b i)) ≠ 0)
    (x : Vertex N) (L q w c u : ℝ)
    (hL : 0 < L) (hq : 0 < q) (hqL : q ≤ L) (hw : 1 ≤ w)
    (hc : 0 ≤ c) (hM : L ^ 4 ≤ (M : ℝ))
    (hhit : ∀ i, c * w / q ≤ (exactExitLaw N D (a i) (b i)).real
      {ω | hittingTime N (a i) ω x < domainExitTime N D (a i) ω}) :
    (exactExitProductLaw N D M a b).real {ω | exitBlockOccupation N D M a ω x ≤ u} ≤
      Real.exp (u - c * L ^ 3 / 2) :=
  (exitBlock_occupation_lower_tail_physical hWalk N D M a b hexit x (c * w / q) u hhit).trans
    (r6_occupation_count_exponent L q w c u M hL hq hqL hw hc hM)

lemma exactExitProduct_map_selection (N : Size) (D : Finset (Vertex N)) (n m : ℕ)
    (a b : Fin n → Vertex N) (e : Fin m → Fin n) (he : Function.Injective e)
    (hexit : ∀ i, walkLaw (exitsThrough N D (a i) (b i)) ≠ 0) :
    (exactExitProductLaw N D n a b).map (fun ω i => ω (e i)) =
      exactExitProductLaw N D m (a ∘ e) (b ∘ e) := by
  let ν := fun i => exactExitLaw N D (a i) (b i)
  have (i : Fin n) : IsProbabilityMeasure (ν i) := cond_isProbabilityMeasure (hexit i)
  have hind := (iIndepFun_pi (μ := ν) (X := fun _ => id)
    (fun _ => measurable_id.aemeasurable)).precomp he
  have hmap := hind.map_fun_eq_pi_map (fun i => (measurable_pi_apply (e i)).aemeasurable)
  simp_rw [(measurePreserving_eval ν _).map_eq] at hmap
  exact hmap

lemma exitBlockOccupation_selection_le (N : Size) (D : Finset (Vertex N)) (n m : ℕ)
    (a : Fin n → Vertex N) (e : Fin m → Fin n) (he : Function.Injective e)
    (ω : Fin n → WalkSample) (x : Vertex N) :
    exitBlockOccupation N D m (a ∘ e) (fun i => ω (e i)) x ≤
      exitBlockOccupation N D n a ω x := by
  let f := fun i => localTime N (a i) (ω i) (finiteExitDuration N D (a i) (ω i)) x
  change (∑ i : Fin m, f (e i)) ≤ ∑ i : Fin n, f i
  rw [← Finset.sum_image (f := f) (s := Finset.univ) (fun i _ j _ hij => he hij)]
  exact Finset.sum_le_sum_of_subset_of_nonneg (Finset.subset_univ _)
    (fun i _ _ => localTime_nonneg N (a i) x (ω i) _)

theorem exitBlock_occupation_lower_tail_selected (hWalk : WalkModelRegular)
    (N : Size) (D : Finset (Vertex N)) (n m : ℕ) (a b : Fin n → Vertex N)
    (e : Fin m → Fin n) (he : Function.Injective e)
    (hexit : ∀ i, walkLaw (exitsThrough N D (a i) (b i)) ≠ 0)
    (x : Vertex N) (p u : ℝ)
    (hhit : ∀ i, p ≤ (exactExitLaw N D (a (e i)) (b (e i))).real
      {ω | hittingTime N (a (e i)) ω x < domainExitTime N D (a (e i)) ω}) :
    (exactExitProductLaw N D n a b).real {ω | exitBlockOccupation N D n a ω x ≤ u} ≤
      Real.exp (u - (m : ℝ) * p / 2) := by
  have (i : Fin n) : IsProbabilityMeasure (exactExitLaw N D (a i) (b i)) :=
    cond_isProbabilityMeasure (hexit i)
  have : IsProbabilityMeasure (exactExitProductLaw N D n a b) := by
    unfold exactExitProductLaw
    infer_instance
  let S := {ω : Fin m → WalkSample | exitBlockOccupation N D m (a ∘ e) ω x ≤ u}
  have hS : MeasurableSet S :=
    measurableSet_le (measurable_exitBlockOccupation N D m (a ∘ e) x) measurable_const
  have hmap : (exactExitProductLaw N D n a b).real ((fun ω i => ω (e i)) ⁻¹' S) =
      (exactExitProductLaw N D m (a ∘ e) (b ∘ e)).real S := by
    rw [← exactExitProduct_map_selection N D n m a b e he hexit,
      map_measureReal_apply (by fun_prop) hS]
  calc
    _ ≤ (exactExitProductLaw N D n a b).real ((fun ω i => ω (e i)) ⁻¹' S) :=
      measureReal_mono (fun ω hω =>
        (exitBlockOccupation_selection_le N D n m a e he ω x).trans hω)
    _ = _ := hmap
    _ ≤ _ := exitBlock_occupation_lower_tail_physical hWalk N D m (a ∘ e) (b ∘ e)
      (fun i => hexit (e i)) x p u hhit

end TorusCoverTime.Blocks.B
