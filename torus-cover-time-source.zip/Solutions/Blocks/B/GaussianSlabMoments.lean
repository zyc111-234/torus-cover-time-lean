import Solutions.Blocks.D.Base.SharedGaussian
import Mathlib.Probability.Independence.Integration

/-! Gaussian regression on a narrow slab. The quadratic moment bounds retain
the slab probability as a factor, which is essential when that probability
tends to zero. No unconditional Markov error is subtracted from a rare event. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal NNReal
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

def scalarRegressionSlope {Ω : Type*} [MeasurableSpace Ω] (μ : Measure Ω) (X Y : Ω → ℝ) : ℝ :=
  cov[X,Y;μ]/Var[X;μ]

def scalarRegressionResidual {Ω : Type*} [MeasurableSpace Ω] (μ : Measure Ω)
    (X Y : Ω → ℝ) (ω : Ω) : ℝ := Y ω-scalarRegressionSlope μ X Y*X ω

theorem scalar_gaussian_regression {Ω : Type*} [MeasurableSpace Ω]
    (μ : Measure Ω) [IsProbabilityMeasure μ] (X Y : Ω → ℝ)
    (hXY : HasGaussianLaw (fun ω => (X ω,Y ω)) μ) (hV : 0 < Var[X;μ]) :
    HasGaussianLaw (fun ω => (X ω,scalarRegressionResidual μ X Y ω)) μ ∧
    IndepFun X (scalarRegressionResidual μ X Y) μ ∧
    Var[scalarRegressionResidual μ X Y;μ] = Var[Y;μ]-cov[X,Y;μ]^2/Var[X;μ] := by
  let t := scalarRegressionSlope μ X Y
  let T : (ℝ × ℝ) →L[ℝ] (ℝ × ℝ) :=
    (ContinuousLinearMap.fst ℝ ℝ ℝ).prod
      (ContinuousLinearMap.snd ℝ ℝ ℝ-t • ContinuousLinearMap.fst ℝ ℝ ℝ)
  have hj : HasGaussianLaw (fun ω => (X ω,scalarRegressionResidual μ X Y ω)) μ := by
    simpa [T,t,scalarRegressionResidual] using hXY.map_fun T
  have hx := hXY.fst.memLp_two
  have hy := hXY.snd.memLp_two
  have hz : cov[X,scalarRegressionResidual μ X Y;μ] = 0 := by
    unfold scalarRegressionResidual
    rw [covariance_fun_sub_right hx hy (hx.const_mul _),covariance_const_mul_right,
      covariance_self hXY.fst.aemeasurable]
    unfold scalarRegressionSlope
    rw [div_mul_cancel₀ _ hV.ne',sub_self]
  refine ⟨hj,hj.indepFun_of_covariance_eq_zero hz,?_⟩
  rw [← covariance_self hj.snd.aemeasurable]
  unfold scalarRegressionResidual
  rw [covariance_fun_sub_fun_sub hy (hx.const_mul _) hy (hx.const_mul _),
    covariance_const_mul_right,covariance_const_mul_left,covariance_const_mul_left,
    covariance_const_mul_right,covariance_self hXY.snd.aemeasurable,
    covariance_self hXY.fst.aemeasurable,covariance_comm (X := Y) (Y := X)]
  unfold scalarRegressionSlope
  field_simp
  ring

theorem scalar_regression_variance_bounds {Ω : Type*} [MeasurableSpace Ω]
    (μ : Measure Ω) [IsProbabilityMeasure μ] (X Y : Ω → ℝ)
    (hXY : HasGaussianLaw (fun ω => (X ω,Y ω)) μ) (hV : 0 < Var[X;μ]) :
    Var[scalarRegressionResidual μ X Y;μ] ≤ Var[Y;μ] ∧
    Var[scalarRegressionResidual μ X Y;μ] ≤ Var[fun ω => Y ω-X ω;μ] ∧
    scalarRegressionSlope μ X Y ^ 2 ≤ Var[Y;μ]/Var[X;μ] := by
  have he := (scalar_gaussian_regression μ X Y hXY hV).2.2
  have hnon := variance_nonneg (scalarRegressionResidual μ X Y) μ
  have hdiv : 0 ≤ cov[X,Y;μ]^2/Var[X;μ] := div_nonneg (sq_nonneg _) hV.le
  have hc : cov[X,Y;μ]^2 ≤ Var[Y;μ]*Var[X;μ] := by
    apply (div_le_iff₀ hV).mp
    linarith
  refine ⟨by linarith,?_,?_⟩
  · rw [he,variance_fun_sub hXY.snd.memLp_two hXY.fst.memLp_two,
      covariance_comm (X := Y) (Y := X)]
    have hsq := sq_nonneg (cov[X,Y;μ]-Var[X;μ])
    have heq : cov[X,Y;μ]^2/Var[X;μ]*Var[X;μ] = cov[X,Y;μ]^2 :=
      div_mul_cancel₀ _ hV.ne'
    apply (mul_le_mul_iff_of_pos_right hV).mp
    nlinarith
  · unfold scalarRegressionSlope
    rw [div_pow]
    apply (div_le_iff₀ (sq_pos_of_pos hV)).mpr
    have heq : Var[Y;μ]/Var[X;μ]*Var[X;μ]^2 = Var[Y;μ]*Var[X;μ] := by
      field_simp
    rwa [heq]

theorem scalarRegressionResidual_mean {Ω : Type*} [MeasurableSpace Ω]
    (μ : Measure Ω) [IsProbabilityMeasure μ] (X Y : Ω → ℝ)
    (hXY : HasGaussianLaw (fun ω => (X ω,Y ω)) μ)
    (hX0 : (∫ ω, X ω ∂μ) = 0) (hY0 : (∫ ω, Y ω ∂μ) = 0) :
    (∫ ω, scalarRegressionResidual μ X Y ω ∂μ) = 0 := by
  unfold scalarRegressionResidual
  rw [integral_sub (hXY.snd.memLp_two.integrable (by norm_num))
    ((hXY.fst.memLp_two.integrable (by norm_num)).const_mul _),integral_const_mul,hX0,hY0]
  ring

theorem independent_slab_square_integral {Ω : Type*} [MeasurableSpace Ω]
    (μ : Measure Ω) [IsProbabilityMeasure μ] (X Z : Ω → ℝ) (hX : Measurable X)
    (hZ : Measurable Z) (hI : IndepFun X Z μ) :
    (∫ ω in {ω | |X ω| ≤ 1}, Z ω^2 ∂μ) =
      μ.real {ω | |X ω| ≤ 1} * ∫ ω, Z ω^2 ∂μ := by
  let f := fun u : ℝ => if |u| ≤ 1 then (1 : ℝ) else 0
  have hf : Measurable f := measurable_const.ite (measurableSet_le measurable_id.abs measurable_const) measurable_const
  have hi := hI.comp hf (measurable_id.pow_const 2)
  have hh := hi.integral_fun_mul_eq_mul_integral (hf.comp hX).aestronglyMeasurable
    (hZ.pow_const 2).aestronglyMeasurable
  have hE : MeasurableSet {ω | |X ω| ≤ 1} := measurableSet_le hX.abs measurable_const
  have he : (fun ω => f (X ω)*Z ω^2) = {ω | |X ω| ≤ 1}.indicator (fun ω => Z ω^2) := by
    funext ω
    simp [f,Set.indicator]
  have hone : (fun ω => f (X ω)) = {ω | |X ω| ≤ 1}.indicator (fun _ => (1 : ℝ)) := by
    funext ω
    simp [f,Set.indicator]
  simp only [Function.comp_def,id_eq] at hh
  rw [he,hone,integral_indicator hE,integral_indicator hE,integral_const] at hh
  simpa only [smul_eq_mul,mul_one,Measure.real,
    Measure.restrict_apply MeasurableSet.univ,univ_inter] using hh

theorem gaussian_slab_square_integral {Ω : Type*} [MeasurableSpace Ω]
    (μ : Measure Ω) [IsProbabilityMeasure μ] (X Y : Ω → ℝ) (hX : Measurable X) (hY : Measurable Y)
    (hXY : HasGaussianLaw (fun ω => (X ω,Y ω)) μ) (hV : 0 < Var[X;μ])
    (hX0 : (∫ ω, X ω ∂μ) = 0) (hY0 : (∫ ω, Y ω ∂μ) = 0) :
    (∫ ω in {ω | |X ω| ≤ 1}, Y ω^2 ∂μ) ≤
      (2*Var[scalarRegressionResidual μ X Y;μ]+2*scalarRegressionSlope μ X Y^2)*
        μ.real {ω | |X ω| ≤ 1} := by
  obtain ⟨hj,hi,hvar⟩ := scalar_gaussian_regression μ X Y hXY hV
  let Z := scalarRegressionResidual μ X Y
  let t := scalarRegressionSlope μ X Y
  let E := {ω | |X ω| ≤ 1}
  have hE : MeasurableSet E := measurableSet_le hX.abs measurable_const
  have hZm : Measurable Z := hY.sub (hX.const_mul _)
  have hZZ : Integrable (fun ω => Z ω^2) μ := by
    have hh := hj.snd.memLp_two.integrable_mul hj.snd.memLp_two
    change Integrable (fun ω => Z ω*Z ω) μ at hh
    simpa only [pow_two] using hh
  have hYY : Integrable (fun ω => Y ω^2) μ := by
    have hh := hXY.snd.memLp_two.integrable_mul hXY.snd.memLp_two
    change Integrable (fun ω => Y ω*Y ω) μ at hh
    simpa only [pow_two] using hh
  have hZ0 := scalarRegressionResidual_mean μ X Y hXY hX0 hY0
  have hZvar : (∫ ω, Z ω^2 ∂μ) = Var[Z;μ] := by
    rw [variance_eq_integral hj.snd.aemeasurable,hZ0]
    simp only [sub_zero]
    rfl
  have hsq := independent_slab_square_integral μ X Z hX hZm hi
  rw [hZvar] at hsq
  have hpoint (ω : Ω) (hω : ω ∈ E) : Y ω^2 ≤ 2*Z ω^2+2*t^2 := by
    have hxx : X ω^2 ≤ 1 := by
      have h := (sq_le_sq₀ (abs_nonneg (X ω)) (by norm_num : (0:ℝ) ≤ 1)).mpr hω
      simpa only [sq_abs,one_pow] using h
    have hxxt := mul_le_mul_of_nonneg_left hxx (sq_nonneg t)
    have he : Y ω = Z ω+t*X ω := by dsimp [Z,t,scalarRegressionResidual]; ring
    rw [he]
    nlinarith [sq_nonneg (Z ω-t*X ω)]
  calc
    _ ≤ ∫ ω in E, (2*Z ω^2+2*t^2) ∂μ :=
      setIntegral_mono_on hYY.integrableOn (((hZZ.const_mul 2).add (integrable_const _)).integrableOn) hE hpoint
    _ = _ := by
      rw [integral_add ((hZZ.const_mul 2).integrableOn) (integrable_const _),integral_const_mul,hsq]
      simp only [integral_const,Measure.real,Measure.restrict_apply MeasurableSet.univ,univ_inter,smul_eq_mul]
      ring

theorem gaussian_slab_square_increment_bound {Ω : Type*} [MeasurableSpace Ω]
    (μ : Measure Ω) [IsProbabilityMeasure μ] (X Y : Ω → ℝ) (hX : Measurable X) (hY : Measurable Y)
    (hXY : HasGaussianLaw (fun ω => (X ω,Y ω)) μ) (hV : 0 < Var[X;μ])
    (hX0 : (∫ ω, X ω ∂μ) = 0) (hY0 : (∫ ω, Y ω ∂μ) = 0) :
    (∫ ω in {ω | |X ω| ≤ 1}, Y ω^2 ∂μ) ≤
      (2*Var[fun ω => Y ω-X ω;μ]+2*(Var[Y;μ]/Var[X;μ]))*μ.real {ω | |X ω| ≤ 1} := by
  have hb := scalar_regression_variance_bounds μ X Y hXY hV
  exact (gaussian_slab_square_integral μ X Y hX hY hXY hV hX0 hY0).trans
    (mul_le_mul_of_nonneg_right (by linarith [hb.2.1,hb.2.2]) measureReal_nonneg)

theorem gaussian_slab_square_global_bound {Ω : Type*} [MeasurableSpace Ω]
    (μ : Measure Ω) [IsProbabilityMeasure μ] (X Y : Ω → ℝ) (hX : Measurable X) (hY : Measurable Y)
    (hXY : HasGaussianLaw (fun ω => (X ω,Y ω)) μ) (hV : 0 < Var[X;μ])
    (hX0 : (∫ ω, X ω ∂μ) = 0) (hY0 : (∫ ω, Y ω ∂μ) = 0) :
    (∫ ω in {ω | |X ω| ≤ 1}, Y ω^2 ∂μ) ≤
      (2+2/Var[X;μ])*Var[Y;μ]*μ.real {ω | |X ω| ≤ 1} := by
  have hb := scalar_regression_variance_bounds μ X Y hXY hV
  apply (gaussian_slab_square_integral μ X Y hX hY hXY hV hX0 hY0).trans
  apply mul_le_mul_of_nonneg_right _ measureReal_nonneg
  calc
    _ ≤ 2*Var[Y;μ]+2*(Var[Y;μ]/Var[X;μ]) := by linarith [hb.1,hb.2.2]
    _ = _ := by ring

end TorusCoverTime.Blocks.B
