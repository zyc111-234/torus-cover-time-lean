import Solutions.Blocks.B.DiskHarmonicAverage
import Solutions.Blocks.B.DiskHarmonicUpper

/-! Scale-uniform interior Harnack from the two proved mean inequalities.
All constants are independent of the torus, center, radius and function. -/

noncomputable section
open Classical
namespace TorusCoverTime.Blocks.B

def diskHarnackRadiusThreshold : ℝ := 16*diskGreenInnerScale*harmonicCutoffScale
def diskHarnackConstant : ℝ :=
  512*harmonicCutoffSourceConstant*diskGreenConvolutionConstant*diskGreenInnerScale^2 + 2

theorem diskHarnackRadiusThreshold_ge_one : 1 ≤ diskHarnackRadiusThreshold := by
  have hL := diskGreenInnerScale_ge_four
  have hH := harmonicCutoffScale_ge_one
  unfold diskHarnackRadiusThreshold
  nlinarith [mul_nonneg (show 0 ≤ diskGreenInnerScale-4 by linarith)
    (show 0 ≤ harmonicCutoffScale-1 by linarith)]

theorem diskHarnackConstant_gt_one : 1 < diskHarnackConstant := by
  have hS := harmonicCutoffSourceConstant_pos
  have hC := diskGreenConvolutionConstant_pos
  unfold diskHarnackConstant
  have hp : 0 ≤ 512*harmonicCutoffSourceConstant*diskGreenConvolutionConstant*diskGreenInnerScale^2 := by positivity
  linarith

theorem disk_harnack (N : Size) (c : Vertex N) (R : ℝ)
    (hR : diskHarnackRadiusThreshold ≤ R) (hsmall : 4*(R+1) < N.val)
    (f : Vertex N → ℝ) (hf : ∀ z, 0 ≤ f z)
    (hg : ∀ z ∈ torusDisk N c R, generator N f z = 0)
    (x y : Vertex N) (hx : periodicDistance x c ≤ R/(4*diskGreenInnerScale))
    (hy : periodicDistance y c ≤ R/(4*diskGreenInnerScale)) :
    f y ≤ diskHarnackConstant * f x := by
  have hR1 := diskHarnackRadiusThreshold_ge_one.trans hR
  have hR0 : 0 < R := by linarith
  have hL := diskGreenInnerScale_ge_four
  have hL0 : 0 < diskGreenInnerScale := by linarith
  have hS := harmonicCutoffSourceConstant_pos
  have hC := diskGreenConvolutionConstant_pos
  let r := R/(8*diskGreenInnerScale)
  have hr0 : 0 < r := div_pos hR0 (by positivity)
  have hrR : r ≤ R := by
    apply (div_le_iff₀ (by positivity)).mpr
    nlinarith
  have hr : 2*harmonicCutoffScale ≤ r := by
    apply (le_div_iff₀ (by positivity)).mpr
    unfold diskHarnackRadiusThreshold at hR
    nlinarith
  have hhalf : R/(4*diskGreenInnerScale) ≤ R/(2*diskGreenInnerScale) :=
    div_le_div_of_nonneg_left hR0.le (by positivity) (by linarith)
  have hquarter : R/(2*diskGreenInnerScale) ≤ R := by
    apply (div_le_iff₀ (by positivity)).mpr
    nlinarith
  have hsub : torusDisk N y (2*r) ⊆ torusDisk N c (R/(2*diskGreenInnerScale)) := by
    intro z hz
    have hz' := (mem_torusDisk N y z (2*r)).mp hz
    have ht := periodicDistance_triangle N z y c
    have hid : 2*r+R/(4*diskGreenInnerScale) = R/(2*diskGreenInnerScale) := by dsimp [r]; ring
    exact (mem_torusDisk N c z _).mpr (by linarith)
  have hgy : ∀ z ∈ torusDisk N y r, generator N f z = 0 := by
    intro z hz
    have hz' : z ∈ torusDisk N y (2*r) :=
      (mem_torusDisk N y z _).mpr (by have := (mem_torusDisk N y z r).mp hz; linarith)
    have hd := (mem_torusDisk N c z _).mp (hsub hz')
    exact hg z ((mem_torusDisk N c z R).mpr (hd.trans_le hquarter))
  have hu := disk_harmonic_mean_upper N y r hr (by linarith) f hf hgy
  have hlo := disk_harmonic_mean_lower N c R hR1 hsmall f hf hg x (hx.trans hhalf)
  have hsum : (∑ z ∈ torusDisk N y (2*r), f z) ≤
      ∑ z ∈ torusDisk N c (R/(2*diskGreenInnerScale)), f z :=
    Finset.sum_le_sum_of_subset_of_nonneg hsub (fun z _ _ => hf z)
  have hp : 0 ≤ 2*harmonicCutoffSourceConstant/r^2 := by positivity
  calc
    f y ≤ (2*harmonicCutoffSourceConstant/r^2) * (∑ z ∈ torusDisk N y (2*r), f z) := hu
    _ ≤ (2*harmonicCutoffSourceConstant/r^2) * (4*diskGreenConvolutionConstant*R^2*f x) :=
      mul_le_mul_of_nonneg_left (hsum.trans hlo) hp
    _ = (512*harmonicCutoffSourceConstant*diskGreenConvolutionConstant*diskGreenInnerScale^2)*f x := by
      dsimp [r]
      field_simp
      ring
    _ ≤ diskHarnackConstant*f x := by unfold diskHarnackConstant; nlinarith [hf x]

theorem disk_exit_harnack (N : Size) (c : Vertex N) (R : ℝ)
    (hR : diskHarnackRadiusThreshold ≤ R) (hsmall : 4*(R+1) < N.val)
    (b x y : Vertex N) (hx : periodicDistance x c ≤ R/(4*diskGreenInnerScale))
    (hy : periodicDistance y c ≤ R/(4*diskGreenInnerScale)) :
    exitHarmonic N (torusDisk N c R) b y ≤ diskHarnackConstant * exitHarmonic N (torusDisk N c R) b x :=
  disk_harnack N c R hR hsmall (exitHarmonic N (torusDisk N c R) b)
    (exitHarmonic_nonneg N _ b) (fun z hz => exitHarmonic_generator N _ b z hz) x y hx hy

theorem disk_harnack_small_torus (N : Size) (c : Vertex N) (R : ℝ)
    (hR : 3*diskHarnackRadiusThreshold ≤ R) (hsmall : 2*(R+1) < N.val)
    (f : Vertex N → ℝ) (hf : ∀ z, 0 ≤ f z)
    (hg : ∀ z ∈ torusDisk N c R, generator N f z = 0)
    (x y : Vertex N) (hx : periodicDistance x c ≤ R/(12*diskGreenInnerScale))
    (hy : periodicDistance y c ≤ R/(12*diskGreenInnerScale)) :
    f y ≤ diskHarnackConstant*f x := by
  have hR1 := diskHarnackRadiusThreshold_ge_one
  have hR0 : 0 < R := by linarith
  have hid : (R/3)/(4*diskGreenInnerScale) = R/(12*diskGreenInnerScale) := by ring
  apply disk_harnack N c (R/3) (by linarith) (by linarith) f hf
  · intro z hz
    have hd := (mem_torusDisk N c z (R/3)).mp hz
    exact hg z ((mem_torusDisk N c z R).mpr (by linarith))
  · rwa [hid]
  · rwa [hid]

end TorusCoverTime.Blocks.B
