import Solutions.Blocks.B.R7ShiftedCount

/-! The +1 introduced by the actual center shift is retained in the
threshold and absorbed uniformly before the spatial grid is summed. -/

noncomputable section
open MeasureTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

def r7ShiftedBarrier (N : Size) (γ q : ℝ) : ℝ :=
  Real.sqrt 2*q-(logSize N)^(3*γ)+1

theorem r7_shifted_barrier_parameters (γ : ℝ) (hγ : 0 < γ) :
    ∀ᶠ N : Size in atTop, ∀ q : ℝ,
      (logSize N)^(16*γ) ≤ q → q ≤ logSize N →
      q ≤ r7ShiftedBarrier N γ q ∧ r7ShiftedBarrier N γ q ≤ 3*logSize N := by
  filter_upwards [r7_lower_barrier_parameters γ hγ,
    blockB_logSize_tendsto.eventually_ge_atTop 1] with N hp hL
  intro q hq hqL
  have hh := hp q hq hqL
  dsimp only [r7ShiftedBarrier]
  constructor <;> linarith

theorem r7_shifted_barrier_exponent (γ C : ℝ) (hγ : 0 < γ) (hC : 0 ≤ C) :
    ∀ᶠ N : Size in atTop, ∀ q : ℝ,
      (logSize N)^(16*γ) ≤ q → q ≤ logSize N-(logSize N)^(16*γ) →
      2*(logSize N-q)+(logSize N)^(3*γ)/4 ≤
        (max (harmonicExtremeCenter N-r7ShiftedBarrier N γ q-
          (logSize N)^(2*γ)-C*Real.log (logSize N)) 0)^2/(logSize N-q+C) := by
  filter_upwards [blockB_logSize_tendsto.eventually_ge_atTop 1,
    blockB_logSize_tendsto.eventually (power_eventually_le_power 1 (2*γ) (3*γ) (1/8) (by linarith) (by norm_num)),
    blockB_logSize_tendsto.eventually (log_eventually_le_power (C+3/(4*Real.sqrt 2)) (3*γ) (1/8) (by positivity) (by norm_num)),
    ((tendsto_rpow_atTop (by positivity : 0 < 3*γ)).comp blockB_logSize_tendsto).eventually_ge_atTop (max 4 (4*C))]
    with N hL hpow hlog hlarge
  dsimp only [Function.comp_def] at hlarge
  intro q hq hqL
  have hS : 0 ≤ (logSize N)^(3*γ) := Real.rpow_nonneg (logSize_pos N).le _
  have hQ : 0 < (logSize N)^(16*γ) := Real.rpow_pos_of_pos (logSize_pos N) _
  have hr : 0 < logSize N-q := by linarith
  have hSr : (logSize N)^(3*γ) ≤ logSize N-q :=
    (Real.rpow_le_rpow_of_exponent_le hL (by linarith : 3*γ ≤ 16*γ)).trans (by linarith)
  have h4 := (le_max_left _ _).trans hlarge
  have hCS := (le_max_right _ _).trans hlarge
  have hbase : Real.sqrt 2*(logSize N-q)+(logSize N)^(3*γ)/2 ≤
      max (harmonicExtremeCenter N-r7ShiftedBarrier N γ q-
        (logSize N)^(2*γ)-C*Real.log (logSize N)) 0 := by
    apply le_trans _ (le_max_left _ _)
    rw [harmonicExtremeCenter_eq,r7ShiftedBarrier]
    nlinarith only [hpow,hlog,h4]
  apply (lower_barrier_quadratic_gain (logSize N-q) ((logSize N)^(3*γ)) C hr hS hC hSr hCS).trans
  apply div_le_div_of_nonneg_right _ (by linarith : 0 ≤ logSize N-q+C)
  apply pow_le_pow_left₀ _ hbase
  positivity

theorem r7_shifted_barrier_marginal (hWalk : WalkModelRegular) (γ H : ℝ)
    (hγ : 0 < γ) (hγ1 : 16*γ < 1) (hH : 0 ≤ H) :
    ∃ c₀ C : ℝ, 0 < c₀ ∧ 0 < C ∧ ∀ᶠ N : Size in atTop,
      ∀ c : Vertex N, ∀ q l r : ℝ,
        (logSize N)^(16*γ) ≤ q → q ≤ logSize N-(logSize N)^(16*γ) →
        l ≤ r → phaseACenter N-H*timeScale N ≤ l → r ≤ phaseACenter N+H*timeScale N →
        r7PerturbedIntegratedLowCount N c γ q (r7ShiftedBarrier N γ q) l r ≤
          ENNReal.ofReal (C*Real.sqrt (logSize N)*Real.exp
            (-2*(logSize N-q)-(logSize N)^(3*γ)/4)) +
          ENNReal.ofReal (Real.exp (-c₀*logSize N*Real.log (logSize N))) := by
  obtain ⟨c₀,C,hc,hC,hlow⟩ := r7_perturbed_integrated_low_count_bound hWalk γ H 3 hγ hγ1 hH (by norm_num)
  refine ⟨c₀,C,hc,hC,?_⟩
  filter_upwards [hlow,r7_shifted_barrier_parameters γ hγ,r7_shifted_barrier_exponent γ C hγ hC.le]
    with N hN hp he
  intro c q l r hq hqL hlr hleft hright
  have hqL' := hqL.trans (sub_le_self _ (Real.rpow_nonneg (logSize_pos N).le _))
  have hv := hp q hq hqL'
  apply (hN c q (r7ShiftedBarrier N γ q) l r hq hqL hv.1 hv.2 hlr hleft hright).trans
  apply add_le_add _ le_rfl
  apply ENNReal.ofReal_le_ofReal
  apply mul_le_mul_of_nonneg_left _ (by positivity)
  apply Real.exp_le_exp.mpr
  have hh := he q hq hqL
  rw [neg_div]
  linarith only [hh]

end TorusCoverTime.Blocks.B
