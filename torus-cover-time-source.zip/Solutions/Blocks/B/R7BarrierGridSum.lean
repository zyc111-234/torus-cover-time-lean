import Solutions.Blocks.B.R7LoopEventMass

/-! Cancellation of the actual grid cardinality against the sharp Gaussian
exponent, with the iteration remainder retained at every grid point. -/

noncomputable section
open MeasureTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

def r7BarrierScaleEnvelope (L γ c C : ℝ) : ℝ :=
  9*C*Real.sqrt L*Real.exp (-L^(3*γ)/4) +
  9*Real.exp (2*L)*Real.exp (-c*L*Real.log L)

theorem r7BarrierScaleEnvelope_nonneg (L γ c C : ℝ) (hC : 0 ≤ C) :
    0 ≤ r7BarrierScaleEnvelope L γ c C := by
  unfold r7BarrierScaleEnvelope
  positivity

theorem r7_grid_marginal_sum (N : Size) (γ q c C : ℝ) (hC : 0 ≤ C)
    (hq : Real.log 2 ≤ q) (hqL : q ≤ logSize N) (f : Vertex N → ℝ≥0∞)
    (hf : ∀ y ∈ r7Grid N q, f y ≤
      ENNReal.ofReal (C*Real.sqrt (logSize N)*Real.exp (-2*(logSize N-q)-(logSize N)^(3*γ)/4)) +
      ENNReal.ofReal (Real.exp (-c*logSize N*Real.log (logSize N)))) :
    ∑ y ∈ r7Grid N q, f y ≤ ENNReal.ofReal (r7BarrierScaleEnvelope (logSize N) γ c C) := by
  let L := logSize N
  let A := C*Real.sqrt L*Real.exp (-2*(L-q)-L^(3*γ)/4)
  let B := Real.exp (-c*L*Real.log L)
  have hA : 0 ≤ A := by dsimp [A]; positivity
  have hB : 0 ≤ B := (Real.exp_pos _).le
  have hc : ((r7Grid N q).card:ℝ≥0∞) ≤ ENNReal.ofReal (9*Real.exp (2*(L-q))) := by
    simpa only [ENNReal.ofReal_natCast] using ENNReal.ofReal_le_ofReal (r7_grid_card N q hq hqL)
  have hsum : ∑ y ∈ r7Grid N q, f y ≤
      ENNReal.ofReal (9*Real.exp (2*(L-q)))*(ENNReal.ofReal A+ENNReal.ofReal B) := by
    calc
      _ ≤ ∑ _y ∈ r7Grid N q, (ENNReal.ofReal A+ENNReal.ofReal B) := Finset.sum_le_sum hf
      _ = ((r7Grid N q).card:ℝ≥0∞)*(ENNReal.ofReal A+ENNReal.ofReal B) := by
        rw [Finset.sum_const,nsmul_eq_mul]
      _ ≤ _ := mul_le_mul' hc le_rfl
  apply hsum.trans
  rw [← ENNReal.ofReal_add hA hB,← ENNReal.ofReal_mul (by positivity : 0 ≤ 9*Real.exp (2*(L-q)))]
  apply ENNReal.ofReal_le_ofReal
  have hmain : 9*Real.exp (2*(L-q))*A = 9*C*Real.sqrt L*Real.exp (-L^(3*γ)/4) := by
    dsimp only [A]
    calc
      _ = 9*C*Real.sqrt L*(Real.exp (2*(L-q))*Real.exp (-2*(L-q)-L^(3*γ)/4)) := by ring
      _ = _ := by rw [← Real.exp_add]; congr 2; ring
  have hq0 : 0 ≤ q := (Real.log_nonneg (by norm_num : (1:ℝ) ≤ 2)).trans hq
  have herr : 9*Real.exp (2*(L-q))*B ≤ 9*Real.exp (2*L)*B := by
    gcongr
    linarith
  dsimp only [r7BarrierScaleEnvelope]
  rw [mul_add,hmain]
  exact add_le_add le_rfl herr

theorem r7_lower_barrier_scale_bound (hWalk : WalkModelRegular) (γ H : ℝ)
    (hγ : 0 < γ) (hγ1 : 16*γ < 1) (hH : 0 ≤ H) :
    ∃ c C : ℝ, 0 < c ∧ 0 < C ∧ ∀ᶠ N : Size in atTop, ∀ q l r : ℝ,
      (logSize N)^(16*γ) ≤ q → q ≤ logSize N-(logSize N)^(16*γ) →
      l ≤ r → phaseACenter N-H*timeScale N ≤ l → r ≤ phaseACenter N+H*timeScale N →
      r7LoopEventMass N (fun root => r7LowerBarrierFailure N root γ q) l r ≤
        ENNReal.ofReal (r7BarrierScaleEnvelope (logSize N) γ c C) := by
  obtain ⟨c,C,hc,hC,hm⟩ := r7_shifted_barrier_marginal hWalk γ H hγ hγ1 hH
  have hQ := (tendsto_rpow_atTop (by positivity : 0 < 16*γ)).comp blockB_logSize_tendsto
  refine ⟨c,C,hc,hC,?_⟩
  filter_upwards [hm,r7_lower_barrier_grid_mass γ hγ,hQ.eventually_ge_atTop (Real.log 2)] with N hN hg hbase
  intro q l r hq hqL hlr hlo hhi
  apply (hg q hq hqL l r).trans
  exact r7_grid_marginal_sum N γ q c C hC.le (hbase.trans hq)
    (hqL.trans (sub_le_self _ (Real.rpow_nonneg (logSize_pos N).le _))) _
    (fun y _ => hN y q l r hq hqL hlr hlo hhi)

end TorusCoverTime.Blocks.B
