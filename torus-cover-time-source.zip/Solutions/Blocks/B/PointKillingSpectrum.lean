import Solutions.Blocks.B.PointKillingEnergy

/-! The actual rate-one point-killing operator on the full finite torus.
Its spectral decay bound follows from the sharp form inequality. -/
noncomputable section
open Classical
open scoped BigOperators RealInnerProductSpace
namespace TorusCoverTime.Blocks.B

def pointKillingStep (N : Size) (c : Vertex N) (f : Vertex N → ℝ) (x : Vertex N) : ℝ :=
  f x+(generator N f x-(if x=c then f x else 0))/2

theorem pointKillingStep_add (N : Size) (c : Vertex N) (f h : Vertex N → ℝ) :
    pointKillingStep N c (f+h) = pointKillingStep N c f+pointKillingStep N c h := by
  funext x
  simp only [pointKillingStep,Pi.add_apply,generator_add]
  split_ifs <;> ring

theorem pointKillingStep_smul (N : Size) (c : Vertex N) (a : ℝ) (f : Vertex N → ℝ) :
    pointKillingStep N c (a • f) = a • pointKillingStep N c f := by
  funext x
  have hg : generator N (a • f) x = a*generator N f x := generator_mul_left N a f x
  simp only [pointKillingStep,Pi.smul_apply,smul_eq_mul,hg]
  split_ifs <;> ring

theorem pointKillingStep_average (N : Size) (c : Vertex N) (f : Vertex N → ℝ) (x : Vertex N) :
    pointKillingStep N c f x = ((∑ d : Fin 4, f (x+direction N d))/4+(if x=c then 0 else f x))/2 := by
  simp only [pointKillingStep,generator,Finset.sum_sub_distrib,Finset.sum_const,
    Finset.card_univ,Fintype.card_fin,nsmul_eq_mul,Nat.cast_ofNat]
  split_ifs <;> ring

theorem pointKillingStep_nonneg (N : Size) (c : Vertex N) (f : Vertex N → ℝ)
    (hf : ∀ x, 0 ≤ f x) (x : Vertex N) : 0 ≤ pointKillingStep N c f x := by
  rw [pointKillingStep_average]
  have hs : 0 ≤ ∑ d : Fin 4, f (x+direction N d) := Finset.sum_nonneg fun _ _ => hf _
  have hx := hf x
  split_ifs <;> positivity

def pointKillingTransition (N : Size) (c : Vertex N) : Module.End ℝ (EuclideanSpace ℝ (Vertex N)) where
  toFun f := WithLp.toLp 2 (pointKillingStep N c f)
  map_add' := by intro f h; ext x; exact congrFun (pointKillingStep_add N c f h) x
  map_smul' := by intro a f; ext x; exact congrFun (pointKillingStep_smul N c a f) x

theorem pointKilling_inner (N : Size) (f h : EuclideanSpace ℝ (Vertex N)) :
    ⟪f,h⟫ = ∑ x : Vertex N, f x*h x := by
  simp only [PiLp.inner_apply,RCLike.inner_apply,conj_trivial,mul_comm]

theorem pointKillingTransition_inner (N : Size) (c : Vertex N) (f h : EuclideanSpace ℝ (Vertex N)) :
    ⟪f,pointKillingTransition N c h⟫ = ⟪f,h⟫-(dirichletPairing N f h+f c*h c)/2 := by
  rw [pointKilling_inner,pointKilling_inner]
  change (∑ x : Vertex N, f x*(h x+(generator N h x-(if x=c then h x else 0))/2)) = _
  have he (x : Vertex N) : f x*(h x+(generator N h x-(if x=c then h x else 0))/2) =
      f x*h x-(f x*(-generator N h x)+(if x=c then f x*h x else 0))/2 := by
    split_ifs <;> ring
  simp only [he,Finset.sum_sub_distrib,← Finset.sum_div,Finset.sum_add_distrib]
  simp [dirichletPairing]

theorem pointKillingTransition_symmetric (N : Size) (c : Vertex N) :
    (pointKillingTransition N c).IsSymmetric := by
  intro f h
  rw [← real_inner_comm (pointKillingTransition N c f) h,pointKillingTransition_inner,
    pointKillingTransition_inner,real_inner_comm h f,dirichletPairing_symm N h f,mul_comm (h c) (f c)]

abbrev PointKillingIndex (N : Size) := Fin (Module.finrank ℝ (EuclideanSpace ℝ (Vertex N)))

def pointKillingBasis (N : Size) (c : Vertex N) :
    OrthonormalBasis (PointKillingIndex N) ℝ (EuclideanSpace ℝ (Vertex N)) :=
  (pointKillingTransition_symmetric N c).eigenvectorBasis rfl

def pointKillingModeRate (N : Size) (c : Vertex N) (i : PointKillingIndex N) : ℝ :=
  2*(1-(pointKillingTransition_symmetric N c).eigenvalues rfl i)

theorem pointKillingBasis_eigen (N : Size) (c : Vertex N) (i : PointKillingIndex N) :
    pointKillingTransition N c (pointKillingBasis N c i) =
      (1-pointKillingModeRate N c i/2) • pointKillingBasis N c i := by
  have h := (pointKillingTransition_symmetric N c).apply_eigenvectorBasis rfl i
  convert h using 1 <;> simp [pointKillingBasis,pointKillingModeRate]

theorem pointKillingBasis_squareSum (N : Size) (c : Vertex N) (i : PointKillingIndex N) :
    squareSum N (pointKillingBasis N c i) = 1 := by
  have h := (pointKillingBasis N c).orthonormal.1 i
  have he : squareSum N (pointKillingBasis N c i) =
      ⟪pointKillingBasis N c i,pointKillingBasis N c i⟫ := by
    simp only [pointKilling_inner,squareSum,pow_two]
  rw [he,real_inner_self_eq_norm_sq,h]
  norm_num

theorem pointKillingBasis_energy (N : Size) (c : Vertex N) (i : PointKillingIndex N) :
    pointKillingEnergy N c (pointKillingBasis N c i) = pointKillingModeRate N c i := by
  have hi : ⟪pointKillingBasis N c i,pointKillingBasis N c i⟫ = 1 := by
    simpa only [pointKilling_inner,pow_two,squareSum] using pointKillingBasis_squareSum N c i
  have he := pointKillingTransition_inner N c (pointKillingBasis N c i) (pointKillingBasis N c i)
  rw [pointKillingBasis_eigen,real_inner_smul_right,hi] at he
  have he' : (1-pointKillingModeRate N c i/2)*1 = 1-pointKillingEnergy N c (pointKillingBasis N c i)/2 := by
    simpa only [pointKillingEnergy,energy,dirichletPairing,pow_two] using he
  linarith only [he']

theorem pointKillingModeRate_lower (N : Size) (c : Vertex N) (i : PointKillingIndex N) :
    pointKillingRate N ≤ pointKillingModeRate N c i := by
  simpa only [pointKillingBasis_squareSum,pointKillingBasis_energy,mul_one] using
    point_killing_rayleigh N c (pointKillingBasis N c i)

end TorusCoverTime.Blocks.B
