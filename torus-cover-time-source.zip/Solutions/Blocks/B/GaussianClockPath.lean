import Solutions.Blocks.C.C4.Base.PinnedBridgeConditioning

/-! A finite centred Gaussian path with its exact variance clock.  The data
below concern only its Gaussian law and covariance, not any ballot estimate.
Segments, reversals and the actual nested-domain path will supply this data. -/

noncomputable section
open MeasureTheory ProbabilityTheory
open scoped ENNReal NNReal
namespace TorusCoverTime.Blocks.B

structure GaussianClockPath {Ω : Type*} [MeasurableSpace Ω]
    (μ : Measure Ω) (n : ℕ) where
  path : Ω → Fin (n + 1) → ℝ
  clock : Fin (n + 1) → ℝ
  measurable : Measurable path
  gaussian : HasGaussianLaw path μ
  mean_zero : ∀ i, (∫ ω, path ω i ∂μ) = 0
  covariance : ∀ i j, cov[fun ω => path ω i, fun ω => path ω j; μ] = clock (min i j)
  clock_zero : clock 0 = 0
  clock_mono : Monotone clock
  start_zero : ∀ ω, path ω 0 = 0

attribute [fun_prop] GaussianClockPath.measurable

namespace GaussianClockPath
variable {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
variable {n : ℕ} (W : GaussianClockPath μ n)

@[fun_prop] theorem measurable_coord (i : Fin (n + 1)) : Measurable (fun ω => W.path ω i) :=
  (measurable_pi_apply i).comp W.measurable

theorem gaussian_coord (i : Fin (n + 1)) : HasGaussianLaw (fun ω => W.path ω i) μ :=
  W.gaussian.map_fun (ContinuousLinearMap.proj i)

theorem memLp (i : Fin (n + 1)) : MemLp (fun ω => W.path ω i) 2 μ :=
  (W.gaussian_coord i).memLp_two

theorem integrable (i : Fin (n + 1)) : Integrable (fun ω => W.path ω i) μ :=
  (W.memLp i).integrable (by norm_num)

theorem clock_nonneg (i : Fin (n + 1)) : 0 ≤ W.clock i := by
  simpa only [W.clock_zero] using W.clock_mono (Fin.zero_le i)

theorem coordinate_hasLaw (i : Fin (n + 1)) :
    HasLaw (fun ω => W.path ω i) (gaussianReal 0 (W.clock i).toNNReal) μ := by
  refine ⟨(W.measurable_coord i).aemeasurable, ?_⟩
  rw [(W.gaussian_coord i).map_eq_gaussianReal, W.mean_zero,
    ← covariance_self (W.memLp i).aemeasurable, W.covariance, min_self]

theorem increment_gaussian (i j : Fin (n + 1)) :
    HasGaussianLaw (fun ω => W.path ω j - W.path ω i) μ :=
  W.gaussian.map_fun ((ContinuousLinearMap.proj j : (Fin (n + 1) → ℝ) →L[ℝ] ℝ) -
    ContinuousLinearMap.proj i)

theorem increment_covariance (i j k l : Fin (n + 1)) :
    cov[fun ω => W.path ω j - W.path ω i,
      fun ω => W.path ω l - W.path ω k; μ] =
      W.clock (min j l) - W.clock (min j k) -
        W.clock (min i l) + W.clock (min i k) := by
  rw [covariance_fun_sub_fun_sub (W.memLp j) (W.memLp i) (W.memLp l) (W.memLp k)]
  simp only [W.covariance]

theorem increment_hasLaw (i j : Fin (n + 1)) (hij : i ≤ j) :
    HasLaw (fun ω => W.path ω j - W.path ω i)
      (gaussianReal 0 (W.clock j - W.clock i).toNNReal) μ := by
  refine ⟨((W.measurable_coord j).sub (W.measurable_coord i)).aemeasurable, ?_⟩
  rw [(W.increment_gaussian i j).map_eq_gaussianReal,
    integral_sub (W.integrable j) (W.integrable i), W.mean_zero, W.mean_zero, sub_self,
    ← covariance_self (show AEMeasurable (fun ω => W.path ω j - W.path ω i) μ from
      ((W.memLp j).sub (W.memLp i)).aemeasurable),
    W.increment_covariance]
  simp only [min_self, min_eq_left hij, min_eq_right hij, sub_add_cancel]

theorem disjoint_increment_covariance (i j k l : Fin (n + 1))
    (hij : i ≤ j) (hjk : j ≤ k) (hkl : k ≤ l) :
    cov[fun ω => W.path ω j - W.path ω i,
      fun ω => W.path ω l - W.path ω k; μ] = 0 := by
  rw [W.increment_covariance]
  simp only [min_eq_left (hjk.trans hkl), min_eq_left hjk,
    min_eq_left (hij.trans (hjk.trans hkl)), min_eq_left (hij.trans hjk)]
  ring

theorem past_increment_covariance (i j k : Fin (n + 1)) (hij : i ≤ j) (hjk : j ≤ k) :
    cov[fun ω => W.path ω i, fun ω => W.path ω k - W.path ω j; μ] = 0 := by
  rw [covariance_fun_sub_right (W.memLp i) (W.memLp k) (W.memLp j),
    W.covariance, W.covariance, min_eq_left (hij.trans hjk), min_eq_left hij, sub_self]

end GaussianClockPath
end TorusCoverTime.Blocks.B
