import Solutions.Blocks.B.GaussianBridgeExceptionalScales

noncomputable section
open MeasureTheory ProbabilityTheory Classical
open scoped BigOperators ENNReal
namespace TorusCoverTime.Blocks.B.GaussianClockPath
variable {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
variable {M : ℕ} (W : GaussianClockPath μ (M+1))

def gridDifferenceFailure {n : ℕ} (f : Fin (n+1) → Fin (M+2)) (g : Fin (M+2) → Fin (n+1)) (A : ℝ) : Set Ω :=
  {ω | ∃ j : Fin (M+2), A≤|W.bridge ω j-W.bridge ω (f (g j))|}

theorem gridDifferenceFailure_bound {n : ℕ} (f : Fin (n+1) → Fin (M+2)) (g : Fin (M+2) → Fin (n+1))
    (K A : ℝ) (hK : 0<K) (hA : 0≤A) (hv : 0<W.clock (Fin.last (M+1)))
    (hle : ∀ j, f (g j)≤j) (hgap : ∀ j, W.clock j-W.clock (f (g j))≤K) :
    μ.real (W.gridDifferenceFailure f g A)≤(M+2:ℕ)*(2*Real.exp (-A^2/(2*K))) := by
  have hb := finite_event_probability_bound (μ := μ)
    (fun j : Fin (M+2) => {ω | A≤|W.bridge ω j-W.bridge ω (f (g j))|}) (2*Real.exp (-A^2/(2*K)))
  simp only [Fintype.card_fin,Set.mem_ofPred_eq] at hb
  unfold gridDifferenceFailure
  apply hb
  intro j
  exact W.bridge_increment_abs_tail hv (f (g j)) j (hle j) K A hK hA (hgap j)

def rawMiddleContact (L A S : ℝ) : Set Ω :=
  {ω | (∀ i : Fin (M+2), i.val≤M → A≤(i.val:ℝ) → (i.val:ℝ)≤L-A →
      -A≤W.bridge ω i ∨ W.bridge ω i≤-(i.val:ℝ)) ∧
    ∃ j : Fin (M+2), j.val≤M ∧ S≤(j.val:ℝ) ∧ (j.val:ℝ)≤L-S ∧ W.bridge ω j≤A}

theorem bridge_last_zero (hv : 0<W.clock (Fin.last (M+1))) (ω : Ω) :
    W.bridge ω (Fin.last (M+1))=0 := by rw [bridge,div_self hv.ne',one_mul,sub_self]

theorem rawMiddleContact_subset {n : ℕ} (L A S : ℝ) (hA : 0≤A)
    (hv : 0<W.clock (Fin.last (M+1)))
    (f : Fin (n+1) → Fin (M+2)) (hf : Monotone f) (hf0 : f 0=0) (hfl : f (Fin.last n)=Fin.last (M+1))
    (g : Fin (M+2) → Fin (n+1)) (r : ℕ)
    (hmid : ∀ j : Fin (M+2), j.val≤M → S≤(j.val:ℝ) → (j.val:ℝ)≤L-S → r≤(g j).val ∧ r≤n-(g j).val) :
    W.rawMiddleContact L A S ⊆
      ((W.neg.subsample f hf hf0).middleContact (2*A) (4*A) r ∪ W.oppositeBranch A) ∪
        W.endpointOvershoot L A ∪ W.gridDifferenceFailure f g A := by
  intro ω hω
  by_cases hop : ω∈W.oppositeBranch A
  · exact Or.inl (Or.inl (Or.inr hop))
  by_cases hend : ω∈W.endpointOvershoot L A
  · exact Or.inl (Or.inr hend)
  by_cases hdif : ω∈W.gridDifferenceFailure f g A
  · exact Or.inr hdif
  apply Or.inl ∘ Or.inl ∘ Or.inl
  change (∀ i, (W.neg.subsample f hf hf0).bridge ω i≤2*A) ∧ _
  have hbridge (i : Fin (n+1)) : (W.neg.subsample f hf hf0).bridge ω i= -W.bridge ω (f i) := by
    rw [subsample_bridge W.neg f hf hf0 hfl,neg_bridge]
  constructor
  · intro i
    rw [hbridge]
    by_cases hlast : (f i).val=M+1
    · have he : f i=Fin.last (M+1) := Fin.ext hlast
      rw [he,W.bridge_last_zero hv,neg_zero]
      linarith
    have hiM : (f i).val≤M := by have := (f i).isLt; omega
    by_cases hlo : A≤((f i).val:ℝ)
    · by_cases hhi : ((f i).val:ℝ)≤L-A
      · rcases hω.1 (f i) hiM hlo hhi with hh | hh
        · linarith
        · exact False.elim (hop ⟨f i,hiM,hlo,hh⟩)
      · have hh : ¬(2*A≤-W.bridge ω (f i)) := fun hh => hend ⟨f i,hiM,Or.inr (lt_of_not_ge hhi),hh⟩
        linarith
    · have hh : ¬(2*A≤-W.bridge ω (f i)) := fun hh => hend ⟨f i,hiM,Or.inl (lt_of_not_ge hlo),hh⟩
      linarith
  · obtain ⟨j,hj,hs,hl,hc⟩ := hω.2
    have hm := hmid j hj hs hl
    refine ⟨g j,hm.1,hm.2,?_⟩
    rw [hbridge]
    have hd : |W.bridge ω j-W.bridge ω (f (g j))|<A :=
      lt_of_not_ge (fun hh => hdif ⟨j,hh⟩)
    have hh := (abs_lt.mp hd).1
    linarith

theorem rawMiddleContact_bound {n : ℕ} (L C A S K U : ℝ) (hA : 0<A) (hK : 0<K) (hC : 0≤C)
    (hAC : 4*C≤A) (hv : 0<W.clock (Fin.last (M+1)))
    (herr : ∀ i, |W.clock i-sparseClockTime L 1 (M+1) i/2|≤C)
    (f : Fin (n+1) → Fin (M+2)) (hf : Monotone f) (hf0 : f 0=0) (hfl : f (Fin.last n)=Fin.last (M+1))
    (g : Fin (M+2) → Fin (n+1)) (hle : ∀ j, f (g j)≤j) (hgap : ∀ j, W.clock j-W.clock (f (g j))≤K)
    (hbound : (W.neg.subsample f hf hf0).ClockBounds U)
    (r : ℕ) (hr : 1≤r) (hrn : 2*r≤n)
    (hmid : ∀ j : Fin (M+2), j.val≤M → S≤(j.val:ℝ) → (j.val:ℝ)≤L-S → r≤(g j).val ∧ r≤n-(g j).val) :
    μ.real (W.rawMiddleContact L A S)≤
      bridgeContactConstant U*(2*A+bridgeBarrierPadding U)^2*(4*A+bridgeBarrierPadding U)^3/((n:ℝ)*Real.sqrt r)+
        (M+2:ℕ)*(2*Real.exp (-A/2)+2*Real.exp (-A^2/(2*K))) := by
  have hs := W.rawMiddleContact_subset L A S hA.le hv f hf hf0 hfl g r hmid
  have hh := (measureReal_mono (μ := μ) hs).trans (measureReal_union_le _ _)
  have h1 := measureReal_union_le (μ := μ)
    ((W.neg.subsample f hf hf0).middleContact (2*A) (4*A) r ∪ W.oppositeBranch A) (W.endpointOvershoot L A)
  have h2 := measureReal_union_le (μ := μ)
    ((W.neg.subsample f hf hf0).middleContact (2*A) (4*A) r) (W.oppositeBranch A)
  have hb := (W.neg.subsample f hf hf0).bridge_middle_contact_bound hbound r hr hrn (2*A) (4*A) (by linarith) (by linarith)
  have hb' := ENNReal.toReal_mono (by finiteness) hb
  rw [ENNReal.toReal_ofReal (by
    have hh := bridgeContactConstant_bounds U
    have hp := bridgeBarrierPadding_ge_two U
    have hc : 0 ≤ bridgeContactConstant U := by linarith [hh.1]
    have hp0 : 0 ≤ bridgeBarrierPadding U := by linarith
    positivity)] at hb'
  have ho := W.oppositeBranch_bound L C A hA (by linarith) hv herr
  have he := W.endpointOvershoot_bound L C A hA hAC hv herr
  have hd := W.gridDifferenceFailure_bound f g K A hK hA.le hv hle hgap
  change μ.real ((W.neg.subsample f hf hf0).middleContact (2*A) (4*A) r)≤_ at hb'
  nlinarith

end TorusCoverTime.Blocks.B.GaussianClockPath
