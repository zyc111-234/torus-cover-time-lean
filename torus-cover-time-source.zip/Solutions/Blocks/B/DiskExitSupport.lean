import Solutions.Blocks.B.DiskGreenBounds
import Solutions.Blocks.B.DiskWalkLift
import Solutions.Blocks.B.DiskCardinality

/-! Actual disk exit measure is supported on exterior neighbors, and its
harmonic extension preserves uniform boundary estimates. -/

noncomputable section
open MeasureTheory Classical
namespace TorusCoverTime.Blocks.B

theorem torusDisk_proper (N : Size) (c : Vertex N) (R : ℝ) (hR : 0 ≤ R)
    (hsmall : 2*(R+1) < N.val) : torusDisk N c R ≠ Finset.univ := by
  intro he
  have hcard := torusDisk_card_le N c R hR
  rw [he] at hcard
  simp only [Finset.card_univ, Fintype.card_prod, ZMod.card, Nat.cast_mul] at hcard
  have hN : 0 < (N.val : ℝ) := zero_lt_one.trans (size_real_gt_one N)
  have hh := mul_pos (by linarith : 0 < (N.val : ℝ) - (2*R+1))
    (by linarith : 0 < (N.val : ℝ) + (2*R+1))
  nlinarith

theorem exitsThrough_disk_exterior (N : Size) (c : Vertex N) (R : ℝ) (a b : Vertex N)
    (ha : a ∈ torusDisk N c R) (ω : WalkSample) (hω : ω ∈ exitsThrough N (torusDisk N c R) a b) :
    diskExteriorNeighbor N c R b := by
  obtain ⟨n, hb, hend, hpre⟩ := hω
  cases n with
  | zero =>
    have he : a = b := by simpa [position] using hend
    exact False.elim (hb (he ▸ ha))
  | succ n =>
    refine ⟨hb, position N a ω n, hpre ⟨n, by omega⟩, ?_⟩
    rw [position_succ_step] at hend
    rw [← hend]
    exact torus_neighbor_step N _ _

theorem exitHarmonic_disk_support (N : Size) (c : Vertex N) (R : ℝ) (a b : Vertex N)
    (ha : a ∈ torusDisk N c R) (hb : ¬ diskExteriorNeighbor N c R b) :
    exitHarmonic N (torusDisk N c R) b a = 0 := by
  have he : exitsThrough N (torusDisk N c R) a b = ∅ := by
    apply Set.eq_empty_iff_forall_notMem.mpr
    intro ω hω
    exact hb (exitsThrough_disk_exterior N c R a b ha ω hω)
  unfold exitHarmonic
  rw [he, measureReal_empty]

theorem exitExtension_bounds (N : Size) (D : Finset (Vertex N)) (hD : D ≠ Finset.univ)
    (a : Vertex N) (f : Vertex N → ℝ) (l u : ℝ)
    (hf : ∀ b, exitHarmonic N D b a ≠ 0 → l ≤ f b ∧ f b ≤ u) :
    l ≤ exitExtension N D f a ∧ exitExtension N D f a ≤ u := by
  have hl (b : Vertex N) : l * exitHarmonic N D b a ≤ f b * exitHarmonic N D b a := by
    by_cases hb : exitHarmonic N D b a = 0
    · simp [hb]
    · exact mul_le_mul_of_nonneg_right (hf b hb).1 (exitHarmonic_nonneg N D b a)
  have hu (b : Vertex N) : f b * exitHarmonic N D b a ≤ u * exitHarmonic N D b a := by
    by_cases hb : exitHarmonic N D b a = 0
    · simp [hb]
    · exact mul_le_mul_of_nonneg_right (hf b hb).2 (exitHarmonic_nonneg N D b a)
  have hl' := Finset.sum_le_sum (s := Finset.univ) (fun b _ => hl b)
  have hu' := Finset.sum_le_sum (s := Finset.univ) (fun b _ => hu b)
  rw [← Finset.mul_sum, exitHarmonic_sum_one N D hD a, mul_one] at hl' hu'
  exact ⟨hl', hu'⟩

theorem exitExtension_abs_error (N : Size) (D : Finset (Vertex N)) (hD : D ≠ Finset.univ)
    (a : Vertex N) (f : Vertex N → ℝ) (v C : ℝ)
    (hf : ∀ b, exitHarmonic N D b a ≠ 0 → |f b - v| ≤ C) :
    |exitExtension N D f a - v| ≤ C := by
  have h := exitExtension_bounds N D hD a f (v-C) (v+C) (by
    intro b hb
    have h := abs_le.mp (hf b hb)
    constructor <;> linarith)
  rw [abs_le]
  constructor <;> linarith

theorem diskExitExtension_abs_error (N : Size) (c : Vertex N) (R : ℝ) (hR : 0 ≤ R)
    (hsmall : 2*(R+1) < N.val) (a : Vertex N) (ha : a ∈ torusDisk N c R)
    (f : Vertex N → ℝ) (v C : ℝ) (hf : ∀ b, diskExteriorNeighbor N c R b → |f b - v| ≤ C) :
    |exitExtension N (torusDisk N c R) f a - v| ≤ C := by
  apply exitExtension_abs_error N _ (torusDisk_proper N c R hR hsmall) a f v C
  intro b hb
  exact hf b (by by_contra hn; exact hb (exitHarmonic_disk_support N c R a b ha hn))

theorem diskExteriorNeighbor_inner_distance (N : Size) (c : Vertex N) (R : ℝ) (hR : 1 ≤ R)
    (b y : Vertex N) (hb : diskExteriorNeighbor N c R b) (hy : periodicDistance y c ≤ R/2) :
    R/2 ≤ periodicDistance b y ∧ periodicDistance b y ≤ 3*R := by
  have hr := diskExteriorNeighbor_radius N c R b hb
  have ht := periodicDistance_triangle N b y c
  have ht' := periodicDistance_triangle N b c y
  rw [periodicDistance_comm c y] at ht'
  constructor <;> linarith

theorem diskBarrier_correction_bound (N : Size) (c : Vertex N) (R : ℝ) (hR : 0 ≤ R)
    (hsmall : 2*(R+1) < N.val) (a : Vertex N) :
    |(1 / vertexCount N) * (diskBarrier N c R a -
      exitExtension N (torusDisk N c R) (diskBarrier N c R) a)| ≤ 1 := by
  have he := exitExtension_bounds N (torusDisk N c R) (torusDisk_proper N c R hR hsmall)
    a (diskBarrier N c R) 0 ((R+1)^2) (fun b _ => ⟨diskBarrier_nonneg N c R b, diskBarrier_le N c R b⟩)
  have hb0 := diskBarrier_nonneg N c R a
  have hb1 := diskBarrier_le N c R a
  have hdiff : |diskBarrier N c R a - exitExtension N (torusDisk N c R) (diskBarrier N c R) a| ≤ (R+1)^2 := by
    rw [abs_le]
    constructor <;> linarith
  rw [abs_mul, abs_of_pos (one_div_pos.mpr (vertexCount_pos N))]
  apply (mul_le_mul_of_nonneg_left hdiff (one_div_nonneg.mpr (vertexCount_pos N).le)).trans
  rw [one_div_mul_eq_div]
  apply (div_le_one (vertexCount_pos N)).mpr
  unfold vertexCount
  have hN : 0 < (N.val : ℝ) := zero_lt_one.trans (size_real_gt_one N)
  nlinarith

end TorusCoverTime.Blocks.B
