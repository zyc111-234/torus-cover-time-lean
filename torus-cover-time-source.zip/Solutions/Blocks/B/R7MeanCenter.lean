import Solutions.Blocks.B.R7PreciseGreen
import Solutions.Blocks.B.R7ConcentrationRate

/-! R7.1: the actual conditioned one-block mean and sums of such means
have exponentially small error about the original logarithmic width. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

def r7MeanExponent : ℝ := min diskExitOscillationExponent (1/4)
def r7MeanConstant : ℝ :=
  diskExitOscillationConstant*(1+r7GreenCenterConstant)+r7GreenCenterConstant

theorem r7MeanExponent_pos : 0 < r7MeanExponent :=
  lt_min diskExitOscillationExponent_pos (by norm_num)

theorem r7MeanConstant_pos : 0 < r7MeanConstant := by
  have := diskExitOscillationConstant_pos
  have := r7GreenCenterConstant_pos
  unfold r7MeanConstant
  positivity

theorem r7_occupation_mean_center (hWalk : WalkModelRegular) (γ : ℝ)
    (hγ : 0 < γ) (hγ1 : γ ≤ 1) :
    ∀ᶠ q : ℝ in atTop, ∀ N : Size, ∀ c a b : Vertex N,
      2*(Real.exp (q+2*q^γ)+1) < N.val →
      |periodicDistance a c-Real.exp (q+q^γ)| ≤ 2 →
      diskExteriorNeighbor N c (Real.exp (q+2*q^γ)) b →
      |(∫ ω, harmonicExitOccupation N c (Real.exp (q+1)) (Real.exp (q+2*q^γ)) a ω
        ∂exactExitLaw N (torusDisk N c (Real.exp (q+2*q^γ))) a b)-q^γ| ≤
          r7MeanConstant*q^γ*Real.exp (-r7MeanExponent*q^γ) := by
  filter_upwards [r7_green_center γ hγ hγ1, r7_mean_conditioning_error hWalk γ hγ,
    (tendsto_rpow_atTop hγ).eventually_ge_atTop (1:ℝ)] with q hc hm hw
  intro N c a b hsmall ha hb
  let w := q^γ
  let K := diskGreen N c (Real.exp (q+2*q^γ)) a c/g
  let e := Real.exp (-r7MeanExponent*w)
  have hw0 : 0 ≤ w := by dsimp [w]; linarith
  have he : 0 < e := Real.exp_pos _
  have hK := hc N c a b hsmall ha hb
  have hcond := hm N c a b hsmall ha hb
  have hG := r7GreenCenterConstant_pos
  have hD := diskExitOscillationConstant_pos
  have he1 : Real.exp (-diskExitOscillationExponent*w) ≤ e := by
    apply Real.exp_le_exp.mpr
    have hh := mul_le_mul_of_nonneg_right (min_le_left diskExitOscillationExponent (1/4)) hw0
    dsimp [r7MeanExponent, e]
    linarith
  have he2 : Real.exp (-w/4) ≤ e := by
    apply Real.exp_le_exp.mpr
    have hh := mul_le_mul_of_nonneg_right (min_le_right diskExitOscillationExponent (1/4)) hw0
    dsimp [r7MeanExponent, e]
    linarith
  have he20 : Real.exp (-w/4) ≤ 1 := Real.exp_le_one_iff.mpr (by linarith)
  have hK0 : 0 ≤ K := div_nonneg
    (diskGreen_nonneg N c _ (Real.exp_pos _).le hsmall a c) (by unfold g; positivity)
  have hKu : K ≤ (1+r7GreenCenterConstant)*w := by
    have hh := (abs_le.mp hK).2
    have hh' := mul_le_mul_of_nonneg_left he20 hG.le
    change K-w ≤ r7GreenCenterConstant*Real.exp (-w/4) at hh
    nlinarith [mul_nonneg hG.le (show 0 ≤ w-1 by dsimp [w]; linarith)]
  calc
    _ ≤ |(∫ ω, harmonicExitOccupation N c (Real.exp (q+1)) (Real.exp (q+2*q^γ)) a ω
          ∂exactExitLaw N (torusDisk N c (Real.exp (q+2*q^γ))) a b)-K|+|K-w| := abs_sub_le _ _ _
    _ ≤ (diskExitOscillationConstant*Real.exp (-diskExitOscillationExponent*w))*K+
        r7GreenCenterConstant*Real.exp (-w/4) := add_le_add hcond hK
    _ ≤ (diskExitOscillationConstant*e)*((1+r7GreenCenterConstant)*w)+r7GreenCenterConstant*e := by
      apply add_le_add
      · exact mul_le_mul (mul_le_mul_of_nonneg_left he1 hD.le) hKu hK0 (by positivity)
      · exact mul_le_mul_of_nonneg_left he2 hG.le
    _ ≤ (diskExitOscillationConstant*e)*((1+r7GreenCenterConstant)*w)+r7GreenCenterConstant*e*w := by
      exact add_le_add (le_refl _) (le_mul_of_one_le_right (by positivity) hw)
    _ = _ := by dsimp [r7MeanConstant, w, e]; ring

theorem r7_mean_sum_center (hWalk : WalkModelRegular) (γ : ℝ) (hγ : 0 < γ) (hγ1 : γ ≤ 1) :
    ∀ᶠ q : ℝ in atTop, ∀ N : Size, ∀ c : Vertex N, ∀ m : ℕ,
      ∀ a b : Fin m → Vertex N,
      2*(Real.exp (q+2*q^γ)+1) < N.val →
      (∀ i, |periodicDistance (a i) c-Real.exp (q+q^γ)| ≤ 2) →
      (∀ i, diskExteriorNeighbor N c (Real.exp (q+2*q^γ)) (b i)) →
      |harmonicExitMeanSum N c (Real.exp (q+1)) (Real.exp (q+2*q^γ)) m a b-(m:ℝ)*q^γ| ≤
        (r7MeanConstant*Real.exp (-r7MeanExponent*q^γ))*((m:ℝ)*q^γ) := by
  filter_upwards [r7_occupation_mean_center hWalk γ hγ hγ1] with q hm
  intro N c m a b hsmall ha hb
  have he : (m:ℝ)*q^γ = ∑ _i : Fin m, q^γ := by simp
  rw [he, harmonicExitMeanSum, ← Finset.sum_sub_distrib]
  apply (Finset.abs_sum_le_sum_abs _ _).trans
  calc
    _ ≤ ∑ _i : Fin m, r7MeanConstant*q^γ*Real.exp (-r7MeanExponent*q^γ) :=
      Finset.sum_le_sum (fun i _ => hm N c (a i) (b i) hsmall (ha i) (hb i))
    _ = _ := by simp; ring

end TorusCoverTime.Blocks.B
