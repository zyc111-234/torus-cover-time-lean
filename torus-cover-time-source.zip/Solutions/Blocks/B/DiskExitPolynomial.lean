import Solutions.Blocks.B.RadialGreenLower
import Solutions.Blocks.B.R6ConditionedHitting

/-! A polynomial lower bound for every feasible specified exterior endpoint.
The proof uses a single inward step, a radial Green subsolution, and the
already proved interior Harnack comparison. -/

noncomputable section
open Classical
namespace TorusCoverTime.Blocks.B

theorem harmonic_point_hit_lower (N : Size) (D : Finset (Vertex N))
    (f : Vertex N → ℝ) (hf : ∀ z, 0 ≤ f z) (hg : ∀ z ∈ D, generator N f z = 0)
    (a x : Vertex N) : f x*exitHarmonic N (D.erase x) x a ≤ f a := by
  have hD : D.erase x ≠ Finset.univ := by
    intro he
    have hh : x ∈ D.erase x := by rw [he]; exact Finset.mem_univ _
    simpa using hh
  let U := f-(fun z => f x*exitHarmonic N (D.erase x) x z)
  have hgen : ∀ z ∈ D.erase x, generator N U z = 0 := by
    intro z hz
    dsimp [U]
    rw [generator_sub,hg z (Finset.mem_erase.mp hz).2,generator_mul_left,
      exitHarmonic_generator N (D.erase x) x z hz,mul_zero,sub_zero]
  have hbd : ∀ z, z ∉ D.erase x → 0 ≤ U z := by
    intro z hz
    dsimp [U]
    rw [exitHarmonic_boundary N (D.erase x) x z hz]
    by_cases hzx : z = x
    · subst z
      simp
    · rw [if_neg hzx,mul_zero,sub_zero]
      exact hf z
  exact sub_nonneg.mp (domain_harmonic_nonnegative N _ hD U hgen hbd a)

def diskExitPower : ℕ := 2*(radialPowerIndex+2)+2

theorem disk_exit_center_polynomial (N : Size) (c : Vertex N) (R : ℝ)
    (hR : 4*diskGreenInnerScale ≤ R) (hsmall : 2*(R+1) < N.val)
    (b : Vertex N) (hb : diskExteriorNeighbor N c R b) :
    1/(64*R^diskExitPower) ≤ exitHarmonic N (torusDisk N c R) b c := by
  have hL := diskGreenInnerScale_ge_four
  have hR1 : 1 ≤ R := by linarith
  have hR0 : 0 < R := by linarith
  let D := torusDisk N c R
  let f := exitHarmonic N D b
  obtain ⟨u,hu,hbu⟩ := hb.2
  obtain ⟨d,hd⟩ := hbu.2
  have huR := (mem_torusDisk N c u R).mp hu
  have hbR : R ≤ periodicDistance b c := not_lt.mp ((mem_torusDisk N c b R).not.mp hb.1)
  have hdist := periodicDistance_step_le N c u d
  rw [← hd] at hdist
  have hu2 : 2 ≤ periodicDistance u c := by linarith
  obtain ⟨e,he⟩ := torus_radial_inward N c u (by linarith)
  let v := u+direction N e
  have huv : 1 ≤ R^2-periodicDistance v c^2 := by
    have hsq := pow_le_pow_left₀ (Real.sqrt_nonneg _) huR.le 2
    dsimp [v]
    nlinarith
  have hvD : v ∈ D := by
    apply (mem_torusDisk N c v R).mpr
    have hrv := Real.sqrt_nonneg (periodicDistance v c^2)
    have hp : 0 ≤ periodicDistance v c := Real.sqrt_nonneg _
    nlinarith
  have hfu : 1/4 ≤ f u := by
    have hh := exitHarmonic_neighbor_le N D b u hu d
    rw [← hd,exitHarmonic_boundary N D b b hb.1,if_pos rfl] at hh
    dsimp [f]
    linarith
  have hfv : 1/16 ≤ f v := by
    have hh := exitHarmonic_neighbor_le N D b v hvD (reversedDirection e)
    have hvu : v+direction N (reversedDirection e) = u := by dsimp [v]; rw [direction_reversed]; simp
    rw [hvu] at hh
    change f u ≤ 4*f v at hh
    linarith
  have hG : 1/(R^2)^(radialPowerIndex+2) ≤ diskGreen N c R c v := by
    rw [diskGreen_symm N c R hR0.le hsmall c v]
    exact diskGreen_inward_polynomial N c R hR hsmall v huv
  have hdiag : 0 < diskGreen N c R v v :=
    zero_lt_one.trans_le (diskGreen_diagonal N c R hR0.le hsmall v hvD)
  have hdiagHi : diskGreen N c R v v ≤ 4*R^2 := by
    have hsingle := Finset.single_le_sum (s := (Finset.univ : Finset (Vertex N)))
      (fun z _ => diskGreen_nonneg N c R hR0.le hsmall v z) (Finset.mem_univ v)
    have hmass := diskGreen_mass_bound N c R hR0.le hsmall v
    nlinarith
  have hhit := harmonic_point_hit_lower N D f (exitHarmonic_nonneg N D b)
    (fun z hz => exitHarmonic_generator N D b z hz) c v
  rw [domainGreenFromBarrier_hit_ratio N D (diskBarrier N c R)
    (fun z hz => diskBarrier_generator N c R hR0.le hsmall z hz) c v hvD] at hhit
  change f v*(diskGreen N c R c v/diskGreen N c R v v) ≤ f c at hhit
  have hratio : (1/(R^2)^(radialPowerIndex+2))/(4*R^2) ≤ diskGreen N c R c v/diskGreen N c R v v :=
    (div_le_div_of_nonneg_left (by positivity) hdiag hdiagHi).trans
      (div_le_div_of_nonneg_right hG hdiag.le)
  have hmul := mul_le_mul hfv hratio (by positivity)
    (exitHarmonic_nonneg N D b v)
  change _ ≤ f c
  calc
    _ = (1/16)*((1/(R^2)^(radialPowerIndex+2))/(4*R^2)) := by
      unfold diskExitPower
      rw [pow_add,pow_mul]
      ring
    _ ≤ f v*(diskGreen N c R c v/diskGreen N c R v v) := hmul
    _ ≤ f c := hhit

def diskExitLowerConstant : ℝ := 1/(64*diskHarnackConstant)

theorem diskExitLowerConstant_pos : 0 < diskExitLowerConstant := by
  have := diskHarnackConstant_gt_one
  unfold diskExitLowerConstant
  positivity

theorem disk_exit_interior_polynomial (N : Size) (c : Vertex N) (R : ℝ)
    (hR : 3*diskHarnackRadiusThreshold ≤ R) (hsmall : 2*(R+1) < N.val)
    (a b : Vertex N) (ha : periodicDistance a c ≤ R/(12*diskGreenInnerScale))
    (hb : diskExteriorNeighbor N c R b) :
    diskExitLowerConstant*R^(-(diskExitPower:ℝ)) ≤ exitHarmonic N (torusDisk N c R) b a := by
  have hL := diskGreenInnerScale_ge_four
  have hH := harmonicCutoffScale_ge_one
  have hT := diskHarnackRadiusThreshold_ge_one
  have hR0 : 0 < R := by linarith
  have hr : 4*diskGreenInnerScale ≤ R := by
    unfold diskHarnackRadiusThreshold at hR
    nlinarith [mul_nonneg (show 0 ≤ diskGreenInnerScale by linarith) (show 0 ≤ harmonicCutoffScale-1 by linarith)]
  have hc := disk_exit_center_polynomial N c R hr hsmall b hb
  have hh := disk_harnack_small_torus N c R hR hsmall (exitHarmonic N (torusDisk N c R) b)
    (exitHarmonic_nonneg N _ b) (fun z hz => exitHarmonic_generator N _ b z hz) a c ha
    (by rw [periodicDistance_self_zero]; positivity)
  have hHP : 0 < diskHarnackConstant := zero_lt_one.trans diskHarnackConstant_gt_one
  have hbnd : (1/(64*R^diskExitPower))/diskHarnackConstant ≤ exitHarmonic N (torusDisk N c R) b a :=
    (div_le_iff₀ hHP).mpr (by nlinarith)
  rw [Real.rpow_neg hR0.le,Real.rpow_natCast]
  unfold diskExitLowerConstant
  convert hbnd using 1 <;> ring

end TorusCoverTime.Blocks.B
