import Solutions.Blocks.B.CapacityChargeBounds
import Solutions.Blocks.B.Poincare
import Mathlib.Analysis.Normed.Module.FiniteDimension

/-! Compact attainment of the killed Rayleigh infimum and its homogeneous inequality. -/

noncomputable section
open scoped BigOperators
namespace TorusCoverTime.Blocks.B

def squareSum (N : Size) (f : Vertex N → ℝ) : ℝ := ∑ x : Vertex N, f x ^ 2

lemma squareSum_nonneg (N : Size) (f : Vertex N → ℝ) : 0 ≤ squareSum N f :=
  Finset.sum_nonneg (fun _ _ => sq_nonneg _)

lemma squareSum_eq_zero (N : Size) (f : Vertex N → ℝ) : squareSum N f = 0 ↔ f = 0 := by
  constructor
  · intro hf
    funext x
    have hx := Finset.single_le_sum (s := (Finset.univ : Finset (Vertex N)))
      (f := fun y => f y ^ 2) (fun _ _ => sq_nonneg _) (Finset.mem_univ x)
    change f x ^ 2 ≤ squareSum N f at hx
    rw [hf] at hx
    change f x = 0
    nlinarith [sq_nonneg (f x)]
  · rintro rfl
    simp [squareSum]

lemma squareSum_pos (N : Size) (f : Vertex N → ℝ) (hf : f ≠ 0) : 0 < squareSum N f :=
  lt_of_le_of_ne (squareSum_nonneg N f) (fun h => hf ((squareSum_eq_zero N f).mp h.symm))

lemma squareSum_smul (N : Size) (c : ℝ) (f : Vertex N → ℝ) :
    squareSum N (c • f) = c ^ 2 * squareSum N f := by
  simp only [squareSum, Pi.smul_apply, smul_eq_mul, mul_pow, Finset.mul_sum]

lemma squareSum_single (N : Size) (x : Vertex N) : squareSum N (Pi.single x 1) = 1 := by
  classical
  simp [squareSum, Pi.single_apply]

lemma vanishesOn_single (N : Size) (A : Finset (Vertex N)) (x : Vertex N) (hx : x ∉ A) :
    vanishesOn N A (Pi.single x 1) := by
  classical
  intro y hy
  have hyx : y ≠ x := fun h => hx (h ▸ hy)
  simp [hyx]

lemma vanishesOn_smul (N : Size) (A : Finset (Vertex N))
    (c : ℝ) (f : Vertex N → ℝ) (hf : vanishesOn N A f) : vanishesOn N A (c • f) := by
  intro x hx
  simp [hf x hx]

def killedUnitSphere (N : Size) (A : Finset (Vertex N)) : Set (Vertex N → ℝ) :=
  {f | vanishesOn N A f ∧ squareSum N f = 1}

lemma continuous_squareSum (N : Size) : Continuous (squareSum N) := by
  unfold squareSum
  fun_prop

lemma continuous_energy (N : Size) : Continuous (energy N) := by
  unfold energy generator
  fun_prop

lemma killedUnitSphere_nonempty (N : Size) (A : Finset (Vertex N)) (hA : A ≠ Finset.univ) :
    (killedUnitSphere N A).Nonempty := by
  classical
  obtain ⟨x, hx⟩ : ∃ x : Vertex N, x ∉ A := by
    by_contra! hall
    exact hA (Finset.eq_univ_iff_forall.mpr hall)
  exact ⟨Pi.single x 1, vanishesOn_single N A x hx, squareSum_single N x⟩

lemma killedUnitSphere_isClosed (N : Size) (A : Finset (Vertex N)) :
    IsClosed (killedUnitSphere N A) := by
  have hs : IsClosed {f : Vertex N → ℝ | vanishesOn N A f} := by
    change IsClosed {f : Vertex N → ℝ | ∀ x ∈ A, f x = 0}
    simp only [Set.ofPred_forall]
    exact isClosed_iInter fun x => isClosed_iInter fun _ =>
      isClosed_eq (continuous_apply x) continuous_const
  exact hs.inter (isClosed_eq (continuous_squareSum N) continuous_const)

lemma killedUnitSphere_compact (N : Size) (A : Finset (Vertex N)) :
    IsCompact (killedUnitSphere N A) := by
  apply (isCompact_closedBall (0 : Vertex N → ℝ) 1).of_isClosed_subset
    (killedUnitSphere_isClosed N A)
  intro f hf
  simp only [Metric.mem_closedBall, dist_zero_right, pi_norm_le_iff_of_nonneg zero_le_one,
    Real.norm_eq_abs]
  intro x
  have hx := Finset.single_le_sum (s := (Finset.univ : Finset (Vertex N)))
    (f := fun y => f y ^ 2) (fun _ _ => sq_nonneg _) (Finset.mem_univ x)
  change f x ^ 2 ≤ squareSum N f at hx
  rw [hf.2] at hx
  exact abs_le.mpr ⟨by nlinarith, by nlinarith⟩

lemma exists_killed_minimizer (N : Size) (A : Finset (Vertex N)) (hA : A ≠ Finset.univ) :
    ∃ f : Vertex N → ℝ, vanishesOn N A f ∧ squareSum N f = 1 ∧
      energy N f = killedEigenvalue N A ∧
      ∀ g : Vertex N → ℝ, vanishesOn N A g → squareSum N g = 1 → energy N f ≤ energy N g := by
  obtain ⟨f, hf, hmin⟩ := (killedUnitSphere_compact N A).exists_isMinOn
    (killedUnitSphere_nonempty N A hA) (continuous_energy N).continuousOn
  have heq : energy N f = killedEigenvalue N A := by
    unfold killedEigenvalue
    apply le_antisymm
    · refine le_csInf ?_ ?_
      · exact ⟨energy N f, f, hf.1, hf.2, rfl⟩
      · rintro r ⟨g, hg, hg1, rfl⟩
        exact hmin ⟨hg, hg1⟩
    · apply csInf_le
      · refine ⟨0, ?_⟩
        rintro r ⟨g, _, _, rfl⟩
        exact energy_nonneg N g
      · exact ⟨f, hf.1, hf.2, rfl⟩
  exact ⟨f, hf.1, hf.2, heq, fun g hg hg1 => hmin ⟨hg, hg1⟩⟩

lemma killedEigenvalue_nonneg (N : Size) (A : Finset (Vertex N)) (hA : A ≠ Finset.univ) :
    0 ≤ killedEigenvalue N A := by
  obtain ⟨f, _, _, hf, _⟩ := exists_killed_minimizer N A hA
  rw [← hf]
  exact energy_nonneg N f

lemma killed_rayleigh (N : Size) (A : Finset (Vertex N)) (hA : A ≠ Finset.univ)
    (f : Vertex N → ℝ) (hf : vanishesOn N A f) :
    killedEigenvalue N A * squareSum N f ≤ energy N f := by
  by_cases hf0 : f = 0
  · subst f
    simp [squareSum, energy, generator]
  have hs := squareSum_pos N f hf0
  let c := (Real.sqrt (squareSum N f))⁻¹
  have hc : c ^ 2 * squareSum N f = 1 := by
    dsimp [c]
    rw [inv_pow, Real.sq_sqrt hs.le, inv_mul_cancel₀ hs.ne']
  obtain ⟨g, _, _, hg, hmin⟩ := exists_killed_minimizer N A hA
  have h := hmin (c • f) (vanishesOn_smul N A c f hf) (by rw [squareSum_smul, hc])
  rw [hg, energy_smul] at h
  have hm := mul_le_mul_of_nonneg_right h hs.le
  calc
    killedEigenvalue N A * squareSum N f ≤ (c ^ 2 * energy N f) * squareSum N f := hm
    _ = energy N f := by
      calc
        _ = (c ^ 2 * squareSum N f) * energy N f := by ring
        _ = _ := by rw [hc, one_mul]

end TorusCoverTime.Blocks.B
