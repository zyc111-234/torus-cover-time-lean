import Solutions.Blocks.B.R7PerturbedLowCountMass

/-! Exact identification of the cutoff mass with the perturbed annulus's actual
square-root completed traversal count. -/

noncomputable section
open MeasureTheory Filter Set Classical
open scoped ENNReal NNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

def r7PerturbedTraversalRadius (N : Size) (c root : Vertex N) (γ q : ℝ) (z : WalkSample × ℝ) : ℝ :=
  Real.sqrt (r7PerturbedWidth q (q^γ)*(completedTraversalCount N (torusDisk N c (r7PerturbedInner q (q^γ)))
    (torusDisk N c (r7PerturbedOuter q (q^γ))) root z.1 z.2:ℝ))

theorem r7PerturbedTraversalRadius_measurable (N : Size) (c root : Vertex N) (γ q : ℝ) :
    Measurable (r7PerturbedTraversalRadius N c root γ q) :=
  (((measurable_from_nat : Measurable (fun n : ℕ => (n:ℝ))).comp
    (completedTraversalCount_measurable N _ _ root)).const_mul (r7PerturbedWidth q (q^γ))).sqrt

def r7PerturbedIntegratedLowCount (N : Size) (c : Vertex N) (γ q v l r : ℝ) : ℝ≥0∞ :=
  (ENNReal.ofReal (timeScale N))⁻¹ * ∑ root : Vertex N,
    ∫⁻ ω, ∫⁻ t in Ioi (0:ℝ), if
      (N.val:ℝ)*Real.exp (-((logSize N)^(16*γ))/2) ≤ periodicDistance c root ∧
      r7PerturbedTraversalRadius N c root γ q (ω,t) ≤ v ∧ walk N root ω t = root ∧ t ∈ Icc l r
      then 1 else 0 ∂volume ∂walkLaw

theorem r7PerturbedIntegratedLowCount_eq_cutoff (N : Size) (c : Vertex N) (γ q v l r : ℝ)
    (hw : 0 < r7PerturbedWidth q (q^γ)) (hv : 0 ≤ v) :
    r7PerturbedIntegratedLowCount N c γ q v l r =
      normalizedPerturbedFarRootCountedMass N c γ q (r7PerturbedLowCountCutoff q γ v) l r := by
  unfold r7PerturbedIntegratedLowCount normalizedPerturbedFarRootCountedMass perturbedFarRootCountedMass
  congr 1
  apply Finset.sum_congr rfl
  intro root _
  by_cases hfar : (N.val:ℝ)*Real.exp (-((logSize N)^(16*γ))/2) ≤ periodicDistance c root
  · rw [if_pos hfar]
    unfold countedLoopWindowMass
    apply lintegral_congr
    intro ω
    apply lintegral_congr
    intro t
    simp only [r7_perturbed_low_count_cutoff_iff q γ v _ hw hv,hfar,true_and,r7PerturbedTraversalRadius]
  · simp only [hfar,false_and,if_false,lintegral_zero]

theorem r7_perturbed_integrated_low_count_bound (hWalk : WalkModelRegular) (γ H C₁ : ℝ)
    (hγ : 0 < γ) (hγ1 : 16*γ < 1) (hH : 0 ≤ H) (hC₁ : 0 < C₁) :
    ∃ c₀ C : ℝ, 0 < c₀ ∧ 0 < C ∧ ∀ᶠ N : Size in atTop,
      ∀ c : Vertex N, ∀ q v l r : ℝ,
        (logSize N)^(16*γ) ≤ q → q ≤ logSize N-(logSize N)^(16*γ) → q ≤ v → v ≤ C₁*logSize N →
        l ≤ r → phaseACenter N-H*timeScale N ≤ l → r ≤ phaseACenter N+H*timeScale N →
        r7PerturbedIntegratedLowCount N c γ q v l r ≤
          ENNReal.ofReal (C*Real.sqrt (logSize N)*Real.exp (-(max
            (harmonicExtremeCenter N-v-(logSize N)^(2*γ)-C*Real.log (logSize N)) 0)^2/(logSize N-q+C))) +
          ENNReal.ofReal (Real.exp (-c₀*logSize N*Real.log (logSize N))) := by
  obtain ⟨c₀,C,hc,hC,hlow⟩ := r7_perturbed_low_count_mass hWalk γ H C₁ hγ hγ1 hH hC₁
  obtain ⟨q0,hq0⟩ := eventually_atTop.mp (r7_perturbed_parameter_geometry γ hγ (by linarith))
  have hQ := (tendsto_rpow_atTop (by positivity : 0 < 16*γ)).comp blockB_logSize_tendsto
  refine ⟨c₀,C,hc,hC,?_⟩
  filter_upwards [hlow,hQ.eventually_ge_atTop q0] with N hN hbase
  intro c q v l r hq hqL hqv hvL hlr hleft hright
  have hqpos : 0 < q := (Real.rpow_pos_of_pos (logSize_pos N) (16*γ)).trans_le hq
  have hw : 0 < r7PerturbedWidth q (q^γ) :=
    (Real.rpow_pos_of_pos hqpos γ).trans_le (hq0 q (hbase.trans hq)).2.2.2.2.2.2.1
  rw [r7PerturbedIntegratedLowCount_eq_cutoff N c γ q v l r hw (hqpos.le.trans hqv)]
  exact hN c q v l r hq hqL hqv hvL hlr hleft hright

end TorusCoverTime.Blocks.B

