import Solutions.Blocks.B.BT6Goal

/-! Deterministic conversion of the original square norm to the two bridge
branches. The error budget is explicit, including the square residual. -/

noncomputable section
namespace TorusCoverTime.Blocks.B

theorem square_norm_lower_abs (M R q δ e : ℝ) (hq : 0<q) (hδ : 0≤δ) (hδq : δ≤q/2)
    (he : 0≤e) (hR : R≤q*e) (hlo : q-δ≤Real.sqrt (M^2+R)) :
    q-δ-2*e≤|M| := by
  by_contra hn
  have ha : |M|<q-δ-2*e := lt_of_not_ge hn
  have heq : (q-δ)^2≤M^2+R := by
    have hs := Real.sq_sqrt (show 0≤M^2+R from by
      by_contra hneg
      rw [Real.sqrt_eq_zero_of_nonpos (le_of_not_ge hneg)] at hlo
      linarith)
    nlinarith [Real.sqrt_nonneg (M^2+R)]
  have hab : 0≤q-δ-|M| := by linarith
  have hgap : 0<q-δ-2*e-|M| := by linarith
  have hp : 0<q-δ := by linarith
  nlinarith [sq_abs M,mul_nonneg (abs_nonneg M) hab,
    mul_nonneg he (show 0≤q-2*δ by linarith),mul_pos hp hgap]

theorem norm_lower_bridge_branches (q δ e r B M : ℝ) (hq : 0<q) (hδ : 0≤δ)
    (hδq : δ≤q/2) (he : 0≤e) (hr : 0≤r) (hR : r≤q*e)
    (hlo : q-δ≤Real.sqrt (M^2+r)) (hreg : |M+q+B|≤e) :
    -δ-3*e≤B ∨ B≤-2*q+δ+3*e := by
  have hab := square_norm_lower_abs M r q δ e hq hδ hδq he hR hlo
  have hreg' := abs_le.mp hreg
  rcases le_or_gt M 0 with hM | hM
  · left
    rw [abs_of_nonpos hM] at hab
    linarith
  · right
    rw [abs_of_pos hM] at hab
    linarith

theorem norm_contact_bridge (q δ e r B M : ℝ) (hr : 0≤r) (he : 0≤e)
    (hhi : Real.sqrt (M^2+r)≤q+δ) (hreg : |M+q+B|≤e) : B≤δ+e := by
  have ha : |M|≤Real.sqrt (M^2+r) := by
    rw [← Real.sqrt_sq_eq_abs M]
    exact Real.sqrt_le_sqrt (by linarith)
  have hm := neg_abs_le M
  have hh := (abs_le.mp hreg).2
  linarith

end TorusCoverTime.Blocks.B
