import Solutions.Blocks.B.ExitVisit

/-! R6's local Laplace estimate uses actual occupation and exact-exit conditioning.
No Harnack or hitting-probability estimate is assumed in the holding-time argument. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Classical
open scoped ENNReal Topology BigOperators
namespace TorusCoverTime.Blocks.B

lemma integral_directionSelectedHolding_cond_event
    (J : (ℕ → Fin 4) → ℕ) (hJ : Measurable J)
    (E F : Set (ℕ → Fin 4)) (hE : MeasurableSet E) (hF : MeasurableSet F) :
    (∫ ω in walkDirections ⁻¹' F, Real.exp (-directionSelectedHolding J ω)
      ∂walkLaw[|walkDirections ⁻¹' E]) =
      (1 / 2 : ℝ) * (walkLaw[|walkDirections ⁻¹' E]).real (walkDirections ⁻¹' F) := by
  simp only [ProbabilityTheory.cond, Measure.restrict_smul, integral_smul_measure,
    Measure.restrict_restrict (hF.preimage measurable_walkDirections),
    measureReal_ennreal_smul_apply,
    measureReal_restrict_apply (hF.preimage measurable_walkDirections)]
  rw [← Set.preimage_inter,
    integral_directionSelectedHolding_direction_event J hJ (F ∩ E) (hF.inter hE)]
  ring

lemma integral_first_holdingTime_given_exit_on_visit (N : Size) (D : Finset (Vertex N))
    (a b x : Vertex N) :
    (∫ ω in visitsBeforeExit N D a x, Real.exp (-holdingTime ω (firstVisitIndex N a x ω))
      ∂exactExitLaw N D a b) =
      (1 / 2 : ℝ) * (exactExitLaw N D a b).real (visitsBeforeExit N D a x) := by
  have h := integral_directionSelectedHolding_cond_event
    (firstVisitIndex N a x ∘ skeletonSample)
    ((measurable_firstVisitIndex N a x).comp measurable_skeletonSample)
    (skeletonSample ⁻¹' exitsThrough N D a b)
    (skeletonSample ⁻¹' visitsBeforeExit N D a x)
    ((measurableSet_exitsThrough N D a b).preimage measurable_skeletonSample)
    ((measurableSet_visitsBeforeExit N D a x).preimage measurable_skeletonSample)
  rw [exitsThrough_direction_preimage, visitsBeforeExit_direction_preimage] at h
  simpa only [directionSelectedHolding, Function.comp_def, firstVisitIndex_skeletonSample_directions,
    exactExitLaw] using h

lemma localTime_nonneg (N : Size) (a x : Vertex N) (ω : WalkSample) (t : ℝ) :
    0 ≤ localTime N a ω t x := by
  apply integral_nonneg
  intro s
  dsimp only
  split_ifs <;> norm_num

lemma integrable_exp_neg_exit_occupation (N : Size) (D : Finset (Vertex N)) (a x : Vertex N)
    (μ : Measure WalkSample) [IsFiniteMeasure μ] :
    Integrable (fun ω => Real.exp (-localTime N a ω (finiteExitDuration N D a ω) x)) μ := by
  apply Integrable.of_bound ((localTime_measurable_random_time N a x _
    (measurable_finiteExitDuration N D a)).neg.exp.aestronglyMeasurable) 1
  exact Eventually.of_forall fun ω => by
    rw [Real.norm_eq_abs, abs_of_pos (Real.exp_pos _)]
    exact Real.exp_le_one_iff.mpr (neg_nonpos.mpr (localTime_nonneg N a x ω _))

lemma exit_occupation_laplace_le (hWalk : WalkModelRegular)
    (N : Size) (D : Finset (Vertex N)) (a b x : Vertex N)
    (hexit : walkLaw (exitsThrough N D a b) ≠ 0) :
    (∫ ω, Real.exp (-localTime N a ω (finiteExitDuration N D a ω) x) ∂exactExitLaw N D a b) ≤
      1 - (1 / 2 : ℝ) * (exactExitLaw N D a b).real (visitsBeforeExit N D a x) := by
  let μ := exactExitLaw N D a b
  have : IsProbabilityMeasure μ := cond_isProbabilityMeasure hexit
  let H := visitsBeforeExit N D a x
  let f := fun ω => Real.exp (-localTime N a ω (finiteExitDuration N D a ω) x)
  let g := fun ω => Real.exp (-holdingTime ω (firstVisitIndex N a x ω))
  have hH : MeasurableSet H := measurableSet_visitsBeforeExit N D a x
  have hf : Integrable f μ := integrable_exp_neg_exit_occupation N D a x μ
  have hmg : Measurable g := by
    have hm := measurable_directionSelectedHolding (firstVisitIndex N a x ∘ skeletonSample)
      ((measurable_firstVisitIndex N a x).comp measurable_skeletonSample)
    exact hm.neg.exp
  have hg : Integrable g μ := by
    apply Integrable.of_bound hmg.aestronglyMeasurable 1
    exact Eventually.of_forall fun ω => by
      dsimp [g]
      rw [abs_of_pos (Real.exp_pos _)]
      apply Real.exp_le_one_iff.mpr
      simp [holdingTime]
  have hregular : ∀ᵐ ω ∂μ, (∀ j, 0 < (ω j).1) ∧ Tendsto (jumpTime ω) atTop atTop :=
    cond_absolutelyContinuous.ae_le hWalk.1
  have hhit : (∫ ω in H, f ω ∂μ) ≤ ∫ ω in H, g ω ∂μ := by
    apply integral_mono_ae hf.integrableOn hg.integrableOn
    filter_upwards [ae_restrict_of_ae hregular, ae_restrict_mem hH] with ω hω hx
    exact Real.exp_le_exp.mpr (neg_le_neg (first_holdingTime_le_exit_occupation
      N D a x hω.1 hω.2 hx))
  have hmiss : (∫ ω in Hᶜ, f ω ∂μ) ≤ μ.real Hᶜ := by
    calc
      _ ≤ ∫ _ in Hᶜ, (1 : ℝ) ∂μ := by
        apply integral_mono_ae hf.integrableOn (integrable_const 1)
        exact Eventually.of_forall fun ω =>
          Real.exp_le_one_iff.mpr (neg_nonpos.mpr (localTime_nonneg N a x ω _))
      _ = _ := by simp [Measure.real]
  have hmean : (∫ ω in H, g ω ∂μ) = (1 / 2 : ℝ) * μ.real H :=
    integral_first_holdingTime_given_exit_on_visit N D a b x
  have hsplit := integral_add_compl hH hf
  have hcompl := probReal_compl_eq_one_sub (μ := μ) hH
  change (∫ ω, f ω ∂μ) ≤ _
  rw [hmean] at hhit
  rw [hcompl] at hmiss
  linarith

lemma visitsBeforeExit_probability_eq_physical (hWalk : WalkModelRegular)
    (N : Size) (D : Finset (Vertex N)) (a b x : Vertex N) :
    (exactExitLaw N D a b).real (visitsBeforeExit N D a x) =
      (exactExitLaw N D a b).real {ω | hittingTime N a ω x < domainExitTime N D a ω} := by
  have hregular : ∀ᵐ ω ∂exactExitLaw N D a b,
      (∀ j, 0 < (ω j).1) ∧ Tendsto (jumpTime ω) atTop atTop :=
    cond_absolutelyContinuous.ae_le hWalk.1
  have hexit : ∀ᵐ ω ∂exactExitLaw N D a b, ω ∈ exitsThrough N D a b :=
    ae_cond_mem (measurableSet_exitsThrough N D a b)
  apply congrArg ENNReal.toReal
  apply measure_congr
  filter_upwards [hregular, hexit] with ω hω he
  exact propext (hittingTime_lt_domainExitTime_iff_visit N D a b x hω.1 hω.2 he).symm

lemma exit_occupation_laplace_le_hittingTime (hWalk : WalkModelRegular)
    (N : Size) (D : Finset (Vertex N)) (a b x : Vertex N)
    (hexit : walkLaw (exitsThrough N D a b) ≠ 0) :
    (∫ ω, Real.exp (-localTime N a ω (finiteExitDuration N D a ω) x) ∂exactExitLaw N D a b) ≤
      1 - (1 / 2 : ℝ) * (exactExitLaw N D a b).real
        {ω | hittingTime N a ω x < domainExitTime N D a ω} := by
  rw [← visitsBeforeExit_probability_eq_physical hWalk N D a b x]
  exact exit_occupation_laplace_le hWalk N D a b x hexit

end TorusCoverTime.Blocks.B
