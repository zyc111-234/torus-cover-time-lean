import Solutions.Blocks.B.BT11WitnessSurvival

/-! Disintegrate the actual path at the fixed prefix time. Only then use
the short-bridge estimate; this retains the original loop endpoint event. -/
noncomputable section
open MeasureTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

theorem bt11_closing_joint_lower (hWalk : WalkModelRegular) :
    ∀ᶠ N : Size in atTop, ∀ a : Vertex N, ∀ u η s T : ℝ, 0<η → 0≤s →
    bt11ShortTime N≤T → T≤2*bt11ShortTime N →
      ENNReal.ofReal (1/(4*vertexCount N))*walkLaw (bt11Bad N a u η s∩bt11GoodPrefix N a u s)≤
        walkLaw {ω | ω∈bt11Bad N a (u+1) (η/2) (s+T) ∧ walk N a ω (s+T)=a} := by
  filter_upwards [bt11_prefix_extension hWalk] with N hN
  intro a u η s T hη hs hlo hhi
  let E := bt11Bad N a u η s∩bt11GoodPrefix N a u s
  let F := {ω | ω∈bt11Bad N a (u+1) (η/2) (s+T) ∧ walk N a ω (s+T)=a}
  let ρ := ENNReal.ofReal (1/(4*vertexCount N))
  have hE : MeasurableSet E := (bt11Bad_measurable N a u η s).inter (bt11GoodPrefix_measurable N a u s)
  have hF : MeasurableSet F := (bt11Bad_measurable N a (u+1) (η/2) (s+T)).inter
    (((measurable_walk_eq_joint N a a).comp (measurable_id.prodMk measurable_const)).setOf)
  change ρ*walkLaw E≤walkLaw F
  rw [← lintegral_indicator_const hE ρ,← lintegral_indicator_one hF,
    A.lintegral_disintegrate_time s hs (measurable_const.indicator hE),
    A.lintegral_disintegrate_time s hs (measurable_one.indicator hF)]
  apply ENNReal.tsum_le_tsum
  intro n
  apply lintegral_mono_ae
  filter_upwards [ae_restrict_of_ae (A.prefix_positive_ae n),
    ae_restrict_mem (measurableSet_le (A.prefixTime_measurable n) measurable_const)] with p hp hps
  apply mul_le_mul' le_rfl
  by_cases he : A.glueAt n p s A.regularSample∈E
  · have hleft : (fun ξ => E.indicator (fun _ => ρ) (A.glueAt n p s ξ))=ᵐ[walkLaw] fun _ => ρ := by
      filter_upwards [hWalk.1] with ξ hξ
      have hi : A.glueAt n p s ξ∈E :=
        ⟨(bt11_glue_bad_past N a n hp s hps hξ.1 hξ.2 u η).mpr he.1,
          (bt11_glue_good_past N a n hp s hps hξ.1 hξ.2 u).mpr he.2⟩
      exact indicator_of_mem hi _
    rw [lintegral_congr_ae hleft,lintegral_const,measure_univ,mul_one]
    simpa only [ρ,F,Set.indicator,Pi.one_apply,mem_setOf_eq] using hN a u η s T hη hlo hhi n p hp hps he
  · have hleft : (fun ξ => E.indicator (fun _ => ρ) (A.glueAt n p s ξ))=ᵐ[walkLaw] fun _ => 0 := by
      filter_upwards [hWalk.1] with ξ hξ
      apply indicator_of_notMem
      intro hi
      exact he ⟨(bt11_glue_bad_past N a n hp s hps hξ.1 hξ.2 u η).mp hi.1,
        (bt11_glue_good_past N a n hp s hps hξ.1 hξ.2 u).mp hi.2⟩
    rw [lintegral_congr_ae hleft,lintegral_zero]
    exact bot_le

theorem bt11_bad_split (N : Size) (a : Vertex N) (u η s : ℝ) :
    walkLaw (bt11Bad N a u η s)≤walkLaw (bt11Bad N a u η s∩bt11GoodPrefix N a u s)+
      (walkLaw {ω | (ω,s)∈pointNearSoftEvent N a a (bt11FarRadius N) u}+
        walkLaw {ω | (ω,s)∈pointNearTerminalEvent N a (bt11FarRadius N) u}) := by
  let E := bt11Bad N a u η s∩bt11GoodPrefix N a u s
  let F := {ω | (ω,s)∈pointNearSoftEvent N a a (bt11FarRadius N) u}
  let G := {ω | (ω,s)∈pointNearTerminalEvent N a (bt11FarRadius N) u}
  have hsub : bt11Bad N a u η s⊆E∪(F∪G) := by
    intro ω hω
    by_cases hf : ω∈F
    · exact Or.inr (Or.inl hf)
    · by_cases hg : ω∈G
      · exact Or.inr (Or.inr hg)
      · exact Or.inl ⟨hω,hf,hg⟩
  exact (measure_mono hsub).trans ((measure_union_le E (F∪G)).trans
    (add_le_add le_rfl (measure_union_le F G)))

theorem bt11_closing_point_upper (hWalk : WalkModelRegular) (u H : ℝ) (hH : 0≤H) :
    ∀ᶠ N : Size in atTop, ∀ a : Vertex N, ∀ η s T : ℝ, 0<η → 0≤s →
    phaseACenter N-H*timeScale N≤s → bt11ShortTime N≤T → T≤2*bt11ShortTime N →
      walkLaw (bt11Bad N 0 u η s)≤ENNReal.ofReal (4*vertexCount N)*
        walkLaw {ω | ω∈bt11Bad N a (u+1) (η/2) (s+T) ∧ walk N a ω (s+T)=a}+
          ENNReal.ofReal (2*pointNearEnvelope N (1/8192) 1 u H) := by
  filter_upwards [bt11_closing_joint_lower hWalk,
    point_near_central_probabilities hWalk (1/8192) 1 u H (by norm_num) hH] with N hclose hnear
  intro a η s T hη hs htime hlo hhi
  have hρ : ENNReal.ofReal (4*vertexCount N)*ENNReal.ofReal (1/(4*vertexCount N))=1 := by
    rw [← ENNReal.ofReal_mul (by have := vertexCount_pos N; positivity),mul_one_div_cancel
      (show 4*vertexCount N≠0 by have := vertexCount_pos N; positivity),ENNReal.ofReal_one]
  have h := mul_le_mul' (le_refl (ENNReal.ofReal (4*vertexCount N))) (hclose a u η s T hη hs hlo hhi)
  rw [← mul_assoc,hρ,one_mul] at h
  have hnear₁ := ENNReal.ofReal_le_ofReal (hnear a a s htime).1
  have hnear₂ := ENNReal.ofReal_le_ofReal (hnear a a s htime).2
  simp only [Measure.real,ENNReal.ofReal_toReal (measure_ne_top _ _)] at hnear₁ hnear₂
  have hn := add_le_add hnear₁ hnear₂
  rw [← ENNReal.ofReal_add (pointNearEnvelope_nonneg N (1/8192) 1 u H)
    (pointNearEnvelope_nonneg N (1/8192) 1 u H),← two_mul] at hn
  rw [← bt11Bad_start_eq N a 0]
  exact (bt11_bad_split N a u η s).trans (add_le_add h hn)

end TorusCoverTime.Blocks.B
