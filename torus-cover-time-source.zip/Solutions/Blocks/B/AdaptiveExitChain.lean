import Solutions.Blocks.B.ExitChainResampling

/-! Successive exits on the actual path: each segment starts at the endpoint
of the preceding one. All finite shifts exit every proper domain almost surely,
so no independence or prescribed entrance sequence is assumed here. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

def adaptiveExitIndex (N : Size) (D : ℕ → Finset (Vertex N)) (root : Vertex N) :
    ℕ → WalkSample → ℕ
  | 0, _ => 0
  | k+1, ω =>
      let s := adaptiveExitIndex N D root k ω
      s + finiteExitIndex N (D k) (position N root ω s) (fun j => ω (s+j))

def adaptiveExitStart (N : Size) (D : ℕ → Finset (Vertex N)) (root : Vertex N)
    (k : ℕ) (ω : WalkSample) : Vertex N := position N root ω (adaptiveExitIndex N D root k ω)

def adaptiveExitTail (N : Size) (D : ℕ → Finset (Vertex N)) (root : Vertex N)
    (k : ℕ) (ω : WalkSample) : WalkSample := fun j => ω (adaptiveExitIndex N D root k ω+j)

def adaptiveExitRecord (N : Size) (D : ℕ → Finset (Vertex N)) (root : Vertex N)
    (k : ℕ) (ω : WalkSample) : ℕ × WalkSample :=
  finiteExitRecord N (D k) (adaptiveExitStart N D root k ω) (adaptiveExitTail N D root k ω)

def adaptiveExitTime (N : Size) (D : ℕ → Finset (Vertex N)) (root : Vertex N)
    (k : ℕ) (ω : WalkSample) : ℝ := jumpTime ω (adaptiveExitIndex N D root k ω)

@[simp] theorem adaptiveExitIndex_zero (N : Size) (D : ℕ → Finset (Vertex N))
    (root : Vertex N) (ω : WalkSample) : adaptiveExitIndex N D root 0 ω = 0 := rfl

@[simp] theorem adaptiveExitStart_zero (N : Size) (D : ℕ → Finset (Vertex N))
    (root : Vertex N) (ω : WalkSample) : adaptiveExitStart N D root 0 ω = root := by
  simp [adaptiveExitStart]

theorem adaptiveExitIndex_succ (N : Size) (D : ℕ → Finset (Vertex N))
    (root : Vertex N) (k : ℕ) (ω : WalkSample) :
    adaptiveExitIndex N D root (k+1) ω = adaptiveExitIndex N D root k ω +
      finiteExitIndex N (D k) (adaptiveExitStart N D root k ω) (adaptiveExitTail N D root k ω) := rfl

theorem adaptiveExitStart_succ (N : Size) (D : ℕ → Finset (Vertex N))
    (root : Vertex N) (k : ℕ) (ω : WalkSample) :
    adaptiveExitStart N D root (k+1) ω = position N (adaptiveExitStart N D root k ω)
      (adaptiveExitTail N D root k ω)
      (finiteExitIndex N (D k) (adaptiveExitStart N D root k ω) (adaptiveExitTail N D root k ω)) := by
  exact position_shift_sample N root ω _ _

theorem adaptiveExitIndex_mono (N : Size) (D : ℕ → Finset (Vertex N))
    (root : Vertex N) (ω : WalkSample) : Monotone (fun k => adaptiveExitIndex N D root k ω) := by
  apply monotone_nat_of_le_succ
  intro k
  rw [adaptiveExitIndex_succ]
  omega

theorem position_at_measurable_index (N : Size) (root : Vertex N)
    (τ : WalkSample → ℕ) (hτ : Measurable τ) : Measurable (fun ω => position N root ω (τ ω)) := by
  have hm : Measurable (fun p : WalkSample × ℕ => position N root p.1 p.2) :=
    measurable_from_prod_countable_left fun n =>
      measurable_to_countable' fun b => (measurable_position_eq N root b n).setOf
  exact hm.comp (measurable_id.prodMk hτ)

theorem adaptiveExitIndex_measurable (N : Size) (D : ℕ → Finset (Vertex N))
    (root : Vertex N) (k : ℕ) : Measurable (adaptiveExitIndex N D root k) := by
  induction k with
  | zero => exact measurable_const
  | succ k ih =>
    have hm : Measurable (fun p : WalkSample × Vertex N => finiteExitIndex N (D k) p.2 p.1) :=
      measurable_from_prod_countable_left fun a => measurable_finiteExitIndex N (D k) a
    exact ih.add (hm.comp ((stoppedTail_measurable ih).prodMk (position_at_measurable_index N root _ ih)))

theorem adaptiveExitStart_measurable (N : Size) (D : ℕ → Finset (Vertex N))
    (root : Vertex N) (k : ℕ) : Measurable (adaptiveExitStart N D root k) :=
  position_at_measurable_index N root _ (adaptiveExitIndex_measurable N D root k)

theorem adaptiveExitTail_measurable (N : Size) (D : ℕ → Finset (Vertex N))
    (root : Vertex N) (k : ℕ) : Measurable (adaptiveExitTail N D root k) :=
  stoppedTail_measurable (adaptiveExitIndex_measurable N D root k)

theorem adaptiveExitRecord_measurable (N : Size) (D : ℕ → Finset (Vertex N))
    (root : Vertex N) (k : ℕ) : Measurable (adaptiveExitRecord N D root k) := by
  have hm : Measurable (fun p : WalkSample × Vertex N => finiteExitRecord N (D k) p.2 p.1) :=
    measurable_from_prod_countable_left fun a => finiteExitRecord_measurable N (D k) a
  exact hm.comp ((adaptiveExitTail_measurable N D root k).prodMk (adaptiveExitStart_measurable N D root k))

theorem adaptiveExitTime_measurable (N : Size) (D : ℕ → Finset (Vertex N))
    (root : Vertex N) (k : ℕ) : Measurable (adaptiveExitTime N D root k) :=
  excursionRecordDuration_measurable.comp ((adaptiveExitIndex_measurable N D root k).prodMk measurable_id)

theorem fixedShift_measurePreserving (n : ℕ) :
    MeasurePreserving (fun ω : WalkSample => fun j => ω (n+j)) walkLaw walkLaw := by
  refine ⟨by fun_prop, ?_⟩
  exact Measure.map_infinitePi_infinitePi_of_inj (P := fun _ => stepLaw)
    (fun _ _ h => Nat.add_left_cancel h)

theorem all_shifts_exit_ae (N : Size) (D : ℕ → Finset (Vertex N))
    (hD : ∀ k, ∃ b : Vertex N, b ∉ D k) :
    ∀ᵐ ω ∂walkLaw, ∀ k s : ℕ, ∀ a : Vertex N,
      ∃ n : ℕ, position N a (fun j => ω (s+j)) n ∉ D k := by
  apply ae_all_iff.mpr
  intro k
  apply ae_all_iff.mpr
  intro s
  apply ae_all_iff.mpr
  intro a
  exact (fixedShift_measurePreserving s).quasiMeasurePreserving.ae (finite_domain_exits_ae N (D k) (hD k) a)

theorem adaptiveExit_spec_ae (N : Size) (D : ℕ → Finset (Vertex N))
    (hD : ∀ k, ∃ b : Vertex N, b ∉ D k) (root : Vertex N) :
    ∀ᵐ ω ∂walkLaw, ∀ k,
      exitsThroughAt N (D k) (adaptiveExitStart N D root k ω) (adaptiveExitStart N D root (k+1) ω)
        (adaptiveExitTail N D root k ω)
        (finiteExitIndex N (D k) (adaptiveExitStart N D root k ω) (adaptiveExitTail N D root k ω)) := by
  filter_upwards [all_shifts_exit_ae N D hD] with ω hω
  intro k
  rw [adaptiveExitStart_succ]
  exact finiteExitIndex_spec N (D k) _ _ (hω k (adaptiveExitIndex N D root k ω) _)

theorem adaptiveExitTime_succ (N : Size) (D : ℕ → Finset (Vertex N))
    (root : Vertex N) (k : ℕ) (ω : WalkSample) :
    adaptiveExitTime N D root (k+1) ω = adaptiveExitTime N D root k ω +
      excursionRecordDuration (adaptiveExitRecord N D root k ω) := by
  rw [adaptiveExitTime, adaptiveExitIndex_succ, jumpTime_shift_sample]
  congr 1
  exact finiteExitDuration_eq_record N (D k) _ _

theorem adaptiveExitTime_eq_sum (N : Size) (D : ℕ → Finset (Vertex N))
    (root : Vertex N) (k : ℕ) (ω : WalkSample) :
    adaptiveExitTime N D root k ω =
      ∑ j ∈ Finset.range k, excursionRecordDuration (adaptiveExitRecord N D root j ω) := by
  induction k with
  | zero => simp [adaptiveExitTime]
  | succ k ih => rw [adaptiveExitTime_succ, ih, Finset.sum_range_succ]

theorem adaptiveExit_between (N : Size) (D : ℕ → Finset (Vertex N)) (root : Vertex N)
    (ω : WalkSample) (k : ℕ)
    (hs : exitsThroughAt N (D k) (adaptiveExitStart N D root k ω)
      (adaptiveExitStart N D root (k+1) ω) (adaptiveExitTail N D root k ω)
      (finiteExitIndex N (D k) (adaptiveExitStart N D root k ω) (adaptiveExitTail N D root k ω)))
    (j : ℕ) (hj : adaptiveExitIndex N D root k ω ≤ j)
    (hj' : j < adaptiveExitIndex N D root (k+1) ω) : position N root ω j ∈ D k := by
  have he : j = adaptiveExitIndex N D root k ω+(j-adaptiveExitIndex N D root k ω) := by omega
  rw [he, position_shift_sample]
  apply hs.2.2 ⟨j-adaptiveExitIndex N D root k ω, ?_⟩
  rw [adaptiveExitIndex_succ] at hj'
  omega

end TorusCoverTime.Blocks.B
