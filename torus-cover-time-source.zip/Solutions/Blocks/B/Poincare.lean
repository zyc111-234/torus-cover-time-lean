import Solutions.Blocks.B.FiniteParseval
import Solutions.Blocks.B.GreenPositive

/-! The exact torus Poincare inequality, deduced from finite Parseval and the exact gap. -/

noncomputable section
open scoped BigOperators
namespace TorusCoverTime.Blocks.B

lemma sum_const_vertex (N : Size) (c : ℝ) : (∑ _ : Vertex N, c) = vertexCount N * c := by
  simp [vertexCount, Fintype.card_prod, ZMod.card, pow_two]

lemma sum_eq_vertexCount_mean (N : Size) (f : Vertex N → ℝ) :
    (∑ x : Vertex N, f x) = vertexCount N * spatialMean N f := by
  unfold spatialMean
  rw [mul_div_cancel₀ _ (vertexCount_pos N).ne']

lemma sum_sq_centered (N : Size) (f : Vertex N → ℝ) (c : ℝ) :
    (∑ x : Vertex N, (f x - c) ^ 2) =
      (∑ x : Vertex N, f x ^ 2) - 2 * c * (∑ x : Vertex N, f x) + vertexCount N * c ^ 2 := by
  simp_rw [sub_sq]
  rw [Finset.sum_add_distrib, Finset.sum_sub_distrib, sum_const_vertex]
  congr 1
  congr 1
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro x _
  ring

lemma sum_sq_sub_mean (N : Size) (f : Vertex N → ℝ) :
    (∑ x : Vertex N, (f x - spatialMean N f) ^ 2) =
      (∑ x : Vertex N, f x ^ 2) - vertexCount N * spatialMean N f ^ 2 := by
  rw [sum_sq_centered, sum_eq_vertexCount_mean N f]
  ring

lemma energy_sub_const (N : Size) (f : Vertex N → ℝ) (c : ℝ) :
    energy N (f - fun _ => c) = energy N f := by
  simp only [energy_edges, Pi.sub_apply]
  have h (a b : ℝ) : ((a - c) - (b - c)) ^ 2 = (a - b) ^ 2 := by ring
  simp only [h]

lemma poincare_zero_mean (N : Size) (f : Vertex N → ℝ) (hf : spatialMean N f = 0) :
    spectralGap N * (∑ x : Vertex N, f x ^ 2) ≤ energy N f := by
  have hsum := Finset.sum_le_sum (s := nonzeroFrequencies N)
    (f := fun k => spectralGap N * (cosineCoefficient N f k ^ 2 + sineCoefficient N f k ^ 2))
    (g := fun k => finiteEigenvalue N k * (cosineCoefficient N f k ^ 2 + sineCoefficient N f k ^ 2))
    (fun k hk => mul_le_mul_of_nonneg_right
      (spectralGap_le_eigenvalue N k (Finset.mem_erase.mp hk).1) (by positivity))
  rw [← Finset.mul_sum, finite_parseval, finite_energy_parseval,
    sum_eq_zero_of_mean_zero N f hf, zero_pow (by decide : 2 ≠ 0), sub_zero] at hsum
  apply (mul_le_mul_iff_right₀ (vertexCount_pos N)).mp
  nlinarith [hsum]

lemma poincare_variance (N : Size) (f : Vertex N → ℝ) :
    spectralGap N * ((∑ x : Vertex N, f x ^ 2) - vertexCount N * spatialMean N f ^ 2) ≤
      energy N f := by
  have hmean : spatialMean N (f - fun _ => spatialMean N f) = 0 := by
    rw [spatialMean_sub, spatialMean_const, sub_self]
  have h := poincare_zero_mean N (f - fun _ => spatialMean N f) hmean
  simpa only [Pi.sub_apply, sum_sq_sub_mean, energy_sub_const] using h

lemma square_mean_le_mean_square (N : Size) (f : Vertex N → ℝ) :
    spatialMean N f ^ 2 ≤ spatialMean N (fun x => f x ^ 2) := by
  have hnonneg : 0 ≤ ∑ x : Vertex N, (f x - spatialMean N f) ^ 2 :=
    Finset.sum_nonneg (fun _ _ => sq_nonneg _)
  rw [sum_sq_sub_mean] at hnonneg
  apply (le_div_iff₀ (vertexCount_pos N)).mpr
  nlinarith

end TorusCoverTime.Blocks.B
