import Solutions.Blocks.B.R7BarrierSummability

/-! B.11: the original all-center, all-integer-scale lower barrier has
vanishing normalized loop-window complement mass. No low-count or grid
estimate is left as an additional hypothesis. -/

noncomputable section
open MeasureTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

def r7LowerBarrierFailureMass (N : Size) (γ l r : ℝ) : ℝ≥0∞ :=
  r7LoopEventMass N (fun root => {z | ¬ r7LowerBarrier N root γ z}) l r

theorem r7LowerBarrier_compl_measurable (N : Size) (root : Vertex N) (γ : ℝ) :
    MeasurableSet {z | ¬ r7LowerBarrier N root γ z} := by
  rw [r7LowerBarrier_compl_eq]
  exact MeasurableSet.biUnion (r7CoarseIntegerScales N γ).countable_toSet
    (fun k _ => r7LowerBarrierFailure_measurable N root γ k)

theorem r7_global_lower_barrier_bound (hWalk : WalkModelRegular) (γ H : ℝ)
    (hγ : 0 < γ) (hγ1 : 16*γ < 1) (hH : 0 ≤ H) :
    ∃ c C : ℝ, 0 < c ∧ 0 < C ∧ ∀ᶠ N : Size in atTop, ∀ l r : ℝ,
      l ≤ r → phaseACenter N-H*timeScale N ≤ l → r ≤ phaseACenter N+H*timeScale N →
      r7LowerBarrierFailureMass N γ l r ≤
        ENNReal.ofReal (r7BarrierGlobalEnvelope (logSize N) γ c C) := by
  obtain ⟨c,C,hc,hC,hs⟩ := r7_lower_barrier_scale_bound hWalk γ H hγ hγ1 hH
  refine ⟨c,C,hc,hC,?_⟩
  filter_upwards [hs,blockB_logSize_tendsto.eventually_ge_atTop 1] with N hN hL
  intro l r hlr hlo hhi
  have hcard := r7_coarse_integer_scales_card N γ hL
  have henv := r7BarrierScaleEnvelope_nonneg (logSize N) γ c C hC.le
  unfold r7LowerBarrierFailureMass
  simp_rw [r7LowerBarrier_compl_eq]
  apply (r7LoopEventMass_biUnion_le N (r7CoarseIntegerScales N γ)
    (fun k root => r7LowerBarrierFailure N root γ k)
    (fun k _ root => r7LowerBarrierFailure_measurable N root γ k) l r).trans
  calc
    _ ≤ ∑ _k ∈ r7CoarseIntegerScales N γ,
        ENNReal.ofReal (r7BarrierScaleEnvelope (logSize N) γ c C) := by
      apply Finset.sum_le_sum
      intro k hk
      have hk' := (mem_r7CoarseIntegerScales N γ k).mp hk
      exact hN k l r hk'.1 hk'.2 hlr hlo hhi
    _ = ENNReal.ofReal (((r7CoarseIntegerScales N γ).card:ℝ)*r7BarrierScaleEnvelope (logSize N) γ c C) := by
      rw [Finset.sum_const,nsmul_eq_mul,ENNReal.ofReal_mul (Nat.cast_nonneg _),ENNReal.ofReal_natCast]
    _ ≤ _ := ENNReal.ofReal_le_ofReal (mul_le_mul_of_nonneg_right hcard henv)

theorem r7_global_lower_barrier_uniform (hWalk : WalkModelRegular) (γ H : ℝ)
    (hγ : 0 < γ) (hγ1 : 16*γ < 1) (hH : 0 ≤ H) :
    ∀ ε : ℝ, 0 < ε → ∀ᶠ N : Size in atTop, ∀ l r : ℝ,
      l ≤ r → phaseACenter N-H*timeScale N ≤ l → r ≤ phaseACenter N+H*timeScale N →
      r7LowerBarrierFailureMass N γ l r ≤ ENNReal.ofReal ε := by
  obtain ⟨c,C,hc,hC,hbound⟩ := r7_global_lower_barrier_bound hWalk γ H hγ hγ1 hH
  intro ε hε
  have ht := (r7_barrier_global_envelope_tendsto γ c C hγ hc).comp blockB_logSize_tendsto
  filter_upwards [hbound,ht.eventually_le_const hε] with N hN hsmall
  intro l r hlr hlo hhi
  exact (hN l r hlr hlo hhi).trans (ENNReal.ofReal_le_ofReal hsmall)

theorem r7_global_lower_barrier_tendsto (hWalk : WalkModelRegular) (γ H : ℝ)
    (hγ : 0 < γ) (hγ1 : 16*γ < 1) (hH : 0 ≤ H) (l r : Size → ℝ)
    (hwin : ∀ᶠ N : Size in atTop, l N ≤ r N ∧
      phaseACenter N-H*timeScale N ≤ l N ∧ r N ≤ phaseACenter N+H*timeScale N) :
    Tendsto (fun N => r7LowerBarrierFailureMass N γ (l N) (r N)) atTop (𝓝 0) := by
  obtain ⟨c,C,hc,hC,hbound⟩ := r7_global_lower_barrier_bound hWalk γ H hγ hγ1 hH
  have ht := ENNReal.tendsto_ofReal ((r7_barrier_global_envelope_tendsto γ c C hγ hc).comp blockB_logSize_tendsto)
  simp only [ENNReal.ofReal_zero] at ht
  apply tendsto_of_tendsto_of_tendsto_of_le_of_le' tendsto_const_nhds ht (Eventually.of_forall (fun _ => bot_le))
  filter_upwards [hbound,hwin] with N hN hw
  exact hN (l N) (r N) hw.1 hw.2.1 hw.2.2

end TorusCoverTime.Blocks.B
