import Solutions.Blocks.B.BernoulliExponential
import Mathlib.MeasureTheory.Integral.Bochner.Set

/-! B.16: a lower geometric tail gives an upper Laplace transform. The
proof integrates finite tail sums and passes only a scalar geometric series
to its limit; no exact geometric law or moment finiteness is assumed. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology BigOperators
namespace TorusCoverTime.Blocks.B

theorem finite_geometric_tail_sum_le (z : ℝ) (hz : 0 ≤ z) (hz1 : z ≤ 1) (n k : ℕ) :
    (1-z)*(∑ i ∈ Finset.range n, if i+1 ≤ k then z^i else 0) ≤ 1-z^k := by
  have hs : (∑ i ∈ Finset.range n, if i+1 ≤ k then z^i else 0) ≤
      ∑ i ∈ Finset.range k, z^i := by
    rw [← Finset.sum_filter]
    apply Finset.sum_le_sum_of_subset_of_nonneg
    · intro i hi
      have hh := (Finset.mem_filter.mp hi).2
      exact Finset.mem_range.mpr (by omega)
    · intro i _ _
      exact pow_nonneg hz i
  have hm := mul_le_mul_of_nonneg_left hs (sub_nonneg.mpr hz1)
  have he := geom_sum_mul_neg z k
  nlinarith

theorem geometric_tail_pow_integral_le {Ω : Type*} [MeasurableSpace Ω]
    (μ : Measure Ω) [IsProbabilityMeasure μ] (K : Ω → ℕ) (hK : Measurable K)
    (p r z : ℝ) (hp : 0 ≤ p) (hr : 0 < r) (hr1 : r ≤ 1)
    (hz : 0 ≤ z) (hz1 : z < 1)
    (htail : ∀ k : ℕ, p*(1-r)^k ≤ μ.real {ω | k+1 ≤ K ω}) :
    (∫ ω, z^(K ω) ∂μ) ≤ 1-p*(1-z)/(1-(1-r)*z) := by
  let E := fun i : ℕ => {ω | i+1 ≤ K ω}
  have hE (i : ℕ) : MeasurableSet (E i) := measurableSet_le measurable_const hK
  let f := fun i : ℕ => (E i).indicator (fun _ => z^i)
  have hf (i : ℕ) : Integrable (f i) μ := (integrable_const _).indicator (hE i)
  have hi (i : ℕ) : (∫ ω, f i ω ∂μ) = z^i*μ.real (E i) := by
    rw [show f i = (E i).indicator (fun _ => z^i) from rfl,integral_indicator (hE i)]
    simp only [setIntegral_const,smul_eq_mul,mul_comm]
  have hmeas : Measurable (fun ω => z^(K ω)) := (measurable_of_countable (fun k : ℕ => z^k)).comp hK
  have hpow : Integrable (fun ω => z^(K ω)) μ :=
    (integrable_const (1:ℝ)).mono' hmeas.aestronglyMeasurable (Eventually.of_forall fun ω => by
      rw [Real.norm_eq_abs,abs_of_nonneg (pow_nonneg hz _)]
      exact pow_le_one₀ hz hz1.le)
  have hpartial (n : ℕ) :
      p*(1-z)*(∑ i ∈ Finset.range n, (z*(1-r))^i) ≤ 1-∫ ω, z^(K ω) ∂μ := by
    have hpoint (ω : Ω) : (1-z)*(∑ i ∈ Finset.range n, f i ω) ≤ 1-z^(K ω) := by
      simpa only [f,E,indicator_apply,Set.mem_ofPred_eq] using
        finite_geometric_tail_sum_le z hz hz1.le n (K ω)
    have hint := integral_mono ((integrable_finsetSum _ fun i _ => hf i).const_mul (1-z))
      ((integrable_const (1:ℝ)).sub hpow) hpoint
    simp only [Pi.sub_apply] at hint
    rw [integral_const_mul,integral_finsetSum _ (fun i _ => hf i),
      integral_sub (integrable_const (1:ℝ)) hpow,integral_const] at hint
    simp only [probReal_univ,one_smul] at hint
    simp_rw [hi] at hint
    apply le_trans ?_ hint
    calc
      _ = (1-z)*∑ i ∈ Finset.range n, z^i*(p*(1-r)^i) := by
        rw [Finset.mul_sum,Finset.mul_sum]
        apply Finset.sum_congr rfl
        intro i _
        rw [mul_pow]
        ring
      _ ≤ _ := mul_le_mul_of_nonneg_left (Finset.sum_le_sum fun i _ =>
        mul_le_mul_of_nonneg_left (htail i) (pow_nonneg hz i)) (sub_nonneg.mpr hz1.le)
  have hgeom0 : 0 ≤ z*(1-r) := mul_nonneg hz (sub_nonneg.mpr hr1)
  have hgeom1 : z*(1-r) < 1 :=
    (mul_le_of_le_one_right hz (by linarith : 1-r ≤ 1)).trans_lt hz1
  have hlim := ((hasSum_geometric_of_lt_one hgeom0 hgeom1).tendsto_sum_nat).const_mul (p*(1-z))
  have hl := le_of_tendsto hlim (Eventually.of_forall hpartial)
  have he : p*(1-z)*(1-z*(1-r))⁻¹ = p*(1-z)/(1-(1-r)*z) := by ring
  rw [he] at hl
  linarith

theorem geometric_tail_laplace_le {Ω : Type*} [MeasurableSpace Ω]
    (μ : Measure Ω) [IsProbabilityMeasure μ] (K : Ω → ℕ) (hK : Measurable K)
    (p r h t : ℝ) (hp : 0 ≤ p) (hr : 0 < r) (hr1 : r ≤ 1) (hh : 0 < h) (ht : 0 ≤ t)
    (htail : ∀ k : ℕ, p*(1-r)^k ≤ μ.real {ω | k+1 ≤ K ω}) :
    (∫ ω, Real.exp (-t*(h*(K ω:ℝ))) ∂μ) ≤
      1-p*(1-Real.exp (-t*h))/(r+(1-r)*(1-Real.exp (-t*h))) := by
  by_cases ht0 : t = 0
  · subst t
    simp
  have htpos : 0 < t := lt_of_le_of_ne ht (Ne.symm ht0)
  have he : Real.exp (-t*h) < 1 := Real.exp_lt_one_iff.mpr (by nlinarith)
  have hbound := geometric_tail_pow_integral_le μ K hK p r (Real.exp (-t*h)) hp hr hr1
    (Real.exp_pos _).le he htail
  have hpow (ω : Ω) : Real.exp (-t*(h*(K ω:ℝ))) = Real.exp (-t*h)^(K ω) := by
    rw [← Real.exp_nat_mul]
    congr 1
    ring
  simp_rw [hpow]
  have hden : r+(1-r)*(1-Real.exp (-t*h)) = 1-(1-r)*Real.exp (-t*h) := by ring
  rw [hden]
  exact hbound

theorem geometric_laplace_envelope_le (p r h t : ℝ)
    (hp : 0 ≤ p) (hr : 0 < r) (hr1 : r ≤ 1) (hh : 0 < h) (ht : 0 ≤ t) :
    1-p*(1-Real.exp (-t*h))/(r+(1-r)*(1-Real.exp (-t*h))) ≤
      1-p+p*(r/h)/(r/h+t) := by
  let x := t*h
  let u := 1-Real.exp (-t*h)
  have hx : 0 ≤ x := mul_nonneg ht hh.le
  have hu : 0 ≤ u := sub_nonneg.mpr (Real.exp_le_one_iff.mpr (by nlinarith))
  have hxu : x/(1+x) ≤ u := by
    have hexp := Real.add_one_le_exp x
    have hpos : 0 < 1+x := by linarith
    have hinv : Real.exp (-x) ≤ 1/(1+x) := by
      rw [Real.exp_neg,inv_eq_one_div]
      exact one_div_le_one_div_of_le hpos (by linarith)
    change x/(1+x) ≤ 1-Real.exp (-t*h)
    rw [show -t*h = -x by dsimp [x]; ring]
    apply (div_le_iff₀ hpos).mpr
    have hm := (le_div_iff₀ hpos).mp hinv
    nlinarith
  have hd : 0 < r+(1-r)*u := add_pos_of_pos_of_nonneg hr (mul_nonneg (by linarith) hu)
  have hrx : 0 < r+x := by linarith
  have he : x/(r+x) ≤ u/(r+(1-r)*u) := by
    apply (div_le_div_iff₀ hrx hd).mpr
    have hxU := (div_le_iff₀ (by linarith : 0 < 1+x)).mp hxu
    have hm := mul_le_mul_of_nonneg_left hxU hr.le
    nlinarith
  have hm := mul_le_mul_of_nonneg_left he hp
  have hid : 1-p+p*(r/h)/(r/h+t) = 1-p*x/(r+x) := by
    dsimp [x]
    have hden : r/h+t ≠ 0 := ne_of_gt (add_pos_of_pos_of_nonneg (div_pos hr hh) ht)
    have hden' : r+t*h ≠ 0 := hrx.ne'
    field_simp
    ; ring
  rw [hid]
  change 1-p*u/(r+(1-r)*u) ≤ _
  simpa only [mul_div_assoc] using sub_le_sub_left hm 1

end TorusCoverTime.Blocks.B
