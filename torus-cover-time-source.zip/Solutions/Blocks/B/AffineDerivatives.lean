import Solutions.Blocks.B.SmoothDifference
import Mathlib.Algebra.Ring.Periodic

/-! Restricting smooth multipliers to coordinate lines preserves uniform derivative bounds. -/

noncomputable section
open Function
open scoped Topology ContDiff
namespace TorusCoverTime.Blocks.B

lemma iteratedDeriv_affine_line {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
    (F : E → ℂ) (hF : ContDiff ℝ ∞ F) (v e : E) (p : ℕ) (x : ℝ) :
    iteratedDeriv p (fun t => F (v + t • e)) x =
      iteratedFDeriv ℝ p F (v + x • e) (fun _ => e) := by
  let g : ℝ →L[ℝ] E := (ContinuousLinearMap.id ℝ ℝ).smulRight e
  let H : E → ℂ := fun w => F (v + w)
  have hH : ContDiff ℝ ∞ H := hF.comp (contDiff_const.add contDiff_id)
  change (iteratedFDeriv ℝ p (H ∘ g) x) (fun _ => (1 : ℝ)) = _
  rw [g.iteratedFDeriv_comp_right hH x (by exact_mod_cast (le_top : (p : ℕ∞) ≤ ⊤))]
  simp only [H, iteratedFDeriv_comp_add_left, ContinuousMultilinearMap.compContinuousLinearMap_apply,
    g, ContinuousLinearMap.smulRight_apply, ContinuousLinearMap.id_apply, one_smul]

lemma norm_iteratedDeriv_affine_line_le {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
    (F : E → ℂ) (hF : ContDiff ℝ ∞ F) (v e : E) (p : ℕ) (x : ℝ) :
    ‖iteratedDeriv p (fun t => F (v + t • e)) x‖ ≤
      ‖iteratedFDeriv ℝ p F (v + x • e)‖ * ‖e‖ ^ p := by
  rw [iteratedDeriv_affine_line F hF v e p x]
  simpa using (iteratedFDeriv ℝ p F (v + x • e)).le_opNorm (fun _ => e)

lemma periodic_iteratedDeriv (f : ℝ → ℂ) (T : ℝ) (hf : Periodic f T) (p : ℕ) :
    Periodic (iteratedDeriv p f) T := by
  intro x
  have heq : (fun t => f (t + T)) = f := funext hf
  have hd := congrFun (iteratedDeriv_comp_add_const p f T) x
  rw [heq] at hd
  exact hd.symm

end TorusCoverTime.Blocks.B
