import Solutions.Blocks.B.WindowResamplingBound

/-! Window resampling with an untouched exterior. Only the selected interior
durations need be short; exterior return times may be arbitrarily long. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

theorem shiftedWindowIntegral_add (G : ℝ → ℝ≥0∞) (l r e v : ℝ) :
    shiftedWindowIntegral G l r (e+v) = shiftedWindowIntegral G (l-e) (r-e) v := by
  apply lintegral_congr
  intro u
  have he : e+v+u ∈ Icc l r ↔ v+u ∈ Icc (l-e) (r-e) := by
    simp only [mem_Icc]
    constructor <;> rintro ⟨h1,h2⟩ <;> constructor <;> linarith
  simp only [he]

theorem parametrized_shiftedWindowIntegral_measurable {Ξ : Type*} [MeasurableSpace Ξ]
    (G : Ξ × ℝ → ℝ≥0∞) (hG : Measurable G) (E : Ξ → ℝ) (hE : Measurable E) (l r : ℝ) :
    Measurable (fun p : Ξ × ℝ => shiftedWindowIntegral (fun u => G (p.1,u)) l r (E p.1+p.2)) := by
  have hm : Measurable (fun z : (Ξ × ℝ) × ℝ =>
      if E z.1.1+z.1.2+z.2 ∈ Icc l r then G (z.1.1,z.2) else 0) :=
    (hG.comp (measurable_fst.fst.prodMk measurable_snd)).ite
      (measurableSet_Icc.preimage (((hE.comp measurable_fst.fst).add measurable_fst.snd).add measurable_snd))
      measurable_const
  exact hm.lintegral_prod_right'

theorem exterior_window_bad_mass_bound {Ω Ξ : Type*} [MeasurableSpace Ω] [MeasurableSpace Ξ]
    (μ : Measure Ω) [SFinite μ] (ν : Measure Ξ) [IsProbabilityMeasure ν]
    (V : Ω → ℝ) (hV : Measurable V) (hV0 : ∀ x, 0 ≤ V x)
    (E : Ξ → ℝ) (hE : Measurable E) (G : Ξ × ℝ → ℝ≥0∞) (hG : Measurable G)
    (hG1 : ∀ y u, G (y,u) ≤ 1) (l r d : ℝ)
    (hshort : (1 : ℝ≥0∞)/2 ≤ μ {x | V x ≤ d}) (B : Set Ω) (hB : MeasurableSet B) :
    (∫⁻ y, ∫⁻ x in B, shiftedWindowIntegral (fun u => G (y,u)) l r (E y+V x) ∂μ ∂ν) ≤
      2*μ B*(∫⁻ y, ∫⁻ x, shiftedWindowIntegral (fun u => G (y,u)) (l-d) (r+d) (E y+V x) ∂μ ∂ν) +
        ENNReal.ofReal (r-l)*μ {x | d < V x} := by
  have hm : Measurable (fun z : Ξ × Ω =>
      shiftedWindowIntegral (fun u => G (z.1,u)) (l-d) (r+d) (E z.1+V z.2)) :=
    (parametrized_shiftedWindowIntegral_measurable G hG E hE (l-d) (r+d)).comp
      (measurable_fst.prodMk (hV.comp measurable_snd))
  have hA : Measurable (fun y => ∫⁻ x, shiftedWindowIntegral (fun u => G (y,u))
      (l-d) (r+d) (E y+V x) ∂μ) := hm.lintegral_prod_right'
  calc
    _ ≤ ∫⁻ y, 2*μ B*(∫⁻ x, shiftedWindowIntegral (fun u => G (y,u))
        (l-d) (r+d) (E y+V x) ∂μ) + ENNReal.ofReal (r-l)*μ {x | d < V x} ∂ν := by
      apply lintegral_mono
      intro y
      have hh := resampling_bad_mass_bound μ
        (fun x => shiftedWindowIntegral (fun u => G (y,u)) l r (E y+V x))
        (fun x => shiftedWindowIntegral (fun u => G (y,u)) (l-d) (r+d) (E y+V x))
        B {x | V x ≤ d} hB (measurableSet_le hV measurable_const) hshort (ENNReal.ofReal (r-l))
        (fun x => shiftedWindowIntegral_le_length _ (hG1 y) l r (E y+V x)) (by
          intro x hx z hz
          simp only [shiftedWindowIntegral_add]
          have hc := shiftedWindowIntegral_enlarge (fun u => G (y,u)) (l-E y) (r-E y) d
            (V x) (V z) ⟨hV0 x,hx⟩ ⟨hV0 z,hz⟩
          convert hc using 1 <;> congr 1 <;> ring)
      have he : {x | V x ≤ d}ᶜ = {x | d < V x} := by ext x; simp
      simpa only [he] using hh
    _ = _ := by
      rw [lintegral_add_right _ measurable_const, lintegral_const_mul _ hA, lintegral_const,
        measure_univ, mul_one]

theorem exterior_window_recurrence {Ω Ξ : Type*} [MeasurableSpace Ω] [MeasurableSpace Ξ]
    (μ : Measure Ω) [SFinite μ] (ν : Measure Ξ) [IsProbabilityMeasure ν]
    (V : Ω → ℝ) (hV : Measurable V) (hV0 : ∀ x, 0 ≤ V x)
    (E : Ξ → ℝ) (hE : Measurable E) (G : Ξ × ℝ → ℝ≥0∞) (hG : Measurable G)
    (hG1 : ∀ y u, G (y,u) ≤ 1) (l r d : ℝ)
    (hshort : (1 : ℝ≥0∞)/2 ≤ μ {x | V x ≤ d}) (B : Set Ω) (hB : MeasurableSet B) :
    (∫⁻ y, ∫⁻ x, shiftedWindowIntegral (fun u => G (y,u)) l r (E y+V x) ∂μ ∂ν) ≤
      (∫⁻ y, ∫⁻ x in Bᶜ, shiftedWindowIntegral (fun u => G (y,u)) l r (E y+V x) ∂μ ∂ν) +
      2*μ B*(∫⁻ y, ∫⁻ x, shiftedWindowIntegral (fun u => G (y,u)) (l-d) (r+d) (E y+V x) ∂μ ∂ν) +
        ENNReal.ofReal (r-l)*μ {x | d < V x} := by
  let f := fun y x => shiftedWindowIntegral (fun u => G (y,u)) l r (E y+V x)
  have hm : Measurable (fun z : Ξ × Ω => f z.1 z.2) :=
    (parametrized_shiftedWindowIntegral_measurable G hG E hE l r).comp
      (measurable_fst.prodMk (hV.comp measurable_snd))
  have hs (y : Ξ) : (∫⁻ x, f y x ∂μ) = (∫⁻ x in B, f y x ∂μ)+(∫⁻ x in Bᶜ, f y x ∂μ) :=
    (lintegral_add_compl (f y) hB).symm
  have he : (∫⁻ y, ∫⁻ x, f y x ∂μ ∂ν) =
      (∫⁻ y, ∫⁻ x in B, f y x ∂μ ∂ν)+(∫⁻ y, ∫⁻ x in Bᶜ, f y x ∂μ ∂ν) := by
    simp_rw [hs]
    exact lintegral_add_left hm.lintegral_prod_right' _
  change (∫⁻ y, ∫⁻ x, f y x ∂μ ∂ν) ≤ _
  rw [he]
  have hb := exterior_window_bad_mass_bound μ ν V hV hV0 E hE G hG hG1 l r d hshort B hB
  calc
    _ ≤ (2*μ B*(∫⁻ y, ∫⁻ x, shiftedWindowIntegral (fun u => G (y,u)) (l-d) (r+d) (E y+V x) ∂μ ∂ν) +
        ENNReal.ofReal (r-l)*μ {x | d < V x}) + (∫⁻ y, ∫⁻ x in Bᶜ, f y x ∂μ ∂ν) := add_le_add hb le_rfl
    _ = _ := by dsimp only [f]; ac_rfl

end TorusCoverTime.Blocks.B
