import Solutions.Blocks.B.FourierOrthogonality
import Mathlib.Probability.Independence.InfinitePi
import Mathlib.Probability.Independence.Integration

/-! Fourier expectations for the discrete skeleton of the concrete walk. -/

noncomputable section
open MeasureTheory ProbabilityTheory
open scoped BigOperators ENNReal

namespace TorusCoverTime.Blocks.B

lemma finiteCharacter_zero (N : Size) (k : Vertex N) : finiteCharacter N k 0 = 1 := by
  simp [finiteCharacter]

lemma finiteCharacter_sum_to_prod (N : Size) (k : Vertex N) {ι : Type*}
    (s : Finset ι) (f : ι → Vertex N) :
    finiteCharacter N k (∑ i ∈ s, f i) = ∏ i ∈ s, finiteCharacter N k (f i) := by
  classical
  induction s using Finset.induction_on with
  | empty => simp [finiteCharacter_zero]
  | @insert a s ha ih => simp [ha, finiteCharacter_add, ih]

lemma integral_uniform_direction (N : Size) (k : Vertex N) :
    (∫ d : Fin 4, finiteCharacter N k (direction N d)
      ∂uniformOn (Set.univ : Set (Fin 4))) = (1 - finiteEigenvalue N k : ℝ) := by
  have hmeasure : uniformOn (Set.univ : Set (Fin 4)) =
      (4 : ℝ≥0∞)⁻¹ • Measure.count := by
    ext s
    simp [uniformOn_univ, div_eq_mul_inv, mul_comm]
  rw [hmeasure, integral_smul_measure, integral_count, finiteCharacter_direction_sum]
  norm_num
  ring

lemma integral_single_step_character (N : Size) (k : Vertex N) (j : ℕ) :
    (∫ ω : WalkSample, finiteCharacter N k (direction N (ω j).2) ∂walkLaw) =
      (1 - finiteEigenvalue N k : ℝ) := by
  have hmeas : Measurable (fun z : ℝ × Fin 4 => finiteCharacter N k (direction N z.2)) :=
    (measurable_of_finite (fun d : Fin 4 => finiteCharacter N k (direction N d))).comp
      measurable_snd
  have hmap := integral_map (μ := walkLaw) (measurable_pi_apply j).aemeasurable
    (f := fun z : ℝ × Fin 4 => finiteCharacter N k (direction N z.2))
    hmeas.aestronglyMeasurable
  rw [walkLaw, Measure.infinitePi_map_eval] at hmap
  rw [walkLaw, ← hmap, stepLaw,
    integral_fun_snd (fun d : Fin 4 => finiteCharacter N k (direction N d)),
    integral_uniform_direction]
  simp

lemma independent_step_characters (N : Size) (k : Vertex N) :
    iIndepFun (fun j : ℕ => fun ω : WalkSample =>
      finiteCharacter N k (direction N (ω j).2)) walkLaw := by
  exact iIndepFun_infinitePi (P := fun _ : ℕ => stepLaw)
    (X := fun _ => fun z : ℝ × Fin 4 => finiteCharacter N k (direction N z.2))
    (fun _ => (measurable_of_finite (fun d : Fin 4 =>
      finiteCharacter N k (direction N d))).comp measurable_snd)

lemma position_character_eq_prod (N : Size) (start k : Vertex N)
    (ω : WalkSample) (n : ℕ) :
    finiteCharacter N k (position N start ω n) = finiteCharacter N k start *
      ∏ j : Fin n, finiteCharacter N k (direction N (ω j).2) := by
  rw [position, finiteCharacter_add, finiteCharacter_sum_to_prod]
  congr 1
  exact (Fin.prod_univ_eq_prod_range _ _).symm

lemma integral_position_character (N : Size) (start k : Vertex N) (n : ℕ) :
    (∫ ω, finiteCharacter N k (position N start ω n) ∂walkLaw) =
      finiteCharacter N k start * ((1 - finiteEigenvalue N k : ℝ) : ℂ) ^ n := by
  simp_rw [position_character_eq_prod]
  rw [integral_const_mul]
  have hind := (independent_step_characters N k).precomp
    (show Function.Injective (fun j : Fin n => (j : ℕ)) from Fin.val_injective)
  rw [hind.integral_fun_prod_eq_prod_integral]
  · simp [integral_single_step_character]
  · intro j
    exact ((measurable_of_finite (finiteCharacter N k ∘ direction N)).comp
      (measurable_snd.comp (measurable_pi_apply (j : ℕ)))).aestronglyMeasurable

end TorusCoverTime.Blocks.B
