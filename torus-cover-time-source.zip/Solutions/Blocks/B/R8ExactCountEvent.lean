import Solutions.Blocks.B.R8ModerateCountMarginal
import Solutions.Blocks.B.R7LoopEventMass

/-! Exact count slices are genuine events of the same path and time. They
embed into the low-count marginal at their square-root count value. -/
noncomputable section
open MeasureTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

def r8ExactCountEvent (N : Size) (x root : Vertex N) (γ q : ℝ) (m : ℕ) : Set (WalkSample × ℝ) :=
  {z | (N.val:ℝ)*Real.exp (-((logSize N)^(16*γ))/2) ≤ periodicDistance x root ∧
    completedTraversalCount N (torusDisk N x (Real.exp (q+q^γ)))
      (torusDisk N x (Real.exp (q+2*q^γ))) root z.1 z.2 = m}

theorem r8ExactCountEvent_measurable (N : Size) (x root : Vertex N) (γ q : ℝ) (m : ℕ) :
    MeasurableSet (r8ExactCountEvent N x root γ q m) :=
  (MeasurableSet.const _).inter ((completedTraversalCount_measurable N _ _ root) (measurableSet_singleton m))

def r8ExactCountMass (N : Size) (x : Vertex N) (γ q : ℝ) (m : ℕ) (l r : ℝ) : ℝ≥0∞ :=
  r7LoopEventMass N (fun root => r8ExactCountEvent N x root γ q m) l r

theorem r8_exact_count_mass_le_marginal (N : Size) (x : Vertex N) (γ q : ℝ) (m : ℕ) (l r : ℝ) :
    r8ExactCountMass N x γ q m l r ≤ r7IntegratedLowCount N x γ q (Real.sqrt (q^γ*(m:ℝ))) l r := by
  have hh := r7LoopEventMass_mono_ae N (fun root => r8ExactCountEvent N x root γ q m)
    (fun root => {z | (N.val:ℝ)*Real.exp (-((logSize N)^(16*γ))/2) ≤ periodicDistance x root ∧
      r7TraversalRadius N x root γ q z ≤ Real.sqrt (q^γ*(m:ℝ))})
    (fun root => Eventually.of_forall (by
      intro ω t ht h
      refine ⟨h.1,?_⟩
      simp only [r7TraversalRadius,h.2,le_refl])) l r
  change r7LoopEventMass N (fun root => r8ExactCountEvent N x root γ q m) l r ≤ _
  refine hh.trans_eq ?_
  unfold r7LoopEventMass r7LoopEventTest r7IntegratedLowCount
  simp only [mem_ofPred_eq,and_assoc]

end TorusCoverTime.Blocks.B
