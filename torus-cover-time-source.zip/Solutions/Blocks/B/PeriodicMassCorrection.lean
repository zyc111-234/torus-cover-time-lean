import Solutions.Blocks.B.PeriodicBindingLS

/-! Exact independent decomposition after the periodic zero-mass constraint.
The binding data retain the mass coordinate, for later random-envelope bounds. -/
noncomputable section
open MeasureTheory ProbabilityTheory Classical
open scoped BigOperators
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

def normalizedDirichletMass (N : Size) (root : Vertex N) (D : Finset (Vertex N))
    (ξ : FiniteFieldSample N) : ℝ := dirichletMass N root D ξ/Real.sqrt (dirichletMassVariance N root D)

def periodicBindingData (N : Size) (root : Vertex N) (D : Finset (Vertex N))
    (ξ : FiniteFieldSample N) : Option (Vertex N) → ℝ
  | none => normalizedDirichletMass N root D ξ
  | some x => harmonicBindingLS N root D ξ x

def periodicBindingDataMap (N : Size) (root : Vertex N) (D : Finset (Vertex N)) :
    Option (Vertex N) → FiniteFieldSample N →L[ℝ] ℝ
  | none => (1/Real.sqrt (dirichletMassVariance N root D)) • dirichletMassMap N root D
  | some x => harmonicBindingLSMap N root D x

def correctedBindingLS (N : Size) (root : Vertex N) (D : Finset (Vertex N))
    (ξ : FiniteFieldSample N) (x : Vertex N) : ℝ :=
  harmonicBindingLS N root D ξ x+(dirichletMassSlope N root D x-1/vertexCount N)*dirichletMass N root D ξ

theorem periodicBindingDataMap_apply (N : Size) (root : Vertex N) (D : Finset (Vertex N))
    (i : Option (Vertex N)) (ξ : FiniteFieldSample N) :
    periodicBindingDataMap N root D i ξ=periodicBindingData N root D ξ i := by
  cases i with
  | none => simp [periodicBindingDataMap,periodicBindingData,normalizedDirichletMass,dirichletMassMap_apply,div_eq_mul_inv,mul_comm]
  | some x => exact harmonicBindingLSMap_apply N root D x ξ

@[fun_prop] theorem periodicBindingData_measurable (N : Size) (root : Vertex N) (D : Finset (Vertex N)) :
    Measurable (periodicBindingData N root D) := by
  apply measurable_pi_lambda
  intro i
  have h : Measurable (fun ξ => periodicBindingDataMap N root D i ξ) :=
    (periodicBindingDataMap N root D i).continuous.measurable
  simpa only [periodicBindingDataMap_apply] using h

theorem periodicBindingData_gaussian (N : Size) (root : Vertex N) (D : Finset (Vertex N))
    (i : Option (Vertex N)) : HasGaussianLaw (fun ξ => periodicBindingData N root D ξ i) (finiteFieldLaw N) := by
  simpa only [id_eq,periodicBindingDataMap_apply] using
    (Blocks.D.finiteFieldSample_gaussian N).map_fun (periodicBindingDataMap N root D i)

theorem periodicBindingData_mean (N : Size) (root : Vertex N) (D : Finset (Vertex N))
    (i : Option (Vertex N)) : (∫ ξ, periodicBindingData N root D ξ i ∂finiteFieldLaw N)=0 := by
  cases i with
  | none => change (∫ ξ, dirichletMass N root D ξ/_ ∂finiteFieldLaw N)=0
            rw [integral_div,dirichletMass_mean,zero_div]
  | some x => exact harmonicBindingLS_mean N root D x

theorem normalizedDirichletMass_variance (N : Size) (root : Vertex N) (D : Finset (Vertex N))
    (hroot : root∉D) (hV : 0<dirichletMassVariance N root D) :
    Var[normalizedDirichletMass N root D;finiteFieldLaw N]=1 := by
  unfold normalizedDirichletMass
  simp_rw [div_eq_mul_inv]
  rw [variance_mul_const,inv_pow,Real.sq_sqrt hV.le,dirichletMass_variance N root D hroot]
  exact mul_inv_cancel₀ hV.ne'

theorem massZeroFieldLS_gaussian (N : Size) (root : Vertex N) (D : Finset (Vertex N)) (x : Vertex N) :
    HasGaussianLaw (fun ξ => massZeroFieldLS N root D ξ x) (finiteFieldLaw N) := by
  simpa only [id_eq,massZeroCoordinateMap_apply] using
    (Blocks.D.finiteFieldSample_gaussian N).map_fun (massZeroCoordinateMap N root D x)

theorem massZeroFieldLS_cov_binding (N : Size) (root : Vertex N) (D : Finset (Vertex N))
    (hroot : root∉D) (x y : Vertex N) :
    cov[fun ξ => massZeroFieldLS N root D ξ x,fun ξ => harmonicBindingLS N root D ξ y;finiteFieldLaw N]=0 := by
  have hi : IndepFun (fun ξ => massZeroFieldLS N root D ξ x) (fun ξ => harmonicBindingLS N root D ξ y) (finiteFieldLaw N) :=
    (dirichletFieldLS_indep_harmonicBinding N root D hroot).comp
      (show Measurable (fun f : Vertex N → ℝ => f x-dirichletMassSlope N root D x*(∑ z, f z)) by fun_prop)
      (measurable_pi_apply y)
  exact hi.covariance_eq_zero (massZeroFieldLS_gaussian N root D x).memLp_two
    (harmonicBindingLS_gaussian N root D y).memLp_two

theorem massZeroFieldLS_indep_bindingData (N : Size) (root : Vertex N) (D : Finset (Vertex N))
    (hroot : root∉D) (hV : 0<dirichletMassVariance N root D) :
    IndepFun (massZeroFieldLS N root D) (periodicBindingData N root D) (finiteFieldLaw N) := by
  let A := ContinuousLinearMap.pi (fun x => massZeroCoordinateMap N root D x)
  let B := ContinuousLinearMap.pi (fun i => periodicBindingDataMap N root D i)
  have hj : HasGaussianLaw (fun ξ => (massZeroFieldLS N root D ξ,periodicBindingData N root D ξ)) (finiteFieldLaw N) := by
    apply ((Blocks.D.finiteFieldSample_gaussian N).map_fun (A.prod B)).congr
    exact Filter.Eventually.of_forall (fun ξ => by
      apply Prod.ext <;> funext z <;>
        simp only [A,B,id_eq,ContinuousLinearMap.prod_apply,ContinuousLinearMap.pi_apply,
          massZeroCoordinateMap_apply,periodicBindingDataMap_apply])
  apply hj.indepFun_of_covariance_eval
  intro x i
  cases i with
  | none => change cov[fun ξ => massZeroFieldLS N root D ξ x,fun ξ => dirichletMass N root D ξ/_;finiteFieldLaw N]=0
            rw [covariance_fun_div_right,massZeroFieldLS_cov_mass N root D hroot hV,zero_div]
  | some y => exact massZeroFieldLS_cov_binding N root D hroot x y

theorem periodicFieldLS_mass_corrected (N : Size) (root : Vertex N) (D : Finset (Vertex N))
    (ξ : FiniteFieldSample N) (x : Vertex N) :
    periodicFieldLS N ξ x=massZeroFieldLS N root D ξ x+correctedBindingLS N root D ξ x := by
  rw [periodicFieldLS_decomposition N root D ξ x]
  unfold massZeroFieldLS correctedBindingLS
  ring

theorem correctedBindingLS_of_data (N : Size) (root : Vertex N) (D : Finset (Vertex N))
    (hV : 0<dirichletMassVariance N root D) (ξ : FiniteFieldSample N) (x : Vertex N) :
    correctedBindingLS N root D ξ x=periodicBindingData N root D ξ (some x)+
      (dirichletMassProfile N root D x-Real.sqrt (dirichletMassVariance N root D)/vertexCount N)*
        periodicBindingData N root D ξ none := by
  simp only [correctedBindingLS,periodicBindingData,normalizedDirichletMass,dirichletMassSlope,dirichletMassProfile]
  have hs := Real.sq_sqrt hV.le
  have hs0 := (Real.sqrt_pos.mpr hV).ne'
  field_simp [hV.ne',hs0]
  rw [hs]
  ring

theorem massZeroFieldLS_indep_correctedBinding (N : Size) (root : Vertex N) (D : Finset (Vertex N))
    (hroot : root∉D) (hV : 0<dirichletMassVariance N root D) :
    IndepFun (massZeroFieldLS N root D) (correctedBindingLS N root D) (finiteFieldLaw N) := by
  have he : correctedBindingLS N root D=(fun b : Option (Vertex N) → ℝ => fun x =>
      b (some x)+(dirichletMassProfile N root D x-Real.sqrt (dirichletMassVariance N root D)/vertexCount N)*b none) ∘
        periodicBindingData N root D :=
    funext (fun ξ => funext (fun x => correctedBindingLS_of_data N root D hV ξ x))
  rw [he]
  exact (massZeroFieldLS_indep_bindingData N root D hroot hV).comp measurable_id (by fun_prop)

end TorusCoverTime.Blocks.B
