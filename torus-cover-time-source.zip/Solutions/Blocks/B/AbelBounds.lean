import Solutions.Blocks.B.FourierOrthogonality
import Mathlib.Algebra.BigOperators.Module
import Mathlib.Algebra.Field.GeomSum

/-! Finite summation-by-parts bounds for decreasing Fourier row weights. -/

noncomputable section
open scoped BigOperators
namespace TorusCoverTime.Blocks.B

lemma sum_successive_drops (f : ℕ → ℝ) (n : ℕ) :
    (∑ j ∈ Finset.range n, (f j - f (j + 1))) = f 0 - f n := by
  induction n with
  | zero => simp
  | succ n ih => rw [Finset.sum_range_succ, ih]; ring

lemma norm_sum_antitone_weights (f : ℕ → ℝ) (z : ℕ → ℂ) (B : ℝ)
    (hf : ∀ j, 0 ≤ f j) (hanti : Antitone f) (hB : 0 ≤ B)
    (hpartial : ∀ n, ‖∑ j ∈ Finset.range n, z j‖ ≤ B) (n : ℕ) :
    ‖∑ j ∈ Finset.range n, f j • z j‖ ≤ f 0 * B := by
  cases n with
  | zero => simpa using mul_nonneg (hf 0) hB
  | succ n =>
    rw [Finset.sum_range_by_parts]
    simp only [Nat.add_sub_cancel]
    apply (norm_sub_le _ _).trans
    have hfirst : ‖f n • (∑ j ∈ Finset.range (n + 1), z j)‖ ≤ f n * B := by
      rw [norm_smul, Real.norm_eq_abs, abs_of_nonneg (hf n)]
      exact mul_le_mul_of_nonneg_left (hpartial (n + 1)) (hf n)
    have hdrops : ‖∑ j ∈ Finset.range n,
        (f (j + 1) - f j) • (∑ i ∈ Finset.range (j + 1), z i)‖ ≤ (f 0 - f n) * B := by
      calc
        _ ≤ ∑ j ∈ Finset.range n, ‖(f (j + 1) - f j) •
            (∑ i ∈ Finset.range (j + 1), z i)‖ := norm_sum_le _ _
        _ ≤ ∑ j ∈ Finset.range n, (f j - f (j + 1)) * B := by
          apply Finset.sum_le_sum
          intro j _
          rw [norm_smul, Real.norm_eq_abs,
            abs_of_nonpos (sub_nonpos.mpr (hanti (Nat.le_succ j))), neg_sub]
          exact mul_le_mul_of_nonneg_left (hpartial (j + 1))
            (sub_nonneg.mpr (hanti (Nat.le_succ j)))
        _ = _ := by rw [← Finset.sum_mul, sum_successive_drops]
    linarith

lemma norm_unit_geometric_sum (z : ℂ) (hz : ‖z‖ = 1) (hz1 : z ≠ 1) (n : ℕ) :
    ‖∑ j ∈ Finset.range n, z ^ j‖ ≤ 2 / ‖z - 1‖ := by
  rw [geom_sum_eq hz1, norm_div]
  apply div_le_div_of_nonneg_right _ (norm_nonneg _)
  have h := norm_sub_le (z ^ n) 1
  simpa only [norm_pow, hz, one_pow, norm_one, one_add_one_eq_two] using h

lemma norm_antitone_geometric_sum (f : ℕ → ℝ) (z : ℂ)
    (hf : ∀ j, 0 ≤ f j) (hanti : Antitone f) (hz : ‖z‖ = 1) (hz1 : z ≠ 1) (n : ℕ) :
    ‖∑ j ∈ Finset.range n, (f j : ℂ) * z ^ j‖ ≤ 2 * f 0 / ‖z - 1‖ := by
  have h := norm_sum_antitone_weights f (fun j => z ^ j) (2 / ‖z - 1‖)
    hf hanti (by positivity) (norm_unit_geometric_sum z hz hz1) n
  calc
    _ ≤ f 0 * (2 / ‖z - 1‖) := by simpa only [Complex.real_smul] using h
    _ = _ := by ring

lemma norm_antitone_geometric_shift (f : ℕ → ℝ) (z : ℂ)
    (hf : ∀ j, 0 ≤ f j) (hanti : Antitone f) (hz : ‖z‖ = 1) (hz1 : z ≠ 1) (n : ℕ) :
    ‖∑ j ∈ Finset.range n, (f (j + 1) : ℂ) * z ^ (j + 1)‖ ≤ 2 * f 0 / ‖z - 1‖ := by
  have h := norm_antitone_geometric_sum (fun j => f (j + 1)) z
    (fun j => hf (j + 1)) (fun i j hij => hanti (Nat.add_le_add_right hij 1)) hz hz1 n
  have hid : (∑ j ∈ Finset.range n, (f (j + 1) : ℂ) * z ^ (j + 1)) =
      z * (∑ j ∈ Finset.range n, (f (j + 1) : ℂ) * z ^ j) := by
    rw [Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro j _
    rw [pow_succ]
    ring
  rw [hid, norm_mul, hz, one_mul]
  apply h.trans
  exact div_le_div_of_nonneg_right
    (mul_le_mul_of_nonneg_left (hanti (by omega : 0 ≤ 0 + 1)) (by norm_num)) (norm_nonneg _)

end TorusCoverTime.Blocks.B
