import Solutions.Blocks.B.ShellImageRootSum
import Solutions.Blocks.B.HarmonicShellCenter

/-! The actual coarea image integral over a physical window, after exact root
averaging, shell normalization and the sharp Gaussian harmonic tail. -/

noncomputable section
open MeasureTheory Filter Set Classical
open scoped ENNReal NNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

def shellTimeCoordinate (N : Size) (s : ℝ) : ℝ :=
  (s-phaseACenter N-vertexCount N*greenDiagonal N)/timeScale N

theorem shellTimeCoordinate_energy (N : Size) (s : ℝ) :
    D.shellEnergyParameter N (shellTimeCoordinate N s) = 2*s/vertexCount N := by
  unfold D.shellEnergyParameter shellTimeCoordinate
  rw [div_mul_cancel₀ _ (timeScale_pos N).ne']
  ring

theorem r7HarmonicImageTest_shell (N : Size) (c : Vertex N) (q v Δ l r s : ℝ)
    (hs : s ∈ Icc l (r+(64*g)*vertexCount N*logSize N/2))
    (z : FiniteFieldSample N × Bool) :
    r7HarmonicImageTest N c q v Δ l r (D.shellCoareaImage N (s,z)) =
      harmonicShellTest N c q (v+Δ+2*coarseProbeRadialConstant)
        (z.1,D.shellAmplitude N (2*s/vertexCount N) z.1,z.2) := by
  unfold r7HarmonicImageTest harmonicShellTest harmonicImageRadius
    harmonicShiftedSquareImage D.shellCoareaImage
  simp only [hs,true_and]

theorem r7HarmonicImageTest_normalized (N : Size) (c : Vertex N) (q v Δ l r s : ℝ)
    (hs : s ∈ Icc l (r+(64*g)*vertexCount N*logSize N/2)) :
    (∫⁻ z, r7HarmonicImageTest N c q v Δ l r (D.shellCoareaImage N (s,z)) ∂
      D.normalizedAveragedShell N (2*s/vertexCount N)) =
        harmonicShellMass N (shellTimeCoordinate N s) c q (v+Δ+2*coarseProbeRadialConstant) := by
  simp_rw [r7HarmonicImageTest_shell N c q v Δ l r s hs]
  unfold harmonicShellMass shellCountObservable
  rw [shellTimeCoordinate_energy]

def r7ShellTailBudget (N : Size) (H c₀ C q v Δ : ℝ) : ℝ≥0∞ :=
  ENNReal.ofReal (4*C*Real.exp (-(max (harmonicExtremeCenter N-v-Δ-
    2*coarseProbeRadialConstant-harmonicShellTailShift H*Real.log (logSize N)) 0)^2 /
      (logSize N-q+2*harmonicVarianceErrorConstant))) +
  ENNReal.ofReal (C*vertexCount N*logSize N^2*Real.exp (-c₀*logSize N*Real.log (logSize N)))

theorem r7_shell_image_window_bound (H : ℝ) (hH : 0 ≤ H) :
    ∃ c₀ C : ℝ, 0 < c₀ ∧ 0 < C ∧ ∀ᶠ N : Size in atTop,
      ∀ c : Vertex N, ∀ q v Δ l r : ℝ,
        0 ≤ q → q ≤ logSize N → 2*(Real.exp (q+1)+1) < N.val →
        (∀ s ∈ Icc l (r+(64*g)*vertexCount N*logSize N/2), |shellTimeCoordinate N s| ≤ H) →
        (∑ root, ∫⁻ z, r7HarmonicImageTest N c q v Δ l r z ∂D.rootedShellImageMeasure N root) ≤
          ENNReal.ofReal (r+(64*g)*vertexCount N*logSize N/2-l)*2*r7ShellTailBudget N H c₀ C q v Δ := by
  obtain ⟨c₀,C,hc,hC,hbound⟩ := harmonic_shell_tail_uniform H hH
  refine ⟨c₀,C,hc,hC,?_⟩
  filter_upwards [hbound,averagedShell_mass_bound_uniform H hH] with N hN hm
  intro c q v Δ l r hq hqL hsmall hwindow
  apply rootedShellImage_window_bound N _ (r7HarmonicImageTest_measurable N c q v Δ l r)
  · intro z hz
    simp only [r7HarmonicImageTest]
    rw [if_neg (fun h => hz h.1)]
  · intro s hs _
    have hθ := hwindow s hs
    have hmass := hm (shellTimeCoordinate N s) hθ
    have htail := hN (shellTimeCoordinate N s) hθ c q
      (v+Δ+2*coarseProbeRadialConstant) hq hqL hsmall
    have ht : harmonicShellMass N (shellTimeCoordinate N s) c q
        (v+Δ+2*coarseProbeRadialConstant) ≤ r7ShellTailBudget N H c₀ C q v Δ := by
      convert htail using 1 <;> unfold r7ShellTailBudget <;> congr 4 <;> ring
    rw [shellTimeCoordinate_energy] at hmass
    rw [averagedShell_lintegral_normalize N _ hmass.1 hmass.2.1,
      r7HarmonicImageTest_normalized N c q v Δ l r s hs,← mul_assoc]
    exact mul_le_mul' hmass.2.2 ht

def farRootLowHarmonicMass (N : Size) (c : Vertex N) (γ q a l r : ℝ) : ℝ≥0∞ :=
  ∑ root : Vertex N, if (N.val:ℝ)*Real.exp (-((logSize N)^(16*γ))/2) ≤ periodicDistance c root then
    lowHarmonicLoopWindowMass N c root q a l r else 0

theorem r7_low_harmonic_root_sum (γ : ℝ) (hγ : 0 < γ) (hγ1 : 16*γ < 1) :
    ∀ᶠ N : Size in atTop, ∀ c : Vertex N, ∀ q v Δ l r : ℝ,
      (logSize N)^(16*γ) ≤ q → q ≤ logSize N-(logSize N)^(16*γ) → q ≤ v → 0 ≤ Δ →
      ENNReal.ofReal (coarseProbeProbabilityConstant/Real.sqrt (logSize N))*
        farRootLowHarmonicMass N c γ q (v+Δ) l r ≤
          ∑ root, ∫⁻ z, r7HarmonicImageTest N c q v Δ l r z ∂D.rootedShellImageMeasure N root := by
  filter_upwards [r7_low_harmonic_coarea_transfer γ hγ hγ1] with N hN
  intro c q v Δ l r hq hqL hqv hΔ
  rw [farRootLowHarmonicMass,Finset.mul_sum]
  apply Finset.sum_le_sum
  intro root _
  split_ifs with hfar
  · exact hN root c q hq hqL hfar v Δ l r hqv hΔ
  · simp only [mul_zero]
    exact bot_le

theorem r7_low_harmonic_physical_bound (γ H : ℝ) (hγ : 0 < γ) (hγ1 : 16*γ < 1) (hH : 0 ≤ H) :
    ∃ c₀ C : ℝ, 0 < c₀ ∧ 0 < C ∧ ∀ᶠ N : Size in atTop,
      ∀ c : Vertex N, ∀ q v Δ l r : ℝ,
        (logSize N)^(16*γ) ≤ q → q ≤ logSize N-(logSize N)^(16*γ) → q ≤ v → 0 ≤ Δ →
        (∀ s ∈ Icc l (r+(64*g)*vertexCount N*logSize N/2), |shellTimeCoordinate N s| ≤ H) →
        farRootLowHarmonicMass N c γ q (v+Δ) l r ≤
          (ENNReal.ofReal (coarseProbeProbabilityConstant/Real.sqrt (logSize N)))⁻¹ *
            (ENNReal.ofReal (r+(64*g)*vertexCount N*logSize N/2-l)*2*r7ShellTailBudget N H c₀ C q v Δ) := by
  obtain ⟨c₀,C,hc,hC,himage⟩ := r7_shell_image_window_bound H hH
  have hQ := (tendsto_rpow_atTop (by positivity : 0 < 16*γ)).comp blockB_logSize_tendsto
  refine ⟨c₀,C,hc,hC,?_⟩
  filter_upwards [himage,r7_low_harmonic_root_sum γ hγ hγ1,r6_disk_radius_embedding γ hγ,
    hQ.eventually_ge_atTop 1] with N hi hr he hlarge
  intro c q v Δ l r hq hqL hqv hΔ hwindow
  have hq1 : 1 ≤ q := hlarge.trans hq
  have hq0 : 0 ≤ q := by linarith
  have hqL' : q ≤ logSize N := hqL.trans (sub_le_self _ (Real.rpow_nonneg (logSize_pos N).le _))
  have hsmall : 2*(Real.exp (q+1)+1) < N.val := by
    have hh := he q hq0 hqL
    have hw : 1 ≤ q^γ := Real.one_le_rpow hq1 hγ.le
    have hx := Real.exp_le_exp.mpr (show q+1 ≤ q+2*q^γ by linarith)
    linarith
  have hh := (hr c q v Δ l r hq hqL hqv hΔ).trans (hi c q v Δ l r hq0 hqL' hsmall hwindow)
  have hp : ENNReal.ofReal (coarseProbeProbabilityConstant/Real.sqrt (logSize N)) ≠ 0 :=
    ENNReal.ofReal_ne_zero_iff.mpr (div_pos coarseProbeProbabilityConstant_pos (Real.sqrt_pos.mpr (logSize_pos N)))
  have hm := mul_le_mul' (le_refl ((ENNReal.ofReal (coarseProbeProbabilityConstant/Real.sqrt (logSize N)))⁻¹)) hh
  simpa only [← mul_assoc,ENNReal.inv_mul_cancel hp ENNReal.ofReal_ne_top,one_mul] using hm

end TorusCoverTime.Blocks.B
