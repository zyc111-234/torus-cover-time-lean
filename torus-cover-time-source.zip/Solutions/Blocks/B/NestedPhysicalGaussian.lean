import Solutions.Blocks.B.NestedPhysicalExterior
import Solutions.Blocks.B.R8NestedExteriorGaussian
import Solutions.Blocks.B.NestedExteriorCount

/-! Weighted Gaussian lower tail for the actual inner count, not merely the finite-record proxy. -/
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B


theorem r8_nested_physical_exterior_gaussian (hWalk : WalkModelRegular) (γ : ℝ)
    (hγ : 0 < γ) (hγ1 : γ < 1) :
    ∀ᶠ N : Size in atTop, ∀ c root : Vertex N, ∀ m : ℕ, ∀ w : Fin (2*m) → Vertex N, ∀ q : ℝ,
      (logSize N)^(16*γ) ≤ q → q ≤ logSize N-(logSize N)^(16*γ) →
      root ∉ torusDisk N c (Real.exp (q+2*q^γ)) →
      walkLaw {ω | adaptiveExitWord N (alternatingDomain N (torusDisk N c (Real.exp (q+q^γ)))
        (torusDisk N c (Real.exp (q+2*q^γ)))) root (2*m) ω = w} ≠ 0 →
      ∀ E : TraversalExteriorSample m × ℝ → ℝ≥0∞, Measurable E → (∀ y u, E (y,u) ≤ 1) →
      ∀ v l r : ℝ, 0 ≤ v → Real.sqrt ((m:ℝ)*q^γ) ≤ 10*logSize N →
      (logSize N)^(5*γ) ≤ Real.sqrt ((m:ℝ)*q^γ)-v →
      let Q := torusDisk N c (Real.exp (q+q^γ))
      let O := torusDisk N c (Real.exp (q+2*q^γ))
      let I := torusDisk N c (Real.exp (r8NestedScale γ q+(r8NestedScale γ q)^γ))
      let J := torusDisk N c (Real.exp (r8NestedScale γ q+2*(r8NestedScale γ q)^γ))
      let d := (m:ℝ)*Real.exp (2*logSize N-(logSize N)^(16*γ))
      nestedPhysicalExteriorSlice N Q O I J root m w ((r8NestedScale γ q)^γ) (v^2) E l r ≤
        2*ENNReal.ofReal (Real.exp (-((Real.sqrt ((m:ℝ)*q^γ)-v)^2/(24*q^γ))))*
          conditionalTraversalExteriorSlice N Q O root m w univ E (l-d) (r+d) +
        ENNReal.ofReal (r-l)*ENNReal.ofReal (Real.exp (-Real.exp ((logSize N)^(16*γ)/2))) := by
  obtain ⟨q0,hq0⟩ := eventually_atTop.mp
    ((r8_nested_record_entry_ae γ hγ hγ1).and (r8_nested_scale_geometry γ hγ hγ1))
  have hQ := (tendsto_rpow_atTop (by positivity : 0 < 16*γ)).comp blockB_logSize_tendsto
  filter_upwards [r8_nested_exterior_gaussian hWalk γ hγ hγ1,hQ.eventually_ge_atTop q0] with N hwin hbase
  intro c root m w q hq hqL hr hw E hE hE1 v l r hv hvL hgap
  have hs := hq0 q (hbase.trans hq)
  have hq0' := (Real.rpow_nonneg (logSize_pos N).le (16*γ)).trans hq
  have hl0 : 0 ≤ r8NestedScale γ q := le_trans zero_le_one hs.2.2.1
  have hi := r8_nested_disk_inclusions N c γ q hq0' hl0 hs.2.2.2.2.2.2.2.2.2.2.2
  have hb := nestedPhysicalExteriorSlice_le_records N _ _ _ _ hi.2.2
    (torusDisk_nonempty N c _ (Real.exp_pos _)) hi.1 (torusDisk_nonempty N c _ (Real.exp_pos _))
    (fun x hx => hi.2.2 (hi.2.1 hx)) root hr m w (hs.1 N c root hr) _ (v^2)
    (Real.rpow_nonneg hl0 γ) E l r
  exact hb.trans (hwin c root m w q hq hqL hr hw E hE hE1 v l r hv hvL hgap)


end TorusCoverTime.Blocks.B
