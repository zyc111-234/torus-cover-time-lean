import Solutions.Blocks.B.BT8CountedCoarea
import Solutions.Blocks.B.BT8ShellLimit

noncomputable section
open MeasureTheory Filter Set Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

theorem bt8ImageTest_shell (N : Size) (γ u l r s : ℝ)
    (hs : s∈Icc l (r+(64*g)*vertexCount N*logSize N/2)) (z : FiniteFieldSample N × Bool) :
    bt8ImageTest N γ u l r (D.shellCoareaImage N (s,z))=
      shellCountObservable N (shellTimeCoordinate N s) (bt8ShellTest N γ u) z := by
  simp only [bt8ImageTest,D.shellCoareaImage,hs,if_true,shellCountObservable,bt8ShellTest,
    harmonicShiftedSquareImage,shellTimeCoordinate_energy]
  rfl

theorem bt8_shell_image_window_bound (γ u H : ℝ) (hH : 0≤H) :
    ∀ᶠ N : Size in atTop, ∀ l r : ℝ,
      (∀ s∈Icc l (r+(64*g)*vertexCount N*logSize N/2), |shellTimeCoordinate N s|≤H) →
      (∑ root, ∫⁻ y, bt8ImageTest N γ u l r y ∂D.rootedShellImageMeasure N root)≤
        ENNReal.ofReal (r+(64*g)*vertexCount N*logSize N/2-l)*2*
          shellCountWindow N H (fun _ => bt8ShellTest N γ u) := by
  filter_upwards [averagedShell_mass_bound_uniform H hH] with N hm
  intro l r hwindow
  apply rootedShellImage_window_bound N _ (bt8ImageTest_measurable N γ u l r)
  · intro y hy; exact if_neg hy
  · intro s hs _
    have hθ := hwindow s hs
    have hmass := hm (shellTimeCoordinate N s) hθ
    rw [shellTimeCoordinate_energy] at hmass
    rw [averagedShell_lintegral_normalize N _ hmass.1 hmass.2.1,← mul_assoc]
    apply mul_le_mul' hmass.2.2
    simp_rw [bt8ImageTest_shell N γ u l r s hs]
    rw [← shellTimeCoordinate_energy N s]
    exact le_iSup (fun θ : {θ : ℝ // |θ|≤H} =>
      ∫⁻ z, shellCountObservable N θ.1 (bt8ShellTest N γ u) z ∂D.normalizedAveragedShell N (D.shellEnergyParameter N θ.1))
      ⟨shellTimeCoordinate N s,hθ⟩

theorem bt8_good_count_bound (γ u H : ℝ) (hγ : 0<γ) (hγhi : 32*γ<1/10) (hH : 0≤H) :
    ∀ᶠ N : Size in atTop, ∀ l r : ℝ,
      phaseACenter N-H*timeScale N≤l → r≤phaseACenter N+H*timeScale N →
      bt8GoodCountMass N γ u l r≤
        ENNReal.ofReal (2*(2*H+32)*Real.sqrt (logSize N)/coarseProbeProbabilityConstant)*
          shellCountWindow N (r7ShellWindowRadius H) (fun _ => bt8ShellTest N γ u) := by
  filter_upwards [bt8_counted_coarea γ hγ hγhi,
    bt8_shell_image_window_bound γ u (r7ShellWindowRadius H) (r7ShellWindowRadius_nonneg H hH),
    blockB_logSize_tendsto.eventually_ge_atTop 1] with N hc hs hL
  intro l r hlo hhi
  let p := ENNReal.ofReal (coarseProbeProbabilityConstant/Real.sqrt (logSize N))
  have hp : p≠0 := ENNReal.ofReal_ne_zero_iff.mpr
    (div_pos coarseProbeProbabilityConstant_pos (Real.sqrt_pos.mpr (logSize_pos N)))
  have hsum := Finset.sum_le_sum (fun root (_ : root∈(Finset.univ:Finset (Vertex N))) => hc root u l r)
  rw [← Finset.mul_sum] at hsum
  have hh := hsum.trans (hs l r (central_physical_shell_window N H l r hH hL hlo hhi))
  have hnorm := mul_le_mul' (le_refl ((ENNReal.ofReal (timeScale N))⁻¹*p⁻¹)) hh
  have hcancel : (ENNReal.ofReal (timeScale N))⁻¹*p⁻¹*
      (p*∑ root, ∫⁻ a, ∑ x, bt8SourceWeight N root x γ u l r a ∂D.rootedLoopMeasure N root)=
      bt8GoodCountMass N γ u l r := by
    rw [bt8GoodCountMass]
    simp only [mul_assoc,← mul_assoc p⁻¹ p,ENNReal.inv_mul_cancel hp ENNReal.ofReal_ne_top,one_mul]
  change _≤_ at hnorm
  rw [hcancel] at hnorm
  have hlen := ENNReal.ofReal_le_ofReal (central_image_window_length N H l r hlo hhi)
  refine hnorm.trans ((mul_le_mul' le_rfl (mul_le_mul' (mul_le_mul' hlen le_rfl) le_rfl)).trans_eq ?_)
  have ht0 : ENNReal.ofReal (timeScale N)≠0 := ENNReal.ofReal_ne_zero_iff.mpr (timeScale_pos N)
  have hinv : p⁻¹=ENNReal.ofReal (Real.sqrt (logSize N)/coarseProbeProbabilityConstant) := by
    dsimp [p]
    rw [← ENNReal.ofReal_inv_of_pos (div_pos coarseProbeProbabilityConstant_pos (Real.sqrt_pos.mpr (logSize_pos N))),inv_div]
  rw [hinv,ENNReal.ofReal_mul (by positivity : 0≤2*H+32)]
  calc
    _ = ((ENNReal.ofReal (timeScale N))⁻¹*ENNReal.ofReal (timeScale N))*
        (2*ENNReal.ofReal (2*H+32)*ENNReal.ofReal (Real.sqrt (logSize N)/coarseProbeProbabilityConstant))*
          shellCountWindow N (r7ShellWindowRadius H) (fun _ => bt8ShellTest N γ u) := by ac_rfl
    _ = _ := by
      rw [ENNReal.inv_mul_cancel ht0 ENNReal.ofReal_ne_top,one_mul,
        show (2:ℝ≥0∞)=ENNReal.ofReal (2:ℝ) by norm_num,
        ← ENNReal.ofReal_mul (by norm_num : (0:ℝ)≤2),
        ← ENNReal.ofReal_mul (by positivity : 0≤2*(2*H+32))]
      congr 2
      ring

end TorusCoverTime.Blocks.B
