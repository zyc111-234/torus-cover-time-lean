import Solutions.Blocks.B.R7PerturbedGeometry
import Solutions.Blocks.B.OutwardRecordLaws

/-! The R6 duration remainder for the enlarged disk is proved by a radius
comparison, keeping the original physical duration scale. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

theorem r7_perturbed_outer_comparison (q h : ℝ) (hh : Real.log 4 ≤ h) :
    Real.exp (q+2*h) ≤ r7PerturbedOuter q h ∧
      r7PerturbedOuter q h ≤ 2*Real.exp (q+2*h) := by
  have hh0 := (Real.log_nonneg (by norm_num : (1:ℝ) ≤ 4)).trans hh
  have he4 : (4:ℝ) ≤ Real.exp (2*h) := by
    have he := Real.exp_le_exp.mpr (show Real.log 4 ≤ 2*h by linarith)
    simpa only [Real.exp_log (by norm_num : (0:ℝ) < 4)] using he
  have he := mul_le_mul_of_nonneg_left he4 (Real.exp_pos q).le
  rw [← Real.exp_add] at he
  dsimp only [r7PerturbedOuter]
  exact ⟨by linarith [Real.exp_pos q],by linarith [Real.exp_pos q]⟩

theorem r7_perturbed_endpoint_lower (γ : ℝ) (hγ : 0 < γ) (hγ1 : γ < 1) :
    ∀ᶠ q : ℝ in atTop, ∀ N : Size, ∀ c a b : Vertex N,
      2*(r7PerturbedOuter q (q^γ)+1) < N.val →
      |periodicDistance a c-r7PerturbedInner q (q^γ)| ≤ 2 →
      diskExteriorNeighbor N c (r7PerturbedOuter q (q^γ)) b →
      ENNReal.ofReal (diskExitLowerConstant*(r7PerturbedOuter q (q^γ))^(-(diskExitPower:ℝ))) ≤
        walkLaw (exitsThrough N (torusDisk N c (r7PerturbedOuter q (q^γ))) a b) := by
  filter_upwards [r6_oscillation_rate_geometry γ hγ,
    r7_perturbed_entrance_support γ hγ hγ1,
    r7_perturbed_parameter_geometry γ hγ hγ1] with q hs hg hp
  intro N c a b hsmall ha hb
  have hR := (r7_perturbed_outer_comparison q (q^γ) hp.1).1
  have hL : 0 < diskGreenInnerScale := by linarith [diskGreenInnerScale_ge_four]
  have hpow : 1 ≤ diskOscillationScale^(diskOscillationSteps (q^γ)) :=
    one_le_pow₀ (by linarith [diskOscillationScale_ge_two])
  have hsub : periodicDistance a c ≤ r7PerturbedOuter q (q^γ)/(12*diskGreenInnerScale) := by
    calc
      _ ≤ 2*Real.exp (q+q^γ) := ((mem_torusDisk N c a _).mp ((hg N c).1 a ha).2.1).le
      _ ≤ _ := hs.2.2
      _ ≤ Real.exp (q+2*q^γ)/(24*diskGreenInnerScale) := div_le_self (by positivity) hpow
      _ ≤ r7PerturbedOuter q (q^γ)/(24*diskGreenInnerScale) := div_le_div_of_nonneg_right hR (by positivity)
      _ ≤ _ := div_le_div_of_nonneg_left (r7PerturbedOuter_pos q (q^γ)).le (by positivity) (by linarith)
  exact disk_exit_interior_probability_lower N c _ (hs.1.trans hR) hsmall a b hsub hb

theorem r7_perturbed_disk_radius_embedding (γ : ℝ) (hγ : 0 < γ) :
    ∀ᶠ N : Size in atTop, ∀ q : ℝ, 0 ≤ q → q ≤ logSize N-(logSize N)^(16*γ) →
      2*(r7PerturbedOuter q (q^γ)+1) < N.val := by
  have hQ := (tendsto_rpow_atTop (by positivity : 0 < 16*γ)).comp blockB_logSize_tendsto
  filter_upwards [blockB_logSize_tendsto.eventually_ge_atTop (Real.log 16),
    blockB_logSize_tendsto.eventually
      (power_eventually_le_power 2 γ (16*γ) (1/2) (by linarith) (by norm_num)),
    hQ.eventually_ge_atTop (2*Real.log 16)] with N hL16 hpow hQ16
  intro q hq hqL
  change 2*Real.log 16 ≤ (logSize N)^(16*γ) at hQ16
  have hL := (logSize_pos N).le
  have hqL' : q ≤ logSize N := hqL.trans (sub_le_self _ (Real.rpow_nonneg hL _))
  have hqpow := Real.rpow_le_rpow hq hqL' hγ.le
  have hr : Real.exp (q+2*q^γ) ≤ Real.exp (logSize N)/16 := by
    calc
      _ ≤ Real.exp (logSize N-Real.log 16) := Real.exp_le_exp.mpr (by linarith)
      _ = _ := by rw [Real.exp_sub,Real.exp_log (by norm_num : (0:ℝ) < 16)]
  have he : Real.exp q ≤ Real.exp (q+2*q^γ) :=
    Real.exp_le_exp.mpr (by linarith [Real.rpow_nonneg hq γ])
  have h16 : (16:ℝ) ≤ Real.exp (logSize N) := by
    simpa only [Real.exp_log (by norm_num : (0:ℝ) < 16)] using Real.exp_le_exp.mpr hL16
  have hexp : Real.exp (logSize N) = (N.val:ℝ) :=
    Real.exp_log (by exact_mod_cast (show 0 < N.val by have := N.property; omega))
  dsimp only [r7PerturbedOuter]
  rw [hexp] at hr h16
  linarith

theorem doubled_radius_duration_bound (R R' C C' d : ℝ) (hR : 1 ≤ R) (hR' : 0 < R')
    (hcomp : R' ≤ 2*R) (hC : 0 < C) (hCC : C ≤ C') (hcoef : C*2^C ≤ C') (hd : 0 ≤ d) :
    C*R'^C*Real.exp (-(1/8)*d/R'^2) ≤ C'*R^C'*Real.exp (-(1/32)*d/R^2) := by
  have hR0 : 0 < R := by linarith
  have hC' : 0 < C' := hC.trans_le hCC
  have hpref : C*R'^C ≤ C'*R^C' := by
    calc
      _ ≤ C*(2*R)^C := mul_le_mul_of_nonneg_left (Real.rpow_le_rpow hR'.le hcomp hC.le) hC.le
      _ = (C*2^C)*R^C := by rw [Real.mul_rpow (by norm_num : (0:ℝ) ≤ 2) hR0.le]; ring
      _ ≤ C'*R^C' := mul_le_mul hcoef (Real.rpow_le_rpow_of_exponent_le hR hCC)
        (Real.rpow_nonneg hR0.le _) hC'.le
  have hratio : (1/32)*d/R^2 ≤ (1/8)*d/R'^2 := by
    apply (div_le_div_iff₀ (sq_pos_of_pos hR0) (sq_pos_of_pos hR')).mpr
    have hsq : R'^2 ≤ 4*R^2 := by nlinarith
    nlinarith [mul_le_mul_of_nonneg_left hsq hd]
  exact mul_le_mul hpref (Real.exp_le_exp.mpr (by
    simpa only [neg_mul,neg_div] using neg_le_neg hratio)) (Real.exp_pos _).le (by positivity)

theorem r7_perturbed_coarse_duration (hWalk : WalkModelRegular) (γ : ℝ)
    (hγ : 0 < γ) (hγ1 : γ < 1) :
    ∀ᶠ N : Size in atTop, ∀ c : Vertex N, ∀ m : ℕ, ∀ a b : Fin m → Vertex N, ∀ q : ℝ,
      (logSize N)^(16*γ) ≤ q → q ≤ logSize N-(logSize N)^(16*γ) →
      (m:ℝ) ≤ (logSize N)^4+1 →
      (∀ i, |periodicDistance (a i) c-r7PerturbedInner q (q^γ)| ≤ 2) →
      (∀ i, diskExteriorNeighbor N c (r7PerturbedOuter q (q^γ)) (b i)) →
      exactExitProductLaw N (torusDisk N c (r7PerturbedOuter q (q^γ))) m a b
        {ω | ∃ i, Real.exp (2*logSize N-(logSize N)^(16*γ)) <
          finiteExitDuration N (torusDisk N c (r7PerturbedOuter q (q^γ))) (a i) (ω i)} ≤
        ENNReal.ofReal (Real.exp (-Real.exp ((logSize N)^(16*γ)/2))) := by
  let C := max 1 (max (9/diskExitLowerConstant) ((diskExitPower:ℝ)+2))
  let C' := max (C*2^C) C
  have hC : 0 < C := lt_of_lt_of_le (by norm_num : (0:ℝ) < 1) (le_max_left _ _)
  have hC' : 0 < C' := hC.trans_le (le_max_right _ _)
  have hc : (0:ℝ) < 1/32 := by norm_num
  obtain ⟨qE,hqE⟩ := eventually_atTop.mp (r7_perturbed_endpoint_lower γ hγ hγ1)
  obtain ⟨qG,hqG⟩ := eventually_atTop.mp (r7_perturbed_parameter_geometry γ hγ hγ1)
  have hQ := (tendsto_rpow_atTop (by positivity : 0 < 16*γ)).comp blockB_logSize_tendsto
  filter_upwards [r7_perturbed_disk_radius_embedding γ hγ,
    hQ.eventually_ge_atTop (max 0 (max qE qG)),
    blockB_logSize_tendsto.eventually (r6_duration_prefactor_superexponential γ C' (1/32) hγ hγ1.le hC' hc)]
      with N hsmall hQbase hscalar
  intro c m a b q hq hqL hm ha hb
  have hq0 : 0 ≤ q := (le_max_left _ _).trans (hQbase.trans hq)
  have hqe : qE ≤ q := (le_max_left _ _).trans ((le_max_right _ _).trans (hQbase.trans hq))
  have hqg : qG ≤ q := (le_max_right _ _).trans ((le_max_right _ _).trans (hQbase.trans hq))
  let R := Real.exp (q+2*q^γ)
  let R' := r7PerturbedOuter q (q^γ)
  let d := Real.exp (2*logSize N-(logSize N)^(16*γ))
  have hR : 1 ≤ R := Real.one_le_exp_iff.mpr (by positivity)
  have hcmp := r7_perturbed_outer_comparison q (q^γ) (hqG q hqg).1
  have hR' : 1 ≤ R' := hR.trans hcmp.1
  have hexit (i : Fin m) := hqE q hqe N c (a i) (b i) (hsmall q hq0 hqL) (ha i) (hb i)
  have hpos (i : Fin m) : walkLaw (exitsThrough N (torusDisk N c R') (a i) (b i)) ≠ 0 :=
    ((ENNReal.ofReal_pos.mpr (mul_pos diskExitLowerConstant_pos
      (Real.rpow_pos_of_pos (r7PerturbedOuter_pos q (q^γ)) _))).trans_le (hexit i)).ne'
  have htail (i : Fin m) : exactExitLaw N (torusDisk N c R') (a i) (b i)
      {ω | d < finiteExitDuration N (torusDisk N c R') (a i) ω} ≤
        ENNReal.ofReal (C'*R^C'*Real.exp (-(1/32)*d/R^2)) := by
    have ht := r6_disk_conditioned_tail_constants hWalk N c R' hR' (hsmall q hq0 hqL)
      (a i) (b i) d diskExitLowerConstant diskExitPower (1/8) C (Real.exp_pos _).le
      diskExitLowerConstant_pos ((le_max_left _ _).trans (le_max_right _ _))
      ((le_max_right _ _).trans (le_max_right _ _)) (by norm_num) (hexit i)
    exact ht.trans (ENNReal.ofReal_le_ofReal (doubled_radius_duration_bound R R' C C' d hR
      (r7PerturbedOuter_pos q (q^γ)) hcmp.2 hC (le_max_right _ _) (le_max_left _ _) (Real.exp_pos _).le))
  have hu := exactExit_duration_union_bound N (torusDisk N c R') m a b hpos d
    (ENNReal.ofReal (C'*R^C'*Real.exp (-(1/32)*d/R^2))) htail
  apply hu.trans
  rw [← ENNReal.ofReal_natCast m,← ENNReal.ofReal_mul (Nat.cast_nonneg m)]
  apply ENNReal.ofReal_le_ofReal
  have hdiv : (m:ℝ)*(C'*R^C'*Real.exp (-(1/32)*d/R^2)) ≤
      C'*(m:ℝ)*R^C'/(1/32:ℝ)^m*Real.exp (-(1/32)*d/R^2) := by
    have hp : (1/32:ℝ)^m ≤ 1 := pow_le_one₀ (by norm_num) (by norm_num)
    have hn : 0 ≤ C'*(m:ℝ)*R^C'*Real.exp (-(1/32)*d/R^2) := by positivity
    have ht := mul_le_mul_of_nonneg_left hp hn
    have hd := (le_div_iff₀ (pow_pos hc m)).mpr (by simpa only [mul_one] using ht)
    calc
      _ = C'*(m:ℝ)*R^C'*Real.exp (-(1/32)*d/R^2) := by ring
      _ ≤ (C'*(m:ℝ)*R^C'*Real.exp (-(1/32)*d/R^2))/(1/32:ℝ)^m := hd
      _ = _ := by ring
  exact hdiv.trans (hscalar q m hq0 hqL hm)

end TorusCoverTime.Blocks.B
