import Solutions.Blocks.B.R8PairMarginalClosure
import Solutions.Blocks.B.R8PreparationGoodEvent

/-! Retain the scalar lower and upper range required by B.20 in each
actual slice. Membership in the finite count support alone does not imply it. -/
noncomputable section
open MeasureTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

def r8MarginalPairRange (N : Size) (γ q : ℝ) (p : ℕ × ℕ) : Prop :=
  q ≤ Real.sqrt (q^γ*(p.1:ℝ)) ∧ Real.sqrt (q^γ*(p.1:ℝ)) ≤ 10*logSize N

def r8MarginalDeviationSlice (N : Size) (c root : Vertex N) (γ q U : ℝ) (p : ℕ × ℕ) :
    Set (WalkSample × ℝ) :=
  {z | z ∈ r8ModerateDeviationSlice N c root γ q U p ∧ r8MarginalPairRange N γ q p}

theorem r8MarginalDeviationSlice_measurable (N : Size) (c root : Vertex N) (γ q U : ℝ) (p : ℕ × ℕ) :
    MeasurableSet (r8MarginalDeviationSlice N c root γ q U p) :=
  (r8ModerateDeviationSlice_measurable N c root γ q U p).inter (MeasurableSet.const _)

theorem r8_prepared_marginal_slice_cover (γ : ℝ) (hγ : 0 < γ) (hγ1 : γ < 1) :
    ∀ᶠ N : Size in atTop, ∀ c root : Vertex N, ∀ k ∈ r8InteriorIntegerScales N γ, ∀ U : ℝ,
      ∀ z : WalkSample × ℝ, r8PreparationGood N root γ U z →
      2*((N.val:ℝ)*Real.exp (-((logSize N)^(16*γ))/2)) ≤ periodicDistance c root →
      z ∈ r8DeviationEvent N c root γ k U →
      ∃ p ∈ r8CountPairs (logSize N), z ∈ r8MarginalDeviationSlice N c root γ k U p := by
  filter_upwards [r8_prepared_deviation_finite_cover γ hγ hγ1,
    r8_barrier_implies_marginal_range γ hγ] with N hcover hlower
  intro c root k hk U z hgood hfar hdev
  obtain ⟨p,hp,hz⟩ := hcover c root k hk U z hgood hfar hdev
  have hk' : k ∈ r7CoarseIntegerScales N γ := (Finset.mem_filter.mp hk).1
  have hkq := (mem_r7CoarseIntegerScales N γ k).mp hk'
  have he := (r8_count_pair_radii N c root γ k p z hz.2.2.1).1
  have hlo := hlower c root k hk' z hgood.1 hfar
  have hfar' : (N.val:ℝ)*Real.exp (-((logSize N)^(16*γ))/2) ≤ periodicDistance c root := by
    have hR : 0 ≤ (N.val:ℝ)*Real.exp (-((logSize N)^(16*γ))/2) := by positivity
    linarith
  have hhi := (r8HighCountFailure_compl_iff N root γ U z).mp hgood.2 k hkq.1 hkq.2 c hfar' hdev.1
  exact ⟨p,hp,hz,by simpa only [he] using hlo,by simpa only [he] using hhi⟩

theorem r8_marginal_slice_le_actual_pair (N : Size) (c : Vertex N) (γ q U l r : ℝ) (p : ℕ × ℕ) :
    r7LoopEventMass N (fun root => r8MarginalDeviationSlice N c root γ q U p) l r ≤
      r8PairIntegratedWindow N c γ q U p.1 p.2 l r := by
  rw [r8PairIntegratedWindow_eq_actual]
  apply r7LoopEventMass_mono_ae
  intro root
  exact Eventually.of_forall (by
    intro ω t ht hz
    have hR : 0 ≤ (N.val:ℝ)*Real.exp (-((logSize N)^(16*γ))/2) := by positivity
    exact ⟨by linarith [hz.1.1],hz.1.2.2.1,hz.1.2.1⟩)

theorem r8_marginal_slice_empty (N : Size) (c : Vertex N) (γ q U l r : ℝ) (p : ℕ × ℕ)
    (hp : ¬r8MarginalPairRange N γ q p) :
    r7LoopEventMass N (fun root => r8MarginalDeviationSlice N c root γ q U p) l r = 0 := by
  have he (root : Vertex N) : r8MarginalDeviationSlice N c root γ q U p = ∅ := by
    ext z
    simp only [r8MarginalDeviationSlice,mem_ofPred_eq,hp,and_false,mem_empty_iff_false]
  simp only [r7LoopEventMass,r7LoopEventTest,he,mem_empty_iff_false,false_and,if_false,
    lintegral_zero,Finset.sum_const_zero,mul_zero]

theorem r8_marginal_slice_bound (hWalk : WalkModelRegular) (γ U H : ℝ)
    (hγ : 0 < γ) (hγ1 : 16*γ < 1) (hU : 0 ≤ U) (hH : 0 ≤ H) :
    ∃ a C : ℝ, 0 < a ∧ 0 < C ∧ ∀ᶠ N : Size in atTop, ∀ c : Vertex N,
      ∀ k ∈ r8InteriorIntegerScales N γ, ∀ p ∈ r8CountPairs (logSize N), ∀ l r : ℝ,
      l ≤ r → phaseACenter N-H*timeScale N ≤ l → r ≤ phaseACenter N+H*timeScale N →
      r7LoopEventMass N (fun root => r8MarginalDeviationSlice N c root γ k U p) l r ≤
        ENNReal.ofReal (r8PairFinalEnvelope (logSize N) γ H a C) := by
  obtain ⟨a,C,ha,hC,hpair⟩ := r8_pair_marginal_closure hWalk γ U H hγ hγ1 hU hH
  refine ⟨a,C,ha,hC,?_⟩
  filter_upwards [hpair] with N hN
  intro c k hk p hp l r hlr hlo hhi
  by_cases h : r8MarginalPairRange N γ k p
  · have hk' := (mem_r8InteriorIntegerScales N γ k).mp hk
    exact (r8_marginal_slice_le_actual_pair N c γ k U l r p).trans
      (hN c p hp k l r hk'.1 hk'.2 h.1 h.2 hlr hlo hhi)
  · rw [r8_marginal_slice_empty N c γ k U l r p h]
    exact bot_le

end TorusCoverTime.Blocks.B
