import Solutions.Blocks.B.R7PerturbedWords
import Solutions.Blocks.B.R7ActualWordRecurrence

/-! Enlarged physical-window recurrence for the actual perturbed annulus. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

theorem r7_perturbed_actual_word_recurrence (hWalk : WalkModelRegular) (γ : ℝ) (hγ : 0 < γ) (hγ1 : γ < 1) :
    ∀ᶠ N : Size in atTop, ∀ c root : Vertex N, ∀ m : ℕ, ∀ w : Fin (2*m) → Vertex N, ∀ q : ℝ,
      (logSize N)^(16*γ) ≤ q → q ≤ logSize N-(logSize N)^(16*γ) → (m:ℝ) ≤ (logSize N)^4+1 →
      root ∉ torusDisk N c (r7PerturbedOuter q (q^γ)) →
      walkLaw {ω | adaptiveExitWord N (alternatingDomain N (torusDisk N c (r7PerturbedInner q (q^γ)))
        (torusDisk N c (r7PerturbedOuter q (q^γ)))) root (2*m) ω = w} ≠ 0 →
      ∀ v Δ : ℝ, 0 ≤ v → (m:ℝ)*r7PerturbedWidth q (q^γ) ≤ v^2 → 0 ≤ Δ →
      2*r7PerturbedMeanConstant*Real.exp (-r7MeanExponent*q^γ)*v ≤ Δ → ∀ l r : ℝ,
      let I := torusDisk N c (r7PerturbedInner q (q^γ))
      let O := torusDisk N c (r7PerturbedOuter q (q^γ))
      let d := (m:ℝ)*Real.exp (2*logSize N-(logSize N)^(16*γ))
      conditionalTraversalSlice N I O root m w (fun _ => 1) l r ≤
        conditionalTraversalSlice N I O root m w (lowOutwardRecordTest m (r7WordHighOccupation N c root m w q v Δ)) l r +
        2*ENNReal.ofReal (2*Real.exp (-(r7PerturbedConcentrationConstant/4)*Δ^2/q^γ)) *
          conditionalTraversalSlice N I O root m w (fun _ => 1) (l-d) (r+d) +
        ENNReal.ofReal (r-l)*ENNReal.ofReal (Real.exp (-Real.exp ((logSize N)^(16*γ)/2))) := by
  obtain ⟨q0,hq0⟩ := eventually_atTop.mp ((r7_perturbed_positive_word_upper hWalk γ hγ hγ1).and (r7_perturbed_annulus_geometry γ hγ hγ1))
  have hQ := (tendsto_rpow_atTop (by positivity : 0 < 16*γ)).comp blockB_logSize_tendsto
  filter_upwards [r7_perturbed_positive_word_duration hWalk γ hγ hγ1,r7_perturbed_disk_radius_embedding γ hγ,
    hQ.eventually_ge_atTop q0] with N htail hsmall hqbase
  intro c root m w q hq hqL hm hr hw v Δ hv hmv hΔ hlo l r
  dsimp only
  have hq0' : 0 ≤ q := (Real.rpow_nonneg (logSize_pos N).le _).trans hq
  have hI := torusDisk_nonempty N c (r7PerturbedInner q (q^γ)) (hq0 q (hqbase.trans hq)).2.1
  have := traversalWordOutwardLaw_probability N (torusDisk N c (r7PerturbedInner q (q^γ)))
    (torusDisk N c (r7PerturbedOuter q (q^γ))) root hI hr m w hw
  have hbad := (hq0 q (hqbase.trans hq)).1 N c root m w hr (hsmall q hq0' hqL) hw v Δ hv hmv hΔ hlo
  have hb : traversalWordOutwardLaw N (torusDisk N c (r7PerturbedInner q (q^γ)))
      (torusDisk N c (r7PerturbedOuter q (q^γ))) root m w (r7WordHighOccupation N c root m w q v Δ) ≤
        ENNReal.ofReal (2*Real.exp (-(r7PerturbedConcentrationConstant/4)*Δ^2/q^γ)) :=
    (ENNReal.le_ofReal_iff_toReal_le (measure_ne_top _ _) (by positivity)).mpr hbad
  exact actual_word_window_recurrence N _ _ root hI hr m w hw _
    (r7WordHighOccupation_measurable N c root m w q v Δ) l r _ _ _ hb
    (htail c root m w q hq hqL hm hr hw)
    (r6_superexponential_error_le_half _ (Real.rpow_nonneg (logSize_pos N).le _))

end TorusCoverTime.Blocks.B

