import Solutions.Blocks.B.TraversalExteriorSlice

/-! A conditional physical window for an arbitrary original path-time test. -/
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B


def physicalWordWindow (N : Size) (I O : Finset (Vertex N)) (root : Vertex N) (m : ℕ)
    (w : Fin (2*m) → Vertex N) (F : WalkSample × ℝ → ℝ≥0∞) (l r : ℝ) : ℝ≥0∞ :=
  ∫⁻ ω, (∫⁻ t in Ioi (adaptiveExitTime N (alternatingDomain N I O) root (2*m) ω),
    if t < adaptiveExitTime N (alternatingDomain N I O) root (2*m+1) ω ∧
      walk N root ω t = root ∧ t ∈ Icc l r then F (ω,t) else 0)
    ∂walkLaw[|{ω | adaptiveExitWord N (alternatingDomain N I O) root (2*m) ω = w}]

theorem physicalWordWindow_mono (N : Size) (I O : Finset (Vertex N)) (root : Vertex N)
    (m : ℕ) (w : Fin (2*m) → Vertex N) (F G : WalkSample × ℝ → ℝ≥0∞)
    (hFG : ∀ z, F z ≤ G z) (l r : ℝ) :
    physicalWordWindow N I O root m w F l r ≤ physicalWordWindow N I O root m w G l r := by
  apply lintegral_mono
  intro ω
  apply lintegral_mono
  intro t
  dsimp only
  split_ifs
  · exact hFG _
  · rfl

theorem physicalWordWindow_congr_ae (N : Size) (I O : Finset (Vertex N)) (root : Vertex N)
    (m : ℕ) (w : Fin (2*m) → Vertex N) (F G : WalkSample × ℝ → ℝ≥0∞)
    (hFG : ∀ᵐ ω ∂walkLaw[|{ω | adaptiveExitWord N (alternatingDomain N I O) root (2*m) ω = w}],
      ∀ t, adaptiveExitTime N (alternatingDomain N I O) root (2*m) ω ≤ t → F (ω,t) = G (ω,t))
    (l r : ℝ) :
    physicalWordWindow N I O root m w F l r = physicalWordWindow N I O root m w G l r := by
  apply lintegral_congr_ae
  filter_upwards [hFG] with ω hω
  apply lintegral_congr_ae
  filter_upwards [ae_restrict_mem (measurableSet_Ioi
    (a := adaptiveExitTime N (alternatingDomain N I O) root (2*m) ω))] with t ht
  split_ifs
  · exact hω t ht.le
  · rfl

theorem physicalWordWindow_mono_window (N : Size) (I O : Finset (Vertex N)) (root : Vertex N)
    (m : ℕ) (w : Fin (2*m) → Vertex N) (F : WalkSample × ℝ → ℝ≥0∞)
    (l r l' r' : ℝ) (hl : l' ≤ l) (hr : r ≤ r') :
    physicalWordWindow N I O root m w F l r ≤ physicalWordWindow N I O root m w F l' r' := by
  apply lintegral_mono
  intro ω
  apply lintegral_mono
  intro t
  by_cases h : t < adaptiveExitTime N (alternatingDomain N I O) root (2*m+1) ω ∧
      walk N root ω t = root ∧ t ∈ Icc l r
  · have h' : t < adaptiveExitTime N (alternatingDomain N I O) root (2*m+1) ω ∧
        walk N root ω t = root ∧ t ∈ Icc l' r' := ⟨h.1,h.2.1,hl.trans h.2.2.1,h.2.2.2.trans hr⟩
    simp only [if_pos h,if_pos h',le_refl]
  · simp only [if_neg h,zero_le]


end TorusCoverTime.Blocks.B
