import Solutions.Blocks.B.R8PrefixConditionalLaw

/-! The deterministic high-count prefix is soft with probability at most
exp(-40 log N), under the original unconditioned walk law. -/
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

theorem r8_high_count_prefix_probability (hWalk : WalkModelRegular) (γ U : ℝ)
    (hγ : 0 < γ) (hγ1 : γ < 1) (hU : 0 ≤ U) :
    ∀ᶠ N : Size in atTop, ∀ c root : Vertex N, ∀ q : ℝ,
      (logSize N)^(16*γ) ≤ q → q ≤ logSize N-(logSize N)^(16*γ) →
      root ∉ torusDisk N c (Real.exp (q+2*q^γ)) →
      walkLaw {ω | traversalOccupation N (torusDisk N c (Real.exp (q+q^γ)))
        (torusDisk N c (Real.exp (q+2*q^γ))) root (r8SitePotential N c)
        (r8HighCountCutoff (logSize N) q γ) ω ≤ U} ≤ ENNReal.ofReal (Real.exp (-40*logSize N)) := by
  filter_upwards [r8_positive_word_high_count hWalk γ U hγ hγ1 hU] with N hN
  intro c root q hq hqL hr
  have hqpos : 0 < q := (Real.rpow_pos_of_pos (logSize_pos N) _).trans_le hq
  exact r8_prefix_probability_of_word_bounds N _ _ c root
    (torusDisk_nonempty N c _ (Real.exp_pos _)) hr _ U _
    (fun w hw => hN c root q hq hqL hr _ (r8_high_count_cutoff_lower _ q γ hqpos) w hw)

end TorusCoverTime.Blocks.B
