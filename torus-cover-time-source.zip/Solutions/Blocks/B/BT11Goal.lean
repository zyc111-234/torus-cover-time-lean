import Solutions.Blocks.B.BT10

/-! B-T11 is the original registered R10 goal, including its time supremum.
The fixed-time bad event below is only an intermediate presentation. -/
noncomputable section
open MeasureTheory Filter Set Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

abbrev BT11Conclusion : Prop := WideDefectLimit

def bt11Bad (N : Size) (a : Vertex N) (u η t : ℝ) : Set WalkSample :=
  {ω | η*Real.sqrt (logSize N)<bt10DefectCount N a u (ω,t)}

theorem bt11Bad_measurable (N : Size) (a : Vertex N) (u η t : ℝ) :
    MeasurableSet (bt11Bad N a u η t) :=
  measurableSet_lt measurable_const ((bt10DefectCount_measurable N a u).comp
    (measurable_id.prodMk measurable_const))

theorem bt11Bad_eq_earliest (N : Size) (a : Vertex N) (u η W : ℝ) :
    bt11Bad N a u η (phaseACenter N-W*timeScale N) =
      {ω | η<earliestDefectMass N a ω u W} := by
  ext ω
  simp only [bt11Bad,bt10DefectCount,earliestDefectMass,mem_setOf_eq,
    lt_div_iff₀ (Real.sqrt_pos.mpr (logSize_pos N))]

end TorusCoverTime.Blocks.B
