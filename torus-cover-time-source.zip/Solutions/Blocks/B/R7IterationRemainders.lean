import Solutions.Blocks.B.R7EnlargedWindows

/-! Both physical iteration remainders are exponentially small at any fixed
L log L rate. The root-count factor n is included throughout. -/

noncomputable section
open Filter
open scoped Topology
namespace TorusCoverTime.Blocks.B

theorem polynomial_quadratic_exponential_absorption (d K A : ℝ) (m : ℕ) :
    ∀ᶠ L : ℝ in atTop, K*L^m*Real.exp (A*L-L^2) ≤ Real.exp (-d*L*Real.log L) := by
  have ht := (Real.tendsto_pow_mul_exp_neg_atTop_nhds_zero m).const_mul K
  simp only [mul_zero] at ht
  filter_upwards [eventually_ge_atTop (0:ℝ),eventually_ge_atTop (2*(A+1)),
    ht.eventually_le_const zero_lt_one,log_eventually_le_power d 1 (1/2) zero_lt_one (by norm_num)]
    with L hL hA hpoly hlog
  simp only [Real.rpow_one] at hlog
  have he : K*L^m*Real.exp (A*L-L^2) =
      (K*(L^m*Real.exp (-L)))*Real.exp ((A+1)*L-L^2) := by
    calc
      _ = K*L^m*Real.exp (-L+((A+1)*L-L^2)) := by congr 2; ring
      _ = _ := by rw [Real.exp_add]; ring
  rw [he]
  calc
    _ ≤ 1*Real.exp ((A+1)*L-L^2) := mul_le_mul_of_nonneg_right hpoly (Real.exp_pos _).le
    _ ≤ _ := by
      rw [one_mul]
      apply Real.exp_le_exp.mpr
      have h1 := mul_le_mul_of_nonneg_right hlog hL
      have h2 := mul_nonneg (show 0 ≤ L-2*(A+1) by linarith) hL
      nlinarith

theorem r7_terminal_remainder_bound (γ d K : ℝ) (hγ : 0 < γ) (hK : 0 ≤ K) :
    ∀ᶠ N : Size in atTop,
      K*vertexCount N*(r7IterationProbability N γ)^(r7IterationLength N) ≤
        Real.exp (-d*logSize N*Real.log (logSize N)) := by
  filter_upwards [r7_probability_power_bound γ hγ,
    blockB_logSize_tendsto.eventually (polynomial_quadratic_exponential_absorption d K 2 0)] with N hp hN
  calc
    _ ≤ K*vertexCount N*Real.exp (-(logSize N)^2) :=
      mul_le_mul_of_nonneg_left hp.2 (mul_nonneg hK (vertexCount_pos N).le)
    _ = K*(logSize N)^0*Real.exp (2*logSize N-(logSize N)^2) := by
      rw [D.vertexCount_eq_exp_two_logSize,sub_eq_add_neg,Real.exp_add]
      ring
    _ ≤ _ := hN

theorem stretched_exponential_dominates_square (a : ℝ) (ha : 0 < a) :
    ∀ᶠ L : ℝ in atTop, L^2 ≤ Real.exp (L^a/2) := by
  have ht := polynomial_times_stretched_exp_tendsto_zero a (1/2) 2 ha (by norm_num)
  filter_upwards [ht.eventually_le_const zero_lt_one] with L hL
  simp only [Real.rpow_two] at hL
  have h := mul_le_mul_of_nonneg_right hL (Real.exp_pos (L^a/2)).le
  have he : L^2*Real.exp (-(1/2)*L^a)*Real.exp (L^a/2) = L^2 := by
    rw [mul_assoc,← Real.exp_add,show -(1/2)*L^a+L^a/2 = 0 by ring,Real.exp_zero,mul_one]
  rwa [he,one_mul] at h

theorem r7_duration_remainder_bound (γ d K : ℝ) (hγ : 0 < γ) (hK : 0 ≤ K) :
    ∀ᶠ N : Size in atTop, ∀ M : ℕ, (M:ℝ) ≤ (logSize N)^4+1 → ∀ l r : ℝ,
      r-l ≤ K*timeScale N →
      vertexCount N*((M:ℝ)+1)*(r-l)*Real.exp (-Real.exp ((logSize N)^(16*γ)/2))/timeScale N ≤
        Real.exp (-d*logSize N*Real.log (logSize N)) := by
  filter_upwards [blockB_logSize_tendsto.eventually_ge_atTop 1,
    blockB_logSize_tendsto.eventually (stretched_exponential_dominates_square (16*γ) (by positivity)),
    blockB_logSize_tendsto.eventually (polynomial_quadratic_exponential_absorption d (3*K) 2 4)] with N hL hexp hN
  intro M hM l r hlen
  have hL4 : 1 ≤ (logSize N)^4 := by nlinarith [sq_nonneg ((logSize N)^2-1),sq_nonneg (logSize N-1)]
  have hM' : (M:ℝ)+1 ≤ 3*(logSize N)^4 := by linarith
  have he := Real.exp_le_exp.mpr (neg_le_neg hexp)
  calc
    _ = vertexCount N*((M:ℝ)+1)*((r-l)/timeScale N)*
        Real.exp (-Real.exp ((logSize N)^(16*γ)/2)) := by ring
    _ ≤ vertexCount N*((M:ℝ)+1)*K*Real.exp (-Real.exp ((logSize N)^(16*γ)/2)) := by
      apply mul_le_mul_of_nonneg_right _ (Real.exp_pos _).le
      apply mul_le_mul_of_nonneg_left ((div_le_iff₀ (timeScale_pos N)).mpr hlen)
      exact mul_nonneg (vertexCount_pos N).le (by positivity)
    _ ≤ vertexCount N*(3*(logSize N)^4)*K*Real.exp (-(logSize N)^2) := by
      have := (vertexCount_pos N).le
      gcongr
    _ = (3*K)*(logSize N)^4*Real.exp (2*logSize N-(logSize N)^2) := by
      rw [D.vertexCount_eq_exp_two_logSize,sub_eq_add_neg,Real.exp_add]
      ring
    _ ≤ _ := hN

end TorusCoverTime.Blocks.B
