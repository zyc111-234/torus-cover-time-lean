import Solutions.Blocks.B.FiniteExitDuration
import Solutions.Blocks.B.DefectWindow

/-! Actual occupation up to a jump time is the sum of the holding times at the visited
vertices. The terminal point has zero occupation contribution at the instant of exit. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Classical
open scoped ENNReal Topology BigOperators
namespace TorusCoverTime.Blocks.B

lemma walk_eq_position_on_holding_interval (N : Size) (a : Vertex N)
    {ω : WalkSample} (hpos : ∀ j, 0 < (ω j).1)
    (hnon : Tendsto (jumpTime ω) atTop atTop) (j : ℕ) (t : ℝ)
    (ht : t ∈ Set.Ico (jumpTime ω j) (jumpTime ω (j + 1))) :
    walk N a ω t = position N a ω j := by
  have ht0 := (jumpTime_nonneg ω j).trans ht.1
  rw [walk, if_neg (not_lt.mpr ht0),
    (jumpCount_eq_iff_on_regular_sample hpos hnon t ht0 j).mpr ht]

lemma integral_walk_holding_interval (N : Size) (a x : Vertex N)
    {ω : WalkSample} (hpos : ∀ j, 0 < (ω j).1)
    (hnon : Tendsto (jumpTime ω) atTop atTop) (j : ℕ) :
    (∫ t in (jumpTime ω j)..(jumpTime ω (j + 1)),
      if walk N a ω t = x then (1 : ℝ) else 0) =
      if position N a ω j = x then holdingTime ω j else 0 := by
  have hle := (jumpTime_strictMono hpos).monotone (Nat.le_succ j)
  rw [intervalIntegral.integral_of_le hle, ← integral_Ico_eq_integral_Ioc]
  have heq : Set.EqOn (fun t => if walk N a ω t = x then (1 : ℝ) else 0)
      (fun _ => if position N a ω j = x then (1 : ℝ) else 0)
      (Set.Ico (jumpTime ω j) (jumpTime ω (j + 1))) := by
    intro t ht
    dsimp only
    rw [walk_eq_position_on_holding_interval N a hpos hnon j t ht]
  rw [setIntegral_congr_fun measurableSet_Ico heq]
  have hlen : jumpTime ω (j + 1) - jumpTime ω j = holdingTime ω j := by
    simp [jumpTime, Finset.sum_range_succ]
  split_ifs <;> simp [hlen, holdingTime]

lemma localTime_jumpTime_eq_sum_holding (N : Size) (a x : Vertex N)
    {ω : WalkSample} (hpos : ∀ j, 0 < (ω j).1)
    (hnon : Tendsto (jumpTime ω) atTop atTop) (n : ℕ) :
    localTime N a ω (jumpTime ω n) x =
      ∑ j ∈ Finset.range n, if position N a ω j = x then holdingTime ω j else 0 := by
  let f := fun t : ℝ => if walk N a ω t = x then (1 : ℝ) else 0
  have hm : Measurable f := (measurable_walk_indicator_joint N a x).comp
    (measurable_const.prodMk measurable_id)
  have hi (j : ℕ) : IntervalIntegrable f volume (jumpTime ω j) (jumpTime ω (j + 1)) := by
    apply (intervalIntegrable_iff_integrableOn_Icc_of_le
      ((jumpTime_strictMono hpos).monotone (Nat.le_succ j))).mpr
    apply Integrable.of_bound hm.aestronglyMeasurable 1
    exact Eventually.of_forall fun t => by dsimp [f]; split_ifs <;> norm_num
  have hs := intervalIntegral.sum_integral_adjacent_intervals (n := n) (fun j _ => hi j)
  rw [jumpTime_zero, intervalIntegral.integral_of_le (jumpTime_nonneg ω n),
    ← integral_Icc_eq_integral_Ioc] at hs
  change _ = localTime N a ω (jumpTime ω n) x at hs
  rw [← hs]
  exact Finset.sum_congr rfl fun j _ => integral_walk_holding_interval N a x hpos hnon j

lemma holdingTime_le_localTime_jumpTime (N : Size) (a x : Vertex N)
    {ω : WalkSample} (hpos : ∀ j, 0 < (ω j).1)
    (hnon : Tendsto (jumpTime ω) atTop atTop) (n j : ℕ)
    (hj : j < n) (hx : position N a ω j = x) :
    holdingTime ω j ≤ localTime N a ω (jumpTime ω n) x := by
  rw [localTime_jumpTime_eq_sum_holding N a x hpos hnon n]
  have hterm : (if position N a ω j = x then holdingTime ω j else 0) = holdingTime ω j := by
    rw [if_pos hx]
  rw [← hterm]
  exact Finset.single_le_sum (f := fun i => if position N a ω i = x then holdingTime ω i else 0)
    (fun i _ => by split_ifs <;> simp [holdingTime])
    (Finset.mem_range.mpr hj)

lemma localTime_finiteExitDuration_eq_sum_holding (N : Size) (D : Finset (Vertex N))
    (a x : Vertex N) {ω : WalkSample} (hpos : ∀ j, 0 < (ω j).1)
    (hnon : Tendsto (jumpTime ω) atTop atTop) :
    localTime N a ω (finiteExitDuration N D a ω) x =
      ∑ j ∈ Finset.range (finiteExitIndex N D a ω),
        if position N a ω j = x then holdingTime ω j else 0 :=
  localTime_jumpTime_eq_sum_holding N a x hpos hnon _

end TorusCoverTime.Blocks.B
