import Solutions.Blocks.B.GreenSpatialDecay

/-! The logarithmic spatial Green-kernel bound, with the manuscript's periodic distance. -/

noncomputable section
open scoped BigOperators
namespace TorusCoverTime.Blocks.B

lemma greenKernel_quadratic_error (N : Size) (x y : Vertex N) :
    |greenKernel N x y - (quadraticFourierSum N (x - y)).re / Real.pi ^ 2| ≤ Real.pi ^ 2 / 12 := by
  classical
  let err := fun k => 1 / (vertexCount N * finiteEigenvalue N k) -
    1 / (Real.pi ^ 2 * frequencyNormSq N k)
  have herr (k) (hk : k ∈ nonzeroFrequencies N) : 0 ≤ err k :=
    (green_multiplier_quadratic_error N k hk).1
  have hreal : (quadraticFourierSum N (x - y)).re / Real.pi ^ 2 =
      ∑ k ∈ nonzeroFrequencies N, finiteCosine N k (x - y) / (Real.pi ^ 2 * frequencyNormSq N k) := by
    have hre (f : Vertex N → ℂ) : (∑ k ∈ nonzeroFrequencies N, f k).re =
        ∑ k ∈ nonzeroFrequencies N, (f k).re := map_sum Complex.reAddGroupHom _ _
    rw [quadraticFourierSum, hre, Finset.sum_div]
    apply Finset.sum_congr rfl
    intro k _
    simp only [Complex.mul_re, Complex.ofReal_re, Complex.ofReal_im, zero_mul, sub_zero,
      finiteCharacter_re, div_eq_mul_inv, mul_inv_rev]
    ring
  have hid : greenKernel N x y - (quadraticFourierSum N (x - y)).re / Real.pi ^ 2 =
      ∑ k ∈ nonzeroFrequencies N, finiteCosine N k (x - y) * err k := by
    rw [hreal, greenKernel, Finset.sum_div, ← Finset.sum_sub_distrib]
    apply Finset.sum_congr rfl
    intro k _
    simp only [err, div_eq_mul_inv, mul_inv_rev]
    ring
  have hsum : (∑ k ∈ nonzeroFrequencies N, err k) ≤ Real.pi ^ 2 / 12 := by
    have hdiag : (∑ k ∈ nonzeroFrequencies N, err k) = greenDiagonal N -
        (∑ k ∈ nonzeroFrequencies N, 1 / frequencyNormSq N k) / Real.pi ^ 2 := by
      rw [greenDiagonal_eq_sum, Finset.sum_div, Finset.sum_div, ← Finset.sum_sub_distrib]
      apply Finset.sum_congr rfl
      intro k _
      simp only [err, div_eq_mul_inv, mul_inv_rev]
      ring
    rw [hdiag]
    exact (le_abs_self _).trans (greenDiagonal_quadratic_error N)
  rw [hid]
  apply (Finset.abs_sum_le_sum_abs _ _).trans
  apply le_trans _ hsum
  apply Finset.sum_le_sum
  intro k hk
  rw [abs_mul, abs_of_nonneg (herr k hk)]
  exact mul_le_of_le_one_left (herr k hk) (Real.abs_cos_le_one _)

lemma abs_greenKernel_le_quadratic_norm (N : Size) (x y : Vertex N) :
    |greenKernel N x y| ≤ Real.pi ^ 2 / 12 + ‖quadraticFourierSum N (x - y)‖ / Real.pi ^ 2 := by
  have hp := sq_pos_of_pos Real.pi_pos
  calc
    _ = |(greenKernel N x y - (quadraticFourierSum N (x - y)).re / Real.pi ^ 2) +
      (quadraticFourierSum N (x - y)).re / Real.pi ^ 2| := by congr 1; ring
    _ ≤ _ := abs_add_le _ _
    _ ≤ _ := add_le_add (greenKernel_quadratic_error N x y) (by
      rw [abs_div, abs_of_pos hp]
      exact div_le_div_of_nonneg_right (Complex.abs_re_le_norm _) hp.le)

def greenSpatialConstant : ℝ :=
  greenDiagonalErrorConstant + g + Real.pi ^ 2 / 12 + (28 + 4 * Real.pi) / Real.pi ^ 2

lemma greenSpatialConstant_pos : 0 < greenSpatialConstant := by
  have := greenDiagonalErrorConstant_pos
  unfold greenSpatialConstant g
  positivity

lemma greenKernel_spatial_bound (N : Size) (x y : Vertex N) :
    |greenKernel N x y| ≤ greenSpatialConstant *
      (1 + Real.log ((N.val : ℝ) / max (periodicDistance x y) 1)) := by
  have hp := sq_pos_of_pos Real.pi_pos
  have hg : 0 < g := by unfold g; positivity
  have hdiag := greenDiagonalErrorConstant_pos
  have hB : 0 ≤ Real.pi ^ 2 / 12 := by positivity
  have hK : 0 ≤ (28 + 4 * Real.pi) / Real.pi ^ 2 := by positivity
  have hCdiag : greenDiagonalErrorConstant + g ≤ greenSpatialConstant := by
    unfold greenSpatialConstant
    linarith
  have hCoff : Real.pi ^ 2 / 12 + (28 + 4 * Real.pi) / Real.pi ^ 2 ≤ greenSpatialConstant := by
    unfold greenSpatialConstant
    linarith
  by_cases hxy : x = y
  · subst y
    have hd0 : periodicDistance x x = 0 := by simp [periodicDistance, coordinateDistance]
    rw [hd0, max_eq_right (by norm_num : (0 : ℝ) ≤ 1), div_one,
      greenKernel_diagonal, abs_of_pos (greenDiagonal_pos N)]
    have he := (abs_le.mp (greenDiagonal_log_error N)).2
    have hL : 0 ≤ logSize N := (logSize_pos N).le
    have hmult := mul_le_mul_of_nonneg_right hCdiag hL
    change greenDiagonal N ≤ greenSpatialConstant * (1 + logSize N)
    nlinarith [mul_nonneg hdiag.le hL]
  · have hz : x - y ≠ 0 := sub_ne_zero.mpr hxy
    have hd := periodicDistance_nonzero_ge_one N (x - y) hz
    rw [periodicDistance_sub_zero] at hd
    have hd0 : 0 < periodicDistance x y := lt_of_lt_of_le zero_lt_one hd
    rw [max_eq_left hd]
    have hfac : 1 ≤ 1 + Real.log ((N.val : ℝ) / periodicDistance x y) := by
      have h := Real.log_nonneg ((one_le_div hd0).mpr (periodicDistance_le_size N x y))
      linarith
    have hQ := quadraticFourierSum_spatial_bound N (x - y) hz
    rw [periodicDistance_sub_zero] at hQ
    calc
      _ ≤ Real.pi ^ 2 / 12 + ‖quadraticFourierSum N (x - y)‖ / Real.pi ^ 2 :=
        abs_greenKernel_le_quadratic_norm N x y
      _ ≤ Real.pi ^ 2 / 12 + ((28 + 4 * Real.pi) / Real.pi ^ 2) *
          (1 + Real.log ((N.val : ℝ) / periodicDistance x y)) := by
        apply add_le_add le_rfl
        calc
          _ ≤ ((28 + 4 * Real.pi) * (1 + Real.log ((N.val : ℝ) / periodicDistance x y))) /
              Real.pi ^ 2 := div_le_div_of_nonneg_right hQ hp.le
          _ = _ := by ring
      _ ≤ (Real.pi ^ 2 / 12 + (28 + 4 * Real.pi) / Real.pi ^ 2) *
          (1 + Real.log ((N.val : ℝ) / periodicDistance x y)) := by
        nlinarith [mul_le_mul_of_nonneg_left hfac hB]
      _ ≤ _ := mul_le_mul_of_nonneg_right hCoff (by linarith)

end TorusCoverTime.Blocks.B
