import Solutions.Blocks.B.R8SingleExponent
import Solutions.Blocks.B.ExitPairLaplace

/-! Quantitative two-by-two comparison retaining the leading entrance factor 2. -/
noncomputable section
namespace TorusCoverTime.Blocks.B

theorem bt9_matrix_comparison (q k h A B C D : ℝ)
    (hq : 0 < q) (hk : 0 ≤ k) (hh : 0 ≤ h) (hsmall : k*h ≤ q/16)
    (hA : |A-q| ≤ k*h) (hD : |D-q| ≤ k*h)
    (hB : 0 ≤ B) (hC : 0 ≤ C) (hBu : B ≤ k*h) (hCu : C ≤ k*h) :
    0 < A*D-B*C ∧
    (A*D-B*C)/(q+8*k*h) ≤ D-B ∧
    (A*D-B*C)/(q+8*k*h) ≤ A-C := by
  have ht : 0 ≤ k*h := mul_nonneg hk hh
  have ha := abs_le.mp hA
  have hd := abs_le.mp hD
  have hlow : 0 ≤ q-k*h := by linarith
  have hprodlo : (q-k*h)^2 ≤ A*D := by
    nlinarith [mul_le_mul (show q-k*h ≤ A by linarith)
      (show q-k*h ≤ D by linarith) hlow (show 0 ≤ A by linarith)]
  have hbc : B*C ≤ (k*h)^2 := by nlinarith [mul_le_mul hBu hCu hC ht]
  have hprodhi : A*D ≤ (q+k*h)^2 := by
    nlinarith [mul_le_mul (show A ≤ q+k*h by linarith)
      (show D ≤ q+k*h by linarith) (show 0 ≤ D by linarith) (by linarith : 0 ≤ q+k*h)]
  have hden : 0 < q+8*k*h := by nlinarith
  have hdet : 0 < A*D-B*C := by
    nlinarith [mul_pos hq (show 0 < q-2*k*h by linarith)]
  have hub : A*D-B*C ≤ (q+k*h)^2 := by nlinarith [mul_nonneg hB hC]
  have hshape : (q+k*h)^2 ≤ (q-2*k*h)*(q+8*k*h) := by
    nlinarith [mul_nonneg ht (show 0 ≤ 4*q-17*k*h by linarith)]
  refine ⟨hdet, (div_le_iff₀ hden).mpr ?_, (div_le_iff₀ hden).mpr ?_⟩
  · exact hub.trans (hshape.trans (mul_le_mul_of_nonneg_right (by linarith) hden.le))
  · exact hub.trans (hshape.trans (mul_le_mul_of_nonneg_right (by linarith) hden.le))

theorem bt9_entry_product (q h X H : ℝ) (hq : 0 < q) (hh : 0 ≤ h)
    (hhq : h/q ≤ 1) (hX : h*(1-h/q) ≤ X) (hH : 1-h/q ≤ H) :
    h*(1-2*h/q) ≤ X*H := by
  have hl : 0 ≤ 1-h/q := by linarith
  have hX0 : 0 ≤ X := (mul_nonneg hh hl).trans hX
  have hp := mul_le_mul hX hH hl hX0
  have he : h*(1-h/q)*(1-h/q) = h*(1-2*h/q)+h*(h/q)^2 := by ring
  linarith [mul_nonneg hh (sq_nonneg (h/q))]

theorem bt9_entrance_parameter (q h k E : ℝ) (hq : 0 < q)
    (hh : 0 ≤ h) (hk : 0 ≤ k) (hE : 2*h*(1-2*h/q) ≤ E) :
    (2*h/q)*(1-(8*k+2)*(h/q)) ≤ E/(q+8*k*h) := by
  apply (le_div_iff₀ (by positivity : 0 < q+8*k*h)).mpr
  apply le_trans _ hE
  have he : 2*h*(1-2*h/q)-
      (2*h/q*(1-(8*k+2)*(h/q)))*(q+8*k*h) =
      16*k*(8*k+2)*h^3/q^2 := by field_simp; ring
  have hp : 0 ≤ 16*k*(8*k+2)*h^3/q^2 := by positivity
  linarith

theorem bt9_exponent_expanded (q v h C U : ℝ)
    (hq : 0 < q) (hh : 1 ≤ h) (hC : 0 ≤ C) (hU : 0 ≤ U)
    (hscale : 0 ≤ 1-C*(h/q)) :
    let s := v-Real.sqrt 2*q;
    let K := 8*(C+1)+2*U;
    -((max (Real.sqrt (2*v^2/q*(1-C*(h/q)))-Real.sqrt (2*U/q)) 0)^2) ≤
      -4*q-4*Real.sqrt 2*s-(s^2/q)*(2-K*(h/q))+K*h := by
  dsimp only
  let s := v-Real.sqrt 2*q
  let K := 8*(C+1)+2*U
  have hr := Real.sq_sqrt (by norm_num : (0:ℝ) ≤ 2)
  have hv : v^2 = 2*q^2+2*Real.sqrt 2*q*s+s^2 := by
    calc
      _ = (Real.sqrt 2*q+s)^2 := by dsimp [s]; ring
      _ = (Real.sqrt 2)^2*q^2+2*Real.sqrt 2*q*s+s^2 := by ring
      _ = _ := by rw [hr]
  have hvhi : v^2 ≤ 4*q^2+2*s^2 := by
    have ht : (Real.sqrt 2*q-s)^2 = 2*q^2-2*Real.sqrt 2*q*s+s^2 := by
      calc
        _ = (Real.sqrt 2)^2*q^2-2*Real.sqrt 2*q*s+s^2 := by ring
        _ = _ := by rw [hr]
    nlinarith only [sq_nonneg (Real.sqrt 2*q-s), ht, hv]
  have heq : (Real.sqrt 2*v)^2 = 2*v^2 := by rw [mul_pow,hr]
  have hmain := single_softness_exponent_loss q (Real.sqrt 2*v) h C U hq
    (by linarith) hC hU hscale
  rw [heq] at hmain
  have hmore : 2*v^2/q^2 ≤ 2*h*v^2/q^2 :=
    div_le_div_of_nonneg_right
      (mul_le_mul_of_nonneg_right (show 2 ≤ 2*h by linarith) (sq_nonneg v)) (sq_nonneg q)
  have hu : 2*U ≤ 2*U*h := le_mul_of_one_le_right (by positivity) hh
  have hvdiv : 2*(C+1)*h*(v^2/q^2) ≤ 2*(C+1)*h*(4+2*s^2/q^2) := by
    apply mul_le_mul_of_nonneg_left _ (by positivity)
    apply (div_le_iff₀ (sq_pos_of_pos hq)).mpr
    have he : (4+2*s^2/q^2)*q^2 = 4*q^2+2*s^2 := by field_simp <;> ring
    rwa [he]
  have hquad := mul_le_mul_of_nonneg_right
    (show 4*(C+1) ≤ K by dsimp [K]; linarith)
    (show 0 ≤ h*s^2/q^2 by positivity)
  have hrewrite : -4*q-4*Real.sqrt 2*s-(s^2/q)*(2-K*(h/q))+K*h =
      -2*v^2/q+K*h+K*h*s^2/q^2 := by rw [hv]; field_simp; ring
  change _ ≤ -4*q-4*Real.sqrt 2*s-(s^2/q)*(2-K*(h/q))+K*h
  rw [hrewrite]
  dsimp only [K] at hquad ⊢
  linear_combination hmain + hmore + hu + hvdiv + hquad

end TorusCoverTime.Blocks.B
