import Solutions.Blocks.B.FourierRowEstimates
import Solutions.Blocks.B.TruncatedHarmonic

/-! Summing oscillatory quadratic Fourier rows at the spatial cutoff N/d. -/

noncomputable section
open scoped BigOperators
namespace TorusCoverTime.Blocks.B

def quadraticFourierSum (N : Size) (z : Vertex N) : ℂ :=
  ∑ k ∈ nonzeroFrequencies N, ((1 / frequencyNormSq N k : ℝ) : ℂ) * finiteCharacter N k z

lemma quadraticFourierSum_rows (N : Size) (z : Vertex N) :
    quadraticFourierSum N z = ∑ b : ZMod N.val,
      coordinateCharacter N (b * z.2) * quadraticFourierRow N z.1 (coordinateDistance b 0) := by
  classical
  have h := Finset.sum_erase_add (s := (Finset.univ : Finset (Vertex N)))
    (fun k => ((1 / frequencyNormSq N k : ℝ) : ℂ) * finiteCharacter N k z) (Finset.mem_univ 0)
  have hz : frequencyNormSq N 0 = 0 := by simp [frequencyNormSq, coordinateDistance]
  simp only [hz, div_zero, Complex.ofReal_zero, zero_mul, add_zero] at h
  unfold quadraticFourierSum
  rw [show nonzeroFrequencies N = Finset.univ.erase 0 from rfl, h, Fintype.sum_prod_type,
    Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro b _
  rw [quadraticFourierRow, Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro a _
  simp only [frequencyNormSq, finiteCharacter, coordinateCharacter_add]
  rw [add_comm (coordinateDistance a 0 ^ 2) (coordinateDistance b 0 ^ 2)]
  ring

lemma quadraticFourierSum_norm_le_rows (N : Size) (z : Vertex N) :
    ‖quadraticFourierSum N z‖ ≤
      ∑ b : ZMod N.val, ‖quadraticFourierRow N z.1 (coordinateDistance b 0)‖ := by
  rw [quadraticFourierSum_rows]
  apply (norm_sum_le _ _).trans
  apply Finset.sum_le_sum
  intro b _
  rw [norm_mul, coordinateCharacter_norm, one_mul]

lemma quadraticFourierSum_coordinate_bound (N : Size) (z : Vertex N) (hz : z.1 ≠ 0) :
    ‖quadraticFourierSum N z‖ ≤
      (14 + 2 * Real.pi) * (1 + Real.log ((N.val : ℝ) / coordinateDistance z.1 0)) := by
  classical
  let T := (N.val : ℝ) / coordinateDistance z.1 0
  let C := 1 + Real.pi
  let weight := fun x : ℝ => min (C / x) (2 * T / x ^ 2)
  let s := Finset.univ.erase (0 : ZMod N.val)
  have hd : 0 < coordinateDistance z.1 0 :=
    lt_of_lt_of_le zero_lt_one (coordinateDistance_nonzero_ge_one N z.1 hz)
  have hT : 1 ≤ T := by
    apply (le_div_iff₀ hd).mpr
    have := (coordinateDistance_zero_bounds N z.1).2
    have := size_real_gt_one N
    linarith
  have hC : 0 ≤ C := by dsimp [C]; positivity
  have hrow : (∑ b ∈ s, ‖quadraticFourierRow N z.1 (coordinateDistance b 0)‖) ≤
      ∑ b ∈ s, weight (coordinateDistance b 0) := by
    apply Finset.sum_le_sum
    intro b hb
    have hdb := coordinateDistance_nonzero_ge_one N b (Finset.mem_erase.mp hb).1
    apply le_min (quadraticFourierRow_absolute N z.1 _ hdb)
    have hosc := quadraticFourierRow_oscillatory N z.1 hz _ (lt_of_lt_of_le zero_lt_one hdb)
    calc
      _ ≤ 2 * (N.val : ℝ) / (coordinateDistance z.1 0 * coordinateDistance b 0 ^ 2) := hosc
      _ = 2 * T / coordinateDistance b 0 ^ 2 := by
        simp only [T, div_eq_mul_inv, mul_inv_rev]
        ring
  have hfold : (∑ b ∈ s, weight (coordinateDistance b 0)) =
      (∑ j ∈ Finset.range (N.val / 2), weight ((j : ℝ) + 1)) +
      (∑ j ∈ Finset.range ((N.val - 1) / 2), weight ((j : ℝ) + 1)) := by
    have h := sum_centered_coordinate N weight
    rw [sum_zmod_erase_zero] at h
    have hd0 : coordinateDistance (0 : ZMod N.val) 0 = 0 := by simp [coordinateDistance]
    simpa only [hd0, weight, div_zero, zero_pow (by decide : 2 ≠ 0), min_self,
      add_zero, zero_add] using h
  have hR := truncated_harmonic_bound C 2 T hC (by norm_num) hT (N.val / 2)
  have hM := truncated_harmonic_bound C 2 T hC (by norm_num) hT ((N.val - 1) / 2)
  have htotal := quadraticFourierSum_norm_le_rows N z
  rw [sum_zmod_erase_zero] at htotal
  have hd0 : coordinateDistance (0 : ZMod N.val) 0 = 0 := by simp [coordinateDistance]
  rw [hd0] at htotal
  have hzrow := quadraticFourierRow_zero N z.1
  rw [hfold] at hrow
  have hlog : 0 ≤ Real.log T := Real.log_nonneg hT
  change ‖quadraticFourierSum N z‖ ≤ (14 + 2 * Real.pi) * (1 + Real.log T)
  change _ ≤ C * (1 + Real.log T) + 2 * 2 at hR hM
  dsimp [weight] at hrow
  dsimp [C] at hR hM hrow
  nlinarith [hR, hM]

lemma quadraticFourierSum_swap (N : Size) (z : Vertex N) :
    quadraticFourierSum N z.swap = quadraticFourierSum N z := by
  classical
  unfold quadraticFourierSum
  apply Finset.sum_bij (fun k _ => k.swap)
  · intro k hk
    apply Finset.mem_erase.mpr
    refine ⟨?_, Finset.mem_univ _⟩
    intro h
    apply (Finset.mem_erase.mp hk).1
    exact Prod.swap_injective (by simpa using h)
  · intro a _ b _ hab
    exact Prod.swap_injective hab
  · intro k hk
    refine ⟨k.swap, ?_, by simp⟩
    apply Finset.mem_erase.mpr
    refine ⟨?_, Finset.mem_univ _⟩
    intro h
    apply (Finset.mem_erase.mp hk).1
    exact Prod.swap_injective (by simpa using h)
  · intro k _
    simp only [frequencyNormSq, finiteCharacter, Prod.fst_swap, Prod.snd_swap, add_comm]

lemma spatial_log_row_comparison (N : Size) (u d : ℝ) (hu : 0 < u) (hd : 0 < d)
    (hdN : d ≤ N.val) (hdu : d ≤ 2 * u) :
    (14 + 2 * Real.pi) * (1 + Real.log ((N.val : ℝ) / u)) ≤
      (28 + 4 * Real.pi) * (1 + Real.log ((N.val : ℝ) / d)) := by
  have hn : 0 < (N.val : ℝ) := lt_trans zero_lt_one (size_real_gt_one N)
  have hquot : (N.val : ℝ) / u ≤ 2 * N.val / d := by
    apply (div_le_div_iff₀ hu hd).mpr
    nlinarith [mul_le_mul_of_nonneg_left hdu hn.le]
  have hlog := Real.log_le_log (div_pos hn hu) hquot
  rw [show 2 * (N.val : ℝ) / d = 2 * ((N.val : ℝ) / d) by ring,
    Real.log_mul (by norm_num) (div_pos hn hd).ne'] at hlog
  have hlog2 : Real.log 2 ≤ 1 := by
    have h := Real.log_le_sub_one_of_pos (by norm_num : (0 : ℝ) < 2)
    norm_num at h
    exact h
  have hlog0 : 0 ≤ Real.log ((N.val : ℝ) / d) :=
    Real.log_nonneg ((one_le_div hd).mpr hdN)
  have hc : 0 ≤ 14 + 2 * Real.pi := by positivity
  have h := mul_le_mul_of_nonneg_left (show 1 + Real.log ((N.val : ℝ) / u) ≤
      2 * (1 + Real.log ((N.val : ℝ) / d)) by linarith) hc
  nlinarith [h]

lemma periodicDistance_nonzero_ge_one (N : Size) (z : Vertex N) (hz : z ≠ 0) :
    1 ≤ periodicDistance z 0 := by
  have hd : 0 ≤ periodicDistance z 0 := Real.sqrt_nonneg _
  have hsq : periodicDistance z 0 ^ 2 =
      coordinateDistance z.1 0 ^ 2 + coordinateDistance z.2 0 ^ 2 := by
    simp only [periodicDistance, Prod.fst_zero, Prod.snd_zero,
      Real.sq_sqrt (add_nonneg (sq_nonneg _) (sq_nonneg _))]
  by_cases hz1 : z.1 = 0
  · have hz2 : z.2 ≠ 0 := by intro h; exact hz (Prod.ext hz1 h)
    have h2 := coordinateDistance_nonzero_ge_one N z.2 hz2
    nlinarith [sq_nonneg (coordinateDistance z.1 0)]
  · have h1 := coordinateDistance_nonzero_ge_one N z.1 hz1
    nlinarith [sq_nonneg (coordinateDistance z.2 0)]

lemma quadraticFourierSum_spatial_bound (N : Size) (z : Vertex N) (hz : z ≠ 0) :
    ‖quadraticFourierSum N z‖ ≤
      (28 + 4 * Real.pi) * (1 + Real.log ((N.val : ℝ) / periodicDistance z 0)) := by
  have hd := periodicDistance_nonzero_ge_one N z hz
  have hsum := periodicDistance_le_coordinate_sum N z
  have hd0 : 0 < periodicDistance z 0 := lt_of_lt_of_le zero_lt_one hd
  have hz0 : coordinateDistance (0 : ZMod N.val) 0 = 0 := by simp [coordinateDistance]
  rcases le_total (coordinateDistance z.2 0) (coordinateDistance z.1 0) with hc | hc
  · have hz1 : z.1 ≠ 0 := by
      intro h
      rw [h, hz0] at hc hsum
      linarith
    have hu := lt_of_lt_of_le zero_lt_one (coordinateDistance_nonzero_ge_one N z.1 hz1)
    exact (quadraticFourierSum_coordinate_bound N z hz1).trans
      (spatial_log_row_comparison N _ _ hu hd0 (periodicDistance_le_size N z 0) (by linarith))
  · have hz2 : z.2 ≠ 0 := by
      intro h
      rw [h, hz0] at hc hsum
      linarith
    have hu := lt_of_lt_of_le zero_lt_one (coordinateDistance_nonzero_ge_one N z.2 hz2)
    have hbound := quadraticFourierSum_coordinate_bound N z.swap hz2
    rw [quadraticFourierSum_swap] at hbound
    simp only [Prod.fst_swap] at hbound
    exact hbound.trans
      (spatial_log_row_comparison N _ _ hu hd0 (periodicDistance_le_size N z 0) (by linarith))

end TorusCoverTime.Blocks.B
