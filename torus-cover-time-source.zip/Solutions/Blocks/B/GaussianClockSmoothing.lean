import Solutions.Blocks.B.GaussianClockSurvival

/-! The half-time recurrence retains the complete early survival event.  The
future density uses the actual sum of variances over the remaining segment. -/

noncomputable section
open MeasureTheory ProbabilityTheory Classical Set
open scoped ENNReal NNReal
namespace TorusCoverTime.Blocks.B.GaussianClockPath
variable {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
variable {n : ℕ} (W : GaussianClockPath μ n)

theorem survival_interval_le (lo hi : Fin (n + 1)) (hlohi : lo ≤ hi)
    (δ : ℝ) (hδ : 0 < δ) (hgap : δ ≤ W.clock hi - W.clock lo)
    (a t : ℝ) (ht : 0 ≤ t) :
    μ {ω | ω ∈ W.survival a lo ∧ W.path ω hi ∈ Icc (a - t) a} ≤
      ENNReal.ofReal (t / Real.sqrt (2 * Real.pi * δ)) * μ (W.survival a lo) := by
  let L := fun ω (i : {i : Fin (n + 1) // i ≤ lo}) => W.path ω i.val
  let G := fun ω => W.path ω hi - W.path ω lo
  let S : Set ({i : Fin (n + 1) // i ≤ lo} → ℝ) := {f | ∀ i, f i ≤ a}
  have hS : MeasurableSet S := by
    change MeasurableSet {f : {i : Fin (n + 1) // i ≤ lo} → ℝ | ∀ i, f i ≤ a}
    rw [Set.ofPred_forall]
    exact MeasurableSet.iInter (fun i => measurableSet_le (measurable_pi_apply i) measurable_const)
  have hv := hδ.trans_le hgap
  have h := Blocks.C.C4.independent_event_interval_le μ L G (by fun_prop) (by fun_prop)
    (W.past_indep_increment lo hi hlohi) (Real.toNNReal_pos.mpr hv).ne'
    (W.increment_hasLaw lo hi hlohi) (fun f => f ⟨lo, le_rfl⟩) (measurable_pi_apply _)
    S hS (a - t) a (by linarith)
  rw [Real.coe_toNNReal _ hv.le, show a - (a - t) = t by ring] at h
  have he (ω : Ω) : L ω ⟨lo, le_rfl⟩ + G ω = W.path ω hi := by dsimp [L, G]; ring
  have hs : L ⁻¹' S = W.survival a lo := by
    ext ω
    exact ⟨fun h i hi => h ⟨i, hi⟩, fun h i => h i.val i.property⟩
  have hevent : {ω | L ω ∈ S ∧ L ω ⟨lo, le_rfl⟩ + G ω ∈ Icc (a - t) a} =
      {ω | ω ∈ W.survival a lo ∧ W.path ω hi ∈ Icc (a - t) a} := by
    ext ω
    simp only [mem_ofPred_eq, he]
    exact and_congr (Set.ext_iff.mp hs ω) Iff.rfl
  rw [hevent, hs] at h
  refine h.trans ?_
  gcongr

theorem survival_probability_recurrence (lo hi : Fin (n + 1)) (hlohi : lo ≤ hi)
    (δ : ℝ) (hδ : 0 < δ) (hgap : δ ≤ W.clock hi - W.clock lo)
    (a C K t : ℝ) (hC : 0 ≤ C) (ht : 0 < t)
    (hK : W.survivalMoment a C hi ≤ ENNReal.ofReal K) :
    μ (W.survival a hi) ≤ ENNReal.ofReal (t / Real.sqrt (2 * Real.pi * δ)) *
      μ (W.survival a lo) + ENNReal.ofReal (K / t) := by
  have hsub : W.survival a hi ⊆
      {ω | ω ∈ W.survival a lo ∧ W.path ω hi ∈ Icc (a - t) a} ∪
      {ω | ω ∈ W.survival a hi ∧ t < a - W.path ω hi} := by
    intro ω hω
    have hh := hω hi le_rfl
    by_cases hc : a - t ≤ W.path ω hi
    · exact Or.inl ⟨W.survival_antitone a hlohi hω, hc, hh⟩
    · exact Or.inr ⟨hω, by linarith⟩
  refine (measure_mono hsub).trans ((measure_union_le _ _).trans ?_)
  exact add_le_add (W.survival_interval_le lo hi hlohi δ hδ hgap a t ht.le)
    (Blocks.C.C4.weighted_gap_tail_le μ _ _ (W.measurable_coord hi) a C K t hC ht hK)

end TorusCoverTime.Blocks.B.GaussianClockPath
