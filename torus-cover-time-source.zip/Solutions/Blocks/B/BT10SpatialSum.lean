import Solutions.Blocks.B.BT10WitnessCover
import Solutions.Blocks.B.DiskCardinality
import Solutions.Blocks.B.R8RemainderSummability

/-! Pay every distance-shell vertex, center, count and scale. The small
additive errors retain N^4 and N^6 respectively after the complete sum. -/
noncomputable section
open MeasureTheory Filter Set Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

def bt10ShellEnvelope (L γ H a C : ℝ) : ℝ :=
  18*C*Real.sqrt L*Real.exp (-2*L-L^(8*γ))+
    18*Real.exp (2*L-a*L*Real.log L)+
    54*(H+1)*Real.exp (4*L-Real.exp (L^(16*γ)/2))

theorem bt10_shell_envelope_bound (L γ H a C q : ℝ) (hH : 0≤H) (hC : 0≤C) (hq : q≤L) :
    (9*Real.exp (2*q))*bt10SliceEnvelope L γ H a C q≤bt10ShellEnvelope L γ H a C := by
  have hmain : (9*Real.exp (2*q))*(2*C*Real.sqrt L*Real.exp (-2*L-2*q-L^(8*γ))) =
      18*C*Real.sqrt L*Real.exp (-2*L-L^(8*γ)) := by
    calc
      _ = 18*C*Real.sqrt L*(Real.exp (2*q)*Real.exp (-2*L-2*q-L^(8*γ))) := by ring
      _ = _ := by rw [← Real.exp_add]; congr 2; ring
  have hi : (9*Real.exp (2*q))*(2*Real.exp (-a*L*Real.log L)) =
      18*Real.exp (2*q-a*L*Real.log L) := by
    rw [show 2*q-a*L*Real.log L=2*q+(-a*L*Real.log L) by ring,Real.exp_add]; ring
  have hd : (9*Real.exp (2*q))*(6*(H+1)*Real.exp (2*L)*Real.exp (-Real.exp (L^(16*γ)/2))) =
      54*(H+1)*Real.exp (2*q+2*L-Real.exp (L^(16*γ)/2)) := by
    rw [show 2*q+2*L-Real.exp (L^(16*γ)/2)=2*q+(2*L+(-Real.exp (L^(16*γ)/2))) by ring,
      Real.exp_add,Real.exp_add]; ring
  unfold bt10SliceEnvelope bt10ShellEnvelope
  rw [mul_add,mul_add,hmain,hi,hd]
  apply add_le_add (add_le_add le_rfl _) _ <;> gcongr <;> linarith

def bt10AggregateEnvelope (L γ H a C : ℝ) : ℝ :=
  (202*L^3*Real.exp (2*L))*bt10ShellEnvelope L γ H a C

theorem bt10_aggregate_envelope_identity (L γ H a C : ℝ) (hL : 0<L) :
    bt10AggregateEnvelope L γ H a C =
      (3636*C)*L^(7/2:ℝ)*Real.exp (-L^(8*γ))+
      3636*L^3*Real.exp (4*L-a*L*Real.log L)+
      (10908*(H+1))*L^3*Real.exp (6*L-Real.exp (L^(16*γ)/2)) := by
  have hpow : L^3*Real.sqrt L=L^(7/2:ℝ) := by
    rw [Real.sqrt_eq_rpow,← Real.rpow_natCast,← Real.rpow_add hL]
    norm_num
  have h₁ : Real.exp (2*L)*Real.exp (-2*L-L^(8*γ))=Real.exp (-L^(8*γ)) := by
    rw [← Real.exp_add]; congr 1; ring
  have h₂ : Real.exp (2*L)*Real.exp (2*L-a*L*Real.log L)=Real.exp (4*L-a*L*Real.log L) := by
    rw [← Real.exp_add]; congr 1; ring
  have h₃ : Real.exp (2*L)*Real.exp (4*L-Real.exp (L^(16*γ)/2))=Real.exp (6*L-Real.exp (L^(16*γ)/2)) := by
    rw [← Real.exp_add]; congr 1; ring
  unfold bt10AggregateEnvelope bt10ShellEnvelope
  calc
    _ = (3636*C)*(L^3*Real.sqrt L)*(Real.exp (2*L)*Real.exp (-2*L-L^(8*γ)))+
        3636*L^3*(Real.exp (2*L)*Real.exp (2*L-a*L*Real.log L))+
        (10908*(H+1))*L^3*(Real.exp (2*L)*Real.exp (4*L-Real.exp (L^(16*γ)/2))) := by ring
    _ = _ := by rw [hpow,h₁,h₂,h₃]

theorem bt10_aggregate_envelope_tendsto (γ H a C : ℝ) (hγ : 0<γ) (hH : 0≤H) (ha : 0<a) :
    Tendsto (fun L : ℝ => bt10AggregateEnvelope L γ H a C) atTop (𝓝 0) := by
  have ht := (((polynomial_times_stretched_exp_tendsto_zero (8*γ) 1 (7/2) (by positivity) zero_lt_one).const_mul (3636*C)).add
    (r8_iteration_remainder_tendsto 3636 4 a 3 (by norm_num) ha)).add
    (r8_duration_remainder_tendsto γ (10908*(H+1)) 6 3 hγ (by positivity))
  simp only [mul_zero,add_zero,one_mul,neg_one_mul,Real.rpow_natCast,Real.rpow_ofNat,mul_assoc] at ht
  apply ht.congr'
  filter_upwards [eventually_gt_atTop (0:ℝ)] with L hL
  simpa only [mul_assoc] using (bt10_aggregate_envelope_identity L γ H a C hL).symm

theorem bt10_spatial_sum_bound (N : Size) (γ U H a C l r : ℝ)
    (hL : 1≤logSize N) (hH : 0≤H) (hC : 0≤C)
    (hbound : ∀ q∈r8InteriorIntegerScales N γ, ∀ x y : Vertex N, ∀ m∈r8ModerateCounts (logSize N),
      bt10SliceMass N x y γ q U m l r≤ENNReal.ofReal (bt10SliceEnvelope (logSize N) γ H a C q)) :
    bt10AllSliceMass N γ U l r≤ENNReal.ofReal (bt10AggregateEnvelope (logSize N) γ H a C) := by
  let L := logSize N
  let A := ENNReal.ofReal (bt10ShellEnvelope L γ H a C)
  have hscale (q : ℕ) (hq : q∈r8InteriorIntegerScales N γ) :
      (∑ x : Vertex N, ∑ y∈torusDisk N x (Real.exp (q:ℝ)),
        ∑ m∈r8ModerateCounts L, bt10SliceMass N x y γ q U m l r) ≤
      ENNReal.ofReal (Real.exp (2*L))*ENNReal.ofReal (101*L^2)*A := by
    have hqr := (mem_r8InteriorIntegerScales N γ q).mp hq
    have hqL : (q:ℝ)≤L := by have := Real.rpow_nonneg (logSize_pos N).le (16*γ); dsimp [L]; linarith
    have hcenter (x : Vertex N) : (∑ y∈torusDisk N x (Real.exp (q:ℝ)),
        ∑ m∈r8ModerateCounts L, bt10SliceMass N x y γ q U m l r)≤ENNReal.ofReal (101*L^2)*A := by
      have hc := torusDisk_card_quadratic N x (Real.exp (q:ℝ)) (Real.one_le_exp_iff.mpr (Nat.cast_nonneg q))
      have hc' : ((torusDisk N x (Real.exp (q:ℝ))).card:ℝ)≤9*Real.exp (2*(q:ℝ)) := by
        convert hc using 1
        rw [show (2:ℝ)*(q:ℝ)=(q:ℝ)+(q:ℝ) by ring,Real.exp_add,pow_two]
      have hm := r8_moderate_counts_card L hL
      calc
        _ ≤ ∑ _y∈torusDisk N x (Real.exp (q:ℝ)),
            ∑ _m∈r8ModerateCounts L, ENNReal.ofReal (bt10SliceEnvelope L γ H a C q) :=
          Finset.sum_le_sum (fun y _ => Finset.sum_le_sum (fun m hm => hbound q hq x y m hm))
        _ = ((torusDisk N x (Real.exp (q:ℝ))).card:ℝ≥0∞)*
            ((r8ModerateCounts L).card:ℝ≥0∞)*ENNReal.ofReal (bt10SliceEnvelope L γ H a C q) := by
          simp only [Finset.sum_const,nsmul_eq_mul]; ring
        _ ≤ ENNReal.ofReal (9*Real.exp (2*(q:ℝ)))*ENNReal.ofReal (101*L^2)*
            ENNReal.ofReal (bt10SliceEnvelope L γ H a C q) := by
          exact mul_le_mul' (mul_le_mul'
            (by simpa only [ENNReal.ofReal_natCast] using ENNReal.ofReal_le_ofReal hc')
            (by simpa only [ENNReal.ofReal_natCast] using ENNReal.ofReal_le_ofReal hm)) le_rfl
        _ = ENNReal.ofReal (101*L^2)*ENNReal.ofReal
            ((9*Real.exp (2*(q:ℝ)))*bt10SliceEnvelope L γ H a C q) := by
          rw [ENNReal.ofReal_mul (by positivity : 0≤9*Real.exp (2*(q:ℝ)))]; ring
        _ ≤ _ := mul_le_mul' le_rfl (ENNReal.ofReal_le_ofReal (bt10_shell_envelope_bound L γ H a C q hH hC hqL))
    apply (Finset.sum_le_sum (fun x _ => hcenter x)).trans_eq
    rw [Finset.sum_const,Finset.card_univ,nsmul_eq_mul,
      show (Fintype.card (Vertex N):ℝ≥0∞)=ENNReal.ofReal (Real.exp (2*L)) by
        rw [← ENNReal.ofReal_natCast,← D.vertexCount_eq_card,D.vertexCount_eq_exp_two_logSize]]
    ring
  calc
    _ ≤ ∑ _q∈r8InteriorIntegerScales N γ,
        ENNReal.ofReal (Real.exp (2*L))*ENNReal.ofReal (101*L^2)*A := Finset.sum_le_sum hscale
    _ ≤ ENNReal.ofReal (2*L)*(ENNReal.ofReal (Real.exp (2*L))*ENNReal.ofReal (101*L^2)*A) := by
      rw [Finset.sum_const,nsmul_eq_mul]
      exact mul_le_mul' (by simpa only [ENNReal.ofReal_natCast] using
        ENNReal.ofReal_le_ofReal (r8_interior_scales_card N γ hL)) le_rfl
    _ = _ := by
      rw [← mul_assoc,← mul_assoc,← ENNReal.ofReal_mul (by positivity : 0≤2*L),
        ← ENNReal.ofReal_mul (by positivity : 0≤2*L*Real.exp (2*L)),
        ← ENNReal.ofReal_mul (by positivity : 0≤2*L*Real.exp (2*L)*(101*L^2))]
      congr 1
      unfold bt10AggregateEnvelope
      ring

end TorusCoverTime.Blocks.B
