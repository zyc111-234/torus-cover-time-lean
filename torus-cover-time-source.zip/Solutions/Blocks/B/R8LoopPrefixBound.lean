import Solutions.Blocks.B.R8HighCountEvent

/-! A path event containing every bad loop time controls the entire window.
This deliberately keeps the root-count factor when the loop constraint drops. -/
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

theorem r7LoopEventTest_le_one (N : Size) (root : Vertex N) (E : Set (WalkSample × ℝ))
    (l r : ℝ) (z : WalkSample × ℝ) : r7LoopEventTest N root E l r z ≤ 1 := by
  unfold r7LoopEventTest
  split_ifs <;> simp

theorem r7LoopEventTest_time_bound (N : Size) (root : Vertex N) (E : Set (WalkSample × ℝ))
    (l r : ℝ) (ω : WalkSample) :
    (∫⁻ t in Ioi (0:ℝ), r7LoopEventTest N root E l r (ω,t)) ≤ ENNReal.ofReal (r-l) := by
  calc
    _ ≤ ∫⁻ t in Ioi (0:ℝ), (Icc l r).indicator (fun _ => (1:ℝ≥0∞)) t := by
      apply lintegral_mono
      intro t
      by_cases h : (ω,t) ∈ E ∧ walk N root ω t = root ∧ t ∈ Icc l r
      · simp only [r7LoopEventTest,if_pos h,indicator_of_mem h.2.2,le_refl]
      · simp only [r7LoopEventTest,if_neg h]
        exact bot_le
    _ ≤ ∫⁻ t, (Icc l r).indicator (fun _ => (1:ℝ≥0∞)) t := lintegral_mono' Measure.restrict_le_self le_rfl
    _ = _ := by rw [lintegral_indicator_const measurableSet_Icc,one_mul,Real.volume_Icc]

theorem r8_root_loop_prefix_bound (N : Size) (root : Vertex N) (E : Set (WalkSample × ℝ))
    (B : Set WalkSample) (hB : MeasurableSet B)
    (hEB : ∀ᵐ ω ∂walkLaw, ∀ t : ℝ, 0 ≤ t → walk N root ω t = root → (ω,t) ∈ E → ω ∈ B)
    (l r : ℝ) :
    (∫⁻ ω, ∫⁻ t in Ioi (0:ℝ), r7LoopEventTest N root E l r (ω,t) ∂volume ∂walkLaw) ≤
      ENNReal.ofReal (r-l)*walkLaw B := by
  calc
    _ ≤ ∫⁻ ω, ENNReal.ofReal (r-l)*(if ω ∈ B then (1:ℝ≥0∞) else 0) ∂walkLaw := by
      apply lintegral_mono_ae
      filter_upwards [hEB] with ω hω
      by_cases hb : ω ∈ B
      · rw [if_pos hb,mul_one]
        exact r7LoopEventTest_time_bound N root E l r ω
      · rw [if_neg hb,mul_zero]
        apply le_of_eq
        apply lintegral_eq_zero_of_ae_eq_zero
        filter_upwards [ae_restrict_mem (measurableSet_Ioi (a := (0:ℝ)))] with t ht
        apply if_neg
        rintro ⟨he,hloop,_⟩
        exact hb (hω t ht.le hloop he)
    _ = _ := by
      simp_rw [mul_ite,mul_one,mul_zero]
      exact lintegral_indicator_const hB _

theorem r8_loop_normalized_root_bound (N : Size) (E : Vertex N → Set (WalkSample × ℝ))
    (l r : ℝ) (ρ : ℝ≥0∞)
    (hroot : ∀ root, (∫⁻ ω, ∫⁻ t in Ioi (0:ℝ), r7LoopEventTest N root (E root) l r (ω,t) ∂volume ∂walkLaw) ≤
      ENNReal.ofReal (r-l)*ρ) :
    r7LoopEventMass N E l r ≤ ENNReal.ofReal (vertexCount N*(r-l)/timeScale N)*ρ := by
  unfold r7LoopEventMass
  apply (mul_le_mul' le_rfl (Finset.sum_le_sum (fun root _ => hroot root))).trans_eq
  rw [Finset.sum_const,Finset.card_univ,nsmul_eq_mul]
  rw [show (Fintype.card (Vertex N):ℝ≥0∞) = ENNReal.ofReal (vertexCount N) by
    rw [D.vertexCount_eq_card,ENNReal.ofReal_natCast]]
  rw [← ENNReal.ofReal_inv_of_pos (timeScale_pos N)]
  simp only [← mul_assoc]
  rw [← ENNReal.ofReal_mul (inv_nonneg.mpr (timeScale_pos N).le),
    ← ENNReal.ofReal_mul (mul_nonneg (inv_nonneg.mpr (timeScale_pos N).le) (vertexCount_pos N).le)]
  congr 2
  ring

end TorusCoverTime.Blocks.B
