import Solutions.Blocks.B.BT6ResidualEvent
import Mathlib.Analysis.SpecialFunctions.Pow.Asymptotics

noncomputable section
open Filter Asymptotics
open scoped Topology
namespace TorusCoverTime.Blocks.B

theorem bt6_power_ratio (a b : ℝ) (hba : b<a) :
    Tendsto (fun L : ℝ => L^b/L^a) atTop (𝓝 0) := by
  apply (tendsto_rpow_neg_atTop (sub_pos.mpr hba)).congr'
  filter_upwards [eventually_gt_atTop (0:ℝ)] with L hL
  rw [show -(a-b)=b-a by ring,Real.rpow_sub hL]

/-- The analytic absorption used below, with all coefficients fixed independently of N. -/
theorem bt6_polylog_subpower (a b D E F G : ℝ) (ha : 0<a) (hba : b<a) :
    ∀ᶠ L : ℝ in atTop, D*L^b+E*(Real.log L)^2+F*Real.log L+G≤L^a := by
  have hp := (bt6_power_ratio a b hba).const_mul D
  have hl2 : Tendsto (fun L : ℝ => (Real.log L)^2/L^a) atTop (𝓝 0) := by
    simpa only [Real.rpow_two] using (isLittleO_log_rpow_rpow_atTop 2 ha).tendsto_div_nhds_zero
  have hl := (isLittleO_log_rpow_atTop ha).tendsto_div_nhds_zero
  have hc := (tendsto_inv_atTop_zero.comp (tendsto_rpow_atTop ha)).const_mul G
  have ht : Tendsto (fun L : ℝ => (D*L^b+E*(Real.log L)^2+F*Real.log L+G)/L^a) atTop (𝓝 0) := by
    convert ((hp.add (hl2.const_mul E)).add (hl.const_mul F)).add hc using 1
    · ext L
      simp only [Function.comp_def]
      ring
    · simp only [mul_zero,add_zero]
  filter_upwards [eventually_gt_atTop (0:ℝ),ht.eventually_lt_const (by norm_num : (0:ℝ)<1)] with L hL hh
  exact (div_le_one (Real.rpow_pos_of_pos hL a)).mp hh.le

theorem bt6_paper_parameters (γ C C₀ C₁ : ℝ) (K : ℕ) (hγ : 0<γ) (hγhi : 32*γ<1/10)
    (hC : 0≤C) (hC₀ : 0≤C₀) (hC₁ : 0≤C₁) (hK : 0<K) :
    ∀ᶠ L : ℝ in atTop,
      8*(C+1)≤L ∧ 2*(K:ℝ)≤L ∧
      1≤L^(32*γ) ∧ L^(32*γ)≤L^(1/10:ℝ) ∧ 4*C≤L^(32*γ) ∧
      4*(K:ℝ)≤L^(1/10:ℝ) ∧ L^(1/10:ℝ)≤L/4 ∧
      0≤C₀*(Real.log L+1) ∧ C₀*(Real.log L+1)≤L ∧
      0≤C₁*L^(8*γ) ∧
      2*(C₁*L^(8*γ))+6*bt6BridgeError L C (C₀*(Real.log L+1))≤L^(32*γ) ∧
      (K:ℝ)≤L^(32*γ) ∧ (Real.log L)^2+4*Real.log L≤L^(32*γ) := by
  have ha : 0<32*γ := by linarith
  have hbudget := bt6_polylog_subpower (32*γ) (8*γ) (2*C₁) (6*dirichletResidualLogScaleConstant)
    (6+12*C₀) (24*Real.sqrt 2*C+12*C₀) ha (by linarith)
  have hη := bt6_polylog_subpower 1 0 0 0 C₀ C₀ (by norm_num) (by norm_num)
  have hS := bt6_polylog_subpower 1 (1/10) 4 0 0 0 (by norm_num) (by norm_num)
  have htail := bt6_polylog_subpower (32*γ) 0 0 1 4 0 ha ha
  filter_upwards [eventually_ge_atTop (8*(C+1)),eventually_ge_atTop (2*(K:ℝ)),
    (tendsto_rpow_atTop ha).eventually_ge_atTop 1,
    (tendsto_rpow_atTop ha).eventually_ge_atTop (4*C),
    (tendsto_rpow_atTop (by norm_num : (0:ℝ)<1/10)).eventually_ge_atTop (4*(K:ℝ)),
    (tendsto_rpow_atTop ha).eventually_ge_atTop (K:ℝ),hbudget,hη,hS,htail]
    with L hL hLK hA hAC hSK hAK hb he hs ht
  have hl1 : 1≤L := by linarith
  have hl0 : 0≤L := by linarith
  simp only [zero_mul,zero_add,add_zero,Real.rpow_one,one_mul] at he hs ht
  refine ⟨hL,hLK,hA,Real.rpow_le_rpow_of_exponent_le hl1 hγhi.le,hAC,hSK,by linarith,
    by positivity [Real.log_nonneg hl1],by linarith,by positivity,?_,hAK,ht⟩
  unfold bt6BridgeError
  nlinarith only [hb]

end TorusCoverTime.Blocks.B
