import Solutions.Blocks.B.AdaptiveExitWord

/-! Actual alternating returns to the inner set and exits from the outer set.
The physical segment count is finite almost surely. A loop rooted outside the
outer set can only be observed during an exterior segment, so completed
traversals are indexed by the unique interval [T_(2m), T_(2m+1)). -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

def alternatingDomain (N : Size) (I O : Finset (Vertex N)) (k : ℕ) : Finset (Vertex N) :=
  if k % 2 = 0 then Finset.univ \ I else O

theorem alternatingDomain_even (N : Size) (I O : Finset (Vertex N)) (m : ℕ) :
    alternatingDomain N I O (2*m) = Finset.univ \ I := by simp [alternatingDomain]

theorem alternatingDomain_odd (N : Size) (I O : Finset (Vertex N)) (m : ℕ) :
    alternatingDomain N I O (2*m+1) = O := by simp [alternatingDomain]

theorem alternatingDomain_proper (N : Size) (I O : Finset (Vertex N))
    (hI : I.Nonempty) (hO : ∃ b : Vertex N, b ∉ O) :
    ∀ k, ∃ b : Vertex N, b ∉ alternatingDomain N I O k := by
  intro k
  by_cases hk : k % 2 = 0
  · obtain ⟨b,hb⟩ := hI
    exact ⟨b, by simpa [alternatingDomain, hk] using hb⟩
  · simpa only [alternatingDomain, if_neg hk] using hO

theorem alternatingDomain_switch (N : Size) (I O : Finset (Vertex N)) (hIO : I ⊆ O)
    (k : ℕ) (x : Vertex N) (hx : x ∉ alternatingDomain N I O k) :
    x ∈ alternatingDomain N I O (k+1) := by
  by_cases hk : k % 2 = 0
  · have hk' : (k+1) % 2 ≠ 0 := by omega
    simp only [alternatingDomain, if_pos hk, Finset.mem_sdiff, Finset.mem_univ, true_and, not_not] at hx
    simpa only [alternatingDomain, if_neg hk'] using hIO hx
  · have hk' : (k+1) % 2 = 0 := by omega
    simp only [alternatingDomain, if_neg hk] at hx
    simpa only [alternatingDomain, if_pos hk', Finset.mem_sdiff, Finset.mem_univ, true_and] using
      (fun hi => hx (hIO hi))

theorem alternatingExit_starts_inside_ae (N : Size) (I O : Finset (Vertex N))
    (hIO : I ⊆ O) (hI : I.Nonempty) (root : Vertex N) (hr : root ∉ O) :
    ∀ᵐ ω ∂walkLaw, ∀ k,
      adaptiveExitStart N (alternatingDomain N I O) root k ω ∈ alternatingDomain N I O k := by
  filter_upwards [adaptiveExit_spec_ae N _ (alternatingDomain_proper N I O hI ⟨root,hr⟩) root]
    with ω hω
  intro k
  cases k with
  | zero => simpa [alternatingDomain] using (fun hi => hr (hIO hi))
  | succ k => exact alternatingDomain_switch N I O hIO k _ (hω k).1

theorem alternatingExitIndex_strictMono_ae (N : Size) (I O : Finset (Vertex N))
    (hIO : I ⊆ O) (hI : I.Nonempty) (root : Vertex N) (hr : root ∉ O) :
    ∀ᵐ ω ∂walkLaw, StrictMono (fun k => adaptiveExitIndex N (alternatingDomain N I O) root k ω) := by
  filter_upwards [alternatingExit_starts_inside_ae N I O hIO hI root hr,
    adaptiveExit_spec_ae N _ (alternatingDomain_proper N I O hI ⟨root,hr⟩) root] with ω hin hs
  apply strictMono_nat_of_lt_succ
  intro k
  have hp : 0 < finiteExitIndex N (alternatingDomain N I O k)
      (adaptiveExitStart N (alternatingDomain N I O) root k ω)
      (adaptiveExitTail N (alternatingDomain N I O) root k ω) := by
    by_contra h
    have he : finiteExitIndex N (alternatingDomain N I O k)
        (adaptiveExitStart N (alternatingDomain N I O) root k ω)
        (adaptiveExitTail N (alternatingDomain N I O) root k ω) = 0 := by omega
    have hh := hs k
    rw [he] at hh
    have hx := hh.2.1
    simp only [position_zero] at hx
    exact hh.1 (hx ▸ hin k)
  rw [adaptiveExitIndex_succ]
  omega

theorem alternatingExitTime_regular_ae (N : Size) (I O : Finset (Vertex N))
    (hIO : I ⊆ O) (hI : I.Nonempty) (root : Vertex N) (hr : root ∉ O) :
    ∀ᵐ ω ∂walkLaw,
      StrictMono (fun k => adaptiveExitTime N (alternatingDomain N I O) root k ω) ∧
      Tendsto (fun k => adaptiveExitTime N (alternatingDomain N I O) root k ω) atTop atTop := by
  filter_upwards [alternatingExitIndex_strictMono_ae N I O hIO hI root hr,
    A.holding_positive_and_nonexplosive] with ω hs hω
  exact ⟨(jumpTime_strictMono hω.1).comp hs, hω.2.comp hs.tendsto_atTop⟩

def physicalSegmentCount (T : ℕ → ℝ) (t : ℝ) : ℕ :=
  if h : ∃ k : ℕ, t < T (k+1) then Nat.find h else 0

theorem physicalSegmentCount_bounds (T : ℕ → ℝ) (hT0 : T 0 = 0)
    (hdiv : Tendsto T atTop atTop) (t : ℝ) (ht : 0 ≤ t) :
    T (physicalSegmentCount T t) ≤ t ∧ t < T (physicalSegmentCount T t+1) := by
  have he : ∃ k : ℕ, t < T (k+1) := by
    obtain ⟨k,hk⟩ := ((hdiv.eventually_gt_atTop t).and (eventually_gt_atTop 0)).exists
    refine ⟨k-1, ?_⟩
    simpa only [Nat.sub_add_cancel (by omega : 1 ≤ k)] using hk.1
  rw [physicalSegmentCount, dif_pos he]
  refine ⟨?_, Nat.find_spec he⟩
  by_cases hz : Nat.find he = 0
  · simpa only [hz,hT0] using ht
  · have hk : Nat.find he-1 < Nat.find he := by omega
    have h := Nat.find_min he hk
    simpa only [Nat.sub_add_cancel (by omega : 1 ≤ Nat.find he), not_lt] using h

theorem physicalSegmentCount_unique (T : ℕ → ℝ) (hT : StrictMono T) (t : ℝ)
    (k : ℕ) (hk : T k ≤ t ∧ t < T (k+1)) : physicalSegmentCount T t = k := by
  have he : ∃ j : ℕ, t < T (j+1) := ⟨k,hk.2⟩
  rw [physicalSegmentCount, dif_pos he]
  apply (Nat.find_eq_iff he).mpr
  refine ⟨hk.2, ?_⟩
  intro j hj hlt
  exact (not_lt_of_ge ((hT.monotone (by omega : j+1 ≤ k)).trans hk.1)) hlt

theorem physicalSegmentCount_measurable {Ω : Type*} [MeasurableSpace Ω]
    (T : ℕ → Ω → ℝ) (hT : ∀ k, Measurable (T k)) :
    Measurable (fun p : Ω × ℝ => physicalSegmentCount (fun k => T k p.1) p.2) := by
  let E : Set (Ω × ℝ) := {p | ∃ k : ℕ, p.2 < T (k+1) p.1}
  have hE : MeasurableSet E := by
    simp only [E, Set.ofPred_exists]
    exact MeasurableSet.iUnion fun k => measurableSet_lt measurable_snd ((hT (k+1)).comp measurable_fst)
  have hm : Measurable (fun p : E => Nat.find p.property) := by
    apply measurable_find
    intro k
    exact (measurableSet_lt measurable_snd ((hT (k+1)).comp measurable_fst)).preimage measurable_subtype_coe
  exact hm.dite measurable_const hE

def completedTraversalCount (N : Size) (I O : Finset (Vertex N)) (root : Vertex N)
    (ω : WalkSample) (t : ℝ) : ℕ :=
  physicalSegmentCount (fun k => adaptiveExitTime N (alternatingDomain N I O) root k ω) t / 2

theorem completedTraversalCount_measurable (N : Size) (I O : Finset (Vertex N)) (root : Vertex N) :
    Measurable (fun p : WalkSample × ℝ => completedTraversalCount N I O root p.1 p.2) := by
  exact (measurable_of_countable (fun k : ℕ => k/2)).comp
    (physicalSegmentCount_measurable _ (adaptiveExitTime_measurable N _ root))

theorem adaptiveExitTime_between (N : Size) (D : ℕ → Finset (Vertex N)) (root : Vertex N)
    (ω : WalkSample) (hp : ∀ j, 0 < (ω j).1) (hd : Tendsto (jumpTime ω) atTop atTop)
    (k : ℕ)
    (hs : exitsThroughAt N (D k) (adaptiveExitStart N D root k ω)
      (adaptiveExitStart N D root (k+1) ω) (adaptiveExitTail N D root k ω)
      (finiteExitIndex N (D k) (adaptiveExitStart N D root k ω) (adaptiveExitTail N D root k ω)))
    (t : ℝ) (ht : adaptiveExitTime N D root k ω ≤ t ∧ t < adaptiveExitTime N D root (k+1) ω) :
    walk N root ω t ∈ D k := by
  have ht0 : 0 ≤ t := (jumpTime_nonneg ω _).trans ht.1
  have hl := jumpTime_jumpCount_le hp hd ht0
  have hu := A.jumpCount_upper hp hd t
  have hi : adaptiveExitIndex N D root k ω ≤ jumpCount ω t := by
    by_contra hn
    have hh := (jumpTime_strictMono hp).monotone (show jumpCount ω t+1 ≤ adaptiveExitIndex N D root k ω by omega)
    exact (not_lt_of_ge (hh.trans ht.1)) hu
  have hi' : jumpCount ω t < adaptiveExitIndex N D root (k+1) ω := by
    by_contra hn
    have hh := (jumpTime_strictMono hp).monotone (show adaptiveExitIndex N D root (k+1) ω ≤ jumpCount ω t by omega)
    exact (not_lt_of_ge (hh.trans hl)) ht.2
  simpa only [walk, if_neg (not_lt.mpr ht0)] using adaptiveExit_between N D root ω k hs _ hi hi'

theorem completedTraversalCount_loop_slice_ae (N : Size) (I O : Finset (Vertex N))
    (hIO : I ⊆ O) (hI : I.Nonempty) (root : Vertex N) (hr : root ∉ O) :
    ∀ᵐ ω ∂walkLaw, ∀ t : ℝ, 0 ≤ t → walk N root ω t = root →
      let m := completedTraversalCount N I O root ω t
      adaptiveExitTime N (alternatingDomain N I O) root (2*m) ω ≤ t ∧
      t < adaptiveExitTime N (alternatingDomain N I O) root (2*m+1) ω := by
  filter_upwards [alternatingExitTime_regular_ae N I O hIO hI root hr,
    adaptiveExit_spec_ae N _ (alternatingDomain_proper N I O hI ⟨root,hr⟩) root,
    A.holding_positive_and_nonexplosive] with ω hT hs hω
  intro t ht hroot
  let T := fun k => adaptiveExitTime N (alternatingDomain N I O) root k ω
  let k := physicalSegmentCount T t
  have hb := physicalSegmentCount_bounds T (by simp [T,adaptiveExitTime]) hT.2 t ht
  have hx := adaptiveExitTime_between N _ root ω hω.1 hω.2 k (hs k) t hb
  have heven : k % 2 = 0 := by
    by_contra hn
    have hx' : walk N root ω t ∈ O := by simpa only [alternatingDomain,if_neg hn] using hx
    exact hr (hroot ▸ hx')
  have he : 2*(k/2) = k := by omega
  change T (2*(k/2)) ≤ t ∧ t < T (2*(k/2)+1)
  simpa only [he] using hb

end TorusCoverTime.Blocks.B
