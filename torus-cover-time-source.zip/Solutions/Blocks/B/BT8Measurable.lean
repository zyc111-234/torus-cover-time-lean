import Solutions.Blocks.B.BT8Goal

noncomputable section
open MeasureTheory Filter Set Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

theorem bt8ContactAt_measurable (N : Size) (root x : Vertex N) (γ : ℝ) (q : ℕ) :
    MeasurableSet {z | bt8ContactAt N root x γ q z} :=
  (MeasurableSet.const _).inter ((MeasurableSet.const _).inter
    (measurableSet_le (r7TraversalRadius_measurable N x root γ q) measurable_const))

theorem bt8SoftPoint_measurable (N : Size) (root x : Vertex N) (γ u : ℝ) :
    MeasurableSet {z | bt8SoftPoint N root x γ u z} := by
  unfold bt8SoftPoint
  simp only [Set.ofPred_and,Set.ofPred_exists]
  exact (measurableSet_le (localTime_joint_measurable N root x) measurable_const).inter
    (MeasurableSet.iUnion (bt8ContactAt_measurable N root x γ))

theorem bt8SoftCount_measurable (N : Size) (root : Vertex N) (γ u : ℝ) :
    Measurable (bt8SoftCount N root γ u) :=
  Finset.measurable_sum _ (fun x _ => measurable_const.ite (bt8SoftPoint_measurable N root x γ u) measurable_const)

theorem bt8Good_measurable (N : Size) (root : Vertex N) (γ u : ℝ) :
    MeasurableSet {z | bt8Good N root γ u z} := by
  simpa only [bt8Good,Set.compl_ofPred,not_not,Set.ofPred_and] using
    (r7LowerBarrier_compl_measurable N root γ).compl.inter (bt1R8Good_measurable N root γ u)

theorem bt8ImageBad_measurable (N : Size) (γ u : ℝ) (x : Vertex N) :
    MeasurableSet {y | bt8ImageBad N γ u x y} := by
  unfold bt8ImageBad
  simp only [Set.ofPred_and,Set.ofPred_forall,Set.ofPred_exists]
  refine (measurableSet_le ((measurable_pi_apply x).comp measurable_snd) measurable_const).inter
    ((MeasurableSet.iInter (fun q : ℕ => MeasurableSet.iInter (fun _ => MeasurableSet.iInter (fun _ =>
      measurableSet_le measurable_const (harmonicImageRadius_measurable N x q))))).inter ?_)
  exact MeasurableSet.iUnion (fun q => (MeasurableSet.const _).inter
    ((MeasurableSet.const _).inter (measurableSet_le (harmonicImageRadius_measurable N x q) measurable_const)))

theorem bt8ImageCount_measurable (N : Size) (γ u : ℝ) : Measurable (bt8ImageCount N γ u) :=
  Finset.measurable_sum _ (fun x _ => measurable_const.ite (bt8ImageBad_measurable N γ u x) measurable_const)

theorem bt8ImageCount_le (N : Size) (γ u : ℝ) (y : D.CoareaImage N) :
    bt8ImageCount N γ u y≤ENNReal.ofReal (vertexCount N) := by
  calc
    _ ≤ ∑ _x : Vertex N, (1:ℝ≥0∞) := Finset.sum_le_sum (fun x _ => by split_ifs <;> simp)
    _ = _ := by simp [D.vertexCount_eq_card]

theorem bt8Probe_measurable (N : Size) (root x : Vertex N) (γ : ℝ) :
    MeasurableSet {z | bt8Probe N root x γ z} := by
  unfold bt8Probe
  simp only [Set.ofPred_exists,Set.ofPred_and]
  exact MeasurableSet.iUnion (fun q => ((bt8ContactAt_measurable N root x γ q).preimage
    (measurable_swap.comp measurable_fst)).inter (measurable_snd (r7CoarseProbe_measurable N root x q)))

end TorusCoverTime.Blocks.B
