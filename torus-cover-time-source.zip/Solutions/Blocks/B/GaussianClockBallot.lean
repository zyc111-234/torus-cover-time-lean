import Solutions.Blocks.B.GaussianClockSmoothing
import Solutions.Blocks.C.C4.Base.SurvivalRecurrenceBound
import Mathlib.Analysis.Real.Pi.Bounds

/-! The inverse-square-root discrete survival bound for arbitrary clock tables
whose increments are bounded above and bounded below by one.  A fixed linear
change of field units or a sparse grid provides this normalization. -/

noncomputable section
open MeasureTheory ProbabilityTheory
open scoped ENNReal NNReal
namespace TorusCoverTime.Blocks.B.GaussianClockPath
variable {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
variable {n : ℕ} (W : GaussianClockPath μ n)

theorem survival_half_recurrence (C : ℝ) (hC : 0 ≤ C)
    (hgap : ∀ i j, i ≤ j → (j.val : ℝ) - i.val ≤ W.clock j - W.clock i)
    (hupper : ∀ k : Fin n, 2 * Real.sqrt (W.clock k.succ - W.clock k.castSucc) ≤ C)
    (a : ℝ) (ha : 0 ≤ a) (k : Fin (n + 1)) (hk : 2 ≤ k.val) :
    μ.real (W.survival a k) ≤ μ.real (W.survival a (Blocks.C.C4.halfScaleIndex k)) / 4 +
      4 * (a + C) / Real.sqrt (k.val : ℝ) := by
  let m := Blocks.C.C4.halfScaleIndex k
  let δ : ℝ := (k.val : ℝ) - m.val
  let t := Real.sqrt (2 * Real.pi * δ) / 4
  have hmk : m < k := by change k.val / 2 < k.val; omega
  have hδ : 0 < δ := sub_pos.mpr (by exact_mod_cast hmk)
  have hs : 0 < Real.sqrt (2 * Real.pi * δ) := by positivity
  have ht : 0 < t := by dsimp [t]; positivity
  have hK := add_nonneg ha hC
  have hv (j : Fin n) : W.clock j.castSucc < W.clock j.succ := by
    have hh := hgap j.castSucc j.succ (by change j.val ≤ j.val + 1; omega)
    simp only [Fin.val_succ, Fin.val_castSucc, Nat.cast_add, Nat.cast_one] at hh
    linarith
  have h := W.survival_probability_recurrence m k hmk.le δ hδ (hgap m k hmk.le)
    a C (a + C) t hC ht (W.survivalMoment_le a C ha hv hupper k)
  have hcoef : t / Real.sqrt (2 * Real.pi * δ) = (1 / 4 : ℝ) := by dsimp [t]; field_simp
  rw [hcoef] at h
  have hreal := ENNReal.toReal_mono (by finiteness) h
  rw [ENNReal.toReal_add (by finiteness) ENNReal.ofReal_ne_top, ENNReal.toReal_mul,
    ENNReal.toReal_ofReal (by norm_num : (0 : ℝ) ≤ 1 / 4),
    ENNReal.toReal_ofReal (div_nonneg hK ht.le)] at hreal
  have hkpos : (0 : ℝ) < k.val := by exact_mod_cast (show 0 < k.val by omega)
  have hhalf : 2 * m.val ≤ k.val := by change 2 * (k.val / 2) ≤ k.val; omega
  have hhalfReal : 2 * (m.val : ℝ) ≤ (k.val : ℝ) := by exact_mod_cast hhalf
  have hden : Real.sqrt (k.val : ℝ) ≤ Real.sqrt (2 * Real.pi * δ) := by
    apply Real.sqrt_le_sqrt
    have hpi := Real.pi_gt_three
    dsimp [δ] at hδ ⊢
    nlinarith
  have htail : (a + C) / t ≤ 4 * (a + C) / Real.sqrt (k.val : ℝ) := by
    calc
      _ = 4 * (a + C) / Real.sqrt (2 * Real.pi * δ) := by dsimp [t]; ring
      _ ≤ _ := div_le_div_of_nonneg_left (mul_nonneg (by norm_num) hK)
        (Real.sqrt_pos.mpr hkpos) hden
  change μ.real _ ≤ (1 / 4 : ℝ) * μ.real _ + _ at hreal
  linarith

theorem survival_probability_le (C : ℝ) (hC : 0 ≤ C)
    (hgap : ∀ i j, i ≤ j → (j.val : ℝ) - i.val ≤ W.clock j - W.clock i)
    (hupper : ∀ k : Fin n, 2 * Real.sqrt (W.clock k.succ - W.clock k.castSucc) ≤ C)
    (a : ℝ) (ha : 0 ≤ a) (i : Fin (n + 1)) (hi : 0 < i.val) :
    μ (W.survival a i) ≤ ENNReal.ofReal (8 * (a + C + 1) / Real.sqrt (i.val : ℝ)) := by
  have h := Blocks.C.C4.finite_survival_recurrence_sqrt_bound n
    (fun k => μ.real (W.survival a k)) (a + C) (add_nonneg ha hC)
    (fun _ => measureReal_le_one) (W.survival_half_recurrence C hC hgap hupper a ha) i hi
  rw [← ofReal_measureReal]
  exact ENNReal.ofReal_le_ofReal h

end TorusCoverTime.Blocks.B.GaussianClockPath
