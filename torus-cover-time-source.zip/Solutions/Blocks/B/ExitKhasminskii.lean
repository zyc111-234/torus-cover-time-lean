import Solutions.Blocks.B.ExitExponentialBound
import Solutions.Blocks.B.ExitGreenOccupation

/-! Khasminskii's bound for the actual specified-exit occupation. The Green
bound is needed only on the support of the nonnegative test potential;
harmonic extension proves it everywhere before constructing a supersolution. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

theorem exitPotentialMean_nonneg (N : Size) (D : Finset (Vertex N)) (b : Vertex N)
    (U : Vertex N → ℝ) (hU : ∀ z, 0 ≤ U z) (a : Vertex N) :
    0 ≤ exitPotentialMean N D b U a :=
  integral_nonneg (exitPotentialWeight_nonneg N D b U hU a)

theorem exitPotentialMean_boundary (N : Size) (D : Finset (Vertex N)) (b : Vertex N)
    (U : Vertex N → ℝ) (a : Vertex N) (ha : a ∉ D) :
    exitPotentialMean N D b U a = 0 := by
  simp only [exitPotentialMean, exitPotentialWeight_boundary N D b U a ha, integral_zero]

theorem disk_exitPotentialMean_diagonal (N : Size) (c : Vertex N) (R : ℝ)
    (hR : 0 ≤ R) (hsmall : 2*(R+1) < N.val) (b : Vertex N)
    (U : Vertex N → ℝ) (hU : ∀ z, 0 ≤ U z) (a : Vertex N) (ha : a ∈ torusDisk N c R) :
    U a*exitHarmonic N (torusDisk N c R) b a ≤
      exitPotentialMean N (torusDisk N c R) b U a := by
  rw [disk_exitPotentialMean_green N c R hR hsmall b U hU a]
  calc
    _ ≤ U a*exitHarmonic N (torusDisk N c R) b a*diskGreen N c R a a := by
      exact le_mul_of_one_le_right (mul_nonneg (hU a) (exitHarmonic_nonneg N _ b a))
        (diskGreen_diagonal N c R hR hsmall a ha)
    _ ≤ _ := Finset.single_le_sum (fun z _ => mul_nonneg
      (mul_nonneg (hU z) (exitHarmonic_nonneg N _ b z))
      (domainGreenFromBarrier_nonneg_all N (torusDisk N c R) (diskBarrier N c R)
        (fun x hx => diskBarrier_generator N c R hR hsmall x hx) a z))
        (Finset.mem_univ a)

theorem disk_exitPotentialMean_bound_from_support (N : Size) (c : Vertex N) (R : ℝ)
    (hR : 0 ≤ R) (hsmall : 2*(R+1) < N.val) (b : Vertex N)
    (U : Vertex N → ℝ) (hU : ∀ z, 0 ≤ U z) (K : ℝ) (hK : 0 ≤ K)
    (hbound : ∀ a ∈ torusDisk N c R, U a ≠ 0 →
      exitPotentialMean N (torusDisk N c R) b U a ≤ K*exitHarmonic N (torusDisk N c R) b a)
    (a : Vertex N) : exitPotentialMean N (torusDisk N c R) b U a ≤
      K*exitHarmonic N (torusDisk N c R) b a := by
  let D := torusDisk N c R
  let E := D.filter (fun z => U z = 0)
  let p := exitPotentialMean N D b U
  let h := exitHarmonic N D b
  have hproper : E ≠ Finset.univ := by
    intro he
    exact torusDisk_proper N c R hR hsmall (Finset.eq_univ_of_forall fun z => by
      have hz : z ∈ E := by rw [he]; exact Finset.mem_univ _
      exact (Finset.mem_filter.mp hz).1)
  have hgen : ∀ z ∈ E, generator N ((fun z => K*h z)-p) z = 0 := by
    intro z hz
    obtain ⟨hzD,hzU⟩ := Finset.mem_filter.mp hz
    have hp := disk_exitPotentialMean_generator N c R hR hsmall b U hU z hzD
    rw [hzU, zero_mul] at hp
    rw [generator_sub, generator_mul_left, exitHarmonic_generator N D b z hzD, mul_zero]
    change 0-generator N (exitPotentialMean N D b U) z = 0
    linarith
  have hn := domain_harmonic_nonnegative N E hproper _ hgen (by
    intro z hz
    change 0 ≤ K*h z-p z
    apply sub_nonneg.mpr
    by_cases hzD : z ∈ D
    · exact hbound z hzD (fun hzU => hz (Finset.mem_filter.mpr ⟨hzD,hzU⟩))
    · rw [show p z = 0 from exitPotentialMean_boundary N D b U z hzD]
      exact mul_nonneg hK (exitHarmonic_nonneg N D b z)) a
  exact sub_nonneg.mp hn

theorem disk_exitExpWeight_bound (N : Size) (c : Vertex N) (R : ℝ)
    (hR : 0 ≤ R) (hsmall : 2*(R+1) < N.val) (b : Vertex N)
    (U : Vertex N → ℝ) (hU : ∀ z, 0 ≤ U z) (K θ : ℝ) (hK : 0 ≤ K)
    (hθ : 0 ≤ θ) (hθK : θ*K ≤ 1/2)
    (hpositive : ∀ a ∈ torusDisk N c R, U a ≠ 0 → 0 < exitHarmonic N (torusDisk N c R) b a)
    (hbound : ∀ a ∈ torusDisk N c R, U a ≠ 0 →
      exitPotentialMean N (torusDisk N c R) b U a ≤ K*exitHarmonic N (torusDisk N c R) b a)
    (a : Vertex N) :
    (∫⁻ ω, exitExpWeight N (torusDisk N c R) b U θ a ω ∂walkLaw) ≤
      ENNReal.ofReal (2*exitHarmonic N (torusDisk N c R) b a) := by
  let D := torusDisk N c R
  let p := exitPotentialMean N D b U
  let h := exitHarmonic N D b
  let f := fun z => h z+2*θ*p z
  have hp : ∀ z, 0 ≤ p z := exitPotentialMean_nonneg N D b U hU
  have hh : ∀ z, 0 ≤ h z := exitHarmonic_nonneg N D b
  have hpK : ∀ z, p z ≤ K*h z :=
    disk_exitPotentialMean_bound_from_support N c R hR hsmall b U hU K hK hbound
  have hf : ∀ z, 0 ≤ f z := fun z => add_nonneg (hh z) (mul_nonneg (by positivity) (hp z))
  have hf2 : ∀ z, f z ≤ 2*h z := by
    intro z
    have h1 := mul_le_mul_of_nonneg_left (hpK z) (show 0 ≤ 2*θ by positivity)
    have h2 := mul_le_mul_of_nonneg_right hθK (hh z)
    dsimp only [f]
    nlinarith
  have ht : ∀ z ∈ D, θ*U z < 1 := by
    intro z hz
    by_cases hzU : U z = 0
    · rw [hzU, mul_zero]; norm_num
    · have hd := (disk_exitPotentialMean_diagonal N c R hR hsmall b U hU z hz).trans (hpK z)
      have hUK : U z ≤ K := (mul_le_mul_iff_of_pos_right (hpositive z hz hzU)).mp hd
      exact ((mul_le_mul_of_nonneg_left hUK hθ).trans hθK).trans_lt (by norm_num)
  have hgen : ∀ z ∈ D, -generator N f z = 2*θ*U z*h z := by
    intro z hz
    have hpgen := disk_exitPotentialMean_generator N c R hR hsmall b U hU z hz
    change -generator N (h+(fun z => (2*θ)*p z)) z = _
    rw [generator_add, generator_mul_left, exitHarmonic_generator N D b z hz, zero_add]
    change -(2*θ*generator N (exitPotentialMean N D b U) z) = _
    calc
      _ = (2*θ)*(-generator N (exitPotentialMean N D b U) z) := by ring
      _ = _ := by rw [hpgen]; ring
  have hs : ∀ z ∈ D, (∑ d : Fin 4, f (z+direction N d))/(4*(1-θ*U z)) ≤ f z := by
    intro z hz
    have hg := hgen z hz
    simp only [generator, Finset.sum_sub_distrib, Finset.sum_const, Finset.card_univ,
      Fintype.card_fin, nsmul_eq_mul, Nat.cast_ofNat] at hg
    have hhf := mul_le_mul_of_nonneg_left (hf2 z) (mul_nonneg hθ (hU z))
    apply (div_le_iff₀ (by have := ht z hz; positivity : 0 < 4*(1-θ*U z))).mpr
    nlinarith
  have hb : ∀ z, z ∉ D → (if z = b then 1 else 0) ≤ f z := by
    intro z hz
    dsimp only [f,h,p]
    rw [exitPotentialMean_boundary N D b U z hz, mul_zero, add_zero,
      exitHarmonic_boundary N D b z hz]
  exact (exitExpWeight_lintegral_bound N D b U θ f hf hb ht hs a).trans
    (ENNReal.ofReal_le_ofReal (hf2 a))

end TorusCoverTime.Blocks.B
