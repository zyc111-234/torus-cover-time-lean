import Solutions.Blocks.B.FourierRowEstimates
import Solutions.Blocks.B.GreenDiagonal

/-! Exact centered frequency cutoffs and oscillatory tails. -/

noncomputable section
open scoped BigOperators
namespace TorusCoverTime.Blocks.B

def centeredCore (N : Size) (m : ℕ) : Finset (ZMod N.val) :=
  Finset.univ.filter (fun a => coordinateDistance a 0 ≤ (m : ℝ))

@[simp] theorem mem_centeredCore (N : Size) (m : ℕ) (a : ZMod N.val) :
    a ∈ centeredCore N m ↔ coordinateDistance a 0 ≤ (m : ℝ) := by simp [centeredCore]

theorem sum_range_initial_cutoff {α : Type*} [AddCommMonoid α]
    (n m : ℕ) (hmn : m ≤ n) (F : ℕ → α) :
    (∑ j ∈ Finset.range n, if j < m then F j else 0) = ∑ j ∈ Finset.range m, F j := by
  rw [← Finset.sum_filter]
  congr 1
  ext j
  simp only [Finset.mem_filter, Finset.mem_range]
  omega

theorem sum_centeredCore_complex (N : Size) (m : ℕ) (hm : m ≤ (N.val - 1) / 2)
    (F : ZMod N.val → ℂ) :
    (∑ a ∈ centeredCore N m, F a) = F 0 +
      (∑ j ∈ Finset.range m, F ((j + 1 : ℕ) : ZMod N.val)) +
      (∑ j ∈ Finset.range m, F (-((j + 1 : ℕ) : ZMod N.val))) := by
  unfold centeredCore
  rw [Finset.sum_filter, sum_zmod_centered_complex]
  have hz : coordinateDistance (0 : ZMod N.val) 0 ≤ (m : ℝ) := by
    simp [coordinateDistance]
  rw [if_pos hz]
  have hs (n : ℕ) (hn : n ≤ N.val / 2) (hmn : m ≤ n) (neg : Bool) :
      (∑ j ∈ Finset.range n, if coordinateDistance
        (if neg then -((j+1 : ℕ) : ZMod N.val) else ((j+1 : ℕ) : ZMod N.val)) 0 ≤ (m : ℝ)
          then F (if neg then -((j+1 : ℕ) : ZMod N.val) else ((j+1 : ℕ) : ZMod N.val)) else 0) =
      ∑ j ∈ Finset.range m,
        F (if neg then -((j+1 : ℕ) : ZMod N.val) else ((j+1 : ℕ) : ZMod N.val)) := by
    convert sum_range_initial_cutoff n m hmn (fun j =>
      F (if neg then -((j+1 : ℕ) : ZMod N.val) else ((j+1 : ℕ) : ZMod N.val))) using 1
    apply Finset.sum_congr rfl
    intro j hj
    have hjn : j + 1 ≤ N.val / 2 := by have := Finset.mem_range.mp hj; omega
    have hd : coordinateDistance
        (if neg then -((j+1 : ℕ) : ZMod N.val) else ((j+1 : ℕ) : ZMod N.val)) 0 = (j : ℝ) + 1 := by
      cases neg <;> simp only [Bool.false_eq_true, ↓reduceIte, coordinateDistance_neg_zero]
        <;> rw [coordinateDistance_natCast_half N _ hjn, Nat.cast_add, Nat.cast_one]
    rw [hd]
    have he : (j : ℝ) + 1 ≤ (m : ℝ) ↔ j < m := by
      rw [← Nat.cast_one, ← Nat.cast_add, Nat.cast_le]
      omega
    simp only [he]
  rw [show (∑ j ∈ Finset.range (N.val / 2),
      if coordinateDistance ((j+1 : ℕ) : ZMod N.val) 0 ≤ (m : ℝ)
        then F ((j+1 : ℕ) : ZMod N.val) else 0) =
      ∑ j ∈ Finset.range m, F ((j+1 : ℕ) : ZMod N.val) from
        hs (N.val / 2) le_rfl (by omega) false]
  exact congrArg (fun v => F 0 + (∑ j ∈ Finset.range m, F ((j+1 : ℕ) : ZMod N.val)) + v)
    (hs ((N.val - 1) / 2) (by omega) hm true)

theorem sum_centeredCore_real (N : Size) (m : ℕ) (hm : m ≤ (N.val - 1) / 2)
    (F : ZMod N.val → ℝ) :
    (∑ a ∈ centeredCore N m, F a) = F 0 +
      (∑ j ∈ Finset.range m, F ((j + 1 : ℕ) : ZMod N.val)) +
      (∑ j ∈ Finset.range m, F (-((j + 1 : ℕ) : ZMod N.val))) := by
  have h := congrArg Complex.re (sum_centeredCore_complex N m hm (fun a => (F a : ℂ)))
  simpa only [← Complex.ofReal_sum, Complex.add_re, Complex.ofReal_re] using h

theorem centeredCore_card (N : Size) (m : ℕ) (hm : m ≤ (N.val - 1) / 2) :
    ((centeredCore N m).card : ℝ) = 2 * m + 1 := by
  have h := sum_centeredCore_real N m hm (fun _ => (1 : ℝ))
  simp only [Finset.sum_const, Finset.card_range, nsmul_eq_mul, mul_one] at h
  linarith

theorem sum_centeredCore_distance (N : Size) (m : ℕ) (hm : m ≤ (N.val - 1) / 2)
    (f : ℝ → ℝ) :
    (∑ a ∈ centeredCore N m, f (coordinateDistance a 0)) = symmetricCoordinateSum m f := by
  rw [sum_centeredCore_real N m hm]
  have hterm (j : ℕ) (hj : j ∈ Finset.range m) :
      coordinateDistance ((j+1 : ℕ) : ZMod N.val) 0 = (j : ℝ) + 1 := by
    rw [coordinateDistance_natCast_half N _ (by have := Finset.mem_range.mp hj; omega),
      Nat.cast_add, Nat.cast_one]
  simp_rw [coordinateDistance_neg_zero]
  rw [Finset.sum_congr rfl (fun j hj => congrArg f (hterm j hj))]
  have hz : coordinateDistance (0 : ZMod N.val) 0 = 0 := by simp [coordinateDistance]
  rw [hz, symmetricCoordinateSum]
  ring

theorem sum_range_sub_initial {α : Type*} [AddCommGroup α]
    (n m : ℕ) (hmn : m ≤ n) (F : ℕ → α) :
    (∑ j ∈ Finset.range n, F j) - (∑ j ∈ Finset.range m, F j) =
      ∑ j ∈ Finset.range (n-m), F (m+j) := by
  have h := Finset.sum_range_add F m (n-m)
  rw [Nat.add_sub_of_le hmn] at h
  rw [h]
  abel

theorem sum_zmod_sub_centeredCore_complex (N : Size) (m : ℕ) (hm : m ≤ (N.val - 1) / 2)
    (F : ZMod N.val → ℂ) :
    (∑ a, F a) - (∑ a ∈ centeredCore N m, F a) =
      (∑ j ∈ Finset.range (N.val / 2 - m), F ((m+j+1 : ℕ) : ZMod N.val)) +
      (∑ j ∈ Finset.range ((N.val - 1) / 2 - m), F (-((m+j+1 : ℕ) : ZMod N.val))) := by
  rw [sum_zmod_centered_complex, sum_centeredCore_complex N m hm]
  have hp := sum_range_sub_initial (N.val / 2) m (by omega) (fun j => F ((j+1 : ℕ) : ZMod N.val))
  have hn := sum_range_sub_initial ((N.val - 1) / 2) m hm (fun j => F (-((j+1 : ℕ) : ZMod N.val)))
  linear_combination hp + hn

theorem sum_zmod_sub_centeredCore_real (N : Size) (m : ℕ) (hm : m ≤ (N.val - 1) / 2)
    (F : ZMod N.val → ℝ) :
    (∑ a, F a) - (∑ a ∈ centeredCore N m, F a) =
      (∑ j ∈ Finset.range (N.val / 2 - m), F ((m+j+1 : ℕ) : ZMod N.val)) +
      (∑ j ∈ Finset.range ((N.val - 1) / 2 - m), F (-((m+j+1 : ℕ) : ZMod N.val))) := by
  have h := congrArg Complex.re (sum_zmod_sub_centeredCore_complex N m hm (fun a => (F a : ℂ)))
  simpa only [← Complex.ofReal_sum, Complex.add_re, Complex.sub_re, Complex.ofReal_re] using h

theorem quadratic_geometric_tail_bound (b : ℝ) (m n : ℕ) (z : ℂ)
    (hz : ‖z‖ = 1) (hz1 : z ≠ 1) :
    ‖∑ j ∈ Finset.range n,
      ((1 / (b ^ 2 + (((m+j : ℕ) : ℝ) + 1) ^ 2) : ℝ) : ℂ) * z ^ (m+j+1)‖ ≤
        2 / (((m : ℝ) + 1) ^ 2 * ‖z - 1‖) := by
  let f : ℕ → ℝ := fun j => 1 / (b ^ 2 + (((m+j : ℕ) : ℝ) + 1) ^ 2)
  have hf (j) : 0 ≤ f j := by dsimp [f]; positivity
  have ha : Antitone f := by
    intro i j hij
    dsimp [f]
    apply one_div_le_one_div_of_le (by positivity)
    have hijr : (i : ℝ) ≤ j := by exact_mod_cast hij
    simp only [Nat.cast_add]
    nlinarith [Nat.cast_nonneg (α := ℝ) m, Nat.cast_nonneg (α := ℝ) i]
  have he : (∑ j ∈ Finset.range n, (f j : ℂ) * z ^ (m+j+1)) =
      z ^ (m+1) * (∑ j ∈ Finset.range n, (f j : ℂ) * z ^ j) := by
    rw [Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro j _
    rw [show m+j+1 = (m+1)+j by omega, pow_add]
    ring
  change ‖∑ j ∈ Finset.range n, (f j : ℂ) * z ^ (m+j+1)‖ ≤ _
  rw [he, norm_mul, norm_pow, hz, one_pow, one_mul]
  apply (norm_antitone_geometric_sum f z hf ha hz hz1 n).trans
  have hf0 : f 0 ≤ 1 / ((m : ℝ) + 1)^2 := by
    dsimp [f]
    exact one_div_le_one_div_of_le (by positivity) (le_add_of_nonneg_left (sq_nonneg b))
  calc
    2 * f 0 / ‖z - 1‖ ≤ 2 * (1 / ((m : ℝ) + 1)^2) / ‖z - 1‖ := by gcongr
    _ = _ := by simp only [div_eq_mul_inv, mul_inv_rev]; ring

end TorusCoverTime.Blocks.B
