import Solutions.Blocks.B.DiskGeometry
import Mathlib.Data.Int.Interval

/-! Radius-only cardinality estimates for Euclidean disks, uniformly in torus size. -/

noncomputable section
open Classical
namespace TorusCoverTime.Blocks.B

lemma centeredLift_box_mem (N : Size) (y : Vertex N) (R : ℝ)
    (x : Vertex N) (hx : x ∈ torusDisk N y R) :
    centeredLift N y x ∈ (Finset.Icc (-⌊R⌋) ⌊R⌋ ×ˢ Finset.Icc (-⌊R⌋) ⌊R⌋) := by
  have hb := latticeRadius_coordinates (centeredLift N y x)
  rw [latticeRadius_centeredLift] at hb
  have hxr := (mem_torusDisk N y x R).mp hx
  have hm (z : ℤ) (hz : |(z : ℝ)| ≤ periodicDistance x y) :
      z ∈ Finset.Icc (-⌊R⌋) ⌊R⌋ := by
    apply Finset.mem_Icc.mpr
    have hu : z ≤ ⌊R⌋ := Int.le_floor.mpr ((le_abs_self _).trans (hz.trans hxr.le))
    have hl : -z ≤ ⌊R⌋ := Int.le_floor.mpr (by
      simpa only [Int.cast_neg] using (neg_le_abs _).trans (hz.trans hxr.le))
    exact ⟨by omega, hu⟩
  exact Finset.mem_product.mpr ⟨hm _ hb.1, hm _ hb.2⟩

lemma torusDisk_card_le (N : Size) (y : Vertex N) (R : ℝ) (hR : 0 ≤ R) :
    ((torusDisk N y R).card : ℝ) ≤ (2*R+1)^2 := by
  let L : ℤ := ⌊R⌋
  let I := Finset.Icc (-L) L
  have hL : 0 ≤ L := Int.floor_nonneg.mpr hR
  have hcard : (torusDisk N y R).card ≤ (I ×ˢ I).card := by
    apply Finset.card_le_card_of_injOn (centeredLift N y)
    · exact centeredLift_box_mem N y R
    · exact (centeredLift_injective N y).injOn
  have hI : (I.card : ℝ) = 2*(L : ℝ)+1 := by
    have hi : (I.card : ℤ) = L+1- -L := Int.card_Icc_of_le (-L) L (by omega)
    have hr : (I.card : ℝ) = (L : ℝ)+1- -(L : ℝ) := by exact_mod_cast hi
    linarith
  have hb : ((torusDisk N y R).card : ℝ) ≤ (2*(L : ℝ)+1)^2 := by
    have hc : ((torusDisk N y R).card : ℝ) ≤ ((I ×ˢ I).card : ℝ) := by
      exact_mod_cast hcard
    simpa only [Finset.card_product, Nat.cast_mul, hI, pow_two] using hc
  apply hb.trans
  have hfloor : (L : ℝ) ≤ R := Int.floor_le _
  have hLr : (0 : ℝ) ≤ L := by exact_mod_cast hL
  gcongr

lemma torusDisk_card_quadratic (N : Size) (y : Vertex N) (R : ℝ) (hR : 1 ≤ R) :
    ((torusDisk N y R).card : ℝ) ≤ 9*R^2 := by
  have hb := torusDisk_card_le N y R (by linarith)
  have hs : (2*R+1)^2 ≤ (3*R)^2 := by gcongr; linarith
  nlinarith

end TorusCoverTime.Blocks.B
