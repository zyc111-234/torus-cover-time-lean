import Solutions.Blocks.B.DirichletConditionedBridge

noncomputable section
open MeasureTheory ProbabilityTheory
open scoped BigOperators
namespace TorusCoverTime.Blocks.B

def bt6ResidualSquare (N : Size) (root : Vertex N) (E : Finset (Vertex N)) (x : Vertex N)
    (q : ℕ) (t : ℝ) (ξ : FiniteFieldSample N) : ℝ :=
  ∑ z, exitHarmonic N (torusDisk N x (Real.exp ((q:ℝ)+1))) z x*
    (dirichletResidualAtEndpoint N root (torusDisk N x (Real.exp ((q:ℝ)+1))) E x t ξ z)^2

theorem bt6ResidualSquare_nonneg (N : Size) (root : Vertex N) (E : Finset (Vertex N))
    (x : Vertex N) (q : ℕ) (t : ℝ) (ξ : FiniteFieldSample N) : 0≤bt6ResidualSquare N root E x q t ξ :=
  Finset.sum_nonneg (fun z _ => mul_nonneg (exitHarmonic_nonneg N _ z x) (sq_nonneg _))

def bt6ResidualFailure (N : Size) (root : Vertex N) (E : Finset (Vertex N))
    (x : Vertex N) (M : ℕ) (t : ℝ) : Set (FiniteFieldSample N) :=
  {ξ | ∃ q : ℕ, 1≤q ∧ q≤M ∧ dirichletResidualLogScaleConstant*(q:ℝ)*(Real.log (logSize N))^2≤
    bt6ResidualSquare N root E x q t ξ}

theorem bt6ResidualFailure_bound (N : Size) (root c x : Vertex N) (R : ℝ) (M : ℕ)
    (hsmall : 2*(R+1)<N.val) (hroot : root∉torusDisk N c R)
    (hdeep : periodicDistance x c+(Real.exp ((M:ℝ)+1)+1)≤R/2)
    (hV : 0<dirichletClockLS N root (torusDisk N c R) x)
    (hM : (M:ℝ)≤logSize N) (t : ℝ) (ht : |t|≤12*dirichletClockLS N root (torusDisk N c R) x) :
    (finiteFieldLaw N).real (bt6ResidualFailure N root (torusDisk N c R) x M t)≤
      dirichletResidualTailConstant 12*Real.exp (-((Real.log (logSize N))^2)/2) := by
  have hh := dirichlet_residual_integer_scales (I := Fin M) N root c x R (fun i => i.val+1)
    (fun i => by omega) hsmall hroot (fun i => ?_) hV (logSize N) 12 t (logSize_pos N)
    (by simpa only [Fintype.card_fin] using hM) ht
  · refine (measureReal_mono (μ := finiteFieldLaw N) ?_).trans hh
    rintro ξ ⟨q,hq,hqM,hbad⟩
    let i : Fin M := ⟨q-1,by omega⟩
    refine ⟨i,?_⟩
    have he : i.val+1=q := by dsimp [i]; omega
    simpa only [he,bt6ResidualSquare] using hbad
  · have hi : ((i.val+1:ℕ):ℝ)≤M := by exact_mod_cast (show i.val+1≤M by have := i.isLt; omega)
    have he := Real.exp_le_exp.mpr (show ((i.val+1:ℕ):ℝ)+1≤M+1 by linarith)
    linarith

def bt6BridgeError (L C η : ℝ) : ℝ :=
  dirichletResidualLogScaleConstant*(Real.log L)^2+4*Real.sqrt 2*C+Real.log L+2*η

theorem bt6BridgeError_bounds (L C η : ℝ) (hL : 1≤L) (hC : 0≤C) (hη : 0≤η) :
    0≤bt6BridgeError L C η ∧
      dirichletResidualLogScaleConstant*(Real.log L)^2≤bt6BridgeError L C η ∧
      4*Real.sqrt 2*C+Real.log L+2*η≤bt6BridgeError L C η := by
  have hp := dirichletLogError_pos
  have hc : 0≤dirichletResidualLogScaleConstant := by
    unfold dirichletResidualLogScaleConstant
    have hl : 0≤Real.log 3 := Real.log_nonneg (by norm_num)
    positivity
  have hl := Real.log_nonneg hL
  unfold bt6BridgeError
  constructor
  · positivity
  constructor
  · have hh : 0≤4*Real.sqrt 2*C := by positivity
    linarith
  · have hh : 0≤dirichletResidualLogScaleConstant*(Real.log L)^2 := by positivity
    linarith

end TorusCoverTime.Blocks.B
