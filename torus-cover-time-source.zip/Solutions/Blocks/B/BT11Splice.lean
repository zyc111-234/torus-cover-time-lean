import Solutions.Blocks.B.BT11Translation
import Solutions.Blocks.A.TimeDisintegration
import Solutions.Blocks.A.ConditionalKernel

/-! Occupation at a deterministic-time splice, with the original physical clock. -/
noncomputable section
open MeasureTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

theorem bt11_glue_localTime_past (N : Size) (a x : Vertex N) (n : ℕ)
    {p : A.WalkPrefix n} (hp : ∀ j,0<(p j).1) (s : ℝ) (hs : A.prefixTime n p≤s)
    {η : WalkSample} (hη : ∀ j,0<(η j).1) (hnon : Tendsto (jumpTime η) atTop atTop) :
    localTime N a (A.glueAt n p s η) s x=
      localTime N a (A.glueAt n p s A.regularSample) s x := by
  apply setIntegral_congr_fun measurableSet_Icc
  intro t ht
  dsimp only
  rw [A.glueAt_history_eq N a n hp s hs hη A.regularSample_spec.1 hnon t ht]

theorem bt11_glue_localTime_add (N : Size) (a x : Vertex N) (n : ℕ)
    {p : A.WalkPrefix n} (hp : ∀ j,0<(p j).1) (s : ℝ) (hs : A.prefixTime n p≤s)
    {η : WalkSample} (hη : ∀ j,0<(η j).1) (hnon : Tendsto (jumpTime η) atTop atTop)
    (T : ℝ) (hT : 0≤T) :
    localTime N a (A.glueAt n p s η) (s+T) x=
      localTime N a (A.glueAt n p s A.regularSample) s x+
        localTime N (A.prefixPosition N a n p) η T x := by
  rw [localTime_add_shift N a x _ s T ((A.prefixTime_nonneg n p).trans hs) hT,
    bt11_glue_localTime_past N a x n hp s hs hη hnon]
  congr 1
  apply setIntegral_congr_fun measurableSet_Icc
  intro t ht
  dsimp only
  rw [A.walk_glueAt_future N a n hp s hs hη hnon t ht.1]

theorem bt11_glue_bad_past (N : Size) (a : Vertex N) (n : ℕ)
    {p : A.WalkPrefix n} (hp : ∀ j,0<(p j).1) (s : ℝ) (hs : A.prefixTime n p≤s)
    {η : WalkSample} (hη : ∀ j,0<(η j).1) (hnon : Tendsto (jumpTime η) atTop atTop)
    (u ξ : ℝ) :
    A.glueAt n p s η∈bt11Bad N a u ξ s ↔ A.glueAt n p s A.regularSample∈bt11Bad N a u ξ s := by
  have he : softSet N a (A.glueAt n p s η) u s=softSet N a (A.glueAt n p s A.regularSample) u s := by
    ext x
    simp only [softSet,Finset.mem_filter,bt11_glue_localTime_past N a x n hp s hs hη hnon]
  simp only [bt11Bad,bt10DefectCount,mem_setOf_eq,he]

end TorusCoverTime.Blocks.B
