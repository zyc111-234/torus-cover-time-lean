import Solutions.Blocks.B.ExitHitKernel
import Solutions.Blocks.B.DiskBarrier

/-! Finite-domain Green representation with the actual exit harmonic measure.
The small-disk specialization uses the proved quadratic barrier and includes
the exact finite-torus correction. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

theorem punctured_harmonic_representation (N : Size) (D : Finset (Vertex N)) (x : Vertex N)
    (f : Vertex N → ℝ) (hb : ∀ a, a ∉ D → f a = 0)
    (hf : ∀ a ∈ D, a ≠ x → generator N f a = 0) :
    f = fun a => f x * exitHarmonic N (D.erase x) x a := by
  have hproper : D.erase x ≠ Finset.univ := by
    intro he
    have hh : x ∈ D.erase x := by rw [he]; exact Finset.mem_univ _
    simpa using hh
  apply domain_harmonic_unique N (D.erase x) hproper
  · intro a ha
    rw [exitHarmonic_boundary N (D.erase x) x a ha]
    by_cases hax : a = x
    · simp [hax]
    · have haD : a ∉ D := fun h => ha (Finset.mem_erase.mpr ⟨hax, h⟩)
      rw [if_neg hax, mul_zero, hb a haD]
  · intro a ha
    rw [hf a (Finset.mem_erase.mp ha).2 (Finset.mem_erase.mp ha).1,
      generator_mul_left, exitHarmonic_generator N (D.erase x) x a ha, mul_zero]

def domainGreenFromBarrier (N : Size) (D : Finset (Vertex N)) (b : Vertex N → ℝ)
    (x y : Vertex N) : ℝ := greenKernel N x y - exitExtension N D (fun z => greenKernel N z y) x +
      (1 / vertexCount N) * (b x - exitExtension N D b x)

theorem domainGreenFromBarrier_boundary (N : Size) (D : Finset (Vertex N)) (b : Vertex N → ℝ)
    (x y : Vertex N) (hx : x ∉ D) : domainGreenFromBarrier N D b x y = 0 := by
  simp only [domainGreenFromBarrier, exitExtension_boundary N D _ x hx, sub_self, mul_zero, add_zero]

theorem domainGreenFromBarrier_generator (N : Size) (D : Finset (Vertex N)) (b : Vertex N → ℝ)
    (hb : ∀ x ∈ D, -generator N b x = 1) (x y : Vertex N) (hx : x ∈ D) :
    -generator N (fun z => domainGreenFromBarrier N D b z y) x = if x = y then 1 else 0 := by
  have hg := greenKernel_generator N x y
  have hbar := hb x hx
  change -generator N (((fun z => greenKernel N z y) - exitExtension N D (fun z => greenKernel N z y)) +
    (fun z => (1 / vertexCount N) * (b - exitExtension N D b) z)) x = _
  rw [generator_add, generator_sub, generator_mul_left, generator_sub,
    exitExtension_generator N D _ x hx, exitExtension_generator N D _ x hx]
  rw [show generator N b x = -1 by linarith]
  linarith

theorem domainGreenFromBarrier_hit (N : Size) (D : Finset (Vertex N)) (b : Vertex N → ℝ)
    (hb : ∀ x ∈ D, -generator N b x = 1) (y : Vertex N) :
    (fun x => domainGreenFromBarrier N D b x y) =
      fun x => domainGreenFromBarrier N D b y y * exitHarmonic N (D.erase y) y x := by
  apply punctured_harmonic_representation
  · intro a ha
    exact domainGreenFromBarrier_boundary N D b a y ha
  · intro a ha hay
    have h := domainGreenFromBarrier_generator N D b hb a y ha
    rw [if_neg hay] at h
    linarith

theorem domainGreenFromBarrier_diagonal (N : Size) (D : Finset (Vertex N)) (b : Vertex N → ℝ)
    (hb : ∀ x ∈ D, -generator N b x = 1) (y : Vertex N) (hy : y ∈ D) :
    1 ≤ domainGreenFromBarrier N D b y y := by
  let h := exitHarmonic N (D.erase y) y
  have hroot : h y = 1 := by
    dsimp [h]
    rw [exitHarmonic_boundary N (D.erase y) y y (by simp), if_pos rfl]
  have hsum0 : 0 ≤ ∑ d : Fin 4, h (y + direction N d) :=
    Finset.sum_nonneg fun d _ => exitHarmonic_nonneg N (D.erase y) y _
  have hsum1 : (∑ d : Fin 4, h (y + direction N d)) ≤ 4 := by
    calc
      _ ≤ ∑ _d : Fin 4, (1 : ℝ) := Finset.sum_le_sum fun d _ => exitHarmonic_le_one N (D.erase y) y _
      _ = 4 := by simp
  have he := domainGreenFromBarrier_generator N D b hb y y hy
  rw [domainGreenFromBarrier_hit N D b hb y, generator_mul_left, if_pos rfl] at he
  have hh : generator N h y = (∑ d : Fin 4, h (y + direction N d)) / 4 - 1 := by
    simp only [generator, hroot, Finset.sum_sub_distrib, Finset.sum_const,
      Finset.card_univ, Fintype.card_fin, nsmul_eq_mul, Nat.cast_ofNat]
    ring
  change -(domainGreenFromBarrier N D b y y * generator N h y) = 1 at he
  rw [hh] at he
  have hp : 0 < domainGreenFromBarrier N D b y y := by
    by_contra hn
    have hm := mul_nonpos_of_nonpos_of_nonneg (not_lt.mp hn)
      (show 0 ≤ 1 - (∑ d : Fin 4, h (y + direction N d)) / 4 by linarith)
    nlinarith
  nlinarith [mul_nonneg hp.le hsum0]

theorem domainGreenFromBarrier_nonneg (N : Size) (D : Finset (Vertex N)) (b : Vertex N → ℝ)
    (hb : ∀ x ∈ D, -generator N b x = 1) (x y : Vertex N) (hy : y ∈ D) :
    0 ≤ domainGreenFromBarrier N D b x y := by
  have h := congrFun (domainGreenFromBarrier_hit N D b hb y) x
  rw [h]
  exact mul_nonneg (zero_le_one.trans (domainGreenFromBarrier_diagonal N D b hb y hy))
    (exitHarmonic_nonneg N (D.erase y) y x)

theorem domainGreenFromBarrier_hit_ratio (N : Size) (D : Finset (Vertex N)) (b : Vertex N → ℝ)
    (hb : ∀ x ∈ D, -generator N b x = 1) (x y : Vertex N) (hy : y ∈ D) :
    exitHarmonic N (D.erase y) y x = domainGreenFromBarrier N D b x y / domainGreenFromBarrier N D b y y := by
  have hp : 0 < domainGreenFromBarrier N D b y y :=
    zero_lt_one.trans_le (domainGreenFromBarrier_diagonal N D b hb y hy)
  apply (eq_div_iff hp.ne').mpr
  rw [congrFun (domainGreenFromBarrier_hit N D b hb y) x]
  ring

def diskGreen (N : Size) (c : Vertex N) (R : ℝ) (x y : Vertex N) : ℝ :=
  domainGreenFromBarrier N (torusDisk N c R) (diskBarrier N c R) x y

theorem diskGreen_generator (N : Size) (c : Vertex N) (R : ℝ) (hR : 0 ≤ R)
    (hsmall : 2 * (R + 1) < N.val) (x y : Vertex N) (hx : x ∈ torusDisk N c R) :
    -generator N (fun z => diskGreen N c R z y) x = if x = y then 1 else 0 :=
  domainGreenFromBarrier_generator N _ _ (fun a ha => diskBarrier_generator N c R hR hsmall a ha) x y hx

theorem diskGreen_diagonal (N : Size) (c : Vertex N) (R : ℝ) (hR : 0 ≤ R)
    (hsmall : 2 * (R + 1) < N.val) (y : Vertex N) (hy : y ∈ torusDisk N c R) :
    1 ≤ diskGreen N c R y y :=
  domainGreenFromBarrier_diagonal N _ _ (fun a ha => diskBarrier_generator N c R hR hsmall a ha) y hy

theorem disk_exactExit_hit_ratio (N : Size) (c : Vertex N) (R : ℝ) (hR : 0 ≤ R)
    (hsmall : 2 * (R + 1) < N.val) (a b x : Vertex N) (hx : x ∈ torusDisk N c R) :
    (exactExitLaw N (torusDisk N c R) a b).real (visitsBeforeExit N (torusDisk N c R) a x) =
      (diskGreen N c R a x / diskGreen N c R x x) *
        exitHarmonic N (torusDisk N c R) b x / exitHarmonic N (torusDisk N c R) b a := by
  rw [exactExitLaw_visit_formula N (torusDisk N c R) a b x hx,
    domainGreenFromBarrier_hit_ratio N _ _
      (fun z hz => diskBarrier_generator N c R hR hsmall z hz) a x hx]
  rfl

end TorusCoverTime.Blocks.B
