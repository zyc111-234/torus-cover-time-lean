import Solutions.Blocks.B.CapacityVariational

/-! The finite maximum principle and every charge clause of CapacitySpectrum. -/

noncomputable section
open scoped BigOperators
namespace TorusCoverTime.Blocks.B

lemma generator_at_max_nonpos (N : Size) (f : Vertex N → ℝ) (x : Vertex N)
    (hx : ∀ y, f y ≤ f x) : generator N f x ≤ 0 := by
  unfold generator
  exact mul_nonpos_of_nonneg_of_nonpos (by norm_num)
    (Finset.sum_nonpos (fun d _ => sub_nonpos.mpr (hx _)))

lemma greenCharge_potential_le_one (N : Size) (A : Finset (Vertex N))
    (hne : A.Nonempty) (hA : A ≠ Finset.univ) (q : Vertex N → ℝ)
    (hq : greenChargeEquation N A q) : ∀ x, greenOperator N q x ≤ 1 := by
  obtain ⟨z, _, hz⟩ := Finset.exists_max_image (Finset.univ : Finset (Vertex N))
    (greenOperator N q) Finset.univ_nonempty
  have hmax : ∀ x, greenOperator N q x ≤ greenOperator N q z :=
    fun x => hz x (Finset.mem_univ x)
  have hzA : z ∈ A := by
    by_contra hzA
    have hgen := greenOperator_generator N q z
    rw [hq.1 z hzA, zero_sub] at hgen
    have hgenle := generator_at_max_nonpos N (greenOperator N q) z hmax
    have hmeanpos : 0 < spatialMean N q :=
      div_pos (greenCharge_sum_pos N A hne hA q hq) (vertexCount_pos N)
    linarith
  intro x
  calc
    greenOperator N q x ≤ greenOperator N q z := hmax x
    _ = 1 := hq.2 z hzA

lemma greenCharge_lower_bound (N : Size) (A : Finset (Vertex N))
    (hne : A.Nonempty) (hA : A ≠ Finset.univ) (q : Vertex N → ℝ)
    (hq : greenChargeEquation N A q) (x : Vertex N) (hx : x ∈ A) :
    capacity N A / vertexCount N ≤ q x := by
  have hmax : ∀ y, greenOperator N q y ≤ greenOperator N q x := by
    rw [show greenOperator N q x = 1 from hq.2 x hx]
    exact greenCharge_potential_le_one N A hne hA q hq
  have hgenle := generator_at_max_nonpos N (greenOperator N q) x hmax
  have hgen := greenOperator_generator N q x
  rw [capacity_eq_charge N A q hq]
  change spatialMean N q ≤ q x
  linarith

lemma capacity_charge_properties (N : Size) (A : Finset (Vertex N))
    (hne : A.Nonempty) (hA : A ≠ Finset.univ) :
    ∃ q : Vertex N → ℝ, greenChargeEquation N A q ∧
      (∀ q', greenChargeEquation N A q' → q' = q) ∧ (∑ x, q x) = capacity N A ∧
      (∀ x ∈ A, capacity N A / vertexCount N ≤ q x) ∧
      (∀ x, (∑ y, greenKernel N x y * q y) ≤ 1) ∧
      spatialMean N (fun x => ∑ y, greenKernel N x y * q y) = 0 ∧
      energy N (fun x => ∑ y, greenKernel N x y * q y) = capacity N A ∧
      (∀ f, IsCapacityMinimizer N A f → f = fun x => ∑ y, greenKernel N x y * q y) ∧
      (∀ x, 0 ≤ q x / capacity N A) ∧ (∑ x, q x / capacity N A) = 1 := by
  obtain ⟨q, hq⟩ := exists_greenCharge N A hA
  have hcap := capacity_pos N A hne hA
  have hcharge := greenCharge_lower_bound N A hne hA q hq
  refine ⟨q, hq, (fun q' hq' => greenCharge_unique N A hA q' q hq' hq),
    (capacity_eq_charge N A q hq).symm, hcharge,
    greenCharge_potential_le_one N A hne hA q hq, greenOperator_mean_zero N q,
    (greenCharge_is_minimizer N A q hq).2.2,
    (fun f hf => capacity_minimizer_unique N A q f hq hf), ?_, ?_⟩
  · intro x
    apply div_nonneg _ hcap.le
    by_cases hx : x ∈ A
    · exact (div_pos hcap (vertexCount_pos N)).le.trans (hcharge x hx)
    · rw [hq.1 x hx]
  · rw [← Finset.sum_div, ← capacity_eq_charge N A q hq, div_self hcap.ne']

end TorusCoverTime.Blocks.B
