import Solutions.Blocks.B.BT11LoopWindow

/-! Recover the fixed earliest time from a fixed positive closing window,
then the original probability-internal time supremum and all starting vertices. -/
noncomputable section
open MeasureTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

theorem bt11_closing_window_tendsto (u η W : ℝ) (hu : 0≤u) (hη : 0<η) (hW : 0≤W) :
    Tendsto (fun N : Size => r7LoopEventMass N
      (fun a => {z | (η/2)*Real.sqrt (logSize N)<bt10DefectCount N a (u+1) z})
      (phaseACenter N-W*timeScale N+bt11ShortTime N)
      (phaseACenter N-W*timeScale N+2*bt11ShortTime N)) atTop (𝓝 0) := by
  apply bt10_actual_conclusion (u+1) (by linarith) (W+1) (η/2) (by linarith) (by linarith)
  apply Eventually.of_forall
  intro N
  have hT := timeScale_pos N
  dsimp only [bt11ShortTime]
  refine ⟨by linarith,by nlinarith,by nlinarith [mul_nonneg hW hT.le]⟩

theorem bt11_fixed_time_tendsto (hWalk : WalkModelRegular) (u η W : ℝ)
    (hu : 0≤u) (hη : 0<η) (hW : 0≤W) :
    Tendsto (fun N : Size => walkLaw (bt11Bad N 0 u η (phaseACenter N-W*timeScale N))) atTop (𝓝 0) := by
  have hloop := ENNReal.Tendsto.const_mul (a := 65536)
    (bt11_closing_window_tendsto u η W hu hη hW) (Or.inr (by norm_num))
  have hnear := ENNReal.tendsto_ofReal ((point_near_envelope_tendsto (1/8192) 1 u W (by norm_num)).const_mul 2)
  simp only [mul_zero,ENNReal.ofReal_zero] at hloop hnear
  have ht := hloop.add hnear
  simp only [add_zero] at ht
  apply tendsto_of_tendsto_of_tendsto_of_le_of_le' tendsto_const_nhds ht (Eventually.of_forall fun _ => bot_le)
  filter_upwards [bt11_window_upper hWalk u W hW,point_soft_phaseA_rate_eventually W hW,
    blockB_logSize_tendsto.eventually_ge_atTop 1] with N hbound htime hL
  have hm : 0≤mixingTime N := by
    unfold mixingTime
    exact mul_nonneg (by have := vertexCount_pos N; positivity) (Real.log_nonneg hL)
  exact hbound η (phaseACenter N-W*timeScale N) hη
    (hm.trans (htime _ le_rfl).1) le_rfl

theorem bt11_actual_conclusion : BT11Conclusion :=
  bt11_of_fixed_time (fun u hu W hW η hη =>
    bt11_fixed_time_tendsto TorusCoverTime.Blocks.A.walk_model_regular u η W hu.le hη hW)

end TorusCoverTime.Blocks.B
