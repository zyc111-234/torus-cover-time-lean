import Solutions.Blocks.B.FiniteDomainSpectrum
import Solutions.Blocks.B.FixedCapacity

/-! Sharp coercivity for killing at one vertex at rate one.  Green's
representer controls the mean, while Poincare controls the variance. -/
noncomputable section
open Filter Classical
open scoped BigOperators Topology
namespace TorusCoverTime.Blocks.B

def pointKillingEnergy (N : Size) (c : Vertex N) (f : Vertex N → ℝ) : ℝ :=
  energy N f+(f c)^2

theorem pointKillingEnergy_nonneg (N : Size) (c : Vertex N) (f : Vertex N → ℝ) :
    0 ≤ pointKillingEnergy N c f := add_nonneg (energy_nonneg N f) (sq_nonneg _)

theorem green_point_pairing (N : Size) (c : Vertex N) (f : Vertex N → ℝ) :
    dirichletPairing N f (fun z => greenKernel N z c) = f c-spatialMean N f := by
  rw [← green_inverse_generator N f c]
  simp only [greenOperator,dirichletPairing,greenKernel_symm N c]
  exact dirichletPairing_symm N f _

theorem green_point_energy (N : Size) (c : Vertex N) :
    energy N (fun z => greenKernel N z c) = greenDiagonal N := by
  have hm : spatialMean N (fun z => greenKernel N z c) = 0 := by
    unfold spatialMean
    rw [greenKernel_sum_left,zero_div]
  simpa only [dirichletPairing,energy,hm,sub_zero,greenKernel_diagonal] using
    green_point_pairing N c (fun z => greenKernel N z c)

theorem green_point_energy_bound (N : Size) (c : Vertex N) (f : Vertex N → ℝ) :
    (f c-spatialMean N f)^2 ≤ greenDiagonal N*energy N f := by
  let G := greenDiagonal N
  let d := f c-spatialMean N f
  have hG : 0 < G := greenDiagonal_pos N
  have h := energy_nonneg N (f+(-d/G) • (fun z => greenKernel N z c))
  rw [energy_add_smul,green_point_energy,green_point_pairing] at h
  change 0 ≤ energy N f+(-d/G)^2*G+2*(-d/G)*d at h
  have hm := mul_nonneg (sq_nonneg G) h
  have he : G^2*(energy N f+(-d/G)^2*G+2*(-d/G)*d) = G*(G*energy N f-d^2) := by
    field_simp
    ring
  rw [he] at hm
  have hh := (mul_nonneg_iff_of_pos_left hG).mp hm
  dsimp only [G,d] at hh
  linarith

theorem point_killing_mean_bound (N : Size) (c : Vertex N) (f : Vertex N → ℝ) :
    (spatialMean N f)^2 ≤ (greenDiagonal N+1)*pointKillingEnergy N c f := by
  have hG := greenDiagonal_pos N
  have h := mul_le_mul_of_nonneg_left (green_point_energy_bound N c f)
    (by positivity : 0 ≤ greenDiagonal N+1)
  apply (mul_le_mul_iff_right₀ hG).mp
  unfold pointKillingEnergy
  nlinarith [sq_nonneg ((greenDiagonal N+1)*f c-spatialMean N f)]

theorem point_killing_coercivity (N : Size) (c : Vertex N) (f : Vertex N → ℝ) :
    squareSum N f ≤ vertexCount N*(greenDiagonal N+5/4)*pointKillingEnergy N c f := by
  have hvar : 0 ≤ squareSum N f-vertexCount N*(spatialMean N f)^2 := by
    rw [squareSum,← sum_sq_sub_mean]
    exact Finset.sum_nonneg (fun _ _ => sq_nonneg _)
  have hp := mul_le_mul_of_nonneg_left (poincare_variance N f) (vertexCount_pos N).le
  have hg := mul_le_mul_of_nonneg_right (vertexCount_mul_spectralGap_ge_four N) hvar
  have hm := mul_le_mul_of_nonneg_left (point_killing_mean_bound N c f) (vertexCount_pos N).le
  have hs := mul_nonneg (vertexCount_pos N).le (sq_nonneg (f c))
  dsimp only [squareSum,pointKillingEnergy] at hvar hp hg hm ⊢
  nlinarith

def pointKillingRate (N : Size) : ℝ := (vertexCount N*(greenDiagonal N+5/4))⁻¹

theorem pointKillingRate_pos (N : Size) : 0 < pointKillingRate N := by
  have := vertexCount_pos N
  have := greenDiagonal_pos N
  unfold pointKillingRate
  positivity

theorem point_killing_rayleigh (N : Size) (c : Vertex N) (f : Vertex N → ℝ) :
    pointKillingRate N*squareSum N f ≤ pointKillingEnergy N c f := by
  have hD : 0 < vertexCount N*(greenDiagonal N+5/4) := by
    have := vertexCount_pos N
    have := greenDiagonal_pos N
    positivity
  have h : squareSum N f/(vertexCount N*(greenDiagonal N+5/4)) ≤ pointKillingEnergy N c f :=
    (div_le_iff₀ hD).mpr (by simpa only [mul_comm] using point_killing_coercivity N c f)
  simpa only [pointKillingRate,div_eq_mul_inv,mul_comm] using h

theorem point_killing_rate_log_lower (N : Size) :
    (vertexCount N*(g*logSize N+(greenDiagonalErrorConstant+5/4)))⁻¹ ≤ pointKillingRate N := by
  have hdiag : greenDiagonal N ≤ g*logSize N+greenDiagonalErrorConstant := by
    have h := (le_abs_self (greenDiagonal N-g*logSize N)).trans (greenDiagonal_log_error N)
    linarith
  have hD : 0 < vertexCount N*(greenDiagonal N+5/4) := by
    have := vertexCount_pos N
    have := greenDiagonal_pos N
    positivity
  unfold pointKillingRate
  exact inv_anti₀ hD (mul_le_mul_of_nonneg_left (by linarith) (vertexCount_pos N).le)

end TorusCoverTime.Blocks.B
