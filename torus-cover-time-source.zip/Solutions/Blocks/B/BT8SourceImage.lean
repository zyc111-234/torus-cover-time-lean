import Solutions.Blocks.B.BT8Parameters

/-! One contact witness suffices: adding Gaussian square occupation preserves
every lower barrier, so only the selected contact needs a radial cutoff. -/
noncomputable section
open MeasureTheory Filter Set Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

theorem bt8_source_image (N : Size) (root x : Vertex N) (γ u : ℝ)
    (hA : 2*(logSize N)^(16*γ)≤(logSize N)^(32*γ))
    (hAS : (logSize N)^(32*γ)≤(logSize N)^(1/10:ℝ))
    (h3 : (logSize N)^(3*γ)≤(logSize N)^(8*γ))
    (h4 : (logSize N)^(4*γ)≤(logSize N)^(8*γ))
    (hC : 2*coarseProbeRadialConstant≤(logSize N)^(8*γ))
    (z : D.LoopSource × FiniteFieldSample N)
    (hg : bt8Good N root γ u (z.1.2,z.1.1))
    (hs : localTime N root z.1.2 z.1.1 x≤u) (hp : bt8Probe N root x γ z) :
    bt8ImageBad N γ u x (D.sourceCoareaImage N root z) ∧
      D.pinnedEnergy N root z.2≤(64*g)*vertexCount N*logSize N := by
  obtain ⟨q,hq,hprobe⟩ := hp
  have hδ := Real.rpow_pos_of_pos (logSize_pos N) (8*γ)
  have hlower (k : ℕ) (hk : (logSize N)^(32*γ)≤(k:ℝ))
      (hkl : (k:ℝ)≤logSize N-(logSize N)^(32*γ)) :
      Real.sqrt 2*(k:ℝ)-4*(logSize N)^(8*γ)≤
        harmonicImageRadius N x k (D.sourceCoareaImage N root z) := by
    have hh := bt8Good_harmonic_lower N root x γ u _ hg hs k (hA.trans hk) (by linarith)
    rw [harmonicImageRadius_source]
    have hmono := Real.sqrt_le_sqrt (le_add_of_nonneg_right (a := harmonicPathOccupation N x root k (z.1.2,z.1.1))
      (pinnedWeightedEnergy_nonneg N root (diskHarmonicWeight N x (Real.exp ((k:ℝ)+1)))
        (diskHarmonicWeight_nonneg N x (Real.exp ((k:ℝ)+1))) z.2))
    exact (show Real.sqrt 2*(k:ℝ)-4*(logSize N)^(8*γ)≤
      Real.sqrt (harmonicPathOccupation N x root k (z.1.2,z.1.1)) by linarith).trans hmono
  have hctl := bt8Good_harmonic_control N root x γ u _ hg hs q
    (hA.trans (hAS.trans hq.1)) (by linarith [hq.2.1])
  have hlow : Real.sqrt (harmonicPathOccupation N x root q (z.1.2,z.1.1))≤
      Real.sqrt 2*(q:ℝ)+2*(logSize N)^(8*γ) := by
    linarith [(abs_le.mp hctl).2,hq.2.2]
  have hsqrt : 1≤Real.sqrt (2:ℝ) := by norm_num
  have hq0 : 0≤(q:ℝ) := Nat.cast_nonneg q
  have hupper := r7_probe_image_radius N x root q (Real.sqrt 2*(q:ℝ)) (2*(logSize N)^(8*γ))
    hq0 (by nlinarith) (by positivity) z hlow hprobe
  refine ⟨⟨?_,hlower,q,hq.1,hq.2.1,by linarith⟩,hprobe.2.2⟩
  change 2*localTime N root z.1.2 z.1.1 x+D.pinnedField N root z.2 x^2≤2*u+1
  have habs := abs_le.mp hprobe.1
  nlinarith

theorem bt8_probe_mass (γ : ℝ) (hγ : 0<γ) (hγhi : 32*γ<1/10) :
    ∀ᶠ N : Size in atTop, ∀ root x : Vertex N, ∀ u : ℝ, ∀ a : D.LoopSource,
      bt8Good N root γ u (a.2,a.1) → bt8SoftPoint N root x γ u (a.2,a.1) →
      ENNReal.ofReal (coarseProbeProbabilityConstant/Real.sqrt (logSize N))≤
        ∫⁻ ξ, (if bt8Probe N root x γ (a,ξ) then (1:ℝ≥0∞) else 0) ∂finiteFieldLaw N := by
  filter_upwards [r7_coarse_probe_mass γ hγ (by linarith),bt8_parameters γ hγ hγhi] with N hm hp
  intro root x u a hg hs
  obtain ⟨q,hq⟩ := hs.2
  have hpow := Real.rpow_pos_of_pos (logSize_pos N) (16*γ)
  have hfar := bt8Good_far N root x γ u _ hg hs.1
  have hf0 : 0≤(N.val:ℝ)*Real.exp (-((logSize N)^(16*γ))/2) := by positivity
  have hh := hm root x q (by linarith [hp.2.1,hp.2.2.1,hq.1])
    (by linarith [hp.2.1,hp.2.2.1,hq.2.1]) (by linarith)
  have hh' := (ENNReal.ofReal_le_iff_le_toReal (measure_ne_top _ _)).mpr hh
  calc
    _ ≤ (finiteFieldLaw N) (r7CoarseProbe N root x q) := hh'
    _ = ∫⁻ ξ, (r7CoarseProbe N root x q).indicator (fun _ => (1:ℝ≥0∞)) ξ ∂finiteFieldLaw N := by
      rw [lintegral_indicator (r7CoarseProbe_measurable N root x q),lintegral_one,Measure.restrict_apply_univ]
    _ ≤ _ := lintegral_mono (fun ξ => by
      by_cases hx : ξ∈r7CoarseProbe N root x q
      · rw [indicator_of_mem hx,if_pos (show bt8Probe N root x γ (a,ξ) from ⟨q,hq,hx⟩)]
      · rw [indicator_of_notMem hx]; exact bot_le)

end TorusCoverTime.Blocks.B
