import Solutions.Blocks.B.ScaledIncrement

/-! Sine-coordinate annuli for the periodic symbol, with a smooth zero-scale extension. -/

noncomputable section
open scoped Topology ContDiff
namespace TorusCoverTime.Blocks.B

def sineCoordinate (a x : ℝ) : ℝ := x * Real.sinc (Real.pi * a * x)

@[fun_prop] lemma sineCoordinate_contDiff :
    ContDiff ℝ ∞ (fun v : ℝ × ℝ => sineCoordinate v.1 v.2) := by
  unfold sineCoordinate
  fun_prop

lemma sineCoordinate_mul_scale (a x : ℝ) :
    (Real.pi * a) * sineCoordinate a x = Real.sin (Real.pi * a * x) := by
  simpa only [sineCoordinate, mul_assoc] using mul_sinc_eq_sin (Real.pi * a * x)

lemma sineCoordinate_zero (a : ℝ) : sineCoordinate a 0 = 0 := by simp [sineCoordinate]

lemma sineCoordinate_zero_scale (x : ℝ) : sineCoordinate 0 x = x := by simp [sineCoordinate]

lemma annularDenominator_zero_scale_pos (x y : ℝ) : 0 < annularDenominator 0 x y := by
  by_cases hxy : x = 0 ∧ y = 0
  · simp [annularDenominator, scaledSymbol, rectangleCutoff, hxy.1, hxy.2,
      frequencyBump_one 0 (by norm_num)]
  · have hne : x ≠ 0 ∨ y ≠ 0 := by tauto
    exact add_pos_of_pos_of_nonneg
      (scaledSymbol_pos 0 x y (by simpa using Real.pi_pos) (by simpa using Real.pi_pos) hne)
      (rectangleCutoff_nonneg _ _)

@[fun_prop] lemma annularReciprocal_zero_scale_contDiff :
    ContDiff ℝ ∞ (fun v : ℝ × ℝ => annularReciprocal 0 v.1 v.2) := by
  have hd : ContDiff ℝ ∞ (fun v : ℝ × ℝ => annularDenominator 0 v.1 v.2) :=
    annularDenominator_contDiff.comp (contDiff_const.prodMk contDiff_id)
  exact annularCutoff_contDiff.div hd (fun v => (annularDenominator_zero_scale_pos v.1 v.2).ne')

def periodicAnnularCore (ds : List (Fin 4)) (a x y : ℝ) : ℂ :=
  (annularReciprocal 0 (sineCoordinate a x) (sineCoordinate a y) : ℂ) *
    (ds.map (fun d => scaledIncrement a (stepCoordinate d x y))).prod

@[fun_prop] lemma periodicAnnularCore_contDiff (ds : List (Fin 4)) :
    ContDiff ℝ ∞ (fun v : ℝ × (ℝ × ℝ) => periodicAnnularCore ds v.1 v.2.1 v.2.2) := by
  have hx : ContDiff ℝ ∞ (fun v : ℝ × (ℝ × ℝ) => sineCoordinate v.1 v.2.1) :=
    sineCoordinate_contDiff.comp (contDiff_fst.prodMk (contDiff_fst.comp contDiff_snd))
  have hy : ContDiff ℝ ∞ (fun v : ℝ × (ℝ × ℝ) => sineCoordinate v.1 v.2.2) :=
    sineCoordinate_contDiff.comp (contDiff_fst.prodMk (contDiff_snd.comp contDiff_snd))
  exact (complexOfReal_contDiff.comp (annularReciprocal_zero_scale_contDiff.comp (hx.prodMk hy))).mul
    (scaledStepProduct_contDiff ds)

lemma periodicAnnularCore_eq (ds : List (Fin 4)) (a x y : ℝ) :
    periodicAnnularCore ds a x y =
      ((annularCutoff (sineCoordinate a x) (sineCoordinate a y) / scaledSymbol a x y : ℝ) : ℂ) *
        (ds.map (fun d => scaledIncrement a (stepCoordinate d x y))).prod := by
  rw [periodicAnnularCore, annularReciprocal_eq, scaledSymbol_zero_scale]
  rfl

lemma periodicAnnularCore_zero_outer (ds : List (Fin 4)) (a x y : ℝ)
    (hxy : 2 ≤ |sineCoordinate a x| ∨ 2 ≤ |sineCoordinate a y|) :
    periodicAnnularCore ds a x y = 0 := by
  simp [periodicAnnularCore, annularReciprocal_zero_outer 0 _ _ hxy]

lemma sinc_lower_on_half_pi (t : ℝ) (ht : |t| ≤ Real.pi / 2) :
    2 / Real.pi ≤ Real.sinc t := by
  have habs : Real.sinc |t| = Real.sinc t := by
    by_cases ht0 : 0 ≤ t
    · rw [abs_of_nonneg ht0]
    · rw [abs_of_nonpos (le_of_not_ge ht0), Real.sinc_neg]
  by_cases ht0 : t = 0
  · rw [ht0, Real.sinc_zero]
    exact (div_le_one Real.pi_pos).mpr Real.two_le_pi
  · rw [← habs, Real.sinc_of_ne_zero (abs_ne_zero.mpr ht0)]
    exact (le_div_iff₀ (abs_pos.mpr ht0)).mpr (Real.mul_le_sin (abs_nonneg t) ht)

lemma sineCoordinate_lower (a x : ℝ) (hx : |a * x| ≤ 1 / 2) :
    2 / Real.pi * |x| ≤ |sineCoordinate a x| := by
  have ht : |Real.pi * a * x| ≤ Real.pi / 2 := by
    have hp := mul_le_mul_of_nonneg_left hx Real.pi_pos.le
    calc
      |Real.pi * a * x| = Real.pi * |a * x| := by
        rw [mul_assoc, abs_mul, abs_of_pos Real.pi_pos]
      _ ≤ Real.pi * (1 / 2) := hp
      _ = Real.pi / 2 := by ring
  have h := (sinc_lower_on_half_pi _ ht).trans (le_abs_self _)
  simpa only [sineCoordinate, abs_mul, mul_comm] using mul_le_mul_of_nonneg_left h (abs_nonneg x)

lemma sineCoordinate_bound_implies_coordinate_bound (a x : ℝ)
    (hx : |a * x| ≤ 1 / 2) (hs : |sineCoordinate a x| ≤ 2) : |x| ≤ Real.pi := by
  have h := (sineCoordinate_lower a x hx).trans hs
  have hp := mul_le_mul_of_nonneg_left h Real.pi_pos.le
  have hid : Real.pi * (2 / Real.pi * |x|) = 2 * |x| := by field_simp
  rw [hid] at hp
  linarith

def frequencySineCoordinate (N : Size) (R : ℝ) (b : ZMod N.val) : ℝ :=
  sineCoordinate (R / N.val) ((b.valMinAbs : ℝ) / R)

lemma frequencySineCoordinate_formula (N : Size) (R : ℝ) (hR : R ≠ 0) (b : ZMod N.val) :
    frequencySineCoordinate N R b =
      (N.val : ℝ) / (Real.pi * R) * Real.sin (Real.pi * (b.valMinAbs : ℝ) / N.val) := by
  have hN : (N.val : ℝ) ≠ 0 := ne_of_gt (lt_trans zero_lt_one (size_real_gt_one N))
  have h := sineCoordinate_mul_scale (R / N.val) ((b.valMinAbs : ℝ) / R)
  rw [show Real.pi * (R / N.val) * ((b.valMinAbs : ℝ) / R) =
      Real.pi * (b.valMinAbs : ℝ) / N.val by field_simp] at h
  unfold frequencySineCoordinate
  apply (mul_left_cancel₀ (show Real.pi * (R / N.val) ≠ 0 from mul_ne_zero Real.pi_ne_zero (div_ne_zero hR hN)))
  rw [h]
  field_simp

lemma frequencySineCoordinate_half_scale (N : Size) (R : ℝ) (hR : R ≠ 0) (b : ZMod N.val) :
    frequencySineCoordinate N (R / 2) b = 2 * frequencySineCoordinate N R b := by
  rw [frequencySineCoordinate_formula N (R / 2) (div_ne_zero hR (by norm_num)),
    frequencySineCoordinate_formula N R hR]
  ring

def frequencyCutoff (N : Size) (R : ℝ) (k : Vertex N) : ℝ :=
  rectangleCutoff (frequencySineCoordinate N R k.1) (frequencySineCoordinate N R k.2)

lemma frequencyCutoff_difference (N : Size) (R : ℝ) (hR : R ≠ 0) (k : Vertex N) :
    frequencyCutoff N R k - frequencyCutoff N (R / 2) k =
      annularCutoff (frequencySineCoordinate N R k.1) (frequencySineCoordinate N R k.2) := by
  simp only [frequencyCutoff, frequencySineCoordinate_half_scale N R hR, annularCutoff]

end TorusCoverTime.Blocks.B
