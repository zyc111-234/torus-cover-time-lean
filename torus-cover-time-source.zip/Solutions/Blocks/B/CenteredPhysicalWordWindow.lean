import Solutions.Blocks.B.PhysicalCenteredExterior
import Solutions.Blocks.B.CenteredCoarseExterior
import Solutions.Blocks.B.PhysicalWordWindow

/-! Coarse two-sided harmonic concentration for the original physical path, conditional on its actual word. -/
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B


theorem physicalWordWindow_one_eq_exterior (N : Size) (I O : Finset (Vertex N)) (root : Vertex N)
    (m : ℕ) (w : Fin (2*m) → Vertex N) (l r : ℝ) :
    physicalWordWindow N I O root m w (fun _ => 1) l r =
      conditionalTraversalExteriorSlice N I O root m w univ (fun _ => 1) l r := by
  unfold physicalWordWindow conditionalTraversalExteriorSlice
  simp only [traversalExteriorMarkedTest,mem_univ,if_true]

theorem r8_centered_physical_word_window (hWalk : WalkModelRegular) (γ : ℝ) (hγ : 0 < γ) (hγ1 : γ ≤ 1) :
    ∀ᶠ N : Size in atTop, ∀ c root : Vertex N, ∀ m : ℕ, ∀ w : Fin (2*m) → Vertex N, ∀ q : ℝ,
      (logSize N)^(16*γ) ≤ q → q ≤ logSize N-(logSize N)^(16*γ) →
      root ∉ torusDisk N c (Real.exp (q+2*q^γ)) →
      walkLaw {ω | adaptiveExitWord N (alternatingDomain N (torusDisk N c (Real.exp (q+q^γ)))
        (torusDisk N c (Real.exp (q+2*q^γ)))) root (2*m) ω = w} ≠ 0 →
      q ≤ Real.sqrt ((m:ℝ)*q^γ) → Real.sqrt ((m:ℝ)*q^γ) ≤ 10*logSize N → ∀ l r : ℝ,
      let I := torusDisk N c (Real.exp (q+q^γ))
      let O := torusDisk N c (Real.exp (q+2*q^γ))
      let d := (m:ℝ)*Real.exp (2*logSize N-(logSize N)^(16*γ))
      physicalWordWindow N I O root m w (fun z =>
        if (logSize N)^(4*γ)/2 < |Real.sqrt (harmonicPathOccupation N c root q z)-Real.sqrt ((m:ℝ)*q^γ)|
          then 1 else 0) l r ≤
        2*ENNReal.ofReal (2*Real.exp (-(r7ConcentrationConstant/16)*(logSize N)^(7*γ)))*
          physicalWordWindow N I O root m w (fun _ => 1) (l-d) (r+d) +
        ENNReal.ofReal (r-l)*ENNReal.ofReal (Real.exp (-Real.exp ((logSize N)^(16*γ)/2))) := by
  obtain ⟨q0,hq0⟩ := eventually_atTop.mp ((tendsto_rpow_atTop hγ).eventually_ge_atTop (2:ℝ))
  have hQ := (tendsto_rpow_atTop (by positivity : 0 < 16*γ)).comp blockB_logSize_tendsto
  filter_upwards [r8_centered_coarse_exterior hWalk γ hγ hγ1,hQ.eventually_ge_atTop q0] with N hwin hbase
  intro c root m w q hq hqL hr hw hv hvL l r
  dsimp only
  have hq0' := (Real.rpow_nonneg (logSize_pos N).le (16*γ)).trans hq
  have hIO := torusDisk_subset N c (Real.exp (q+q^γ)) (Real.exp (q+2*q^γ))
    (Real.exp_le_exp.mpr (by linarith [Real.rpow_nonneg hq0' γ]))
  have hU := r7_harmonicWeight_supported_in_traversal_inner N c q (q^γ) hq0' (hq0 q (hbase.trans hq))
  have he := harmonicCenteredPhysicalSlice_eq_record N _ _ c root hIO
    (torusDisk_nonempty N c _ (Real.exp_pos _)) hr m w γ q ((logSize N)^(4*γ)/2) hU (fun _ => 1) l r
  change physicalWordWindow N (torusDisk N c (Real.exp (q+q^γ)))
    (torusDisk N c (Real.exp (q+2*q^γ))) root m w (fun z : WalkSample × ℝ =>
      if (logSize N)^(4*γ)/2 < |Real.sqrt (harmonicPathOccupation N c root q z)-Real.sqrt ((m:ℝ)*q^γ)|
        then 1 else 0) l r = _ at he
  rw [he,physicalWordWindow_one_eq_exterior]
  exact hwin c root m w q hq hqL hr hw hv hvL (fun _ => 1) measurable_const (fun _ _ => le_rfl) l r


end TorusCoverTime.Blocks.B
