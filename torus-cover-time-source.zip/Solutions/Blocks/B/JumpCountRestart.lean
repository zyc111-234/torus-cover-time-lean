import Solutions.Blocks.B.JumpOccupationRestart
import Solutions.Blocks.B.TraversalPrefixScan

/-! Exact shift of jump counts at a finite original jump; the residual clock is not resampled. -/
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B


theorem walk_all_shifts_regular :
    ∀ᵐ ω ∂walkLaw, ∀ n : ℕ,
      (∀ j, 0 < (ω (n+j)).1) ∧ Tendsto (jumpTime (fun j => ω (n+j))) atTop atTop :=
  ae_all_iff.mpr fun n =>
    (fixedShift_measurePreserving n).quasiMeasurePreserving.ae A.holding_positive_and_nonexplosive

theorem jumpCount_jump_restart (ω : WalkSample) (n : ℕ) (hp : ∀ j, 0 < (ω j).1)
    (hd : Tendsto (jumpTime (fun j => ω (n+j))) atTop atTop) (u : ℝ) (hu : 0 ≤ u) :
    jumpCount ω (jumpTime ω n+u) = n+jumpCount (fun j => ω (n+j)) u := by
  have he : recordJoin (n,ω) (fun j => ω (n+j)) = ω := by
    funext j
    by_cases hj : j < n
    · simp [recordJoin,hj]
    · simp [recordJoin,hj,Nat.add_sub_of_le (by omega : n ≤ j)]
  have hh := recordJoin_jumpCount (n,ω) (fun j _ => hp j) (fun j => hp (n+j)) hd u hu
  simpa only [he,excursionRecordDuration] using hh

theorem traversalPrefixScan_physical_restart (N : Size) (I O : Finset (Vertex N))
    (a : Vertex N) (ω : WalkSample) (s : ℕ) (hp : ∀ j, 0 < (ω j).1)
    (hd : Tendsto (jumpTime (fun j => ω (s+j))) atTop atTop) (t : ℝ) (ht : jumpTime ω s ≤ t) :
    traversalPrefixScan N I O a ω (jumpCount ω t+1) 0 =
      traversalPrefixScan N I O (position N a ω s) (fun j => ω (s+j))
        (jumpCount (fun j => ω (s+j)) (t-jumpTime ω s)+1)
        (traversalPrefixScan N I O a ω s 0) := by
  have he := jumpCount_jump_restart ω s hp hd (t-jumpTime ω s) (sub_nonneg.mpr ht)
  rw [add_sub_cancel] at he
  rw [he,Nat.add_assoc,traversalPrefixScan_add]


end TorusCoverTime.Blocks.B
