import Solutions.Blocks.B.R7BarrierGridSum

/-! The two errors after summing all coarse integer scales both vanish.
In particular the grid multiplicity is retained on the L log L remainder. -/

noncomputable section
open Filter
open scoped Topology
namespace TorusCoverTime.Blocks.B

def r7BarrierGlobalEnvelope (L γ c C : ℝ) : ℝ :=
  2*L*r7BarrierScaleEnvelope L γ c C

theorem r7_barrier_grid_remainder_tendsto (c : ℝ) (hc : 0 < c) :
    Tendsto (fun L : ℝ => 18*L*Real.exp (2*L)*Real.exp (-c*L*Real.log L)) atTop (𝓝 0) := by
  have ht := (Real.tendsto_pow_mul_exp_neg_atTop_nhds_zero 1).const_mul 18
  simp only [pow_one,mul_zero] at ht
  have hbound : ∀ᶠ L : ℝ in atTop,
      18*L*Real.exp (2*L)*Real.exp (-c*L*Real.log L) ≤ 18*(L*Real.exp (-L)) := by
    filter_upwards [eventually_ge_atTop (0:ℝ),Real.tendsto_log_atTop.eventually_ge_atTop (3/c)] with L hL hlog
    have hm := mul_le_mul_of_nonneg_right ((div_le_iff₀ hc).mp hlog) hL
    calc
      _ = 18*L*Real.exp (2*L-c*L*Real.log L) := by rw [sub_eq_add_neg,Real.exp_add]; ring
      _ ≤ _ := by
        rw [← mul_assoc]
        apply mul_le_mul_of_nonneg_left (Real.exp_le_exp.mpr (by nlinarith only [hm]))
        positivity
  apply squeeze_zero' ?_ hbound ht
  filter_upwards [eventually_ge_atTop (0:ℝ)] with L hL
  positivity

theorem r7_barrier_global_envelope_tendsto (γ c C : ℝ) (hγ : 0 < γ) (hc : 0 < c) :
    Tendsto (fun L : ℝ => r7BarrierGlobalEnvelope L γ c C) atTop (𝓝 0) := by
  have hm := (polynomial_times_stretched_exp_tendsto_zero (3*γ) (1/4) (3/2)
    (by positivity) (by norm_num)).const_mul (18*C)
  simp only [mul_zero] at hm
  have ht := hm.add (r7_barrier_grid_remainder_tendsto c hc)
  simp only [add_zero] at ht
  apply ht.congr'
  filter_upwards [eventually_gt_atTop (0:ℝ)] with L hL
  have hp : L^(3/2:ℝ) = L*Real.sqrt L := by
    rw [Real.sqrt_eq_rpow,show (3/2:ℝ) = 1+1/2 by norm_num,Real.rpow_add hL,Real.rpow_one]
  dsimp only [r7BarrierGlobalEnvelope,r7BarrierScaleEnvelope]
  rw [hp]
  congr 1 <;> ring

end TorusCoverTime.Blocks.B
