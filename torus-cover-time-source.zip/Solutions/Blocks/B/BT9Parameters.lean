import Solutions.Blocks.B.BT9GreenGeometry
import Solutions.Blocks.B.R6ConditionedHitting

/-! Discharge every parameter of the pair Laplace comparison from the actual
annulus and the logarithmic pair separation. -/
noncomputable section
open MeasureTheory ProbabilityTheory Filter Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

def bt9_pair_parameters_of_bounds (N : Size) (c : Vertex N) (R : ℝ)
    (a b x y : Vertex N) (q h k : ℝ)
    (hq : 0 < q) (hh : 0 ≤ h) (hk : 0 ≤ k) (hsmall : k*h ≤ q/16)
    (ha : 0 < exitHarmonic N (torusDisk N c R) b a)
    (hx : 0 < exitHarmonic N (torusDisk N c R) b x)
    (hy : 0 < exitHarmonic N (torusDisk N c R) b y)
    (hA : |conditionedDiskGreen N c R b x x/g-q| ≤ k*h)
    (hD : |conditionedDiskGreen N c R b y y/g-q| ≤ k*h)
    (hB : 0 ≤ conditionedDiskGreen N c R b x y/g)
    (hC : 0 ≤ conditionedDiskGreen N c R b y x/g)
    (hBu : conditionedDiskGreen N c R b x y/g ≤ k*h)
    (hCu : conditionedDiskGreen N c R b y x/g ≤ k*h)
    (hE : 2*h*(1-2*h/q) ≤ conditionedDiskGreen N c R b a x/g+
      conditionedDiskGreen N c R b a y/g) :
    PairExitParameters N c R a b x y ((2*h/q)*(1-(8*k+2)*(h/q))) (2/q) := by
  have hg : 0 < g := by unfold g; positivity
  let F := conditionedDiskGreen N c R b
  let δ := F x x*F y y-F x y*F y x
  let d := q+8*k*h
  have hd : 0 < d := by dsimp [d]; positivity
  have hmat := bt9_matrix_comparison q k h (F x x/g) (F x y/g) (F y x/g) (F y y/g)
    hq hk hh hsmall hA hD hB hC hBu hCu
  have hδ : F x x/g*(F y y/g)-F x y/g*(F y x/g) = δ/g^2 := by dsimp [δ]; ring
  rw [hδ] at hmat
  have hdet : 0 < δ := by
    have ht := mul_pos hmat.1 (sq_pos_of_pos hg)
    rwa [div_mul_cancel₀ _ (sq_pos_of_pos hg).ne'] at ht
  have hrow₁ : (1/(g*d))*δ ≤ F y y-F x y := by
    calc
      _ = (δ/g^2/d)*g := by field_simp <;> ring
      _ ≤ (F y y/g-F x y/g)*g := mul_le_mul_of_nonneg_right hmat.2.1 hg.le
      _ = _ := by field_simp
  have hrow₂ : (1/(g*d))*δ ≤ F x x-F y x := by
    calc
      _ = (δ/g^2/d)*g := by field_simp <;> ring
      _ ≤ (F x x/g-F y x/g)*g := mul_le_mul_of_nonneg_right hmat.2.2 hg.le
      _ = _ := by field_simp
  have he := bt9_entrance_parameter q h k (F a x/g+F a y/g) hq hh hk hE
  have hr : g*(1/(g*d)) ≤ 2/q := by
    have hqd : q ≤ d := by dsimp [d]; nlinarith [mul_nonneg hk hh]
    calc
      _ = 1/d := by field_simp
      _ ≤ 1/q := div_le_div_of_nonneg_left (by norm_num) hq hqd
      _ ≤ 2/q := by gcongr; norm_num
  refine ⟨ha,hx,hy,1/(g*d),by positivity,hdet,hrow₁,hrow₂,?_,hr⟩
  convert he using 1 <;> (try dsimp only [d]) <;> field_simp <;> ring

theorem bt9_actual_green_parameters (γ : ℝ) (hγ : 0 < γ) (hγ1 : γ < 1) :
    ∀ᶠ q : ℝ in atTop, ∀ N : Size, ∀ c a b z : Vertex N,
      c ≠ z → q-2 ≤ Real.log (periodicDistance c z) →
      Real.log (periodicDistance c z) < q →
      2*(Real.exp (q+2*q^γ)+1) < N.val →
      |periodicDistance a c-Real.exp (q+q^γ)| ≤ 2 →
      diskExteriorNeighbor N c (Real.exp (q+2*q^γ)) b →
      Nonempty (PairExitParameters N c (Real.exp (q+2*q^γ)) a b c z
        ((2*q^γ/q)*(1-bt9ParameterConstant*(q^γ/q))) (2/q)) := by
  filter_upwards [bt9_parameter_small_errors γ hγ hγ1, bt9_shifted_green γ hγ hγ1,
    r6_exit_ratio_exponential γ hγ] with q herr hgreen hratio
  intro N c a b z hcz hlo hhi hsmall ha hb
  obtain ⟨hq,hh,hh8,hkq,hp,he⟩ := herr
  have hq0 : 0 < q := by linarith
  have hg : 0 < g := by unfold g; positivity
  let h := q^γ
  let R := Real.exp (q+2*q^γ)
  let D := torusDisk N c R
  let H := exitHarmonic N D b
  let F := conditionedDiskGreen N c R b
  let K := bt9MatrixConstant
  let C := r6GreenErrorConstant/g
  have hC : 0 ≤ C := div_nonneg r6GreenErrorConstant_pos.le hg.le
  have hK : 8 ≤ K := bt9MatrixConstant_ge_eight
  have hh0 : 0 ≤ h := by dsimp [h]; positivity
  have hhq : h/q ≤ 1 := by
    have ht := mul_le_mul_of_nonneg_right hK hh0
    apply (div_le_one hq0).mpr
    change K*h ≤ q/16 at hkq
    linarith
  have hz := (bt9_site_geometry N c z q hcz hhi).2
  have hc : c ∈ torusDisk N c (Real.exp q) :=
    (mem_torusDisk N c c _).mpr (by rw [periodicDistance_self_zero]; positivity)
  have hgeom := r6_green_geometry N c a z q h hq0.le hh8 ha hz
  have hgeomc := r6_green_geometry N c a c q h hq0.le hh8 ha hc
  have hsiteD (x : Vertex N) (hx : x ∈ torusDisk N c (Real.exp q)) : x ∈ D := by
    apply (mem_torusDisk N c x _).mpr
    exact ((mem_torusDisk N c x _).mp hx).trans_le
      (Real.exp_le_exp.mpr (show q ≤ q+2*q^γ by change q ≤ q+2*h; linarith))
  have hpos (x : Vertex N) (hx : x ∈ D) : 0 < H x :=
    disk_exitHarmonic_pos N c R (Real.exp_pos _) (by dsimp [R]; linarith) x b hx hb
  have haH := hpos a hgeom.2.1
  have hcH := hpos c (hsiteD c hc)
  have hzH := hpos z (hsiteD z hz)
  have hE : 2 < Real.exp (q+h) := by
    have ht := Real.add_one_le_exp (q+h)
    change 1 ≤ h at hh
    linarith
  have hprobe (x : Vertex N) (hx : x ∈ torusDisk N c (Real.exp q)) :
      x ∈ torusDisk N c (2*Real.exp (q+h)) := by
    apply (mem_torusDisk N c x _).mpr
    have ht := (mem_torusDisk N c x _).mp hx
    have hE' : Real.exp q ≤ Real.exp (q+h) := Real.exp_le_exp.mpr (by linarith)
    linarith
  have haP : a ∈ torusDisk N c (2*Real.exp (q+h)) :=
    (mem_torusDisk N c a _).mpr (by have := (abs_le.mp ha).2; change _ ≤ 2 at this; linarith)
  have hratio' (x y : Vertex N)
      (hx : x ∈ torusDisk N c (2*Real.exp (q+h)))
      (hy : y ∈ torusDisk N c (2*Real.exp (q+h))) : |H x/H y-1| ≤ 1/q :=
    (hratio N c b x y hsmall hb hx hy).trans he
  have hratioU (x y : Vertex N) (hx : x ∈ torusDisk N c (Real.exp q))
      (hy : y ∈ torusDisk N c (Real.exp q)) : H x/H y ≤ 2 := by
    have ht := (abs_le.mp (hratio' x y (hprobe x hx) (hprobe y hy))).2
    have hu : 1/q ≤ 1 := (div_le_one hq0).mpr hq
    linarith
  have hdiag (x : Vertex N) (hx : x ∈ torusDisk N c (Real.exp q)) : |F x x/g-q| ≤ K*h := by
    have hxH := hpos x (hsiteD x hx)
    rw [show F x x = diskGreen N c R x x from bt9_conditioned_diagonal N c R b x hxH]
    have ht := (r6_green_estimates N c a x q h hq0.le hh8 hsmall ha hx).2.1
    have hn : |diskGreen N c R x x/g-(q+2*h)| ≤ C := by
      rw [show diskGreen N c R x x/g-(q+2*h) = (diskGreen N c R x x-g*(q+2*h))/g by field_simp <;> ring,
        abs_div, abs_of_pos hg]
      exact div_le_div_of_nonneg_right ht hg.le
    have ha' := abs_le.mp hn
    have hCh := le_mul_of_one_le_right hC hh
    apply abs_le.mpr
    dsimp [K,bt9MatrixConstant,C] at *
    constructor <;> nlinarith
  have hOff := bt9_green_offdiagonal_upper N c z q h hq0.le hh8 hsmall hcz hlo hz
  have hOff' (x y : Vertex N) (hxy : diskGreen N c R x y/g ≤ 2*h+2+C)
      (hx : x ∈ torusDisk N c (Real.exp q)) (hy : y ∈ torusDisk N c (Real.exp q)) :
      F x y/g ≤ K*h := by
    rw [bt9_conditioned_normalize]
    have hG0 := div_nonneg (diskGreen_nonneg N c R (Real.exp_pos _).le hsmall x y) hg.le
    have hH0 : 0 ≤ H y/H x := div_nonneg (hpos y (hsiteD y hy)).le (hpos x (hsiteD x hx)).le
    have ht := mul_le_mul hxy (hratioU y x hy hx) hH0 (by positivity : 0 ≤ 2*h+2+C)
    have hCh := le_mul_of_one_le_right hC hh
    apply ht.trans
    change (2*h+2+C)*2 ≤ (8+2*C)*h
    nlinarith
  have hentry (x : Vertex N) (hx : x ∈ torusDisk N c (Real.exp q)) :
      h*(1-2*h/q) ≤ F a x/g := by
    rw [bt9_conditioned_normalize]
    have hG := (abs_le.mp (hgreen N c a b x hsmall ha hb hx)).1
    have hX : h*(1-h/q) ≤ diskGreen N c R a x/g := by
      have hhh : 1 ≤ h^2 := by nlinarith
      have ht := div_le_div_of_nonneg_right hhh hq0.le
      have heq : h*(1-h/q) = h-h^2/q := by ring
      rw [heq]
      change -(1/q) ≤ diskGreen N c R a x/g-h at hG
      linarith
    have hH : 1-h/q ≤ H x/H a := by
      have ht := (abs_le.mp (hratio' x a (hprobe x hx) haP)).1
      have hu := div_le_div_of_nonneg_right hh hq0.le
      linarith
    exact bt9_entry_product q h _ _ hq0 hh0 hhq hX hH
  have hsum : 2*h*(1-2*h/q) ≤ F a c/g+F a z/g := by linarith [hentry c hc,hentry z hz]
  exact ⟨bt9_pair_parameters_of_bounds N c R a b c z q h K hq0 hh0 (by linarith) hkq
    haH hcH hzH (hdiag c hc) (hdiag z hz)
    (div_nonneg (conditionedDiskGreen_nonneg N c R (Real.exp_pos _).le hsmall b c z) hg.le)
    (div_nonneg (conditionedDiskGreen_nonneg N c R (Real.exp_pos _).le hsmall b z c) hg.le)
    (hOff' c z hOff.1 hc hz) (hOff' z c hOff.2 hz hc) hsum⟩

end TorusCoverTime.Blocks.B
