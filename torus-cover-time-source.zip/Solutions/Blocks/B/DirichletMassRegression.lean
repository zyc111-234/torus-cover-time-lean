import Solutions.Blocks.B.DirichletLSCovariance
import Solutions.Blocks.B.GaussianSlabMoments

noncomputable section
open MeasureTheory ProbabilityTheory Classical
open scoped BigOperators
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

def dirichletMass (N : Size) (root : Vertex N) (D : Finset (Vertex N)) (ξ : FiniteFieldSample N) : ℝ :=
  ∑ z, dirichletFieldLS N root D ξ z
def dirichletMassMap (N : Size) (root : Vertex N) (D : Finset (Vertex N)) : FiniteFieldSample N →L[ℝ] ℝ :=
  ∑ z, dirichletLSCoordinateMap N root D z
def dirichletRowMass (N : Size) (root : Vertex N) (D : Finset (Vertex N)) (x : Vertex N) : ℝ :=
  ∑ z, dirichletKernelLS N root D x z
def dirichletMassVariance (N : Size) (root : Vertex N) (D : Finset (Vertex N)) : ℝ :=
  ∑ x, dirichletRowMass N root D x
def dirichletMassSlope (N : Size) (root : Vertex N) (D : Finset (Vertex N)) (x : Vertex N) : ℝ :=
  dirichletRowMass N root D x/dirichletMassVariance N root D
def dirichletMassProfile (N : Size) (root : Vertex N) (D : Finset (Vertex N)) (x : Vertex N) : ℝ :=
  dirichletRowMass N root D x/Real.sqrt (dirichletMassVariance N root D)
def massZeroFieldLS (N : Size) (root : Vertex N) (D : Finset (Vertex N))
    (ξ : FiniteFieldSample N) (x : Vertex N) : ℝ :=
  dirichletFieldLS N root D ξ x-dirichletMassSlope N root D x*dirichletMass N root D ξ
def massZeroCoordinateMap (N : Size) (root : Vertex N) (D : Finset (Vertex N)) (x : Vertex N) :
    FiniteFieldSample N →L[ℝ] ℝ :=
  dirichletLSCoordinateMap N root D x-dirichletMassSlope N root D x • dirichletMassMap N root D

theorem dirichletMassMap_apply (N : Size) (root : Vertex N) (D : Finset (Vertex N)) (ξ : FiniteFieldSample N) :
    dirichletMassMap N root D ξ=dirichletMass N root D ξ := by
  simp [dirichletMassMap,dirichletMass,dirichletLSCoordinateMap_apply]
theorem massZeroCoordinateMap_apply (N : Size) (root : Vertex N) (D : Finset (Vertex N))
    (x : Vertex N) (ξ : FiniteFieldSample N) :
    massZeroCoordinateMap N root D x ξ=massZeroFieldLS N root D ξ x := by
  simp [massZeroCoordinateMap,massZeroFieldLS,dirichletMassMap_apply,dirichletLSCoordinateMap_apply]

@[fun_prop] theorem dirichletMass_measurable (N : Size) (root : Vertex N) (D : Finset (Vertex N)) :
    Measurable (dirichletMass N root D) := by unfold dirichletMass; fun_prop
theorem dirichletMass_gaussian (N : Size) (root : Vertex N) (D : Finset (Vertex N)) :
    HasGaussianLaw (dirichletMass N root D) (finiteFieldLaw N) := by
  simpa only [id_eq,dirichletMassMap_apply] using
    (Blocks.D.finiteFieldSample_gaussian N).map_fun (dirichletMassMap N root D)
theorem dirichletMass_mean (N : Size) (root : Vertex N) (D : Finset (Vertex N)) :
    (∫ ξ, dirichletMass N root D ξ ∂finiteFieldLaw N)=0 := by
  unfold dirichletMass
  rw [integral_finsetSum _ (fun z _ => (dirichletFieldLS_memLp N root D z).integrable (by norm_num))]
  simp only [dirichletFieldLS_mean,Finset.sum_const_zero]

theorem dirichletFieldLS_cov_mass (N : Size) (root : Vertex N) (D : Finset (Vertex N))
    (hroot : root∉D) (x : Vertex N) :
    cov[fun ξ => dirichletFieldLS N root D ξ x,dirichletMass N root D;finiteFieldLaw N]=dirichletRowMass N root D x := by
  unfold dirichletMass
  rw [covariance_fun_sum_right (fun z => dirichletFieldLS_memLp N root D z) (dirichletFieldLS_memLp N root D x)]
  simp only [dirichletFieldLS_covariance N root D hroot,dirichletRowMass]

theorem dirichletMass_variance (N : Size) (root : Vertex N) (D : Finset (Vertex N)) (hroot : root∉D) :
    Var[dirichletMass N root D;finiteFieldLaw N]=dirichletMassVariance N root D := by
  rw [← covariance_self (dirichletMass_measurable N root D).aemeasurable]
  change cov[fun ξ => ∑ z, dirichletFieldLS N root D ξ z,dirichletMass N root D;finiteFieldLaw N]=_
  rw [covariance_fun_sum_left (fun z => dirichletFieldLS_memLp N root D z) (dirichletMass_gaussian N root D).memLp_two]
  simp only [dirichletFieldLS_cov_mass N root D hroot,dirichletMassVariance]

theorem massZeroFieldLS_sum (N : Size) (root : Vertex N) (D : Finset (Vertex N))
    (hV : 0<dirichletMassVariance N root D) (ξ : FiniteFieldSample N) :
    (∑ x, massZeroFieldLS N root D ξ x)=0 := by
  have hs : (∑ x, dirichletMassSlope N root D x)=1 := by
    unfold dirichletMassSlope
    rw [← Finset.sum_div]
    exact div_self hV.ne'
  simp only [massZeroFieldLS,Finset.sum_sub_distrib,← Finset.sum_mul,hs,one_mul,dirichletMass,sub_self]

@[fun_prop] theorem massZeroFieldLS_measurable (N : Size) (root : Vertex N) (D : Finset (Vertex N)) :
    Measurable (massZeroFieldLS N root D) := by
  apply measurable_pi_lambda
  intro x
  unfold massZeroFieldLS
  fun_prop

theorem massZeroFieldLS_cov_mass (N : Size) (root : Vertex N) (D : Finset (Vertex N))
    (hroot : root∉D) (hV : 0<dirichletMassVariance N root D) (x : Vertex N) :
    cov[fun ξ => massZeroFieldLS N root D ξ x,dirichletMass N root D;finiteFieldLaw N]=0 := by
  unfold massZeroFieldLS
  rw [covariance_fun_sub_left (dirichletFieldLS_memLp N root D x)
    ((dirichletMass_gaussian N root D).memLp_two.const_mul _) (dirichletMass_gaussian N root D).memLp_two,
    covariance_const_mul_left,dirichletFieldLS_cov_mass N root D hroot,
    covariance_self (dirichletMass_measurable N root D).aemeasurable,dirichletMass_variance N root D hroot]
  unfold dirichletMassSlope
  rw [div_mul_cancel₀ _ hV.ne',sub_self]

theorem massZeroFieldLS_indep_mass (N : Size) (root : Vertex N) (D : Finset (Vertex N))
    (hroot : root∉D) (hV : 0<dirichletMassVariance N root D) :
    IndepFun (massZeroFieldLS N root D) (dirichletMass N root D) (finiteFieldLaw N) := by
  let A := ContinuousLinearMap.pi (fun x => massZeroCoordinateMap N root D x)
  let B := ContinuousLinearMap.pi (fun _ : Unit => dirichletMassMap N root D)
  have hj : HasGaussianLaw (fun ξ => (massZeroFieldLS N root D ξ,fun _ : Unit => dirichletMass N root D ξ)) (finiteFieldLaw N) := by
    apply ((Blocks.D.finiteFieldSample_gaussian N).map_fun (A.prod B)).congr
    exact Filter.Eventually.of_forall (fun ξ => by
      apply Prod.ext <;> funext z <;>
        simp only [A,B,id_eq,ContinuousLinearMap.prod_apply,ContinuousLinearMap.pi_apply,
          massZeroCoordinateMap_apply,dirichletMassMap_apply])
  simpa only [Function.comp_def,id_eq] using
    (hj.indepFun_of_covariance_eval (fun x _ => massZeroFieldLS_cov_mass N root D hroot hV x)).comp
      measurable_id (measurable_pi_apply ())

theorem massZeroFieldLS_covariance (N : Size) (root : Vertex N) (D : Finset (Vertex N))
    (hroot : root∉D) (hV : 0<dirichletMassVariance N root D) (x y : Vertex N) :
    cov[fun ξ => massZeroFieldLS N root D ξ x,fun ξ => massZeroFieldLS N root D ξ y;finiteFieldLaw N]=
      dirichletKernelLS N root D x y-dirichletRowMass N root D x*dirichletRowMass N root D y/dirichletMassVariance N root D := by
  have hm := (dirichletMass_gaussian N root D).memLp_two
  have hrev : cov[dirichletMass N root D,fun ξ => dirichletFieldLS N root D ξ y;finiteFieldLaw N]=dirichletRowMass N root D y := by
    rw [covariance_comm,dirichletFieldLS_cov_mass N root D hroot]
  unfold massZeroFieldLS
  rw [covariance_fun_sub_fun_sub (dirichletFieldLS_memLp N root D x) (hm.const_mul _)
    (dirichletFieldLS_memLp N root D y) (hm.const_mul _),covariance_const_mul_right,
    covariance_const_mul_left,covariance_const_mul_left,covariance_const_mul_right,
    dirichletFieldLS_covariance N root D hroot,dirichletFieldLS_cov_mass N root D hroot,hrev,
    covariance_self (dirichletMass_measurable N root D).aemeasurable,dirichletMass_variance N root D hroot]
  unfold dirichletMassSlope
  field_simp [hV.ne']
  <;> ring

end TorusCoverTime.Blocks.B
