import Solutions.Blocks.B.R8NestedScales
import Solutions.Blocks.B.DiskHarmonicMeasure

/-! The outer harmonic measure is zero throughout every erased inner outward domain. -/
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B


theorem diskHarmonicWeight_zero_subdisk (N : Size) (c x : Vertex N) (r R : ℝ)
    (hrR : r ≤ R) (hx : x ∈ torusDisk N c r) :
    diskHarmonicWeight N c R x = 0 := by
  exact exitHarmonic_zero_inside N _ c x (torusDisk_subset N c r R hrR hx)

theorem nested_harmonic_potential_zero (N : Size) (c : Vertex N) (γ q : ℝ)
    (hsep : r8NestedScale γ q+2*(r8NestedScale γ q)^γ < q) :
    ∀ x ∈ torusDisk N c (Real.exp (r8NestedScale γ q+2*(r8NestedScale γ q)^γ)),
      diskHarmonicWeight N c (Real.exp (q+1)) x/g = 0 := by
  intro x hx
  rw [diskHarmonicWeight_zero_subdisk N c x _ _ (Real.exp_le_exp.mpr (by linarith)) hx,zero_div]

theorem nested_harmonic_potential_zero_eventually (γ : ℝ) (hγ : 0 < γ) (hγ1 : γ < 1) :
    ∀ᶠ q : ℝ in atTop, ∀ N : Size, ∀ c : Vertex N,
      ∀ x ∈ torusDisk N c (Real.exp (r8NestedScale γ q+2*(r8NestedScale γ q)^γ)),
      diskHarmonicWeight N c (Real.exp (q+1)) x/g = 0 := by
  filter_upwards [r8_nested_scale_geometry γ hγ hγ1] with q hq
  exact fun N c => nested_harmonic_potential_zero N c γ q hq.2.2.2.2.2.2.2.2.2.2


end TorusCoverTime.Blocks.B

