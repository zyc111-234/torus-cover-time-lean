import Solutions.Blocks.B.SparseIntegerGrid
import Mathlib.Algebra.Order.Floor.Ring

noncomputable section
namespace TorusCoverTime.Blocks.B

/-- The last ordinary disk is separated by a fixed gap from the macroscopic disk. -/
def bt6GridLength (L : ℝ) (K : ℕ) : ℕ := ⌊L/(K:ℝ)⌋₊
def bt6LastInteger (L : ℝ) (K : ℕ) : ℕ := ⌊L⌋₊-K
def bt6GridClearance (S : ℝ) (K : ℕ) : ℕ := ⌊S/(2*(K:ℝ))⌋₊

theorem bt6_grid_choice (L S : ℝ) (K : ℕ) (hK : 0<K)
    (hL : 2*(K:ℝ)≤L) (hS : 4*(K:ℝ)≤S) (hSL : S≤L/4) :
    let n := bt6GridLength L K
    let M := bt6LastInteger L K
    let r := bt6GridClearance S K
    0<n ∧ (K:ℝ)*n≤L ∧ L<(K:ℝ)*(n+1) ∧ K*(n-1)≤M ∧ M<K*n ∧
      (M:ℝ)≤L ∧ L-S≤M ∧ 1≤r ∧ 2*r≤n ∧ (r:ℝ)≤S/(2*K) ∧
      L/(2*K)≤n ∧ S/(4*K)≤r ∧ (M+2:ℕ)≤2*L ∧ (M:ℝ)+1≤L-K+1 := by
  dsimp only
  let n := bt6GridLength L K
  let M := bt6LastInteger L K
  let r := bt6GridClearance S K
  have hk : (0:ℝ)<K := by exact_mod_cast hK
  have hk1 : (1:ℝ)≤K := by exact_mod_cast hK
  have hl0 : 0≤L := by linarith
  have hs0 : 0≤S := by linarith
  have hnlo : (n:ℝ)≤L/K := Nat.floor_le (div_nonneg hl0 hk.le)
  have hnhi : L/K<(n:ℝ)+1 := Nat.lt_floor_add_one (L/K)
  have hn2 : 2≤n := by
    apply (Nat.le_floor_iff (div_nonneg hl0 hk.le)).mpr
    exact (le_div_iff₀ hk).mpr (by simpa using hL)
  have hnl : (K:ℝ)*n≤L := by have := (le_div_iff₀ hk).mp hnlo; nlinarith
  have hnu : L<(K:ℝ)*(n+1) := by have := (div_lt_iff₀ hk).mp hnhi; nlinarith
  have hfl := Nat.floor_le hl0
  have hfu := Nat.lt_floor_add_one L
  have hkfl : K≤⌊L⌋₊ := (Nat.le_floor_iff hl0).mpr (by linarith)
  have hMc : (M:ℝ)=(⌊L⌋₊:ℝ)-K := Nat.cast_sub hkfl
  have hkn : K*n≤⌊L⌋₊ := (Nat.le_floor_iff hl0).mpr (by exact_mod_cast hnl)
  have hfkn : ⌊L⌋₊<K*(n+1) := by
    have hh : (⌊L⌋₊:ℝ)<((K*(n+1):ℕ):ℝ) := by push_cast; linarith
    exact_mod_cast hh
  have hmlo : K*(n-1)≤M := by
    dsimp only [M,bt6LastInteger]
    rw [Nat.mul_sub_left_distrib,Nat.mul_one]
    exact Nat.sub_le_sub_right hkn K
  have hmhi : M<K*n := by
    dsimp only [M,bt6LastInteger]
    rw [Nat.mul_add,Nat.mul_one] at hfkn
    omega
  have hmL : (M:ℝ)≤L := by rw [hMc]; linarith
  have hrlo : (r:ℝ)≤S/(2*K) := Nat.floor_le (by positivity)
  have hrhi : S/(2*K)<(r:ℝ)+1 := Nat.lt_floor_add_one _
  have hr1 : 1≤r := by
    apply (Nat.le_floor_iff (by positivity : 0≤S/(2*K))).mpr
    exact (le_div_iff₀ (by positivity)).mpr (by norm_num; linarith)
  have hrn : 2*r≤n := by
    have hh : (2:ℝ)*r≤n := by
      have hrk := (le_div_iff₀ (by positivity : 0<2*(K:ℝ))).mp hrlo
      have hnk := (div_lt_iff₀ hk).mp hnhi
      nlinarith
    exact_mod_cast hh
  refine ⟨by omega,hnl,hnu,hmlo,hmhi,hmL,?_,hr1,hrn,hrlo,?_,?_,?_,?_⟩
  · rw [hMc]; linarith
  · apply (div_le_iff₀ (by positivity : 0<2*(K:ℝ))).mpr
    have hh : (2:ℝ)≤n := by exact_mod_cast hn2
    nlinarith
  · apply (div_le_iff₀ (by positivity : 0<4*(K:ℝ))).mpr
    have hh := (div_lt_iff₀ (by positivity : 0<2*(K:ℝ))).mp hrhi
    have hr2 : 2≤r := by
      apply (Nat.le_floor_iff (by positivity : 0≤S/(2*K))).mpr
      exact (le_div_iff₀ (by positivity)).mpr (by norm_num; nlinarith)
    have hh2 : (2:ℝ)≤r := by exact_mod_cast hr2
    nlinarith
  · push_cast
    linarith
  · rw [hMc]; linarith

end TorusCoverTime.Blocks.B
