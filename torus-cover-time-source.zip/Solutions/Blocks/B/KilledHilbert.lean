import Solutions.Blocks.B.KilledDiscrete
import Solutions.Blocks.B.KilledSimplicity
import Mathlib.Analysis.InnerProductSpace.Spectrum

/-! The killed transition is self-adjoint on the actual functions vanishing on the target. -/

noncomputable section
open Classical
open scoped BigOperators RealInnerProductSpace
namespace TorusCoverTime.Blocks.B

lemma killedStep_vanishes (N : Size) (A : Finset (Vertex N)) (f : Vertex N → ℝ) :
    vanishesOn N A (killedStep N A f) := by
  intro x hx
  simp [killedStep, hx]

lemma killedStep_add (N : Size) (A : Finset (Vertex N)) (f g : Vertex N → ℝ) :
    killedStep N A (f + g) = killedStep N A f + killedStep N A g := by
  funext x
  simp only [killedStep, Pi.add_apply, Finset.sum_add_distrib, add_div]
  split_ifs <;> simp

lemma killedStep_smul (N : Size) (A : Finset (Vertex N)) (c : ℝ) (f : Vertex N → ℝ) :
    killedStep N A (c • f) = c • killedStep N A f := by
  funext x
  simp only [killedStep, Pi.smul_apply, smul_eq_mul, ← Finset.mul_sum]
  split_ifs <;> simp [mul_div_assoc]

lemma killedStep_off_target (N : Size) (A : Finset (Vertex N))
    (f : Vertex N → ℝ) (x : Vertex N) (hx : x ∉ A) :
    killedStep N A f x = f x + generator N f x := by
  simp [killedStep, hx, generator, Finset.sum_sub_distrib]
  ring

def killedSubspace (N : Size) (A : Finset (Vertex N)) :
    Submodule ℝ (EuclideanSpace ℝ (Vertex N)) where
  carrier := {f | vanishesOn N A f}
  zero_mem' := by intro x _; rfl
  add_mem' := by
    intro f g hf hg x hx
    change f x + g x = 0
    rw [hf x hx, hg x hx, add_zero]
  smul_mem' := by intro c f hf x hx; change c * f x = 0; rw [hf x hx, mul_zero]

abbrev KilledSpace (N : Size) (A : Finset (Vertex N)) := ↥(killedSubspace N A)

def killedValue {N : Size} {A : Finset (Vertex N)} (f : KilledSpace N A) : Vertex N → ℝ := f.val

def killedLift (N : Size) (A : Finset (Vertex N))
    (f : Vertex N → ℝ) (hf : vanishesOn N A f) : KilledSpace N A :=
  ⟨WithLp.toLp 2 f, hf⟩

lemma killedValue_vanishes {N : Size} {A : Finset (Vertex N)} (f : KilledSpace N A) :
    vanishesOn N A (killedValue f) := f.property

lemma killed_inner {N : Size} {A : Finset (Vertex N)} (f g : KilledSpace N A) :
    ⟪f, g⟫ = ∑ x : Vertex N, killedValue f x * killedValue g x := by
  change inner ℝ f.val g.val = _
  simp only [PiLp.inner_apply, RCLike.inner_apply, conj_trivial, killedValue, mul_comm]

def killedTransition (N : Size) (A : Finset (Vertex N)) : Module.End ℝ (KilledSpace N A) where
  toFun f := killedLift N A (killedStep N A (killedValue f)) (killedStep_vanishes N A _)
  map_add' := by
    intro f g
    apply Subtype.ext
    ext x
    exact congrFun (killedStep_add N A (killedValue f) (killedValue g)) x
  map_smul' := by
    intro c f
    apply Subtype.ext
    ext x
    exact congrFun (killedStep_smul N A c (killedValue f)) x

lemma killedTransition_value {N : Size} {A : Finset (Vertex N)} (f : KilledSpace N A) :
    killedValue (killedTransition N A f) = killedStep N A (killedValue f) := rfl

lemma killedTransition_inner {N : Size} {A : Finset (Vertex N)} (f g : KilledSpace N A) :
    ⟪f, killedTransition N A g⟫ = ⟪f, g⟫ - dirichletPairing N (killedValue f) (killedValue g) := by
  rw [killed_inner, killed_inner, killedTransition_value, dirichletPairing,
    ← Finset.sum_sub_distrib]
  apply Finset.sum_congr rfl
  intro x _
  by_cases hx : x ∈ A
  · rw [killedValue_vanishes f x hx]
    ring
  · rw [killedStep_off_target N A _ x hx]
    ring

lemma killedTransition_symmetric (N : Size) (A : Finset (Vertex N)) :
    (killedTransition N A).IsSymmetric := by
  intro f g
  rw [← real_inner_comm (killedTransition N A f) g, killedTransition_inner,
    killedTransition_inner, real_inner_comm g f, dirichletPairing_symm]

def killedBasis (N : Size) (A : Finset (Vertex N)) :
    OrthonormalBasis (Fin (Module.finrank ℝ (KilledSpace N A))) ℝ (KilledSpace N A) :=
  (killedTransition_symmetric N A).eigenvectorBasis rfl

def killedModeRate (N : Size) (A : Finset (Vertex N))
    (i : Fin (Module.finrank ℝ (KilledSpace N A))) : ℝ :=
  1 - (killedTransition_symmetric N A).eigenvalues rfl i

lemma killedBasis_eigen (N : Size) (A : Finset (Vertex N))
    (i : Fin (Module.finrank ℝ (KilledSpace N A))) :
    killedTransition N A (killedBasis N A i) =
      (1 - killedModeRate N A i) • killedBasis N A i := by
  simpa [killedBasis, killedModeRate] using
    (killedTransition_symmetric N A).apply_eigenvectorBasis rfl i

lemma killedBasis_generator (N : Size) (A : Finset (Vertex N))
    (i : Fin (Module.finrank ℝ (KilledSpace N A))) (x : Vertex N) (hx : x ∉ A) :
    -generator N (killedValue (killedBasis N A i)) x =
      killedModeRate N A i * killedValue (killedBasis N A i) x := by
  have h := congrArg (fun f : KilledSpace N A => killedValue f x) (killedBasis_eigen N A i)
  change killedStep N A (killedValue (killedBasis N A i)) x =
    (1 - killedModeRate N A i) * killedValue (killedBasis N A i) x at h
  rw [killedStep_off_target N A _ x hx] at h
  linarith

end TorusCoverTime.Blocks.B
