import Solutions.Blocks.B.ConditionedRecordProduct
import Solutions.Blocks.B.ExitSpliceOccupation
import Solutions.Blocks.B.RootExcursionOccupation

/-! A compatible endpoint word turns the sequential records into consecutive
segments of the original path. Cumulative jump indices, physical times, and
occupation integrals agree exactly with the sums of the recorded quantities. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

def exitChainIndex (N : Size) (D : ℕ → Finset (Vertex N)) (a : ℕ → Vertex N)
    (k : ℕ) (ω : WalkSample) : ℕ :=
  ∑ j ∈ Finset.range k, (exitChainRecord N D a j ω).1

def exitChainTime (N : Size) (D : ℕ → Finset (Vertex N)) (a : ℕ → Vertex N)
    (k : ℕ) (ω : WalkSample) : ℝ := jumpTime ω (exitChainIndex N D a k ω)

@[simp] theorem exitChainIndex_zero (N : Size) (D : ℕ → Finset (Vertex N))
    (a : ℕ → Vertex N) (ω : WalkSample) : exitChainIndex N D a 0 ω = 0 := by
  simp [exitChainIndex]

theorem exitChainIndex_succ (N : Size) (D : ℕ → Finset (Vertex N))
    (a : ℕ → Vertex N) (k : ℕ) (ω : WalkSample) :
    exitChainIndex N D a (k+1) ω = exitChainIndex N D a k ω +
      finiteExitIndex N (D k) (a k) (exitChainTail N D a k ω) :=
  Finset.sum_range_succ _ _

theorem exitChainTail_succ (N : Size) (D : ℕ → Finset (Vertex N))
    (a : ℕ → Vertex N) (k : ℕ) (ω : WalkSample) :
    exitChainTail N D a (k+1) ω = finiteExitTail N (D k) (a k) (exitChainTail N D a k ω) :=
  congrFun (sequentialTail_succ_last _ k) ω

theorem exitChainTail_eq_shift (N : Size) (D : ℕ → Finset (Vertex N))
    (a : ℕ → Vertex N) (k : ℕ) (ω : WalkSample) :
    exitChainTail N D a k ω = fun j => ω (exitChainIndex N D a k ω+j) := by
  induction k with
  | zero => simp [exitChainTail, sequentialTail]
  | succ k ih =>
    rw [exitChainTail_succ]
    funext j
    change exitChainTail N D a k ω
      (finiteExitIndex N (D k) (a k) (exitChainTail N D a k ω)+j) = _
    rw [exitChainIndex_succ]
    exact (congrFun ih _).trans (congrArg ω (Nat.add_assoc _ _ _).symm)

theorem exitChainIndex_mono (N : Size) (D : ℕ → Finset (Vertex N))
    (a : ℕ → Vertex N) (ω : WalkSample) : Monotone (fun k => exitChainIndex N D a k ω) := by
  apply monotone_nat_of_le_succ
  intro k
  rw [exitChainIndex_succ]
  omega

theorem exitChainIndex_measurable (N : Size) (D : ℕ → Finset (Vertex N))
    (hD : ∀ k, ∃ b : Vertex N, b ∉ D k) (a : ℕ → Vertex N) (k : ℕ) :
    Measurable (exitChainIndex N D a k) :=
  Finset.measurable_sum _ fun j _ => (exitChainRecord_measurable N D hD a j).fst

theorem exitChainTime_measurable (N : Size) (D : ℕ → Finset (Vertex N))
    (hD : ∀ k, ∃ b : Vertex N, b ∉ D k) (a : ℕ → Vertex N) (k : ℕ) :
    Measurable (exitChainTime N D a k) :=
  excursionRecordDuration_measurable.comp
    ((exitChainIndex_measurable N D hD a k).prodMk measurable_id)

theorem exitChainEndpoints_spec (N : Size) (D : ℕ → Finset (Vertex N))
    (a b : ℕ → Vertex N) (n : ℕ) (ω : WalkSample)
    (hω : ω ∈ exitChainEndpoints N D a b n) (k : ℕ) (hk : k < n) :
    exitsThroughAt N (D k) (a k) (b k) (exitChainTail N D a k ω)
      (finiteExitIndex N (D k) (a k) (exitChainTail N D a k ω)) := by
  have hs := hω ⟨k, hk⟩
  change exitsThroughAt N (D k) (a k) (b k)
    (finiteExitRecord N (D k) (a k) (exitChainTail N D a k ω)).2
      (finiteExitIndex N (D k) (a k) (exitChainTail N D a k ω)) at hs
  exact (exitsThroughAt_prefix N (D k) (a k) (b k) _
    (finiteExitRecord_agrees N (D k) (a k) _)).mp hs

theorem exitChain_position (N : Size) (D : ℕ → Finset (Vertex N))
    (a b : ℕ → Vertex N) (n : ℕ) (hab : ∀ k < n, b k = a (k+1))
    (ω : WalkSample) (hω : ω ∈ exitChainEndpoints N D a b n) :
    ∀ k ≤ n, position N (a 0) ω (exitChainIndex N D a k ω) = a k := by
  intro k
  induction k with
  | zero => intro _; simp
  | succ k ih =>
    intro hk
    rw [exitChainIndex_succ, position_shift_sample, ih (by omega), ← exitChainTail_eq_shift]
    exact (exitChainEndpoints_spec N D a b n ω hω k (by omega)).2.1.trans (hab k (by omega))

theorem exitChainTime_succ (N : Size) (D : ℕ → Finset (Vertex N))
    (a : ℕ → Vertex N) (k : ℕ) (ω : WalkSample) :
    exitChainTime N D a (k+1) ω = exitChainTime N D a k ω +
      excursionRecordDuration (exitChainRecord N D a k ω) := by
  rw [exitChainTime, exitChainIndex_succ, jumpTime_shift_sample, ← exitChainTail_eq_shift]
  congr 1
  exact finiteExitDuration_eq_record N (D k) (a k) _

theorem exitChainTime_eq_sum (N : Size) (D : ℕ → Finset (Vertex N))
    (a : ℕ → Vertex N) (k : ℕ) (ω : WalkSample) :
    exitChainTime N D a k ω =
      ∑ j ∈ Finset.range k, excursionRecordDuration (exitChainRecord N D a j ω) := by
  induction k with
  | zero => simp [exitChainTime]
  | succ k ih => rw [exitChainTime_succ, ih, Finset.sum_range_succ]

theorem finiteExit_holdingCost_eq_record (N : Size) (D : Finset (Vertex N))
    (a : Vertex N) (U : Vertex N → ℝ) (ω : WalkSample) :
    (∑ j ∈ Finset.range (finiteExitIndex N D a ω), U (position N a ω j)*holdingTime ω j) =
      excursionRecordCost N a U (finiteExitRecord N D a ω) := by
  apply Finset.sum_congr rfl
  intro j hj
  have hj' := Finset.mem_range.mp hj
  rw [finiteExitRecord_position N D a ω j hj'.le]
  simp only [holdingTime, finiteExitRecord_agrees N D a ω j hj']

theorem exitChain_holdingCost_eq_sum (N : Size) (D : ℕ → Finset (Vertex N))
    (a b : ℕ → Vertex N) (n : ℕ) (hab : ∀ k < n, b k = a (k+1))
    (ω : WalkSample) (hω : ω ∈ exitChainEndpoints N D a b n) (U : Vertex N → ℝ) :
    ∀ k ≤ n, (∑ j ∈ Finset.range (exitChainIndex N D a k ω),
      U (position N (a 0) ω j)*holdingTime ω j) =
      ∑ j ∈ Finset.range k, excursionRecordCost N (a j) U (exitChainRecord N D a j ω) := by
  intro k
  induction k with
  | zero => intro _; simp
  | succ k ih =>
    intro hk
    rw [exitChainIndex_succ, Finset.sum_range_add, ih (by omega), Finset.sum_range_succ]
    congr 1
    simp_rw [position_shift_sample, exitChain_position N D a b n hab ω hω k (by omega),
      ← exitChainTail_eq_shift]
    have he (j : ℕ) : holdingTime ω (exitChainIndex N D a k ω+j) =
        holdingTime (exitChainTail N D a k ω) j := by
      rw [holdingTime, holdingTime, exitChainTail_eq_shift]
    simp_rw [he]
    exact finiteExit_holdingCost_eq_record N (D k) (a k) U _

theorem exitChain_weighted_occupation_eq_sum (N : Size) (D : ℕ → Finset (Vertex N))
    (a b : ℕ → Vertex N) (n : ℕ) (hab : ∀ k < n, b k = a (k+1))
    (ω : WalkSample) (hω : ω ∈ exitChainEndpoints N D a b n)
    (hpos : ∀ j, 0 < (ω j).1) (hnon : Tendsto (jumpTime ω) atTop atTop)
    (U : Vertex N → ℝ) (k : ℕ) (hk : k ≤ n) :
    (∑ x, U x*localTime N (a 0) ω (exitChainTime N D a k ω) x) =
      ∑ j ∈ Finset.range k, excursionRecordCost N (a j) U (exitChainRecord N D a j ω) := by
  simp_rw [exitChainTime, localTime_jumpTime_eq_sum_holding N (a 0) _ hpos hnon, Finset.mul_sum]
  rw [Finset.sum_comm]
  convert exitChain_holdingCost_eq_sum N D a b n hab ω hω U k hk using 1
  apply Finset.sum_congr rfl
  intro j _
  simp [mul_ite, eq_comm]

theorem exitChain_occupation_increment (N : Size) (D : ℕ → Finset (Vertex N))
    (a b : ℕ → Vertex N) (n : ℕ) (hab : ∀ k < n, b k = a (k+1))
    (ω : WalkSample) (hω : ω ∈ exitChainEndpoints N D a b n)
    (hpos : ∀ j, 0 < (ω j).1) (hnon : Tendsto (jumpTime ω) atTop atTop)
    (U : Vertex N → ℝ) (k : ℕ) (hk : k < n) :
    (∑ x, U x*(localTime N (a 0) ω (exitChainTime N D a (k+1) ω) x -
      localTime N (a 0) ω (exitChainTime N D a k ω) x)) =
      excursionRecordCost N (a k) U (exitChainRecord N D a k ω) := by
  simp_rw [mul_sub]
  rw [Finset.sum_sub_distrib,
    exitChain_weighted_occupation_eq_sum N D a b n hab ω hω hpos hnon U (k+1) (by omega),
    exitChain_weighted_occupation_eq_sum N D a b n hab ω hω hpos hnon U k hk.le,
    Finset.sum_range_succ]
  ring

end TorusCoverTime.Blocks.B
