import Solutions.Blocks.B.ContinuousFourier

/-! Actual hitting-time survival is exactly avoidance along the finite jump-count prefix. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter
open Classical
open scoped BigOperators ENNReal Topology
namespace TorusCoverTime.Blocks.B

def discreteAvoids (N : Size) (start : Vertex N) (A : Finset (Vertex N))
    (ω : WalkSample) (n : ℕ) : Prop := ∀ k ≤ n, position N start ω k ∉ A

lemma survival_iff_discreteAvoids (N : Size) (start : Vertex N) (A : Finset (Vertex N))
    {ω : WalkSample} (hpos : ∀ j, 0 < (ω j).1)
    (hnon : Tendsto (jumpTime ω) atTop atTop) (t : ℝ) (ht : 0 ≤ t) :
    (∀ a ∈ A, ENNReal.ofReal t < hittingTime N start ω a) ↔
      discreteAvoids N start A ω (jumpCount ω t) := by
  classical
  have hb := (jumpCount_eq_iff_on_regular_sample hpos hnon t ht (jumpCount ω t)).mp rfl
  have hmono := (jumpTime_strictMono hpos).monotone
  constructor
  · intro hsurv k hk hvisit
    have hhit : hittingTime N start ω (position N start ω k) ≤ ENNReal.ofReal t := by
      rw [hittingTime_eq_discrete N start hpos hnon, discreteHittingTime]
      calc
        _ ≤ ENNReal.ofReal (jumpTime ω k) := iInf_le_of_le k (by simp)
        _ ≤ ENNReal.ofReal t := ENNReal.ofReal_le_ofReal ((hmono hk).trans hb.1)
    exact (not_lt_of_ge hhit) (hsurv _ hvisit)
  · intro havoid a ha
    have hgap : ENNReal.ofReal t < ENNReal.ofReal (jumpTime ω (jumpCount ω t + 1)) :=
      (ENNReal.ofReal_lt_ofReal_iff_of_nonneg ht).mpr hb.2
    apply hgap.trans_le
    rw [hittingTime_eq_discrete N start hpos hnon, discreteHittingTime]
    apply le_iInf
    intro k
    split_ifs with hk
    · have hkn : jumpCount ω t < k := by
        by_contra! hkn
        exact havoid k hkn (hk ▸ ha)
      exact ENNReal.ofReal_le_ofReal (hmono (Nat.succ_le_of_lt hkn))
    · exact le_top

lemma survival_ae_discreteAvoids (hWalk : WalkModelRegular)
    (N : Size) (start : Vertex N) (A : Finset (Vertex N)) (t : ℝ) (ht : 0 ≤ t) :
    ∀ᵐ ω ∂walkLaw, (∀ a ∈ A, ENNReal.ofReal t < hittingTime N start ω a) ↔
      discreteAvoids N start A ω (jumpCount ω t) := by
  filter_upwards [hWalk.1] with ω hω
  exact survival_iff_discreteAvoids N start A hω.1 hω.2 t ht

lemma measurableSet_discreteAvoids (N : Size) (start : Vertex N)
    (A : Finset (Vertex N)) (n : ℕ) : MeasurableSet {ω | discreteAvoids N start A ω n} := by
  have heq : {ω | discreteAvoids N start A ω n} =
      {ω : WalkSample | ∀ k ≤ n, ∀ a ∈ A, position N start ω k ≠ a} := by
    ext ω
    constructor
    · intro h k hk a ha heq
      exact h k hk (heq ▸ ha)
    · intro h k hk hm
      exact h k hk _ hm rfl
  rw [heq]
  simp only [Set.ofPred_forall]
  apply MeasurableSet.iInter
  intro k
  apply MeasurableSet.iInter
  intro _
  apply MeasurableSet.iInter
  intro a
  apply MeasurableSet.iInter
  intro _
  exact (measurable_position_eq N start a k).setOf.compl

lemma measurableSet_discreteAvoids_count (N : Size) (start : Vertex N)
    (A : Finset (Vertex N)) (t : ℝ) :
    MeasurableSet {ω | discreteAvoids N start A ω (jumpCount ω t)} := by
  have heq : {ω | discreteAvoids N start A ω (jumpCount ω t)} =
      ⋃ n : ℕ, {ω : WalkSample | jumpCount ω t = n} ∩ {ω | discreteAvoids N start A ω n} := by
    ext ω
    simp only [Set.mem_ofPred_eq, Set.mem_iUnion, Set.mem_inter_iff]
    constructor
    · intro h
      exact ⟨jumpCount ω t, rfl, h⟩
    · rintro ⟨n, hn, h⟩
      simpa only [hn] using h
  rw [heq]
  apply MeasurableSet.iUnion
  intro n
  apply MeasurableSet.inter _ (measurableSet_discreteAvoids N start A n)
  exact (measurableSet_singleton n).preimage
    (measurable_jumpCount_joint.comp (measurable_prodMk_right (y := t)))

lemma survival_probability_discrete (hWalk : WalkModelRegular)
    (N : Size) (start : Vertex N) (A : Finset (Vertex N)) (t : ℝ) (ht : 0 ≤ t) :
    (walkLaw {ω | ∀ a ∈ A, ENNReal.ofReal t < hittingTime N start ω a}).toReal =
      ∫ ω : WalkSample, if discreteAvoids N start A ω (jumpCount ω t) then (1 : ℝ) else 0 ∂walkLaw := by
  classical
  have heq : {ω | ∀ a ∈ A, ENNReal.ofReal t < hittingTime N start ω a} =ᵐ[walkLaw]
      {ω | discreteAvoids N start A ω (jumpCount ω t)} := by
    filter_upwards [survival_ae_discreteAvoids hWalk N start A t ht] with ω hω
    exact propext hω
  rw [measure_congr heq]
  symm
  simpa [Set.indicator, Measure.real] using integral_indicator_const (μ := walkLaw) (1 : ℝ)
    (measurableSet_discreteAvoids_count N start A t)

end TorusCoverTime.Blocks.B
