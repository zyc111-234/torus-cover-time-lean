import Solutions.Blocks.B.SequentialTailLaw
import Solutions.Blocks.B.ExitChainPath

/-! Joint disintegration of all finite stopped segments and the unused tail,
also after fixing every endpoint. No tail or exterior-path independence is an input. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

theorem cond_prod_left_law {Ω Z : Type*} [MeasurableSpace Ω] [MeasurableSpace Z]
    (μ : Measure Ω) [IsFiniteMeasure μ] (ν : Measure Z) [IsProbabilityMeasure ν]
    (E : Set Ω) (hE : MeasurableSet E) :
    (μ.prod ν)[|E ×ˢ Set.univ] = (μ[|E]).prod ν := by
  apply Measure.ext_prod
  intro S F hS hF
  rw [cond_apply (hE.prod MeasurableSet.univ), Measure.prod_prod, Measure.prod_prod, cond_apply hE]
  have he : (E ×ˢ Set.univ) ∩ (S ×ˢ F) = (E ∩ S) ×ˢ F := by ext p; simp; tauto
  rw [he, Measure.prod_prod, measure_univ, mul_one, mul_assoc]

theorem exitChainRecord_tail_law (N : Size) (D : ℕ → Finset (Vertex N))
    (hD : ∀ k, ∃ b : Vertex N, b ∉ D k) (a : ℕ → Vertex N) (n : ℕ) :
    walkLaw.map (fun ω => ((fun j : Fin n => exitChainRecord N D a j.val ω), exitChainTail N D a n ω)) =
      (Measure.pi (fun j : Fin n => walkLaw.map (finiteExitRecord N (D j.val) (a j.val)))).prod walkLaw :=
  sequentialRecord_prefix_tail_law _ _ (fun j => finiteExitRecord_measurable N (D j) (a j))
    (fun j => finiteExitTail_measurePreserving N (D j) (hD j) (a j))
    (fun j => finiteExitRecord_tail_independent N (D j) (hD j) (a j)) n

theorem exitChainRecord_conditioned_tail_law (N : Size) (D : ℕ → Finset (Vertex N))
    (hD : ∀ k, ∃ b : Vertex N, b ∉ D k) (a b : ℕ → Vertex N) (n : ℕ) :
    (walkLaw[|exitChainEndpoints N D a b n]).map
      (fun ω => ((fun j : Fin n => exitChainRecord N D a j.val ω), exitChainTail N D a n ω)) =
      (Measure.pi (fun j : Fin n => exactExitRecordLaw N (D j.val) (a j.val) (b j.val))).prod walkLaw := by
  let X := fun ω => ((fun j : Fin n => exitChainRecord N D a j.val ω), exitChainTail N D a n ω)
  let E := fun j : Fin n => exitRecordEvent N (D j.val) (a j.val) (b j.val)
  have hX : Measurable X := (measurable_pi_lambda _ fun j : Fin n => exitChainRecord_measurable N D hD a j.val).prodMk
    (exitChainTail_measurePreserving N D hD a n).measurable
  have hE : MeasurableSet (Set.pi Set.univ E) :=
    MeasurableSet.univ_pi fun j => exitRecordEvent_measurable N (D j.val) (a j.val) (b j.val)
  have he : exitChainEndpoints N D a b n = X ⁻¹' ((Set.pi Set.univ E) ×ˢ Set.univ) := by
    ext ω
    simp [exitChainEndpoints, X, E]
  rw [he, map_cond_preimage_law walkLaw X hX _ (hE.prod MeasurableSet.univ)]
  change (walkLaw.map (fun ω => ((fun j : Fin n => exitChainRecord N D a j.val ω),
    exitChainTail N D a n ω)))[|(Set.pi Set.univ E) ×ˢ Set.univ] = _
  rw [exitChainRecord_tail_law N D hD a n, cond_prod_left_law _ walkLaw _ hE,
    cond_pi_law _ E (fun j => exitRecordEvent_measurable N (D j.val) (a j.val) (b j.val))]
  dsimp only [E]
  simp_rw [← exactExitRecordLaw_eq_cond]

theorem exitChainEndpoints_measurable (N : Size) (D : ℕ → Finset (Vertex N))
    (hD : ∀ k, ∃ b : Vertex N, b ∉ D k) (a b : ℕ → Vertex N) (n : ℕ) :
    MeasurableSet (exitChainEndpoints N D a b n) := by
  simp only [exitChainEndpoints, Set.ofPred_forall]
  exact MeasurableSet.iInter fun j => (exitRecordEvent_measurable N (D j.val) (a j.val) (b j.val)).preimage
    (exitChainRecord_measurable N D hD a j.val)

theorem lintegral_exitChain_record_tail (N : Size) (D : ℕ → Finset (Vertex N))
    (hD : ∀ k, ∃ b : Vertex N, b ∉ D k) (a b : ℕ → Vertex N) (n : ℕ)
    (F : (Fin n → ℕ × WalkSample) × WalkSample → ℝ≥0∞) (hF : Measurable F) :
    (∫⁻ ω, F ((fun j : Fin n => exitChainRecord N D a j.val ω), exitChainTail N D a n ω)
      ∂walkLaw[|exitChainEndpoints N D a b n]) =
      ∫⁻ p, ∫⁻ η, F (p,η) ∂walkLaw
        ∂Measure.pi (fun j : Fin n => exactExitRecordLaw N (D j.val) (a j.val) (b j.val)) := by
  rw [← lintegral_map hF ((measurable_pi_lambda _ fun j : Fin n => exitChainRecord_measurable N D hD a j.val).prodMk
    (exitChainTail_measurePreserving N D hD a n).measurable),
    exitChainRecord_conditioned_tail_law N D hD a b n]
  exact lintegral_prod _ hF.aemeasurable

end TorusCoverTime.Blocks.B
