import Solutions.Blocks.B.BT6FiniteBound

noncomputable section
namespace TorusCoverTime.Blocks.B

def bt6MainConstant (K : ℕ) (C : ℝ) : ℝ :=
  4*(K:ℝ)^2*bridgeContactConstant ((K:ℝ)+2*C)*
    (2+bridgeBarrierPadding ((K:ℝ)+2*C))^2*(4+bridgeBarrierPadding ((K:ℝ)+2*C))^3

theorem bt6MainConstant_pos (K : ℕ) (C : ℝ) (hK : 0<K) : 0<bt6MainConstant K C := by
  have hc : 0<bridgeContactConstant ((K:ℝ)+2*C) := by
    linarith [(bridgeContactConstant_bounds ((K:ℝ)+2*C)).1]
  have hp : 0≤bridgeBarrierPadding ((K:ℝ)+2*C) := by linarith [bridgeBarrierPadding_ge_two ((K:ℝ)+2*C)]
  unfold bt6MainConstant
  positivity

theorem bt6_main_bound (L S A C : ℝ) (K n r : ℕ) (hK : 0<K) (hL : 0<L) (hS : 0<S)
    (hA : 1≤A) (hn : L/(2*K)≤n) (hr : S/(4*K)≤r) :
    bridgeContactConstant ((K:ℝ)+2*C)*(2*A+bridgeBarrierPadding ((K:ℝ)+2*C))^2*
      (4*A+bridgeBarrierPadding ((K:ℝ)+2*C))^3/((n:ℝ)*Real.sqrt r)≤
      bt6MainConstant K C*A^5/(L*Real.sqrt S) := by
  let U := (K:ℝ)+2*C
  let p := bridgeBarrierPadding U
  let B := bridgeContactConstant U*(2+p)^2*(4+p)^3
  have hp : 0≤p := by dsimp [p]; linarith [bridgeBarrierPadding_ge_two U]
  have hc : 0≤bridgeContactConstant U := by linarith [(bridgeContactConstant_bounds U).1]
  have hB : 0≤B := by dsimp [B]; positivity
  have hk : (0:ℝ)<K := by exact_mod_cast hK
  have hk1 : (1:ℝ)≤K := by exact_mod_cast hK
  have hn' := (div_le_iff₀ (by positivity : 0<2*(K:ℝ))).mp hn
  have hr' := (div_le_iff₀ (by positivity : 0<4*(K:ℝ))).mp hr
  have hn0 : (0:ℝ)<n := lt_of_lt_of_le (by positivity) hn
  have hr0 : (0:ℝ)<r := lt_of_lt_of_le (by positivity) hr
  have hroot : Real.sqrt S≤2*(K:ℝ)*Real.sqrt r := by
    have hs := Real.sq_sqrt hS.le
    have hrs := Real.sq_sqrt hr0.le
    have hk2 : (K:ℝ)≤(K:ℝ)^2 := by nlinarith
    have hmul := mul_le_mul_of_nonneg_right hk2 (show 0≤4*(r:ℝ) by positivity)
    have hb : 0≤2*(K:ℝ)*Real.sqrt r := by positivity
    nlinarith [Real.sqrt_nonneg S]
  have hden : L*Real.sqrt S≤4*(K:ℝ)^2*((n:ℝ)*Real.sqrt r) := by
    calc
      _ ≤ (2*(K:ℝ)*n)*(2*(K:ℝ)*Real.sqrt r) := mul_le_mul (by nlinarith only [hn']) hroot (Real.sqrt_nonneg S) (by positivity)
      _ = _ := by ring
  have hnum : bridgeContactConstant U*(2*A+p)^2*(4*A+p)^3≤B*A^5 := by
    have h2 : 2*A+p≤(2+p)*A := by nlinarith
    have h4 : 4*A+p≤(4+p)*A := by nlinarith
    calc
      _ ≤ bridgeContactConstant U*((2+p)*A)^2*((4+p)*A)^3 := by gcongr
      _ = _ := by dsimp [B]; ring
  calc
    _ ≤ B*A^5/((n:ℝ)*Real.sqrt r) := div_le_div_of_nonneg_right hnum (by positivity)
    _ ≤ (4*(K:ℝ)^2*B*A^5)/(L*Real.sqrt S) := by
      apply (div_le_div_iff₀ (by positivity) (by positivity)).mpr
      have hh := mul_le_mul_of_nonneg_left hden (show 0≤B*A^5 by positivity)
      nlinarith only [hh]
    _ = _ := by dsimp [B,p,U,bt6MainConstant]; ring

theorem bt6_failure_absorption (L A : ℝ) (K M : ℕ) (hL : 1≤L) (hK : 0<K)
    (hAK : (K:ℝ)≤A) (hlog : (Real.log L)^2+4*Real.log L≤A) (hM : (M+2:ℕ)≤2*L) :
    (M+2:ℕ)*(2*Real.exp (-A/2)+2*Real.exp (-A^2/(2*K)))≤8*Real.exp (-((Real.log L)^2)/4) := by
  have hk : (0:ℝ)<K := by exact_mod_cast hK
  have hA : 0≤A := hk.le.trans hAK
  have he1 : -A/2≤-((Real.log L)^2)/4-Real.log L := by nlinarith [Real.log_nonneg hL,sq_nonneg (Real.log L)]
  have he2 : -A^2/(2*K)≤-A/2 := by
    apply (div_le_iff₀ (by positivity : 0<2*(K:ℝ))).mpr
    nlinarith [mul_nonneg hA (sub_nonneg.mpr hAK)]
  have he : Real.exp (-A/2)≤Real.exp (-((Real.log L)^2)/4)/L := by
    simpa only [Real.exp_sub,Real.exp_log (by linarith : 0<L)] using Real.exp_le_exp.mpr he1
  have he' : Real.exp (-A^2/(2*K))≤Real.exp (-((Real.log L)^2)/4)/L := (Real.exp_le_exp.mpr he2).trans he
  calc
    _ ≤ (2*L)*(4*(Real.exp (-((Real.log L)^2)/4)/L)) := by
      apply mul_le_mul hM (by linarith) (by positivity) (by positivity)
    _ = _ := by field_simp; ring

end TorusCoverTime.Blocks.B
