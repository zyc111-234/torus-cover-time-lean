import Definitions.FinitePotential
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Linarith

/-! The concrete eigenvalues have the exact gap claimed in S1.
These finite trigonometric facts do not assume any unproved walk theorem. -/

noncomputable section
open scoped BigOperators

namespace TorusCoverTime.Blocks.B

lemma vertexCount_pos (N : Size) : 0 < vertexCount N := by
  have := size_real_gt_one N
  unfold vertexCount
  positivity

lemma finiteEigenvalue_eq_sines (N : Size) (k : Vertex N) :
    finiteEigenvalue N k =
      Real.sin (Real.pi * k.1.val / N.val) ^ 2 +
      Real.sin (Real.pi * k.2.val / N.val) ^ 2 := by
  rw [Real.sin_sq_eq_half_sub, Real.sin_sq_eq_half_sub]
  simp only [finiteEigenvalue]
  ring_nf

lemma finite_sine_lower (N : Size) (k : ZMod N.val) (hk : k ≠ 0) :
    Real.sin (Real.pi / N.val) ≤ Real.sin (Real.pi * k.val / N.val) := by
  have hN : 0 < (N.val : ℝ) := lt_trans zero_lt_one (size_real_gt_one N)
  have hN3 : (3 : ℝ) ≤ N.val := by exact_mod_cast N.property
  have hk1 : (1 : ℝ) ≤ k.val := by exact_mod_cast (ZMod.val_pos.mpr hk)
  have hkN : (k.val : ℝ) + 1 ≤ N.val := by exact_mod_cast (ZMod.val_lt k)
  have hpi := Real.pi_pos
  have hleft : Real.pi / N.val ≤ Real.pi * k.val / N.val :=
    (div_le_div_iff_of_pos_right hN).mpr (by nlinarith)
  have hright : Real.pi * k.val / N.val ≤ Real.pi - Real.pi / N.val := by
    apply (le_sub_iff_add_le).mpr
    rw [← add_div]
    apply (div_le_iff₀ hN).mpr
    nlinarith
  have hbase : -(Real.pi / 2) ≤ Real.pi / N.val := by
    have : 0 ≤ Real.pi / N.val := by positivity
    linarith
  by_cases hhalf : Real.pi * k.val / N.val ≤ Real.pi / 2
  · exact Real.sin_le_sin_of_le_of_le_pi_div_two hbase hhalf hleft
  · have h := Real.sin_le_sin_of_le_of_le_pi_div_two hbase
      (show Real.pi - Real.pi * k.val / N.val ≤ Real.pi / 2 by linarith)
      (show Real.pi / N.val ≤ Real.pi - Real.pi * k.val / N.val by linarith)
    simpa only [Real.sin_pi_sub] using h

lemma spectralGap_pos (N : Size) : 0 < spectralGap N := by
  have hN := size_real_gt_one N
  have hangle : Real.pi / N.val < Real.pi := by
    apply (div_lt_iff₀ (by linarith : (0 : ℝ) < N.val)).mpr
    nlinarith [Real.pi_pos]
  exact sq_pos_of_pos (Real.sin_pos_of_pos_of_lt_pi (by positivity) hangle)

lemma spectralGap_le_eigenvalue (N : Size) (k : Vertex N) (hk : k ≠ 0) :
    spectralGap N ≤ finiteEigenvalue N k := by
  have hs0 : 0 ≤ Real.sin (Real.pi / N.val) := by
    have hN := size_real_gt_one N
    apply Real.sin_nonneg_of_nonneg_of_le_pi (by positivity)
    apply (div_le_iff₀ (by linarith : (0 : ℝ) < N.val)).mpr
    nlinarith [Real.pi_pos]
  rw [finiteEigenvalue_eq_sines]
  unfold spectralGap
  by_cases hfirst : k.1 = 0
  · have hsecond : k.2 ≠ 0 := by
      intro hsecond
      exact hk (Prod.ext hfirst hsecond)
    have hs := pow_le_pow_left₀ hs0 (finite_sine_lower N k.2 hsecond) 2
    nlinarith [sq_nonneg (Real.sin (Real.pi * k.1.val / N.val))]
  · have hs := pow_le_pow_left₀ hs0 (finite_sine_lower N k.1 hfirst) 2
    nlinarith [sq_nonneg (Real.sin (Real.pi * k.2.val / N.val))]

lemma eigenvalue_pos_of_nonzero (N : Size) {k : Vertex N}
    (hk : k ∈ nonzeroFrequencies N) : 0 < finiteEigenvalue N k := by
  exact (spectralGap_pos N).trans_le
    (spectralGap_le_eigenvalue N k (Finset.mem_erase.mp hk).1)

lemma spectralGap_attained (N : Size) :
    ∃ k ∈ nonzeroFrequencies N, finiteEigenvalue N k = spectralGap N := by
  have hN1 : N.val ≠ 1 := by have := N.property; omega
  refine ⟨(1, 0), ?_, ?_⟩
  · apply Finset.mem_erase.mpr
    refine ⟨?_, Finset.mem_univ _⟩
    intro heq
    have hval := congrArg (fun k : Vertex N => k.1.val) heq
    simp [ZMod.val_one'' hN1] at hval
  · rw [finiteEigenvalue_eq_sines]
    simp [ZMod.val_one'' hN1, spectralGap]

lemma abs_sine_square_error (x : ℝ) (hx : 0 ≤ x) :
    |Real.sin x ^ 2 - x ^ 2| ≤ x ^ 4 / 3 := by
  have hdiff : |Real.sin x - x| ≤ x ^ 3 / 6 := by
    simpa [abs_sub_comm, abs_of_nonneg hx] using Real.abs_sub_sin_le x
  have hsum : |Real.sin x + x| ≤ 2 * x := by
    calc
      |Real.sin x + x| ≤ |Real.sin x| + |x| := abs_add_le _ _
      _ ≤ 2 * x := by
        have h := Real.abs_sin_le_abs (x := x)
        rw [abs_of_nonneg hx] at h ⊢
        linarith
  calc
    |Real.sin x ^ 2 - x ^ 2| = |Real.sin x - x| * |Real.sin x + x| := by
      rw [← abs_mul]
      congr 1
      ring
    _ ≤ (x ^ 3 / 6) * (2 * x) :=
      mul_le_mul hdiff hsum (abs_nonneg _) (by positivity)
    _ = x ^ 4 / 3 := by ring

lemma spectralGap_relative_error (N : Size) :
    |vertexCount N * spectralGap N / Real.pi ^ 2 - 1| ≤
      (Real.pi ^ 2 / 3) / vertexCount N := by
  have hN : (N.val : ℝ) ≠ 0 := ne_of_gt (lt_trans zero_lt_one (size_real_gt_one N))
  have hpi := Real.pi_ne_zero
  have hc : 0 ≤ (N.val : ℝ) ^ 2 / Real.pi ^ 2 := by positivity
  unfold vertexCount spectralGap
  calc
    |(N.val : ℝ) ^ 2 * Real.sin (Real.pi / N.val) ^ 2 / Real.pi ^ 2 - 1|
        = ((N.val : ℝ) ^ 2 / Real.pi ^ 2) *
          |Real.sin (Real.pi / N.val) ^ 2 - (Real.pi / N.val) ^ 2| := by
      rw [← abs_of_nonneg hc, ← abs_mul]
      congr 1
      field_simp
    _ ≤ ((N.val : ℝ) ^ 2 / Real.pi ^ 2) * ((Real.pi / N.val) ^ 4 / 3) :=
      mul_le_mul_of_nonneg_left (abs_sine_square_error _ (by positivity)) hc
    _ = (Real.pi ^ 2 / 3) / (N.val : ℝ) ^ 2 := by field_simp

end TorusCoverTime.Blocks.B
