import Solutions.Blocks.B.DomainGreenOperator
import Mathlib.LinearAlgebra.FiniteDimensional.Basic

/-! Positive killing on the actual finite torus: the maximum principle and
existence/uniqueness for arbitrary Dirichlet data. -/

noncomputable section
open Classical
namespace TorusCoverTime.Blocks.B

theorem generator_nonneg_at_min (N : Size) (f : Vertex N → ℝ) (x : Vertex N)
    (hx : ∀ y, f x ≤ f y) : 0 ≤ generator N f x := by
  unfold generator
  exact mul_nonneg (by norm_num) (Finset.sum_nonneg fun d _ => sub_nonneg.mpr (hx _))

theorem massive_maximum_principle (N : Size) (D : Finset (Vertex N)) (μ : ℝ)
    (hμ : 0 < μ) (f : Vertex N → ℝ) (hb : ∀ x, x ∉ D → 0 ≤ f x)
    (hf : ∀ x ∈ D, 0 ≤ μ * f x - generator N f x) (x : Vertex N) : 0 ≤ f x := by
  obtain ⟨z, _, hz⟩ := Finset.exists_min_image (Finset.univ : Finset (Vertex N))
    f Finset.univ_nonempty
  have hmin (y : Vertex N) : f z ≤ f y := hz y (Finset.mem_univ y)
  have hz0 : 0 ≤ f z := by
    by_cases hzD : z ∈ D
    · have hg := generator_nonneg_at_min N f z hmin
      have hp : 0 ≤ μ * f z := by linarith [hf z hzD]
      exact (mul_nonneg_iff_of_pos_left hμ).mp hp
    · exact hb z hzD
  exact hz0.trans (hmin x)

def massiveDirichletMap (N : Size) (D : Finset (Vertex N)) (μ : ℝ) :
    (Vertex N → ℝ) →ₗ[ℝ] (Vertex N → ℝ) where
  toFun f x := if x ∈ D then μ * f x - generator N f x else f x
  map_add' f g := by
    funext x
    by_cases hx : x ∈ D
    · simp only [if_pos hx, Pi.add_apply, generator_add]
      ring
    · simp only [if_neg hx, Pi.add_apply]
  map_smul' c f := by
    funext x
    by_cases hx : x ∈ D
    · simp only [if_pos hx, Pi.smul_apply, smul_eq_mul]
      change μ * (c * f x) - generator N (fun z => c * f z) x =
        c * (μ * f x - generator N f x)
      rw [generator_mul_left]
      ring
    · simp only [if_neg hx, Pi.smul_apply, smul_eq_mul, RingHom.id_apply]

theorem massiveDirichletMap_injective (N : Size) (D : Finset (Vertex N)) (μ : ℝ)
    (hμ : 0 < μ) : Function.Injective (massiveDirichletMap N D μ) := by
  apply LinearMap.ker_eq_bot.mp
  apply LinearMap.ker_eq_bot'.mpr
  intro f hf
  have he (x : Vertex N) : (if x ∈ D then μ * f x - generator N f x else f x) = 0 :=
    congrFun hf x
  have hb (x : Vertex N) (hx : x ∉ D) : f x = 0 := by simpa only [if_neg hx] using he x
  have hg (x : Vertex N) (hx : x ∈ D) : μ * f x - generator N f x = 0 := by
    simpa only [if_pos hx] using he x
  funext x
  have hpos := massive_maximum_principle N D μ hμ f (fun z hz => (hb z hz).ge)
    (fun z hz => (hg z hz).ge) x
  have hneg := massive_maximum_principle N D μ hμ (fun z => (-1:ℝ) * f z)
    (fun z hz => by rw [hb z hz]; norm_num) (by
      intro z hz
      rw [generator_mul_left]
      linarith [hg z hz]) x
  change f x = 0
  linarith

theorem massiveDirichletMap_surjective (N : Size) (D : Finset (Vertex N)) (μ : ℝ)
    (hμ : 0 < μ) : Function.Surjective (massiveDirichletMap N D μ) :=
  (LinearMap.injective_iff_surjective).mp (massiveDirichletMap_injective N D μ hμ)

def massiveDirichletSolution (N : Size) (D : Finset (Vertex N)) (μ : ℝ)
    (hμ : 0 < μ) (f : Vertex N → ℝ) : Vertex N → ℝ :=
  Classical.choose (massiveDirichletMap_surjective N D μ hμ f)

theorem massiveDirichletSolution_spec (N : Size) (D : Finset (Vertex N)) (μ : ℝ)
    (hμ : 0 < μ) (f : Vertex N → ℝ) :
    massiveDirichletMap N D μ (massiveDirichletSolution N D μ hμ f) = f :=
  Classical.choose_spec (massiveDirichletMap_surjective N D μ hμ f)

theorem massiveDirichletSolution_boundary (N : Size) (D : Finset (Vertex N)) (μ : ℝ)
    (hμ : 0 < μ) (f : Vertex N → ℝ) (x : Vertex N) (hx : x ∉ D) :
    massiveDirichletSolution N D μ hμ f x = f x := by
  have h := congrFun (massiveDirichletSolution_spec N D μ hμ f) x
  simpa only [massiveDirichletMap, LinearMap.coe_mk, AddHom.coe_mk, if_neg hx] using h

theorem massiveDirichletSolution_generator (N : Size) (D : Finset (Vertex N)) (μ : ℝ)
    (hμ : 0 < μ) (f : Vertex N → ℝ) (x : Vertex N) (hx : x ∈ D) :
    μ * massiveDirichletSolution N D μ hμ f x -
      generator N (massiveDirichletSolution N D μ hμ f) x = f x := by
  have h := congrFun (massiveDirichletSolution_spec N D μ hμ f) x
  simpa only [massiveDirichletMap, LinearMap.coe_mk, AddHom.coe_mk, if_pos hx] using h

theorem massiveDirichletSolution_nonneg (N : Size) (D : Finset (Vertex N)) (μ : ℝ)
    (hμ : 0 < μ) (f : Vertex N → ℝ) (hf : ∀ x, 0 ≤ f x) (x : Vertex N) :
    0 ≤ massiveDirichletSolution N D μ hμ f x := by
  apply massive_maximum_principle N D μ hμ
  · intro z hz
    rw [massiveDirichletSolution_boundary N D μ hμ f z hz]
    exact hf z
  · intro z hz
    rw [massiveDirichletSolution_generator N D μ hμ f z hz]
    exact hf z

theorem massive_dirichlet_unique (N : Size) (D : Finset (Vertex N)) (μ : ℝ)
    (hμ : 0 < μ) (f g : Vertex N → ℝ)
    (hb : ∀ x, x ∉ D → f x = g x)
    (hg : ∀ x ∈ D, μ * f x - generator N f x = μ * g x - generator N g x) : f = g := by
  apply massiveDirichletMap_injective N D μ hμ
  funext x
  change (if x ∈ D then _ else _) = (if x ∈ D then _ else _)
  by_cases hx : x ∈ D
  · simpa only [if_pos hx] using hg x hx
  · simpa only [if_neg hx] using hb x hx

end TorusCoverTime.Blocks.B

