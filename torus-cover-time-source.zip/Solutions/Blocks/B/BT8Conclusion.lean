import Solutions.Blocks.B.BT8ShellWindow
import Solutions.Blocks.B.BT8Markov

/-! B-T8 / B.37: original soft traversal-contact count in any compact
physical-time window. Probe and shell estimates are proved, not hypotheses. -/
noncomputable section
open MeasureTheory Filter Set Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

theorem bt8_markov_coefficient (N : Size) (H η : ℝ) (hH : 0≤H) (hη : 0<η) :
    (ENNReal.ofReal (η*Real.sqrt (logSize N)))⁻¹*
      ENNReal.ofReal (2*(2*H+32)*Real.sqrt (logSize N)/coarseProbeProbabilityConstant)=
      ENNReal.ofReal (2*(2*H+32)/(η*coarseProbeProbabilityConstant)) := by
  have hs := Real.sqrt_pos.mpr (logSize_pos N)
  have hp := coarseProbeProbabilityConstant_pos
  rw [← ENNReal.ofReal_inv_of_pos (mul_pos hη hs),
    ← ENNReal.ofReal_mul (inv_nonneg.mpr (mul_nonneg hη.le hs.le))]
  congr 1
  field_simp

theorem bt8_conclusion (hWalk : WalkModelRegular) (γ u : ℝ)
    (hγ : 0<γ) (hmargin : 160*γ<1/20) (hu : 0≤u) : BT8Conclusion γ u := by
  intro H η hH hη l r hwindow
  let K := ENNReal.ofReal (2*(2*H+32)/(η*coarseProbeProbabilityConstant))
  have hf := bt8Good_failure_tendsto hWalk γ u H hγ (by linarith) hu hH l r hwindow
  have hs := bt8_shell_count_limit γ u (r7ShellWindowRadius H) hγ hmargin (r7ShellWindowRadius_nonneg H hH)
  have hks : Tendsto (fun N => K*shellCountWindow N (r7ShellWindowRadius H) (fun _ => bt8ShellTest N γ u)) atTop (𝓝 0) := by
    simpa only [mul_zero] using ENNReal.Tendsto.const_mul hs (Or.inr ENNReal.ofReal_ne_top)
  have htotal := hf.add hks
  simp only [add_zero] at htotal
  apply tendsto_of_tendsto_of_tendsto_of_le_of_le' tendsto_const_nhds htotal (Eventually.of_forall (fun _ => bot_le))
  filter_upwards [bt8_good_count_bound γ u H hγ (by linarith) hH,hwindow] with N hb hw
  have hh := bt8_markov N γ u (l N) (r N) (η*Real.sqrt (logSize N)) (by positivity [logSize_pos N])
  refine hh.trans (add_le_add le_rfl ?_)
  have hc := mul_le_mul' (le_refl ((ENNReal.ofReal (η*Real.sqrt (logSize N)))⁻¹))
    (hb (l N) (r N) hw.2.1 hw.2.2)
  rw [← mul_assoc,bt8_markov_coefficient N H η hH hη] at hc
  exact hc

theorem bt8_paper_gamma (hWalk : WalkModelRegular) (u : ℝ) (hu : 0≤u) :
    BT8Conclusion (1/8192) u :=
  bt8_conclusion hWalk _ u (by norm_num) (by norm_num) hu

end TorusCoverTime.Blocks.B
