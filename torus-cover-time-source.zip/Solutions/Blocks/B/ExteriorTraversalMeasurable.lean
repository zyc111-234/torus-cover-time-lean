import Solutions.Blocks.B.ExteriorTraversalObservable

/-! Joint measurability of the concrete exterior count, including its residual observation time. -/
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 800000
namespace TorusCoverTime.Blocks.B


theorem exteriorTraversalPhase_measurable (N : Size) (Q O : Finset (Vertex N))
    (root c : Vertex N) (m : ℕ) (w : Fin (2*m) → Vertex N) :
    Measurable (exteriorTraversalPhase N Q O root c m w) := by
  have hK : Measurable (fun y => finiteActionScan (exteriorTraversalAction N Q O root c m w y) (2*m) 0) :=
    finiteActionScan_measurable _ (exteriorTraversalAction_measurable N Q O root c m w) (2*m) _ measurable_const
  have hn : Measurable (fun z : TraversalExteriorSample m × ℝ => jumpCount z.1.2 z.2+1) :=
    (measurable_jumpCount_joint.comp (measurable_fst.snd.prodMk measurable_snd)).add_const 1
  exact (traversalRecordScan_joint_measurable N Q O (endpointWordStart root w (2*m))).comp
    ((hn.prodMk measurable_fst.snd).prodMk (hK.comp measurable_fst))

theorem exteriorTraversalCount_measurable (N : Size) (Q O : Finset (Vertex N))
    (root c : Vertex N) (m : ℕ) (w : Fin (2*m) → Vertex N) :
    Measurable (exteriorTraversalCount N Q O root c m w) :=
  (measurable_of_countable (fun k : ℕ => k/2)).comp (exteriorTraversalPhase_measurable N Q O root c m w)

theorem exteriorTraversalCount_rejoin_invariant (N : Size) (Q O : Finset (Vertex N))
    (root c : Vertex N) (m : ℕ) (w : Fin (2*m) → Vertex N)
    (x x' : {j : Fin (2*m) // j.val % 2 = 1} → ℕ × WalkSample)
    (y : TraversalExteriorSample m) (u : ℝ) :
    exteriorTraversalCount N Q O root c m w
      (recordExteriorProjection (2*m) (fun j => j.val % 2 = 1) (selectedRecordsJoin _ x y.1,y.2),u) =
    exteriorTraversalCount N Q O root c m w
      (recordExteriorProjection (2*m) (fun j => j.val % 2 = 1) (selectedRecordsJoin _ x' y.1,y.2),u) := by
  rw [recordExteriorProjection_join,recordExteriorProjection_join]


end TorusCoverTime.Blocks.B
