import Solutions.Blocks.B.JumpOccupationRestart
import Solutions.Blocks.B.TraversalExteriorSlice

/-! Retained return costs: the concrete finite exterior observable, not an assumed factorization. -/
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B


def returnRecordIndex (m : ℕ) (i : Fin m) : {j : Fin (2*m) // ¬j.val % 2 = 1} :=
  ⟨⟨2*i.val,by omega⟩,by change ¬(2*i.val)%2 = 1; omega⟩

def exteriorReturnOccupation (N : Size) (root : Vertex N) (m : ℕ)
    (w : Fin (2*m) → Vertex N) (U : Vertex N → ℝ) (y : TraversalExteriorSample m) : ℝ :=
  ∑ i : Fin m, excursionRecordCost N (endpointWordStart root w (2*i.val)) U
    (y.1 (returnRecordIndex m i))

theorem exteriorReturnOccupation_measurable (N : Size) (root : Vertex N) (m : ℕ)
    (w : Fin (2*m) → Vertex N) (U : Vertex N → ℝ) :
    Measurable (exteriorReturnOccupation N root m w U) :=
  Finset.measurable_sum _ fun i _ => (excursionRecordCost_measurable N _ U).comp
    ((measurable_pi_apply (returnRecordIndex m i)).comp measurable_fst)

theorem sum_range_pairs_of_odd_zero (f : ℕ → ℝ) (m : ℕ)
    (hf : ∀ k < m, f (2*k+1) = 0) :
    (∑ j ∈ Finset.range (2*m), f j) = ∑ k ∈ Finset.range m, f (2*k) := by
  induction m with
  | zero => simp
  | succ m ih =>
    rw [show 2*(m+1) = 2*m+1+1 by omega,Finset.sum_range_succ,Finset.sum_range_succ,
      ih (fun k hk => hf k (by omega)),hf m (by omega),add_zero,Finset.sum_range_succ]

theorem exteriorReturnOccupation_of_word (N : Size) (I O : Finset (Vertex N))
    (root : Vertex N) (m : ℕ) (w : Fin (2*m) → Vertex N) (U : Vertex N → ℝ)
    (ω : WalkSample) (hw : adaptiveExitWord N (alternatingDomain N I O) root (2*m) ω = w) :
    exteriorReturnOccupation N root m w U (traversalExteriorData N I O root m ω) =
      ∑ k ∈ Finset.range m, excursionRecordCost N
        (adaptiveExitStart N (alternatingDomain N I O) root (2*k) ω) U
        (adaptiveExitRecord N (alternatingDomain N I O) root (2*k) ω) := by
  unfold exteriorReturnOccupation traversalExteriorData returnRecordIndex
  dsimp only
  have he (i : Fin m) : endpointWordStart root w (2*i.val) =
      adaptiveExitStart N (alternatingDomain N I O) root (2*i.val) ω :=
    (adaptiveExitStart_of_word N _ root (2*m) w ω hw (2*i.val) (by omega)).symm
  simp_rw [he]
  exact Fin.sum_univ_eq_sum_range (fun k : ℕ => excursionRecordCost N
    (adaptiveExitStart N (alternatingDomain N I O) root (2*k) ω) U
    (adaptiveExitRecord N (alternatingDomain N I O) root (2*k) ω)) m


end TorusCoverTime.Blocks.B
