import Solutions.Blocks.B.ExitDirichlet
import Solutions.Blocks.B.ExitVisit

/-! Exact first-hit factorization for the actual exterior-endpoint kernel.
It is proved by first-step recursion and finite-domain uniqueness, without
assuming a strong Markov or Harnack theorem. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

def exitsThroughVisiting (N : Size) (D : Finset (Vertex N)) (a b x : Vertex N) : Set WalkSample :=
  {ω | ∃ n, exitsThroughAt N D a b ω n ∧ ∃ j < n, position N a ω j = x}

theorem exitsThroughVisiting_measurable (N : Size) (D : Finset (Vertex N)) (a b x : Vertex N) :
    MeasurableSet (exitsThroughVisiting N D a b x) := by
  unfold exitsThroughVisiting
  simp only [Set.ofPred_exists, Set.ofPred_and]
  apply MeasurableSet.iUnion
  intro n
  apply (measurableSet_exitsThroughAt N D a b n).inter
  apply MeasurableSet.iUnion
  intro j
  exact MeasurableSet.inter (MeasurableSet.const _) (measurable_position_eq N a x j).setOf

theorem exitsThroughVisiting_shift (N : Size) (D : Finset (Vertex N)) (a b x : Vertex N)
    (ha : a ∈ D) (hax : a ≠ x) (ω : WalkSample) :
    ω ∈ exitsThroughVisiting N D a b x ↔
      walkTail ω ∈ exitsThroughVisiting N D (a + direction N (ω 0).2) b x := by
  constructor
  · rintro ⟨n, hn, j, hj, hx⟩
    cases n with
    | zero => omega
    | succ n =>
      refine ⟨n, ((exitsThroughAt_succ_shift N D a b ω n).mp hn).2, ?_⟩
      cases j with
      | zero => exact False.elim (hax (by simpa [position] using hx))
      | succ j =>
        refine ⟨j, by omega, ?_⟩
        rw [position_succ_shift] at hx
        exact hx
  · rintro ⟨n, hn, j, hj, hx⟩
    refine ⟨n + 1, (exitsThroughAt_succ_shift N D a b ω n).mpr ⟨ha, hn⟩, j + 1, by omega, ?_⟩
    rw [position_succ_shift]
    exact hx

theorem exitsThroughVisiting_at_hit (N : Size) (D : Finset (Vertex N)) (b x : Vertex N)
    (hx : x ∈ D) : exitsThroughVisiting N D x b x = exitsThrough N D x b := by
  ext ω
  constructor
  · rintro ⟨n, hn, _⟩
    exact ⟨n, hn⟩
  · rintro ⟨n, hn⟩
    have hnpos : 0 < n := by
      cases n with
      | zero =>
        have he : x = b := by simpa [position] using hn.2.1
        exact False.elim (hn.1 (he ▸ hx))
      | succ n => omega
    exact ⟨n, hn, 0, hnpos, by simp [position]⟩

theorem exitsThroughVisiting_outside (N : Size) (D : Finset (Vertex N)) (a b x : Vertex N)
    (ha : a ∉ D) : exitsThroughVisiting N D a b x = ∅ := by
  ext ω
  simp only [exitsThroughVisiting, Set.mem_ofPred_eq, Set.mem_empty_iff_false, iff_false, not_exists]
  rintro n ⟨hn, j, hj, _⟩
  exact ha (by simpa [position] using hn.2.2 ⟨0, by omega⟩)

def exitHitHarmonic (N : Size) (D : Finset (Vertex N)) (b x a : Vertex N) : ℝ :=
  walkLaw.real (exitsThroughVisiting N D a b x)

theorem exitHitHarmonic_eq_integral (N : Size) (D : Finset (Vertex N)) (b x a : Vertex N) :
    exitHitHarmonic N D b x a =
      ∫ ω, if ω ∈ exitsThroughVisiting N D a b x then (1 : ℝ) else 0 ∂walkLaw :=
  (integral_indicator_one (exitsThroughVisiting_measurable N D a b x)).symm

theorem exitHitHarmonic_first_step (N : Size) (D : Finset (Vertex N)) (b x a : Vertex N)
    (ha : a ∈ D) (hax : a ≠ x) : exitHitHarmonic N D b x a =
      (∑ d : Fin 4, exitHitHarmonic N D b x (a + direction N d)) / 4 := by
  rw [exitHitHarmonic_eq_integral]
  have he (ω : WalkSample) : (if ω ∈ exitsThroughVisiting N D a b x then (1 : ℝ) else 0) =
      Real.exp (-(0 : ℝ) * holdingTime ω 0) *
        (if walkTail ω ∈ exitsThroughVisiting N D (a + direction N (ω 0).2) b x then 1 else 0) := by
    rw [exitsThroughVisiting_shift N D a b x ha hax ω]
    simp
  simp_rw [he]
  have h := integral_first_step_weighted 0 le_rfl
    (fun d ω => if ω ∈ exitsThroughVisiting N D (a + direction N d) b x then (1 : ℝ) else 0)
    (fun d => measurable_const.ite (exitsThroughVisiting_measurable N D _ b x) measurable_const)
    (by intro d ω; split_ifs <;> norm_num)
  simpa only [add_zero, one_mul, mul_one, ← exitHitHarmonic_eq_integral] using h

theorem exitHitHarmonic_generator (N : Size) (D : Finset (Vertex N)) (b x a : Vertex N)
    (ha : a ∈ D) (hax : a ≠ x) : generator N (exitHitHarmonic N D b x) a = 0 := by
  have h := exitHitHarmonic_first_step N D b x a ha hax
  simp only [generator, Finset.sum_sub_distrib, Finset.sum_const, Finset.card_univ,
    Fintype.card_fin, nsmul_eq_mul, Nat.cast_ofNat]
  linarith

theorem exitHitHarmonic_factor (N : Size) (D : Finset (Vertex N)) (b x a : Vertex N)
    (hx : x ∈ D) : exitHitHarmonic N D b x a =
      exitHarmonic N D b x * exitHarmonic N (D.erase x) x a := by
  have hproper : D.erase x ≠ Finset.univ := by
    intro he
    have hh : x ∈ D.erase x := by rw [he]; exact Finset.mem_univ _
    simpa using hh
  have hf : exitHitHarmonic N D b x =
      (fun a => exitHarmonic N D b x * exitHarmonic N (D.erase x) x a) := by
    apply domain_harmonic_unique N (D.erase x) hproper
    · intro z hz
      by_cases hzx : z = x
      · subst z
        simp only [exitHitHarmonic, exitsThroughVisiting_at_hit N D b x hx,
          exitHarmonic_boundary N (D.erase x) x x (by simp), if_true, mul_one]
        rfl
      · have hzD : z ∉ D := by
          intro hzD
          exact hz (Finset.mem_erase.mpr ⟨hzx, hzD⟩)
        rw [exitHitHarmonic, exitsThroughVisiting_outside N D z b x hzD, measureReal_empty,
          exitHarmonic_boundary N (D.erase x) x z hz, if_neg hzx, mul_zero]
    · intro z hz
      have hh := Finset.mem_erase.mp hz
      rw [exitHitHarmonic_generator N D b x z hh.2 hh.1, generator_mul_left,
        exitHarmonic_generator N (D.erase x) x z hz, mul_zero]
  exact congrFun hf a

theorem exitsThroughVisiting_eq_inter (N : Size) (D : Finset (Vertex N)) (a b x : Vertex N) :
    exitsThroughVisiting N D a b x = exitsThrough N D a b ∩ visitsBeforeExit N D a x := by
  ext ω
  constructor
  · rintro ⟨n, hn, j, hj, hx⟩
    refine ⟨⟨n, hn⟩, j, ?_, hx⟩
    rwa [finiteExitIndex_of_exit_word N D a b ω n hn]
  · rintro ⟨⟨n, hn⟩, j, hj, hx⟩
    refine ⟨n, hn, j, ?_, hx⟩
    rwa [finiteExitIndex_of_exit_word N D a b ω n hn] at hj

theorem exactExitLaw_visit_formula (N : Size) (D : Finset (Vertex N)) (a b x : Vertex N)
    (hx : x ∈ D) :
    (exactExitLaw N D a b).real (visitsBeforeExit N D a x) =
      exitHarmonic N (D.erase x) x a * exitHarmonic N D b x / exitHarmonic N D b a := by
  have h := cond_apply (μ := walkLaw) (measurableSet_exitsThrough N D a b)
    (visitsBeforeExit N D a x)
  change exactExitLaw N D a b (visitsBeforeExit N D a x) = _ at h
  have hr := congrArg ENNReal.toReal h
  rw [ENNReal.toReal_mul, ENNReal.toReal_inv, ← exitsThroughVisiting_eq_inter,
    show (walkLaw (exitsThroughVisiting N D a b x)).toReal = exitHitHarmonic N D b x a from rfl,
    exitHitHarmonic_factor N D b x a hx] at hr
  change (exactExitLaw N D a b).real (visitsBeforeExit N D a x) = _ at hr
  rw [hr]
  unfold exitHarmonic
  simp only [measureReal_def, div_eq_mul_inv]
  ring

end TorusCoverTime.Blocks.B
