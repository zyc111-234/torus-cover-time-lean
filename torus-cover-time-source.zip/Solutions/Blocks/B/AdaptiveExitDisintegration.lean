import Solutions.Blocks.B.AdaptiveExitWord
import Solutions.Blocks.B.ExitChainLoopTransfer

/-! The product law and loop reassembly apply to the actual endpoint partition,
including zero-probability words. Conditional independence is proved, not an
assumption on the path or on its random successive entrances. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

theorem adaptiveExitRecord_of_fixed (N : Size) (D : ℕ → Finset (Vertex N))
    (root : Vertex N) (n : ℕ) (w : Fin n → Vertex N) (ω : WalkSample)
    (hw : ω ∈ exitChainEndpoints N D (endpointWordStart root w) (endpointWordEnd root w) n)
    (k : ℕ) (hk : k ≤ n) :
    adaptiveExitRecord N D root k ω = exitChainRecord N D (endpointWordStart root w) k ω := by
  have hi := adaptiveExitIndex_of_fixed N D root n w ω hw k hk
  have hp := exitChain_position N D (endpointWordStart root w) (endpointWordEnd root w) n
    (fun _ _ => rfl) ω hw k hk
  rw [endpointWordStart_zero] at hp
  change finiteExitRecord N (D k) (position N root ω (adaptiveExitIndex N D root k ω))
    (fun j => ω (adaptiveExitIndex N D root k ω+j)) = _
  rw [hi, hp]
  change finiteExitRecord N (D k) (endpointWordStart root w k) _ =
    finiteExitRecord N (D k) (endpointWordStart root w k) (exitChainTail N D (endpointWordStart root w) k ω)
  rw [exitChainTail_eq_shift]

theorem adaptiveExit_record_tail_conditional_law (N : Size) (D : ℕ → Finset (Vertex N))
    (hD : ∀ k, ∃ b : Vertex N, b ∉ D k) (root : Vertex N) (n : ℕ) (w : Fin n → Vertex N) :
    (walkLaw[|{ω | adaptiveExitWord N D root n ω = w}]).map
      (fun ω => ((fun j : Fin n => adaptiveExitRecord N D root j.val ω), adaptiveExitTail N D root n ω)) =
      (Measure.pi (fun j : Fin n => exactExitRecordLaw N (D j.val)
        (endpointWordStart root w j.val) (endpointWordEnd root w j.val))).prod walkLaw := by
  rw [adaptiveExitWord_cond_eq N D hD root n w]
  calc
    _ = (walkLaw[|exitChainEndpoints N D (endpointWordStart root w) (endpointWordEnd root w) n]).map
        (fun ω => ((fun j : Fin n => exitChainRecord N D (endpointWordStart root w) j.val ω),
          exitChainTail N D (endpointWordStart root w) n ω)) := by
      apply Measure.map_congr
      filter_upwards [ae_cond_mem (μ := walkLaw)
        (exitChainEndpoints_measurable N D hD (endpointWordStart root w) (endpointWordEnd root w) n)] with ω hω
      apply Prod.ext
      · funext j
        exact adaptiveExitRecord_of_fixed N D root n w ω hω j.val j.isLt.le
      · rw [exitChainTail_eq_shift]
        change (fun j => ω (adaptiveExitIndex N D root n ω+j)) = _
        rw [adaptiveExitIndex_of_fixed N D root n w ω hω n le_rfl]
    _ = _ := exitChainRecord_conditioned_tail_law N D hD _ _ n

theorem adaptiveExitTime_of_fixed (N : Size) (D : ℕ → Finset (Vertex N))
    (root : Vertex N) (n : ℕ) (w : Fin n → Vertex N) (ω : WalkSample)
    (hw : ω ∈ exitChainEndpoints N D (endpointWordStart root w) (endpointWordEnd root w) n)
    (k : ℕ) (hk : k ≤ n) :
    adaptiveExitTime N D root k ω = exitChainTime N D (endpointWordStart root w) k ω := by
  exact congrArg (jumpTime ω) (adaptiveExitIndex_of_fixed N D root n w ω hw k hk)

theorem adaptiveExit_loop_lintegral (N : Size) (D : ℕ → Finset (Vertex N))
    (hD : ∀ k, ∃ b : Vertex N, b ∉ D k) (root : Vertex N) (n : ℕ) (w : Fin n → Vertex N)
    (F : ℝ × WalkSample → ℝ≥0∞) (hF : Measurable F) :
    (∫⁻ ω, (∫⁻ t in Ioi (adaptiveExitTime N D root n ω),
      if walk N root ω t = root then F (t,ω) else 0)
      ∂walkLaw[|{ω | adaptiveExitWord N D root n ω = w}]) =
      ∫⁻ p, ∫⁻ η, (∫⁻ u in Ioi (0 : ℝ), if walk N (endpointWordStart root w n) η u = root then
        F (recordsDuration n p+u, recordsJoin n p η) else 0) ∂walkLaw
        ∂Measure.pi (fun j : Fin n => exactExitRecordLaw N (D j.val)
          (endpointWordStart root w j.val) (endpointWordEnd root w j.val)) := by
  rw [adaptiveExitWord_cond_eq N D hD root n w]
  calc
    _ = ∫⁻ ω, (∫⁻ t in Ioi (exitChainTime N D (endpointWordStart root w) n ω),
        if walk N root ω t = root then F (t,ω) else 0)
        ∂walkLaw[|exitChainEndpoints N D (endpointWordStart root w) (endpointWordEnd root w) n] := by
      apply lintegral_congr_ae
      filter_upwards [ae_cond_mem (μ := walkLaw)
        (exitChainEndpoints_measurable N D hD (endpointWordStart root w) (endpointWordEnd root w) n)] with ω hω
      rw [adaptiveExitTime_of_fixed N D root n w ω hω n le_rfl]
    _ = _ := exitChain_loop_lintegral N D hD _ _ n (fun _ _ => rfl) F hF

theorem restriction_eq_mass_smul_cond {Ω : Type*} [MeasurableSpace Ω]
    (μ : Measure Ω) [IsFiniteMeasure μ] (E : Set Ω) : μ.restrict E = μ E • μ[|E] := by
  by_cases h0 : μ E = 0
  · simp [h0, Measure.restrict_eq_zero.mpr h0]
  · rw [ProbabilityTheory.cond, smul_smul, ENNReal.mul_inv_cancel h0 (measure_ne_top μ E), one_smul]

theorem adaptiveExitWord_conditional_partition (N : Size) (D : ℕ → Finset (Vertex N))
    (root : Vertex N) (n : ℕ) (F : WalkSample → ℝ≥0∞) :
    (∫⁻ ω, F ω ∂walkLaw) = ∑ w : Fin n → Vertex N,
      walkLaw {ω | adaptiveExitWord N D root n ω = w} *
        ∫⁻ ω, F ω ∂walkLaw[|{ω | adaptiveExitWord N D root n ω = w}] := by
  rw [adaptiveExitWord_lintegral_partition N D root n F]
  apply Finset.sum_congr rfl
  intro w _
  rw [restriction_eq_mass_smul_cond, lintegral_smul_measure, smul_eq_mul]

end TorusCoverTime.Blocks.B
