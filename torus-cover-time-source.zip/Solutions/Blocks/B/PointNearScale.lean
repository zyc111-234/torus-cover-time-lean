import Solutions.Blocks.B.PointSoftSpatialSum
import Solutions.Blocks.B.R10WitnessAlgebra

/-! The prescribed root-neighborhood radius and a summable spatial budget.
The harmless lattice term avoids an artificial assumption that the radius exceeds one. -/
noncomputable section
open Filter
open scoped Topology
namespace TorusCoverTime.Blocks.B

def pointNearRadius (N : Size) (γ C : ℝ) : ℝ :=
  C*(N.val:ℝ)*Real.exp (-((logSize N)^(16*γ))/2)

def pointNearEnvelope (N : Size) (γ C u H : ℝ) : ℝ :=
  pointSoftConstant u H*(logSize N)^(3/2:ℝ)*
    (8*C^2*Real.exp (-((logSize N)^(16*γ)))+2*Real.exp (-2*logSize N))

theorem pointNearRadius_nonneg (N : Size) (γ C : ℝ) (hC : 0 ≤ C) : 0 ≤ pointNearRadius N γ C := by
  unfold pointNearRadius
  positivity

theorem pointNearRadius_sq (N : Size) (γ C : ℝ) :
    (pointNearRadius N γ C)^2=C^2*vertexCount N*Real.exp (-((logSize N)^(16*γ))) := by
  unfold pointNearRadius
  calc
    _ = C^2*(N.val:ℝ)^2*(Real.exp (-((logSize N)^(16*γ))/2))^2 := by ring
    _ = _ := by
      rw [pow_two (Real.exp _),← Real.exp_add]
      congr 2
      ring

theorem point_near_inverse_vertexCount (N : Size) :
    Real.exp (-2*logSize N)=(vertexCount N)⁻¹ := by
  rw [neg_mul,Real.exp_neg]
  congr 1
  rw [show 2*logSize N=logSize N+logSize N by ring,Real.exp_add]
  simp [logSize,Real.exp_log (lt_trans zero_lt_one (size_real_gt_one N)),vertexCount,pow_two]

theorem pointNearEnvelope_nonneg (N : Size) (γ C u H : ℝ) : 0 ≤ pointNearEnvelope N γ C u H := by
  have := pointSoftConstant_pos u H
  have := logSize_pos N
  unfold pointNearEnvelope
  positivity

theorem point_near_spatial_budget (N : Size) (γ C u H : ℝ) :
    vertexCount N*(2*pointNearRadius N γ C+1)^2*pointSoftJointBound N u H ≤
      pointNearEnvelope N γ C u H := by
  have hsq : (2*pointNearRadius N γ C+1)^2 ≤ 8*(pointNearRadius N γ C)^2+2 := by
    nlinarith [sq_nonneg (2*pointNearRadius N γ C-1)]
  have h := mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left hsq (vertexCount_pos N).le)
    (pointSoftJointBound_nonneg N u H)
  apply h.trans_eq
  rw [pointNearRadius_sq]
  unfold pointSoftJointBound pointNearEnvelope
  rw [point_near_inverse_vertexCount]
  field_simp [(vertexCount_pos N).ne'] <;> ring

theorem point_near_envelope_tendsto (γ C u H : ℝ) (hγ : 0 < γ) :
    Tendsto (fun N : Size => pointNearEnvelope N γ C u H) atTop (𝓝 0) := by
  have h₁ := ((polynomial_times_stretched_exp_tendsto_zero (16*γ) 1 (3/2)
    (by positivity) zero_lt_one).const_mul (pointSoftConstant u H*8*C^2)).comp blockB_logSize_tendsto
  have h₂ := ((polynomial_times_stretched_exp_tendsto_zero 1 2 (3/2)
    zero_lt_one (by norm_num)).const_mul (pointSoftConstant u H*2)).comp blockB_logSize_tendsto
  have h := h₁.add h₂
  simp only [mul_zero,add_zero,Function.comp_def,Real.rpow_one,neg_one_mul] at h
  apply h.congr'
  exact Filter.Eventually.of_forall fun N => by unfold pointNearEnvelope; ring

end TorusCoverTime.Blocks.B
