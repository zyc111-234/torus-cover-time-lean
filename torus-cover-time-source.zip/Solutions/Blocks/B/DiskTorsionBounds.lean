import Solutions.Blocks.B.DomainGreenOperator

noncomputable section
open Classical
open scoped BigOperators
namespace TorusCoverTime.Blocks.B

theorem diskGreen_mass_lower (N : Size) (c : Vertex N) (R : ℝ) (hR : 0<R)
    (hsmall : 2*(R+1)<N.val) (x : Vertex N) (hx : x∈torusDisk N c R) :
    R^2-periodicDistance x c^2≤∑ y, diskGreen N c R x y := by
  have he := domainGreenFromBarrier_mass N (torusDisk N c R) (torusDisk_proper N c R hR.le hsmall)
    (diskBarrier N c R) (fun z hz => diskBarrier_generator N c R hR.le hsmall z hz) x
  change (∑ y, diskGreen N c R x y)=_ at he
  have hb := (exitExtension_bounds N _ (torusDisk_proper N c R hR.le hsmall) x
    (diskBarrier N c R) 0 (2*R+1) (by
      intro z hz
      have hbd : diskExteriorNeighbor N c R z := by
        by_contra hn
        exact hz (exitHarmonic_disk_support N c R x z hx hn)
      have hd := diskExteriorNeighbor_radius N c R z hbd
      refine ⟨diskBarrier_nonneg N c R z,?_⟩
      rw [diskBarrier_eq_quadratic N c R hR.le z hd.2.le]
      nlinarith [Real.sqrt_nonneg (0:ℝ)])).2
  have hxc := (mem_torusDisk N c x R).mp hx
  rw [he,diskBarrier_eq_quadratic N c R hR.le x (by linarith)]
  linarith

theorem diskGreen_mass_deep_lower (N : Size) (c : Vertex N) (R : ℝ) (hR : 0<R)
    (hsmall : 2*(R+1)<N.val) (x : Vertex N) (hx : periodicDistance x c≤R/2) :
    3*R^2/4≤∑ y, diskGreen N c R x y := by
  have hh := diskGreen_mass_lower N c R hR hsmall x ((mem_torusDisk N c x R).mpr (by linarith))
  have hd : 0≤periodicDistance x c := by unfold periodicDistance; positivity
  nlinarith

end TorusCoverTime.Blocks.B
