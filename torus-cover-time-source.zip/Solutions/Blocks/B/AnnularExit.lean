import Solutions.Blocks.B.DiskExitSupport

/-! Actual exit laws from a punctured finite domain, including the exact
probability of leaving the outer domain while avoiding its core. -/

noncomputable section
open MeasureTheory Classical
namespace TorusCoverTime.Blocks.B

theorem exitsThrough_disjoint (N : Size) (D : Finset (Vertex N)) (a b b' : Vertex N)
    (hbb : b ≠ b') : Disjoint (exitsThrough N D a b) (exitsThrough N D a b') := by
  apply Set.disjoint_left.mpr
  rintro ω ⟨n, hn⟩ ⟨m, hm⟩
  have he : n = m := (finiteExitIndex_of_exit_word N D a b ω n hn).symm.trans
    (finiteExitIndex_of_exit_word N D a b' ω m hm)
  subst m
  exact hbb (hn.2.1.symm.trans hm.2.1)

def exitsInto (N : Size) (D K : Finset (Vertex N)) (a : Vertex N) : Set WalkSample :=
  ⋃ b ∈ K, exitsThrough N D a b

theorem exitsInto_measurable (N : Size) (D K : Finset (Vertex N)) (a : Vertex N) :
    MeasurableSet (exitsInto N D K a) :=
  K.measurableSet_biUnion (fun b _ => measurableSet_exitsThrough N D a b)

theorem exitsInto_probability_sum (N : Size) (D K : Finset (Vertex N)) (a : Vertex N) :
    walkLaw.real (exitsInto N D K a) = ∑ b ∈ K, exitHarmonic N D b a := by
  apply measureReal_biUnion_finset
  · intro b _ b' _ hbb
    exact exitsThrough_disjoint N D a b b' hbb
  · exact fun b _ => measurableSet_exitsThrough N D a b
  · exact fun b _ => measure_ne_top walkLaw _

def exitsAvoidingCore (N : Size) (D K : Finset (Vertex N)) (a : Vertex N) : Set WalkSample :=
  ⋃ b : Vertex N, exitsThroughAvoiding N D K a b

theorem exitsAvoidingCore_measurable (N : Size) (D K : Finset (Vertex N)) (a : Vertex N) :
    MeasurableSet (exitsAvoidingCore N D K a) :=
  MeasurableSet.iUnion fun b => measurableSet_exitsThroughAvoiding N D K a b

theorem exitsAvoidingCore_eq_annulus_exit (N : Size) (D K : Finset (Vertex N))
    (hKD : K ⊆ D) (a : Vertex N) :
    exitsAvoidingCore N D K a = exitsInto N (D \ K) (Finset.univ \ K) a := by
  ext ω
  simp only [exitsAvoidingCore, exitsInto, Set.mem_iUnion]
  constructor
  · rintro ⟨b, n, hn, havoid⟩
    refine ⟨b, Finset.mem_sdiff.mpr ⟨Finset.mem_univ _, fun h => hn.1 (hKD h)⟩,
      n, fun h => hn.1 (Finset.mem_sdiff.mp h).1, hn.2.1, ?_⟩
    intro j
    exact Finset.mem_sdiff.mpr ⟨hn.2.2 j, havoid j.val j.isLt.le⟩
  · rintro ⟨b, hb, n, hn⟩
    have hbK := (Finset.mem_sdiff.mp hb).2
    have hbD : b ∉ D := fun h => hn.1 (Finset.mem_sdiff.mpr ⟨h, hbK⟩)
    refine ⟨b, n, ⟨hbD, hn.2.1, fun j => (Finset.mem_sdiff.mp (hn.2.2 j)).1⟩, ?_⟩
    intro j hj
    rcases lt_or_eq_of_le hj with hj | rfl
    · exact (Finset.mem_sdiff.mp (hn.2.2 ⟨j, hj⟩)).2
    · simpa only [hn.2.1] using hbK

theorem proper_sdiff (N : Size) (D K : Finset (Vertex N)) (hD : D ≠ Finset.univ) :
    D \ K ≠ Finset.univ := by
  intro he
  apply hD
  apply Finset.eq_univ_of_forall
  intro x
  have hx : x ∈ D \ K := he ▸ Finset.mem_univ x
  exact (Finset.mem_sdiff.mp hx).1

theorem annulus_core_avoid_probabilities (N : Size) (D K : Finset (Vertex N))
    (hD : D ≠ Finset.univ) (hKD : K ⊆ D) (a : Vertex N) :
    walkLaw.real (exitsInto N (D \ K) K a) + walkLaw.real (exitsAvoidingCore N D K a) = 1 := by
  rw [exitsAvoidingCore_eq_annulus_exit N D K hKD a, exitsInto_probability_sum,
    exitsInto_probability_sum]
  rw [add_comm, Finset.sum_sdiff (Finset.subset_univ _)]
  exact exitHarmonic_sum_one N (D \ K) (proper_sdiff N D K hD) a

theorem torusDisk_subset (N : Size) (c : Vertex N) (r R : ℝ) (hrR : r ≤ R) :
    torusDisk N c r ⊆ torusDisk N c R := by
  intro x hx
  exact (mem_torusDisk N c x R).mpr (((mem_torusDisk N c x r).mp hx).trans_le hrR)

theorem annulus_exit_geometry (N : Size) (c : Vertex N) (r R : ℝ) (a b : Vertex N)
    (ha : a ∈ torusDisk N c R \ torusDisk N c r) (ω : WalkSample)
    (hω : ω ∈ exitsThrough N (torusDisk N c R \ torusDisk N c r) a b) :
    (b ∈ torusDisk N c r → r-1 ≤ periodicDistance b c) ∧
    (b ∉ torusDisk N c r → diskExteriorNeighbor N c R b) := by
  obtain ⟨n, hb, hend, hpre⟩ := hω
  cases n with
  | zero =>
    have he : a = b := by simpa [position] using hend
    exact False.elim (hb (he ▸ ha))
  | succ n =>
    let z := position N a ω n
    have hz := Finset.mem_sdiff.mp (hpre ⟨n, by omega⟩)
    have hstep : b = z + direction N (ω n).2 := by rw [position_succ_step] at hend; exact hend.symm
    have hd : periodicDistance b z = 1 := by rw [hstep]; exact periodicDistance_step N z _
    constructor
    · intro _
      have hzR : r ≤ periodicDistance z c := le_of_not_gt (fun h => hz.2 ((mem_torusDisk N c z r).mpr h))
      have ht := periodicDistance_triangle N z b c
      rw [periodicDistance_comm z b, hd] at ht
      linarith
    · intro hbK
      refine ⟨fun h => hb (Finset.mem_sdiff.mpr ⟨h, hbK⟩), z, hz.1, ?_⟩
      rw [hstep]
      exact torus_neighbor_step N z _

theorem exitHarmonic_annulus_geometry (N : Size) (c : Vertex N) (r R : ℝ) (a b : Vertex N)
    (ha : a ∈ torusDisk N c R \ torusDisk N c r)
    (hb : exitHarmonic N (torusDisk N c R \ torusDisk N c r) b a ≠ 0) :
    (b ∈ torusDisk N c r → r-1 ≤ periodicDistance b c) ∧
    (b ∉ torusDisk N c r → diskExteriorNeighbor N c R b) := by
  by_contra hn
  have he : exitsThrough N (torusDisk N c R \ torusDisk N c r) a b = ∅ := by
    apply Set.eq_empty_iff_forall_notMem.mpr
    intro ω hω
    exact hn (annulus_exit_geometry N c r R a b ha ω hω)
  apply hb
  unfold exitHarmonic
  rw [he, measureReal_empty]

end TorusCoverTime.Blocks.B
