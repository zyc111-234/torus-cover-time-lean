import Solutions.Blocks.B.BT9
import Solutions.Blocks.B.R8WordSiteLaw

/-! Exact two-site all-return occupation under the actual finite record law. -/
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

def bt10Potential (N : Size) (x y : Vertex N) (z : Vertex N) : ℝ :=
  r8SitePotential N x z+r8SitePotential N y z

theorem bt10Potential_support (N : Size) (x y : Vertex N) (I : Finset (Vertex N))
    (hx : x∈I) (hy : y∈I) : ∀ z, z∉I → bt10Potential N x y z=0 := by
  intro z hz
  simp only [bt10Potential,r8SitePotential_support N x I hx z hz,
    r8SitePotential_support N y I hy z hz,add_zero]

theorem bt10Potential_sum (N : Size) (x y : Vertex N) (f : Vertex N → ℝ) :
    (∑ z, bt10Potential N x y z*f z)=(f x+f y)/g := by
  simp only [bt10Potential,add_mul,Finset.sum_add_distrib,r8SitePotential_sum]
  ring

def bt10WordCost (N : Size) (x y root : Vertex N) (m : ℕ) (w : Fin (2*m) → Vertex N) :=
  traversalWordOutwardOccupation N root m w (bt10Potential N x y)

theorem bt10WordCost_measurable (N : Size) (x y root : Vertex N) (m : ℕ) (w : Fin (2*m) → Vertex N) :
    Measurable (bt10WordCost N x y root m w) := traversalWordOutwardOccupation_measurable N root m w _

theorem bt10_record_event_law (N : Size) (D : Finset (Vertex N)) (x y : Vertex N)
    (m : ℕ) (a b : Fin m → Vertex N) (U : ℝ) :
    exactExitRecordProductLaw N D m a b {p | recordProductOccupation N m a (bt10Potential N x y) p≤U} =
      exactExitProductLaw N D m a b {ω | (exitBlockOccupation N D m a ω x+exitBlockOccupation N D m a ω y)/g≤U} := by
  have he := congrArg (fun μ : Measure ℝ => μ (Iic U))
    (exactExitRecordProduct_occupation_law N D m a b (bt10Potential N x y))
  have hm : Measurable (fun ω : Fin m → WalkSample =>
      ∑ i, weightedExitOccupation N D (a i) (bt10Potential N x y) (ω i)) :=
    Finset.measurable_sum _ fun i _ => (weightedExitOccupation_measurable N D (a i) _).comp (measurable_pi_apply i)
  rw [Measure.map_apply (recordProductOccupation_measurable N m a _) measurableSet_Iic,
    Measure.map_apply hm measurableSet_Iic] at he
  simpa only [weightedExitOccupation,bt10Potential_sum,← Finset.sum_div,
    Finset.sum_add_distrib,exitBlockOccupation,Set.preimage,mem_Iic] using he

theorem bt10_word_event_law (N : Size) (I O : Finset (Vertex N)) (x y root : Vertex N)
    (hI : I.Nonempty) (hr : root∉O) (m : ℕ) (w : Fin (2*m) → Vertex N)
    (hw : walkLaw {ω | adaptiveExitWord N (alternatingDomain N I O) root (2*m) ω=w}≠0) (U : ℝ) :
    traversalWordOutwardLaw N I O root m w {p | bt10WordCost N x y root m w p≤U} =
      exactExitProductLaw N O m (fun i => endpointWordStart root w (2*i.val+1))
        (fun i => endpointWordEnd root w (2*i.val+1))
        {ω | (exitBlockOccupation N O m (fun i => endpointWordStart root w (2*i.val+1)) ω x+
          exitBlockOccupation N O m (fun i => endpointWordStart root w (2*i.val+1)) ω y)/g≤U} := by
  rw [← bt10_record_event_law]
  have he := congrArg (fun μ : Measure (Fin m → ℕ × WalkSample) => μ
    {p | recordProductOccupation N m (fun i => endpointWordStart root w (2*i.val+1)) (bt10Potential N x y) p≤U})
    (outwardRecordProjection_law N I O root hI hr m w hw)
  rw [Measure.map_apply (outwardRecordProjection_measurable m)
    (measurableSet_le (recordProductOccupation_measurable N m _ _) measurable_const)] at he
  exact he

def bt10PairEnvelope (γ K q : ℝ) (m : ℕ) : ℝ :=
  Real.exp (-4*q-4*Real.sqrt 2*(Real.sqrt (q^γ*(m:ℝ))-Real.sqrt 2*q)+K*q^γ)

theorem bt10_positive_word_bound (γ U : ℝ) (h : BT9Conclusion γ U) :
    ∃ K : ℝ, 0<K ∧ ∀ᶠ q : ℝ in atTop, ∀ N : Size, ∀ x y root : Vertex N,
      ∀ m : ℕ, ∀ w : Fin (2*m) → Vertex N,
      x≠y → q-2≤Real.log (periodicDistance x y) → Real.log (periodicDistance x y)<q →
      root∉torusDisk N x (Real.exp (q+2*q^γ)) → 2*(Real.exp (q+2*q^γ)+1)<N.val →
      walkLaw {ω | adaptiveExitWord N (alternatingDomain N (torusDisk N x (Real.exp (q+q^γ)))
        (torusDisk N x (Real.exp (q+2*q^γ)))) root (2*m) ω=w}≠0 →
      traversalWordOutwardLaw N (torusDisk N x (Real.exp (q+q^γ)))
        (torusDisk N x (Real.exp (q+2*q^γ))) root m w {p | bt10WordCost N x y root m w p≤U} ≤
        ENNReal.ofReal (bt10PairEnvelope γ K q m) := by
  obtain ⟨K,hK,h⟩ := h
  refine ⟨K,hK,?_⟩
  filter_upwards [h,eventually_ge_atTop (0:ℝ)] with q hq hq0
  intro N x y root m w hxy hlo hhi hr hs hw
  have hgeo := diskTraversal_positive_word_geometry N x root _ _ (Real.exp_pos _)
    (Real.exp_le_exp.mpr (by linarith [Real.rpow_nonneg hq0 γ])) hr m w hw
  have hI := torusDisk_nonempty N x (Real.exp (q+q^γ)) (Real.exp_pos _)
  have := traversalWordOutwardLaw_probability N _ _ root hI hr m w hw
  apply (ENNReal.le_ofReal_iff_toReal_le (measure_ne_top _ _) (Real.exp_pos _).le).mpr
  have he := congrArg ENNReal.toReal (bt10_word_event_law N _ _ x y root hI hr m w hw U)
  exact he.le.trans (by
    simpa only [Measure.real,bt10PairEnvelope,mul_comm (m:ℝ) (q^γ)] using
      (hq N x y m _ _ hxy hlo hhi hs (fun i => (hgeo i).1.trans (by norm_num)) (fun i => (hgeo i).2)))

end TorusCoverTime.Blocks.B
