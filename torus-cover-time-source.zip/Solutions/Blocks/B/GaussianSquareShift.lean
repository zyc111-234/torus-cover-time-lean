import Solutions.Blocks.D.Base.GaussianSquare
import Solutions.Blocks.B.GaussianSlabMoments

/-! Uniform square-exponential moments with a deterministic mean shift.
Degenerate Gaussian coordinates are included. -/

noncomputable section
open MeasureTheory ProbabilityTheory
open scoped ENNReal
namespace TorusCoverTime.Blocks.B
variable {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]

theorem centered_gaussian_square_exp (X : Ω → ℝ) (hG : HasGaussianLaw X μ)
    (hzero : (∫ ω, X ω ∂μ)=0) (V : ℝ) (hV : 0<V) (hvar : Var[X;μ]≤V) :
    Integrable (fun ω => Real.exp (X ω^2/(4*V))) μ ∧
      (∫ ω, Real.exp (X ω^2/(4*V)) ∂μ) ≤ 2 := by
  have hp : 2*(1/(4*V))*(Var[X;μ]).toNNReal ≤ (1/2:ℝ) := by
    rw [Real.coe_toNNReal _ (variance_nonneg _ _)]
    calc
      _ ≤ 2*(1/(4*V))*V := mul_le_mul_of_nonneg_left hvar (by positivity)
      _ = _ := by field_simp [hV.ne'] <;> norm_num
  have he : (∫ ω, Real.exp (X ω^2/(4*V)) ∂μ) =
      1/Real.sqrt (1-2*(1/(4*V))*(Var[X;μ]).toNNReal) := by
    have hh := integral_map hG.aemeasurable
      (f := fun x : ℝ => Real.exp ((1/(4*V))*x^2)) (by fun_prop)
    rw [hG.map_eq_gaussianReal,hzero,Blocks.D.gaussianSquare_integral _ _ (by linarith)] at hh
    simpa only [one_div,mul_comm,div_eq_mul_inv,one_mul] using hh.symm
  have hd : 0 < 1-2*(1/(4*V))*(Var[X;μ]).toNNReal := by linarith
  refine ⟨Integrable.of_integral_ne_zero (by rw [he]; positivity),?_⟩
  rw [he]
  apply (div_le_iff₀ (Real.sqrt_pos.mpr hd)).mpr
  nlinarith [Real.sq_sqrt hd.le,Real.sqrt_nonneg (1-2*(1/(4*V))*(Var[X;μ]).toNNReal)]

theorem shifted_gaussian_square_exp (X : Ω → ℝ) (hX : Measurable X)
    (hG : HasGaussianLaw X μ) (hzero : (∫ ω, X ω ∂μ)=0)
    (V m M : ℝ) (hV : 0<V) (hvar : Var[X;μ]≤V) (hm : |m|≤M) :
    Integrable (fun ω => Real.exp ((X ω+m)^2/(8*V))) μ ∧
      (∫ ω, Real.exp ((X ω+m)^2/(8*V)) ∂μ) ≤ 2*Real.exp (M^2/(4*V)) := by
  obtain ⟨hi,hb⟩ := centered_gaussian_square_exp X hG hzero V hV hvar
  have hM : 0≤M := (abs_nonneg m).trans hm
  have hm2 : m^2≤M^2 := by simpa only [sq_abs] using (sq_le_sq₀ (abs_nonneg m) hM).mpr hm
  have hp (ω : Ω) : Real.exp ((X ω+m)^2/(8*V)) ≤
      Real.exp (M^2/(4*V))*Real.exp (X ω^2/(4*V)) := by
    rw [← Real.exp_add]
    apply Real.exp_le_exp.mpr
    apply (mul_le_mul_iff_of_pos_right (show 0<8*V by positivity)).mp
    field_simp
    nlinarith [sq_nonneg (X ω-m)]
  have hi' := hi.const_mul (Real.exp (M^2/(4*V)))
  have hg : Integrable (fun ω => Real.exp ((X ω+m)^2/(8*V))) μ :=
    hi'.mono' (by fun_prop) (Filter.Eventually.of_forall (fun ω => by
      rw [Real.norm_eq_abs,abs_of_pos (Real.exp_pos _)]
      exact hp ω))
  refine ⟨hg,?_⟩
  calc
    _ ≤ ∫ ω, Real.exp (M^2/(4*V))*Real.exp (X ω^2/(4*V)) ∂μ := integral_mono hg hi' hp
    _ = Real.exp (M^2/(4*V))*(∫ ω, Real.exp (X ω^2/(4*V)) ∂μ) := integral_const_mul _ _
    _ ≤ _ := by nlinarith [mul_le_mul_of_nonneg_left hb (Real.exp_pos (M^2/(4*V))).le]

end TorusCoverTime.Blocks.B
