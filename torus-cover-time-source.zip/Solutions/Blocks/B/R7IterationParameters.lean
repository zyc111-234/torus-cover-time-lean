import Solutions.Blocks.B.R7CountedIteration

/-! The actual low-count cutoff and the R7 choices Delta=L^(2 gamma),
J=ceil(L^2). All concentration side conditions are discharged uniformly over
the original coarse scales and linearly bounded thresholds. -/

noncomputable section
open MeasureTheory Filter Set Classical
open scoped ENNReal NNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

def r7LowCountCutoff (q γ v : ℝ) : ℕ := ⌊v^2/q^γ⌋₊

theorem r7_low_count_cutoff_iff (q γ v : ℝ) (m : ℕ) (hq : 0 < q) (hv : 0 ≤ v) :
    m ≤ r7LowCountCutoff q γ v ↔ Real.sqrt (q^γ*(m:ℝ)) ≤ v := by
  have hw := Real.rpow_pos_of_pos hq γ
  rw [r7LowCountCutoff,Nat.le_floor_iff (div_nonneg (sq_nonneg v) hw.le),
    le_div_iff₀ hw,Real.sqrt_le_iff]
  constructor
  · intro h
    exact ⟨hv,by nlinarith⟩
  · intro h
    nlinarith [h.2]

theorem r7_low_count_cutoff_scale (L q γ v C₁ : ℝ) (hL : 1 ≤ L) (hq : 1 ≤ q)
    (hγ : 0 ≤ γ) (hv : 0 ≤ v) (hvL : v ≤ C₁*L) (hC : 0 ≤ C₁) (hCL : C₁ ≤ L) :
    (r7LowCountCutoff q γ v:ℝ)*q^γ ≤ v^2 ∧ (r7LowCountCutoff q γ v:ℝ) ≤ L^4+1 := by
  have hw := Real.one_le_rpow hq hγ
  have hw0 : 0 < q^γ := by linarith
  have hm := (le_div_iff₀ hw0).mp (Nat.floor_le (div_nonneg (sq_nonneg v) hw0.le))
  change (r7LowCountCutoff q γ v:ℝ)*q^γ ≤ v^2 at hm
  refine ⟨hm,?_⟩
  have hc := (sq_le_sq₀ hC (by linarith : 0 ≤ L)).mpr hCL
  calc
    _ ≤ v^2 := by nlinarith [mul_nonneg (Nat.cast_nonneg (r7LowCountCutoff q γ v)) (show 0 ≤ q^γ-1 by linarith)]
    _ ≤ (C₁*L)^2 := pow_le_pow_left₀ hv hvL 2
    _ = C₁^2*L^2 := by ring
    _ ≤ L^2*L^2 := mul_le_mul_of_nonneg_right hc (sq_nonneg _)
    _ ≤ _ := by nlinarith

theorem r7_delta_ratio (L q γ : ℝ) (hL : 0 < L) (hq : 0 < q) (hqL : q ≤ L) (hγ : 0 ≤ γ) :
    L^(3*γ) ≤ (L^(2*γ))^2/q^γ := by
  have hw := Real.rpow_pos_of_pos hq γ
  apply (le_div_iff₀ hw).mpr
  have hqpow := Real.rpow_le_rpow hq.le hqL hγ
  have he : (L^(2*γ))^2 = L^(3*γ)*L^γ := by
    rw [← Real.rpow_mul_natCast hL.le,← Real.rpow_add hL]
    congr 1
    ring
  rw [he]
  exact mul_le_mul_of_nonneg_left hqpow (Real.rpow_nonneg hL.le _)

theorem r7_iteration_side_conditions (γ C₁ : ℝ) (hγ : 0 < γ) (hC : 0 < C₁) :
    ∀ᶠ N : Size in atTop, ∀ q v : ℝ,
      (logSize N)^(16*γ) ≤ q → q ≤ logSize N → q ≤ v → v ≤ C₁*logSize N →
      1 ≤ q ∧ (r7LowCountCutoff q γ v:ℝ)*q^γ ≤ v^2 ∧
      (r7LowCountCutoff q γ v:ℝ) ≤ (logSize N)^4+1 ∧
      0 ≤ (logSize N)^(2*γ) ∧ (logSize N)^(2*γ) ≤ v ∧
      2*r7MeanConstant*Real.exp (-r7MeanExponent*q^γ)*v ≤ (logSize N)^(2*γ) ∧
      4*Real.exp (-(r7ConcentrationConstant/4)*((logSize N)^(2*γ))^2/q^γ) ≤
        4*Real.exp (-(r7ConcentrationConstant/4)*(logSize N)^(3*γ)) := by
  have ht := (polynomial_times_stretched_exp_tendsto_zero (16*γ*γ) r7MeanExponent 1
    (by positivity) r7MeanExponent_pos).const_mul (2*r7MeanConstant*C₁)
  simp only [Real.rpow_one,mul_zero] at ht
  filter_upwards [blockB_logSize_tendsto.eventually_ge_atTop 1,
    blockB_logSize_tendsto.eventually_ge_atTop C₁,
    blockB_logSize_tendsto.eventually (ht.eventually_le_const zero_lt_one)] with N hL hCL hmean
  intro q v hq hqL hqv hvL
  have hQ := Real.one_le_rpow hL (by positivity : 0 ≤ 16*γ)
  have hq1 : 1 ≤ q := hQ.trans hq
  have hq0 : 0 < q := by linarith
  have hv : 0 ≤ v := by linarith
  have hcut := r7_low_count_cutoff_scale (logSize N) q γ v C₁ hL hq1 hγ.le hv hvL hC.le hCL
  have hΔ := Real.rpow_nonneg (logSize_pos N).le (2*γ)
  have hΔ1 := Real.one_le_rpow hL (by positivity : 0 ≤ 2*γ)
  have hΔq : (logSize N)^(2*γ) ≤ q :=
    (Real.rpow_le_rpow_of_exponent_le hL (by linarith : 2*γ ≤ 16*γ)).trans hq
  have hW : (logSize N)^(16*γ*γ) ≤ q^γ := by
    rw [Real.rpow_mul (logSize_pos N).le]
    exact Real.rpow_le_rpow (Real.rpow_nonneg (logSize_pos N).le _) hq hγ.le
  have hmean' : 2*r7MeanConstant*Real.exp (-r7MeanExponent*q^γ)*v ≤ (logSize N)^(2*γ) := by
    have he := Real.exp_le_exp.mpr (mul_le_mul_of_nonpos_left hW (by have := r7MeanExponent_pos; linarith : -r7MeanExponent ≤ 0))
    have hm := mul_le_mul (mul_le_mul_of_nonneg_left he (by have := r7MeanConstant_pos; positivity : 0 ≤ 2*r7MeanConstant))
      hvL hv (by have := r7MeanConstant_pos; positivity)
    have heq : (2*r7MeanConstant*Real.exp (-r7MeanExponent*(logSize N)^(16*γ*γ)))*(C₁*logSize N) =
        (2*r7MeanConstant*C₁)*(logSize N*Real.exp (-r7MeanExponent*(logSize N)^(16*γ*γ))) := by ring
    rw [heq] at hm
    exact (hm.trans hmean).trans hΔ1
  refine ⟨hq1,hcut.1,hcut.2,hΔ,hΔq.trans hqv,hmean',?_⟩
  have hratio := r7_delta_ratio (logSize N) q γ (logSize_pos N) hq0 hqL hγ.le
  apply mul_le_mul_of_nonneg_left _ (by norm_num : (0:ℝ) ≤ 4)
  apply Real.exp_le_exp.mpr
  have hmul := mul_le_mul_of_nonpos_left hratio (by have := r7ConcentrationConstant_pos; linarith : -(r7ConcentrationConstant/4) ≤ 0)
  simpa only [mul_div_assoc] using hmul

end TorusCoverTime.Blocks.B
