import Solutions.Blocks.B.PointNearProbability

/-! Fixed-time closed bridges: the return probability is divided out only
after proving its strictly positive mixing lower bound. -/
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

theorem point_soft_return_lower (hWalk : WalkModelRegular) :
    ∀ᶠ N : Size in atTop, ∀ t : ℝ, mixingTime N ≤ t → ∀ a b : Vertex N,
      (2*vertexCount N)⁻¹ ≤ transitionProbability N a b t := by
  filter_upwards [(fourier_walk_identities hWalk).2.2.2,
    blockB_logSize_tendsto.eventually (eventually_ge_atTop 2)] with N hmix hL
  intro t ht a b
  have hp : (logSize N)^(-8:ℝ) ≤ (1/2:ℝ) := by
    apply (Real.rpow_le_rpow_of_nonpos (by norm_num : (0:ℝ)<2) hL (by norm_num : (-8:ℝ)≤0)).trans
    norm_num
  have hh := (neg_abs_le (vertexCount N*transitionProbability N a b t-1)).trans'
    (neg_le_neg ((hmix t ht a b).1.trans hp))
  rw [← one_div]
  apply (div_le_iff₀ (by have := vertexCount_pos N; positivity : 0 < 2*vertexCount N)).mpr
  nlinarith

theorem point_conditioned_event_real (N : Size) (a b : Vertex N) (t : ℝ) (E : Set WalkSample) :
    (walkLaw[|{ω | walk N a ω t=b}]).real E =
      walkLaw.real (E ∩ {ω | walk N a ω t=b})/transitionProbability N a b t := by
  have hm : MeasurableSet {ω | walk N a ω t=b} :=
    ((measurable_walk_eq_joint N a b).comp (measurable_id.prodMk measurable_const)).setOf
  simp only [Measure.real,cond_apply hm,ENNReal.toReal_mul,ENNReal.toReal_inv,
    transitionProbability,div_eq_mul_inv,Set.inter_comm,mul_comm]

theorem point_conditioned_event_bound (N : Size) (a b : Vertex N) (t B : ℝ) (E : Set WalkSample)
    (hB : 0 ≤ B) (hE : walkLaw.real (E ∩ {ω | walk N a ω t=b}) ≤ B)
    (hp : (2*vertexCount N)⁻¹ ≤ transitionProbability N a b t) :
    (walkLaw[|{ω | walk N a ω t=b}]).real E ≤ 2*vertexCount N*B := by
  have hn : 0 < 2*vertexCount N := by have := vertexCount_pos N; positivity
  have hp0 : 0 < transitionProbability N a b t := (inv_pos.mpr hn).trans_le hp
  rw [point_conditioned_event_real]
  apply (div_le_div_of_nonneg_right hE hp0.le).trans
  apply (div_le_iff₀ hp0).mpr
  have h := mul_le_mul_of_nonneg_left hp (mul_nonneg hn.le hB)
  have he : (2*vertexCount N*B)*(2*vertexCount N)⁻¹=B := by field_simp [(vertexCount_pos N).ne']
  rw [he] at h
  exact h

theorem point_soft_closed_bridge_central (hWalk : WalkModelRegular) (u H : ℝ) (hH : 0 ≤ H) :
    ∀ᶠ N : Size in atTop, ∀ root c : Vertex N, ∀ t : ℝ,
      phaseACenter N-H*timeScale N ≤ t →
      (walkLaw[|{ω | walk N root ω t=root}]).real {ω | localTime N root ω t c ≤ u} ≤
        2*pointSoftConstant u H*(logSize N)^(3/2:ℝ)/vertexCount N := by
  filter_upwards [point_soft_joint_central hWalk u H hH,point_soft_return_lower hWalk,
    point_soft_phaseA_rate_eventually H hH] with N hJ hp htime
  intro root c t ht
  have h := point_conditioned_event_bound N root root t (pointSoftJointBound N u H)
    {ω | localTime N root ω t c ≤ u} (pointSoftJointBound_nonneg N u H)
    (hJ c root root t ht) (hp t (htime t ht).1 root root)
  apply h.trans_eq
  unfold pointSoftJointBound
  field_simp [(vertexCount_pos N).ne'] <;> ring

theorem point_near_closed_bridge_central (hWalk : WalkModelRegular) (γ C u H : ℝ)
    (hC : 0 ≤ C) (hH : 0 ≤ H) :
    ∀ᶠ N : Size in atTop, ∀ root : Vertex N, ∀ t : ℝ,
      phaseACenter N-H*timeScale N ≤ t →
      (walkLaw[|{ω | walk N root ω t=root}]).real
        {ω | (ω,t) ∈ pointNearSoftEvent N root root (pointNearRadius N γ C) u} ≤
          2*pointNearEnvelope N γ C u H := by
  filter_upwards [point_soft_joint_central hWalk u H hH,point_soft_return_lower hWalk,
    point_soft_phaseA_rate_eventually H hH] with N hJ hp htime
  intro root t ht
  let R := pointNearRadius N γ C
  let J := pointSoftJointBound N u H
  have hJ0 : 0 ≤ J := pointSoftJointBound_nonneg N u H
  have hj := (point_soft_sites_joint N root root (torusDisk N root R) t u J
    (fun c _ => hJ c root root t ht)).trans
      (mul_le_mul_of_nonneg_right (torusDisk_card_le N root R (pointNearRadius_nonneg N γ C hC)) hJ0)
  have h := point_conditioned_event_bound N root root t ((2*R+1)^2*J)
    {ω | (ω,t) ∈ pointNearSoftEvent N root root R u} (mul_nonneg (sq_nonneg _) hJ0)
    hj (hp t (htime t ht).1 root root)
  apply h.trans
  have hb := mul_le_mul_of_nonneg_left (point_near_spatial_budget N γ C u H) (by norm_num : (0:ℝ)≤2)
  convert hb using 1 <;> (try dsimp only [R,J]) <;> ring

theorem point_near_closed_bridge_uniform (hWalk : WalkModelRegular) (γ C u H : ℝ)
    (hγ : 0 < γ) (hC : 0 ≤ C) (hH : 0 ≤ H) :
    ∀ ε : ℝ, 0 < ε → ∀ᶠ N : Size in atTop, ∀ root : Vertex N, ∀ t : ℝ,
      phaseACenter N-H*timeScale N ≤ t →
      (walkLaw[|{ω | walk N root ω t=root}]).real
        {ω | (ω,t) ∈ pointNearSoftEvent N root root (pointNearRadius N γ C) u} ≤ ε := by
  intro ε hε
  have ht := (point_near_envelope_tendsto γ C u H hγ).const_mul 2
  simp only [mul_zero] at ht
  filter_upwards [point_near_closed_bridge_central hWalk γ C u H hC hH,
    ht.eventually (eventually_lt_nhds hε)] with N hN hεN
  intro root t htime
  exact (hN root t htime).trans hεN.le

end TorusCoverTime.Blocks.B
