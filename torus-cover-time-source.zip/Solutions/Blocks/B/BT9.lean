import Solutions.Blocks.B.BT9Conclusion
import Solutions.Blocks.A.ModelRegularity

/-! Single B-T9 entry point, with actual walk regularity discharged. -/
noncomputable section
namespace TorusCoverTime.Blocks.B

theorem bt9_actual_conclusion (γ U : ℝ) (hγ : 0 < γ) (hγ1 : γ < 1)
    (hU : 0 ≤ U) : BT9Conclusion γ U :=
  bt9_conclusion TorusCoverTime.Blocks.A.walk_model_regular γ U hγ hγ1 hU

theorem bt9_actual_paper_gamma (U : ℝ) (hU : 0 ≤ U) : BT9Conclusion (1/8192) U :=
  bt9_actual_conclusion (1/8192) U (by norm_num) (by norm_num) hU

theorem bt9_actual_two_soft_sites (γ u : ℝ) (hγ : 0 < γ) (hγ1 : γ < 1)
    (hu : 0 ≤ u) : BT9TwoSoftConclusion γ u := by
  have hg : 0 < g := by unfold g; positivity
  exact bt9_two_soft_of_total γ u
    (bt9_actual_conclusion γ (2*u/g) hγ hγ1 (by positivity))

theorem bt9_actual_paper_two_soft_sites (u : ℝ) (hu : 0 ≤ u) :
    BT9TwoSoftConclusion (1/8192) u :=
  bt9_actual_two_soft_sites (1/8192) u (by norm_num) (by norm_num) hu

end TorusCoverTime.Blocks.B
