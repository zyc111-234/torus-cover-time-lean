import Solutions.Blocks.B.WordCenteredConcentration
import Solutions.Blocks.B.TraversalExteriorResampling
import Solutions.Blocks.B.R8SoftExteriorWindow

/-! Two-sided harmonic resampling in the original window with an arbitrary complete exterior weight. -/
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B


theorem r7_centered_exterior_window (hWalk : WalkModelRegular) (γ : ℝ) (hγ : 0 < γ) (hγ1 : γ ≤ 1) :
    ∀ᶠ N : Size in atTop, ∀ c root : Vertex N, ∀ m : ℕ, ∀ w : Fin (2*m) → Vertex N, ∀ q : ℝ,
      (logSize N)^(16*γ) ≤ q → q ≤ logSize N-(logSize N)^(16*γ) →
      (m:ℝ) ≤ (logSize N)^4+1 → root ∉ torusDisk N c (Real.exp (q+2*q^γ)) →
      walkLaw {ω | adaptiveExitWord N (alternatingDomain N (torusDisk N c (Real.exp (q+q^γ)))
        (torusDisk N c (Real.exp (q+2*q^γ)))) root (2*m) ω = w} ≠ 0 →
      ∀ E : TraversalExteriorSample m × ℝ → ℝ≥0∞, Measurable E → (∀ y u, E (y,u) ≤ 1) →
      ∀ Δ l r : ℝ, 0 ≤ Δ →
      2*r7MeanConstant*Real.exp (-r7MeanExponent*q^γ)*Real.sqrt ((m:ℝ)*q^γ) ≤ Δ →
      Δ ≤ Real.sqrt ((m:ℝ)*q^γ) →
      let I := torusDisk N c (Real.exp (q+q^γ))
      let O := torusDisk N c (Real.exp (q+2*q^γ))
      let d := (m:ℝ)*Real.exp (2*logSize N-(logSize N)^(16*γ))
      conditionalTraversalExteriorSlice N I O root m w (r7WordCenteredOccupation N c root m w γ q Δ) E l r ≤
        2*ENNReal.ofReal (2*Real.exp (-(r7ConcentrationConstant/4)*Δ^2/q^γ))*
          conditionalTraversalExteriorSlice N I O root m w univ E (l-d) (r+d) +
        ENNReal.ofReal (r-l)*ENNReal.ofReal (Real.exp (-Real.exp ((logSize N)^(16*γ)/2))) := by
  obtain ⟨q0,hq0⟩ := eventually_atTop.mp (r7_positive_word_centered hWalk γ hγ hγ1)
  have hQ := (tendsto_rpow_atTop (by positivity : 0 < 16*γ)).comp blockB_logSize_tendsto
  filter_upwards [r6_positive_word_duration hWalk γ hγ hγ1,r6_disk_radius_embedding γ hγ,
    hQ.eventually_ge_atTop q0] with N htail hsmall hbase
  intro c root m w q hq hqL hm hr hw E hE hE1 Δ l r hΔ hlo hhi
  dsimp only
  have hI := torusDisk_nonempty N c (Real.exp (q+q^γ)) (Real.exp_pos _)
  have := traversalWordOutwardLaw_probability N _ _ root hI hr m w hw
  have hq0' := (Real.rpow_nonneg (logSize_pos N).le (16*γ)).trans hq
  have hρ := (ENNReal.le_ofReal_iff_toReal_le (measure_ne_top _ _) (by positivity)).mpr
    (hq0 q (hbase.trans hq) N c root m w hr (hsmall q hq0' hqL) hw Δ hΔ hlo hhi)
  exact actual_word_exterior_window_bound N _ _ root hI hr m w hw _
    (r7WordCenteredOccupation_measurable N c root m w γ q Δ) E hE hE1 l r _ _ _ hρ
    (htail c root m w q hq hqL hm hr hw)
    (r6_superexponential_error_le_half _ (Real.rpow_nonneg (logSize_pos N).le _))


end TorusCoverTime.Blocks.B

