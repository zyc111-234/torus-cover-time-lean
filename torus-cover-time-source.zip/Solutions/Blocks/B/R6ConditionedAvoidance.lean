import Solutions.Blocks.B.AnnularConditioning
import Solutions.Blocks.B.R6AnnularAvoidance

/-! R6.3 for the actual specified-endpoint law: a scale-uniform positive
probability of avoiding the entire core, with all conditioning inputs proved. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Classical
open scoped Topology ENNReal
namespace TorusCoverTime.Blocks.B

theorem r6_conditioned_avoidance (γ : ℝ) (hγ : 0 < γ) :
    ∀ᶠ q : ℝ in atTop, ∀ N : Size, ∀ c a b : Vertex N,
      2*(Real.exp (q+2*q^γ)+1) < N.val →
      |periodicDistance a c - Real.exp (q+q^γ)| ≤ 2 →
      diskExteriorNeighbor N c (Real.exp (q+2*q^γ)) b →
      1/8 ≤ (exactExitLaw N (torusDisk N c (Real.exp (q+2*q^γ))) a b).real
        (exitsAvoidingCore N (torusDisk N c (Real.exp (q+2*q^γ))) (torusDisk N c (Real.exp q)) a) := by
  filter_upwards [r6_unconditioned_avoidance γ hγ, r6_exit_ratio_eventually γ hγ (1/8) (by norm_num),
    eventually_ge_atTop (1:ℝ), (tendsto_rpow_atTop hγ).eventually_ge_atTop (Real.log 8)] with q hav hrat hq hw
  intro N c a b hsmall ha hb
  let R := Real.exp (q+2*q^γ)
  let D := torusDisk N c R
  let K := torusDisk N c (Real.exp q)
  have hR0 : 0 < R := Real.exp_pos _
  have hq0 : 0 < q := by linarith
  have hw0 : 0 < q^γ := Real.rpow_pos_of_pos hq0 γ
  have hrR : Real.exp q ≤ R := Real.exp_le_exp.mpr (by linarith)
  have hKD : K ⊆ D := torusDisk_subset N c _ _ hrR
  have hD : D ≠ Finset.univ := torusDisk_proper N c R hR0.le hsmall
  have hcK : c ∈ torusDisk N c (Real.exp q) :=
    (mem_torusDisk N c c _).mpr (by rw [periodicDistance_self_zero]; positivity)
  have haD : a ∈ D := (r6_green_geometry N c a c q (q^γ) hq0.le hw ha hcK).2.1
  have hp : 0 < exitHarmonic N D b a := disk_exitHarmonic_pos N c R hR0 (by linarith) a b haD hb
  have hsum := annulus_core_avoid_probabilities N D K hD hKD a
  have hu := hav N c a hsmall ha
  change 1/4 ≤ walkLaw.real (exitsAvoidingCore N D K a) at hu
  have hcore : walkLaw.real (exitsInto N (D \ K) K a) ≤ 3/4 := by linarith
  have he := exactExitLaw_avoid_lower N D K hD hKD a b hb.1 hp (1/8) (by
    intro z hz
    have hzratio := (abs_le.mp (hrat N c a b z hsmall ha hb hz)).2
    linarith)
  change 1/8 ≤ (exactExitLaw N D a b).real (exitsAvoidingCore N D K a)
  linarith

theorem r6_conditioned_avoiding_exit (γ : ℝ) (hγ : 0 < γ) :
    ∀ᶠ q : ℝ in atTop, ∀ N : Size, ∀ c a b : Vertex N,
      2*(Real.exp (q+2*q^γ)+1) < N.val →
      |periodicDistance a c - Real.exp (q+q^γ)| ≤ 2 →
      diskExteriorNeighbor N c (Real.exp (q+2*q^γ)) b →
      (1/8 : ℝ≥0∞) ≤ exactExitLaw N (torusDisk N c (Real.exp (q+2*q^γ))) a b
        (exitsThroughAvoiding N (torusDisk N c (Real.exp (q+2*q^γ))) (torusDisk N c (Real.exp q)) a b) := by
  filter_upwards [r6_conditioned_avoidance γ hγ] with q hq
  intro N c a b hsmall ha hb
  have he := hq N c a b hsmall ha hb
  have hm := ENNReal.ofReal_le_ofReal he
  have hle : ENNReal.ofReal ((exactExitLaw N (torusDisk N c (Real.exp (q+2*q^γ))) a b).real
      (exitsAvoidingCore N (torusDisk N c (Real.exp (q+2*q^γ))) (torusDisk N c (Real.exp q)) a)) ≤
      exactExitLaw N (torusDisk N c (Real.exp (q+2*q^γ))) a b
      (exitsAvoidingCore N (torusDisk N c (Real.exp (q+2*q^γ))) (torusDisk N c (Real.exp q)) a) :=
    ENNReal.ofReal_toReal_le
  have hres := hm.trans hle
  rw [exactExitLaw_avoid_eq] at hres
  simpa only [ENNReal.ofReal_div_of_pos (by norm_num : (0:ℝ) < 8),
    ENNReal.ofReal_one, ENNReal.ofReal_ofNat] using hres

end TorusCoverTime.Blocks.B
