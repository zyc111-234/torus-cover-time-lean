import Solutions.Blocks.B.R8NestedGaussianWindow

/-! The full exterior consists of every unselected return record and the
terminal infinite tail. Under a fixed endpoint word, an arbitrary measurable
test of this exterior factors from a selected-record event. This assertion
precedes physical-window weighting; the weighted loop estimate is provided
separately by R8NestedGaussianWindow. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

theorem record_exterior_event_factor (n : ℕ)
    (μ : Fin n → Measure (ℕ × WalkSample)) [∀ i, IsProbabilityMeasure (μ i)]
    (S : Fin n → Prop) [DecidablePred S]
    (E : (({i // ¬S i} → ℕ × WalkSample) × WalkSample) → ℝ≥0∞) (hE : Measurable E)
    (B : Set ({i // S i} → ℕ × WalkSample)) (hB : MeasurableSet B) :
    (∫⁻ p, ∫⁻ η, if (fun i : {i // S i} => p i.val) ∈ B then
      E ((fun i : {i // ¬S i} => p i.val),η) else 0 ∂walkLaw ∂Measure.pi μ) =
      (Measure.pi fun i : {i // S i} => μ i.val) B *
        ∫⁻ y, E y ∂((Measure.pi fun i : {i // ¬S i} => μ i.val).prod walkLaw) := by
  let F := fun q : (Fin n → ℕ × WalkSample) × WalkSample =>
    if (fun i : {i // S i} => q.1 i.val) ∈ B then
      E ((fun i : {i // ¬S i} => q.1 i.val),q.2) else 0
  have hF : Measurable F :=
    (hE.comp ((measurable_pi_lambda _ fun i => (measurable_pi_apply i.val).comp measurable_fst).prodMk measurable_snd)).ite
      (hB.preimage (measurable_pi_lambda _ fun i => (measurable_pi_apply i.val).comp measurable_fst)) measurable_const
  have hjoin (x : {i // S i} → ℕ × WalkSample)
      (y : ({i // ¬S i} → ℕ × WalkSample) × WalkSample) :
      F (selectedRecordsJoin S x y.1,y.2) = if x ∈ B then E y else 0 := by
    have hi : (fun i : {i // S i} => selectedRecordsJoin S x y.1 i.val) = x := by
      funext i
      simp [selectedRecordsJoin,Equiv.piEquivPiSubtypeProd,i.property]
    have he : (fun i : {i // ¬S i} => selectedRecordsJoin S x y.1 i.val) = y.1 := by
      funext i
      simp [selectedRecordsJoin,Equiv.piEquivPiSubtypeProd,i.property]
    simp only [F,hi,he,Prod.mk.eta]
  have hinner (y : ({i // ¬S i} → ℕ × WalkSample) × WalkSample) :
      (∫⁻ x, if x ∈ B then E y else 0 ∂Measure.pi (fun i : {i // S i} => μ i.val)) =
      (Measure.pi fun i : {i // S i} => μ i.val) B * E y := by
    rw [mul_comm]
    exact lintegral_indicator_const hB (E y)
  change (∫⁻ p, ∫⁻ η, F (p,η) ∂walkLaw ∂Measure.pi μ) = _
  rw [lintegral_selectedRecordExterior n μ S F hF]
  simp_rw [hjoin,hinner]
  exact lintegral_const_mul _ hE

abbrev TraversalExteriorSample (m : ℕ) :=
  ({j : Fin (2*m) // ¬j.val % 2 = 1} → ℕ × WalkSample) × WalkSample

def traversalExteriorData (N : Size) (Q O : Finset (Vertex N)) (root : Vertex N)
    (m : ℕ) (ω : WalkSample) : TraversalExteriorSample m :=
  ((fun j => adaptiveExitRecord N (alternatingDomain N Q O) root j.val.val ω),
    adaptiveExitTail N (alternatingDomain N Q O) root (2*m) ω)

theorem traversalExteriorData_measurable (N : Size) (Q O : Finset (Vertex N)) (root : Vertex N)
    (m : ℕ) : Measurable (traversalExteriorData N Q O root m) :=
  (measurable_pi_lambda _ fun j : {j : Fin (2*m) // ¬j.val % 2 = 1} =>
    adaptiveExitRecord_measurable N (alternatingDomain N Q O) root j.val.val).prodMk
    (adaptiveExitTail_measurable N _ root (2*m))

theorem actual_word_exterior_event_factor (N : Size) (Q O : Finset (Vertex N)) (root : Vertex N)
    (hQ : Q.Nonempty) (hr : root ∉ O) (m : ℕ) (w : Fin (2*m) → Vertex N)
    (hw : walkLaw {ω | adaptiveExitWord N (alternatingDomain N Q O) root (2*m) ω = w} ≠ 0)
    (E : TraversalExteriorSample m → ℝ≥0∞) (hE : Measurable E)
    (B : Set ({j : Fin (2*m) // j.val % 2 = 1} → ℕ × WalkSample)) (hB : MeasurableSet B) :
    (∫⁻ ω, if (fun j : {j : Fin (2*m) // j.val % 2 = 1} =>
        adaptiveExitRecord N (alternatingDomain N Q O) root j.val.val ω) ∈ B then
        E (traversalExteriorData N Q O root m ω) else 0
      ∂walkLaw[|{ω | adaptiveExitWord N (alternatingDomain N Q O) root (2*m) ω = w}]) =
      traversalWordOutwardLaw N Q O root m w B *
        ∫⁻ y, E y ∂((Measure.pi fun j : {j : Fin (2*m) // ¬j.val % 2 = 1} =>
          traversalWordRecordLaw N Q O root m w j.val).prod walkLaw) := by
  have := traversalWordRecordLaw_probability N Q O root hQ hr m w hw
  let X := fun ω => ((fun j : Fin (2*m) => adaptiveExitRecord N (alternatingDomain N Q O) root j.val ω),
    adaptiveExitTail N (alternatingDomain N Q O) root (2*m) ω)
  have hX : Measurable X :=
    (measurable_pi_lambda _ fun j : Fin (2*m) =>
      adaptiveExitRecord_measurable N (alternatingDomain N Q O) root j.val).prodMk
      (adaptiveExitTail_measurable N _ root (2*m))
  let F := fun z : (Fin (2*m) → ℕ × WalkSample) × WalkSample =>
    if (fun j : {j : Fin (2*m) // j.val % 2 = 1} => z.1 j.val) ∈ B then
      E ((fun j : {j : Fin (2*m) // ¬j.val % 2 = 1} => z.1 j.val),z.2) else 0
  have hF : Measurable F :=
    (hE.comp ((measurable_pi_lambda _ fun j => (measurable_pi_apply j.val).comp measurable_fst).prodMk measurable_snd)).ite
      (hB.preimage (measurable_pi_lambda _ fun j => (measurable_pi_apply j.val).comp measurable_fst)) measurable_const
  change (∫⁻ ω, F (X ω) ∂walkLaw[|{ω | adaptiveExitWord N (alternatingDomain N Q O) root (2*m) ω = w}]) = _
  rw [← lintegral_map hF hX,adaptiveExit_record_tail_conditional_law N _
    (alternatingDomain_proper N Q O hQ ⟨root,hr⟩) root (2*m) w,lintegral_prod _ hF.aemeasurable]
  exact record_exterior_event_factor (2*m) (traversalWordRecordLaw N Q O root m w)
    (fun j => j.val % 2 = 1) E hE B hB

theorem r8_nested_complete_exterior_bound (γ : ℝ) (hγ : 0 < γ) (hγ1 : γ < 1) :
    ∀ᶠ q : ℝ in atTop, ∀ N : Size, ∀ c root : Vertex N, ∀ m : ℕ, ∀ w : Fin (2*m) → Vertex N,
      root ∉ torusDisk N c (Real.exp (q+2*q^γ)) →
      2*(Real.exp (q+2*q^γ)+1) < N.val →
      walkLaw {ω | adaptiveExitWord N (alternatingDomain N (torusDisk N c (Real.exp (q+q^γ)))
        (torusDisk N c (Real.exp (q+2*q^γ)))) root (2*m) ω = w} ≠ 0 →
      ∀ U : ℝ, 0 ≤ U → ∀ E : TraversalExteriorSample m → ℝ≥0∞, Measurable E →
      let Q := torusDisk N c (Real.exp (q+q^γ));
      let O := torusDisk N c (Real.exp (q+2*q^γ));
      (∫⁻ ω, if (r8NestedScale γ q)^γ*r8WordNestedCount γ q N c root m w
          (fun j => adaptiveExitRecord N (alternatingDomain N Q O) root j.val.val ω) ≤ U then
          E (traversalExteriorData N Q O root m ω) else 0
        ∂walkLaw[|{ω | adaptiveExitWord N (alternatingDomain N Q O) root (2*m) ω = w}]) ≤
        ENNReal.ofReal (r8NestedLowerTailBound γ q m U)*
          ∫⁻ y, E y ∂((Measure.pi fun j : {j : Fin (2*m) // ¬j.val % 2 = 1} =>
            traversalWordRecordLaw N Q O root m w j.val).prod walkLaw) := by
  filter_upwards [r8_positive_word_nested_tail γ hγ hγ1] with q hq
  intro N c root m w hr hsmall hw U hU E hE
  dsimp only
  let Q := torusDisk N c (Real.exp (q+q^γ))
  let O := torusDisk N c (Real.exp (q+2*q^γ))
  let B : Set ({j : Fin (2*m) // j.val % 2 = 1} → ℕ × WalkSample) :=
    {p | (r8NestedScale γ q)^γ*r8WordNestedCount γ q N c root m w p ≤ U}
  have hB : MeasurableSet B := measurableSet_le
    ((r8WordNestedCount_measurable γ q N c root m w).const_mul _) measurable_const
  have hQ := torusDisk_nonempty N c (Real.exp (q+q^γ)) (Real.exp_pos _)
  have := traversalWordOutwardLaw_probability N Q O root hQ hr m w hw
  have hρ : traversalWordOutwardLaw N Q O root m w B ≤ ENNReal.ofReal (r8NestedLowerTailBound γ q m U) :=
    (ENNReal.le_ofReal_iff_toReal_le (measure_ne_top _ _) (by unfold r8NestedLowerTailBound; positivity)).mpr
      (hq N c root m w hr hsmall hw U hU)
  have he := actual_word_exterior_event_factor N Q O root hQ hr m w hw E hE B hB
  exact he.le.trans (mul_le_mul' hρ le_rfl)

end TorusCoverTime.Blocks.B
