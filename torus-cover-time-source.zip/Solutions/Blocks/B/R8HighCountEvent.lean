import Solutions.Blocks.B.R8HighCountPrefix
import Solutions.Blocks.B.R7GlobalLowerBarrier

/-! The original physical high-count/soft-site event reduces to a single
fixed-prefix event on each regular sample, simultaneously at all loop times. -/
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

def r8HighCountSoftEvent (N : Size) (c root : Vertex N) (γ q U : ℝ) : Set (WalkSample × ℝ) :=
  {z | 10*logSize N < r7TraversalRadius N c root γ q z ∧ localTime N root z.1 z.2 c/g ≤ U}

theorem r8HighCountSoftEvent_measurable (N : Size) (c root : Vertex N) (γ q U : ℝ) :
    MeasurableSet (r8HighCountSoftEvent N c root γ q U) :=
  (measurableSet_lt measurable_const (r7TraversalRadius_measurable N c root γ q)).inter
    (measurableSet_le ((localTime_joint_measurable N root c).div_const g) measurable_const)

theorem r8_high_count_event_prefix_ae (N : Size) (c root : Vertex N) (γ q U : ℝ) (hq : 0 < q)
    (hr : root ∉ torusDisk N c (Real.exp (q+2*q^γ))) :
    ∀ᵐ ω ∂walkLaw, ∀ t : ℝ, 0 ≤ t → walk N root ω t = root → (ω,t) ∈ r8HighCountSoftEvent N c root γ q U →
      traversalOccupation N (torusDisk N c (Real.exp (q+q^γ))) (torusDisk N c (Real.exp (q+2*q^γ)))
        root (r8SitePotential N c) (r8HighCountCutoff (logSize N) q γ) ω ≤ U := by
  have hIO : torusDisk N c (Real.exp (q+q^γ)) ⊆ torusDisk N c (Real.exp (q+2*q^γ)) :=
    torusDisk_subset N c _ _ (Real.exp_le_exp.mpr (by linarith [Real.rpow_pos_of_pos hq γ]))
  have hc : c ∈ torusDisk N c (Real.exp (q+q^γ)) :=
    (mem_torusDisk N c c _).mpr (by rw [periodicDistance_self_zero]; positivity)
  filter_upwards [r8_site_prefix_le_localTime_ae N _ _ c root hIO hc hr] with ω hω
  intro t ht hloop hbad
  exact (hω t ht hloop _ (r8_high_count_cutoff_le _ q γ _ (logSize_pos N).le hq hbad.1)).trans hbad.2

end TorusCoverTime.Blocks.B
