import Solutions.Blocks.B.KilledSimplicity

/-! The complete registered CapacitySpectrum target, preserving both original inputs. -/

noncomputable section
open scoped BigOperators
namespace TorusCoverTime.Blocks.B

theorem capacity_spectrum (_hFourier : FourierWalkIdentities) (_hGreen : GreenEstimates) :
    CapacitySpectrum := by
  intro N A hne hA
  refine ⟨capacity_pos N A hne hA, ?_, capacity_charge_properties N A hne hA, ?_⟩
  · exact fun q hsupport hq => green_quadratic_pos N A hA q hsupport hq
  · intro hd
    exact ⟨principalMode_valid N A hA,
      (fun f hfA hf => killed_eigenspace_simple N A hA hd f hfA hf),
      killedEigenvalue_lower_bound N A hA hd, killedEigenvalue_le_capacity N A hA,
      principalVariance_nonneg N A hA, principalVariance_bound N A hA hd,
      (fun f hfA horth => killed_orthogonal_gap N A hA hd f hfA horth)⟩

end TorusCoverTime.Blocks.B
