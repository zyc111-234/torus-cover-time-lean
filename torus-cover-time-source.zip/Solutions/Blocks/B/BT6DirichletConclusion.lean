import Solutions.Blocks.B.BT6PowerParameters
import Solutions.Blocks.B.BT6BoundSimplification
import Solutions.Blocks.B.BT6MacroscopicGrid

/-! B-T6 / B.30. The original exit weights, all integer scales, and the
sample-dependent existential amplitude are retained. No bridge, residual,
clock, or geometric probability bound is assumed in this final theorem. -/

noncomputable section
open MeasureTheory Filter
open scoped Topology
namespace TorusCoverTime.Blocks.B

theorem bt6_dirichlet_conclusion (γ ρ C₀ C₁ : ℝ)
    (hγ : 0<γ) (hγhi : 32*γ<1/10) (hρ : 0<ρ) (hρhi : ρ<1/4)
    (hC₀ : 0≤C₀) (hC₁ : 0≤C₁) : BT6DirichletConclusion γ ρ C₀ C₁ := by
  obtain ⟨K,hK,hstep,hgeom⟩ := bt6_exists_step ρ hρ
  let C := bt6ClockError ρ
  let D := bt6MainConstant K C
  let T := dirichletResidualTailConstant 12
  let F := D+8+T+1
  have hC := (bt6ClockError_pos ρ).le
  have hD : 0<D := bt6MainConstant_pos K C hK
  have hT : 0<T := by unfold T dirichletResidualTailConstant; positivity
  have hF : 0<F := by dsimp [F]; linarith
  refine ⟨F,hF,?_⟩
  filter_upwards [blockB_logSize_tendsto.eventually
    (bt6_paper_parameters γ C C₀ C₁ K hγ hγhi hC hC₀ hC₁ hK),
    bt6_macroscopic_geometry ρ K hρ hρhi hgeom] with N hp hg
  rcases hp with ⟨hL,hLK,hA,hAS,hAC,hSK,hSL,hη,hηL,hδ,hbudget,hAK,hlog⟩
  let L := logSize N
  let A := L^(32*γ)
  let S := L^(1/10:ℝ)
  let n := bt6GridLength L K
  let M := bt6LastInteger L K
  let r := bt6GridClearance S K
  have hl1 : 1≤L := by dsimp [L]; linarith
  have hl0 : 0<L := by linarith
  have hs0 : 0<S := Real.rpow_pos_of_pos hl0 _
  obtain ⟨hn,hnlo,hnhi,hmlo,hmhi,hmL,hmS,hr,hrn,hrS,hncmp,hrcmp,hmcount,hmrad⟩ :=
    bt6_grid_choice L S K hK hLK hSK hSL
  intro root c x hroot hx t ht
  have hdeep := hg.2.2 M hmrad c x hx
  have hfinite := bt6_finite_bound N root c x ρ K M n r hρ hg.1 hg.2.1 hdeep hroot hL
    hK hn hstep hnlo hnhi hmlo hmhi hmL A S (C₀*(Real.log L+1)) (C₁*L^(8*γ)) t
    hA hAS hAC hmS hη hηL hδ ht hbudget hr hrn hrS (by dsimp [S] at *; linarith)
  have hmain := bt6_main_bound L S A C K n r hK hl0 hs0 hA hncmp hrcmp
  have hfail := bt6_failure_absorption L A K M hl1 hK hAK hlog hmcount
  have hres : T*Real.exp (-(Real.log L)^2/2)≤T*Real.exp (-(Real.log L)^2/4) := by
    apply mul_le_mul_of_nonneg_left (Real.exp_le_exp.mpr ?_) hT.le
    nlinarith [sq_nonneg (Real.log L)]
  have hb : (finiteFieldLaw N).real (bt6BarrierEvent N root (torusDisk N c (ρ*(N.val:ℝ))) x
      A S (C₀*(Real.log L+1)) (C₁*L^(8*γ)) t)≤
      D*A^5/(L*Real.sqrt S)+(8+T)*Real.exp (-(Real.log L)^2/4) := by
    refine hfinite.trans ?_
    change _+_+T*Real.exp (-(Real.log L)^2/2)≤_
    have hh := add_le_add (add_le_add hmain hfail) hres
    dsimp only [D] at *
    nlinarith only [hh]
  have hpow : A^5=L^(160*γ) := by
    dsimp [A]
    rw [← Real.rpow_mul_natCast hl0.le]
    congr 1
    ring
  rw [hpow] at hb
  have hb' : (finiteFieldLaw N).real (bt6BarrierEvent N root (torusDisk N c (ρ*(N.val:ℝ))) x
      A S (C₀*(Real.log L+1)) (C₁*L^(8*γ)) t)≤
      F*L^(160*γ)/(L*Real.sqrt S)+F*Real.exp (-(Real.log L)^2/4) := by
    refine hb.trans (add_le_add ?_ ?_)
    · apply div_le_div_of_nonneg_right _ (by positivity)
      apply mul_le_mul_of_nonneg_right _ (by positivity)
      dsimp [F]
      linarith
    · apply mul_le_mul_of_nonneg_right _ (Real.exp_pos _).le
      dsimp [F]
      linarith
  have hout := ENNReal.ofReal_le_ofReal hb'
  rw [ofReal_measureReal] at hout
  exact hout

theorem bt6_dirichlet_paper_gamma (ρ C₀ C₁ : ℝ)
    (hρ : 0<ρ) (hρhi : ρ<1/4) (hC₀ : 0≤C₀) (hC₁ : 0≤C₁) :
    BT6DirichletConclusion (1/8192) ρ C₀ C₁ :=
  bt6_dirichlet_conclusion _ ρ C₀ C₁ (by norm_num) (by norm_num) hρ hρhi hC₀ hC₁

end TorusCoverTime.Blocks.B
