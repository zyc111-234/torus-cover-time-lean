import Solutions.Blocks.B.DomainGreenOperator
import Solutions.Blocks.B.GreenArbitraryDifferences

/-! Source representation and spatial differences for the actual disk Green
function. The finite-torus barrier correction is retained and cancels exactly
in a difference of the second argument. -/

noncomputable section
open Classical
namespace TorusCoverTime.Blocks.B

theorem domainGreenFromBarrier_source (N : Size) (D : Finset (Vertex N))
    (hD : D ≠ Finset.univ) (b : Vertex N → ℝ)
    (hb : ∀ x ∈ D, -generator N b x = 1) (f : Vertex N → ℝ) (a : Vertex N) :
    exitExtension N D f a - f a =
      ∑ z ∈ D, generator N f z * domainGreenFromBarrier N D b a z := by
  have hU : ∀ x, x ∉ D → (exitExtension N D f-f) x = 0 := by
    intro x hx
    simp only [Pi.sub_apply, exitExtension_boundary N D f x hx, sub_self]
  have hgen : ∀ x ∈ D, -generator N (exitExtension N D f-f) x = generator N f x := by
    intro x hx
    rw [generator_sub, exitExtension_generator N D f x hx, zero_sub, neg_neg]
  have h := congrFun (domainGreenFromBarrier_solution N D hD b hb
    (generator N f) (exitExtension N D f-f) hU hgen) a
  change exitExtension N D f a-f a = _ at h
  rw [h]
  symm
  apply Finset.sum_subset (Finset.subset_univ D)
  intro z _ hz
  rw [domainGreenFromBarrier_boundary_right N D b hb a z hz, mul_zero]

theorem diskGreen_source (N : Size) (c : Vertex N) (R : ℝ) (hR : 0 ≤ R)
    (hsmall : 2*(R+1) < N.val) (f : Vertex N → ℝ) (a : Vertex N) :
    exitExtension N (torusDisk N c R) f a-f a =
      ∑ z ∈ torusDisk N c R, generator N f z * diskGreen N c R a z :=
  domainGreenFromBarrier_source N _ (torusDisk_proper N c R hR hsmall) _
    (fun z hz => diskBarrier_generator N c R hR hsmall z hz) f a

theorem exitExtension_sub (N : Size) (D : Finset (Vertex N))
    (f h : Vertex N → ℝ) (a : Vertex N) :
    exitExtension N D (f-h) a = exitExtension N D f a-exitExtension N D h a := by
  simp only [exitExtension, Pi.sub_apply, sub_mul, Finset.sum_sub_distrib]

theorem diskGreen_second_difference_of_nearest (C : ℝ) (hC : 0 < C)
    (hNear : NearestGreenControl C) (N : Size) (c : Vertex N) (R ρ : ℝ)
    (hρ : 0 < ρ) (hρR : ρ ≤ R) (hsmall : 2*(R+1) < N.val)
    (a z : Vertex N) (ha : a ∈ torusDisk N c R)
    (hsep : ρ ≤ periodicDistance a c) (hz : periodicDistance z c ≤ ρ/4) :
    |diskGreen N c R a z-diskGreen N c R a c| ≤
      32*C*periodicDistance z c/ρ := by
  have hR := hρ.le.trans hρR
  have hdiff (y : Vertex N) (hy : ρ ≤ periodicDistance y c) :
      |greenKernel N y z-greenKernel N y c| ≤ 16*C*periodicDistance z c/ρ := by
    rw [greenKernel_symm N y z, greenKernel_symm N y c]
    exact (green_arbitrary_differences_of_nearest C hC hNear N ρ hρ z c y y hz
      (by rw [periodicDistance_self_zero]; positivity)
      (by rwa [periodicDistance_comm c y])).1
  have he : |exitExtension N (torusDisk N c R)
      ((fun y => greenKernel N y z)-(fun y => greenKernel N y c)) a| ≤
      16*C*periodicDistance z c/ρ := by
    have hh := diskExitExtension_abs_error N c R hR hsmall a ha
      ((fun y => greenKernel N y z)-(fun y => greenKernel N y c)) 0
      (16*C*periodicDistance z c/ρ) (by
        intro y hy
        simpa only [Pi.sub_apply, sub_zero] using
          hdiff y (hρR.trans (diskExteriorNeighbor_radius N c R y hy).1))
    simpa only [sub_zero] using hh
  have hid : diskGreen N c R a z-diskGreen N c R a c =
      (greenKernel N a z-greenKernel N a c)-exitExtension N (torusDisk N c R)
        ((fun y => greenKernel N y z)-(fun y => greenKernel N y c)) a := by
    rw [exitExtension_sub]
    unfold diskGreen domainGreenFromBarrier
    ring
  rw [hid]
  calc
    _ ≤ |greenKernel N a z-greenKernel N a c| +
        |exitExtension N (torusDisk N c R)
          ((fun y => greenKernel N y z)-(fun y => greenKernel N y c)) a| := abs_sub _ _
    _ ≤ 16*C*periodicDistance z c/ρ + 16*C*periodicDistance z c/ρ :=
      add_le_add (hdiff a hsep) he
    _ = _ := by ring

theorem diskGreen_all_log_bound (N : Size) (c : Vertex N) (R : ℝ) (hR : 0 ≤ R)
    (hsmall : 2*(R+1) < N.val) (b a z : Vertex N)
    (hb : diskExteriorNeighbor N c R b) :
    |diskGreen N c R a z| ≤ 2*greenIncrementConstant*Real.log (3+2*R) := by
  have hbar := fun x hx => diskBarrier_generator N c R hR hsmall x hx
  have hn := domainGreenFromBarrier_nonneg_all N _ _ hbar a z
  change 0 ≤ diskGreen N c R a z at hn
  rw [abs_of_nonneg hn]
  by_cases hz : z ∈ torusDisk N c R
  · have he := congrFun (domainGreenFromBarrier_hit N _ _ hbar z) a
    change diskGreen N c R a z = diskGreen N c R z z *
      exitHarmonic N ((torusDisk N c R).erase z) z a at he
    rw [he]
    apply le_trans _ (diskGreen_diagonal_log_bound N c R hR hsmall b z hb hz)
    exact mul_le_of_le_one_right
      (zero_le_one.trans (diskGreen_diagonal N c R hR hsmall z hz))
      (exitHarmonic_le_one N _ z a)
  · change domainGreenFromBarrier N _ _ a z ≤ _
    rw [domainGreenFromBarrier_boundary_right N _ _ hbar a z hz]
    exact mul_nonneg (by have := greenIncrementConstant_pos; positivity)
      (Real.log_nonneg (by linarith))

end TorusCoverTime.Blocks.B
