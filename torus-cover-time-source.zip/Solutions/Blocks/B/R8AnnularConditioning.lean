import Solutions.Blocks.B.R8AnnularGreen
import Solutions.Blocks.B.AnnularConditioning

/-! The sharp annular estimate survives conditioning on the specified
outer exit. The Doob error is controlled using the actual harmonic kernel. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

theorem exactExitLaw_avoid_relative_error (N : Size) (D K : Finset (Vertex N))
    (hD : D ≠ Finset.univ) (hKD : K ⊆ D) (a b : Vertex N) (hb : b ∉ D)
    (hp : 0 < exitHarmonic N D b a) (ε : ℝ) (hε : 0 ≤ ε)
    (hratio : ∀ z ∈ K, |exitHarmonic N D b z/exitHarmonic N D b a-1| ≤ ε) :
    |(exactExitLaw N D a b).real (exitsAvoidingCore N D K a)-
      walkLaw.real (exitsAvoidingCore N D K a)| ≤ ε := by
  have he := exitHarmonic_annulus_decomposition N D K hD hKD a b hb
  have hsum := annulus_core_avoid_probabilities N D K hD hKD a
  rw [exitsInto_probability_sum] at hsum
  have hform : (exactExitLaw N D a b).real (exitsAvoidingCore N D K a) =
      1-∑ z ∈ K, (exitHarmonic N D b z/exitHarmonic N D b a)*exitHarmonic N (D\K) z a := by
    rw [exactExitLaw_avoid_formula N D K hKD a b hb]
    have hsumdiv : (∑ z ∈ K, (exitHarmonic N D b z/exitHarmonic N D b a)*exitHarmonic N (D\K) z a) =
        (∑ z ∈ K, exitHarmonic N D b z*exitHarmonic N (D\K) z a)/exitHarmonic N D b a := by
      rw [Finset.sum_div]
      apply Finset.sum_congr rfl
      intro z hz
      ring
    rw [hsumdiv]
    apply (div_eq_iff hp.ne').mpr
    field_simp
    linarith
  have hdiff : (exactExitLaw N D a b).real (exitsAvoidingCore N D K a)-
      walkLaw.real (exitsAvoidingCore N D K a) =
      -∑ z ∈ K, (exitHarmonic N D b z/exitHarmonic N D b a-1)*exitHarmonic N (D\K) z a := by
    rw [hform]
    simp only [sub_mul,one_mul,Finset.sum_sub_distrib]
    linarith only [hsum]
  rw [hdiff,abs_neg]
  apply (Finset.abs_sum_le_sum_abs _ _).trans
  calc
    _ ≤ ∑ z ∈ K, ε*exitHarmonic N (D\K) z a := by
      apply Finset.sum_le_sum
      intro z hz
      rw [abs_mul,abs_of_nonneg (exitHarmonic_nonneg N (D\K) z a)]
      exact mul_le_mul_of_nonneg_right (hratio z hz) (exitHarmonic_nonneg N (D\K) z a)
    _ = ε*walkLaw.real (exitsInto N (D\K) K a) := by rw [exitsInto_probability_sum,Finset.mul_sum]
    _ ≤ ε := mul_le_of_le_one_right hε measureReal_le_one

theorem r8_annular_conditioned_avoid_sharp (N : Size) (c a b : Vertex N) (s w v ε : ℝ)
    (hqw : 64 ≤ s-2*w) (hw : Real.log 8 ≤ w) (hwq : w ≤ s-2*w)
    (hqv : 64 ≤ s-2*v) (hv : Real.log 8 ≤ v) (hvq : v ≤ s-2*v)
    (hsmall : 2*(Real.exp s+1) < N.val)
    (ha : |periodicDistance a c-Real.exp (s-w)| ≤ 2)
    (haA : a ∈ torusDisk N c (Real.exp s) \ torusDisk N c (Real.exp (s-v)))
    (hb : diskExteriorNeighbor N c (Real.exp s) b) (hε : 0 ≤ ε)
    (hratio : ∀ z ∈ torusDisk N c (Real.exp (s-v)),
      |exitHarmonic N (torusDisk N c (Real.exp s)) b z /
        exitHarmonic N (torusDisk N c (Real.exp s)) b a-1| ≤ ε) :
    |v*(exactExitLaw N (torusDisk N c (Real.exp s)) a b).real
      (exitsAvoidingCore N (torusDisk N c (Real.exp s)) (torusDisk N c (Real.exp (s-v))) a)-(v-w)| ≤
      r7GreenCenterConstant*(Real.exp (-w/4)+Real.exp (-v/4))+v*ε := by
  have hv0 : 0 ≤ v := (Real.log_nonneg (by norm_num : (1:ℝ) ≤ 8)).trans hv
  have hR : 0 < Real.exp s := Real.exp_pos _
  have hp := disk_exitHarmonic_pos N c _ hR (by linarith) a b (Finset.mem_sdiff.mp haA).1 hb
  have hc := exactExitLaw_avoid_relative_error N (torusDisk N c (Real.exp s))
    (torusDisk N c (Real.exp (s-v))) (torusDisk_proper N c _ hR.le hsmall)
    (torusDisk_subset N c _ _ (Real.exp_le_exp.mpr (by linarith))) a b hb.1 hp ε hε hratio
  have hu := r8_annular_avoid_probability_sharp N c a b s w v hqw hw hwq hqv hv hvq hsmall ha haA hb
  have hm : |v*(exactExitLaw N (torusDisk N c (Real.exp s)) a b).real
      (exitsAvoidingCore N (torusDisk N c (Real.exp s)) (torusDisk N c (Real.exp (s-v))) a)-
      v*walkLaw.real (exitsAvoidingCore N (torusDisk N c (Real.exp s))
        (torusDisk N c (Real.exp (s-v))) a)| ≤ v*ε := by
    rw [← mul_sub,abs_mul,abs_of_nonneg hv0]
    exact mul_le_mul_of_nonneg_left hc hv0
  exact ((abs_sub_le _ _ _).trans (add_le_add hm hu)).trans_eq (add_comm _ _)

end TorusCoverTime.Blocks.B
