import Solutions.Blocks.B.DomainGreenOperator

/-! The Poisson comparison principle for the actual finite-domain generator,
derived from the already constructed ordinary Green inverse. -/

noncomputable section
open Classical
namespace TorusCoverTime.Blocks.B

theorem domain_superharmonic_nonnegative (N : Size) (D : Finset (Vertex N))
    (hD : D ≠ Finset.univ) (b : Vertex N → ℝ) (hb : ∀ x ∈ D, -generator N b x = 1)
    (f : Vertex N → ℝ) (hf : ∀ x ∈ D, 0 ≤ -generator N f x)
    (hbd : ∀ x, x ∉ D → 0 ≤ f x) (x : Vertex N) : 0 ≤ f x := by
  let s := fun z => if z ∈ D then -generator N f z else 0
  let U := f-exitExtension N D f
  have hs (z : Vertex N) : 0 ≤ s z := by
    dsimp [s]
    split_ifs with hz
    · exact hf z hz
    · exact le_rfl
  have hUb (z : Vertex N) (hz : z ∉ D) : U z = 0 := by
    simp only [U,Pi.sub_apply,exitExtension_boundary N D f z hz,sub_self]
  have hUg (z : Vertex N) (hz : z ∈ D) : -generator N U z = s z := by
    dsimp [U,s]
    rw [if_pos hz,generator_sub,exitExtension_generator N D f z hz,sub_zero]
  have he := congrFun (domainGreenFromBarrier_solution N D hD b hb s U hUb hUg) x
  have hpos : 0 ≤ U x := by
    rw [he]
    exact Finset.sum_nonneg fun z _ => mul_nonneg (hs z) (domainGreenFromBarrier_nonneg_all N D b hb x z)
  have hExt := domain_harmonic_nonnegative N D hD (exitExtension N D f)
    (fun z hz => exitExtension_generator N D f z hz) (by
      intro z hz
      rw [exitExtension_boundary N D f z hz]
      exact hbd z hz) x
  change 0 ≤ f x-exitExtension N D f x at hpos
  linarith

end TorusCoverTime.Blocks.B
