import Solutions.Blocks.B.TraversalGeometry
import Solutions.Blocks.B.AdaptiveExitDisintegration

/-! Exact word probabilities and their support. Every positive-probability
word has nonzero individual exit factors and the actual traversal geometry. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

theorem exitChainEndpoints_probability (N : Size) (D : ℕ → Finset (Vertex N))
    (hD : ∀ k, ∃ b : Vertex N, b ∉ D k) (a b : ℕ → Vertex N) (n : ℕ) :
    walkLaw (exitChainEndpoints N D a b n) =
      ∏ j : Fin n, walkLaw (exitsThrough N (D j.val) (a j.val) (b j.val)) := by
  let E := fun j : Fin n => exitRecordEvent N (D j.val) (a j.val) (b j.val)
  let X := fun ω => fun j : Fin n => exitChainRecord N D a j.val ω
  have hX : Measurable X := measurable_pi_lambda _ fun j : Fin n => exitChainRecord_measurable N D hD a j.val
  have hE : MeasurableSet (Set.pi Set.univ E) := MeasurableSet.univ_pi fun j => exitRecordEvent_measurable N _ _ _
  have he : exitChainEndpoints N D a b n = X ⁻¹' Set.pi Set.univ E := by ext ω; simp [X,E,exitChainEndpoints]
  rw [he, ← Measure.map_apply hX hE]
  change (walkLaw.map (fun ω => fun j : Fin n => exitChainRecord N D a j.val ω)) _ = _
  rw [exitChainRecord_prefix_law N D hD a n,Measure.pi_pi]
  apply Finset.prod_congr rfl
  intro j _
  rw [Measure.map_apply (finiteExitRecord_measurable N _ _) (exitRecordEvent_measurable N _ _ _),
    ← exitsThrough_eq_record_preimage]

theorem adaptiveExitWord_probability (N : Size) (D : ℕ → Finset (Vertex N))
    (hD : ∀ k, ∃ b : Vertex N, b ∉ D k) (root : Vertex N) (n : ℕ) (w : Fin n → Vertex N) :
    walkLaw {ω | adaptiveExitWord N D root n ω = w} =
      ∏ j : Fin n, walkLaw (exitsThrough N (D j.val) (endpointWordStart root w j.val) (endpointWordEnd root w j.val)) := by
  rw [measure_congr (adaptiveExitWord_event_eq_ae N D hD root n w)]
  exact exitChainEndpoints_probability N D hD _ _ n

theorem adaptiveExitWord_positive_factors (N : Size) (D : ℕ → Finset (Vertex N))
    (hD : ∀ k, ∃ b : Vertex N, b ∉ D k) (root : Vertex N) (n : ℕ) (w : Fin n → Vertex N)
    (hw : walkLaw {ω | adaptiveExitWord N D root n ω = w} ≠ 0) :
    ∀ j : Fin n, walkLaw (exitsThrough N (D j.val) (endpointWordStart root w j.val) (endpointWordEnd root w j.val)) ≠ 0 := by
  rw [adaptiveExitWord_probability N D hD root n w] at hw
  exact fun j => (Finset.prod_ne_zero_iff.mp hw) j (Finset.mem_univ j)

theorem diskTraversal_positive_word_geometry (N : Size) (c root : Vertex N) (r R : ℝ)
    (hr : 0 < r) (hrR : r ≤ R) (hroot : root ∉ torusDisk N c R) (m : ℕ) (w : Fin (2*m) → Vertex N)
    (hw : walkLaw {ω | adaptiveExitWord N (alternatingDomain N (torusDisk N c r) (torusDisk N c R)) root (2*m) ω = w} ≠ 0) :
    ∀ k : Fin m,
      |periodicDistance (endpointWordStart root w (2*k.val+1)) c-r| ≤ 1 ∧
        diskExteriorNeighbor N c R (endpointWordEnd root w (2*k.val+1)) := by
  obtain ⟨ω,hω,hgeo⟩ := Measure.exists_mem_of_measure_ne_zero_of_ae hw
    (Measure.absolutelyContinuous_restrict.ae_le (diskTraversal_geometry_ae N c root r R hr hrR hroot))
  intro k
  have hh := hgeo k.val
  rw [adaptiveExitStart_of_word N _ root (2*m) w ω hω (2*k.val+1) (by omega),
    adaptiveExitStart_of_word N _ root (2*m) w ω hω (2*k.val+2) (by omega)] at hh
  exact hh

end TorusCoverTime.Blocks.B
