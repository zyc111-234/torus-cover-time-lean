import Solutions.Blocks.B.GaussianAbsoluteEnvelope

noncomputable section
open MeasureTheory Classical
namespace TorusCoverTime.Blocks.B
variable {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]

theorem envelope_weight_pointwise (K c t : ℝ) (hK : 0<K) (ht : 0≤t) :
    (1+t)*Real.exp (c*t)≤Real.exp (K*(c+1)^2/2)*Real.exp (t^2/(2*K)) := by
  have hp : 1+t≤Real.exp t := by linarith [Real.add_one_le_exp t]
  have he : (c+1)*t≤K*(c+1)^2/2+t^2/(2*K) := by
    apply (mul_le_mul_iff_left₀ (show 0<2*K by positivity)).mp
    have he : (K*(c+1)^2/2+t^2/(2*K))*(2*K)=K^2*(c+1)^2+t^2 := by field_simp <;> ring
    rw [he]
    nlinarith [sq_nonneg (t-K*(c+1))]
  calc
    _ ≤ Real.exp t*Real.exp (c*t) := mul_le_mul_of_nonneg_right hp (Real.exp_pos _).le
    _ = Real.exp ((c+1)*t) := by rw [← Real.exp_add]; congr 1; ring
    _ ≤ _ := by rw [← Real.exp_add]; exact Real.exp_le_exp.mpr he

/-- The exponentially weighted large-envelope contribution decays as a
Gaussian tail, directly from the exponential-square moment. -/
theorem envelope_weighted_tail (T : Ω → ℝ) (hm : Measurable T) (hn : ∀ ω, 0≤T ω)
    (K c U : ℝ) (hK : 0<K) (hU : 0≤U)
    (hi : Integrable (fun ω => Real.exp (T ω^2/K)) μ)
    (hb : (∫ ω, Real.exp (T ω^2/K) ∂μ)≤2) :
    Integrable (fun ω => if U<T ω then (1+T ω)*Real.exp (c*T ω) else 0) μ ∧
      (∫ ω, if U<T ω then (1+T ω)*Real.exp (c*T ω) else 0 ∂μ)≤
        2*Real.exp (K*(c+1)^2/2-U^2/(2*K)) := by
  let A := Real.exp (K*(c+1)^2/2-U^2/(2*K))
  let F := fun ω => if U<T ω then (1+T ω)*Real.exp (c*T ω) else 0
  have hA : 0≤A := (Real.exp_pos _).le
  have hF : Measurable F := by
    exact (show Measurable (fun ω => (1+T ω)*Real.exp (c*T ω)) by fun_prop).ite
      (measurableSet_lt measurable_const hm) measurable_const
  have hF0 (ω) : 0≤F ω := by dsimp [F]; split_ifs <;> positivity [hn ω]
  have hpoint (ω) : F ω≤A*Real.exp (T ω^2/K) := by
    dsimp only [F]
    split_ifs with h
    · refine (envelope_weight_pointwise K c (T ω) hK (hn ω)).trans ?_
      dsimp only [A]
      rw [← Real.exp_add,← Real.exp_add]
      apply Real.exp_le_exp.mpr
      have hs : U^2≤T ω^2 := by nlinarith [hn ω]
      have hd := div_le_div_of_nonneg_right hs (show 0≤2*K by positivity)
      have he : T ω^2/K=2*(T ω^2/(2*K)) := by ring
      rw [he]
      linarith
    · positivity
  have hInt : Integrable F μ := (hi.const_mul A).mono' hF.aestronglyMeasurable
    (Filter.Eventually.of_forall (fun ω => by rw [Real.norm_eq_abs,abs_of_nonneg (hF0 ω)]; exact hpoint ω))
  refine ⟨hInt,?_⟩
  calc
    _ ≤ ∫ ω, A*Real.exp (T ω^2/K) ∂μ := integral_mono hInt (hi.const_mul A) hpoint
    _ = A*(∫ ω, Real.exp (T ω^2/K) ∂μ) := integral_const_mul _ _
    _ ≤ A*2 := mul_le_mul_of_nonneg_left hb hA
    _ = _ := by dsimp [A]; ring

theorem envelope_weighted_full (T : Ω → ℝ) (hm : Measurable T) (hn : ∀ ω, 0≤T ω)
    (K c : ℝ) (hK : 0<K) (hi : Integrable (fun ω => Real.exp (T ω^2/K)) μ)
    (hb : (∫ ω, Real.exp (T ω^2/K) ∂μ)≤2) :
    Integrable (fun ω => (1+T ω)*Real.exp (c*T ω)) μ ∧
      (∫ ω, (1+T ω)*Real.exp (c*T ω) ∂μ)≤2*Real.exp (K*(c+1)^2/2) := by
  let A := Real.exp (K*(c+1)^2/2)
  have hp (ω) : (1+T ω)*Real.exp (c*T ω)≤A*Real.exp (T ω^2/K) := by
    refine (envelope_weight_pointwise K c (T ω) hK (hn ω)).trans ?_
    apply mul_le_mul_of_nonneg_left (Real.exp_le_exp.mpr ?_) (Real.exp_pos _).le
    have hh : T ω^2/(2*K)=(T ω^2/K)/2 := by ring
    rw [hh]
    have hnn : 0≤T ω^2/K := by positivity
    linarith
  have hint : Integrable (fun ω => (1+T ω)*Real.exp (c*T ω)) μ := (hi.const_mul A).mono' (by fun_prop)
    (Filter.Eventually.of_forall (fun ω => by
      rw [Real.norm_eq_abs,abs_of_nonneg (by positivity [hn ω])]
      exact hp ω))
  refine ⟨hint,?_⟩
  calc
    _ ≤ ∫ ω, A*Real.exp (T ω^2/K) ∂μ := integral_mono hint (hi.const_mul A) hp
    _ = A*(∫ ω, Real.exp (T ω^2/K) ∂μ) := integral_const_mul _ _
    _ ≤ A*2 := mul_le_mul_of_nonneg_left hb (Real.exp_pos _).le
    _ = _ := by dsimp [A]; ring

theorem envelope_weighted_split (T : Ω → ℝ) (hm : Measurable T) (hn : ∀ ω, 0≤T ω)
    (K c b U P : ℝ) (hK : 0<K) (hb : 0≤b) (hU : 0≤U) (hP : 0≤P)
    (hi : Integrable (fun ω => Real.exp (T ω^2/K)) μ)
    (hmean : (∫ ω, Real.exp (T ω^2/K) ∂μ)≤2) :
    Integrable (fun ω => (b+T ω)*Real.exp (c*(b+T ω))*(if T ω≤U then P else 1)) μ ∧
      (∫ ω, (b+T ω)*Real.exp (c*(b+T ω))*(if T ω≤U then P else 1) ∂μ)≤
        2*(b+1)*Real.exp (c*b+K*(c+1)^2/2)*(P+Real.exp (-U^2/(2*K))) := by
  obtain ⟨hfull,hfullb⟩ := envelope_weighted_full T hm hn K c hK hi hmean
  obtain ⟨htail,htailb⟩ := envelope_weighted_tail T hm hn K c U hK hU hi hmean
  let W := fun ω => (1+T ω)*Real.exp (c*T ω)
  let D := (b+1)*Real.exp (c*b)
  let F := fun ω => (b+T ω)*Real.exp (c*(b+T ω))*(if T ω≤U then P else 1)
  let B := fun ω => D*(P*W ω+(if U<T ω then W ω else 0))
  have hD : 0≤D := by dsimp [D]; positivity
  have hB : Integrable B μ := ((hfull.const_mul P).add htail).const_mul D
  have hF : Measurable F := by
    apply Measurable.mul (by fun_prop)
    exact measurable_const.ite (measurableSet_le hm measurable_const) measurable_const
  have hnF (ω) : 0≤F ω := by dsimp [F]; split_ifs <;> positivity [hn ω]
  have hpoint (ω) : F ω≤B ω := by
    have hp : (b+T ω)*Real.exp (c*(b+T ω))≤D*W ω := by
      rw [mul_add,Real.exp_add]
      dsimp [D,W]
      have hs : b+T ω≤(b+1)*(1+T ω) := by nlinarith [mul_nonneg hb (hn ω)]
      nlinarith only [mul_le_mul_of_nonneg_right hs (mul_nonneg (Real.exp_pos (c*b)).le (Real.exp_pos (c*T ω)).le)]
    dsimp only [F,B]
    by_cases ht : T ω≤U
    · rw [if_pos ht,if_neg (not_lt.mpr ht),add_zero]
      nlinarith only [mul_le_mul_of_nonneg_right hp hP]
    · rw [if_neg ht,if_pos (lt_of_not_ge ht),mul_one]
      have hw0 : 0≤W ω := by dsimp [W]; positivity [hn ω]
      nlinarith only [hp,mul_nonneg hD (mul_nonneg hP hw0)]
  have hint : Integrable F μ := hB.mono' hF.aestronglyMeasurable
    (Filter.Eventually.of_forall (fun ω => by rw [Real.norm_eq_abs,abs_of_nonneg (hnF ω)]; exact hpoint ω))
  refine ⟨hint,(integral_mono hint hB hpoint).trans ?_⟩
  dsimp only [B]
  rw [integral_const_mul,integral_add (hfull.const_mul P) htail,integral_const_mul]
  have hh := mul_le_mul_of_nonneg_left
    (add_le_add (mul_le_mul_of_nonneg_left hfullb hP) htailb) hD
  refine hh.trans_eq ?_
  dsimp only [D]
  rw [Real.exp_sub,Real.exp_add,neg_div,Real.exp_neg]
  ring

end TorusCoverTime.Blocks.B
