import Solutions.Blocks.B.BT10Goal
import Solutions.Blocks.B.BT8Parameters
import Solutions.Blocks.B.R8ModerateCountSupport

noncomputable section
open Filter Set Classical
open scoped Topology
namespace TorusCoverTime.Blocks.B

def bt10WitnessScale (N : Size) (x y : Vertex N) : ℕ := ⌈Real.log (periodicDistance x y)⌉₊+1

theorem bt10_wide_log_range (N : Size) (x y : Vertex N) (h : bt10Wide N x y) :
    x≠y ∧ (logSize N)^(1/8:ℝ)-Real.log 2<Real.log (periodicDistance x y) ∧
      Real.log (periodicDistance x y)<logSize N-(logSize N)^(1/8:ℝ)+Real.log 2 := by
  have hlo : 0<separationRadius N/2 := by unfold separationRadius; positivity
  have hd := hlo.trans h.1
  have hN : 0<(N.val:ℝ) := by have := size_real_gt_one N; linarith
  have hxy : x≠y := by intro he; subst y; rw [periodicDistance_self_zero] at hd; linarith
  have hl := Real.log_lt_log hlo h.1
  have hr := Real.log_lt_log hd h.2
  rw [separationRadius,Real.log_div (Real.exp_pos _).ne' (by norm_num),Real.log_exp] at hl
  rw [distantRadius,Real.log_mul (by norm_num : (2:ℝ)≠0) (mul_pos hN (Real.exp_pos _)).ne',
    Real.log_mul hN.ne' (Real.exp_pos _).ne',Real.log_exp] at hr
  exact ⟨hxy,hl,by change Real.log (periodicDistance x y)<_ at hr; dsimp [logSize] at *; linarith⟩

theorem bt10_witness_scale_bounds (γ : ℝ) (hγ : 0<γ) (hγhi : 32*γ<1/10) :
    ∀ᶠ N : Size in atTop, ∀ x y : Vertex N, bt10Wide N x y →
      let q := bt10WitnessScale N x y;
      x≠y ∧ (q:ℝ)-2≤Real.log (periodicDistance x y) ∧ Real.log (periodicDistance x y)<(q:ℝ) ∧
      (logSize N)^(1/10:ℝ)≤(q:ℝ) ∧ (q:ℝ)≤logSize N-(logSize N)^(1/10:ℝ) ∧
      q∈r8InteriorIntegerScales N γ := by
  have hp := bt6_polylog_subpower (1/8) (1/10) 1 0 0 (Real.log 2+2) (by norm_num) (by norm_num)
  filter_upwards [bt8_parameters γ hγ hγhi,blockB_logSize_tendsto.eventually hp] with N hN hP
  intro x y hwide
  dsimp only
  have hw := bt10_wide_log_range N x y hwide
  have hpow : 1≤(logSize N)^(1/10:ℝ) := Real.one_le_rpow hN.1 (by norm_num)
  simp only [zero_mul,add_zero,one_mul] at hP
  have hd0 : 0≤Real.log (periodicDistance x y) := by linarith [hw.2.1]
  have hc := Nat.le_ceil (Real.log (periodicDistance x y))
  have hc' := Nat.ceil_lt_add_one hd0
  have he : (bt10WitnessScale N x y:ℝ)=(⌈Real.log (periodicDistance x y)⌉₊:ℝ)+1 := by
    simp only [bt10WitnessScale,Nat.cast_add,Nat.cast_one]
  have hlo : (logSize N)^(1/10:ℝ)≤(bt10WitnessScale N x y:ℝ) := by rw [he]; linarith [hw.2.1]
  have hhi : (bt10WitnessScale N x y:ℝ)≤logSize N-(logSize N)^(1/10:ℝ) := by rw [he]; linarith [hw.2.2]
  refine ⟨hw.1,by rw [he]; linarith,by rw [he]; linarith,hlo,hhi,?_⟩
  apply (mem_r8InteriorIntegerScales N γ _).mpr
  exact ⟨hN.2.1.trans (hN.2.2.1.trans hlo),by linarith [hN.2.1,hN.2.2.1]⟩

end TorusCoverTime.Blocks.B
