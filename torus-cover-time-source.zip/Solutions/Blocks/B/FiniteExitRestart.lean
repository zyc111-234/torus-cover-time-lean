import Solutions.Blocks.B.RootExcursionRestart
import Solutions.Blocks.B.DiskPhysicalExit

/-! The first exit from a proper domain is an actual finite stopping index.
Its stopped record and fresh tail have a product law, including all holding times. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

theorem finite_domain_exits_ae (N : Size) (D : Finset (Vertex N))
    (hD : ∃ b : Vertex N, b ∉ D) (a : Vertex N) :
    ∀ᵐ ω ∂walkLaw, ∃ n : ℕ, position N a ω n ∉ D := by
  obtain ⟨b, hb⟩ := hD
  filter_upwards [TorusCoverTime.Blocks.D.ae_position_hits N a b] with ω hω
  obtain ⟨n, hn⟩ := hω
  exact ⟨n, hn.symm ▸ hb⟩

theorem exitsThroughAt_prefix (N : Size) (D : Finset (Vertex N)) (a b : Vertex N)
    {ω η : WalkSample} (n : ℕ) (hp : ∀ j < n, η j = ω j) :
    exitsThroughAt N D a b η n ↔ exitsThroughAt N D a b ω n := by
  have he := A.position_eq_of_prefix N a n hp
  simp only [exitsThroughAt, he n le_rfl]
  apply and_congr_right
  intro _
  apply and_congr_right
  intro _
  exact forall_congr' fun j : Fin n => by rw [he j.val j.isLt.le]

theorem finiteExitIndex_spec (N : Size) (D : Finset (Vertex N)) (a : Vertex N)
    (ω : WalkSample) (he : ∃ n : ℕ, position N a ω n ∉ D) :
    exitsThroughAt N D a (position N a ω (finiteExitIndex N D a ω))
      ω (finiteExitIndex N D a ω) := by
  simpa only [finiteExitIndex, dif_pos he] using exit_word_of_exists_exit N D a ω he

theorem finiteExitIndex_eq_iff_ae (N : Size) (D : Finset (Vertex N))
    (hD : ∃ b : Vertex N, b ∉ D) (a : Vertex N) (n : ℕ) :
    ∀ᵐ ω ∂walkLaw, finiteExitIndex N D a ω = n ↔
      ∃ b : Vertex N, exitsThroughAt N D a b ω n := by
  filter_upwards [finite_domain_exits_ae N D hD a] with ω hω
  constructor
  · intro hn
    exact ⟨position N a ω n, by simpa only [hn] using finiteExitIndex_spec N D a ω hω⟩
  · rintro ⟨b, hb⟩
    exact finiteExitIndex_of_exit_word N D a b ω n hb

theorem finiteExitIndex_stoppingRule (N : Size) (D : Finset (Vertex N))
    (hD : ∃ b : Vertex N, b ∉ D) (a : Vertex N) :
    PrefixStoppingRule (finiteExitIndex N D a) := by
  refine ⟨measurable_finiteExitIndex N D a, ?_⟩
  intro n
  let E : Set (A.WalkPrefix n) := {p | ∃ b : Vertex N,
    exitsThroughAt N D a b (A.joinSequence n p (fun _ => (0, 0))) n}
  have hm : Measurable (fun p : A.WalkPrefix n => A.joinSequence n p (fun _ => (0, 0))) :=
    (prefixRecord_measurable n).snd
  have hE : MeasurableSet E := by
    simp only [E, Set.ofPred_exists]
    exact MeasurableSet.iUnion fun b => (measurableSet_exitsThroughAt N D a b n).preimage hm
  refine ⟨E, hE, ?_⟩
  filter_upwards [finiteExitIndex_eq_iff_ae N D hD a n] with ω hω
  refine hω.trans (exists_congr fun b => ?_)
  exact (exitsThroughAt_prefix N D a b n (fun j hj => by
    simp only [A.joinSequence, dif_pos hj, A.splitSequence])).symm

def finiteExitRecord (N : Size) (D : Finset (Vertex N)) (a : Vertex N) :=
  stoppedRecord (finiteExitIndex N D a)

def finiteExitTail (N : Size) (D : Finset (Vertex N)) (a : Vertex N) :=
  stoppedTail (finiteExitIndex N D a)

def exitRecordEndpoint (N : Size) (a : Vertex N) (p : ℕ × WalkSample) : Vertex N :=
  position N a p.2 p.1

theorem finiteExitRecord_measurable (N : Size) (D : Finset (Vertex N)) (a : Vertex N) :
    Measurable (finiteExitRecord N D a) :=
  stoppedRecord_measurable (measurable_finiteExitIndex N D a)

theorem finiteExitTail_measurable (N : Size) (D : Finset (Vertex N)) (a : Vertex N) :
    Measurable (finiteExitTail N D a) :=
  stoppedTail_measurable (measurable_finiteExitIndex N D a)

theorem exitRecordEndpoint_measurable (N : Size) (a : Vertex N) :
    Measurable (exitRecordEndpoint N a) :=
  measurable_from_prod_countable_right fun n =>
    measurable_to_countable' fun b => (measurable_position_eq N a b n).setOf

theorem finiteExitRecord_agrees (N : Size) (D : Finset (Vertex N)) (a : Vertex N)
    (ω : WalkSample) (j : ℕ) (hj : j < finiteExitIndex N D a ω) :
    (finiteExitRecord N D a ω).2 j = ω j := by
  simp only [finiteExitRecord, stoppedRecord, if_pos hj]

theorem finiteExitRecord_position (N : Size) (D : Finset (Vertex N)) (a : Vertex N)
    (ω : WalkSample) (j : ℕ) (hj : j ≤ finiteExitIndex N D a ω) :
    position N a (finiteExitRecord N D a ω).2 j = position N a ω j :=
  A.position_eq_of_prefix N a _ (finiteExitRecord_agrees N D a ω) j hj

theorem finiteExitDuration_eq_record (N : Size) (D : Finset (Vertex N)) (a : Vertex N)
    (ω : WalkSample) :
    finiteExitDuration N D a ω = excursionRecordDuration (finiteExitRecord N D a ω) :=
  (A.jumpTime_eq_of_prefix _ (finiteExitRecord_agrees N D a ω) _ le_rfl).symm

theorem finiteExitRecord_tail_law (N : Size) (D : Finset (Vertex N))
    (hD : ∃ b : Vertex N, b ∉ D) (a : Vertex N) :
    walkLaw.map (fun ω => (finiteExitRecord N D a ω, finiteExitTail N D a ω)) =
      (walkLaw.map (finiteExitRecord N D a)).prod walkLaw :=
  stoppedRecord_tail_law (finiteExitIndex_stoppingRule N D hD a)

theorem finiteExitTail_measurePreserving (N : Size) (D : Finset (Vertex N))
    (hD : ∃ b : Vertex N, b ∉ D) (a : Vertex N) :
    MeasurePreserving (finiteExitTail N D a) walkLaw walkLaw :=
  stoppedTail_measurePreserving (finiteExitIndex_stoppingRule N D hD a)

theorem finiteExitRecord_tail_independent (N : Size) (D : Finset (Vertex N))
    (hD : ∃ b : Vertex N, b ∉ D) (a : Vertex N) :
    IndepFun (finiteExitRecord N D a) (finiteExitTail N D a) walkLaw :=
  stoppedRecord_tail_independent (finiteExitIndex_stoppingRule N D hD a)

theorem finiteExitDuration_tail_independent (N : Size) (D : Finset (Vertex N))
    (hD : ∃ b : Vertex N, b ∉ D) (a : Vertex N) :
    IndepFun (finiteExitDuration N D a) (finiteExitTail N D a) walkLaw := by
  apply ((finiteExitRecord_tail_independent N D hD a).comp
    excursionRecordDuration_measurable measurable_id).congr
  · exact Eventually.of_forall fun ω => (finiteExitDuration_eq_record N D a ω).symm
  · exact Eventually.of_forall fun _ => rfl

theorem finiteExitRecord_endpoint_ae (N : Size) (D : Finset (Vertex N))
    (hD : ∃ b : Vertex N, b ∉ D) (a : Vertex N) :
    ∀ᵐ ω ∂walkLaw, exitRecordEndpoint N a (finiteExitRecord N D a ω) ∉ D := by
  filter_upwards [finite_domain_exits_ae N D hD a] with ω hω
  change position N a (finiteExitRecord N D a ω).2 (finiteExitIndex N D a ω) ∉ D
  rw [finiteExitRecord_position N D a ω _ le_rfl]
  exact (finiteExitIndex_spec N D a ω hω).1

theorem finiteExitDuration_eq_physical_ae (N : Size) (D : Finset (Vertex N))
    (hD : ∃ b : Vertex N, b ∉ D) (a : Vertex N) :
    ∀ᵐ ω ∂walkLaw, domainExitTime N D a ω =
      ENNReal.ofReal (finiteExitDuration N D a ω) := by
  filter_upwards [A.holding_positive_and_nonexplosive, finite_domain_exits_ae N D hD a]
    with ω hreg he
  exact domainExitTime_of_exit_word N D a _ hreg.1 hreg.2 _
    (finiteExitIndex_spec N D a ω he)

end TorusCoverTime.Blocks.B
