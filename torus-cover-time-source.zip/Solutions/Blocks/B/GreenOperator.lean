import Solutions.Blocks.B.GreenBounds

/-! The finite Green operator: mean zero, symmetry, and inversion of the generator. -/

noncomputable section
open scoped BigOperators
namespace TorusCoverTime.Blocks.B

lemma generator_sum {ι : Type*} (N : Size) (s : Finset ι)
    (f : ι → Vertex N → ℝ) (x : Vertex N) :
    generator N (fun z => ∑ i ∈ s, f i z) x = ∑ i ∈ s, generator N (f i) x := by
  unfold generator
  simp_rw [← Finset.sum_sub_distrib]
  rw [Finset.sum_comm, Finset.mul_sum]

lemma generator_mul_left (N : Size) (c : ℝ) (f : Vertex N → ℝ) (x : Vertex N) :
    generator N (fun z => c * f z) x = c * generator N f x := by
  simp only [generator, ← mul_sub, ← Finset.mul_sum]
  ring

lemma generator_sub_translate (N : Size) (f : Vertex N → ℝ) (x y : Vertex N) :
    generator N (fun z => f (z - y)) x = generator N f (x - y) := by
  unfold generator
  congr 1
  apply Finset.sum_congr rfl
  intro d _
  dsimp only
  rw [show x + direction N d - y = (x - y) + direction N d by abel]

lemma finiteCosine_neg (N : Size) (k z : Vertex N) : finiteCosine N k (-z) = finiteCosine N k z := by
  rw [← finiteCharacter_re, ← finiteCharacter_re]
  simp only [finiteCharacter, Prod.fst_neg, Prod.snd_neg, mul_neg, ← neg_add,
    coordinateCharacter_neg, Complex.inv_eq_conj (coordinateCharacter_norm N _), Complex.conj_re]

lemma greenKernel_symm (N : Size) (x y : Vertex N) : greenKernel N x y = greenKernel N y x := by
  unfold greenKernel
  congr 1
  apply Finset.sum_congr rfl
  intro k _
  rw [← neg_sub x y, finiteCosine_neg]

lemma greenKernel_eq_fourier_sum (N : Size) (x y : Vertex N) :
    greenKernel N x y = ∑ k ∈ nonzeroFrequencies N,
      (1 / (vertexCount N * finiteEigenvalue N k)) * finiteCosine N k (x - y) := by
  rw [greenKernel, Finset.sum_div]
  apply Finset.sum_congr rfl
  intro k _
  simp only [div_eq_mul_inv, mul_inv_rev]
  ring

lemma finiteCosine_sum_space (N : Size) (k : Vertex N) (hk : k ≠ 0) :
    (∑ x : Vertex N, finiteCosine N k x) = 0 := by
  have hre : (∑ x : Vertex N, finiteCharacter N k x).re =
      ∑ x : Vertex N, (finiteCharacter N k x).re := map_sum Complex.reAddGroupHom _ _
  have h := congrArg Complex.re (finiteCharacter_sum_eq_zero N k hk)
  simpa only [hre, finiteCharacter_re, Complex.zero_re] using h

lemma finiteCosine_sum_shift (N : Size) (k y : Vertex N) (hk : k ≠ 0) :
    (∑ x : Vertex N, finiteCosine N k (x - y)) = 0 := by
  calc
    _ = ∑ x : Vertex N, finiteCosine N k x := by
      simpa only [sub_eq_add_neg] using
        (Fintype.sum_equiv (Equiv.addRight (-y))
          (fun x : Vertex N => finiteCosine N k (x + -y))
          (fun x : Vertex N => finiteCosine N k x) (fun _ => rfl))
    _ = _ := finiteCosine_sum_space N k hk

lemma greenKernel_sum_left (N : Size) (y : Vertex N) :
    (∑ x : Vertex N, greenKernel N x y) = 0 := by
  simp_rw [greenKernel_eq_fourier_sum]
  rw [Finset.sum_comm]
  apply Finset.sum_eq_zero
  intro k hk
  rw [← Finset.mul_sum, finiteCosine_sum_shift N k y (Finset.mem_erase.mp hk).1, mul_zero]

lemma greenKernel_generator (N : Size) (x y : Vertex N) :
    -generator N (fun z => greenKernel N z y) x = (if x = y then 1 else 0) - 1 / vertexCount N := by
  classical
  have hfun : (fun z => greenKernel N z y) = fun z => ∑ k ∈ nonzeroFrequencies N,
      (1 / (vertexCount N * finiteEigenvalue N k)) * finiteCosine N k (z - y) := by
    funext z
    exact greenKernel_eq_fourier_sum N z y
  rw [hfun, generator_sum, ← Finset.sum_neg_distrib]
  have hterm (k : Vertex N) (hk : k ∈ nonzeroFrequencies N) :
      -generator N (fun z => 1 / (vertexCount N * finiteEigenvalue N k) * finiteCosine N k (z - y)) x =
        finiteCosine N k (x - y) / vertexCount N := by
    rw [generator_mul_left, neg_mul_eq_mul_neg, generator_sub_translate, finiteCosine_generator]
    have hl := eigenvalue_pos_of_nonzero N hk
    have hn := vertexCount_pos N
    field_simp
  rw [Finset.sum_congr rfl hterm, ← Finset.sum_div]
  have hfour := finite_fourier_initial_condition N x y
  have hn := vertexCount_pos N
  by_cases hxy : x = y
  · rw [if_pos hxy] at hfour ⊢
    apply (div_eq_iff hn.ne').mpr
    field_simp
    linarith
  · rw [if_neg hxy] at hfour ⊢
    apply (div_eq_iff hn.ne').mpr
    field_simp
    linarith

def greenOperator (N : Size) (q : Vertex N → ℝ) (x : Vertex N) : ℝ :=
  ∑ y : Vertex N, greenKernel N x y * q y

lemma greenOperator_mean_zero (N : Size) (q : Vertex N → ℝ) :
    spatialMean N (greenOperator N q) = 0 := by
  unfold spatialMean greenOperator
  rw [Finset.sum_comm]
  simp_rw [← Finset.sum_mul, greenKernel_sum_left, zero_mul]
  simp

lemma greenOperator_generator (N : Size) (q : Vertex N → ℝ) (x : Vertex N) :
    -generator N (greenOperator N q) x = q x - spatialMean N q := by
  classical
  have hfun : greenOperator N q = fun z => ∑ y : Vertex N, q y * greenKernel N z y := by
    funext z
    simp only [greenOperator, mul_comm]
  rw [hfun, generator_sum, ← Finset.sum_neg_distrib]
  simp_rw [generator_mul_left, neg_mul_eq_mul_neg, greenKernel_generator, mul_sub]
  rw [Finset.sum_sub_distrib]
  simp only [mul_ite, mul_one, mul_zero]
  have hdelta : (∑ y : Vertex N, if x = y then q y else 0) = q x := by
    simp
  rw [hdelta]
  rw [← Finset.sum_mul]
  unfold spatialMean
  ring

end TorusCoverTime.Blocks.B
