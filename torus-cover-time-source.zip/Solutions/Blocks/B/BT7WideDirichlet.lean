import Solutions.Blocks.B.BT7WideParameters
import Solutions.Blocks.B.BT6DirichletConclusion

noncomputable section
open MeasureTheory Filter
open scoped Topology
namespace TorusCoverTime.Blocks.B

/-- B.30 with growing endpoint and barrier errors, for the B-T7 transfer. -/
theorem bt7_wide_dirichlet (γ ρ : ℝ)
    (hγ : 0<γ) (hγhi : 32*γ<1/10) (hρ : 0<ρ) (hρhi : ρ<1/4) :
    ∃ F : ℝ, 0<F ∧ ∀ᶠ N : Size in atTop,
      ∀ root c x : Vertex N, root∉torusDisk N c (ρ*(N.val:ℝ)) →
        periodicDistance x c≤ρ*(N.val:ℝ)/4 → ∀ t : ℝ,
          |t-harmonicExtremeCenter N|≤(logSize N)^(16*γ) →
      (finiteFieldLaw N) {ξ | bt6BadField N x γ ((logSize N)^(16*γ)) ((logSize N)^(16*γ))
        (dirichletConditionedField N root (torusDisk N c (ρ*(N.val:ℝ))) x t ξ)} ≤
          ENNReal.ofReal (F*(logSize N)^(160*γ)/(logSize N*Real.sqrt ((logSize N)^(1/10:ℝ)))+
            F*Real.exp (-((Real.log (logSize N))^2)/4)) := by
  obtain ⟨K,hK,hstep,hgeom⟩ := bt6_exists_step ρ hρ
  let C := bt6ClockError ρ
  let D := bt6MainConstant K C
  let T := dirichletResidualTailConstant 12
  let F := D+8+T+1
  have hC := (bt6ClockError_pos ρ).le
  have hD : 0<D := bt6MainConstant_pos K C hK
  have hT : 0<T := by unfold T dirichletResidualTailConstant; positivity
  have hF : 0<F := by dsimp [F]; linarith
  refine ⟨F,hF,?_⟩
  filter_upwards [blockB_logSize_tendsto.eventually
    (bt7_wide_parameters γ C K hγ hγhi hC),
    bt6_macroscopic_geometry ρ K hρ hρhi hgeom] with N hp hg
  rcases hp with ⟨hL,hLK,hA,hAS,hAC,hSK,hSL,hη,hηL,hδ,hbudget,hAK,hlog⟩
  let L := logSize N
  let A := L^(32*γ)
  let S := L^(1/10:ℝ)
  let n := bt6GridLength L K
  let M := bt6LastInteger L K
  let r := bt6GridClearance S K
  have hl1 : 1≤L := by dsimp [L]; linarith
  have hl0 : 0<L := by linarith
  have hs0 : 0<S := Real.rpow_pos_of_pos hl0 _
  obtain ⟨hn,hnlo,hnhi,hmlo,hmhi,hmL,hmS,hr,hrn,hrS,hncmp,hrcmp,hmcount,hmrad⟩ :=
    bt6_grid_choice L S K hK hLK hSK hSL
  intro root c x hroot hx t ht
  have hdeep := hg.2.2 M hmrad c x hx
  have hfinite := bt6_finite_bound N root c x ρ K M n r hρ hg.1 hg.2.1 hdeep hroot hL
    hK hn hstep hnlo hnhi hmlo hmhi hmL A S (L^(16*γ)) (L^(16*γ)) t
    hA hAS hAC hmS hη hηL hδ ht hbudget hr hrn hrS (by dsimp [S] at *; linarith)
  have hmain := bt6_main_bound L S A C K n r hK hl0 hs0 hA hncmp hrcmp
  have hfail := bt6_failure_absorption L A K M hl1 hK hAK hlog hmcount
  have hres : T*Real.exp (-(Real.log L)^2/2)≤T*Real.exp (-(Real.log L)^2/4) := by
    apply mul_le_mul_of_nonneg_left (Real.exp_le_exp.mpr ?_) hT.le
    nlinarith [sq_nonneg (Real.log L)]
  have hb : (finiteFieldLaw N).real (bt6BarrierEvent N root (torusDisk N c (ρ*(N.val:ℝ))) x
      A S (L^(16*γ)) (L^(16*γ)) t)≤
      D*A^5/(L*Real.sqrt S)+(8+T)*Real.exp (-(Real.log L)^2/4) := by
    refine hfinite.trans ?_
    change _+_+T*Real.exp (-(Real.log L)^2/2)≤_
    have hh := add_le_add (add_le_add hmain hfail) hres
    dsimp only [D] at *
    nlinarith only [hh]
  have hpow : A^5=L^(160*γ) := by
    dsimp [A]
    rw [← Real.rpow_mul_natCast hl0.le]
    congr 1
    ring
  rw [hpow] at hb
  have hb' : (finiteFieldLaw N).real (bt6BarrierEvent N root (torusDisk N c (ρ*(N.val:ℝ))) x
      A S (L^(16*γ)) (L^(16*γ)) t)≤
      F*L^(160*γ)/(L*Real.sqrt S)+F*Real.exp (-(Real.log L)^2/4) := by
    refine hb.trans (add_le_add ?_ ?_)
    · apply div_le_div_of_nonneg_right _ (by positivity)
      apply mul_le_mul_of_nonneg_right _ (by positivity)
      dsimp [F]
      linarith
    · apply mul_le_mul_of_nonneg_right _ (Real.exp_pos _).le
      dsimp [F]
      linarith
  have hout := ENNReal.ofReal_le_ofReal hb'
  rw [ofReal_measureReal] at hout
  exact hout

end TorusCoverTime.Blocks.B

