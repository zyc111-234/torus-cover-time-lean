import Solutions.Blocks.B.CenteredExponential
import Mathlib.Probability.Moments.Basic

/-! Finite independent sums with a bounded interval of quadratic MGF
control. Both tails and the optimization are proved explicitly. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

theorem independent_sum_exp_bound {Ω : Type*} [MeasurableSpace Ω]
    (μ : Measure Ω) [IsProbabilityMeasure μ] (m : ℕ) (X : Fin m → Ω → ℝ)
    (hX : ∀ i, Measurable (X i)) (hind : iIndepFun X μ) (V θ : ℝ)
    (hb : ∀ i, Integrable (fun ω => Real.exp (θ*X i ω)) μ ∧
      (∫ ω, Real.exp (θ*X i ω) ∂μ) ≤ Real.exp (V*θ^2)) :
    Integrable (fun ω => Real.exp (θ*(∑ i, X i ω))) μ ∧
      (∫ ω, Real.exp (θ*(∑ i, X i ω)) ∂μ) ≤ Real.exp ((m:ℝ)*V*θ^2) := by
  refine ⟨by simpa only [Finset.sum_apply] using
    hind.integrable_exp_mul_sum hX (s := Finset.univ) (fun i _ => (hb i).1), ?_⟩
  have he := hind.mgf_sum hX Finset.univ (t := θ)
  simp only [mgf, Finset.sum_apply] at he
  rw [he]
  calc
    _ ≤ ∏ _i : Fin m, Real.exp (V*θ^2) := Finset.prod_le_prod
      (fun i _ => mgf_nonneg (X := X i) (μ := μ) (t := θ)) (fun i _ => (hb i).2)
    _ = _ := by simp only [Finset.prod_const, Finset.card_univ, Fintype.card_fin, ← Real.exp_nat_mul]; congr 1; ring

theorem quadratic_chernoff_optimization (z A T : ℝ) (hz : 0 ≤ z) (hA : 0 < A) (hT : 0 < T) :
    ∃ θ : ℝ, 0 ≤ θ ∧ θ ≤ T ∧
      -θ*z+A*θ^2 ≤ -min (z^2/(4*A)) (T*z/2) := by
  let θ := min (z/(2*A)) T
  have ht0 : 0 ≤ θ := le_min (div_nonneg hz (by positivity)) hT.le
  have htT : θ ≤ T := min_le_right _ _
  refine ⟨θ, ht0, htT, ?_⟩
  have htz : θ ≤ z/(2*A) := min_le_left _ _
  have hb : A*θ ≤ z/2 := by
    have h := (le_div_iff₀ (by positivity : 0 < 2*A)).mp htz
    linarith
  have hquad : -θ*z+A*θ^2 ≤ -θ*z/2 := by
    nlinarith [mul_le_mul_of_nonneg_right hb ht0]
  apply hquad.trans
  by_cases hle : z/(2*A) ≤ T
  · have he : θ = z/(2*A) := min_eq_left hle
    rw [he]
    have heq : -(z/(2*A))*z/2 = -(z^2/(4*A)) := by field_simp; ring
    rw [heq]
    exact neg_le_neg (min_le_left _ _)
  · have he : θ = T := min_eq_right (le_of_not_ge hle)
    rw [he]
    have hh : min (z^2/(4*A)) (T*z/2) ≤ T*z/2 := min_le_right _ _
    linarith

theorem independent_bernstein_tail {Ω : Type*} [MeasurableSpace Ω]
    (μ : Measure Ω) [IsProbabilityMeasure μ] (m : ℕ) (hm : 0 < m)
    (X : Fin m → Ω → ℝ) (hX : ∀ i, Measurable (X i)) (hind : iIndepFun X μ)
    (V T : ℝ) (hV : 0 < V) (hT : 0 < T)
    (hmgf : ∀ θ : ℝ, |θ| ≤ T → ∀ i,
      Integrable (fun ω => Real.exp (θ*X i ω)) μ ∧
      (∫ ω, Real.exp (θ*X i ω) ∂μ) ≤ Real.exp (V*θ^2))
    (z : ℝ) (hz : 0 ≤ z) :
    μ.real {ω | z < |∑ i, X i ω|} ≤
      2*Real.exp (-min (z^2/(4*(m:ℝ)*V)) (T*z/2)) := by
  have hA : 0 < (m:ℝ)*V := mul_pos (by exact_mod_cast hm) hV
  obtain ⟨θ,ht0,htT,hopt⟩ := quadratic_chernoff_optimization z ((m:ℝ)*V) T hz hA hT
  have hp := independent_sum_exp_bound μ m X hX hind V θ (hmgf θ (by rw [abs_of_nonneg ht0]; exact htT))
  have hn := independent_sum_exp_bound μ m X hX hind V (-θ) (hmgf (-θ) (by rw [abs_neg, abs_of_nonneg ht0]; exact htT))
  let E := Real.exp (-min (z^2/(4*(m:ℝ)*V)) (T*z/2))
  have hu : μ.real {ω | z ≤ ∑ i, X i ω} ≤ E := by
    have hc := measure_ge_le_exp_mul_mgf z ht0 hp.1
    apply hc.trans
    calc
      _ ≤ Real.exp (-θ*z)*Real.exp ((m:ℝ)*V*θ^2) :=
        mul_le_mul_of_nonneg_left hp.2 (Real.exp_pos _).le
      _ = Real.exp (-θ*z+((m:ℝ)*V)*θ^2) := by rw [← Real.exp_add]
      _ ≤ E := by apply Real.exp_le_exp.mpr; simpa only [mul_assoc] using hopt
  have hl : μ.real {ω | (∑ i, X i ω) ≤ -z} ≤ E := by
    have hc := measure_le_le_exp_mul_mgf (-z) (neg_nonpos.mpr ht0) hn.1
    apply hc.trans
    calc
      _ ≤ Real.exp (-(-θ)*(-z))*Real.exp ((m:ℝ)*V*(-θ)^2) :=
        mul_le_mul_of_nonneg_left hn.2 (Real.exp_pos _).le
      _ = Real.exp (-θ*z+((m:ℝ)*V)*θ^2) := by rw [← Real.exp_add]; congr 1; ring
      _ ≤ E := by apply Real.exp_le_exp.mpr; simpa only [mul_assoc] using hopt
  have hset : {ω | z < |∑ i, X i ω|} ⊆
      {ω | z ≤ ∑ i, X i ω} ∪ {ω | (∑ i, X i ω) ≤ -z} := by
    intro ω hω
    change z < |∑ i, X i ω| at hω
    rcases lt_abs.mp hω with hh | hh
    · exact Or.inl hh.le
    · right
      change (∑ i, X i ω) ≤ -z
      linarith
  have hμ := measureReal_mono (μ := μ) hset
  have hunion := measureReal_union_le {ω | z ≤ ∑ i, X i ω} {ω | (∑ i, X i ω) ≤ -z} (μ := μ)
  change _ ≤ 2*E
  linarith

end TorusCoverTime.Blocks.B
