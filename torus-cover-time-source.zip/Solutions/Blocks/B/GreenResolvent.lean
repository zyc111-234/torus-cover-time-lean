import Solutions.Blocks.B.MassiveGreen

/-! Exact resolvent identities and quantitative comparison with the ordinary
Dirichlet Green operator, on the same finite domain and generator. -/

noncomputable section
open Classical
namespace TorusCoverTime.Blocks.B

theorem domainGreen_resolvent_identity (N : Size) (D : Finset (Vertex N))
    (hD : D ≠ Finset.univ) (b : Vertex N → ℝ) (hb : ∀ x ∈ D, -generator N b x = 1)
    (μ : ℝ) (hμ : 0 < μ) (x y : Vertex N) :
    domainGreenFromBarrier N D b x y - massiveGreen N D μ hμ x y =
      μ * ∑ z, domainGreenFromBarrier N D b x z * massiveGreen N D μ hμ z y := by
  let U := (fun z => domainGreenFromBarrier N D b z y) - (fun z => massiveGreen N D μ hμ z y)
  have hbU (z : Vertex N) (hz : z ∉ D) : U z = 0 := by
    simp only [U, Pi.sub_apply, domainGreenFromBarrier_boundary N D b z y hz,
      massiveGreen_boundary N D μ hμ z y hz, sub_self]
  have hgU (z : Vertex N) (hz : z ∈ D) : -generator N U z = μ * massiveGreen N D μ hμ z y := by
    have hg := domainGreenFromBarrier_generator N D b hb z y hz
    have hm := massiveGreen_generator N D μ hμ z y hz
    dsimp [U]
    rw [generator_sub]
    linarith
  have he := congrFun (domainGreenFromBarrier_solution N D hD b hb
    (fun z => μ * massiveGreen N D μ hμ z y) U hbU hgU) x
  change domainGreenFromBarrier N D b x y - massiveGreen N D μ hμ x y = _ at he
  rw [he, Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro z _
  ring

theorem massiveGreen_le_domainGreen (N : Size) (D : Finset (Vertex N))
    (hD : D ≠ Finset.univ) (b : Vertex N → ℝ) (hb : ∀ x ∈ D, -generator N b x = 1)
    (μ : ℝ) (hμ : 0 < μ) (x y : Vertex N) :
    massiveGreen N D μ hμ x y ≤ domainGreenFromBarrier N D b x y := by
  apply sub_nonneg.mp
  rw [domainGreen_resolvent_identity N D hD b hb μ hμ x y]
  exact mul_nonneg hμ.le (Finset.sum_nonneg fun z _ =>
    mul_nonneg (domainGreenFromBarrier_nonneg_all N D b hb x z)
      (massiveGreen_nonneg N D μ hμ z y))

theorem massiveGreen_lower (N : Size) (D : Finset (Vertex N))
    (hD : D ≠ Finset.univ) (b : Vertex N → ℝ) (hb : ∀ x ∈ D, -generator N b x = 1)
    (μ : ℝ) (hμ : 0 < μ) (x y : Vertex N) :
    domainGreenFromBarrier N D b x y -
      μ * (∑ z, domainGreenFromBarrier N D b x z * domainGreenFromBarrier N D b z y) ≤
    massiveGreen N D μ hμ x y := by
  have he := domainGreen_resolvent_identity N D hD b hb μ hμ x y
  have hs := Finset.sum_le_sum (s := (Finset.univ : Finset (Vertex N))) fun z _ =>
    mul_le_mul_of_nonneg_left (massiveGreen_le_domainGreen N D hD b hb μ hμ z y)
      (domainGreenFromBarrier_nonneg_all N D b hb x z)
  have hm := mul_le_mul_of_nonneg_left hs hμ.le
  linarith

theorem massiveGreen_antitone_rate (N : Size) (D : Finset (Vertex N)) (μ ν : ℝ)
    (hμ : 0 < μ) (hν : 0 < ν) (hμν : μ ≤ ν) (x y : Vertex N) :
    massiveGreen N D ν hν x y ≤ massiveGreen N D μ hμ x y := by
  have hn := massive_maximum_principle N D μ hμ
    ((fun z => massiveGreen N D μ hμ z y) - (fun z => massiveGreen N D ν hν z y)) (by
      intro z hz
      simp only [Pi.sub_apply, massiveGreen_boundary N D μ hμ z y hz,
        massiveGreen_boundary N D ν hν z y hz, sub_self, le_refl]) (by
      intro z hz
      have hm := massiveGreen_generator N D μ hμ z y hz
      have hv := massiveGreen_generator N D ν hν z y hz
      have hp := mul_nonneg (sub_nonneg.mpr hμν) (massiveGreen_nonneg N D ν hν z y)
      rw [Pi.sub_apply, generator_sub]
      nlinarith) x
  exact sub_nonneg.mp hn

theorem massiveGreen_mono_domain (N : Size) (D E : Finset (Vertex N)) (hDE : D ⊆ E)
    (μ : ℝ) (hμ : 0 < μ) (x y : Vertex N) :
    massiveGreen N D μ hμ x y ≤ massiveGreen N E μ hμ x y := by
  have hn := massive_maximum_principle N D μ hμ
    ((fun z => massiveGreen N E μ hμ z y) - (fun z => massiveGreen N D μ hμ z y)) (by
      intro z hz
      simp only [Pi.sub_apply, massiveGreen_boundary N D μ hμ z y hz, sub_zero]
      exact massiveGreen_nonneg N E μ hμ z y) (by
      intro z hz
      have hD := massiveGreen_generator N D μ hμ z y hz
      have hE := massiveGreen_generator N E μ hμ z y (hDE hz)
      rw [Pi.sub_apply, generator_sub]
      linarith) x
  exact sub_nonneg.mp hn

theorem harmonic_average_from_green (N : Size) (D : Finset (Vertex N))
    (hD : D ≠ Finset.univ) (b : Vertex N → ℝ) (hb : ∀ x ∈ D, -generator N b x = 1)
    (μ : ℝ) (hμ : 0 < μ) (K : Finset (Vertex N)) (a c : ℝ)
    (f : Vertex N → ℝ) (hf : ∀ x, 0 ≤ f x) (hg : ∀ x ∈ D, generator N f x = 0)
    (x : Vertex N) (hlo : ∀ y ∈ K, a ≤ domainGreenFromBarrier N D b x y)
    (hconv : ∀ y ∈ K,
      (∑ z, domainGreenFromBarrier N D b x z * domainGreenFromBarrier N D b z y) ≤ c) :
    μ * (a - μ*c) * (∑ y ∈ K, f y) ≤ f x := by
  have hkernel (y : Vertex N) (hy : y ∈ K) : a - μ*c ≤ massiveGreen N D μ hμ x y := by
    have he := massiveGreen_lower N D hD b hb μ hμ x y
    have hm := mul_le_mul_of_nonneg_left (hconv y hy) hμ.le
    linarith [hlo y hy]
  have hs : (a-μ*c) * (∑ y ∈ K, f y) ≤ ∑ y, massiveGreen N D μ hμ x y * f y := by
    rw [Finset.mul_sum]
    apply (Finset.sum_le_sum fun y hy => mul_le_mul_of_nonneg_right (hkernel y hy) (hf y)).trans
    exact Finset.sum_le_sum_of_subset_of_nonneg (Finset.subset_univ K)
      (fun y _ _ => mul_nonneg (massiveGreen_nonneg N D μ hμ x y) (hf y))
  calc
    _ = μ * ((a-μ*c) * (∑ y ∈ K, f y)) := by ring
    _ ≤ μ * (∑ y, massiveGreen N D μ hμ x y * f y) := mul_le_mul_of_nonneg_left hs hμ.le
    _ ≤ f x := harmonic_massive_average N D μ hμ f hf hg x

end TorusCoverTime.Blocks.B
