import Solutions.Blocks.B.BT7FinitePointBound

noncomputable section
open Filter
namespace TorusCoverTime.Blocks.B

theorem bt7_error_parameters (γ ε C₀ C₁ : ℝ) (hγ : 0<γ) (hγhi : 32*γ<1/10)
    (hε : 0≤ε) (hC₀ : 0≤C₀) (hC₁ : 0≤C₁) :
    ∀ᶠ N : Size in atTop,
      (logSize N)^(32*γ)≤(logSize N)^(1/10:ℝ) ∧ 0≤bt7EndpointWidth N ε C₀ ∧
      ε*Real.log (logSize N)+C₀≤(logSize N)^(16*γ) ∧
      C₁*(logSize N)^(8*γ)+(logSize N)^(12*γ)+dirichletMassProfileBound≤(logSize N)^(16*γ) ∧
      bt7EndpointWidth N ε C₀+(logSize N)^(12*γ)≤(logSize N)^(16*γ) := by
  have ha : 0<16*γ := by linarith
  have h1 := bt6_polylog_subpower (16*γ) 0 0 0 ε C₀ ha ha
  have h2 := bt6_polylog_subpower (16*γ) (12*γ) (C₁+1) 0 0 dirichletMassProfileBound ha (by linarith)
  have h3 := bt6_polylog_subpower (16*γ) (12*γ) 1 0 ε (2*C₀+dirichletMassProfileBound) ha (by linarith)
  filter_upwards [blockB_logSize_tendsto.eventually_ge_atTop 1,
    blockB_logSize_tendsto.eventually h1,blockB_logSize_tendsto.eventually h2,blockB_logSize_tendsto.eventually h3]
    with N hL hη hδ hb
  have hg : 0<g := by unfold g; positivity
  have hQ : 0≤dirichletMassProfileBound := by unfold dirichletMassProfileBound; positivity
  have hpow := Real.rpow_le_rpow_of_exponent_le hL (show 8*γ≤12*γ by linarith)
  simp only [zero_mul,zero_add,add_zero,one_mul] at hη hδ hb
  refine ⟨Real.rpow_le_rpow_of_exponent_le hL hγhi.le,?_,hη,?_,?_⟩
  · unfold bt7EndpointWidth
    positivity [Real.log_nonneg hL]
  · nlinarith only [hδ,mul_le_mul_of_nonneg_left hpow hC₁]
  · unfold bt7EndpointWidth
    linarith

theorem bt7_geometric_parameters (ρ γ : ℝ) (hρ : 0<ρ) (hρhi : ρ<1/4) (hγ : 0<γ) :
    ∀ᶠ N : Size in atTop,
      4*diskHarnackRadiusThreshold≤ρ*(N.val:ℝ) ∧ 2*(ρ*(N.val:ℝ)+1)<N.val ∧
      8*(bt6ClockError ρ+1)≤logSize N ∧
      ∀ q : ℕ, (logSize N)^(32*γ)≤(q:ℝ) → (q:ℝ)≤logSize N-(logSize N)^(32*γ) →
        2*(Real.exp ((q:ℝ)+1)+1)<N.val ∧
        Real.exp ((q:ℝ)+1)+1≤(ρ*(N.val:ℝ)/4)/(4*diskGreenInnerScale) := by
  have hscale : 0<diskGreenInnerScale := by linarith [diskGreenInnerScale_ge_four]
  let σ := ρ/(8*diskGreenInnerScale)
  have hσ : 0<σ := by dsimp [σ]; positivity
  have hσρ : σ≤ρ := by dsimp [σ]; apply (div_le_iff₀ (by positivity)).mpr; nlinarith [diskGreenInnerScale_ge_four]
  have hσhi : σ<1/4 := hσρ.trans_lt hρhi
  obtain ⟨K,hK,hstep,hgeom⟩ := bt6_exists_step σ hσ
  have hN : Tendsto (fun N : Size => (N.val:ℝ)) atTop atTop := tendsto_natCast_atTop_atTop.comp blockB_size_nat_tendsto
  filter_upwards [bt6_macroscopic_geometry σ K hσ hσhi hgeom,
    hN.eventually_ge_atTop (4*diskHarnackRadiusThreshold/ρ),hN.eventually_gt_atTop 4,
    blockB_logSize_tendsto.eventually_ge_atTop (8*(bt6ClockError ρ+1)),
    ((tendsto_rpow_atTop (by linarith : 0<32*γ)).comp blockB_logSize_tendsto).eventually_ge_atTop (K:ℝ)]
    with N hg hn hn4 hL hA
  change (K:ℝ)≤(logSize N)^(32*γ) at hA
  have hn0 : (0:ℝ)<N.val := by linarith
  refine ⟨?_,?_,hL,?_⟩
  · have hh := (div_le_iff₀ hρ).mp hn
    nlinarith only [hh]
  · nlinarith [mul_lt_mul_of_pos_right hρhi hn0]
  · intro q _ hq
    let c : Vertex N := 0
    have hh := hg.2.2 q (by linarith) c c (by rw [periodicDistance_self_zero]; positivity)
    rw [periodicDistance_self_zero,zero_add] at hh
    refine ⟨?_,?_⟩
    · nlinarith [hg.2.1,hg.1]
    · convert hh using 1
      dsimp [σ]
      ring

end TorusCoverTime.Blocks.B
