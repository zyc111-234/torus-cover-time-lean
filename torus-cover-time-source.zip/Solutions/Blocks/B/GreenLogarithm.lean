import Solutions.Blocks.B.QuadraticFourierCore
import Solutions.Blocks.B.GreenKernelSpatial

/-! The finite-torus Green function has its precise logarithmic spatial
main term with a size-independent bounded error. -/

noncomputable section
open scoped BigOperators
namespace TorusCoverTime.Blocks.B

theorem spatial_frequency_cutoff (N : Size) (T : ℝ) (hT : 1 ≤ T) (hTN : T ≤ N.val) :
    ∃ m : ℕ, 0 < m ∧ m ≤ (N.val - 1) / 2 ∧ (m : ℝ) ≤ T ∧ T ≤ 4 * (m : ℝ) := by
  let m := min (Nat.floor T) ((N.val - 1) / 2)
  have hf : 0 < Nat.floor T := Nat.floor_pos.mpr hT
  have hM : 0 < (N.val - 1) / 2 := by have := N.property; omega
  have hN4 : (N.val : ℝ) ≤ 4 * (((N.val - 1) / 2 : ℕ) : ℝ) := by
    exact_mod_cast (show N.val ≤ 4 * ((N.val - 1) / 2) by have := N.property; omega)
  refine ⟨m, lt_min hf hM, min_le_right _ _, ?_, ?_⟩
  · exact (Nat.cast_le.mpr (min_le_left _ _)).trans (Nat.floor_le (zero_le_one.trans hT))
  · rcases le_total (Nat.floor T) ((N.val - 1) / 2) with h | h
    · dsimp [m]
      rw [min_eq_left h]
      have hlt := Nat.lt_floor_add_one T
      have hf1 : (1 : ℝ) ≤ Nat.floor T := by exact_mod_cast hf
      linarith
    · dsimp [m]
      rw [min_eq_right h]
      exact hTN.trans hN4

theorem quadratic_cutoff_phase_bound (n u d m : ℝ) (hn : 0 < n) (hu : 0 < u)
    (hd : 0 ≤ d) (hdU : d ≤ 2 * u) (hm : 1 ≤ m) (hmN : m ≤ n / u) :
    (2*m+1)^2 * (2 * Real.pi^2 * d^2 / n^2) ≤ 72 * Real.pi^2 := by
  have hmu := (le_div_iff₀ hu).mp hmN
  have hmd : (2*m+1)*d ≤ 6*n := by
    calc
      _ ≤ (3*m)*d := mul_le_mul_of_nonneg_right (by linarith) hd
      _ ≤ (3*m)*(2*u) := mul_le_mul_of_nonneg_left hdU (by linarith)
      _ = 6*(m*u) := by ring
      _ ≤ 6*n := mul_le_mul_of_nonneg_left hmu (by norm_num)
  have hs := pow_le_pow_left₀ (by positivity : 0 ≤ (2*m+1)*d) hmd 2
  have hs' := mul_le_mul_of_nonneg_left hs (by positivity : 0 ≤ 2 * Real.pi^2)
  rw [← mul_div_assoc]
  apply (div_le_iff₀ (sq_pos_of_pos hn)).mpr
  nlinarith

def quadraticLogErrorConstant : ℝ :=
  40 + 72 * Real.pi^2 + (32 + 2 * Real.pi) + 2 * Real.pi * Real.log 8

theorem quadraticLogErrorConstant_pos : 0 < quadraticLogErrorConstant := by
  have hl : 0 < Real.log 8 := Real.log_pos (by norm_num)
  unfold quadraticLogErrorConstant
  positivity

theorem quadraticFourierSum_log_error_coordinate (N : Size) (z : Vertex N) (hz : z.1 ≠ 0)
    (hdom : periodicDistance z 0 ≤ 2 * coordinateDistance z.1 0) :
    |(quadraticFourierSum N z).re - 2 * Real.pi * Real.log ((N.val : ℝ) / periodicDistance z 0)| ≤
      quadraticLogErrorConstant := by
  let u := coordinateDistance z.1 0
  let d := periodicDistance z 0
  let T := (N.val : ℝ) / u
  have hu1 : 1 ≤ u := coordinateDistance_nonzero_ge_one N z.1 hz
  have hu : 0 < u := zero_lt_one.trans_le hu1
  have hN : 0 < (N.val : ℝ) := zero_lt_one.trans (size_real_gt_one N)
  have huN : u ≤ N.val := by have := (coordinateDistance_zero_bounds N z.1).2; dsimp [u]; linarith
  have hT : 1 ≤ T := (one_le_div hu).mpr huN
  have hTN : T ≤ N.val := (div_le_self hN.le hu1)
  obtain ⟨m, hm0, hm, hmT, hTm⟩ := spatial_frequency_cutoff N T hT hTN
  have hm1 : (1 : ℝ) ≤ m := by exact_mod_cast hm0
  have hmp : 0 < (m : ℝ) := by exact_mod_cast hm0
  have hd0 : 0 < d := by
    have hxy : z ≠ 0 := fun he => hz (congrArg Prod.fst he)
    exact zero_lt_one.trans_le (periodicDistance_nonzero_ge_one N z hxy)
  have hud : u ≤ d := by
    have hq : d^2 = u^2 + coordinateDistance z.2 0 ^ 2 := Real.sq_sqrt (by positivity)
    nlinarith [sq_nonneg (coordinateDistance z.2 0)]
  have ht : 10 * T / ((m : ℝ) + 1) ≤ 40 := by
    apply (div_le_iff₀ (by positivity : 0 < (m : ℝ) + 1)).mpr
    linarith
  have hp := quadratic_cutoff_phase_bound (N.val : ℝ) u d m hN hu hd0.le hdom hm1 hmT
  have hc := quadraticFourierSum_cutoff_error N m hm0 hm z hz
  change |(quadraticFourierSum N z).re - 2 * Real.pi * Real.log m| ≤
      10*T/((m : ℝ)+1) + (2*(m : ℝ)+1)^2 * (2*Real.pi^2*d^2/(N.val : ℝ)^2) +
      (32+2*Real.pi) at hc
  have hc' : |(quadraticFourierSum N z).re - 2 * Real.pi * Real.log m| ≤
      40 + 72*Real.pi^2 + (32+2*Real.pi) := hc.trans (by linarith)
  have hscale0 : 0 < (N.val : ℝ) / d := div_pos hN hd0
  have hl1 : (N.val : ℝ) / d ≤ 8 * (m : ℝ) := by
    have hle : (N.val : ℝ) / d ≤ T := div_le_div_of_nonneg_left hN.le hu hud
    linarith
  have hl2 : (m : ℝ) ≤ 8 * ((N.val : ℝ) / d) := by
    have hTd : T ≤ 2 * ((N.val : ℝ) / d) := by
      change (N.val : ℝ) / u ≤ _
      rw [← mul_div_assoc]
      apply (div_le_div_iff₀ hu hd0).mpr
      have hh := mul_le_mul_of_nonneg_left hdom hN.le
      dsimp [u, d] at hh ⊢
      nlinarith
    linarith
  have hl1' := Real.log_le_log hscale0 hl1
  have hl2' := Real.log_le_log hmp hl2
  rw [Real.log_mul (by norm_num) hmp.ne'] at hl1'
  rw [Real.log_mul (by norm_num) hscale0.ne'] at hl2'
  have hlog : |Real.log m - Real.log ((N.val : ℝ) / d)| ≤ Real.log 8 := by
    rw [abs_le]
    constructor <;> linarith
  have hlogmul : |2*Real.pi*Real.log m - 2*Real.pi*Real.log ((N.val : ℝ)/d)| ≤
      2*Real.pi*Real.log 8 := by
    rw [← mul_sub, abs_mul, abs_of_pos (by positivity : 0 < 2*Real.pi)]
    exact mul_le_mul_of_nonneg_left hlog (by positivity)
  calc
    _ = |((quadraticFourierSum N z).re - 2*Real.pi*Real.log m) +
        (2*Real.pi*Real.log m - 2*Real.pi*Real.log ((N.val : ℝ)/d))| := by congr 1; ring
    _ ≤ _ := abs_add_le _ _
    _ ≤ _ := add_le_add hc' hlogmul

theorem quadraticFourierSum_log_error (N : Size) (z : Vertex N) (hz : z ≠ 0) :
    |(quadraticFourierSum N z).re - 2 * Real.pi * Real.log ((N.val : ℝ) / periodicDistance z 0)| ≤
      quadraticLogErrorConstant := by
  have hd := periodicDistance_nonzero_ge_one N z hz
  have hsum := periodicDistance_le_coordinate_sum N z
  have hz0 : coordinateDistance (0 : ZMod N.val) 0 = 0 := by simp [coordinateDistance]
  rcases le_total (coordinateDistance z.2 0) (coordinateDistance z.1 0) with hc | hc
  · have hz1 : z.1 ≠ 0 := by intro h; rw [h, hz0] at hc hsum; linarith
    exact quadraticFourierSum_log_error_coordinate N z hz1 (by linarith)
  · have hz2 : z.2 ≠ 0 := by intro h; rw [h, hz0] at hc hsum; linarith
    have hdS : periodicDistance z.swap 0 = periodicDistance z 0 := by
      unfold periodicDistance
      simp only [Prod.fst_swap, Prod.snd_swap, Prod.fst_zero, Prod.snd_zero, add_comm]
    have h := quadraticFourierSum_log_error_coordinate N z.swap hz2
      (by rw [hdS]; simp only [Prod.fst_swap]; linarith)
    rw [quadraticFourierSum_swap, hdS] at h
    exact h

def greenLogErrorConstant : ℝ := Real.pi^2 / 12 + quadraticLogErrorConstant / Real.pi^2

theorem greenLogErrorConstant_pos : 0 < greenLogErrorConstant := by
  have := quadraticLogErrorConstant_pos
  unfold greenLogErrorConstant
  positivity

theorem greenKernel_log_error (N : Size) (x y : Vertex N) (hxy : x ≠ y) :
    |greenKernel N x y - g * Real.log ((N.val : ℝ) / periodicDistance x y)| ≤
      greenLogErrorConstant := by
  have h := quadraticFourierSum_log_error N (x-y) (sub_ne_zero.mpr hxy)
  rw [periodicDistance_sub_zero] at h
  have hp := sq_pos_of_pos Real.pi_pos
  have hq : |(quadraticFourierSum N (x-y)).re / Real.pi^2 -
      g * Real.log ((N.val : ℝ) / periodicDistance x y)| ≤ quadraticLogErrorConstant / Real.pi^2 := by
    have he : (quadraticFourierSum N (x-y)).re / Real.pi^2 - g * Real.log ((N.val : ℝ) / periodicDistance x y) =
        ((quadraticFourierSum N (x-y)).re - 2*Real.pi*Real.log ((N.val : ℝ) / periodicDistance x y)) / Real.pi^2 := by
      unfold g
      field_simp
    rw [he, abs_div, abs_of_pos hp]
    exact div_le_div_of_nonneg_right h hp.le
  calc
    _ = |(greenKernel N x y - (quadraticFourierSum N (x-y)).re / Real.pi^2) +
        ((quadraticFourierSum N (x-y)).re / Real.pi^2 - g*Real.log ((N.val : ℝ)/periodicDistance x y))| := by congr 1; ring
    _ ≤ _ := abs_add_le _ _
    _ ≤ _ := add_le_add (greenKernel_quadratic_error N x y) hq

theorem green_increment_log_error (N : Size) (x y : Vertex N) (hxy : x ≠ y) :
    |(greenKernel N x x - greenKernel N x y) - g * Real.log (periodicDistance x y)| ≤
      greenDiagonalErrorConstant + greenLogErrorConstant := by
  have hd := greenDiagonal_log_error N
  have hg := greenKernel_log_error N x y hxy
  have hn : (N.val : ℝ) ≠ 0 := (zero_lt_one.trans (size_real_gt_one N)).ne'
  have hp : 0 < periodicDistance x y := by
    have h := periodicDistance_nonzero_ge_one N (x-y) (sub_ne_zero.mpr hxy)
    rw [periodicDistance_sub_zero] at h
    linarith
  rw [Real.log_div hn hp.ne'] at hg
  rw [greenKernel_diagonal]
  calc
    _ = |(greenDiagonal N - g * logSize N) -
        (greenKernel N x y - g * (Real.log (N.val : ℝ) - Real.log (periodicDistance x y)))| := by
      unfold logSize
      congr 1
      ring
    _ ≤ _ := abs_sub _ _
    _ ≤ _ := add_le_add hd hg

end TorusCoverTime.Blocks.B
