import Solutions.Blocks.B.TraversalVertexScan

/-! A nonempty path entirely in the inner set has exactly the action of one inner vertex. -/
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B


theorem traversalPhaseStep_inner_eq (N : Size) (I O : Finset (Vertex N)) (hIO : I ⊆ O)
    (x c : Vertex N) (hx : x ∈ I) (hc : c ∈ I) (k : ℕ) :
    traversalPhaseStep N I O k x = traversalPhaseStep N I O k c := by
  rw [traversalPhaseStep_inner N I O hIO k x hx,traversalPhaseStep_inner N I O hIO k c hc]

theorem traversalVertexScan_inner_after_entry (N : Size) (I O : Finset (Vertex N)) (hIO : I ⊆ O)
    (c : Vertex N) (hc : c ∈ I) (xs : List (Vertex N)) (hxs : ∀ x ∈ xs, x ∈ I) (k : ℕ) :
    traversalVertexScan N I O xs (traversalPhaseStep N I O k c) = traversalPhaseStep N I O k c := by
  induction xs with
  | nil => rfl
  | cons x xs ih =>
    rw [traversalVertexScan_cons,traversalPhaseStep_inner_eq N I O hIO x c
      (hxs x (by simp)) hc,traversalPhaseStep_idem N I O hIO]
    exact ih (fun y hy => hxs y (by simp [hy]))

theorem traversalVertexScan_inner (N : Size) (I O : Finset (Vertex N)) (hIO : I ⊆ O)
    (c : Vertex N) (hc : c ∈ I) (xs : List (Vertex N)) (hne : xs ≠ [])
    (hxs : ∀ x ∈ xs, x ∈ I) (k : ℕ) :
    traversalVertexScan N I O xs k = traversalPhaseStep N I O k c := by
  cases xs with
  | nil => exact False.elim (hne rfl)
  | cons x xs =>
    rw [traversalVertexScan_cons,traversalPhaseStep_inner_eq N I O hIO x c (hxs x (by simp)) hc]
    exact traversalVertexScan_inner_after_entry N I O hIO c hc xs (fun y hy => hxs y (by simp [hy])) k

theorem traversalVertexScan_replace_inner (N : Size) (I O : Finset (Vertex N)) (hIO : I ⊆ O)
    (c : Vertex N) (hc : c ∈ I) (xs : List (Vertex N)) (hne : xs ≠ [])
    (hxs : ∀ x ∈ xs, x ∈ I) (before after : List (Vertex N)) (k : ℕ) :
    traversalVertexScan N I O (before++xs++after) k =
      traversalVertexScan N I O (before++[c]++after) k := by
  simp only [traversalVertexScan_append,traversalVertexScan_inner N I O hIO c hc xs hne hxs,
    traversalVertexScan_cons,traversalVertexScan_nil]


end TorusCoverTime.Blocks.B

