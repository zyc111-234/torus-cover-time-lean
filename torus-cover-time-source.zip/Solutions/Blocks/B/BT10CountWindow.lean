import Solutions.Blocks.B.BT10WordWindow
import Solutions.Blocks.B.R8PairRootSum

noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

def bt10PairEvent (N : Size) (x y root : Vertex N) (γ q U : ℝ) (m : ℕ) : Set (WalkSample × ℝ) :=
  {z | z∈r8ExactCountEvent N x root γ q m ∧ (localTime N root z.1 z.2 x+localTime N root z.1 z.2 y)/g≤U}

def bt10PairMass (N : Size) (x y : Vertex N) (γ q U : ℝ) (m : ℕ) (l r : ℝ) : ℝ≥0∞ :=
  r7LoopEventMass N (fun root => bt10PairEvent N x y root γ q U m) l r

theorem bt10PairEvent_measurable (N : Size) (x y root : Vertex N) (γ q U : ℝ) (m : ℕ) :
    MeasurableSet (bt10PairEvent N x y root γ q U m) :=
  (r8ExactCountEvent_measurable N x root γ q m).inter
    (measurableSet_le (((localTime_joint_measurable N root x).add
      (localTime_joint_measurable N root y)).div_const g) measurable_const)

theorem bt10_pair_mass_root_sum (N : Size) (x y : Vertex N) (γ q U : ℝ) (m : ℕ) (l r : ℝ) :
    bt10PairMass N x y γ q U m l r =
      (ENNReal.ofReal (timeScale N))⁻¹*∑ root : Vertex N,
        if (N.val:ℝ)*Real.exp (-((logSize N)^(16*γ))/2)≤periodicDistance x root then
          physicalCountWindow N (torusDisk N x (Real.exp (q+q^γ)))
            (torusDisk N x (Real.exp (q+2*q^γ))) root m (bt10SoftTest N x y root U) l r else 0 := by
  unfold bt10PairMass r7LoopEventMass
  congr 1
  apply Finset.sum_congr rfl
  intro root _
  by_cases hfar : (N.val:ℝ)*Real.exp (-((logSize N)^(16*γ))/2)≤periodicDistance x root
  · rw [if_pos hfar]
    apply lintegral_congr
    intro ω
    apply lintegral_congr
    intro t
    simp only [r7LoopEventTest,bt10PairEvent,r8ExactCountEvent,mem_setOf_eq,hfar,true_and,bt10SoftTest]
    split_ifs <;> simp_all
  · simp only [if_neg hfar,r7LoopEventTest,bt10PairEvent,r8ExactCountEvent,mem_setOf_eq,
      hfar,false_and,if_false,lintegral_zero]

theorem bt10_pair_count_window (hWalk : WalkModelRegular) (γ U : ℝ)
    (hγ : 0<γ) (hγ1 : γ<1) (hU : 0≤U) :
    ∃ K : ℝ, 0<K ∧ ∀ᶠ N : Size in atTop, ∀ x y : Vertex N, ∀ m : ℕ, ∀ q : ℝ,
      (logSize N)^(16*γ)≤q → q≤logSize N-(logSize N)^(16*γ) →
      (m:ℝ)≤(logSize N)^4+1 → x≠y → q-2≤Real.log (periodicDistance x y) →
      Real.log (periodicDistance x y)<q → ∀ l r : ℝ,
      bt10PairMass N x y γ q U m l r ≤
        bt10PairFactor γ K q m*r8ExactCountMass N x γ q m (l-r7WindowStep N γ m) (r+r7WindowStep N γ m)+
        (ENNReal.ofReal (timeScale N))⁻¹*(Fintype.card (Vertex N):ℝ≥0∞)*
          (ENNReal.ofReal (r-l)*ENNReal.ofReal (Real.exp (-Real.exp ((logSize N)^(16*γ)/2)))) := by
  obtain ⟨K,hK,hword⟩ := bt10_word_window_bound hWalk γ U hγ hγ1 hU
  refine ⟨K,hK,?_⟩
  filter_upwards [hword,r7_far_root_outside γ hγ] with N hword hout
  intro x y m q hq hqL hm hxy hlo hhi l r
  let ρ := bt10PairFactor γ K q m
  let ε := ENNReal.ofReal (r-l)*ENNReal.ofReal (Real.exp (-Real.exp ((logSize N)^(16*γ)/2)))
  let I := torusDisk N x (Real.exp (q+q^γ))
  let O := torusDisk N x (Real.exp (q+2*q^γ))
  have hq0 := (Real.rpow_nonneg (logSize_pos N).le (16*γ)).trans hq
  have hIO : I⊆O := torusDisk_subset N x _ _ (Real.exp_le_exp.mpr (by linarith [Real.rpow_nonneg hq0 γ]))
  have hI : I.Nonempty := torusDisk_nonempty N x _ (Real.exp_pos _)
  have hb (root : Vertex N) (hfar : (N.val:ℝ)*Real.exp (-((logSize N)^(16*γ))/2)≤periodicDistance x root) :
      physicalCountWindow N I O root m (bt10SoftTest N x y root U) l r ≤
        ρ*r8OuterCountWindow N x root γ q m (l-r7WindowStep N γ m) (r+r7WindowStep N γ m)+ε := by
    have hr := hout x root q hq0 hqL hfar
    exact physicalCountWindow_of_word_bound N I O hIO hI root hr m _ _ l r _ _ _ _
      (fun w hw => hword x y root m w q hq hqL hm hxy hlo hhi hr hw l r)
  rw [bt10_pair_mass_root_sum,← r8OuterCountWindow_root_sum]
  have hsum : (∑ root : Vertex N, if (N.val:ℝ)*Real.exp (-((logSize N)^(16*γ))/2)≤periodicDistance x root then
      physicalCountWindow N I O root m (bt10SoftTest N x y root U) l r else 0) ≤
      ρ*(∑ root : Vertex N, if (N.val:ℝ)*Real.exp (-((logSize N)^(16*γ))/2)≤periodicDistance x root then
        r8OuterCountWindow N x root γ q m (l-r7WindowStep N γ m) (r+r7WindowStep N γ m) else 0)+
      (Fintype.card (Vertex N):ℝ≥0∞)*ε := by
    calc
      _ ≤ ∑ root : Vertex N, (ρ*(if (N.val:ℝ)*Real.exp (-((logSize N)^(16*γ))/2)≤periodicDistance x root then
          r8OuterCountWindow N x root γ q m (l-r7WindowStep N γ m) (r+r7WindowStep N γ m) else 0)+ε) := by
        apply Finset.sum_le_sum
        intro root _
        split_ifs with hfar
        · exact hb root hfar
        · simp
      _ = _ := by rw [Finset.sum_add_distrib,← Finset.mul_sum]; simp [nsmul_eq_mul]
  exact (mul_le_mul' le_rfl hsum).trans_eq (by dsimp [ρ,ε]; ring)

end TorusCoverTime.Blocks.B
