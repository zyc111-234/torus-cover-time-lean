import Solutions.Blocks.B.GaussianClockBounds
import Solutions.Blocks.C.C4.Base.IndependentEndpointSmoothing

/-! Two-end interval smoothing for the exact finite path.  The reversed right
path is reflected in its definition, so both retained conditions are upper
barriers. The independent middle is joint-independent of both end vectors. -/

noncomputable section
open MeasureTheory ProbabilityTheory Classical Set
open scoped ENNReal NNReal
namespace TorusCoverTime.Blocks.B.GaussianClockPath
variable {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
variable {n : ℕ} (W : GaussianClockPath μ n)

def leftPath (lo : Fin (n + 1)) (ω : Ω) (i : {i : Fin (n + 1) // i ≤ lo}) : ℝ := W.path ω i.val
def rightPath (hi : Fin (n + 1)) (ω : Ω) (i : {i : Fin (n + 1) // hi ≤ i}) : ℝ :=
  W.path ω i.val - W.path ω (Fin.last n)

@[fun_prop] theorem leftPath_measurable (lo : Fin (n + 1)) : Measurable (W.leftPath lo) := by
  unfold leftPath
  fun_prop
@[fun_prop] theorem rightPath_measurable (hi : Fin (n + 1)) : Measurable (W.rightPath hi) := by
  unfold rightPath
  fun_prop

theorem left_indep_right (lo hi : Fin (n + 1)) (hlohi : lo ≤ hi) :
    IndepFun (W.leftPath lo) (W.rightPath hi) μ := by
  let L := ContinuousLinearMap.pi (fun i : {i : Fin (n + 1) // i ≤ lo} =>
    (ContinuousLinearMap.proj i.val : (Fin (n + 1) → ℝ) →L[ℝ] ℝ))
  let R := ContinuousLinearMap.pi (fun i : {i : Fin (n + 1) // hi ≤ i} =>
    (ContinuousLinearMap.proj i.val : (Fin (n + 1) → ℝ) →L[ℝ] ℝ) - ContinuousLinearMap.proj (Fin.last n))
  apply W.linear_indep L R
  intro i j
  change cov[fun ω => W.path ω i.val, fun ω => W.path ω j.val - W.path ω (Fin.last n); μ] = 0
  rw [covariance_fun_sub_right (W.memLp _) (W.memLp _) (W.memLp _), W.covariance, W.covariance,
    min_eq_left (i.property.trans (hlohi.trans j.property)), min_eq_left (Fin.le_last i.val), sub_self]

theorem ends_indep_middle (lo hi : Fin (n + 1)) (hlohi : lo ≤ hi) :
    IndepFun (fun ω => (W.leftPath lo ω, W.rightPath hi ω))
      (fun ω => W.path ω hi - W.path ω lo) μ := by
  let I := Sum {i : Fin (n + 1) // i ≤ lo} {i : Fin (n + 1) // hi ≤ i}
  let L : (Fin (n + 1) → ℝ) →L[ℝ] (I → ℝ) := ContinuousLinearMap.pi (fun i =>
    Sum.elim (fun i : {i : Fin (n + 1) // i ≤ lo} =>
      (ContinuousLinearMap.proj i.val : (Fin (n + 1) → ℝ) →L[ℝ] ℝ))
      (fun i : {i : Fin (n + 1) // hi ≤ i} =>
        (ContinuousLinearMap.proj i.val : (Fin (n + 1) → ℝ) →L[ℝ] ℝ) - ContinuousLinearMap.proj (Fin.last n)) i)
  let R : (Fin (n + 1) → ℝ) →L[ℝ] (Unit → ℝ) := ContinuousLinearMap.pi (fun _ =>
    (ContinuousLinearMap.proj hi : (Fin (n + 1) → ℝ) →L[ℝ] ℝ) - ContinuousLinearMap.proj lo)
  have hind := W.linear_indep L R (by
    intro i _
    cases i with
    | inl i => exact W.past_increment_covariance i.val lo hi i.property hlohi
    | inr i =>
      change cov[fun ω => W.path ω i.val - W.path ω (Fin.last n),
        fun ω => W.path ω hi - W.path ω lo; μ] = 0
      rw [W.increment_covariance]
      simp only [min_eq_right i.property, min_eq_right (hlohi.trans i.property),
        min_eq_right (Fin.le_last hi), min_eq_right (Fin.le_last lo)]
      ring)
  let rebuild := fun f : I → ℝ => ((fun i => f (Sum.inl i)), (fun i => f (Sum.inr i)))
  have hm : Measurable rebuild := by fun_prop
  change IndepFun (fun ω => ((fun i : {i : Fin (n+1) // i ≤ lo} => W.path ω i.val),
    (fun i : {i : Fin (n+1) // hi ≤ i} => W.path ω i.val - W.path ω (Fin.last n))))
      (fun ω => W.path ω hi - W.path ω lo) μ
  simpa only [Function.comp_def, rebuild, L, R, ContinuousLinearMap.pi_apply,
    Sum.elim_inl, Sum.elim_inr, sub_apply, ContinuousLinearMap.proj_apply, leftPath, rightPath] using
    hind.comp hm (measurable_pi_apply ())

theorem barrier_interval_decoupling (lo hi : Fin (n + 1)) (hlohi : lo ≤ hi)
    (δ : ℝ) (hδ : 0 < δ) (hgap : δ ≤ W.clock hi - W.clock lo)
    (H a b : ℝ) (hab : a ≤ b) :
    μ {ω | W.path ω (Fin.last n) ∈ Icc a b ∧ ∀ i, W.path ω i ≤ H} ≤
      ENNReal.ofReal ((b-a) / Real.sqrt (2 * Real.pi * δ)) *
        μ (W.survival H lo) * μ (W.reverse.survival (H-a) hi.rev) := by
  let S : Set ({i : Fin (n + 1) // i ≤ lo} → ℝ) := {f | ∀ i, f i ≤ H}
  let T : Set ({i : Fin (n + 1) // hi ≤ i} → ℝ) := {f | ∀ i, f i ≤ H-a}
  have hS : MeasurableSet S := by
    change MeasurableSet {f : {i : Fin (n + 1) // i ≤ lo} → ℝ | ∀ i, f i ≤ H}
    rw [Set.ofPred_forall]
    exact MeasurableSet.iInter (fun i => measurableSet_le (measurable_pi_apply i) measurable_const)
  have hT : MeasurableSet T := by
    change MeasurableSet {f : {i : Fin (n + 1) // hi ≤ i} → ℝ | ∀ i, f i ≤ H-a}
    rw [Set.ofPred_forall]
    exact MeasurableSet.iInter (fun i => measurableSet_le (measurable_pi_apply i) measurable_const)
  have hv := hδ.trans_le hgap
  have h := Blocks.C.C4.independent_endpoint_interval_le μ (W.leftPath lo) (W.rightPath hi)
    (fun ω => W.path ω hi - W.path ω lo) (W.leftPath_measurable lo) (W.rightPath_measurable hi)
    (by fun_prop) (W.left_indep_right lo hi hlohi) (W.ends_indep_middle lo hi hlohi)
    (Real.toNNReal_pos.mpr hv).ne' (W.increment_hasLaw lo hi hlohi)
    (fun f => f ⟨lo, le_rfl⟩) (fun f => -f ⟨hi, le_rfl⟩) (by fun_prop) (by fun_prop)
    S T hS hT a b hab
  rw [Real.coe_toNNReal _ hv.le] at h
  have hs : (W.leftPath lo) ⁻¹' S = W.survival H lo := by
    ext ω
    exact ⟨fun h i hi => h ⟨i, hi⟩, fun h i => h i.val i.property⟩
  have ht : (W.rightPath hi) ⁻¹' T = W.reverse.survival (H-a) hi.rev := by
    ext ω
    constructor
    · intro h i hi'
      exact h ⟨i.rev, by simpa using Fin.rev_le_rev.mpr hi'⟩
    · intro h i
      have hh := h i.val.rev (Fin.rev_le_rev.mpr i.property)
      change W.path ω i.val - W.path ω (Fin.last n) ≤ H-a
      simpa only [reverse, Fin.rev_rev] using hh
  rw [hs, ht] at h
  refine (measure_mono ?_).trans (h.trans ?_)
  · intro ω hω
    refine ⟨fun i => hω.2 i.val, ?_, ?_⟩
    · intro i
      change W.path ω i.val - W.path ω (Fin.last n) ≤ H-a
      linarith [hω.2 i.val, hω.1.1]
    · have he : W.leftPath lo ω ⟨lo, le_rfl⟩ + (W.path ω hi - W.path ω lo) +
          -W.rightPath hi ω ⟨hi, le_rfl⟩ = W.path ω (Fin.last n) := by
        dsimp [leftPath, rightPath]
        ring
      rw [he]
      exact hω.1
  · gcongr

end TorusCoverTime.Blocks.B.GaussianClockPath
