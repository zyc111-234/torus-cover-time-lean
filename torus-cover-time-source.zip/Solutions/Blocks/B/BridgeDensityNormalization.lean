import Solutions.Blocks.B.GaussianClockBridge

/-! A positive endpoint interval has density of order n^(-1/2), uniformly
over the original bounded variance tables. -/

noncomputable section
open MeasureTheory ProbabilityTheory
namespace TorusCoverTime.Blocks.B

def bridgeBarrierPadding (U : ℝ) : ℝ := 2*Real.sqrt U+2

def bridgeDensityConstant (U : ℝ) : ℝ := Real.exp 1*Real.sqrt (2*Real.pi*U)

theorem bridgeBarrierPadding_ge_two (U : ℝ) : 2 ≤ bridgeBarrierPadding U := by
  unfold bridgeBarrierPadding
  linarith [Real.sqrt_nonneg U]

theorem bridge_density_inverse_le (n V U : ℝ) (hn : 1 ≤ n) (hlo : n ≤ V) (hhi : V ≤ U*n) :
    1/(Real.exp (-(1/(2*V)))/Real.sqrt (2*Real.pi*V)) ≤ bridgeDensityConstant U*Real.sqrt n := by
  have hn0 : 0<n := by linarith
  have hV : 0<V := hn0.trans_le hlo
  have hU : 0<U := by nlinarith
  have hx : 1/(2*V) ≤ 1 := (div_le_one (by positivity)).mpr (by linarith)
  have hs : Real.sqrt (2*Real.pi*V) ≤ Real.sqrt (2*Real.pi*U)*Real.sqrt n := by
    rw [← Real.sqrt_mul (by positivity : 0 ≤ 2*Real.pi*U)]
    apply Real.sqrt_le_sqrt
    nlinarith [Real.pi_pos]
  have he : 1/(Real.exp (-(1/(2*V)))/Real.sqrt (2*Real.pi*V)) =
      Real.sqrt (2*Real.pi*V)*Real.exp (1/(2*V)) := by
    rw [one_div_div,div_eq_mul_inv,← Real.exp_neg,neg_neg]
  rw [he]
  calc
    _ ≤ (Real.sqrt (2*Real.pi*U)*Real.sqrt n)*Real.exp 1 :=
      mul_le_mul hs (Real.exp_le_exp.mpr hx) (Real.exp_nonneg _) (by positivity)
    _ = _ := by unfold bridgeDensityConstant; ring

namespace GaussianClockPath
variable {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
variable {n : ℕ} (W : GaussianClockPath μ n)

theorem ClockBounds.endpoint_bounds {U : ℝ} (h : W.ClockBounds U) :
    (n : ℝ) ≤ W.clock (Fin.last n) ∧ W.clock (Fin.last n) ≤ U*n := by
  constructor
  · simpa only [Fin.val_last,Fin.val_zero,Nat.cast_zero,sub_zero,W.clock_zero] using h.lower 0 (Fin.last n) (Fin.zero_le _)
  · simpa only [Fin.val_last,Fin.val_zero,Nat.cast_zero,sub_zero,W.clock_zero] using h.upper 0 (Fin.last n) (Fin.zero_le _)

theorem ClockBounds.one_le_upper {U : ℝ} (h : W.ClockBounds U) (hn : 0<n) : 1 ≤ U := by
  have hh := h.endpoint_bounds W
  have hp : (0 : ℝ)<n := by exact_mod_cast hn
  nlinarith

end GaussianClockPath
end TorusCoverTime.Blocks.B
