import Solutions.Blocks.B.FourierCutoff
import Solutions.Blocks.B.GreenSpatialDecay

/-! Uniform control of the oscillatory complement of a square frequency cutoff. -/

noncomputable section
open scoped BigOperators
namespace TorusCoverTime.Blocks.B

def quadraticRowCore (N : Size) (m : ℕ) (z : ZMod N.val) (b : ℝ) : ℂ :=
  ∑ a ∈ centeredCore N m, ((1 / (b ^ 2 + coordinateDistance a 0 ^ 2) : ℝ) : ℂ) *
    coordinateCharacter N (a * z)

theorem quadraticRowCore_tail (N : Size) (m : ℕ) (hm : m ≤ (N.val - 1) / 2)
    (z : ZMod N.val) (hz : z ≠ 0) (b : ℝ) :
    ‖quadraticFourierRow N z b - quadraticRowCore N m z b‖ ≤
      4 / (((m : ℝ) + 1)^2 * ‖coordinateCharacter N z - 1‖) := by
  unfold quadraticFourierRow quadraticRowCore
  rw [sum_zmod_sub_centeredCore_complex N m hm]
  have he (n : ℕ) (hn : n ≤ N.val / 2 - m) (neg : Bool) :
      (∑ j ∈ Finset.range n,
        ((1 / (b ^ 2 + coordinateDistance
          (if neg then -((m+j+1 : ℕ) : ZMod N.val) else ((m+j+1 : ℕ) : ZMod N.val)) 0 ^ 2) : ℝ) : ℂ) *
          coordinateCharacter N ((if neg then -((m+j+1 : ℕ) : ZMod N.val)
            else ((m+j+1 : ℕ) : ZMod N.val)) * z)) =
      ∑ j ∈ Finset.range n,
        ((1 / (b ^ 2 + (((m+j : ℕ) : ℝ) + 1) ^ 2) : ℝ) : ℂ) *
          (if neg then (coordinateCharacter N z)⁻¹ else coordinateCharacter N z) ^ (m+j+1) := by
    apply Finset.sum_congr rfl
    intro j hj
    have hjh : m+j+1 ≤ N.val / 2 := by have := Finset.mem_range.mp hj; omega
    cases neg
    · simp only [Bool.false_eq_true, ↓reduceIte]
      rw [coordinateDistance_natCast_half N _ hjh, coordinateCharacter_nat_mul,
        Nat.cast_add, Nat.cast_one]
    · simp only [↓reduceIte, coordinateDistance_neg_zero, neg_mul, coordinateCharacter_neg,
        coordinateCharacter_nat_mul, inv_pow]
      rw [coordinateDistance_natCast_half N _ hjh, Nat.cast_add, Nat.cast_one]
  rw [show (∑ j ∈ Finset.range (N.val / 2 - m),
      ((1 / (b ^ 2 + coordinateDistance ((m+j+1 : ℕ) : ZMod N.val) 0 ^ 2) : ℝ) : ℂ) *
        coordinateCharacter N (((m+j+1 : ℕ) : ZMod N.val) * z)) =
      ∑ j ∈ Finset.range (N.val / 2 - m),
        ((1 / (b ^ 2 + (((m+j : ℕ) : ℝ) + 1)^2) : ℝ) : ℂ) *
          coordinateCharacter N z ^ (m+j+1) from he _ le_rfl false]
  rw [show (∑ j ∈ Finset.range ((N.val - 1) / 2 - m),
      ((1 / (b ^ 2 + coordinateDistance (-((m+j+1 : ℕ) : ZMod N.val)) 0 ^ 2) : ℝ) : ℂ) *
        coordinateCharacter N (-((m+j+1 : ℕ) : ZMod N.val) * z)) =
      ∑ j ∈ Finset.range ((N.val - 1) / 2 - m),
        ((1 / (b ^ 2 + (((m+j : ℕ) : ℝ) + 1)^2) : ℝ) : ℂ) *
          (coordinateCharacter N z)⁻¹ ^ (m+j+1) from he _ (by omega) true]
  apply (norm_add_le _ _).trans
  have hp := quadratic_geometric_tail_bound b m (N.val / 2 - m) (coordinateCharacter N z)
    (coordinateCharacter_norm N z) (coordinateCharacter_ne_one N hz)
  have hn := quadratic_geometric_tail_bound b m ((N.val - 1) / 2 - m) (coordinateCharacter N z)⁻¹
    (by rw [norm_inv, coordinateCharacter_norm, inv_one]) (by simpa using coordinateCharacter_ne_one N hz)
  rw [coordinateCharacter_inv_gap] at hn
  convert add_le_add hp hn using 1
  ring

theorem quadraticRowCore_tail_distance (N : Size) (m : ℕ) (hm : m ≤ (N.val - 1) / 2)
    (z : ZMod N.val) (hz : z ≠ 0) (b : ℝ) :
    ‖quadraticFourierRow N z b - quadraticRowCore N m z b‖ ≤
      ((N.val : ℝ) / coordinateDistance z 0) / ((m : ℝ) + 1)^2 := by
  have hd : 0 < coordinateDistance z 0 :=
    zero_lt_one.trans_le (coordinateDistance_nonzero_ge_one N z hz)
  have hN : 0 < (N.val : ℝ) := zero_lt_one.trans (size_real_gt_one N)
  have hg : 0 < ‖coordinateCharacter N z - 1‖ :=
    norm_pos_iff.mpr (sub_ne_zero.mpr (coordinateCharacter_ne_one N hz))
  have hgap := (div_le_iff₀ hN).mp (coordinateCharacter_distance_lower N z)
  have hrec : 4 / ‖coordinateCharacter N z - 1‖ ≤ (N.val : ℝ) / coordinateDistance z 0 := by
    apply (div_le_div_iff₀ hg hd).mpr
    nlinarith
  apply (quadraticRowCore_tail N m hm z hz b).trans
  calc
    _ = (4 / ‖coordinateCharacter N z - 1‖) / ((m : ℝ) + 1)^2 := by
      simp only [div_eq_mul_inv, mul_inv_rev]; ring
    _ ≤ _ := div_le_div_of_nonneg_right hrec (sq_nonneg _)

theorem centeredCore_compl_inverse_squares (N : Size) (m : ℕ)
    (hm : m ≤ (N.val - 1) / 2) :
    (∑ b ∈ Finset.univ \ centeredCore N m, 1 / coordinateDistance b 0 ^ 2) ≤
      4 / ((m : ℝ) + 1) := by
  rw [Finset.sum_sdiff_eq_sub (Finset.subset_univ _), sum_zmod_sub_centeredCore_real N m hm]
  have he (n : ℕ) (hn : n ≤ N.val / 2 - m) (neg : Bool) :
      (∑ j ∈ Finset.range n, 1 / coordinateDistance
        (if neg then -((m+j+1 : ℕ) : ZMod N.val) else ((m+j+1 : ℕ) : ZMod N.val)) 0 ^ 2) =
      ∑ j ∈ Finset.range n, 1 / (((m : ℝ) + 1) + (j : ℝ)) ^ 2 := by
    apply Finset.sum_congr rfl
    intro j hj
    have hjh : m+j+1 ≤ N.val / 2 := by have := Finset.mem_range.mp hj; omega
    cases neg <;> simp only [Bool.false_eq_true, ↓reduceIte, coordinateDistance_neg_zero]
      <;> rw [coordinateDistance_natCast_half N _ hjh]
      <;> simp only [Nat.cast_add, Nat.cast_one]
      <;> ring
  rw [show (∑ j ∈ Finset.range (N.val / 2 - m),
      1 / coordinateDistance ((m+j+1 : ℕ) : ZMod N.val) 0 ^ 2) =
      ∑ j ∈ Finset.range (N.val / 2 - m), 1 / (((m : ℝ) + 1) + (j : ℝ)) ^ 2 from he _ le_rfl false]
  rw [show (∑ j ∈ Finset.range ((N.val - 1) / 2 - m),
      1 / coordinateDistance (-((m+j+1 : ℕ) : ZMod N.val)) 0 ^ 2) =
      ∑ j ∈ Finset.range ((N.val - 1) / 2 - m), 1 / (((m : ℝ) + 1) + (j : ℝ)) ^ 2 from
        he _ (by omega) true]
  have hm1 : 1 ≤ (m : ℝ) + 1 := by have := Nat.cast_nonneg (α := ℝ) m; linarith
  have hp := shifted_reciprocal_squares_bound ((m : ℝ) + 1) hm1 (N.val / 2 - m)
  have hn := shifted_reciprocal_squares_bound ((m : ℝ) + 1) hm1 ((N.val - 1) / 2 - m)
  calc
    _ ≤ 2 / ((m : ℝ) + 1) + 2 / ((m : ℝ) + 1) := add_le_add hp hn
    _ = _ := by ring

def quadraticSquareCore (N : Size) (m : ℕ) (z : Vertex N) : ℂ :=
  ∑ b ∈ centeredCore N m, coordinateCharacter N (b * z.2) * quadraticRowCore N m z.1 (coordinateDistance b 0)

theorem quadraticSquareCore_tail (N : Size) (m : ℕ) (hm : m ≤ (N.val - 1) / 2)
    (z : Vertex N) (hz : z.1 ≠ 0) :
    ‖quadraticFourierSum N z - quadraticSquareCore N m z‖ ≤
      10 * ((N.val : ℝ) / coordinateDistance z.1 0) / ((m : ℝ) + 1) := by
  let T := (N.val : ℝ) / coordinateDistance z.1 0
  have hT : 0 ≤ T := by
    exact div_nonneg (Nat.cast_nonneg _) (coordinateDistance_zero_bounds N z.1).1
  let F := fun b => coordinateCharacter N (b * z.2) * quadraticFourierRow N z.1 (coordinateDistance b 0)
  have he : quadraticFourierSum N z - quadraticSquareCore N m z =
      (∑ b ∈ Finset.univ \ centeredCore N m, F b) +
      (∑ b ∈ centeredCore N m, coordinateCharacter N (b * z.2) *
        (quadraticFourierRow N z.1 (coordinateDistance b 0) - quadraticRowCore N m z.1 (coordinateDistance b 0))) := by
    rw [Finset.sum_sdiff_eq_sub (Finset.subset_univ _), quadraticFourierSum_rows, quadraticSquareCore]
    simp only [mul_sub, Finset.sum_sub_distrib, F]
    abel
  have hh : ‖∑ b ∈ Finset.univ \ centeredCore N m, F b‖ ≤ 8 * T / ((m : ℝ) + 1) := by
    apply (norm_sum_le _ _).trans
    calc
      _ ≤ ∑ b ∈ Finset.univ \ centeredCore N m, 2 * T * (1 / coordinateDistance b 0 ^ 2) := by
        apply Finset.sum_le_sum
        intro b hb
        have hb0 : 0 < coordinateDistance b 0 := by
          have hbn : b ∉ centeredCore N m := (Finset.mem_sdiff.mp hb).2
          have hbn' : (m : ℝ) < coordinateDistance b 0 := lt_of_not_ge (fun h => hbn ((mem_centeredCore N m b).mpr h))
          exact (Nat.cast_nonneg m).trans_lt hbn'
        dsimp [F]
        rw [norm_mul, coordinateCharacter_norm, one_mul]
        calc
          _ ≤ 2 * (N.val : ℝ) / (coordinateDistance z.1 0 * coordinateDistance b 0 ^ 2) :=
            quadraticFourierRow_oscillatory N z.1 hz _ hb0
          _ = _ := by simp only [T, div_eq_mul_inv, mul_inv_rev]; ring
      _ = 2 * T * ∑ b ∈ Finset.univ \ centeredCore N m, 1 / coordinateDistance b 0 ^ 2 := by rw [Finset.mul_sum]
      _ ≤ 2 * T * (4 / ((m : ℝ) + 1)) := mul_le_mul_of_nonneg_left
        (centeredCore_compl_inverse_squares N m hm) (mul_nonneg (by norm_num) hT)
      _ = _ := by ring
  have hl : ‖∑ b ∈ centeredCore N m, coordinateCharacter N (b * z.2) *
      (quadraticFourierRow N z.1 (coordinateDistance b 0) - quadraticRowCore N m z.1 (coordinateDistance b 0))‖ ≤
        2 * T / ((m : ℝ) + 1) := by
    apply (norm_sum_le _ _).trans
    calc
      _ ≤ ∑ _b ∈ centeredCore N m, T / ((m : ℝ) + 1)^2 := by
        apply Finset.sum_le_sum
        intro b _
        rw [norm_mul, coordinateCharacter_norm, one_mul]
        exact quadraticRowCore_tail_distance N m hm z.1 hz _
      _ = (2 * (m : ℝ) + 1) * (T / ((m : ℝ) + 1)^2) := by
        rw [Finset.sum_const, nsmul_eq_mul, centeredCore_card N m hm]
      _ ≤ 2 * T / ((m : ℝ) + 1) := by
        have hp : 0 < (m : ℝ) + 1 := by positivity
        apply (le_div_iff₀ hp).mpr
        field_simp
        nlinarith
  rw [he]
  apply (norm_add_le _ _).trans
  convert add_le_add hh hl using 1
  dsimp [T]
  ring

end TorusCoverTime.Blocks.B
