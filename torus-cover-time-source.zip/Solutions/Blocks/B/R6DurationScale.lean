import Solutions.Blocks.B.R10WitnessAlgebra
import Solutions.Blocks.B.R6DurationConditioning

/-! R6's large-domain scalar scales. These estimates preserve the scale Q = L^(16*gamma)
and do not replace the separately needed disk exit and avoidance estimates. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Asymptotics
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

lemma polynomial_eventually_le_stretched_exp (A M a c : ℝ) (ha : 0 < a) (hc : 0 < c) :
    ∀ᶠ L : ℝ in atTop, A * L ^ M ≤ Real.exp (c * L ^ a) := by
  have ht := (polynomial_times_stretched_exp_tendsto_zero a c M ha hc).const_mul A
  have ht' : Tendsto (fun L : ℝ => A * (L ^ M * Real.exp (-c * L ^ a))) atTop (𝓝 0) := by
    simpa only [mul_zero] using ht
  filter_upwards [ht'.eventually_lt_const (by norm_num : (0 : ℝ) < 1)] with L hL
  have hdiv : A * L ^ M / Real.exp (c * L ^ a) ≤ 1 := by
    simpa only [neg_mul, Real.exp_neg, div_eq_mul_inv, mul_assoc] using hL.le
  exact (div_le_one (Real.exp_pos _)).mp hdiv

lemma r6_log_error_superexponential (γ A c : ℝ) (hγ : 0 < γ) (hc : 0 < c) :
    ∀ᶠ L : ℝ in atTop,
      A * L ^ 4 - c * Real.exp (L ^ (16 * γ) - 4 * L ^ γ) ≤
        -Real.exp (L ^ (16 * γ) / 2) := by
  have ht := (tendsto_rpow_atTop (by positivity : 0 < 16 * γ)).eventually
    (const_exp_eventually_le_exp (2 / c) (1 / 2) (3 / 4) (by norm_num))
  filter_upwards [power_eventually_le_power 4 γ (16 * γ) (1 / 4) (by linarith) (by norm_num),
    polynomial_eventually_le_stretched_exp A 4 (16 * γ) (1 / 2) (by positivity) (by norm_num), ht]
    with L hsmall hpref hlarge
  have hpref' : A * L ^ 4 ≤ Real.exp (L ^ (16 * γ) / 2) := by
    simpa only [Real.rpow_ofNat, one_div_mul_eq_div] using hpref
  have hlarge' : 2 * Real.exp (L ^ (16 * γ) / 2) ≤ c * Real.exp ((3 / 4) * L ^ (16 * γ)) := by
    calc
      _ = c * ((2 / c) * Real.exp ((1 / 2) * L ^ (16 * γ))) := by
        rw [one_div_mul_eq_div]
        field_simp
      _ ≤ _ := mul_le_mul_of_nonneg_left hlarge hc.le
  have hexp : Real.exp ((3 / 4) * L ^ (16 * γ)) ≤
      Real.exp (L ^ (16 * γ) - 4 * L ^ γ) := Real.exp_le_exp.mpr (by linarith)
  have hmul := mul_le_mul_of_nonneg_left hexp hc.le
  linarith

lemma r6_duration_radius_ratio (L q γ : ℝ) (hL : 0 ≤ L) (hq : 0 ≤ q)
    (hγ : 0 ≤ γ) (hqL : q ≤ L - L ^ (16 * γ)) :
    Real.exp (L ^ (16 * γ) - 4 * L ^ γ) ≤
      Real.exp (2 * L - L ^ (16 * γ)) / (Real.exp (q + 2 * q ^ γ)) ^ 2 := by
  have hqL' : q ≤ L := hqL.trans (sub_le_self L (Real.rpow_nonneg hL _))
  have hp := Real.rpow_le_rpow hq hqL' hγ
  rw [← Real.exp_nat_mul, ← Real.exp_sub]
  apply Real.exp_le_exp.mpr
  norm_num
  linarith

theorem r6_kernel_error_superexponential (γ A c : ℝ) (hγ : 0 < γ) (hc : 0 < c) :
    ∀ᶠ L : ℝ in atTop, ∀ q E : ℝ, 0 ≤ q → q ≤ L - L ^ (16 * γ) → E ≤ A * L ^ 4 →
      Real.exp (E - c * Real.exp (2 * L - L ^ (16 * γ)) /
        (Real.exp (q + 2 * q ^ γ)) ^ 2) ≤ Real.exp (-Real.exp (L ^ (16 * γ) / 2)) := by
  filter_upwards [eventually_ge_atTop (0 : ℝ), r6_log_error_superexponential γ A c hγ hc]
    with L hL hscalar
  intro q E hq hqL hE
  have hratio := mul_le_mul_of_nonneg_left (r6_duration_radius_ratio L q γ hL hq hγ.le hqL) hc.le
  apply Real.exp_le_exp.mpr
  rw [← mul_div_assoc] at hratio
  linarith

lemma r6_error_dominates_torus_polynomials (γ a b : ℝ) (hγ : 0 < γ) :
    Tendsto (fun L : ℝ => Real.exp (a * L) * L ^ b *
      Real.exp (-Real.exp (L ^ (16 * γ) / 2))) atTop (𝓝 0) := by
  have hpol := polynomial_times_stretched_exp_tendsto_zero 1 1 b (by norm_num) (by norm_num)
  have hbound : ∀ᶠ L : ℝ in atTop,
      Real.exp (a * L) * L ^ b * Real.exp (-Real.exp (L ^ (16 * γ) / 2)) ≤
        L ^ b * Real.exp (-L) := by
    filter_upwards [eventually_ge_atTop (0 : ℝ),
      polynomial_eventually_le_stretched_exp (a + 1) 1 (16 * γ) (1 / 2) (by positivity) (by norm_num)]
      with L hL hlarge
    have hlarge' : (a + 1) * L ≤ Real.exp (L ^ (16 * γ) / 2) := by
      simpa only [Real.rpow_one, one_div_mul_eq_div] using hlarge
    calc
      _ = L ^ b * Real.exp (a * L - Real.exp (L ^ (16 * γ) / 2)) := by
        rw [Real.exp_sub, Real.exp_neg]
        ring
      _ ≤ _ := mul_le_mul_of_nonneg_left (Real.exp_le_exp.mpr (by nlinarith))
        (Real.rpow_nonneg hL _)
  apply squeeze_zero' ?_ hbound
    (by simpa only [Real.rpow_one, neg_one_mul] using hpol)
  filter_upwards [eventually_ge_atTop (0 : ℝ)] with L hL
  positivity

lemma r6_log_prefactor_bound (L q γ C c : ℝ) (m : ℕ)
    (hL : 1 ≤ L) (hq : 0 ≤ q) (hqL : q ≤ L) (hγ : 0 ≤ γ) (hγ1 : γ ≤ 1)
    (hC : 0 ≤ C) (hm : (m : ℝ) ≤ L ^ 4 + 1) :
    Real.log C + Real.log ((m : ℝ) + 1) + C * (q + 2 * q ^ γ) +
      ((m : ℝ) + 1) * |Real.log c| ≤
        (|Real.log C| + 2 + 3 * C + 3 * |Real.log c|) * L ^ 4 := by
  have h14 : (1 : ℝ) ≤ L ^ 4 := one_le_pow₀ hL
  have hL4 : L ≤ L ^ 4 := by
    simpa only [Real.rpow_one, Real.rpow_ofNat] using
      Real.rpow_le_rpow_of_exponent_le hL (by norm_num : (1 : ℝ) ≤ 4)
  have hqγ : q ^ γ ≤ L := by
    have h1 := Real.rpow_le_rpow hq hqL hγ
    have h2 := Real.rpow_le_rpow_of_exponent_le hL hγ1
    exact h1.trans (by simpa only [Real.rpow_one] using h2)
  have hlog : Real.log ((m : ℝ) + 1) ≤ (m : ℝ) := by
    have h := Real.log_le_sub_one_of_pos (show 0 < (m : ℝ) + 1 by positivity)
    linarith
  have hlogC : Real.log C ≤ |Real.log C| * L ^ 4 :=
    (le_abs_self _).trans (le_mul_of_one_le_right (abs_nonneg _) h14)
  have hqterm := mul_le_mul_of_nonneg_left (show q + 2 * q ^ γ ≤ 3 * L ^ 4 by linarith) hC
  have hmterm := mul_le_mul_of_nonneg_right (show (m : ℝ) + 1 ≤ 3 * L ^ 4 by linarith)
    (abs_nonneg (Real.log c))
  nlinarith

lemma r6_positive_prefactor_eq_exp (C c r : ℝ) (m : ℕ) (hC : 0 < C) (hc : 0 < c) :
    C * ((m : ℝ) + 1) * (Real.exp r) ^ C / c ^ m =
      Real.exp (Real.log C + Real.log ((m : ℝ) + 1) + r * C - (m : ℝ) * Real.log c) := by
  rw [Real.exp_sub, Real.exp_add, Real.exp_add, Real.exp_log hC,
    Real.exp_log (by positivity), Real.exp_mul, Real.exp_nat_mul, Real.exp_log hc]

lemma r6_duration_prefactor_le_exp (C c r d : ℝ) (m : ℕ) (hC : 0 < C) (hc : 0 < c) :
    C * (m : ℝ) * (Real.exp r) ^ C / c ^ m * Real.exp (-c * d / (Real.exp r) ^ 2) ≤
      Real.exp (Real.log C + Real.log ((m : ℝ) + 1) + C * r +
        ((m : ℝ) + 1) * |Real.log c| - c * d / (Real.exp r) ^ 2) := by
  have hcost : -(m : ℝ) * Real.log c ≤ ((m : ℝ) + 1) * |Real.log c| := by
    have h := mul_le_mul_of_nonneg_left (neg_le_abs (Real.log c)) (Nat.cast_nonneg m)
    nlinarith [abs_nonneg (Real.log c)]
  calc
    _ ≤ C * ((m : ℝ) + 1) * (Real.exp r) ^ C / c ^ m * Real.exp (-c * d / (Real.exp r) ^ 2) := by
      apply mul_le_mul_of_nonneg_right _ (Real.exp_pos _).le
      apply div_le_div_of_nonneg_right _ (pow_nonneg hc.le _)
      apply mul_le_mul_of_nonneg_right _ (Real.rpow_nonneg (Real.exp_pos _).le _)
      exact mul_le_mul_of_nonneg_left (by linarith) hC.le
    _ = Real.exp (Real.log C + Real.log ((m : ℝ) + 1) + r * C -
        (m : ℝ) * Real.log c - c * d / (Real.exp r) ^ 2) := by
      rw [r6_positive_prefactor_eq_exp C c r m hC hc, ← Real.exp_add]
      congr 1
      ring
    _ ≤ _ := Real.exp_le_exp.mpr (by nlinarith)

theorem r6_duration_prefactor_superexponential (γ C c : ℝ)
    (hγ : 0 < γ) (hγ1 : γ ≤ 1) (hC : 0 < C) (hc : 0 < c) :
    ∀ᶠ L : ℝ in atTop, ∀ q : ℝ, ∀ m : ℕ,
      0 ≤ q → q ≤ L - L ^ (16 * γ) → (m : ℝ) ≤ L ^ 4 + 1 →
      C * (m : ℝ) * (Real.exp (q + 2 * q ^ γ)) ^ C / c ^ m *
        Real.exp (-c * Real.exp (2 * L - L ^ (16 * γ)) / (Real.exp (q + 2 * q ^ γ)) ^ 2) ≤
          Real.exp (-Real.exp (L ^ (16 * γ) / 2)) := by
  let A := |Real.log C| + 2 + 3 * C + 3 * |Real.log c|
  filter_upwards [eventually_ge_atTop (1 : ℝ), r6_kernel_error_superexponential γ A c hγ hc]
    with L hL hscalar
  intro q m hq hqL hm
  have hqL' : q ≤ L := hqL.trans (sub_le_self L (Real.rpow_nonneg (by linarith) _))
  exact (r6_duration_prefactor_le_exp C c (q + 2 * q ^ γ)
    (Real.exp (2 * L - L ^ (16 * γ))) m hC hc).trans
      (hscalar q _ hq hqL (r6_log_prefactor_bound L q γ C c m hL hq hqL' hγ.le hγ1 hC.le hm))

theorem r6_duration_superexponential_of_disk_bounds (hWalk : TorusCoverTime.WalkModelRegular)
    (γ C c : ℝ) (hγ : 0 < γ) (hγ1 : γ ≤ 1) (hC : 0 < C) (hc : 0 < c) :
    ∀ᶠ L : ℝ in atTop, ∀ N : TorusCoverTime.Size, ∀ D K : Finset (TorusCoverTime.Vertex N),
      ∀ m : ℕ, ∀ a b : Fin m → TorusCoverTime.Vertex N, ∀ q u : ℝ,
      0 ≤ q → q ≤ L - L ^ (16 * γ) → (m : ℝ) ≤ L ^ 4 + 1 →
      K.Nonempty → 0 ≤ u →
      (∀ i, TorusCoverTime.walkLaw (exitsThrough N D (a i) (b i)) ≠ 0) →
      (∀ i, ENNReal.ofReal c ≤ exactExitLaw N D (a i) (b i)
        (exitsThroughAvoiding N D K (a i) (b i))) →
      (∀ i, exactExitLaw N D (a i) (b i)
        {ω | Real.exp (2 * L - L ^ (16 * γ)) < finiteExitDuration N D (a i) ω} ≤
          ENNReal.ofReal (C * (Real.exp (q + 2 * q ^ γ)) ^ C *
            Real.exp (-c * Real.exp (2 * L - L ^ (16 * γ)) / (Real.exp (q + 2 * q ^ γ)) ^ 2))) →
      (exactExitProductLaw N D m a b)[{ω | ∃ i,
        Real.exp (2 * L - L ^ (16 * γ)) < finiteExitDuration N D (a i) (ω i)} |
          exitBlockSoftness N D K m a u] ≤ ENNReal.ofReal (Real.exp (-Real.exp (L ^ (16 * γ) / 2))) := by
  filter_upwards [r6_duration_prefactor_superexponential γ C c hγ hγ1 hC hc] with L hscalar
  intro N D K m a b q u hq hqL hm hK hu hexit havoid htail
  let R := Real.exp (q + 2 * q ^ γ)
  let d := Real.exp (2 * L - L ^ (16 * γ))
  have hb := r6_duration_given_softness_bound hWalk N D K m a b hexit hK u d hu
    (ENNReal.ofReal c) (ENNReal.ofReal (C * R ^ C * Real.exp (-c * d / R ^ 2))) havoid htail
  apply hb.trans
  calc
    _ = ENNReal.ofReal ((m : ℝ) * (C * R ^ C * Real.exp (-c * d / R ^ 2)) / c ^ m) := by
      rw [ENNReal.ofReal_div_of_pos (pow_pos hc m), ENNReal.ofReal_mul (Nat.cast_nonneg m),
        ENNReal.ofReal_natCast, ENNReal.ofReal_pow hc.le]
    _ = ENNReal.ofReal (C * (m : ℝ) * R ^ C / c ^ m * Real.exp (-c * d / R ^ 2)) := by
      congr 1
      ring
    _ ≤ _ := ENNReal.ofReal_le_ofReal (hscalar q m hq hqL hm)

end TorusCoverTime.Blocks.B
