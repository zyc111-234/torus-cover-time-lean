import Solutions.Blocks.B.ExteriorReturnOccupation
import Solutions.Blocks.B.LowHarmonicWindow

/-! Measurable exterior occupation retaining the terminal tail and its residual clock. -/
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B


def exteriorOccupation (N : Size) (root : Vertex N) (m : ℕ)
    (w : Fin (2*m) → Vertex N) (U : Vertex N → ℝ) (z : TraversalExteriorSample m × ℝ) : ℝ :=
  exteriorReturnOccupation N root m w U z.1 +
    ∑ x, U x*localTime N (endpointWordStart root w (2*m)) z.1.2 z.2 x

theorem exteriorOccupation_measurable (N : Size) (root : Vertex N) (m : ℕ)
    (w : Fin (2*m) → Vertex N) (U : Vertex N → ℝ) :
    Measurable (exteriorOccupation N root m w U) :=
  ((exteriorReturnOccupation_measurable N root m w U).comp measurable_fst).add
    (Finset.measurable_sum _ fun x _ =>
      ((localTime_joint_measurable N (endpointWordStart root w (2*m)) x).comp
        (measurable_fst.snd.prodMk measurable_snd)).const_mul _)

theorem exteriorOccupation_rejoin_invariant (N : Size) (root : Vertex N) (m : ℕ)
    (w : Fin (2*m) → Vertex N) (U : Vertex N → ℝ)
    (x x' : {j : Fin (2*m) // j.val % 2 = 1} → ℕ × WalkSample)
    (y : TraversalExteriorSample m) (u : ℝ) :
    exteriorOccupation N root m w U
      (recordExteriorProjection (2*m) (fun j => j.val % 2 = 1) (selectedRecordsJoin _ x y.1,y.2),u) =
    exteriorOccupation N root m w U
      (recordExteriorProjection (2*m) (fun j => j.val % 2 = 1) (selectedRecordsJoin _ x' y.1,y.2),u) := by
  rw [recordExteriorProjection_join,recordExteriorProjection_join]


end TorusCoverTime.Blocks.B

