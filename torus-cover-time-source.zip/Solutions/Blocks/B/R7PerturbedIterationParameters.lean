import Solutions.Blocks.B.R7PerturbedIteration
import Solutions.Blocks.B.R7IterationParameters

/-! The actual low-count cutoff and the R7 choices Delta=L^(2 gamma),
J=ceil(L^2). All concentration side conditions are discharged uniformly over
the original coarse scales and linearly bounded thresholds. -/

noncomputable section
open MeasureTheory Filter Set Classical
open scoped ENNReal NNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

def r7PerturbedLowCountCutoff (q γ v : ℝ) : ℕ := ⌊v^2/r7PerturbedWidth q (q^γ)⌋₊

theorem r7_perturbed_low_count_cutoff_iff (q γ v : ℝ) (m : ℕ) (hw : 0 < r7PerturbedWidth q (q^γ)) (hv : 0 ≤ v) :
    m ≤ r7PerturbedLowCountCutoff q γ v ↔ Real.sqrt (r7PerturbedWidth q (q^γ)*(m:ℝ)) ≤ v := by
  rw [r7PerturbedLowCountCutoff,Nat.le_floor_iff (div_nonneg (sq_nonneg v) hw.le),
    le_div_iff₀ hw,Real.sqrt_le_iff]
  constructor
  · intro h
    exact ⟨hv,by nlinarith⟩
  · intro h
    nlinarith [h.2]

theorem r7_perturbed_low_count_cutoff_scale (L q γ v C₁ : ℝ) (hL : 1 ≤ L) (hq : 1 ≤ q)
    (hwidth : 1 ≤ r7PerturbedWidth q (q^γ)) (hv : 0 ≤ v) (hvL : v ≤ C₁*L) (hC : 0 ≤ C₁) (hCL : C₁ ≤ L) :
    (r7PerturbedLowCountCutoff q γ v:ℝ)*r7PerturbedWidth q (q^γ) ≤ v^2 ∧ (r7PerturbedLowCountCutoff q γ v:ℝ) ≤ L^4+1 := by
  have hw := hwidth
  have hw0 : 0 < r7PerturbedWidth q (q^γ) := by linarith
  have hm := (le_div_iff₀ hw0).mp (Nat.floor_le (div_nonneg (sq_nonneg v) hw0.le))
  change (r7PerturbedLowCountCutoff q γ v:ℝ)*r7PerturbedWidth q (q^γ) ≤ v^2 at hm
  refine ⟨hm,?_⟩
  have hc := (sq_le_sq₀ hC (by linarith : 0 ≤ L)).mpr hCL
  calc
    _ ≤ v^2 := by nlinarith [mul_nonneg (Nat.cast_nonneg (r7PerturbedLowCountCutoff q γ v)) (show 0 ≤ r7PerturbedWidth q (q^γ)-1 by linarith)]
    _ ≤ (C₁*L)^2 := pow_le_pow_left₀ hv hvL 2
    _ = C₁^2*L^2 := by ring
    _ ≤ L^2*L^2 := mul_le_mul_of_nonneg_right hc (sq_nonneg _)
    _ ≤ _ := by nlinarith

theorem r7_perturbed_iteration_side_conditions (γ C₁ : ℝ) (hγ : 0 < γ) (hγ1 : γ < 1) (hC : 0 < C₁) :
    ∀ᶠ N : Size in atTop, ∀ q v : ℝ,
      (logSize N)^(16*γ) ≤ q → q ≤ logSize N → q ≤ v → v ≤ C₁*logSize N →
      1 ≤ q ∧ (r7PerturbedLowCountCutoff q γ v:ℝ)*r7PerturbedWidth q (q^γ) ≤ v^2 ∧
      (r7PerturbedLowCountCutoff q γ v:ℝ) ≤ (logSize N)^4+1 ∧
      0 ≤ (logSize N)^(2*γ) ∧ (logSize N)^(2*γ) ≤ v ∧
      2*r7PerturbedMeanConstant*Real.exp (-r7MeanExponent*q^γ)*v ≤ (logSize N)^(2*γ) ∧
      4*Real.exp (-(r7PerturbedConcentrationConstant/4)*((logSize N)^(2*γ))^2/q^γ) ≤
        4*Real.exp (-(r7PerturbedConcentrationConstant/4)*(logSize N)^(3*γ)) := by
  have ht := (polynomial_times_stretched_exp_tendsto_zero (16*γ*γ) r7MeanExponent 1
    (by positivity) r7MeanExponent_pos).const_mul (2*r7PerturbedMeanConstant*C₁)
  simp only [Real.rpow_one,mul_zero] at ht
  obtain ⟨q0,hq0⟩ := eventually_atTop.mp (r7_perturbed_parameter_geometry γ hγ hγ1)
  have hQt := (tendsto_rpow_atTop (by positivity : 0 < 16*γ)).comp blockB_logSize_tendsto
  filter_upwards [blockB_logSize_tendsto.eventually_ge_atTop 1,
    blockB_logSize_tendsto.eventually_ge_atTop C₁,
    blockB_logSize_tendsto.eventually (ht.eventually_le_const zero_lt_one),hQt.eventually_ge_atTop q0] with N hL hCL hmean hbase
  intro q v hq hqL hqv hvL
  have hQ := Real.one_le_rpow hL (by positivity : 0 ≤ 16*γ)
  have hq1 : 1 ≤ q := hQ.trans hq
  have hg := hq0 q (hbase.trans hq)
  have hwidth : 1 ≤ r7PerturbedWidth q (q^γ) := (Real.one_le_rpow hq1 hγ.le).trans hg.2.2.2.2.2.2.1
  have hq0 : 0 < q := by linarith
  have hv : 0 ≤ v := by linarith
  have hcut := r7_perturbed_low_count_cutoff_scale (logSize N) q γ v C₁ hL hq1 hwidth hv hvL hC.le hCL
  have hΔ := Real.rpow_nonneg (logSize_pos N).le (2*γ)
  have hΔ1 := Real.one_le_rpow hL (by positivity : 0 ≤ 2*γ)
  have hΔq : (logSize N)^(2*γ) ≤ q :=
    (Real.rpow_le_rpow_of_exponent_le hL (by linarith : 2*γ ≤ 16*γ)).trans hq
  have hW : (logSize N)^(16*γ*γ) ≤ q^γ := by
    rw [Real.rpow_mul (logSize_pos N).le]
    exact Real.rpow_le_rpow (Real.rpow_nonneg (logSize_pos N).le _) hq hγ.le
  have hmean' : 2*r7PerturbedMeanConstant*Real.exp (-r7MeanExponent*q^γ)*v ≤ (logSize N)^(2*γ) := by
    have he := Real.exp_le_exp.mpr (mul_le_mul_of_nonpos_left hW (by have := r7MeanExponent_pos; linarith : -r7MeanExponent ≤ 0))
    have hm := mul_le_mul (mul_le_mul_of_nonneg_left he (by have := r7PerturbedMeanConstant_pos; positivity : 0 ≤ 2*r7PerturbedMeanConstant))
      hvL hv (by have := r7PerturbedMeanConstant_pos; positivity)
    have heq : (2*r7PerturbedMeanConstant*Real.exp (-r7MeanExponent*(logSize N)^(16*γ*γ)))*(C₁*logSize N) =
        (2*r7PerturbedMeanConstant*C₁)*(logSize N*Real.exp (-r7MeanExponent*(logSize N)^(16*γ*γ))) := by ring
    rw [heq] at hm
    exact (hm.trans hmean).trans hΔ1
  refine ⟨hq1,hcut.1,hcut.2,hΔ,hΔq.trans hqv,hmean',?_⟩
  have hratio := r7_delta_ratio (logSize N) q γ (logSize_pos N) hq0 hqL hγ.le
  apply mul_le_mul_of_nonneg_left _ (by norm_num : (0:ℝ) ≤ 4)
  apply Real.exp_le_exp.mpr
  have hmul := mul_le_mul_of_nonpos_left hratio (by have := r7PerturbedConcentrationConstant_pos; linarith : -(r7PerturbedConcentrationConstant/4) ≤ 0)
  simpa only [mul_div_assoc] using hmul

end TorusCoverTime.Blocks.B

