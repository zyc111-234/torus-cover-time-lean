import Solutions.Blocks.B.AnnularExit
import Solutions.Blocks.B.ExitOscillation

/-! Exact specified-endpoint conditioning across the actual annulus. The
core and exterior contributions are separated without changing path events. -/

noncomputable section
open MeasureTheory ProbabilityTheory Classical
namespace TorusCoverTime.Blocks.B

theorem exitsThroughAvoiding_eq_sdiff (N : Size) (D K : Finset (Vertex N)) (hKD : K ⊆ D)
    (a b : Vertex N) (hb : b ∉ D) :
    exitsThroughAvoiding N D K a b = exitsThrough N (D \ K) a b := by
  ext ω
  constructor
  · rintro ⟨n, hn, hav⟩
    refine ⟨n, fun hz => hb (Finset.mem_sdiff.mp hz).1, hn.2.1, ?_⟩
    intro j
    exact Finset.mem_sdiff.mpr ⟨hn.2.2 j, hav j.val j.isLt.le⟩
  · rintro ⟨n, _, hend, hpre⟩
    refine ⟨n, ⟨hb, hend, fun j => (Finset.mem_sdiff.mp (hpre j)).1⟩, ?_⟩
    intro j hj
    rcases lt_or_eq_of_le hj with hj | rfl
    · exact (Finset.mem_sdiff.mp (hpre ⟨j,hj⟩)).2
    · rw [hend]
      exact fun h => hb (hKD h)

theorem exitsThrough_inter_avoid (N : Size) (D K : Finset (Vertex N)) (a b : Vertex N) :
    exitsThrough N D a b ∩ exitsAvoidingCore N D K a = exitsThroughAvoiding N D K a b := by
  ext ω
  constructor
  · rintro ⟨hex,hav⟩
    obtain ⟨b',n,hn,havoid⟩ := Set.mem_iUnion.mp hav
    have hbb : b' = b := by
      by_contra hne
      exact Set.disjoint_left.mp (exitsThrough_disjoint N D a b' b hne) ⟨n,hn⟩ hex
    subst b'
    exact ⟨n,hn,havoid⟩
  · rintro ⟨n,hn,hav⟩
    exact ⟨⟨n,hn⟩, Set.mem_iUnion.mpr ⟨b,n,hn,hav⟩⟩

theorem exactExitLaw_avoid_formula (N : Size) (D K : Finset (Vertex N)) (hKD : K ⊆ D)
    (a b : Vertex N) (hb : b ∉ D) :
    (exactExitLaw N D a b).real (exitsAvoidingCore N D K a) =
      exitHarmonic N (D \ K) b a / exitHarmonic N D b a := by
  have he := cond_apply (μ := walkLaw) (measurableSet_exitsThrough N D a b) (exitsAvoidingCore N D K a)
  change exactExitLaw N D a b (exitsAvoidingCore N D K a) = _ at he
  have hr := congrArg ENNReal.toReal he
  rw [ENNReal.toReal_mul, ENNReal.toReal_inv, exitsThrough_inter_avoid,
    exitsThroughAvoiding_eq_sdiff N D K hKD a b hb] at hr
  change (exactExitLaw N D a b).real (exitsAvoidingCore N D K a) = _ at hr
  rw [hr]
  unfold exitHarmonic
  simp only [measureReal_def, div_eq_mul_inv]
  ring

theorem exactExitLaw_avoid_eq (N : Size) (D K : Finset (Vertex N)) (a b : Vertex N) :
    exactExitLaw N D a b (exitsAvoidingCore N D K a) =
      exactExitLaw N D a b (exitsThroughAvoiding N D K a b) := by
  have hsub : exitsThroughAvoiding N D K a b ⊆ exitsThrough N D a b := by
    rintro ω ⟨n,hn,_⟩
    exact ⟨n,hn⟩
  unfold exactExitLaw
  rw [cond_apply (measurableSet_exitsThrough N D a b), cond_apply (measurableSet_exitsThrough N D a b),
    exitsThrough_inter_avoid, Set.inter_eq_right.mpr hsub]

theorem exitHarmonic_annulus_decomposition (N : Size) (D K : Finset (Vertex N))
    (hD : D ≠ Finset.univ) (hKD : K ⊆ D) (a b : Vertex N) (hb : b ∉ D) :
    exitHarmonic N D b a = exitHarmonic N (D \ K) b a +
      ∑ z ∈ K, exitHarmonic N D b z * exitHarmonic N (D \ K) z a := by
  have he := congrFun (harmonic_exit_representation N (D \ K) (proper_sdiff N D K hD)
    (exitHarmonic N D b) (fun z hz => exitHarmonic_generator N D b z (Finset.mem_sdiff.mp hz).1)) a
  have hterm (z : Vertex N) : exitHarmonic N D b z * exitHarmonic N (D \ K) z a =
      (if z ∈ K then exitHarmonic N D b z * exitHarmonic N (D \ K) z a else 0) +
      (if z = b then exitHarmonic N (D \ K) b a else 0) := by
    by_cases hzK : z ∈ K
    · have hzb : z ≠ b := by intro h; subst z; exact hb (hKD hzK)
      rw [if_pos hzK, if_neg hzb, add_zero]
    · rw [if_neg hzK, zero_add]
      by_cases hzD : z ∈ D
      · have hzb : z ≠ b := by intro h; subst z; exact hb hzD
        rw [exitHarmonic_zero_inside N (D \ K) a z (Finset.mem_sdiff.mpr ⟨hzD,hzK⟩),
          mul_zero, if_neg hzb]
      · rw [exitHarmonic_boundary N D b z hzD]
        by_cases hzb : z = b
        · subst z
          simp
        · rw [if_neg hzb, zero_mul, if_neg hzb]
  change exitHarmonic N D b a = ∑ z, exitHarmonic N D b z * exitHarmonic N (D \ K) z a at he
  rw [Finset.sum_congr rfl (fun z _ => hterm z)] at he
  simp only [Finset.sum_add_distrib, Finset.sum_ite_eq', Finset.mem_univ, if_true] at he
  have hsum : (∑ z : Vertex N, if z ∈ K then exitHarmonic N D b z * exitHarmonic N (D \ K) z a else 0) =
      ∑ z ∈ K, exitHarmonic N D b z * exitHarmonic N (D \ K) z a := by
    rw [← Finset.sum_filter]
    congr 1
    ext z
    simp
  rw [hsum] at he
  linarith

theorem exactExitLaw_avoid_lower (N : Size) (D K : Finset (Vertex N))
    (hD : D ≠ Finset.univ) (hKD : K ⊆ D) (a b : Vertex N) (hb : b ∉ D)
    (hp : 0 < exitHarmonic N D b a) (ε : ℝ)
    (hratio : ∀ z ∈ K, exitHarmonic N D b z / exitHarmonic N D b a ≤ 1+ε) :
    1-(1+ε)*walkLaw.real (exitsInto N (D \ K) K a) ≤
      (exactExitLaw N D a b).real (exitsAvoidingCore N D K a) := by
  have he := exitHarmonic_annulus_decomposition N D K hD hKD a b hb
  have hs : (∑ z ∈ K, exitHarmonic N D b z * exitHarmonic N (D \ K) z a) ≤
      ((1+ε)*exitHarmonic N D b a) * (∑ z ∈ K, exitHarmonic N (D \ K) z a) := by
    rw [Finset.mul_sum]
    apply Finset.sum_le_sum
    intro z hz
    exact mul_le_mul_of_nonneg_right ((div_le_iff₀ hp).mp (hratio z hz))
      (exitHarmonic_nonneg N (D \ K) z a)
  rw [exactExitLaw_avoid_formula N D K hKD a b hb, exitsInto_probability_sum]
  apply (le_div_iff₀ hp).mpr
  nlinarith

end TorusCoverTime.Blocks.B
