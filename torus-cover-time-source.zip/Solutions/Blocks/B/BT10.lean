import Solutions.Blocks.B.BT10Closure

/-! Actual-walk B-T10 entry point; no probabilistic estimate is an input. -/
noncomputable section
namespace TorusCoverTime.Blocks.B

theorem bt10_actual_conclusion (u : ℝ) (hu : 0≤u) : BT10Conclusion u :=
  bt10_conclusion TorusCoverTime.Blocks.A.walk_model_regular (1/8192) u (by norm_num) (by norm_num) hu

end TorusCoverTime.Blocks.B
