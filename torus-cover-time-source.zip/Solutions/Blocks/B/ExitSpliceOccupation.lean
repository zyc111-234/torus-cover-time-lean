import Solutions.Blocks.B.ConditionedExitRestart

/-! Exact physical-time and occupation identities for replacing one stopped
segment. These identities retain the common future and its shifted clock. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

theorem recordJoin_nonexplosive (p : ℕ × WalkSample) {η : WalkSample}
    (hnon : Tendsto (jumpTime η) atTop atTop) :
    Tendsto (jumpTime (recordJoin p η)) atTop atTop := by
  apply (tendsto_add_atTop_iff_nat p.1).mp
  apply tendsto_atTop_mono (fun k => ?_) hnon
  rw [Nat.add_comm k p.1, recordJoin_jumpTime]
  exact le_add_of_nonneg_left (jumpTime_nonneg p.2 p.1)

theorem walk_indicator_intervalIntegrable (N : Size) (a x : Vertex N)
    (ω : WalkSample) (s t : ℝ) (hst : s ≤ t) :
    IntervalIntegrable (fun u => if walk N a ω u = x then (1 : ℝ) else 0) volume s t := by
  apply (intervalIntegrable_iff_integrableOn_Icc_of_le hst).mpr
  apply Integrable.of_bound
    ((measurable_walk_indicator_joint N a x).comp
      (measurable_const.prodMk measurable_id)).aestronglyMeasurable 1
  exact Eventually.of_forall fun u => by dsimp only [Function.comp_def, id_eq]; split_ifs <;> norm_num

theorem localTime_eq_intervalIntegral (N : Size) (a x : Vertex N) (ω : WalkSample)
    (t : ℝ) (ht : 0 ≤ t) :
    localTime N a ω t x = ∫ u in (0 : ℝ)..t, if walk N a ω u = x then (1 : ℝ) else 0 := by
  rw [localTime, intervalIntegral.integral_of_le ht, integral_Icc_eq_integral_Ioc]

theorem localTime_add_shift (N : Size) (a x : Vertex N) (ω : WalkSample)
    (s t : ℝ) (hs : 0 ≤ s) (ht : 0 ≤ t) :
    localTime N a ω (s+t) x = localTime N a ω s x +
      ∫ u in Icc 0 t, if walk N a ω (s+u) = x then (1 : ℝ) else 0 := by
  let f : ℝ → ℝ := fun u => if walk N a ω u = x then 1 else 0
  have hshift : (∫ u in Icc 0 t, f (s+u)) = ∫ u in s..(s+t), f u := by
    rw [integral_Icc_eq_integral_Ioc, ← intervalIntegral.integral_of_le ht]
    simpa only [add_zero] using intervalIntegral.integral_comp_add_left (a := 0) (b := t) f s
  rw [localTime_eq_intervalIntegral N a x ω _ (add_nonneg hs ht),
    localTime_eq_intervalIntegral N a x ω _ hs]
  change (∫ u in (0 : ℝ)..(s+t), f u) = (∫ u in (0 : ℝ)..s, f u) + ∫ u in Icc 0 t, f (s+u)
  rw [hshift]
  exact (intervalIntegral.integral_add_adjacent_intervals
    (walk_indicator_intervalIntegrable N a x ω 0 s hs)
    (walk_indicator_intervalIntegrable N a x ω s (s+t) (by linarith))).symm

theorem recordJoin_localTime_add (N : Size) (a x : Vertex N) (p : ℕ × WalkSample)
    (hp : ∀ j < p.1, 0 < (p.2 j).1) {η : WalkSample} (hη : ∀ j, 0 < (η j).1)
    (hnon : Tendsto (jumpTime η) atTop atTop) (t : ℝ) (ht : 0 ≤ t) :
    localTime N a (recordJoin p η) (excursionRecordDuration p+t) x =
      localTime N a (recordJoin p η) (excursionRecordDuration p) x +
        localTime N (exitRecordEndpoint N a p) η t x := by
  rw [localTime_add_shift N a x _ (excursionRecordDuration p) t (jumpTime_nonneg p.2 p.1) ht]
  congr 1
  apply setIntegral_congr_fun measurableSet_Icc
  intro u hu
  dsimp only
  rw [recordJoin_walk_future N a p hp hη hnon u hu.1]

theorem recordJoin_weighted_prefix (N : Size) (a : Vertex N) (U : Vertex N → ℝ)
    (p : ℕ × WalkSample) (hp : ∀ j < p.1, 0 < (p.2 j).1)
    {η : WalkSample} (hη : ∀ j, 0 < (η j).1) (hnon : Tendsto (jumpTime η) atTop atTop) :
    (∑ x, U x * localTime N a (recordJoin p η) (excursionRecordDuration p) x) =
      excursionRecordCost N a U p := by
  have htime : jumpTime (recordJoin p η) p.1 = excursionRecordDuration p := by
    simpa only [Nat.add_zero, jumpTime_zero, add_zero] using recordJoin_jumpTime p η 0
  simp_rw [← htime, localTime_jumpTime_eq_sum_holding N a _
    (recordJoin_pos p hp hη) (recordJoin_nonexplosive p hnon), Finset.mul_sum]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro j hj
  have hj' := Finset.mem_range.mp hj
  have hpos := A.position_eq_of_prefix N a p.1 (recordJoin_agrees p η) j hj'.le
  simp only [mul_ite, mul_zero, eq_comm, Finset.sum_ite_eq', Finset.mem_univ, if_true]
  rw [hpos]
  simp only [holdingTime, recordJoin_agrees p η j hj']

theorem recordJoin_weighted_occupation_add (N : Size) (a : Vertex N) (U : Vertex N → ℝ)
    (p : ℕ × WalkSample) (hp : ∀ j < p.1, 0 < (p.2 j).1)
    {η : WalkSample} (hη : ∀ j, 0 < (η j).1) (hnon : Tendsto (jumpTime η) atTop atTop)
    (t : ℝ) (ht : 0 ≤ t) :
    (∑ x, U x * localTime N a (recordJoin p η) (excursionRecordDuration p+t) x) =
      excursionRecordCost N a U p + ∑ x, U x * localTime N (exitRecordEndpoint N a p) η t x := by
  simp_rw [recordJoin_localTime_add N a _ p hp hη hnon t ht, mul_add]
  rw [Finset.sum_add_distrib, recordJoin_weighted_prefix N a U p hp hη hnon]

theorem finiteExit_weighted_occupation_eq_record (N : Size) (D : Finset (Vertex N))
    (a : Vertex N) (U : Vertex N → ℝ) :
    ∀ᵐ ω ∂walkLaw, (∑ x, U x * localTime N a ω (finiteExitDuration N D a ω) x) =
      excursionRecordCost N a U (finiteExitRecord N D a ω) := by
  filter_upwards [A.holding_positive_and_nonexplosive] with ω hω
  simp_rw [finiteExitDuration, localTime_jumpTime_eq_sum_holding N a _ hω.1 hω.2,
    Finset.mul_sum]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro j hj
  have hj' := Finset.mem_range.mp hj
  simp only [mul_ite, mul_zero, eq_comm, Finset.sum_ite_eq', Finset.mem_univ, if_true]
  rw [finiteExitRecord_position N D a ω j hj'.le]
  simp only [holdingTime, finiteExitRecord_agrees N D a ω j hj']

theorem recordJoin_same_future (N : Size) (a : Vertex N) (p q : ℕ × WalkSample)
    (hp : ∀ j < p.1, 0 < (p.2 j).1) (hq : ∀ j < q.1, 0 < (q.2 j).1)
    (he : exitRecordEndpoint N a p = exitRecordEndpoint N a q)
    {η : WalkSample} (hη : ∀ j, 0 < (η j).1) (hnon : Tendsto (jumpTime η) atTop atTop)
    (t : ℝ) (ht : 0 ≤ t) :
    walk N a (recordJoin p η) (excursionRecordDuration p+t) =
      walk N a (recordJoin q η) (excursionRecordDuration q+t) := by
  rw [recordJoin_walk_future N a p hp hη hnon t ht,
    recordJoin_walk_future N a q hq hη hnon t ht, he]

end TorusCoverTime.Blocks.B
