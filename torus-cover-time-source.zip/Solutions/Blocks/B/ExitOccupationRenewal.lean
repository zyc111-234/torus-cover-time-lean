import Solutions.Blocks.B.RootHitOccupation
import Solutions.Blocks.B.DiskExitExpectation
import Solutions.Blocks.B.DomainGreenOperator

/-! Integrable renewal identities for the actual occupation before a
specified exit. The complete unbounded exit word is retained. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

theorem first_direction_tail_law :
    walkLaw.map (fun ω : WalkSample => ((ω 0).2, walkTail ω)) =
      (uniformOn (Set.univ : Set (Fin 4))).prod walkLaw := by
  have hd : walkLaw.map (fun ω : WalkSample => (ω 0).2) =
      uniformOn (Set.univ : Set (Fin 4)) := by
    rw [show (fun ω : WalkSample => (ω 0).2) = Prod.snd ∘ (fun ω : WalkSample => ω 0) from rfl,
      ← Measure.map_map measurable_snd (measurable_pi_apply 0),
      show walkLaw.map (fun ω : WalkSample => ω 0) = stepLaw from
        Measure.infinitePi_map_eval (fun _ : ℕ => stepLaw) 0,
      stepLaw, Measure.map_snd_prod, measure_univ, one_smul]
  have hi : IndepFun (fun ω : WalkSample => (ω 0).2) walkTail walkLaw := by
    simpa only [Function.comp_def, id_eq] using first_step_independent_tail.comp measurable_snd measurable_id
  rw [hi.map_prod_eq_prod_map_map (measurable_pi_apply 0).snd.aemeasurable measurable_walkTail.aemeasurable,
    walkTail_law, hd]

theorem integrable_uniform_direction (f : Fin 4 → ℝ) :
    Integrable f (uniformOn (Set.univ : Set (Fin 4))) := by
  apply Integrable.of_bound (measurable_of_finite f).aestronglyMeasurable (∑ d, ‖f d‖)
  exact Eventually.of_forall fun d => Finset.single_le_sum (fun i _ => norm_nonneg (f i)) (Finset.mem_univ d)

theorem first_direction_tail_integrable (F : Fin 4 → WalkSample → ℝ)
    (hm : ∀ d, Measurable (F d)) (hi : ∀ d, Integrable (F d) walkLaw) :
    Integrable (fun ω : WalkSample => F (ω 0).2 (walkTail ω)) walkLaw := by
  have hF : Measurable (fun p : Fin 4 × WalkSample => F p.1 p.2) :=
    measurable_from_prod_countable_right hm
  have hp := (integrable_prod_iff hF.aestronglyMeasurable).mpr
    ⟨Eventually.of_forall hi, integrable_uniform_direction _⟩
  have hmp : MeasurePreserving (fun ω : WalkSample => ((ω 0).2, walkTail ω))
      walkLaw ((uniformOn (Set.univ : Set (Fin 4))).prod walkLaw) :=
    ⟨(measurable_pi_apply 0).snd.prodMk measurable_walkTail, first_direction_tail_law⟩
  exact hmp.integrable_comp_of_integrable hp

theorem integral_first_direction_tail (F : Fin 4 → WalkSample → ℝ)
    (hm : ∀ d, Measurable (F d)) (hi : ∀ d, Integrable (F d) walkLaw) :
    (∫ ω, F (ω 0).2 (walkTail ω) ∂walkLaw) = (∑ d, ∫ ω, F d ω ∂walkLaw)/4 := by
  have hF : Measurable (fun p : Fin 4 × WalkSample => F p.1 p.2) :=
    measurable_from_prod_countable_right hm
  have hp := (integrable_prod_iff hF.aestronglyMeasurable).mpr
    ⟨Eventually.of_forall hi, integrable_uniform_direction _⟩
  rw [← integral_map ((measurable_pi_apply 0).snd.prodMk measurable_walkTail).aemeasurable
    hF.aestronglyMeasurable, first_direction_tail_law, integral_prod _ hp, integral_real_uniform_direction]

def exitPotentialWeight (N : Size) (D : Finset (Vertex N)) (b : Vertex N)
    (U : Vertex N → ℝ) (a : Vertex N) (ω : WalkSample) : ℝ :=
  if ω ∈ exitsThrough N D a b then holdingPotentialSum N U a ω (finiteExitIndex N D a ω) else 0

theorem measurable_exitPotentialWeight (N : Size) (D : Finset (Vertex N)) (b : Vertex N)
    (U : Vertex N → ℝ) (a : Vertex N) : Measurable (exitPotentialWeight N D b U a) := by
  have hm : Measurable (fun p : WalkSample × ℕ => holdingPotentialSum N U a p.1 p.2) :=
    measurable_from_prod_countable_left (measurable_holdingPotentialSum N U a)
  have ht := hm.comp (measurable_id.prodMk (measurable_finiteExitIndex N D a))
  have hi := ht.indicator (measurableSet_exitsThrough N D a b)
  have he : exitPotentialWeight N D b U a = (exitsThrough N D a b).indicator
      ((fun p : WalkSample × ℕ => holdingPotentialSum N U a p.1 p.2) ∘
        (fun ω : WalkSample => (id ω, finiteExitIndex N D a ω))) := by
    funext ω
    rfl
  rw [he]
  exact hi

theorem exitPotentialWeight_nonneg (N : Size) (D : Finset (Vertex N)) (b : Vertex N)
    (U : Vertex N → ℝ) (hU : ∀ z, 0 ≤ U z) (a : Vertex N) (ω : WalkSample) :
    0 ≤ exitPotentialWeight N D b U a ω := by
  unfold exitPotentialWeight
  split_ifs
  · exact holdingPotentialSum_nonneg N U hU a ω _
  · exact le_rfl

theorem exitPotentialWeight_bound (N : Size) (D : Finset (Vertex N)) (b : Vertex N)
    (U : Vertex N → ℝ) (hU : ∀ z, 0 ≤ U z) (a : Vertex N) (ω : WalkSample) :
    ‖exitPotentialWeight N D b U a ω‖ ≤ (∑ z, U z)*finiteExitDuration N D a ω := by
  rw [Real.norm_eq_abs, abs_of_nonneg (exitPotentialWeight_nonneg N D b U hU a ω)]
  have hC : 0 ≤ ∑ z, U z := Finset.sum_nonneg fun z _ => hU z
  unfold exitPotentialWeight
  split_ifs
  · unfold holdingPotentialSum finiteExitDuration jumpTime
    rw [Finset.mul_sum]
    exact Finset.sum_le_sum fun j _ => mul_le_mul_of_nonneg_right
      (Finset.single_le_sum (fun z _ => hU z) (Finset.mem_univ _)) (le_max_right _ _)
  · exact mul_nonneg hC (jumpTime_nonneg ω _)

theorem disk_exitPotentialWeight_integrable (N : Size) (c : Vertex N) (R : ℝ)
    (hR : 0 ≤ R) (hsmall : 2*(R+1) < N.val) (b : Vertex N)
    (U : Vertex N → ℝ) (hU : ∀ z, 0 ≤ U z) (a : Vertex N) :
    Integrable (exitPotentialWeight N (torusDisk N c R) b U a) walkLaw := by
  have hi := (disk_finiteExitDuration_integrable N c R hR hsmall a).const_mul (∑ z, U z)
  apply hi.mono' (measurable_exitPotentialWeight N _ b U a).aestronglyMeasurable
  exact Eventually.of_forall (exitPotentialWeight_bound N _ b U hU a)

theorem exitPotentialWeight_boundary (N : Size) (D : Finset (Vertex N)) (b : Vertex N)
    (U : Vertex N → ℝ) (a : Vertex N) (ha : a ∉ D) (ω : WalkSample) :
    exitPotentialWeight N D b U a ω = 0 := by
  have hn : finiteExitIndex N D a ω = 0 := finiteExitIndex_of_exit_word N D a a ω 0
    ⟨ha, by simp [position], by intro i; exact Fin.elim0 i⟩
  simp only [exitPotentialWeight, hn, holdingPotentialSum, Finset.range_zero, Finset.sum_empty, ite_self]

theorem exitPotentialWeight_first_step (N : Size) (D : Finset (Vertex N)) (b : Vertex N)
    (U : Vertex N → ℝ) (a : Vertex N) (ha : a ∈ D) (ω : WalkSample) :
    exitPotentialWeight N D b U a ω =
      U a*(if ω ∈ exitsThrough N D a b then holdingTime ω 0 else 0) +
        exitPotentialWeight N D b U (a+direction N (ω 0).2) (walkTail ω) := by
  by_cases he : ω ∈ exitsThrough N D a b
  · have ht := (exitsThrough_shift N D a b ha ω).mp he
    obtain ⟨n,hn⟩ := ht
    have heword := (exitsThroughAt_succ_shift N D a b ω n).mpr ⟨ha,hn⟩
    have hi := finiteExitIndex_of_exit_word N D a b ω (n+1) heword
    have hit := finiteExitIndex_of_exit_word N D (a+direction N (ω 0).2) b (walkTail ω) n hn
    simp only [exitPotentialWeight, if_pos he, if_pos (show walkTail ω ∈
      exitsThrough N D (a+direction N (ω 0).2) b from ⟨n,hn⟩), hi, hit,
      holdingPotentialSum_succ_shift]
  · have ht := mt (exitsThrough_shift N D a b ha ω).mpr he
    simp only [exitPotentialWeight, if_neg he, if_neg ht, mul_zero, zero_add]

theorem integral_holdingTime_on_exit (N : Size) (D : Finset (Vertex N)) (a b : Vertex N) (j : ℕ) :
    (∫ ω, if ω ∈ exitsThrough N D a b then holdingTime ω j else 0 ∂walkLaw) =
      exitHarmonic N D b a := by
  let E := skeletonSample ⁻¹' exitsThrough N D a b
  have hE := (measurableSet_exitsThrough N D a b).preimage measurable_skeletonSample
  have hh := holdingTime_lintegral_direction_event j E hE
  rw [exitsThrough_direction_preimage] at hh
  have hfun (ω : WalkSample) : (if walkDirections ω ∈ E then ENNReal.ofReal (holdingTime ω j) else 0) =
      ENNReal.ofReal (if ω ∈ exitsThrough N D a b then holdingTime ω j else 0) := by
    have he : walkDirections ω ∈ E ↔ ω ∈ exitsThrough N D a b := by
      change ω ∈ walkDirections ⁻¹' E ↔ _
      rw [exitsThrough_direction_preimage]
    rw [he]
    split_ifs <;> simp
  simp_rw [hfun] at hh
  have hm : Measurable (fun ω => if ω ∈ exitsThrough N D a b then holdingTime ω j else 0) :=
    (measurable_holdingTime j).ite (measurableSet_exitsThrough N D a b) measurable_const
  rw [integral_eq_lintegral_of_nonneg_ae
    (Eventually.of_forall fun ω => by split_ifs <;> simp [holdingTime]) hm.aestronglyMeasurable, hh]
  rfl

end TorusCoverTime.Blocks.B
