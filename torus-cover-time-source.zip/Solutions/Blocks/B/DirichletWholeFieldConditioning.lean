import Solutions.Blocks.B.DirichletConditionedField

/-! The field used in B.30 is a version of the actual full-field conditional
law, simultaneously for every spatial coordinate and every scale functional. -/

noncomputable section
open MeasureTheory ProbabilityTheory
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

theorem dirichletConditionedField_zero_noise (N : Size) (root : Vertex N)
    (E : Finset (Vertex N)) (hroot : root∉E) (x : Vertex N) (hV : 0<dirichletClockLS N root E x) :
    dirichletConditionedField N root E x 0=dirichletResidualNoise N root ∅ E x := by
  funext ξ z
  have hf0 : dirichletFieldLS N root ∅ ξ x=0 := by
    rw [dirichletFieldLS,Blocks.C.C4.pinnedDomainField_boundary N root ∅ ξ x (Finset.notMem_empty x),zero_div]
  have hv0 : dirichletClockLS N root ∅ x=0 := by
    rw [dirichletClockLS,Blocks.C.C4.pinnedDomainKernel_boundary N root ∅ x x (Finset.notMem_empty x),zero_div]
  rw [dirichletResidualNoise,scalarRegressionResidual,← dirichletResidualSlope,
    dirichletLSResidual_eq N root ∅ E (Finset.empty_subset _) hroot,
    dirichletResidualSlope_eq N root ∅ E (Finset.empty_subset _) hroot,hf0,hv0]
  unfold dirichletConditionedField dirichletRootProfileLS
  field_simp [hV.ne']
  <;> ring

theorem dirichletConditionedField_noise_indep (N : Size) (root : Vertex N)
    (E : Finset (Vertex N)) (hroot : root∉E) (x : Vertex N) (hV : 0<dirichletClockLS N root E x) :
    IndepFun (dirichletConditionedField N root E x 0)
      (fun ξ => dirichletFieldLS N root E ξ x) (finiteFieldLaw N) := by
  rw [dirichletConditionedField_zero_noise N root E hroot x hV]
  exact dirichletResidualNoise_indep_endpoint N root ∅ E (Finset.empty_subset _) hroot x hV

theorem dirichletConditionedField_translate (N : Size) (root : Vertex N)
    (E : Finset (Vertex N)) (x : Vertex N) (t : ℝ) (ξ : FiniteFieldSample N) :
    (fun z => dirichletConditionedField N root E x 0 ξ z+dirichletRootProfileLS N root E x z*t)=
      dirichletConditionedField N root E x t ξ := by
  funext z
  unfold dirichletConditionedField
  ring

theorem dirichletConditionedField_condExp_functional (N : Size) (root : Vertex N)
    (E : Finset (Vertex N)) (hroot : root∉E) (x : Vertex N) (hV : 0<dirichletClockLS N root E x)
    (F : (Vertex N → ℝ) → ℝ) (hF : Measurable F) (C : ℝ) (hC : ∀ f, ‖F f‖≤C) :
    (finiteFieldLaw N)[fun ξ => F (dirichletFieldLS N root E ξ) |
      MeasurableSpace.comap (fun ξ => dirichletFieldLS N root E ξ x) inferInstance] =ᵐ[finiteFieldLaw N]
        fun ξ => ∫ η, F (dirichletConditionedField N root E x (dirichletFieldLS N root E ξ x) η)
          ∂finiteFieldLaw N := by
  let X := fun ξ => dirichletFieldLS N root E ξ x
  let Y := dirichletConditionedField N root E x 0
  let f := fun v : ℝ × (Vertex N → ℝ) => F (fun z => v.2 z+dirichletRootProfileLS N root E x z*v.1)
  have hX : Measurable X := dirichletFieldLS_measurable N root E x
  have hY : Measurable Y := dirichletConditionedField_measurable N root E x 0
  have hf : Measurable f := by apply hF.comp; fun_prop
  have hh := Blocks.C.independent_condExp_bounded (finiteFieldLaw N) hX hY
    (dirichletConditionedField_noise_indep N root E hroot x hV).symm hf
    (fun v => hC (fun z => v.2 z+dirichletRootProfileLS N root E x z*v.1))
  have he : (fun ξ => f (X ξ,Y ξ))=fun ξ => F (dirichletFieldLS N root E ξ) := by
    funext ξ
    dsimp only [f,X,Y]
    rw [dirichletConditionedField_translate]
    apply congrArg F
    funext z
    exact dirichletConditionedField_reconstruct N root E x z ξ
  rw [he] at hh
  filter_upwards [hh] with ξ hξ
  rw [hξ]
  have hi := integral_map (μ := finiteFieldLaw N) (f := fun z => f (X ξ,z)) hY.aemeasurable
    ((hf.comp (measurable_const.prodMk measurable_id)).aestronglyMeasurable)
  convert hi using 1
  apply integral_congr_ae
  exact Filter.Eventually.of_forall (fun η => by
    dsimp only [f,X,Y]
    rw [dirichletConditionedField_translate])

end TorusCoverTime.Blocks.B
