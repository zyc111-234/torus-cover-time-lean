import Solutions.Blocks.B.ExitEventRestart

/-! The event of k successive complete inner traversals, all made before
the original outer exit b. Each recursion uses the actual stopped tail. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

def nestedTraversalEvent (N : Size) (O I J : Finset (Vertex N)) (b : Vertex N) :
    ℕ → Vertex N → Set WalkSample
  | 0, a => exitsThrough N O a b
  | k+1, a => exitRestartEvent N (O\I) a (fun z =>
      if z ∈ I then exitRestartEvent N J z (nestedTraversalEvent N O I J b k) else ∅)

theorem nestedTraversalEvent_measurable (N : Size) (O I J : Finset (Vertex N))
    (b : Vertex N) (k : ℕ) (a : Vertex N) :
    MeasurableSet (nestedTraversalEvent N O I J b k a) := by
  induction k generalizing a with
  | zero => exact measurableSet_exitsThrough N O a b
  | succ k ih =>
    apply exitRestartEvent_measurable
    intro z
    split_ifs
    · exact exitRestartEvent_measurable N J z _ ih
    · exact MeasurableSet.empty

theorem nestedTraversalEvent_subset_exit (N : Size) (O I J : Finset (Vertex N))
    (hJO : J ⊆ O) (b : Vertex N) (k : ℕ) (a : Vertex N) :
    nestedTraversalEvent N O I J b k a ⊆ exitsThrough N O a b := by
  induction k generalizing a with
  | zero => exact Subset.rfl
  | succ k ih =>
    apply exitRestartEvent_subset_exit N (O\I) O Finset.sdiff_subset
    intro z
    split_ifs
    · exact exitRestartEvent_subset_exit N J O hJO z b _ ih
    · exact empty_subset _

theorem nestedTraversalEvent_probability_succ (N : Size) (O I J : Finset (Vertex N))
    (hO : ∃ z : Vertex N, z ∉ O) (hJO : J ⊆ O) (b : Vertex N) (k : ℕ) (a : Vertex N) :
    walkLaw.real (nestedTraversalEvent N O I J b (k+1) a) =
      ∑ z ∈ I, exitHarmonic N (O\I) z a *
        ∑ y, exitHarmonic N J y z * walkLaw.real (nestedTraversalEvent N O I J b k y) := by
  have hA : ∃ z : Vertex N, z ∉ O\I :=
    hO.imp fun z hz h => hz (Finset.mem_sdiff.mp h).1
  have hJ : ∃ z : Vertex N, z ∉ J := hO.imp fun z hz h => hz (hJO h)
  rw [nestedTraversalEvent,exitRestartEvent_probability N (O\I) hA]
  · have he (z : Vertex N) :
        exitHarmonic N (O\I) z a * walkLaw.real
          (if z ∈ I then exitRestartEvent N J z (nestedTraversalEvent N O I J b k) else ∅) =
        if z ∈ I then exitHarmonic N (O\I) z a *
          ∑ y, exitHarmonic N J y z * walkLaw.real (nestedTraversalEvent N O I J b k y) else 0 := by
      split_ifs
      · rw [exitRestartEvent_probability N J hJ _ _ (nestedTraversalEvent_measurable N O I J b k)]
      · simp
    simp_rw [he]
    rw [← Finset.sum_filter]
    congr 1
    ext z
    simp
  · intro z
    split_ifs
    · exact exitRestartEvent_measurable N J z _ (nestedTraversalEvent_measurable N O I J b k)
    · exact MeasurableSet.empty

theorem outer_exit_harmonic_inner_average (N : Size) (O J : Finset (Vertex N))
    (hO : O ≠ Finset.univ) (hJO : J ⊆ O) (b z : Vertex N) :
    (∑ y, exitHarmonic N J y z * exitHarmonic N O b y) = exitHarmonic N O b z := by
  have hJ : J ≠ Finset.univ := by
    intro he
    exact hO (Finset.eq_univ_of_forall fun x => hJO (he ▸ Finset.mem_univ x))
  have he := congrFun (harmonic_exit_representation N J hJ (exitHarmonic N O b)
    (fun y hy => exitHarmonic_generator N O b y (hJO hy))) z
  simpa only [exitExtension,mul_comm] using he.symm

theorem annular_hit_mass_of_conditional (N : Size) (O I : Finset (Vertex N))
    (hO : O ≠ Finset.univ) (hIO : I ⊆ O) (a b : Vertex N) (hb : b ∉ O)
    (hp : 0 < exitHarmonic N O b a) (p : ℝ)
    (hhit : p ≤ 1-(exactExitLaw N O a b).real (exitsAvoidingCore N O I a)) :
    p*exitHarmonic N O b a ≤ ∑ z ∈ I, exitHarmonic N (O\I) z a * exitHarmonic N O b z := by
  rw [exactExitLaw_avoid_formula N O I hIO a b hb] at hhit
  have he := exitHarmonic_annulus_decomposition N O I hO hIO a b hb
  have hm := mul_le_mul_of_nonneg_right hhit hp.le
  rw [sub_mul,one_mul,div_mul_cancel₀ _ hp.ne'] at hm
  simp_rw [mul_comm (exitHarmonic N O b _)] at he
  linarith

/-- The geometric tail is deduced from actual one-step kernels, with no
independent-geometric-count assumption. S supports the inner exit law. -/
theorem nestedTraversalEvent_geometric_mass (N : Size) (O I J : Finset (Vertex N))
    (hO : O ≠ Finset.univ) (hJO : J ⊆ O) (b a : Vertex N) (S : Set (Vertex N))
    (hsupport : ∀ z ∈ I, ∀ y, y ∉ S → exitHarmonic N J y z = 0)
    (p r : ℝ) (hp : 0 ≤ p) (hr : r ≤ 1)
    (hfirst : p*exitHarmonic N O b a ≤
      ∑ z ∈ I, exitHarmonic N (O\I) z a * exitHarmonic N O b z)
    (hreturn : ∀ y ∈ S, (1-r)*exitHarmonic N O b y ≤
      ∑ z ∈ I, exitHarmonic N (O\I) z y * exitHarmonic N O b z)
    (k : ℕ) :
    p*(1-r)^k*exitHarmonic N O b a ≤
      walkLaw.real (nestedTraversalEvent N O I J b (k+1) a) := by
  have hO' : ∃ z : Vertex N, z ∉ O := by
    by_contra hn
    push Not at hn
    exact hO (Finset.eq_univ_of_forall hn)
  have hstep (k : ℕ) (c : ℝ) (hc : 0 ≤ c)
      (hk : ∀ y ∈ S, c*exitHarmonic N O b y ≤
        walkLaw.real (nestedTraversalEvent N O I J b k y)) (x : Vertex N) :
      c*(∑ z ∈ I, exitHarmonic N (O\I) z x * exitHarmonic N O b z) ≤
        walkLaw.real (nestedTraversalEvent N O I J b (k+1) x) := by
    rw [nestedTraversalEvent_probability_succ N O I J hO' hJO,
      Finset.mul_sum]
    apply Finset.sum_le_sum
    intro z hz
    have hy : c*exitHarmonic N O b z ≤
        ∑ y, exitHarmonic N J y z * walkLaw.real (nestedTraversalEvent N O I J b k y) := by
      rw [← outer_exit_harmonic_inner_average N O J hO hJO b z,Finset.mul_sum]
      apply Finset.sum_le_sum
      intro y _
      by_cases hyS : y ∈ S
      · simpa only [mul_left_comm c] using
          mul_le_mul_of_nonneg_left (hk y hyS) (exitHarmonic_nonneg N J y z)
      · rw [hsupport z hz y hyS]
        simp
    simpa only [mul_left_comm c] using
      mul_le_mul_of_nonneg_left hy (exitHarmonic_nonneg N (O\I) z x)
  have hrec : ∀ k, ∀ y ∈ S, (1-r)^k*exitHarmonic N O b y ≤
      walkLaw.real (nestedTraversalEvent N O I J b k y) := by
    intro k
    induction k with
    | zero => intro y _; simp [nestedTraversalEvent,exitHarmonic]
    | succ k ih =>
      intro y hy
      have hpow : 0 ≤ (1-r)^k := pow_nonneg (sub_nonneg.mpr hr) k
      have hh := (mul_le_mul_of_nonneg_left (hreturn y hy) hpow).trans (hstep k _ hpow ih y)
      simpa only [pow_succ,mul_assoc] using hh
  have hpow : 0 ≤ (1-r)^k := pow_nonneg (sub_nonneg.mpr hr) k
  have hh := (mul_le_mul_of_nonneg_left hfirst hpow).trans (hstep k _ hpow (hrec k) a)
  simpa only [mul_left_comm, mul_assoc, mul_comm p] using hh

end TorusCoverTime.Blocks.B
