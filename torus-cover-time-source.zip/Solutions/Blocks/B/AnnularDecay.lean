import Solutions.Blocks.B.AnnularDifferenceBounds
import Solutions.Blocks.B.AnnularPartition

/-! Summation by parts yields the uniform cubic spatial envelope for each frequency scale. -/

noncomputable section
open scoped BigOperators
namespace TorusCoverTime.Blocks.B

lemma exists_axis_character_gap (N : Size) (z : Vertex N) :
    ∃ axis : Bool, periodicDistance z 0 / N.val ≤ ‖finiteCharacter N (-axisUnit N axis) z - 1‖ := by
  have hN : 0 < (N.val : ℝ) := lt_trans zero_lt_one (size_real_gt_one N)
  have hd := periodicDistance_le_coordinate_sum N z
  have h1 := (coordinateDistance_zero_bounds N z.1).1
  have h2 := (coordinateDistance_zero_bounds N z.2).1
  by_cases hx : coordinateDistance z.2 0 ≤ coordinateDistance z.1 0
  · refine ⟨false, ?_⟩
    have hc : 4 * coordinateDistance z.1 0 / N.val ≤
        ‖finiteCharacter N (-axisUnit N false) z - 1‖ := by
      simpa [axisUnit, finiteCharacter, coordinateDistance_neg_zero] using
        coordinateCharacter_distance_lower N (-z.1)
    apply le_trans _ hc
    apply (div_le_div_iff_of_pos_right hN).mpr
    linarith
  · refine ⟨true, ?_⟩
    have hc : 4 * coordinateDistance z.2 0 / N.val ≤
        ‖finiteCharacter N (-axisUnit N true) z - 1‖ := by
      simpa [axisUnit, finiteCharacter, coordinateDistance_neg_zero] using
        coordinateCharacter_distance_lower N (-z.2)
    apply le_trans _ hc
    apply (div_le_div_iff_of_pos_right hN).mpr
    linarith

lemma annularArray_spatial_envelope (ds : List (Fin 4)) :
    ∃ C : ℝ, 0 < C ∧ ∀ N : Size, ∀ R : ℝ, 1 / 4 ≤ R →
      ∀ z : Vertex N, 0 < periodicDistance z 0 →
      ‖periodicTransform N (annularArray N R ds) z‖ ≤
        C * (R / N.val) ^ ds.length * min 1 (1 / (R / N.val * periodicDistance z 0) ^ 3) := by
  obtain ⟨C0, hC0, hb0⟩ := annularArray_l1_difference_bound ds 0
  obtain ⟨C3, hC3, hb3⟩ := annularArray_l1_difference_bound ds 3
  let C := max C0 C3
  refine ⟨C, hC0.trans_le (le_max_left _ _), ?_⟩
  intro N R hR z hd
  have hRp : 0 < R := by linarith
  have hN : 0 < (N.val : ℝ) := lt_trans zero_lt_one (size_real_gt_one N)
  have hscale : 0 < R / N.val := div_pos hRp hN
  have hC : 0 < C := hC0.trans_le (le_max_left _ _)
  by_cases hlarge : 2 ≤ R / N.val
  · rw [annularArray_zero_large_scale N R hlarge ds]
    simp only [periodicTransform, Pi.zero_apply, zero_mul, Finset.sum_const_zero, norm_zero]
    positivity
  · have ha : R / N.val ≤ 2 := le_of_lt (lt_of_not_ge hlarge)
    obtain ⟨axis, hgap⟩ := exists_axis_character_gap N z
    have hgapp : 0 < ‖finiteCharacter N (-axisUnit N axis) z - 1‖ := (div_pos hd hN).trans_le hgap
    have hne : finiteCharacter N (-axisUnit N axis) z ≠ 1 := by
      intro he
      simp [he] at hgapp
    have hsmall : ‖periodicTransform N (annularArray N R ds) z‖ ≤ C * (R / N.val) ^ ds.length := by
      apply (periodicTransform_norm_le N _ z).trans
      have h := hb0 N R hR ha axis
      simp only [Function.iterate_zero, id_eq, pow_zero, div_one] at h
      exact h.trans (mul_le_mul_of_nonneg_right (le_max_left _ _) (by positivity))
    have hfar : ‖periodicTransform N (annularArray N R ds) z‖ ≤
        C * (R / N.val) ^ ds.length * (1 / (R / N.val * periodicDistance z 0) ^ 3) := by
      calc
        _ ≤ (∑ k : Vertex N, ‖((frequencyDifference N (axisUnit N axis))^[3] (annularArray N R ds)) k‖) /
            ‖finiteCharacter N (-axisUnit N axis) z - 1‖ ^ 3 :=
          periodicTransform_abel_bound N _ z _ 3 hne
        _ ≤ (C3 * (R / N.val) ^ ds.length / R ^ 3) /
            (periodicDistance z 0 / N.val) ^ 3 := by
          apply div_le_div₀ (by positivity) (hb3 N R hR ha axis) (by positivity)
          exact pow_le_pow_left₀ (by positivity) hgap 3
        _ = C3 * (R / N.val) ^ ds.length * (1 / (R / N.val * periodicDistance z 0) ^ 3) := by
          field_simp
        _ ≤ _ := mul_le_mul_of_nonneg_right
          (mul_le_mul_of_nonneg_right (le_max_right _ _) (by positivity)) (by positivity)
    rw [mul_min_of_nonneg _ _ (by positivity : 0 ≤ C * (R / N.val) ^ ds.length), mul_one]
    exact le_min hsmall hfar

end TorusCoverTime.Blocks.B
