import Solutions.Blocks.B.BT9ShiftedGreen
import Solutions.Blocks.B.BT9Algebra
import Solutions.Blocks.B.BT9PairProduct

/-! Actual annular geometry, including both diagonal and off-diagonal
conditioned Green estimates. Constants are uniform in the torus and endpoints. -/
noncomputable section
open MeasureTheory ProbabilityTheory Filter Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

def bt9MatrixConstant : ℝ := 8+2*(r6GreenErrorConstant/g)
def bt9ParameterConstant : ℝ := 8*bt9MatrixConstant+2

theorem bt9MatrixConstant_ge_eight : 8 ≤ bt9MatrixConstant := by
  have hg : 0 < g := by unfold g; positivity
  unfold bt9MatrixConstant
  linarith [div_nonneg r6GreenErrorConstant_pos.le hg.le]

theorem bt9ParameterConstant_pos : 0 < bt9ParameterConstant := by
  unfold bt9ParameterConstant
  linarith [bt9MatrixConstant_ge_eight]

theorem bt9_scale_ratio_limit (γ : ℝ) (hγ1 : γ < 1) :
    Tendsto (fun q : ℝ => q^γ/q) atTop (𝓝 0) := by
  have ht := tendsto_rpow_neg_atTop (sub_pos.mpr hγ1)
  apply ht.congr'
  filter_upwards [eventually_gt_atTop (0:ℝ)] with q hq
  rw [show -(1-γ) = γ-1 by ring, Real.rpow_sub hq, Real.rpow_one]

theorem bt9_parameter_small_errors (γ : ℝ) (hγ : 0 < γ) (hγ1 : γ < 1) :
    ∀ᶠ q : ℝ in atTop,
      1 ≤ q ∧ 1 ≤ q^γ ∧ Real.log 8 ≤ q^γ ∧
      bt9MatrixConstant*q^γ ≤ q/16 ∧
      bt9ParameterConstant*(q^γ/q) ≤ 1/2 ∧
      diskExitOscillationConstant*Real.exp (-diskExitOscillationExponent*q^γ) ≤ 1/q := by
  have hm := (bt9_scale_ratio_limit γ hγ1).const_mul bt9MatrixConstant
  have hp := (bt9_scale_ratio_limit γ hγ1).const_mul bt9ParameterConstant
  simp only [mul_zero] at hm hp
  filter_upwards [r8_single_parameter_small_errors γ hγ hγ1,
    hm.eventually_le_const (by norm_num : (0:ℝ) < 1/16),
    hp.eventually_le_const (by norm_num : (0:ℝ) < 1/2)] with q hq hm hp
  refine ⟨hq.1, hq.2.1, hq.2.2.1, ?_, hp, hq.2.2.2.2.2.2⟩
  have hq0 : 0 < q := by linarith [hq.1]
  have he := (div_le_iff₀ hq0).mp (show bt9MatrixConstant*q^γ/q ≤ 1/16 by simpa only [mul_div_assoc] using hm)
  linarith

theorem bt9_site_geometry (N : Size) (c z : Vertex N) (q : ℝ)
    (hcz : c ≠ z) (hzq : Real.log (periodicDistance c z) < q) :
    0 < periodicDistance c z ∧ z ∈ torusDisk N c (Real.exp q) := by
  have hd : 0 < periodicDistance c z := by
    have hd := periodicDistance_nonzero_ge_one N (c-z) (sub_ne_zero.mpr hcz)
    rw [periodicDistance_sub_zero] at hd
    linarith
  refine ⟨hd, (mem_torusDisk N c z _).mpr ?_⟩
  rw [periodicDistance_comm z c]
  exact (Real.exp_log hd).symm.trans_lt (Real.exp_lt_exp.mpr hzq)

theorem bt9_green_offdiagonal_upper (N : Size) (c z : Vertex N) (q h : ℝ)
    (hq : 0 ≤ q) (hh : Real.log 8 ≤ h) (hsmall : 2*(Real.exp (q+2*h)+1) < N.val)
    (hcz : c ≠ z) (hlo : q-2 ≤ Real.log (periodicDistance c z))
    (hz : z ∈ torusDisk N c (Real.exp q)) :
    diskGreen N c (Real.exp (q+2*h)) c z/g ≤ 2*h+2+r6GreenErrorConstant/g ∧
    diskGreen N c (Real.exp (q+2*h)) z c/g ≤ 2*h+2+r6GreenErrorConstant/g := by
  have hg : 0 < g := by unfold g; positivity
  have hh0 : 0 ≤ h := (Real.log_nonneg (by norm_num : (1:ℝ) ≤ 8)).trans hh
  have hR : 1 ≤ Real.exp (q+2*h) := Real.one_le_exp_iff.mpr (by linarith)
  have hscale : 2*Real.exp q ≤ Real.exp (q+2*h) := by
    have he : 2 ≤ Real.exp (2*h) := by
      have hl : Real.log 2 ≤ 2*h := by
        have ht := Real.log_le_log (by norm_num : (0:ℝ) < 2) (by norm_num : (2:ℝ) ≤ 8)
        linarith
      simpa only [Real.exp_log (by norm_num : (0:ℝ) < 2)] using Real.exp_le_exp.mpr hl
    rw [Real.exp_add]
    nlinarith [Real.exp_pos q]
  have hcD : c ∈ torusDisk N c (Real.exp (q+2*h)) :=
    (mem_torusDisk N c c _).mpr (by rw [periodicDistance_self_zero]; positivity)
  have hzD : z ∈ torusDisk N c (Real.exp (q+2*h)) :=
    (mem_torusDisk N c z _).mpr (by have := (mem_torusDisk N c z _).mp hz; linarith [Real.exp_pos q])
  have hzR : periodicDistance z c ≤ Real.exp (q+2*h)/2 := by
    have := (mem_torusDisk N c z _).mp hz
    linarith
  have hcR : periodicDistance c c ≤ Real.exp (q+2*h)/2 := by rw [periodicDistance_self_zero]; positivity
  have hd : 0 < periodicDistance c z := by
    have ht := periodicDistance_nonzero_ge_one N (c-z) (sub_ne_zero.mpr hcz)
    rw [periodicDistance_sub_zero] at ht
    linarith
  have he₁ := (abs_le.mp (diskGreen_offdiagonal_log_error N c _ hR hsmall c z hcD hzR hcz)).2
  have he₂ := (abs_le.mp (diskGreen_offdiagonal_log_error N c _ hR hsmall z c hzD hcR hcz.symm)).2
  rw [periodicDistance_comm z c] at he₂
  rw [Real.log_div (Real.exp_pos _).ne' hd.ne', Real.log_exp] at he₁ he₂
  have hC : diskGreenLogErrorConstant ≤ r6GreenErrorConstant := by
    unfold r6GreenErrorConstant
    have := mul_nonneg hg.le (Real.log_nonneg (by norm_num : (1:ℝ) ≤ 3))
    linarith
  have hlog := mul_le_mul_of_nonneg_left hlo hg.le
  constructor <;> apply (div_le_iff₀ hg).mpr <;> rw [add_mul, div_mul_cancel₀ _ hg.ne'] <;> nlinarith

theorem bt9_conditioned_diagonal (N : Size) (c : Vertex N) (R : ℝ) (b x : Vertex N)
    (hx : 0 < exitHarmonic N (torusDisk N c R) b x) :
    conditionedDiskGreen N c R b x x = diskGreen N c R x x := by
  unfold conditionedDiskGreen
  exact mul_div_cancel_right₀ _ hx.ne'

theorem bt9_conditioned_normalize (N : Size) (c : Vertex N) (R : ℝ) (b a x : Vertex N) :
    conditionedDiskGreen N c R b a x/g = (diskGreen N c R a x/g)*
      (exitHarmonic N (torusDisk N c R) b x/exitHarmonic N (torusDisk N c R) b a) := by
  unfold conditionedDiskGreen
  ring

end TorusCoverTime.Blocks.B
