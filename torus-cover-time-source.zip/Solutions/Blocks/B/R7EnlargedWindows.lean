import Solutions.Blocks.B.R7IterationParameters

/-! Uniform control of all ceil(L^2) enlarged physical windows. The n factor
from summing the crude terminal bound is retained in the remainder estimate. -/

noncomputable section
open MeasureTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

def r7IterationLength (N : Size) : ℕ := ⌈(logSize N)^2⌉₊
def r7WindowStep (N : Size) (γ : ℝ) (M : ℕ) : ℝ :=
  (M:ℝ)*Real.exp (2*logSize N-(logSize N)^(16*γ))
def r7IterationProbability (N : Size) (γ : ℝ) : ℝ :=
  4*Real.exp (-(r7ConcentrationConstant/4)*(logSize N)^(3*γ))

theorem r7WindowStep_nonneg (N : Size) (γ : ℝ) (M : ℕ) : 0 ≤ r7WindowStep N γ M := by
  unfold r7WindowStep
  positivity

theorem r7IterationProbability_pos (N : Size) (γ : ℝ) : 0 < r7IterationProbability N γ := by
  unfold r7IterationProbability
  positivity

theorem r7IterationProbability_tendsto (γ : ℝ) (hγ : 0 < γ) :
    Tendsto (fun N => r7IterationProbability N γ) atTop (𝓝 0) := by
  have hpow := (tendsto_rpow_atTop (by positivity : 0 < 3*γ)).comp blockB_logSize_tendsto
  have hc : -(r7ConcentrationConstant/4) < 0 := by have := r7ConcentrationConstant_pos; linarith
  have h := (Real.tendsto_exp_atBot.comp (hpow.const_mul_atTop_of_neg hc)).const_mul 4
  simpa only [r7IterationProbability,mul_zero,Function.comp_def] using h

theorem r7_enlarged_window_size (γ : ℝ) (hγ : 0 < γ) :
    ∀ᶠ N : Size in atTop, ∀ M : ℕ, (M:ℝ) ≤ (logSize N)^4+1 →
      (r7IterationLength N:ℝ)*r7WindowStep N γ M ≤ timeScale N := by
  have hg := coarseProbe_g_pos
  have ht : Tendsto (fun L : ℝ => (4/g)*(L^6*Real.exp (-L^(16*γ)))) atTop (𝓝 0) := by
    simpa using (polynomial_times_stretched_exp_tendsto_zero (16*γ) 1 6 (by positivity) zero_lt_one).const_mul (4/g)
  filter_upwards [blockB_logSize_tendsto.eventually_ge_atTop 1,
    blockB_logSize_tendsto.eventually (ht.eventually_le_const zero_lt_one)] with N hL he
  intro M hM
  have hJ : (r7IterationLength N:ℝ) ≤ (logSize N)^2+1 := (Nat.ceil_lt_add_one (sq_nonneg _)).le
  have hL2 : 1 ≤ (logSize N)^2 := by nlinarith
  have hL4 : 1 ≤ (logSize N)^4 := by nlinarith [sq_nonneg ((logSize N)^2-1)]
  have hJM : (r7IterationLength N:ℝ)*(M:ℝ) ≤ 4*(logSize N)^6 := by
    calc
      _ ≤ (2*(logSize N)^2)*(2*(logSize N)^4) :=
        mul_le_mul (by linarith) (by linarith) (Nat.cast_nonneg M) (by positivity)
      _ = _ := by ring
  have he' : 4*(logSize N)^6*Real.exp (-(logSize N)^(16*γ)) ≤ g := by
    have hm := mul_le_mul_of_nonneg_right he hg.le
    have hid : (4/g)*((logSize N)^6*Real.exp (-(logSize N)^(16*γ)))*g =
        4*(logSize N)^6*Real.exp (-(logSize N)^(16*γ)) := by field_simp
    rw [hid,one_mul] at hm
    exact hm
  have hJMexp := (mul_le_mul_of_nonneg_right hJM (Real.exp_pos _).le).trans he'
  have heq : Real.exp (2*logSize N-(logSize N)^(16*γ)) =
      vertexCount N*Real.exp (-(logSize N)^(16*γ)) := by
    rw [D.vertexCount_eq_exp_two_logSize,sub_eq_add_neg,Real.exp_add]
  rw [r7WindowStep,heq,timeScale_eq_vertexCount]
  have hm := mul_le_mul_of_nonneg_right hJMexp (vertexCount_pos N).le
  have hgL := mul_le_mul_of_nonneg_left hL (mul_nonneg hg.le (vertexCount_pos N).le)
  nlinarith

theorem r7_enlarged_windows_central (N : Size) (γ H l r : ℝ) (M j : ℕ)
    (hj : j ≤ r7IterationLength N)
    (hsize : (r7IterationLength N:ℝ)*r7WindowStep N γ M ≤ timeScale N)
    (hl : phaseACenter N-H*timeScale N ≤ l) (hr : r ≤ phaseACenter N+H*timeScale N) :
    phaseACenter N-(H+1)*timeScale N ≤ l-(j:ℝ)*r7WindowStep N γ M ∧
      r+(j:ℝ)*r7WindowStep N γ M ≤ phaseACenter N+(H+1)*timeScale N := by
  have hj' : (j:ℝ) ≤ (r7IterationLength N:ℝ) := by exact_mod_cast hj
  have h := (mul_le_mul_of_nonneg_right hj' (r7WindowStep_nonneg N γ M)).trans hsize
  constructor <;> linarith

theorem r7_probability_power_bound (γ : ℝ) (hγ : 0 < γ) :
    ∀ᶠ N : Size in atTop, r7IterationProbability N γ ≤ 1/2 ∧
      (r7IterationProbability N γ)^(r7IterationLength N) ≤ Real.exp (-(logSize N)^2) := by
  filter_upwards [(r7IterationProbability_tendsto γ hγ).eventually_le_const (by norm_num : (0:ℝ) < 1/2),
    (r7IterationProbability_tendsto γ hγ).eventually_le_const (Real.exp_pos (-1))] with N hhalf hp
  refine ⟨hhalf,?_⟩
  calc
    _ ≤ (Real.exp (-1))^(r7IterationLength N) := pow_le_pow_left₀ (r7IterationProbability_pos N γ).le hp _
    _ = Real.exp (-(r7IterationLength N:ℝ)) := by rw [← Real.exp_nat_mul]; congr 1; ring
    _ ≤ _ := Real.exp_le_exp.mpr (neg_le_neg (Nat.le_ceil _))

end TorusCoverTime.Blocks.B
