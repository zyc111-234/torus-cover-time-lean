import Mathlib.MeasureTheory.Measure.FiniteMeasureExt
import Mathlib.Algebra.Algebra.Subalgebra.Lattice

/-! Finite multivariate Laplace transforms separate finite measures on the
nonnegative orthant. The separating algebra and its closure under products
are constructed explicitly; no distribution-uniqueness axiom is introduced. -/

noncomputable section
open MeasureTheory ProbabilityTheory Set Classical BoundedContinuousFunction
open scoped NNReal
namespace TorusCoverTime.Blocks.B

variable {ι : Type*} [Fintype ι]

def laplaceTest (u : ι → ℝ≥0) : (ι → ℝ≥0) →ᵇ ℝ :=
  BoundedContinuousFunction.mkOfBound
    ⟨fun x => Real.exp (-(∑ i, (u i : ℝ) * (x i : ℝ))), by fun_prop⟩ 2 (by
      intro x y
      have hbound (z : ι → ℝ≥0) : ‖Real.exp (-(∑ i, (u i : ℝ) * (z i : ℝ)))‖ ≤ 1 := by
        rw [Real.norm_eq_abs, abs_of_pos (Real.exp_pos _)]
        apply Real.exp_le_one_iff.mpr
        exact neg_nonpos.mpr (Finset.sum_nonneg fun i _ => mul_nonneg (u i).coe_nonneg (z i).coe_nonneg)
      rw [dist_eq_norm]
      exact (norm_sub_le _ _).trans
        ((add_le_add (hbound x) (hbound y)).trans_eq (by norm_num)))

@[simp] theorem laplaceTest_apply (u x : ι → ℝ≥0) :
    laplaceTest u x = Real.exp (-(∑ i, (u i : ℝ) * (x i : ℝ))) := rfl

@[simp] theorem laplaceTest_zero : laplaceTest (0 : ι → ℝ≥0) = 1 := by
  ext x
  simp

theorem laplaceTest_add (u v : ι → ℝ≥0) : laplaceTest (u + v) = laplaceTest u * laplaceTest v := by
  ext x
  simp only [laplaceTest_apply, Pi.add_apply, NNReal.coe_add, add_mul,
    Finset.sum_add_distrib, neg_add, Real.exp_add, BoundedContinuousFunction.mul_apply]

def laplaceTestMonoid (ι : Type*) [Fintype ι] : Submonoid ((ι → ℝ≥0) →ᵇ ℝ) where
  carrier := Set.range laplaceTest
  one_mem' := ⟨0, laplaceTest_zero⟩
  mul_mem' := by
    rintro _ _ ⟨u, rfl⟩ ⟨v, rfl⟩
    exact ⟨u + v, laplaceTest_add u v⟩

def laplaceTestAlgebra (ι : Type*) [Fintype ι] : StarSubalgebra ℝ ((ι → ℝ≥0) →ᵇ ℝ) where
  toSubalgebra := Algebra.adjoin ℝ (laplaceTestMonoid ι : Set ((ι → ℝ≥0) →ᵇ ℝ))
  star_mem' := by
    intro f hf
    have hs : star f = f := by ext x; simp
    rwa [hs]

theorem laplaceTest_mem_algebra (u : ι → ℝ≥0) : laplaceTest u ∈ laplaceTestAlgebra ι :=
  Algebra.subset_adjoin ⟨u, rfl⟩

theorem laplaceTestAlgebra_separatesPoints :
    ((laplaceTestAlgebra ι).map (toContinuousMapStarₐ ℝ)).SeparatesPoints := by
  intro x y hxy
  obtain ⟨i, hi⟩ := Function.ne_iff.mp hxy
  let u : ι → ℝ≥0 := fun j => if j = i then 1 else 0
  refine ⟨laplaceTest u, ?_, ?_⟩
  · exact ⟨(laplaceTest u).toContinuousMap,
      ⟨laplaceTest u, laplaceTest_mem_algebra u, rfl⟩, rfl⟩
  · intro he
    have hex : Real.exp (-(x i : ℝ)) = Real.exp (-(y i : ℝ)) := by
      simpa only [laplaceTest_apply, u, apply_ite NNReal.toReal, NNReal.coe_one,
        NNReal.coe_zero, ite_mul, one_mul, zero_mul, Finset.sum_ite_eq',
        Finset.mem_univ, if_true] using he
    exact hi (NNReal.coe_injective (neg_injective (Real.exp_injective hex)))

theorem finite_measure_eq_of_multivariate_laplace
    (μ ν : Measure (ι → ℝ≥0)) [IsFiniteMeasure μ] [IsFiniteMeasure ν]
    (h : ∀ u : ι → ℝ≥0,
      (∫ x, Real.exp (-(∑ i, (u i : ℝ) * (x i : ℝ))) ∂μ) =
        ∫ x, Real.exp (-(∑ i, (u i : ℝ) * (x i : ℝ))) ∂ν) : μ = ν := by
  apply ext_of_forall_mem_subalgebra_integral_eq_of_polish laplaceTestAlgebra_separatesPoints
  intro f hf
  change f ∈ Algebra.adjoin ℝ (laplaceTestMonoid ι : Set ((ι → ℝ≥0) →ᵇ ℝ)) at hf
  change f ∈ (Algebra.adjoin ℝ (laplaceTestMonoid ι : Set ((ι → ℝ≥0) →ᵇ ℝ))).toSubmodule at hf
  rw [Algebra.adjoin_eq_span, (laplaceTestMonoid ι).closure_eq] at hf
  refine Submodule.span_induction (fun f hf => ?_) ?_ (fun f g _ _ hf hg => ?_)
    (fun c f _ hf => ?_) hf
  · obtain ⟨u, rfl⟩ := hf
    exact h u
  · simp
  · simp only [BoundedContinuousFunction.add_apply]
    rw [integral_add (f.integrable μ) (g.integrable μ),
      integral_add (f.integrable ν) (g.integrable ν), hf, hg]
  · simp only [BoundedContinuousFunction.smul_apply, smul_eq_mul]
    rw [integral_const_mul, integral_const_mul, hf]

/-- The real-coordinate version only requires the measures to be supported
on the nonnegative orthant; exceptional null samples are harmless. -/
theorem finite_measure_eq_of_multivariate_laplace_nonneg
    (μ ν : Measure (ι → ℝ)) [IsFiniteMeasure μ] [IsFiniteMeasure ν]
    (hμ : ∀ᵐ x ∂μ, ∀ i, 0 ≤ x i) (hν : ∀ᵐ x ∂ν, ∀ i, 0 ≤ x i)
    (h : ∀ u : ι → ℝ≥0,
      (∫ x, Real.exp (-(∑ i, (u i : ℝ) * x i)) ∂μ) =
        ∫ x, Real.exp (-(∑ i, (u i : ℝ) * x i)) ∂ν) : μ = ν := by
  let n : (ι → ℝ) → (ι → ℝ≥0) := fun x i => Real.toNNReal (x i)
  let c : (ι → ℝ≥0) → (ι → ℝ) := fun x i => (x i : ℝ)
  have hn : Measurable n := by dsimp [n]; fun_prop
  have hc : Measurable c := by dsimp [c]; fun_prop
  have he (ρ : Measure (ι → ℝ)) [IsFiniteMeasure ρ]
      (hρ : ∀ᵐ x ∂ρ, ∀ i, 0 ≤ x i) (u : ι → ℝ≥0) :
      (∫ x, Real.exp (-(∑ i, (u i : ℝ) * (x i : ℝ))) ∂ρ.map n) =
        ∫ x, Real.exp (-(∑ i, (u i : ℝ) * x i)) ∂ρ := by
    have ht : Measurable (fun x : ι → ℝ≥0 => Real.exp (-(∑ i, (u i : ℝ) * (x i : ℝ)))) := by
      fun_prop
    rw [integral_map hn.aemeasurable ht.aestronglyMeasurable]
    apply integral_congr_ae
    filter_upwards [hρ] with x hx
    simp only [n, Real.coe_toNNReal _ (hx _)]
  have hm : μ.map n = ν.map n := by
    apply finite_measure_eq_of_multivariate_laplace
    intro u
    rw [he μ hμ u, he ν hν u, h u]
  have hrecover (ρ : Measure (ι → ℝ)) (hρ : ∀ᵐ x ∂ρ, ∀ i, 0 ≤ x i) :
      (ρ.map n).map c = ρ := by
    rw [Measure.map_map hc hn]
    calc
      ρ.map (c ∘ n) = ρ.map id := Measure.map_congr (by
        filter_upwards [hρ] with x hx
        funext i
        exact Real.coe_toNNReal _ (hx i))
      _ = ρ := Measure.map_id
  rw [← hrecover μ hμ, ← hrecover ν hν, hm]

end TorusCoverTime.Blocks.B
