import Solutions.Blocks.B.R7PerturbedCountedWindow
import Solutions.Blocks.B.R7PhysicalWindow

/-! Identification of the low-record term with the original harmonic local
time. This is the actual counted path-window recurrence, after all word sums. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

theorem r7_perturbed_physical_window_recurrence (hWalk : WalkModelRegular) (γ : ℝ)
    (hγ : 0 < γ) (hγ1 : γ < 1) :
    ∀ᶠ N : Size in atTop, ∀ c root : Vertex N, ∀ M : ℕ, ∀ q : ℝ,
      (logSize N)^(16*γ) ≤ q → q ≤ logSize N-(logSize N)^(16*γ) → (M:ℝ) ≤ (logSize N)^4+1 →
      root ∉ torusDisk N c (r7PerturbedOuter q (q^γ)) →
      ∀ v Δ : ℝ, 0 ≤ v → (M:ℝ)*r7PerturbedWidth q (q^γ) ≤ v^2 → 0 ≤ Δ →
      2*r7PerturbedMeanConstant*Real.exp (-r7MeanExponent*q^γ)*v ≤ Δ → ∀ l r : ℝ,
      let I := torusDisk N c (r7PerturbedInner q (q^γ))
      let O := torusDisk N c (r7PerturbedOuter q (q^γ))
      let d := (M:ℝ)*Real.exp (2*logSize N-(logSize N)^(16*γ))
      countedLoopWindowMass N I O root M l r ≤ lowHarmonicLoopWindowMass N c root q (v+Δ) l r +
        2*ENNReal.ofReal (2*Real.exp (-(r7PerturbedConcentrationConstant/4)*Δ^2/q^γ)) *
          countedLoopWindowMass N I O root M (l-d) (r+d) +
        ((M+1:ℕ):ℝ≥0∞)*ENNReal.ofReal (r-l)*ENNReal.ofReal (Real.exp (-Real.exp ((logSize N)^(16*γ)/2))) := by
  obtain ⟨q0,hq0⟩ := eventually_atTop.mp (r7_perturbed_annulus_geometry γ hγ hγ1)
  have hQ := (tendsto_rpow_atTop (by positivity : 0 < 16*γ)).comp blockB_logSize_tendsto
  filter_upwards [r7_perturbed_counted_window_recurrence hWalk γ hγ hγ1,
    hQ.eventually_ge_atTop q0] with N hN hbase
  intro c root M q hq hqL hM hr v Δ hv hMv hΔ hlo l r
  dsimp only
  have hg := hq0 q (hbase.trans hq)
  have hIO : torusDisk N c (r7PerturbedInner q (q^γ)) ⊆ torusDisk N c (r7PerturbedOuter q (q^γ)) := by
    intro z hz
    exact (mem_torusDisk N c z _).mpr (((mem_torusDisk N c z _).mp hz).trans_le hg.2.1)
  have hlow := lowWordWindowSum_le_harmonic N c root _ _ hIO
    (torusDisk_nonempty N c _ hg.1) hr M q v Δ l r (hg.2.2 N c)
  exact (hN c root M q hq hqL hM hr v Δ hv hMv hΔ hlo l r).trans
    (add_le_add (add_le_add hlow le_rfl) le_rfl)

theorem r7_perturbed_far_root_outside (γ : ℝ) (hγ : 0 < γ) :
    ∀ᶠ N : Size in atTop, ∀ c root : Vertex N, ∀ q : ℝ,
      0 ≤ q → q ≤ logSize N-(logSize N)^(16*γ) →
      (N.val:ℝ)*Real.exp (-((logSize N)^(16*γ))/2) ≤ periodicDistance c root →
      root ∉ torusDisk N c (r7PerturbedOuter q (q^γ)) := by
  have hQ := (tendsto_rpow_atTop (by positivity : 0 < 16*γ)).comp blockB_logSize_tendsto
  filter_upwards [blockB_logSize_tendsto.eventually
    (power_eventually_le_power 2 γ (16*γ) (1/4) (by linarith) (by norm_num)),
    hQ.eventually_gt_atTop (4*Real.log 3)] with N hpow hlarge
  change 4*Real.log 3 < (logSize N)^(16*γ) at hlarge
  intro c root q hq hqL hfar hin
  have hqL' := hqL.trans (sub_le_self _ (Real.rpow_nonneg (logSize_pos N).le _))
  have hqpow := Real.rpow_le_rpow hq hqL' hγ.le
  have he : Real.exp (logSize N-(logSize N)^(16*γ)/2) =
      (N.val:ℝ)*Real.exp (-((logSize N)^(16*γ))/2) := by
    rw [sub_eq_add_neg,Real.exp_add,show Real.exp (logSize N) = (N.val:ℝ) by
      exact Real.exp_log (lt_trans zero_lt_one (size_real_gt_one N))]
    congr 2
    ring
  have hr : 3*Real.exp (q+2*q^γ) < (N.val:ℝ)*Real.exp (-((logSize N)^(16*γ))/2) := by
    rw [← he,show (3:ℝ) = Real.exp (Real.log 3) by rw [Real.exp_log (by norm_num : (0:ℝ) < 3)],
      ← Real.exp_add]
    exact Real.exp_lt_exp.mpr (by linarith)
  have heq : Real.exp q ≤ Real.exp (q+2*q^γ) :=
    Real.exp_le_exp.mpr (by linarith [Real.rpow_nonneg hq γ])
  have hh := (mem_torusDisk N c root _).mp hin
  rw [periodicDistance_comm root c] at hh
  dsimp only [r7PerturbedOuter] at hh
  linarith

end TorusCoverTime.Blocks.B
