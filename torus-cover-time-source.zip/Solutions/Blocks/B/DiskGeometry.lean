import Solutions.Blocks.B.TorusMetric
import Solutions.Blocks.B.ExitPathGeometry

/-! Integer lifts of the manuscript's Euclidean torus disks. Local steps are exactly
planar when the point and its neighbors lie strictly inside half the torus size. -/

noncomputable section
open Classical
namespace TorusCoverTime.Blocks.B

abbrev LatticePoint := ℤ × ℤ

def latticeDirection (d : Fin 4) : LatticePoint :=
  if d = 0 then (1, 0) else if d = 1 then (-1, 0)
  else if d = 2 then (0, 1) else (0, -1)

def latticeRadius (z : LatticePoint) : ℝ :=
  Real.sqrt ((z.1 : ℝ) ^ 2 + (z.2 : ℝ) ^ 2)

def torusProjection (N : Size) (y : Vertex N) (z : LatticePoint) : Vertex N :=
  y + ((z.1 : ZMod N.val), (z.2 : ZMod N.val))

def centeredLift (N : Size) (y x : Vertex N) : LatticePoint :=
  ((x.1 - y.1).valMinAbs, (x.2 - y.2).valMinAbs)

def torusDisk (N : Size) (y : Vertex N) (R : ℝ) : Finset (Vertex N) :=
  Finset.univ.filter (fun x => periodicDistance x y < R)

@[simp] lemma mem_torusDisk (N : Size) (y x : Vertex N) (R : ℝ) :
    x ∈ torusDisk N y R ↔ periodicDistance x y < R := by simp [torusDisk]

@[simp] lemma torusProjection_centeredLift (N : Size) (y x : Vertex N) :
    torusProjection N y (centeredLift N y x) = x := by
  ext <;> simp [torusProjection, centeredLift]

lemma centeredLift_injective (N : Size) (y : Vertex N) :
    Function.Injective (centeredLift N y) := by
  intro x z h
  have hh := congrArg (torusProjection N y) h
  simpa using hh

lemma valMinAbs_intCast_of_small (N : Size) (z : ℤ) (hz : 2 * |(z : ℝ)| < N.val) :
    (z : ZMod N.val).valMinAbs = z := by
  have hi : 2 * |z| < (N.val : ℤ) := by exact_mod_cast hz
  apply (ZMod.valMinAbs_spec _ z).mpr
  refine ⟨rfl, ?_, ?_⟩
  · have := neg_abs_le z
    omega
  · have := le_abs_self z
    omega

lemma centeredLift_projection_of_small (N : Size) (y : Vertex N) (z : LatticePoint)
    (h1 : 2 * |(z.1 : ℝ)| < N.val) (h2 : 2 * |(z.2 : ℝ)| < N.val) :
    centeredLift N y (torusProjection N y z) = z := by
  ext <;> simp only [centeredLift, torusProjection, Prod.fst_add, Prod.snd_add,
    add_sub_cancel_left]
  · exact valMinAbs_intCast_of_small N z.1 h1
  · exact valMinAbs_intCast_of_small N z.2 h2

lemma latticeRadius_centeredLift (N : Size) (y x : Vertex N) :
    latticeRadius (centeredLift N y x) = periodicDistance x y := by
  rw [← periodicDistance_sub_zero N x y]
  simp only [latticeRadius, centeredLift, periodicDistance, Prod.fst_sub, Prod.snd_sub,
    Prod.fst_zero, Prod.snd_zero, coordinateDistance_eq_abs_centered, sq_abs]

lemma latticeRadius_coordinates (z : LatticePoint) :
    |(z.1 : ℝ)| ≤ latticeRadius z ∧ |(z.2 : ℝ)| ≤ latticeRadius z := by
  have hs : latticeRadius z ^ 2 = (z.1 : ℝ) ^ 2 + (z.2 : ℝ) ^ 2 :=
    Real.sq_sqrt (by positivity)
  have hp : 0 ≤ latticeRadius z := Real.sqrt_nonneg _
  constructor <;> nlinarith [sq_abs (z.1 : ℝ), sq_abs (z.2 : ℝ),
    abs_nonneg (z.1 : ℝ), abs_nonneg (z.2 : ℝ), sq_nonneg (z.1 : ℝ), sq_nonneg (z.2 : ℝ)]

lemma periodicDistance_projection_of_small (N : Size) (y : Vertex N) (z : LatticePoint)
    (h1 : 2 * |(z.1 : ℝ)| < N.val) (h2 : 2 * |(z.2 : ℝ)| < N.val) :
    periodicDistance (torusProjection N y z) y = latticeRadius z := by
  rw [← latticeRadius_centeredLift, centeredLift_projection_of_small N y z h1 h2]

lemma projection_mem_disk_iff (N : Size) (y : Vertex N) (R : ℝ) (z : LatticePoint)
    (h1 : 2 * |(z.1 : ℝ)| < N.val) (h2 : 2 * |(z.2 : ℝ)| < N.val) :
    torusProjection N y z ∈ torusDisk N y R ↔ latticeRadius z < R := by
  rw [mem_torusDisk, periodicDistance_projection_of_small N y z h1 h2]

lemma torusProjection_add_direction (N : Size) (y : Vertex N) (z : LatticePoint) (d : Fin 4) :
    torusProjection N y (z + latticeDirection d) = torusProjection N y z + direction N d := by
  fin_cases d <;> ext <;> simp [torusProjection, latticeDirection, direction, add_assoc]

lemma latticeDirection_coordinates (d : Fin 4) :
    |((latticeDirection d).1 : ℝ)| ≤ 1 ∧ |((latticeDirection d).2 : ℝ)| ≤ 1 := by
  fin_cases d <;> simp [latticeDirection]

lemma centeredLift_add_direction (N : Size) (y x : Vertex N) (d : Fin 4)
    (hsmall : 2 * (periodicDistance x y + 1) < N.val) :
    centeredLift N y (x + direction N d) = centeredLift N y x + latticeDirection d := by
  have hb := latticeRadius_coordinates (centeredLift N y x)
  rw [latticeRadius_centeredLift] at hb
  have hd := latticeDirection_coordinates d
  have h1 : 2 * |((centeredLift N y x + latticeDirection d).1 : ℝ)| < N.val := by
    simp only [Prod.fst_add, Int.cast_add]
    have ha := abs_add_le ((centeredLift N y x).1 : ℝ) ((latticeDirection d).1 : ℝ)
    linarith
  have h2 : 2 * |((centeredLift N y x + latticeDirection d).2 : ℝ)| < N.val := by
    simp only [Prod.snd_add, Int.cast_add]
    have ha := abs_add_le ((centeredLift N y x).2 : ℝ) ((latticeDirection d).2 : ℝ)
    linarith
  have h := centeredLift_projection_of_small N y (centeredLift N y x + latticeDirection d) h1 h2
  rw [torusProjection_add_direction, torusProjection_centeredLift] at h
  exact h

end TorusCoverTime.Blocks.B
