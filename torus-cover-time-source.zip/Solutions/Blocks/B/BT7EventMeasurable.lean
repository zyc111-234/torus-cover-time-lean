import Solutions.Blocks.B.BT7Goal
import Solutions.Blocks.B.PeriodicBindingLS

noncomputable section
open MeasureTheory Set Classical
open scoped BigOperators
namespace TorusCoverTime.Blocks.B
theorem bt7_fixed_contact_closed (N : Size) (x : Vertex N) (γ η κ δ : ℝ) (q : ℕ) :
    IsClosed {f : Vertex N → ℝ | ∃ a : ℝ, |a-harmonicExtremeCenter N|≤η ∧ |f x-a|≤κ ∧
      (∀ j : ℕ, (logSize N)^(32*γ)≤(j:ℝ) → (j:ℝ)≤logSize N-(logSize N)^(32*γ) →
        Real.sqrt 2*(j:ℝ)-δ≤bt6ExitNorm N x j f a) ∧
      bt6ExitNorm N x q f a≤Real.sqrt 2*(q:ℝ)+δ} := by
  let I := Set.Icc (harmonicExtremeCenter N-η) (harmonicExtremeCenter N+η)
  let s : Set ((Vertex N → ℝ) × I) := {v | |v.1 x-v.2.val|≤κ ∧
    (∀ j : ℕ, (logSize N)^(32*γ)≤(j:ℝ) → (j:ℝ)≤logSize N-(logSize N)^(32*γ) →
      Real.sqrt 2*(j:ℝ)-δ≤bt6ExitNorm N x j v.1 v.2.val) ∧
    bt6ExitNorm N x q v.1 v.2.val≤Real.sqrt 2*(q:ℝ)+δ}
  have hc (j : ℕ) : Continuous (fun v : (Vertex N → ℝ) × I => bt6ExitNorm N x j v.1 v.2.val) :=
    (bt6ExitNorm_continuous N x j).comp (continuous_fst.prodMk (continuous_subtype_val.comp continuous_snd))
  have hs : IsClosed s := by
    refine IsClosed.inter (isClosed_le (f := fun v : (Vertex N → ℝ) × I => |v.1 x-v.2.val|)
      (by fun_prop) continuous_const) ?_
    apply IsClosed.inter
    · have heq : (fun v : (Vertex N → ℝ) × I =>
          ∀ j : ℕ, (logSize N)^(32*γ)≤(j:ℝ) → (j:ℝ)≤logSize N-(logSize N)^(32*γ) →
            Real.sqrt 2*(j:ℝ)-δ≤bt6ExitNorm N x j v.1 v.2.val) =
          ⋂ j : ℕ, ⋂ (_ : (logSize N)^(32*γ)≤(j:ℝ)), ⋂ (_ : (j:ℝ)≤logSize N-(logSize N)^(32*γ)),
            {v : (Vertex N → ℝ) × I | Real.sqrt 2*(j:ℝ)-δ≤bt6ExitNorm N x j v.1 v.2.val} := by
        ext v
        change (∀ j : ℕ, (logSize N)^(32*γ)≤(j:ℝ) → (j:ℝ)≤logSize N-(logSize N)^(32*γ) →
          Real.sqrt 2*(j:ℝ)-δ≤bt6ExitNorm N x j v.1 v.2.val) ↔
          v ∈ ⋂ j : ℕ, ⋂ (_ : (logSize N)^(32*γ)≤(j:ℝ)), ⋂ (_ : (j:ℝ)≤logSize N-(logSize N)^(32*γ)),
            {v : (Vertex N → ℝ) × I | Real.sqrt 2*(j:ℝ)-δ≤bt6ExitNorm N x j v.1 v.2.val}
        simp only [Set.mem_iInter,Set.mem_ofPred_eq]
      rw [heq]
      exact (isClosed_iInter fun j : ℕ =>
        isClosed_iInter fun _ : (logSize N)^(32*γ)≤(j:ℝ) =>
        isClosed_iInter fun _ : (j:ℝ)≤logSize N-(logSize N)^(32*γ) =>
        isClosed_le (f := fun _ => Real.sqrt 2*(j:ℝ)-δ) continuous_const (hc j))
    · exact isClosed_le (hc q) continuous_const
  have him := isClosedMap_fst_of_compactSpace s hs
  convert him using 1
  ext f
  constructor
  · rintro ⟨a,ha,hend,hl,hu⟩
    have hI : a∈I := by have hh := abs_le.mp ha; constructor <;> linarith
    exact ⟨(f,⟨a,hI⟩),⟨hend,hl,hu⟩,rfl⟩
  · rintro ⟨⟨g,a⟩,⟨hend,hl,hu⟩,he⟩
    dsimp only [Prod.fst] at he
    subst g
    refine ⟨a.val,?_,hend,hl,hu⟩
    have hh := a.property
    apply abs_le.mpr
    constructor <;> linarith [hh.1,hh.2]


theorem bt7BadPoint_measurableSet (N : Size) (γ ε C₀ C₁ : ℝ) (x : Vertex N) :
    MeasurableSet {f : Vertex N → ℝ | bt7BadPoint N γ ε C₀ C₁ f x} := by
  let η := ε*Real.log (logSize N)+C₀
  let δ := C₁*(logSize N)^(8*γ)
  have he : {f : Vertex N → ℝ | bt7BadPoint N γ ε C₀ C₁ f x}=
      ⋃ q : ℕ, ⋃ (_ : (logSize N)^(1/10:ℝ)≤(q:ℝ)), ⋃ (_ : (q:ℝ)≤logSize N-(logSize N)^(1/10:ℝ)),
        {f : Vertex N → ℝ | ∃ a : ℝ, |a-harmonicExtremeCenter N|≤η ∧ |f x-a|≤C₀ ∧
          (∀ j : ℕ, (logSize N)^(32*γ)≤(j:ℝ) → (j:ℝ)≤logSize N-(logSize N)^(32*γ) →
            Real.sqrt 2*(j:ℝ)-δ≤bt6ExitNorm N x j f a) ∧
          bt6ExitNorm N x q f a≤Real.sqrt 2*(q:ℝ)+δ} := by
    ext f
    simp only [Set.mem_ofPred_eq,bt7BadPoint,mem_iUnion]
    constructor
    · rintro ⟨a,ha,hx,hl,q,hq,hq',hu⟩
      exact ⟨q,hq,hq',a,ha,hx,hl,hu⟩
    · rintro ⟨q,hq,hq',a,ha,hx,hl,hu⟩
      exact ⟨a,ha,hx,hl,q,hq,hq',hu⟩
  rw [he]
  exact MeasurableSet.iUnion fun q => MeasurableSet.iUnion fun _ => MeasurableSet.iUnion fun _ =>
    (bt7_fixed_contact_closed N x γ η C₀ δ q).measurableSet

@[fun_prop] theorem bt7BadCount_measurable (N : Size) (γ ε C₀ C₁ : ℝ) :
    Measurable (bt7BadCount N γ ε C₀ C₁) := by
  apply Finset.measurable_sum
  intro x _
  exact measurable_const.ite (((bt7BadPoint_measurableSet N γ ε C₀ C₁ x).preimage (periodicFieldLS_measurable N)).union
    ((bt7BadPoint_measurableSet N γ ε C₀ C₁ x).preimage
      (show Measurable (fun ξ : FiniteFieldSample N => fun z => -periodicFieldLS N ξ z) by fun_prop))) measurable_const

theorem bt7BadCount_bounds (N : Size) (γ ε C₀ C₁ : ℝ) (ξ : FiniteFieldSample N) :
    0≤bt7BadCount N γ ε C₀ C₁ ξ ∧ bt7BadCount N γ ε C₀ C₁ ξ≤vertexCount N := by
  constructor
  · apply Finset.sum_nonneg; intro x _; split_ifs <;> norm_num
  · calc
      _ ≤ ∑ _ : Vertex N, (1:ℝ) := by apply Finset.sum_le_sum; intro x _; split_ifs <;> norm_num
      _ = _ := by rw [sum_const_vertex,mul_one]

theorem bt7BadCount_integrable (N : Size) (γ ε C₀ C₁ : ℝ) :
    Integrable (bt7BadCount N γ ε C₀ C₁) (finiteFieldLaw N) := by
  apply (integrable_const (vertexCount N)).mono' (bt7BadCount_measurable N γ ε C₀ C₁).aestronglyMeasurable
  exact Filter.Eventually.of_forall (fun ξ => by
    rw [Real.norm_eq_abs,abs_of_nonneg (bt7BadCount_bounds N γ ε C₀ C₁ ξ).1]
    exact (bt7BadCount_bounds N γ ε C₀ C₁ ξ).2)

end TorusCoverTime.Blocks.B

