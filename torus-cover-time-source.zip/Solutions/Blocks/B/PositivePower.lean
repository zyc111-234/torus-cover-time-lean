import Solutions.Blocks.B.EnergyAlgebra
import Mathlib.Algebra.Order.Ring.Pow
import Mathlib.Data.Nat.Choose.Cast

/-! Tangent and quadratic lower bounds for positive-part powers, used to
construct explicit subharmonic radial barriers on the actual disk. -/

noncomputable section
namespace TorusCoverTime.Blocks.B

theorem positive_power_tangent (a t : ℝ) (ha : 0 ≤ a) (n : ℕ) :
    a^n + (n:ℝ)*a^(n-1)*t ≤ (max (a+t) 0)^n := by
  have hb : 0 ≤ 2*a+(max (a+t) 0-a) := by have := le_max_right (a+t) 0; linarith
  have he := pow_add_mul_le_add_pow ha hb n
  rw [add_sub_cancel] at he
  have ht : t ≤ max (a+t) 0-a := by have := le_max_left (a+t) 0; linarith
  have hm := mul_le_mul_of_nonneg_left ht (show 0 ≤ (n:ℝ)*a^(n-1) by positivity)
  linarith

theorem positive_power_quadratic (a t : ℝ) (ha : 0 ≤ a) (ht : 0 ≤ t) (n : ℕ) :
    a^(n+2) + ((n:ℝ)+2)*a^(n+1)*t +
      (((n:ℝ)+2)*((n:ℝ)+1)/2)*a^n*t^2 ≤ (a+t)^(n+2) := by
  rw [add_comm a t, add_pow]
  have hs : (∑ k ∈ Finset.range 3, t^k*a^(n+2-k)*(Nat.choose (n+2) k : ℝ)) ≤
      ∑ k ∈ Finset.range (n+2+1), t^k*a^(n+2-k)*(Nat.choose (n+2) k : ℝ) :=
    Finset.sum_le_sum_of_subset_of_nonneg (Finset.range_mono (by omega)) (fun k _ _ => by positivity)
  have hid : (∑ k ∈ Finset.range 3, t^k*a^(n+2-k)*(Nat.choose (n+2) k : ℝ)) =
      a^(n+2) + ((n:ℝ)+2)*a^(n+1)*t + (((n:ℝ)+2)*((n:ℝ)+1)/2)*a^n*t^2 := by
    rw [show (3:ℕ) = 2+1 from rfl, Finset.sum_range_succ, Finset.sum_range_succ, Finset.sum_range_succ]
    simp only [Finset.sum_range_zero, Nat.sub_zero, pow_zero, one_mul, Nat.choose_zero_right,
      Nat.cast_one, mul_one, zero_add, Nat.choose_one_right, pow_one,
      Nat.add_sub_cancel, Nat.cast_add, Nat.cast_ofNat, Nat.cast_choose_two]
    rw [show n+2-1 = n+1 by omega]
    push_cast
    ring
  exact hid ▸ hs

theorem positive_power_generator_lower (N : Size) (F : Vertex N → ℝ) (x : Vertex N)
    (hx : 0 ≤ F x) (n : ℕ) (d : Fin 4) (t : ℝ) (ht : 0 ≤ t)
    (hstep : t ≤ F (x+direction N d)-F x) :
    ((n:ℝ)+2)*(F x)^n*((F x)*generator N F x + (((n:ℝ)+1)/8)*t^2) ≤
      generator N (fun z => (max (F z) 0)^(n+2)) x := by
  let p := ((n:ℝ)+2)*(F x)^(n+1)
  let rem := fun e : Fin 4 =>
    (max (F (x+direction N e)) 0)^(n+2) - (F x)^(n+2) - p*(F (x+direction N e)-F x)
  have hrem (e : Fin 4) : 0 ≤ rem e := by
    have he := positive_power_tangent (F x) (F (x+direction N e)-F x) hx (n+2)
    rw [add_sub_cancel] at he
    simp only [Nat.cast_add, Nat.cast_ofNat, show n+2-1=n+1 by omega] at he
    dsimp [rem,p]
    linarith
  have hd : (((n:ℝ)+2)*((n:ℝ)+1)/2)*(F x)^n*t^2 ≤ rem d := by
    have hs0 : 0 ≤ F (x+direction N d)-F x := ht.trans hstep
    have he := positive_power_quadratic (F x) (F (x+direction N d)-F x) hx hs0 n
    rw [add_sub_cancel] at he
    have hnew : 0 ≤ F (x+direction N d) := by linarith
    have hsq := pow_le_pow_left₀ ht hstep 2
    have hm := mul_le_mul_of_nonneg_left hsq
      (show 0 ≤ (((n:ℝ)+2)*((n:ℝ)+1)/2)*(F x)^n by positivity)
    dsimp [rem,p]
    rw [max_eq_left hnew]
    linarith
  have hs := Finset.single_le_sum (s := (Finset.univ : Finset (Fin 4))) (fun e _ => hrem e) (Finset.mem_univ d)
  have htotal := hd.trans hs
  have hid : generator N (fun z => (max (F z) 0)^(n+2)) x =
      p*generator N F x + (1/4)*(∑ e : Fin 4, rem e) := by
    unfold generator
    dsimp only
    rw [max_eq_left hx]
    dsimp [rem]
    simp only [Finset.sum_sub_distrib, ← Finset.mul_sum]
    ring
  rw [hid]
  have hid' : ((n:ℝ)+2)*(F x)^n*((F x)*generator N F x + (((n:ℝ)+1)/8)*t^2) =
      p*generator N F x + (1/4)*((((n:ℝ)+2)*((n:ℝ)+1)/2)*(F x)^n*t^2) := by
    dsimp [p]
    rw [pow_succ]
    ring
  rw [hid']
  linarith

end TorusCoverTime.Blocks.B
