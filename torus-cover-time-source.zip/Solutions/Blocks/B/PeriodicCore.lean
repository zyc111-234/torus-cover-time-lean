import Solutions.Blocks.B.PeriodicAnnular

/-! The smooth annular model is genuinely periodic, including across the frequency seam. -/

noncomputable section
open Function
open scoped Topology ContDiff
namespace TorusCoverTime.Blocks.B

lemma sineCoordinate_shift (a x : ℝ) (ha : a ≠ 0) :
    sineCoordinate a (x + 1 / a) = -sineCoordinate a x := by
  apply mul_left_cancel₀ (mul_ne_zero Real.pi_ne_zero ha)
  rw [sineCoordinate_mul_scale, mul_neg, sineCoordinate_mul_scale]
  rw [show Real.pi * a * (x + 1 / a) = Real.pi * a * x + Real.pi by field_simp <;> ring]
  exact Real.sin_add_pi _

lemma annularReciprocal_zero_neg_left (x y : ℝ) :
    annularReciprocal 0 (-x) y = annularReciprocal 0 x y := by
  simp [annularReciprocal_eq, scaledSymbol_zero_scale, annularCutoff, rectangleCutoff,
    mul_neg, ContDiffBump.neg]

lemma annularReciprocal_zero_neg_right (x y : ℝ) :
    annularReciprocal 0 x (-y) = annularReciprocal 0 x y := by
  simp [annularReciprocal_eq, scaledSymbol_zero_scale, annularCutoff, rectangleCutoff,
    mul_neg, ContDiffBump.neg]

lemma scaledIncrement_periodic (a : ℝ) (ha : a ≠ 0) : Periodic (scaledIncrement a) (1 / a) := by
  intro x
  apply mul_left_cancel₀ (show (a : ℂ) ≠ 0 by exact_mod_cast ha)
  rw [scaledIncrement_mul_scale, scaledIncrement_mul_scale]
  rw [show 2 * Real.pi * a * (x + 1 / a) = 2 * Real.pi * a * x + 2 * Real.pi by
    field_simp <;> ring]
  simp only [Complex.ofReal_add, Complex.ofReal_mul, Complex.ofReal_ofNat,
    add_mul]
  exact congrArg (fun z : ℂ => z - 1) (Complex.exp_periodic _)

lemma scaledStepIncrement_periodic_x (a : ℝ) (ha : a ≠ 0) (d : Fin 4) (y : ℝ) :
    Periodic (fun x => scaledIncrement a (stepCoordinate d x y)) (1 / a) := by
  intro x
  fin_cases d
  · exact scaledIncrement_periodic a ha x
  · change scaledIncrement a (-(x + 1 / a)) = scaledIncrement a (-x)
    simpa only [neg_add, sub_eq_add_neg] using (scaledIncrement_periodic a ha).sub_eq (-x)
  · rfl
  · rfl

lemma scaledStepIncrement_periodic_y (a : ℝ) (ha : a ≠ 0) (d : Fin 4) (x : ℝ) :
    Periodic (fun y => scaledIncrement a (stepCoordinate d x y)) (1 / a) := by
  intro y
  fin_cases d
  · rfl
  · rfl
  · exact scaledIncrement_periodic a ha y
  · change scaledIncrement a (-(y + 1 / a)) = scaledIncrement a (-y)
    simpa only [neg_add, sub_eq_add_neg] using (scaledIncrement_periodic a ha).sub_eq (-y)

lemma periodicAnnularCore_periodic_x (ds : List (Fin 4)) (a : ℝ) (ha : a ≠ 0) (y : ℝ) :
    Periodic (fun x => periodicAnnularCore ds a x y) (1 / a) := by
  intro x
  unfold periodicAnnularCore
  dsimp only
  rw [sineCoordinate_shift a x ha, annularReciprocal_zero_neg_left]
  congr 1
  apply congrArg List.prod
  apply List.map_congr_left
  intro d _
  exact scaledStepIncrement_periodic_x a ha d y x

lemma periodicAnnularCore_periodic_y (ds : List (Fin 4)) (a : ℝ) (ha : a ≠ 0) (x : ℝ) :
    Periodic (fun y => periodicAnnularCore ds a x y) (1 / a) := by
  intro y
  unfold periodicAnnularCore
  dsimp only
  rw [sineCoordinate_shift a y ha, annularReciprocal_zero_neg_right]
  congr 1
  apply congrArg List.prod
  apply List.map_congr_left
  intro d _
  exact scaledStepIncrement_periodic_y a ha d x y

lemma exists_fundamental_translate (a x : ℝ) (ha : a ≠ 0) :
    ∃ m : ℤ, |a * (x - (m : ℝ) * (1 / a))| ≤ 1 / 2 := by
  refine ⟨⌊a * x + 1 / 2⌋, ?_⟩
  have hl := Int.floor_le (a * x + 1 / 2)
  have hu := Int.lt_floor_add_one (a * x + 1 / 2)
  rw [show a * (x - (⌊a * x + 1 / 2⌋ : ℤ) * (1 / a)) =
    a * x - (⌊a * x + 1 / 2⌋ : ℤ) by field_simp <;> ring]
  exact abs_le.mpr ⟨by linarith, by linarith⟩

end TorusCoverTime.Blocks.B
