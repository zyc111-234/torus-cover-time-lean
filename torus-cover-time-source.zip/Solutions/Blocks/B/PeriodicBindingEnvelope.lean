import Solutions.Blocks.B.PeriodicMassCorrection
import Solutions.Blocks.B.PeriodicBindingVariance
import Solutions.Blocks.B.DirichletMassProfileMean
import Solutions.Blocks.B.GaussianAbsoluteEnvelope

/-! A single random envelope bounds the corrected binding field on the entire
deep disk and has a size-independent exponential-square moment. -/
noncomputable section
open MeasureTheory ProbabilityTheory Classical
open scoped BigOperators
namespace TorusCoverTime.Blocks.B

def bt7EnvelopeMultiplier : ℝ := 2*dirichletMassProfileBound+diskHarnackConstant
def bt7EnvelopeMomentScale (ρ : ℝ) : ℝ := 32*(bt7BindingVarianceBound ρ+1)*bt7EnvelopeMultiplier^2
def periodicBindingEnvelope (N : Size) (root c : Vertex N) (ρ : ℝ) (ξ : FiniteFieldSample N) : ℝ :=
  bt7EnvelopeMultiplier*gaussianAbsoluteEnvelope (diskHarmonicWeight N c (ρ*(N.val:ℝ)/4))
    (normalizedDirichletMass N root (torusDisk N c (ρ*(N.val:ℝ))))
    (fun z ξ => harmonicBindingLS N root (torusDisk N c (ρ*(N.val:ℝ))) ξ z) ξ

theorem bt7EnvelopeMultiplier_pos : 0<bt7EnvelopeMultiplier := by
  have hg : 0<g := by unfold g; positivity
  have hC := diskHarnackConstant_gt_one
  unfold bt7EnvelopeMultiplier dirichletMassProfileBound
  positivity

theorem bt7EnvelopeMomentScale_pos (ρ : ℝ) : 0<bt7EnvelopeMomentScale ρ := by
  have := bt7EnvelopeMultiplier_pos
  have := bt7BindingVarianceBound_pos ρ
  unfold bt7EnvelopeMomentScale
  positivity

@[fun_prop] theorem periodicBindingEnvelope_measurable (N : Size) (root c : Vertex N) (ρ : ℝ) :
    Measurable (periodicBindingEnvelope N root c ρ) := by
  unfold periodicBindingEnvelope gaussianAbsoluteEnvelope normalizedDirichletMass
  fun_prop

theorem periodicBindingEnvelope_nonneg (N : Size) (root c : Vertex N) (ρ : ℝ) (ξ : FiniteFieldSample N) :
    0≤periodicBindingEnvelope N root c ρ ξ := by
  apply mul_nonneg bt7EnvelopeMultiplier_pos.le
  apply add_nonneg (abs_nonneg _)
  exact Finset.sum_nonneg (fun z _ => mul_nonneg (diskHarmonicWeight_nonneg N c _ z) (abs_nonneg _))

theorem correctedBindingLS_le_envelope (N : Size) (root c : Vertex N) (ρ : ℝ)
    (hR : 4*diskHarnackRadiusThreshold≤ρ*(N.val:ℝ)) (hsmall : 2*(ρ*(N.val:ℝ)+1)<N.val)
    (hroot : root∉torusDisk N c (ρ*(N.val:ℝ))) (ξ : FiniteFieldSample N) (x : Vertex N)
    (hx : periodicDistance x c≤(ρ*(N.val:ℝ)/4)/(4*diskGreenInnerScale)) :
    |correctedBindingLS N root (torusDisk N c (ρ*(N.val:ℝ))) ξ x|≤periodicBindingEnvelope N root c ρ ξ := by
  have hR4 : 4≤ρ*(N.val:ℝ) := by linarith [diskHarnackRadiusThreshold_ge_one]
  have hg : 0<g := by unfold g; positivity
  have hV : 0<dirichletMassVariance N root (torusDisk N c (ρ*(N.val:ℝ))) :=
    lt_of_lt_of_le (by positivity) (dirichletMassVariance_disk_lower N root c _ (by linarith) hsmall hroot)
  have hj := harmonic_inner_abs_le N c (ρ*(N.val:ℝ)/4) (by linarith) (by linarith)
    (harmonicBindingLS N root (torusDisk N c (ρ*(N.val:ℝ))) ξ)
    (fun z hz => harmonicBindingLS_harmonic N root _ ξ z
      ((mem_torusDisk N c z _).mpr (by have hh := (mem_torusDisk N c z _).mp hz; linarith))) x hx
  have hq := dirichletMassProfile_centered_bound N root c (ρ*(N.val:ℝ)) (by linarith) hsmall hroot x
  rw [correctedBindingLS_of_data N root _ hV]
  have hmul := mul_le_mul_of_nonneg_right hq
    (abs_nonneg (normalizedDirichletMass N root (torusDisk N c (ρ*(N.val:ℝ))) ξ))
  rw [← abs_mul] at hmul
  have ht := (abs_add_le _ _).trans (add_le_add hj hmul)
  refine ht.trans ?_
  have hs : 0≤∑ z, diskHarmonicWeight N c (ρ*(N.val:ℝ)/4) z*
      |harmonicBindingLS N root (torusDisk N c (ρ*(N.val:ℝ))) ξ z| :=
    Finset.sum_nonneg (fun z _ => mul_nonneg (diskHarmonicWeight_nonneg N c _ z) (abs_nonneg _))
  have hQ : 0≤dirichletMassProfileBound := by unfold dirichletMassProfileBound; positivity
  have hC : 0≤diskHarnackConstant := by linarith [diskHarnackConstant_gt_one]
  change diskHarnackConstant*(_)+2*dirichletMassProfileBound*|normalizedDirichletMass N root _ ξ|≤_
  unfold periodicBindingEnvelope gaussianAbsoluteEnvelope bt7EnvelopeMultiplier
  dsimp only []
  unfold diskHarmonicWeight at hs ⊢
  nlinarith [mul_nonneg hC (abs_nonneg (normalizedDirichletMass N root (torusDisk N c (ρ*(N.val:ℝ))) ξ)),
    mul_nonneg hQ hs]

theorem periodicBindingEnvelope_exp (N : Size) (root c : Vertex N) (ρ : ℝ) (hρ : 0<ρ)
    (hR : 4*diskHarnackRadiusThreshold≤ρ*(N.val:ℝ)) (hsmall : 2*(ρ*(N.val:ℝ)+1)<N.val)
    (hroot : root∉torusDisk N c (ρ*(N.val:ℝ))) :
    Integrable (fun ξ => Real.exp (periodicBindingEnvelope N root c ρ ξ^2/bt7EnvelopeMomentScale ρ)) (finiteFieldLaw N) ∧
      (∫ ξ, Real.exp (periodicBindingEnvelope N root c ρ ξ^2/bt7EnvelopeMomentScale ρ) ∂finiteFieldLaw N)≤2 := by
  have hR4 : 4≤ρ*(N.val:ℝ) := by linarith [diskHarnackRadiusThreshold_ge_one]
  have hg : 0<g := by unfold g; positivity
  have hV : 0<dirichletMassVariance N root (torusDisk N c (ρ*(N.val:ℝ))) :=
    lt_of_lt_of_le (by positivity) (dirichletMassVariance_disk_lower N root c _ (by linarith) hsmall hroot)
  have hz := periodicBindingData_measurable N root (torusDisk N c (ρ*(N.val:ℝ)))
  have hh := gaussian_absolute_envelope_exp (diskHarmonicWeight N c (ρ*(N.val:ℝ)/4))
    (normalizedDirichletMass N root (torusDisk N c (ρ*(N.val:ℝ))))
    (fun z ξ => harmonicBindingLS N root (torusDisk N c (ρ*(N.val:ℝ))) ξ z)
    (diskHarmonicWeight_nonneg N c _) (diskHarmonicWeight_sum N c _ (by linarith) (by linarith))
    ((measurable_pi_apply none).comp hz) (fun z => (measurable_pi_apply (some z)).comp hz)
    (periodicBindingData_gaussian N root _ none) (fun z => periodicBindingData_gaussian N root _ (some z))
    (periodicBindingData_mean N root _ none) (fun z => periodicBindingData_mean N root _ (some z))
    (bt7BindingVarianceBound ρ+1) (by linarith [bt7BindingVarianceBound_pos ρ])
    (by rw [normalizedDirichletMass_variance N root _ hroot hV]; linarith [bt7BindingVarianceBound_pos ρ])
    (fun z hz => by
      have hb := diskExteriorNeighbor_radius N c _ z (diskHarmonicWeight_support N c _ (by linarith) z hz)
      exact (harmonicBindingLS_macroscopic_variance N root c z ρ hρ (by linarith) hsmall hroot (by linarith)).trans (by linarith))
  have he (ξ : FiniteFieldSample N) : periodicBindingEnvelope N root c ρ ξ^2/bt7EnvelopeMomentScale ρ=
      gaussianAbsoluteEnvelope (diskHarmonicWeight N c (ρ*(N.val:ℝ)/4))
        (normalizedDirichletMass N root (torusDisk N c (ρ*(N.val:ℝ))))
        (fun z ξ => harmonicBindingLS N root (torusDisk N c (ρ*(N.val:ℝ))) ξ z) ξ^2/(32*(bt7BindingVarianceBound ρ+1)) := by
    unfold periodicBindingEnvelope bt7EnvelopeMomentScale
    field_simp [bt7EnvelopeMultiplier_pos.ne']
    <;> ring
  simp_rw [he]
  exact hh

theorem massZeroFieldLS_indep_envelope (N : Size) (root c : Vertex N) (ρ : ℝ)
    (hroot : root∉torusDisk N c (ρ*(N.val:ℝ)))
    (hV : 0<dirichletMassVariance N root (torusDisk N c (ρ*(N.val:ℝ)))) :
    IndepFun (massZeroFieldLS N root (torusDisk N c (ρ*(N.val:ℝ))))
      (periodicBindingEnvelope N root c ρ) (finiteFieldLaw N) := by
  exact (massZeroFieldLS_indep_bindingData N root _ hroot hV).comp measurable_id
    (show Measurable (fun b : Option (Vertex N) → ℝ => bt7EnvelopeMultiplier*(|b none|+
      ∑ z, diskHarmonicWeight N c (ρ*(N.val:ℝ)/4) z*|b (some z)|)) by fun_prop)

end TorusCoverTime.Blocks.B
