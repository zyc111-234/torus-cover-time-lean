import Solutions.Blocks.B.KilledDiscrete
import Mathlib.Probability.ConditionalProbability

/-! R1: a feasible core-avoiding exit word has an explicit probability under exact-endpoint conditioning.
The events use the actual discrete skeleton and retain all random holding times in walkLaw. -/

noncomputable section
open MeasureTheory ProbabilityTheory Classical
open scoped ENNReal BigOperators
namespace TorusCoverTime.Blocks.B

def directionCylinder (n : ℕ) (d : Fin n → Fin 4) : Set WalkSample :=
  {ω | (fun j : Fin n => (ω j.val).2) = d}

lemma measurableSet_directionCylinder (n : ℕ) (d : Fin n → Fin 4) :
    MeasurableSet (directionCylinder n d) := by
  exact measurableSet_singleton d |>.preimage (by fun_prop)

lemma directionCylinder_probability (n : ℕ) (d : Fin n → Fin 4) :
    walkLaw (directionCylinder n d) = 1 / (4 : ℝ≥0∞) ^ n := by
  have h := congrArg (fun μ : Measure (Fin n → Fin 4) => μ {d}) (direction_prefix_law n)
  rw [Measure.map_apply (by fun_prop) (measurableSet_singleton d), uniformOn_univ] at h
  simpa [directionCylinder, Set.preimage, Fintype.card_fun] using h

def exitsThroughAt (N : Size) (D : Finset (Vertex N)) (a b : Vertex N) (ω : WalkSample) (n : ℕ) : Prop :=
  b ∉ D ∧ position N a ω n = b ∧ ∀ j : Fin n, position N a ω j.val ∈ D

def exitsThrough (N : Size) (D : Finset (Vertex N)) (a b : Vertex N) : Set WalkSample :=
  {ω | ∃ n : ℕ, exitsThroughAt N D a b ω n}

def exitsThroughAvoiding (N : Size) (D K : Finset (Vertex N)) (a b : Vertex N) : Set WalkSample :=
  {ω | ∃ n : ℕ, exitsThroughAt N D a b ω n ∧ discreteAvoids N a K ω n}

lemma measurableSet_position_mem (N : Size) (a : Vertex N) (D : Finset (Vertex N)) (n : ℕ) :
    MeasurableSet {ω : WalkSample | position N a ω n ∈ D} := by
  have heq : {ω : WalkSample | position N a ω n ∈ D} =
      ⋃ b ∈ D, {ω : WalkSample | position N a ω n = b} := by ext ω; simp
  rw [heq]
  exact D.measurableSet_biUnion (fun b _ => (measurable_position_eq N a b n).setOf)

lemma measurableSet_exitsThroughAt (N : Size) (D : Finset (Vertex N)) (a b : Vertex N) (n : ℕ) :
    MeasurableSet {ω | exitsThroughAt N D a b ω n} := by
  by_cases hb : b ∈ D
  · simp [exitsThroughAt, hb]
  · simp only [exitsThroughAt, hb, not_false_eq_true, true_and, Set.ofPred_and, Set.ofPred_forall]
    exact (measurable_position_eq N a b n).setOf.inter
      (MeasurableSet.iInter fun j => measurableSet_position_mem N a D j.val)

lemma measurableSet_exitsThrough (N : Size) (D : Finset (Vertex N)) (a b : Vertex N) :
    MeasurableSet (exitsThrough N D a b) := by
  simp only [exitsThrough, Set.ofPred_exists]
  exact MeasurableSet.iUnion fun n => measurableSet_exitsThroughAt N D a b n

lemma measurableSet_exitsThroughAvoiding (N : Size) (D K : Finset (Vertex N)) (a b : Vertex N) :
    MeasurableSet (exitsThroughAvoiding N D K a b) := by
  simp only [exitsThroughAvoiding, Set.ofPred_exists, Set.ofPred_and]
  exact MeasurableSet.iUnion fun n => (measurableSet_exitsThroughAt N D a b n).inter
    (measurableSet_discreteAvoids N a K n)

lemma exitsThroughAvoiding_subset (N : Size) (D K : Finset (Vertex N)) (a b : Vertex N) :
    exitsThroughAvoiding N D K a b ⊆ exitsThrough N D a b := by
  rintro ω ⟨n, hn, _⟩
  exact ⟨n, hn⟩

lemma directionCylinder_subset_exit (N : Size) (D K : Finset (Vertex N)) (a b : Vertex N)
    (n : ℕ) (d : Fin n → Fin 4) (hExit : exitsThroughAt N D a b (sampleOfDirections d) n)
    (hAvoid : discreteAvoids N a K (sampleOfDirections d) n) :
    directionCylinder n d ⊆ exitsThroughAvoiding N D K a b := by
  intro ω hω
  have hp (j : ℕ) (hj : j ≤ n) : position N a ω j = position N a (sampleOfDirections d) j := by
    have h := position_of_direction_prefix N a ω n j hj
    rw [show (fun i : Fin n => (ω i.val).2) = d from hω] at h
    exact h.symm
  refine ⟨n, ⟨hExit.1, ?_, ?_⟩, ?_⟩
  · rw [hp n le_rfl]
    exact hExit.2.1
  · intro j
    rw [hp j.val j.isLt.le]
    exact hExit.2.2 j
  · intro j hj
    rw [hp j hj]
    exact hAvoid j hj

lemma feasible_exit_word_probability (N : Size) (D K : Finset (Vertex N)) (a b : Vertex N)
    (n : ℕ) (d : Fin n → Fin 4) (hExit : exitsThroughAt N D a b (sampleOfDirections d) n)
    (hAvoid : discreteAvoids N a K (sampleOfDirections d) n) :
    1 / (4 : ℝ≥0∞) ^ n ≤ walkLaw (exitsThroughAvoiding N D K a b) := by
  rw [← directionCylinder_probability n d]
  exact measure_mono (directionCylinder_subset_exit N D K a b n d hExit hAvoid)

def exactExitLaw (N : Size) (D : Finset (Vertex N)) (a b : Vertex N) : Measure WalkSample :=
  walkLaw[|exitsThrough N D a b]

lemma feasible_exit_word_conditional_probability (N : Size) (D K : Finset (Vertex N)) (a b : Vertex N)
    (n : ℕ) (d : Fin n → Fin 4) (hExit : exitsThroughAt N D a b (sampleOfDirections d) n)
    (hAvoid : discreteAvoids N a K (sampleOfDirections d) n) :
    1 / (4 : ℝ≥0∞) ^ n ≤ exactExitLaw N D a b (exitsThroughAvoiding N D K a b) := by
  rw [exactExitLaw, cond_apply (measurableSet_exitsThrough N D a b)]
  rw [Set.inter_eq_right.mpr (exitsThroughAvoiding_subset N D K a b)]
  apply (feasible_exit_word_probability N D K a b n d hExit hAvoid).trans
  calc
    _ = 1 * walkLaw (exitsThroughAvoiding N D K a b) := (one_mul _).symm
    _ ≤ (walkLaw (exitsThrough N D a b))⁻¹ * walkLaw (exitsThroughAvoiding N D K a b) := by
      have hc : 1 ≤ (walkLaw (exitsThrough N D a b))⁻¹ := by
        rw [← inv_one]
        exact ENNReal.inv_le_inv.mpr prob_le_one
      exact mul_le_mul' hc le_rfl

lemma exactExitLaw_probability_of_feasible (N : Size) (D K : Finset (Vertex N)) (a b : Vertex N)
    (n : ℕ) (d : Fin n → Fin 4) (hExit : exitsThroughAt N D a b (sampleOfDirections d) n)
    (hAvoid : discreteAvoids N a K (sampleOfDirections d) n) :
    IsProbabilityMeasure (exactExitLaw N D a b) := by
  have hp : 0 < walkLaw (exitsThrough N D a b) :=
    (show 0 < 1 / (4 : ℝ≥0∞) ^ n by simp).trans_le
      ((feasible_exit_word_probability N D K a b n d hExit hAvoid).trans
        (measure_mono (exitsThroughAvoiding_subset N D K a b)))
  exact cond_isProbabilityMeasure hp.ne'

lemma finite_domain_exit_avoidance_lower (N : Size) (D K : Finset (Vertex N)) (a b : Vertex N)
    (hpath : ∃ n ≤ D.card + 1, ∃ d : Fin n → Fin 4,
      exitsThroughAt N D a b (sampleOfDirections d) n ∧ discreteAvoids N a K (sampleOfDirections d) n) :
    1 / (4 : ℝ≥0∞) ^ (D.card + 1) ≤ exactExitLaw N D a b (exitsThroughAvoiding N D K a b) := by
  obtain ⟨n, hn, d, hExit, hAvoid⟩ := hpath
  apply le_trans _ (feasible_exit_word_conditional_probability N D K a b n d hExit hAvoid)
  apply ENNReal.div_le_div_left
  exact pow_le_pow_right₀ (by norm_num : (1 : ℝ≥0∞) ≤ 4) hn

end TorusCoverTime.Blocks.B
