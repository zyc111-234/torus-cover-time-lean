import Solutions.Blocks.B.CenteredExteriorWindow
import Solutions.Blocks.B.CoarseCenteredParameters
import Solutions.Blocks.B.R8NestedGaussianWindow

/-! Uniform L^(7 gamma) gain for bounded actual square-root counts in an exterior-weighted window. -/
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B


theorem r8_centered_coarse_exterior (hWalk : WalkModelRegular) (γ : ℝ) (hγ : 0 < γ) (hγ1 : γ ≤ 1) :
    ∀ᶠ N : Size in atTop, ∀ c root : Vertex N, ∀ m : ℕ, ∀ w : Fin (2*m) → Vertex N, ∀ q : ℝ,
      (logSize N)^(16*γ) ≤ q → q ≤ logSize N-(logSize N)^(16*γ) →
      root ∉ torusDisk N c (Real.exp (q+2*q^γ)) →
      walkLaw {ω | adaptiveExitWord N (alternatingDomain N (torusDisk N c (Real.exp (q+q^γ)))
        (torusDisk N c (Real.exp (q+2*q^γ)))) root (2*m) ω = w} ≠ 0 →
      q ≤ Real.sqrt ((m:ℝ)*q^γ) → Real.sqrt ((m:ℝ)*q^γ) ≤ 10*logSize N →
      ∀ E : TraversalExteriorSample m × ℝ → ℝ≥0∞, Measurable E → (∀ y u, E (y,u) ≤ 1) →
      ∀ l r : ℝ,
      let I := torusDisk N c (Real.exp (q+q^γ))
      let O := torusDisk N c (Real.exp (q+2*q^γ))
      let d := (m:ℝ)*Real.exp (2*logSize N-(logSize N)^(16*γ))
      conditionalTraversalExteriorSlice N I O root m w
        (r7WordCenteredOccupation N c root m w γ q ((logSize N)^(4*γ)/2)) E l r ≤
        2*ENNReal.ofReal (2*Real.exp (-(r7ConcentrationConstant/16)*(logSize N)^(7*γ)))*
          conditionalTraversalExteriorSlice N I O root m w univ E (l-d) (r+d) +
        ENNReal.ofReal (r-l)*ENNReal.ofReal (Real.exp (-Real.exp ((logSize N)^(16*γ)/2))) := by
  filter_upwards [r7_centered_exterior_window hWalk γ hγ hγ1,r8_centered_side_conditions γ hγ,
    blockB_logSize_tendsto.eventually_ge_atTop 10] with N hwin hside hL
  intro c root m w q hq hqL hr hw hvlo hvhi E hE hE1 l r
  have hq1 : 1 ≤ q := (Real.one_le_rpow (by linarith : 1 ≤ logSize N) (by positivity : 0 ≤ 16*γ)).trans hq
  have hqL' := hqL.trans (sub_le_self _ (Real.rpow_nonneg (logSize_pos N).le _))
  have hm := nested_count_le_polynomial _ _ m hL (Real.one_le_rpow hq1 hγ.le) hvhi
  have hs := hside q _ hq hqL' hvlo hvhi
  have hb := hwin c root m w q hq hqL hm hr hw E hE hE1 _ l r hs.1 hs.2.2 hs.2.1
  have he : 2*Real.exp (-(r7ConcentrationConstant/4)*((logSize N)^(4*γ)/2)^2/q^γ) ≤
      2*Real.exp (-(r7ConcentrationConstant/16)*(logSize N)^(7*γ)) := by
    apply mul_le_mul_of_nonneg_left _ (by norm_num : (0:ℝ) ≤ 2)
    apply Real.exp_le_exp.mpr
    have ht := mul_le_mul_of_nonneg_left
      (r8_centered_exponent_scale (logSize N) q γ (logSize_pos N) (by linarith) hqL' hγ.le)
      (by have := r7ConcentrationConstant_pos; positivity : 0 ≤ r7ConcentrationConstant/4)
    calc
      _ = -(r7ConcentrationConstant/4*(((logSize N)^(4*γ)/2)^2/q^γ)) := by ring
      _ ≤ -(r7ConcentrationConstant/4*((logSize N)^(7*γ)/4)) := neg_le_neg ht
      _ = _ := by ring
  exact hb.trans (add_le_add (mul_le_mul' (mul_le_mul' le_rfl (ENNReal.ofReal_le_ofReal he)) le_rfl) le_rfl)


end TorusCoverTime.Blocks.B
