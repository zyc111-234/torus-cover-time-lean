import Solutions.Blocks.B.R7ShellWindow

/-! Physical windows centered at the original Phase A time stay in a fixed
central shell band after the full source energy cutoff is added. -/

noncomputable section
open MeasureTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

theorem timeScale_eq_vertexCount (N : Size) : timeScale N = g*vertexCount N*logSize N := rfl

theorem r7_image_energy_time (N : Size) :
    (64*g)*vertexCount N*logSize N/2 = 32*timeScale N := by
  rw [timeScale_eq_vertexCount]
  ring

def r7ShellWindowRadius (H : ℝ) : ℝ := H+(g+greenDiagonalErrorConstant)/g+32

theorem r7ShellWindowRadius_nonneg (H : ℝ) (hH : 0 ≤ H) : 0 ≤ r7ShellWindowRadius H := by
  unfold r7ShellWindowRadius
  have := coarseProbe_g_pos
  have := greenDiagonalErrorConstant_pos
  positivity

theorem central_physical_shell_window (N : Size) (H l r : ℝ) (hH : 0 ≤ H)
    (hL : 1 ≤ logSize N) (hl : phaseACenter N-H*timeScale N ≤ l)
    (hr : r ≤ phaseACenter N+H*timeScale N) :
    ∀ s ∈ Icc l (r+(64*g)*vertexCount N*logSize N/2),
      |shellTimeCoordinate N s| ≤ r7ShellWindowRadius H := by
  intro s hs
  have hg := coarseProbe_g_pos
  have ht := timeScale_pos N
  have hG := D.greenDiagonal_le_log_multiple N hL
  have hnG := mul_le_mul_of_nonneg_left hG (vertexCount_pos N).le
  have he : vertexCount N*((g+greenDiagonalErrorConstant)*logSize N) =
      ((g+greenDiagonalErrorConstant)/g)*timeScale N := by
    rw [timeScale_eq_vertexCount]
    field_simp
  rw [he] at hnG
  rw [r7_image_energy_time] at hs
  have hG0 := mul_nonneg (vertexCount_pos N).le (greenDiagonal_pos N).le
  have hV : 0 ≤ (g+greenDiagonalErrorConstant)/g := by have := greenDiagonalErrorConstant_pos; positivity
  rw [abs_le]
  unfold shellTimeCoordinate r7ShellWindowRadius
  constructor
  · apply (le_div_iff₀ ht).mpr
    nlinarith [hs.1]
  · apply (div_le_iff₀ ht).mpr
    nlinarith [hs.2]

theorem central_image_window_length (N : Size) (H l r : ℝ)
    (hl : phaseACenter N-H*timeScale N ≤ l) (hr : r ≤ phaseACenter N+H*timeScale N) :
    r+(64*g)*vertexCount N*logSize N/2-l ≤ (2*H+32)*timeScale N := by
  rw [r7_image_energy_time]
  linarith

def normalizedFarRootLowHarmonicMass (N : Size) (c : Vertex N) (γ q a l r : ℝ) : ℝ≥0∞ :=
  (ENNReal.ofReal (timeScale N))⁻¹ * farRootLowHarmonicMass N c γ q a l r

theorem central_low_harmonic_bound (γ H : ℝ) (hγ : 0 < γ) (hγ1 : 16*γ < 1) (hH : 0 ≤ H) :
    ∃ c₀ C : ℝ, 0 < c₀ ∧ 0 < C ∧ ∀ᶠ N : Size in atTop,
      ∀ c : Vertex N, ∀ q v Δ l r : ℝ,
        (logSize N)^(16*γ) ≤ q → q ≤ logSize N-(logSize N)^(16*γ) → q ≤ v → 0 ≤ Δ →
        phaseACenter N-H*timeScale N ≤ l → r ≤ phaseACenter N+H*timeScale N →
        normalizedFarRootLowHarmonicMass N c γ q (v+Δ) l r ≤
          ENNReal.ofReal (2*(2*H+32)*Real.sqrt (logSize N)/coarseProbeProbabilityConstant) *
            r7ShellTailBudget N (r7ShellWindowRadius H) c₀ C q v Δ := by
  obtain ⟨c₀,C,hc,hC,hbound⟩ := r7_low_harmonic_physical_bound γ (r7ShellWindowRadius H)
    hγ hγ1 (r7ShellWindowRadius_nonneg H hH)
  refine ⟨c₀,C,hc,hC,?_⟩
  filter_upwards [hbound,blockB_logSize_tendsto.eventually_ge_atTop 1] with N hN hL
  intro c q v Δ l r hq hqL hqv hΔ hl hr
  have hh := hN c q v Δ l r hq hqL hqv hΔ (central_physical_shell_window N H l r hH hL hl hr)
  have hlen := ENNReal.ofReal_le_ofReal (central_image_window_length N H l r hl hr)
  have hupper := hh.trans (mul_le_mul' le_rfl (mul_le_mul' (mul_le_mul' hlen le_rfl) le_rfl))
  have hnorm := mul_le_mul' (le_refl ((ENNReal.ofReal (timeScale N))⁻¹)) hupper
  have ht0 : ENNReal.ofReal (timeScale N) ≠ 0 := ENNReal.ofReal_ne_zero_iff.mpr (timeScale_pos N)
  have hp := coarseProbeProbabilityConstant_pos
  have hs := Real.sqrt_pos.mpr (logSize_pos N)
  have hid : (ENNReal.ofReal (timeScale N))⁻¹ *
      ((ENNReal.ofReal (coarseProbeProbabilityConstant/Real.sqrt (logSize N)))⁻¹ *
        (ENNReal.ofReal ((2*H+32)*timeScale N)*2*r7ShellTailBudget N (r7ShellWindowRadius H) c₀ C q v Δ)) =
      ENNReal.ofReal (2*(2*H+32)*Real.sqrt (logSize N)/coarseProbeProbabilityConstant)*
        r7ShellTailBudget N (r7ShellWindowRadius H) c₀ C q v Δ := by
    rw [ENNReal.ofReal_mul (by positivity : 0 ≤ 2*H+32)]
    have he : (ENNReal.ofReal (coarseProbeProbabilityConstant/Real.sqrt (logSize N)))⁻¹ =
        ENNReal.ofReal (Real.sqrt (logSize N)/coarseProbeProbabilityConstant) := by
      rw [← ENNReal.ofReal_inv_of_pos (div_pos hp hs),inv_div]
    rw [he]
    calc
      _ = ((ENNReal.ofReal (timeScale N))⁻¹*ENNReal.ofReal (timeScale N))*
        (2*ENNReal.ofReal (2*H+32)*ENNReal.ofReal (Real.sqrt (logSize N)/coarseProbeProbabilityConstant))*
          r7ShellTailBudget N (r7ShellWindowRadius H) c₀ C q v Δ := by ac_rfl
      _ = _ := by
        rw [ENNReal.inv_mul_cancel ht0 ENNReal.ofReal_ne_top,one_mul,
          show (2:ℝ≥0∞) = ENNReal.ofReal (2:ℝ) by norm_num,
          ← ENNReal.ofReal_mul (by norm_num : (0:ℝ) ≤ 2),
          ← ENNReal.ofReal_mul (by positivity : 0 ≤ 2*(2*H+32))]
        congr 2
        ring
  exact hnorm.trans_eq hid

end TorusCoverTime.Blocks.B
