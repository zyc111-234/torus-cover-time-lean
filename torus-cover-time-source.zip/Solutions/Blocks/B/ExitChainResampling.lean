import Solutions.Blocks.B.ExitChainTailLaw

/-! Reassembling independently sampled endpoint-conditioned records gives
exactly the original conditioned path law, with its entire unused future. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

def recordsJoin : (n : ℕ) → (Fin n → ℕ × WalkSample) → WalkSample → WalkSample
  | 0, _, η => η
  | n+1, p, η => recordJoin (p 0) (recordsJoin n (fun j => p j.succ) η)

def recordsDuration (n : ℕ) (p : Fin n → ℕ × WalkSample) : ℝ :=
  ∑ j, excursionRecordDuration (p j)

theorem recordsJoin_measurable (n : ℕ) :
    Measurable (fun q : (Fin n → ℕ × WalkSample) × WalkSample => recordsJoin n q.1 q.2) := by
  induction n with
  | zero => exact measurable_snd
  | succ n ih =>
    have ht : Measurable (fun q : (Fin (n+1) → ℕ × WalkSample) × WalkSample =>
        ((fun j : Fin n => q.1 j.succ), q.2)) :=
      (measurable_pi_lambda _ fun j : Fin n =>
        (measurable_pi_apply j.succ).comp measurable_fst).prodMk measurable_snd
    have h0 : Measurable (fun q : (Fin (n+1) → ℕ × WalkSample) × WalkSample => q.1 0) :=
      (measurable_pi_apply 0).comp measurable_fst
    exact recordJoin_measurable.comp (h0.prodMk (ih.comp ht))

theorem recordsDuration_measurable (n : ℕ) : Measurable (recordsDuration n) :=
  Finset.measurable_sum _ fun j _ => excursionRecordDuration_measurable.comp (measurable_pi_apply j)

theorem recordsJoin_exitChain (N : Size) (D : ℕ → Finset (Vertex N)) (a : ℕ → Vertex N)
    (n : ℕ) (ω : WalkSample) :
    recordsJoin n (fun j : Fin n => exitChainRecord N D a j.val ω) (exitChainTail N D a n ω) = ω := by
  induction n generalizing D a ω with
  | zero => rfl
  | succ n ih =>
    change recordJoin (finiteExitRecord N (D 0) (a 0) ω)
      (recordsJoin n (fun j : Fin n => exitChainRecord N (fun k => D (k+1)) (fun k => a (k+1)) j.val
        (finiteExitTail N (D 0) (a 0) ω))
        (exitChainTail N (fun k => D (k+1)) (fun k => a (k+1)) n (finiteExitTail N (D 0) (a 0) ω))) = ω
    rw [ih]
    exact recordJoin_stopped ω

theorem recordsDuration_exitChain (N : Size) (D : ℕ → Finset (Vertex N)) (a : ℕ → Vertex N)
    (n : ℕ) (ω : WalkSample) :
    recordsDuration n (fun j : Fin n => exitChainRecord N D a j.val ω) = exitChainTime N D a n ω := by
  rw [recordsDuration, exitChainTime_eq_sum]
  exact Fin.sum_univ_eq_sum_range (fun j => excursionRecordDuration (exitChainRecord N D a j ω)) n

theorem recordsJoin_conditioned_measurePreserving (N : Size) (D : ℕ → Finset (Vertex N))
    (hD : ∀ k, ∃ b : Vertex N, b ∉ D k) (a b : ℕ → Vertex N) (n : ℕ) :
    MeasurePreserving (fun q : (Fin n → ℕ × WalkSample) × WalkSample => recordsJoin n q.1 q.2)
      ((Measure.pi (fun j : Fin n => exactExitRecordLaw N (D j.val) (a j.val) (b j.val))).prod walkLaw)
      (walkLaw[|exitChainEndpoints N D a b n]) := by
  refine ⟨recordsJoin_measurable n, ?_⟩
  rw [← exitChainRecord_conditioned_tail_law N D hD a b n,
    Measure.map_map (recordsJoin_measurable n)
      ((measurable_pi_lambda _ fun j : Fin n => exitChainRecord_measurable N D hD a j.val).prodMk
        (exitChainTail_measurePreserving N D hD a n).measurable)]
  simp only [Function.comp_def, recordsJoin_exitChain, Measure.map_id']

theorem lintegral_exitChain_reassemble (N : Size) (D : ℕ → Finset (Vertex N))
    (hD : ∀ k, ∃ b : Vertex N, b ∉ D k) (a b : ℕ → Vertex N) (n : ℕ)
    (F : WalkSample → ℝ≥0∞) (hF : Measurable F) :
    (∫⁻ ω, F ω ∂walkLaw[|exitChainEndpoints N D a b n]) =
      ∫⁻ p, ∫⁻ η, F (recordsJoin n p η) ∂walkLaw
        ∂Measure.pi (fun j : Fin n => exactExitRecordLaw N (D j.val) (a j.val) (b j.val)) := by
  rw [← (recordsJoin_conditioned_measurePreserving N D hD a b n).map_eq,
    lintegral_map hF (recordsJoin_measurable n)]
  exact lintegral_prod _ (hF.comp (recordsJoin_measurable n)).aemeasurable

theorem walk_jumpTime_shift (N : Size) (a : Vertex N) (ω : WalkSample) (n : ℕ)
    (hpos : ∀ j, 0 < (ω j).1)
    (hnon : Tendsto (jumpTime (fun j => ω (n+j))) atTop atTop)
    (t : ℝ) (ht : 0 ≤ t) :
    walk N a ω (jumpTime ω n+t) = walk N (position N a ω n) (fun j => ω (n+j)) t := by
  have he : recordJoin (n,ω) (fun j => ω (n+j)) = ω := by
    funext j
    by_cases hj : j < n
    · simp only [recordJoin, if_pos hj]
    · simp only [recordJoin, if_neg hj, Nat.add_sub_of_le (Nat.le_of_not_gt hj)]
  have hh := recordJoin_walk_future N a (n,ω) (fun j _ => hpos j)
    (fun j => hpos (n+j)) hnon t ht
  simpa only [he, excursionRecordDuration, exitRecordEndpoint] using hh

theorem exitChain_walk_future_ae (N : Size) (D : ℕ → Finset (Vertex N))
    (hD : ∀ k, ∃ b : Vertex N, b ∉ D k) (a b : ℕ → Vertex N) (n : ℕ)
    (hab : ∀ k < n, b k = a (k+1)) :
    ∀ᵐ ω ∂walkLaw[|exitChainEndpoints N D a b n], ∀ t : ℝ, 0 ≤ t →
      walk N (a 0) ω (exitChainTime N D a n ω+t) = walk N (a n) (exitChainTail N D a n ω) t := by
  have hr : ∀ᵐ ω ∂walkLaw[|exitChainEndpoints N D a b n],
      (∀ j, 0 < (ω j).1) ∧ Tendsto (jumpTime ω) atTop atTop :=
    cond_absolutelyContinuous.ae_le A.holding_positive_and_nonexplosive
  have ht : ∀ᵐ ω ∂walkLaw[|exitChainEndpoints N D a b n],
      Tendsto (jumpTime (exitChainTail N D a n ω)) atTop atTop :=
    cond_absolutelyContinuous.ae_le
      ((exitChainTail_measurePreserving N D hD a n).quasiMeasurePreserving.ae
        (A.holding_positive_and_nonexplosive.mono fun _ h => h.2))
  filter_upwards [hr, ht, ae_cond_mem (μ := walkLaw) (exitChainEndpoints_measurable N D hD a b n)]
    with ω hreg htail hω
  intro t ht
  rw [exitChainTail_eq_shift] at htail
  rw [exitChainTime, walk_jumpTime_shift N (a 0) ω _ hreg.1 htail t ht,
    exitChain_position N D a b n hab ω hω n le_rfl, ← exitChainTail_eq_shift]

end TorusCoverTime.Blocks.B
