import Solutions.Blocks.B.ExactExitSoftness
import Solutions.Blocks.B.DiskGreenBounds

/-! B-T9: the actual two-site, specified-exit block probability (B.46).
The sites are distinct and have logarithmic separation in [q-2,q).
No Green, Laplace, or probability estimate is an input to this goal. -/
noncomputable section
open MeasureTheory ProbabilityTheory Filter Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

def BT9Conclusion (γ U : ℝ) : Prop :=
  ∃ K : ℝ, 0 < K ∧ ∀ᶠ q : ℝ in atTop,
    ∀ N : Size, ∀ x z : Vertex N, ∀ m : ℕ, ∀ a b : Fin m → Vertex N,
      x ≠ z → q-2 ≤ Real.log (periodicDistance x z) →
      Real.log (periodicDistance x z) < q →
      2*(Real.exp (q+2*q^γ)+1) < N.val →
      (∀ i, |periodicDistance (a i) x-Real.exp (q+q^γ)| ≤ 2) →
      (∀ i, diskExteriorNeighbor N x (Real.exp (q+2*q^γ)) (b i)) →
      (exactExitProductLaw N (torusDisk N x (Real.exp (q+2*q^γ))) m a b).real
        {ω | (exitBlockOccupation N (torusDisk N x (Real.exp (q+2*q^γ))) m a ω x +
          exitBlockOccupation N (torusDisk N x (Real.exp (q+2*q^γ))) m a ω z)/g ≤ U} ≤
        Real.exp (-4*q-4*Real.sqrt 2*(Real.sqrt ((m:ℝ)*q^γ)-Real.sqrt 2*q)+K*q^γ)

def BT9TwoSoftConclusion (γ u : ℝ) : Prop :=
  ∃ K : ℝ, 0 < K ∧ ∀ᶠ q : ℝ in atTop,
    ∀ N : Size, ∀ x z : Vertex N, ∀ m : ℕ, ∀ a b : Fin m → Vertex N,
      x ≠ z → q-2 ≤ Real.log (periodicDistance x z) →
      Real.log (periodicDistance x z) < q →
      2*(Real.exp (q+2*q^γ)+1) < N.val →
      (∀ i, |periodicDistance (a i) x-Real.exp (q+q^γ)| ≤ 2) →
      (∀ i, diskExteriorNeighbor N x (Real.exp (q+2*q^γ)) (b i)) →
      (exactExitProductLaw N (torusDisk N x (Real.exp (q+2*q^γ))) m a b).real
        {ω | exitBlockOccupation N (torusDisk N x (Real.exp (q+2*q^γ))) m a ω x ≤ u ∧
          exitBlockOccupation N (torusDisk N x (Real.exp (q+2*q^γ))) m a ω z ≤ u} ≤
        Real.exp (-4*q-4*Real.sqrt 2*(Real.sqrt ((m:ℝ)*q^γ)-Real.sqrt 2*q)+K*q^γ)

end TorusCoverTime.Blocks.B
