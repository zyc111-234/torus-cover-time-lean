import Solutions.Blocks.B.BT10Record
import Solutions.Blocks.B.R8SoftPhysicalExterior
import Solutions.Blocks.B.WordWindowMixture

/-! One resampling pays the two-site event, preserving the physical clock,
the specified endpoint word and the full duration remainder. -/
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

def bt10SoftTest (N : Size) (x y root : Vertex N) (U : ℝ) (z : WalkSample × ℝ) : ℝ≥0∞ :=
  if (localTime N root z.1 z.2 x+localTime N root z.1 z.2 y)/g≤U then 1 else 0

def bt10PairFactor (γ K q : ℝ) (m : ℕ) : ℝ≥0∞ :=
  2*min 1 (ENNReal.ofReal (bt10PairEnvelope γ K q m))

theorem bt10PairFactor_le_two (γ K q : ℝ) (m : ℕ) : bt10PairFactor γ K q m≤2 := by
  exact (mul_le_mul' le_rfl (min_le_left _ _)).trans_eq (mul_one _)

theorem bt10PairFactor_le_exp (γ K q : ℝ) (m : ℕ) :
    bt10PairFactor γ K q m≤2*ENNReal.ofReal (bt10PairEnvelope γ K q m) :=
  mul_le_mul' le_rfl (min_le_right _ _)

theorem bt10_word_window_record (N : Size) (I O : Finset (Vertex N)) (x y root : Vertex N)
    (hIO : I⊆O) (hx : x∈I) (hy : y∈I) (hr : root∉O)
    (m : ℕ) (w : Fin (2*m) → Vertex N) (U l r : ℝ) :
    physicalWordWindow N I O root m w (bt10SoftTest N x y root U) l r =
      conditionalTraversalExteriorSlice N I O root m w {p | bt10WordCost N x y root m w p≤U}
        (fun _ => 1) l r := by
  have hI : I.Nonempty := ⟨x,hx⟩
  have hcount := (cond_absolutelyContinuous (μ := walkLaw)
    (s := {ω | adaptiveExitWord N (alternatingDomain N I O) root (2*m) ω=w})).ae_le
      (completedTraversalCount_loop_iff_ae N I O hIO hI root hr)
  have hocc := (cond_absolutelyContinuous (μ := walkLaw)
    (s := {ω | adaptiveExitWord N (alternatingDomain N I O) root (2*m) ω=w})).ae_le
      (traversalOccupation_loop_localTime_ae N I O hIO hI root hr _ (bt10Potential_support N x y I hx hy))
  unfold physicalWordWindow conditionalTraversalExteriorSlice
  apply lintegral_congr_ae
  filter_upwards [hcount,hocc,ae_cond_mem (μ := walkLaw)
    ((adaptiveExitWord_measurable N (alternatingDomain N I O) root (2*m)) (measurableSet_singleton w))]
    with ω hcount hocc hw
  apply lintegral_congr_ae
  filter_upwards [ae_restrict_mem (measurableSet_Ioi
    (a := adaptiveExitTime N (alternatingDomain N I O) root (2*m) ω))] with t ht
  by_cases hb : t<adaptiveExitTime N (alternatingDomain N I O) root (2*m+1) ω ∧
      walk N root ω t=root ∧ t∈Icc l r
  · have ht0 : 0≤t := (jumpTime_nonneg ω _).trans ht.le
    have hm := (hcount t ht0 hb.2.1 m).mpr ⟨ht.le,hb.1⟩
    have he := hocc t ht0 hb.2.1
    rw [hm,bt10Potential_sum] at he
    have hword := traversalWordOutwardOccupation_of_word N I O root m w (bt10Potential N x y) ω hw
    have hcost : bt10WordCost N x y root m w
        (fun j => adaptiveExitRecord N (alternatingDomain N I O) root j.val.val ω) =
        (localTime N root ω t x+localTime N root ω t y)/g := hword.trans he.symm
    simp only [if_pos hb,traversalExteriorMarkedTest,Set.mem_ofPred_eq,hcost,bt10SoftTest]
  · simp only [if_neg hb]

theorem bt10_unmarked_word_window (N : Size) (I O : Finset (Vertex N)) (root : Vertex N)
    (m : ℕ) (w : Fin (2*m) → Vertex N) (l r : ℝ) :
    conditionalTraversalExteriorSlice N I O root m w univ (fun _ => 1) l r =
      physicalWordWindow N I O root m w (fun _ => 1) l r := by
  simp only [conditionalTraversalExteriorSlice,physicalWordWindow,traversalExteriorMarkedTest,mem_univ,if_true]

theorem bt10_word_window_bound (hWalk : WalkModelRegular) (γ U : ℝ)
    (hγ : 0<γ) (hγ1 : γ<1) (hU : 0≤U) :
    ∃ K : ℝ, 0<K ∧ ∀ᶠ N : Size in atTop, ∀ x y root : Vertex N,
      ∀ m : ℕ, ∀ w : Fin (2*m) → Vertex N, ∀ q : ℝ,
      (logSize N)^(16*γ)≤q → q≤logSize N-(logSize N)^(16*γ) →
      (m:ℝ)≤(logSize N)^4+1 → x≠y → q-2≤Real.log (periodicDistance x y) →
      Real.log (periodicDistance x y)<q → root∉torusDisk N x (Real.exp (q+2*q^γ)) →
      walkLaw {ω | adaptiveExitWord N (alternatingDomain N (torusDisk N x (Real.exp (q+q^γ)))
        (torusDisk N x (Real.exp (q+2*q^γ)))) root (2*m) ω=w}≠0 → ∀ l r : ℝ,
      physicalWordWindow N (torusDisk N x (Real.exp (q+q^γ)))
        (torusDisk N x (Real.exp (q+2*q^γ))) root m w (bt10SoftTest N x y root U) l r ≤
        bt10PairFactor γ K q m*physicalWordWindow N (torusDisk N x (Real.exp (q+q^γ)))
          (torusDisk N x (Real.exp (q+2*q^γ))) root m w (fun _ => 1)
          (l-r7WindowStep N γ m) (r+r7WindowStep N γ m)+
        ENNReal.ofReal (r-l)*ENNReal.ofReal (Real.exp (-Real.exp ((logSize N)^(16*γ)/2))) := by
  obtain ⟨K,hK,hword⟩ := bt10_positive_word_bound γ U (bt9_conclusion hWalk γ U hγ hγ1 hU)
  obtain ⟨q0,hq0⟩ := eventually_atTop.mp hword
  have hQ := (tendsto_rpow_atTop (by positivity : 0<16*γ)).comp blockB_logSize_tendsto
  refine ⟨K,hK,?_⟩
  filter_upwards [r6_positive_word_duration hWalk γ hγ hγ1.le,r6_disk_radius_embedding γ hγ,
    hQ.eventually_ge_atTop q0] with N htail hsmall hbase
  intro x y root m w q hq hqL hm hxy hlo hhi hr hw l r
  have hq0' := (Real.rpow_nonneg (logSize_pos N).le (16*γ)).trans hq
  have hIO := torusDisk_subset N x (Real.exp (q+q^γ)) (Real.exp (q+2*q^γ))
    (Real.exp_le_exp.mpr (by linarith [Real.rpow_nonneg hq0' γ]))
  have hx : x∈torusDisk N x (Real.exp (q+q^γ)) :=
    (mem_torusDisk N x x _).mpr (by rw [periodicDistance_self_zero]; positivity)
  have hy : y∈torusDisk N x (Real.exp (q+q^γ)) :=
    torusDisk_subset N x _ _ (Real.exp_le_exp.mpr (by linarith [Real.rpow_nonneg hq0' γ]))
      (bt9_site_geometry N x y q hxy hhi).2
  have hI : (torusDisk N x (Real.exp (q+q^γ))).Nonempty := ⟨x,hx⟩
  have := traversalWordOutwardLaw_probability N _ _ root hI hr m w hw
  have hρ := le_min (prob_le_one) (hq0 q (hbase.trans hq) N x y root m w hxy hlo hhi hr
    (hsmall q hq0' hqL) hw)
  rw [bt10_word_window_record N _ _ x y root hIO hx hy hr m w U l r]
  have ht := actual_word_exterior_window_bound N _ _ root hI hr m w hw _
    (measurableSet_le (bt10WordCost_measurable N x y root m w) measurable_const)
    (fun _ => 1) measurable_const (fun _ _ => le_rfl) l r _ _ _ hρ
    (htail x root m w q hq hqL hm hr hw)
    (r6_superexponential_error_le_half _ (Real.rpow_nonneg (logSize_pos N).le _))
  rwa [bt10_unmarked_word_window] at ht

end TorusCoverTime.Blocks.B
