import Solutions.Blocks.B.NestedExteriorCount
import Solutions.Blocks.B.ExteriorHarmonicTests

/-! A concrete bounded exterior test for the exact outer count and its harmonic deviation. -/
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B


def outerCountHarmonicTest (N : Size) (Q O : Finset (Vertex N)) (c root : Vertex N)
    (k : ℕ) (q v Δ : ℝ) (z : WalkSample × ℝ) : ℝ≥0∞ :=
  if completedTraversalCount N Q O root z.1 z.2 = k ∧
    Δ < |Real.sqrt (harmonicPathOccupation N c root q z)-v| then 1 else 0

def exteriorCountHarmonicTest (N : Size) (Q O : Finset (Vertex N)) (c root : Vertex N)
    (m : ℕ) (w : Fin (2*m) → Vertex N) (k : ℕ) (q v Δ : ℝ) (z : TraversalExteriorSample m × ℝ) : ℝ≥0∞ :=
  if exteriorTraversalCount N Q O root c m w z = k ∧
    Δ < |Real.sqrt (exteriorHarmonicOccupation N c root m w q z)-v| then 1 else 0

theorem outerCountHarmonicTest_measurable (N : Size) (Q O : Finset (Vertex N)) (c root : Vertex N)
    (k : ℕ) (q v Δ : ℝ) : Measurable (outerCountHarmonicTest N Q O c root k q v Δ) :=
  measurable_const.ite (((completedTraversalCount_measurable N Q O root) (measurableSet_singleton k)).inter
    (measurableSet_lt measurable_const (((harmonicPathOccupation_measurable N c root q).sqrt.sub_const v).abs)))
    measurable_const

theorem exteriorCountHarmonicTest_measurable (N : Size) (Q O : Finset (Vertex N)) (c root : Vertex N)
    (m : ℕ) (w : Fin (2*m) → Vertex N) (k : ℕ) (q v Δ : ℝ) :
    Measurable (exteriorCountHarmonicTest N Q O c root m w k q v Δ) :=
  measurable_const.ite (((exteriorTraversalCount_measurable N Q O root c m w) (measurableSet_singleton k)).inter
    (measurableSet_lt measurable_const (((exteriorHarmonicOccupation_measurable N c root m w q).sqrt.sub_const v).abs)))
    measurable_const

theorem exteriorCountHarmonicTest_le_one (N : Size) (Q O : Finset (Vertex N)) (c root : Vertex N)
    (m : ℕ) (w : Fin (2*m) → Vertex N) (k : ℕ) (q v Δ : ℝ) (z : TraversalExteriorSample m × ℝ) :
    exteriorCountHarmonicTest N Q O c root m w k q v Δ z ≤ 1 := by
  unfold exteriorCountHarmonicTest
  split_ifs <;> simp

theorem exteriorCountHarmonicTest_actual (N : Size) (I J Q O : Finset (Vertex N))
    (hIJ : I ⊆ J) (hI : I.Nonempty) (hJQ : J ⊆ Q) (hQO : Q ⊆ O)
    (c root : Vertex N) (hc : c ∈ Q) (hr : root ∉ O)
    (m : ℕ) (w : Fin (2*m) → Vertex N) (k : ℕ) (q v Δ : ℝ)
    (hU : ∀ x ∈ J, diskHarmonicWeight N c (Real.exp (q+1)) x/g = 0) :
    ∀ᵐ ω ∂walkLaw[|{ω | adaptiveExitWord N (alternatingDomain N I J) root (2*m) ω = w}],
      ∀ t, adaptiveExitTime N (alternatingDomain N I J) root (2*m) ω ≤ t →
        outerCountHarmonicTest N Q O c root k q v Δ (ω,t) =
          exteriorCountHarmonicTest N Q O c root m w k q v Δ
            (traversalExteriorData N I J root m ω,t-adaptiveExitTime N (alternatingDomain N I J) root (2*m) ω) := by
  have hrJ : root ∉ J := fun h => hr (hQO (hJQ h))
  filter_upwards [exteriorTraversalCount_actual_ae N I J Q O hIJ hI hJQ hQO root c hr hc m w,
    exteriorOccupation_actual_ae N I J hI root hrJ _ hU m w] with ω hn hH
  intro t ht
  unfold outerCountHarmonicTest exteriorCountHarmonicTest
  have he : harmonicPathOccupation N c root q (ω,t) =
      exteriorHarmonicOccupation N c root m w q
        (traversalExteriorData N I J root m ω,t-adaptiveExitTime N (alternatingDomain N I J) root (2*m) ω) := hH t ht
  rw [hn t ht,he]


end TorusCoverTime.Blocks.B

