import Solutions.Blocks.B.EigenvalueBounds

/-! Exact finite Fourier characters and their generator eigenvalue equations. -/

noncomputable section
open scoped BigOperators

namespace TorusCoverTime.Blocks.B

def coordinateCharacter (N : Size) (a : ZMod N.val) : ℂ :=
  (AddCircle.toCircle (ZMod.toAddCircle a) : Circle)

@[simp] lemma coordinateCharacter_zero (N : Size) : coordinateCharacter N 0 = 1 := by
  simp [coordinateCharacter]

lemma coordinateCharacter_add (N : Size) (a b : ZMod N.val) :
    coordinateCharacter N (a + b) = coordinateCharacter N a * coordinateCharacter N b := by
  simp [coordinateCharacter, map_add, AddCircle.toCircle_add]

def finiteCharacter (N : Size) (k x : Vertex N) : ℂ :=
  coordinateCharacter N (k.1 * x.1 + k.2 * x.2)

lemma coordinateCharacter_int_formula (N : Size) (j : ℤ) :
    coordinateCharacter N (j : ZMod N.val) =
      Complex.exp (((2 * Real.pi * j / N.val : ℝ) : ℂ) * Complex.I) := by
  rw [coordinateCharacter, ZMod.toAddCircle_intCast, AddCircle.toCircle_apply_mk, Circle.coe_exp]
  congr 1
  push_cast
  ring

lemma coordinateCharacter_mul_formula (N : Size) (k x : ZMod N.val) :
    coordinateCharacter N (k * x) =
      Complex.exp (((2 * Real.pi * k.val * x.val / N.val : ℝ) : ℂ) * Complex.I) := by
  have heq : (((k.val : ℤ) * x.val : ℤ) : ZMod N.val) = k * x := by simp
  rw [← heq, coordinateCharacter_int_formula]
  congr 1
  push_cast
  ring

lemma finiteCharacter_eq_exp (N : Size) (k x : Vertex N) :
    finiteCharacter N k x = Complex.exp ((fourierAngle N k x : ℂ) * Complex.I) := by
  rw [finiteCharacter, coordinateCharacter_add, coordinateCharacter_mul_formula,
    coordinateCharacter_mul_formula, ← Complex.exp_add]
  congr 1
  unfold fourierAngle
  push_cast
  ring

@[simp] lemma finiteCharacter_re (N : Size) (k x : Vertex N) :
    (finiteCharacter N k x).re = finiteCosine N k x := by
  rw [finiteCharacter_eq_exp, Complex.exp_ofReal_mul_I_re]
  rfl

@[simp] lemma finiteCharacter_im (N : Size) (k x : Vertex N) :
    (finiteCharacter N k x).im = finiteSine N k x := by
  rw [finiteCharacter_eq_exp, Complex.exp_ofReal_mul_I_im]
  rfl

lemma finiteCharacter_add (N : Size) (k x y : Vertex N) :
    finiteCharacter N k (x + y) = finiteCharacter N k x * finiteCharacter N k y := by
  unfold finiteCharacter
  simp only [Prod.fst_add, Prod.snd_add]
  rw [show k.1 * (x.1 + y.1) + k.2 * (x.2 + y.2) =
    (k.1 * x.1 + k.2 * x.2) + (k.1 * y.1 + k.2 * y.2) by ring,
    coordinateCharacter_add]

lemma coordinateCharacter_add_neg (N : Size) (k : ZMod N.val) :
    coordinateCharacter N k + coordinateCharacter N (-k) =
      ((2 * Real.cos (2 * Real.pi * k.val / N.val) : ℝ) : ℂ) := by
  have hpos := coordinateCharacter_int_formula N (k.val : ℤ)
  have hneg := coordinateCharacter_int_formula N (-(k.val : ℤ))
  simp only [Int.cast_natCast, ZMod.natCast_zmod_val] at hpos
  simp only [Int.cast_neg, Int.cast_natCast, ZMod.natCast_zmod_val] at hneg
  rw [hpos, hneg]
  rw [show 2 * Real.pi * (-(k.val : ℝ)) / N.val =
      -(2 * Real.pi * k.val / N.val) by ring]
  rw [Complex.exp_ofReal_mul_I, Complex.exp_ofReal_mul_I]
  simp only [Real.cos_neg, Real.sin_neg, Complex.ofReal_neg]
  push_cast
  ring

lemma finiteCharacter_direction_sum (N : Size) (k : Vertex N) :
    (∑ d : Fin 4, finiteCharacter N k (direction N d)) =
      ((4 * (1 - finiteEigenvalue N k) : ℝ) : ℂ) := by
  have hsum : (∑ d : Fin 4, finiteCharacter N k (direction N d)) =
      (coordinateCharacter N k.1 + coordinateCharacter N (-k.1)) +
      (coordinateCharacter N k.2 + coordinateCharacter N (-k.2)) := by
    simp [Fin.sum_univ_succ, direction, finiteCharacter, add_assoc]
  rw [hsum, coordinateCharacter_add_neg, coordinateCharacter_add_neg]
  unfold finiteEigenvalue
  push_cast
  ring

lemma finiteCharacter_generator (N : Size) (k x : Vertex N) :
    -(1 / 4 : ℂ) * (∑ d : Fin 4,
      (finiteCharacter N k (x + direction N d) - finiteCharacter N k x)) =
      (finiteEigenvalue N k : ℂ) * finiteCharacter N k x := by
  simp_rw [finiteCharacter_add]
  rw [Finset.sum_sub_distrib, ← Finset.mul_sum]
  simp only [Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul]
  rw [finiteCharacter_direction_sum]
  push_cast
  ring

lemma finiteCosine_generator (N : Size) (k x : Vertex N) :
    -generator N (finiteCosine N k) x = finiteEigenvalue N k * finiteCosine N k x := by
  have h := congrArg Complex.re (finiteCharacter_generator N k x)
  simpa [generator, Complex.mul_re] using h

lemma finiteSine_generator (N : Size) (k x : Vertex N) :
    -generator N (finiteSine N k) x = finiteEigenvalue N k * finiteSine N k x := by
  have h := congrArg Complex.im (finiteCharacter_generator N k x)
  simpa [generator, Complex.mul_im] using h

lemma finite_fourier_spectrum (N : Size) (k : Vertex N) :
    4 * frequencyNormSq N k / vertexCount N ≤ finiteEigenvalue N k ∧
    finiteEigenvalue N k ≤ Real.pi ^ 2 * frequencyNormSq N k / vertexCount N ∧
    ∀ x : Vertex N,
      -generator N (finiteCosine N k) x = finiteEigenvalue N k * finiteCosine N k x ∧
      -generator N (finiteSine N k) x = finiteEigenvalue N k * finiteSine N k x := by
  exact ⟨(eigenvalue_frequency_bounds N k).1, (eigenvalue_frequency_bounds N k).2,
    fun x => ⟨finiteCosine_generator N k x, finiteSine_generator N k x⟩⟩

end TorusCoverTime.Blocks.B
