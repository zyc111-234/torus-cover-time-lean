import Solutions.Blocks.B.StoppedRecordSplicing

/-! Exact-endpoint conditioning changes the stopped segment law and leaves the
fresh tail unchanged. This is proved as a joint measure identity, including
zero-probability endpoint events, rather than assuming conditional independence. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

theorem stoppedRecord_cond_tail_law {τ : WalkSample → ℕ} (hτ : PrefixStoppingRule τ)
    (E : Set (ℕ × WalkSample)) (hE : MeasurableSet E) :
    (walkLaw[|stoppedRecord τ ⁻¹' E]).map
      (fun ω => (stoppedRecord τ ω, stoppedTail τ ω)) =
      ((walkLaw[|stoppedRecord τ ⁻¹' E]).map (stoppedRecord τ)).prod walkLaw := by
  have hX := stoppedRecord_measurable hτ.measurable
  have hY := stoppedTail_measurable hτ.measurable
  apply Measure.ext_prod
  intro S T hS hT
  rw [Measure.map_apply (hX.prodMk hY) (hS.prod hT), Measure.prod_prod,
    Measure.map_apply hX hS]
  simp only [cond_apply (hE.preimage hX)]
  have he : (stoppedRecord τ ⁻¹' E) ∩
      (fun ω => (stoppedRecord τ ω, stoppedTail τ ω)) ⁻¹' (S ×ˢ T) =
      (stoppedRecord τ ⁻¹' (E ∩ S)) ∩ (stoppedTail τ ⁻¹' T) := by
    ext ω
    simp only [mem_inter_iff, mem_preimage, mem_prod]
    tauto
  rw [he, (stoppedRecord_tail_independent hτ).measure_inter_preimage_eq_mul _ _ (hE.inter hS) hT,
    (stoppedTail_measurePreserving hτ).measure_preimage hT.nullMeasurableSet,
    preimage_inter, mul_assoc]

def exitRecordEvent (N : Size) (D : Finset (Vertex N)) (a b : Vertex N) :
    Set (ℕ × WalkSample) := {p | exitsThroughAt N D a b p.2 p.1}

theorem exitRecordEvent_measurable (N : Size) (D : Finset (Vertex N)) (a b : Vertex N) :
    MeasurableSet (exitRecordEvent N D a b) := by
  have he : exitRecordEvent N D a b = ⋃ n : ℕ,
      {p : ℕ × WalkSample | p.1 = n} ∩
        Prod.snd ⁻¹' {ω | exitsThroughAt N D a b ω n} := by
    ext p
    simp only [exitRecordEvent, Set.mem_ofPred_eq, mem_iUnion, mem_inter_iff, mem_preimage]
    constructor
    · intro h
      exact ⟨p.1, rfl, h⟩
    · rintro ⟨n, hn, h⟩
      simpa only [hn] using h
  rw [he]
  exact MeasurableSet.iUnion fun n => (measurable_fst (measurableSet_singleton n)).inter
    ((measurableSet_exitsThroughAt N D a b n).preimage measurable_snd)

theorem exitsThrough_eq_record_preimage (N : Size) (D : Finset (Vertex N)) (a b : Vertex N) :
    exitsThrough N D a b = finiteExitRecord N D a ⁻¹' exitRecordEvent N D a b := by
  ext ω
  change (∃ n, exitsThroughAt N D a b ω n) ↔
    exitsThroughAt N D a b (finiteExitRecord N D a ω).2 (finiteExitIndex N D a ω)
  rw [exitsThroughAt_prefix N D a b _ (finiteExitRecord_agrees N D a ω)]
  constructor
  · rintro ⟨n, hn⟩
    simpa only [finiteExitIndex_of_exit_word N D a b ω n hn] using hn
  · exact fun h => ⟨_, h⟩

def exactExitRecordLaw (N : Size) (D : Finset (Vertex N)) (a b : Vertex N) :
    Measure (ℕ × WalkSample) := (exactExitLaw N D a b).map (finiteExitRecord N D a)

theorem exactExitRecord_tail_law (N : Size) (D : Finset (Vertex N))
    (hD : ∃ b : Vertex N, b ∉ D) (a b : Vertex N) :
    (exactExitLaw N D a b).map (fun ω => (finiteExitRecord N D a ω, finiteExitTail N D a ω)) =
      (exactExitRecordLaw N D a b).prod walkLaw := by
  simp only [exactExitLaw, exactExitRecordLaw, exitsThrough_eq_record_preimage,
    finiteExitRecord, finiteExitTail]
  exact stoppedRecord_cond_tail_law (finiteExitIndex_stoppingRule N D hD a) _
    (exitRecordEvent_measurable N D a b)

theorem exactExitRecordLaw_event_ae (N : Size) (D : Finset (Vertex N)) (a b : Vertex N) :
    ∀ᵐ p ∂exactExitRecordLaw N D a b, p ∈ exitRecordEvent N D a b := by
  apply (ae_map_iff (finiteExitRecord_measurable N D a).aemeasurable
    (exitRecordEvent_measurable N D a b)).mpr
  change ∀ᵐ ω ∂exactExitLaw N D a b,
    ω ∈ finiteExitRecord N D a ⁻¹' exitRecordEvent N D a b
  rw [← exitsThrough_eq_record_preimage]
  exact ae_cond_mem (μ := walkLaw) (measurableSet_exitsThrough N D a b)

theorem recordJoin_exactExit_measurePreserving (N : Size) (D : Finset (Vertex N))
    (hD : ∃ b : Vertex N, b ∉ D) (a b : Vertex N) :
    MeasurePreserving (fun q : (ℕ × WalkSample) × WalkSample => recordJoin q.1 q.2)
      ((exactExitRecordLaw N D a b).prod walkLaw) (exactExitLaw N D a b) := by
  refine ⟨recordJoin_measurable, ?_⟩
  rw [← exactExitRecord_tail_law N D hD a b, Measure.map_map recordJoin_measurable
    ((finiteExitRecord_measurable N D a).prodMk (finiteExitTail_measurable N D a))]
  simp only [Function.comp_def, finiteExitRecord, finiteExitTail, recordJoin_stopped, Measure.map_id']

theorem exactExitTail_law (N : Size) (D : Finset (Vertex N))
    (hD : ∃ b : Vertex N, b ∉ D) (a b : Vertex N)
    [IsProbabilityMeasure (exactExitLaw N D a b)] :
    (exactExitLaw N D a b).map (finiteExitTail N D a) = walkLaw := by
  have h := congrArg (fun μ : Measure ((ℕ × WalkSample) × WalkSample) => μ.map Prod.snd)
    (exactExitRecord_tail_law N D hD a b)
  have : IsProbabilityMeasure (exactExitRecordLaw N D a b) :=
    Measure.isProbabilityMeasure_map (finiteExitRecord_measurable N D a).aemeasurable
  simpa only [Measure.map_map measurable_snd
    ((finiteExitRecord_measurable N D a).prodMk (finiteExitTail_measurable N D a)),
    Measure.map_snd_prod, Function.comp_def, measure_univ, one_smul] using h

theorem exactExitRecord_tail_independent (N : Size) (D : Finset (Vertex N))
    (hD : ∃ b : Vertex N, b ∉ D) (a b : Vertex N)
    [IsProbabilityMeasure (exactExitLaw N D a b)] :
    IndepFun (finiteExitRecord N D a) (finiteExitTail N D a) (exactExitLaw N D a b) := by
  apply (indepFun_iff_map_prod_eq_prod_map_map
    (finiteExitRecord_measurable N D a).aemeasurable
    (finiteExitTail_measurable N D a).aemeasurable).mpr
  rw [exactExitTail_law N D hD a b]
  exact exactExitRecord_tail_law N D hD a b

theorem lintegral_exactExit_record_tail (N : Size) (D : Finset (Vertex N))
    (hD : ∃ b : Vertex N, b ∉ D) (a b : Vertex N)
    (F : (ℕ × WalkSample) × WalkSample → ℝ≥0∞) (hF : Measurable F) :
    (∫⁻ ω, F (finiteExitRecord N D a ω, finiteExitTail N D a ω) ∂exactExitLaw N D a b) =
      ∫⁻ p, ∫⁻ η, F (p, η) ∂walkLaw ∂exactExitRecordLaw N D a b := by
  rw [← lintegral_map hF
    ((finiteExitRecord_measurable N D a).prodMk (finiteExitTail_measurable N D a)),
    exactExitRecord_tail_law N D hD a b]
  exact lintegral_prod _ hF.aemeasurable

end TorusCoverTime.Blocks.B
