import Solutions.Blocks.B.FiniteFourier
import Solutions.Blocks.B.FourierMixing
import Solutions.Blocks.B.FourierOccupation

/-! Derive Fourier walk identities from the transition-probability formula. -/

noncomputable section
open Filter
open scoped BigOperators

namespace TorusCoverTime.Blocks.B

lemma fourier_walk_identities_of_transition
    (hTransition : ∀ N : Size, ∀ t : ℝ, 0 ≤ t → ∀ x y : Vertex N,
      vertexCount N * transitionProbability N x y t = 1 +
        ∑ k ∈ nonzeroFrequencies N, Real.exp (-t * finiteEigenvalue N k) *
          finiteCosine N k (x - y)) : FourierWalkIdentities := by
  refine ⟨finite_fourier_spectrum, hTransition, fourier_occupation_from_transition hTransition, ?_⟩
  filter_upwards [eventual_fourier_mixing_bounds,
    blockB_logSize_tendsto.eventually (eventually_ge_atTop 1)] with N hmix hL
  intro t ht x y
  have hm : 0 ≤ mixingTime N := by
    unfold mixingTime
    exact mul_nonneg (mul_nonneg (by norm_num) (vertexCount_pos N).le) (Real.log_nonneg hL)
  have hbound := hmix t ht x y
  refine ⟨?_, hbound.2⟩
  rw [hTransition N t (hm.trans ht) x y]
  simpa using hbound.1

end TorusCoverTime.Blocks.B
