import Solutions.Blocks.B.PointOccupationKernel
import Solutions.Blocks.B.HoldingRenewal

/-! The bounded Volterra equation for the actual finite-time Laplace kernel. -/
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology BigOperators
namespace TorusCoverTime.Blocks.B

theorem four_direction_average_norm {f : Fin 4 → ℝ} (hf : ∀ d, ‖f d‖ ≤ 1) :
    ‖(∑ d, f d)/4‖ ≤ 1 := by
  rw [norm_div]
  norm_num
  apply (div_le_iff₀ (by norm_num : (0:ℝ)<4)).mpr
  have h := (norm_sum_le Finset.univ f).trans (Finset.sum_le_sum fun d _ => hf d)
  simpa using h

theorem pointOccupationKernel_renewal (N : Size) (c a b : Vertex N) (t : ℝ) (ht : 0 ≤ t) :
    pointOccupationKernel N c t a b =
      Real.exp (-(1+pointSitePotential N c a)*t)*(if a=b then 1 else 0) +
        ∫ s in Icc 0 t, Real.exp (-(1+pointSitePotential N c a)*s)*
          ((∑ d : Fin 4, pointOccupationKernel N c (t-s) (a+direction N d) b)/4) := by
  let v := pointSitePotential N c a
  let δ : ℝ := if a=b then 1 else 0
  let F : (ℝ × Fin 4) × WalkSample → ℝ := fun p =>
    if t < max p.1.1 0 then Real.exp (-v*t)*δ else
      Real.exp (-v*max p.1.1 0)*pointOccupationWeight N c (a+direction N p.1.2) b (t-max p.1.1 0) p.2
  have hw : Measurable (fun p : Fin 4 × (WalkSample × ℝ) =>
      pointOccupationWeight N c (a+direction N p.1) b p.2.2 p.2.1) :=
    measurable_from_prod_countable_right fun d => by
      dsimp only
      exact pointOccupationWeight_joint_measurable N c (a+direction N d) b
  have hF : Measurable F := Measurable.ite (measurableSet_lt measurable_const (by fun_prop)) measurable_const
    ((by fun_prop : Measurable (fun p : (ℝ × Fin 4) × WalkSample => Real.exp (-v*max p.1.1 0))).mul
      (hw.comp (show Measurable (fun p : (ℝ × Fin 4) × WalkSample =>
        (p.1.2,(p.2,t-max p.1.1 0))) by fun_prop)))
  have he (s : ℝ) (hs : 0 ≤ s) : ‖Real.exp (-v*s)‖ ≤ 1 := by
    rw [Real.norm_eq_abs,abs_of_pos (Real.exp_pos _)]
    exact Real.exp_le_one_iff.mpr (mul_nonpos_of_nonpos_of_nonneg
      (neg_nonpos.mpr (pointSitePotential_nonneg N c a)) hs)
  have hδ : ‖δ‖ ≤ 1 := by dsimp only [δ]; split_ifs <;> norm_num
  have hb (p : (ℝ × Fin 4) × WalkSample) : ‖F p‖ ≤ 1 := by
    dsimp only [F]
    split_ifs
    · rw [norm_mul]
      exact (mul_le_mul (he t ht) hδ (norm_nonneg _) zero_le_one).trans_eq (one_mul 1)
    · rw [norm_mul]
      exact (mul_le_mul (he _ (le_max_right _ _)) (pointOccupationWeight_norm_le_one N c _ b _ _)
        (norm_nonneg _) zero_le_one).trans_eq (one_mul 1)
  have hi := Integrable.of_bound (μ := stepLaw.prod walkLaw) hF.aestronglyMeasurable 1 (Eventually.of_forall hb)
  let G : ℝ × Fin 4 → ℝ := fun p => if t < max p.1 0 then Real.exp (-v*t)*δ else
    Real.exp (-v*max p.1 0)*pointOccupationKernel N c (t-max p.1 0) (a+direction N p.2) b
  have hin (p : ℝ × Fin 4) : (∫ ω, F (p,ω) ∂walkLaw) = G p := by
    dsimp only [F,G]
    split_ifs <;> simp [integral_const_mul,pointOccupationKernel]
  have hgi : Integrable G stepLaw := hi.integral_prod_left.congr (Eventually.of_forall hin)
  have hfirst : pointOccupationKernel N c t a b = ∫ p, G p ∂stepLaw := by
    rw [pointOccupationKernel]
    calc
      _ = ∫ ω, F (ω 0,walkTail ω) ∂walkLaw :=
        integral_congr_ae (pointOccupationWeight_first_step N c a b t ht)
      _ = _ := by rw [integral_first_step_tail F hF hi]; simp_rw [hin]
  rw [hfirst,show stepLaw = holdingLaw.prod (uniformOn (Set.univ : Set (Fin 4))) from rfl,
    integral_prod _ hgi]
  have hav (s : ℝ) : (∫ d, G (s,d) ∂uniformOn (Set.univ : Set (Fin 4))) =
      if t < max s 0 then Real.exp (-v*t)*δ else Real.exp (-v*max s 0)*
        ((∑ d : Fin 4, pointOccupationKernel N c (t-max s 0) (a+direction N d) b)/4) := by
    dsimp only [G]
    split_ifs
    · simp
    · rw [integral_const_mul,integral_real_uniform_direction]
  simp_rw [hav]
  apply integral_holding_renewal v δ t (pointSitePotential_nonneg N c a) hδ ht
    (fun s => (∑ d : Fin 4, pointOccupationKernel N c s (a+direction N d) b)/4)
  · exact (Finset.measurable_sum _ fun d _ => pointOccupationKernel_measurable N c _ b).div_const _
  · intro s _
    exact four_direction_average_norm fun d => pointOccupationKernel_norm_le_one N c _ b s

end TorusCoverTime.Blocks.B
