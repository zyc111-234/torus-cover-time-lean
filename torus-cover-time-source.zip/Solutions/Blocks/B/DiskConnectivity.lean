import Solutions.Blocks.B.DiskBarrier
import Mathlib.Data.Int.Lemmas

/-! Concrete nearest-neighbor connectivity of Euclidean torus disks.
Coordinates are reduced toward the center without leaving the disk. -/

noncomputable section
open Classical
namespace TorusCoverTime.Blocks.B

def latticeLength (z : LatticePoint) : ℕ := z.1.natAbs + z.2.natAbs

lemma lattice_shrink (z : LatticePoint) (hz : z ≠ 0) :
    ∃ d : Fin 4, latticeLength (z + latticeDirection d) < latticeLength z ∧
      latticeRadius (z + latticeDirection d) ≤ latticeRadius z := by
  have hshrink (u : ℤ) (hu : 0 < u) : (u-1).natAbs < u.natAbs := by
    apply Int.natAbs_lt_iff_sq_lt.mpr
    nlinarith
  have hgrow (u : ℤ) (hu : u < 0) : (u+1).natAbs < u.natAbs := by
    apply Int.natAbs_lt_iff_sq_lt.mpr
    nlinarith
  have hzero : z.1 ≠ 0 ∨ z.2 ≠ 0 := by
    by_contra hh
    push Not at hh
    exact hz (Prod.ext hh.1 hh.2)
  rcases hzero with hx | hy
  · rcases lt_or_gt_of_ne hx with hx | hx
    · refine ⟨0, ?_, ?_⟩
      · simpa [latticeLength, latticeDirection] using Nat.add_lt_add_right (hgrow z.1 hx) z.2.natAbs
      · apply Real.sqrt_le_sqrt
        simp [latticeDirection, Prod.fst_add, Prod.snd_add]
        have hr : (z.1 : ℝ) ≤ -1 := by exact_mod_cast (show z.1 ≤ -1 by omega)
        nlinarith
    · refine ⟨1, ?_, ?_⟩
      · simpa [latticeLength, latticeDirection, sub_eq_add_neg] using
          Nat.add_lt_add_right (hshrink z.1 hx) z.2.natAbs
      · apply Real.sqrt_le_sqrt
        simp [latticeDirection, Prod.fst_add, Prod.snd_add]
        have hr : (1 : ℝ) ≤ z.1 := by exact_mod_cast (show 1 ≤ z.1 by omega)
        nlinarith
  · rcases lt_or_gt_of_ne hy with hy | hy
    · refine ⟨2, ?_, ?_⟩
      · simpa [latticeLength, latticeDirection] using Nat.add_lt_add_left (hgrow z.2 hy) z.1.natAbs
      · apply Real.sqrt_le_sqrt
        simp [latticeDirection, Prod.fst_add, Prod.snd_add]
        have hr : (z.2 : ℝ) ≤ -1 := by exact_mod_cast (show z.2 ≤ -1 by omega)
        nlinarith
    · refine ⟨3, ?_, ?_⟩
      · simpa [latticeLength, latticeDirection, sub_eq_add_neg] using
          Nat.add_lt_add_left (hshrink z.2 hy) z.1.natAbs
      · apply Real.sqrt_le_sqrt
        simp [latticeDirection, Prod.fst_add, Prod.snd_add]
        have hr : (1 : ℝ) ≤ z.2 := by exact_mod_cast (show 1 ≤ z.2 by omega)
        nlinarith

lemma torus_neighbor_step (N : Size) (x : Vertex N) (d : Fin 4) :
    (torusNeighborGraph N).Adj x (x + direction N d) := by
  refine ⟨?_, d, rfl⟩
  intro heq
  have h := periodicDistance_step N x d
  rw [← heq, periodicDistance_self_zero] at h
  norm_num at h

lemma projection_mem_torusDisk (N : Size) (y : Vertex N) (R : ℝ)
    (hsmall : 2*R < N.val) (z : LatticePoint) (hz : latticeRadius z < R) :
    torusProjection N y z ∈ torusDisk N y R := by
  have hb := latticeRadius_coordinates z
  rw [projection_mem_disk_iff N y R z (by linarith [hb.1]) (by linarith [hb.2])]
  exact hz

lemma torusDisk_projection_reachable_center (N : Size) (y : Vertex N) (R : ℝ)
    (hR : 0 < R) (hsmall : 2*R < N.val) (z : LatticePoint) (hz : latticeRadius z < R) :
    ((torusNeighborGraph N).induce (torusDisk N y R : Set (Vertex N))).Reachable
      ⟨torusProjection N y z, projection_mem_torusDisk N y R hsmall z hz⟩
      ⟨y, (mem_torusDisk N y y R).mpr (by simpa [periodicDistance_self_zero] using hR)⟩ := by
  induction hlen : latticeLength z using Nat.strong_induction_on generalizing z with
  | h n ih =>
    by_cases hzero : z = 0
    · subst z
      have heq : torusProjection N y (0 : LatticePoint) = y := by
        ext <;> simp [torusProjection]
      have heq' : (⟨torusProjection N y (0 : LatticePoint),
          projection_mem_torusDisk N y R hsmall 0 hz⟩ : (torusDisk N y R : Set (Vertex N))) =
          ⟨y, (mem_torusDisk N y y R).mpr (by simpa [periodicDistance_self_zero] using hR)⟩ :=
        Subtype.ext heq
      rw [heq']
    · obtain ⟨d, hd, hr⟩ := lattice_shrink z hzero
      have hz' := hr.trans_lt hz
      have hrec := ih (latticeLength (z + latticeDirection d)) (by omega)
        (z + latticeDirection d) hz' rfl
      have hedge : ((torusNeighborGraph N).induce (torusDisk N y R : Set (Vertex N))).Adj
          ⟨torusProjection N y z, projection_mem_torusDisk N y R hsmall z hz⟩
          ⟨torusProjection N y (z + latticeDirection d),
            projection_mem_torusDisk N y R hsmall _ hz'⟩ := by
        change (torusNeighborGraph N).Adj (torusProjection N y z)
          (torusProjection N y (z + latticeDirection d))
        rw [torusProjection_add_direction]
        exact torus_neighbor_step N _ d
      exact hedge.reachable.trans hrec

theorem torusDisk_preconnected (N : Size) (y : Vertex N) (R : ℝ)
    (hR : 0 < R) (hsmall : 2*R < N.val) :
    ((torusNeighborGraph N).induce (torusDisk N y R : Set (Vertex N))).Preconnected := by
  have hcenter (a : (torusDisk N y R : Set (Vertex N))) :=
    torusDisk_projection_reachable_center N y R hR hsmall (centeredLift N y a.val)
      (by rw [latticeRadius_centeredLift]; exact (mem_torusDisk N y a.val R).mp a.property)
  have hr (a : (torusDisk N y R : Set (Vertex N))) :
      ((torusNeighborGraph N).induce (torusDisk N y R : Set (Vertex N))).Reachable a
        ⟨y, (mem_torusDisk N y y R).mpr (by simpa [periodicDistance_self_zero] using hR)⟩ := by
    convert hcenter a using 1
    exact (Subtype.ext (torusProjection_centeredLift N y a.val)).symm
  intro a b
  exact (hr a).trans (hr b).symm

def diskExteriorNeighbor (N : Size) (y : Vertex N) (R : ℝ) (b : Vertex N) : Prop :=
  b ∉ torusDisk N y R ∧ ∃ c ∈ torusDisk N y R, (torusNeighborGraph N).Adj c b

theorem disk_feasible_exit (N : Size) (y : Vertex N) (R : ℝ)
    (hR : 0 < R) (hsmall : 2*R < N.val) (a b : Vertex N)
    (ha : a ∈ torusDisk N y R) (hb : diskExteriorNeighbor N y R b) :
    FeasibleAvoidingExit N (torusDisk N y R) ∅ a b := by
  apply feasibleAvoidingExit_of_connected_core_complement N (torusDisk N y R) ∅ a b
  · simpa using ha
  · exact Finset.empty_subset _
  · exact hb.1
  · rw [Finset.sdiff_empty]
    exact torusDisk_preconnected N y R hR hsmall
  · simpa using hb.2

theorem disk_exit_probability_pos (N : Size) (y : Vertex N) (R : ℝ)
    (hR : 0 < R) (hsmall : 2*R < N.val) (a b : Vertex N)
    (ha : a ∈ torusDisk N y R) (hb : diskExteriorNeighbor N y R b) :
    0 < walkLaw (exitsThrough N (torusDisk N y R) a b) := by
  have hp := finite_domain_exit_probability_lower N (torusDisk N y R) ∅ a b
    (disk_feasible_exit N y R hR hsmall a b ha hb)
  exact (by simp : 0 < 1/(4 : ENNReal)^((torusDisk N y R).card+1)).trans_le hp

theorem disk_exactExitLaw_probability (N : Size) (y : Vertex N) (R : ℝ)
    (hR : 0 < R) (hsmall : 2*R < N.val) (a b : Vertex N)
    (ha : a ∈ torusDisk N y R) (hb : diskExteriorNeighbor N y R b) :
    MeasureTheory.IsProbabilityMeasure (exactExitLaw N (torusDisk N y R) a b) :=
  exactExitLaw_probability_of_path N (torusDisk N y R) ∅ a b
    (disk_feasible_exit N y R hR hsmall a b ha hb)

end TorusCoverTime.Blocks.B
