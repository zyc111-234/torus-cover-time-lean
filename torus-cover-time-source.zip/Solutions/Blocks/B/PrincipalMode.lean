import Solutions.Blocks.B.KilledEuler

/-! Existence and normalization of the nonnegative killed principal mode. -/

noncomputable section
open scoped BigOperators
namespace TorusCoverTime.Blocks.B

lemma energy_abs_le (N : Size) (f : Vertex N → ℝ) :
    energy N (fun x => |f x|) ≤ energy N f := by
  rw [energy_edges, energy_edges]
  apply mul_le_mul_of_nonneg_left _ (by norm_num)
  apply add_le_add <;> apply Finset.sum_le_sum <;> intro x _
  · exact sq_le_sq.mpr (abs_abs_sub_abs_le_abs_sub _ _)
  · exact sq_le_sq.mpr (abs_abs_sub_abs_le_abs_sub _ _)

lemma squareSum_abs (N : Size) (f : Vertex N → ℝ) :
    squareSum N (fun x => |f x|) = squareSum N f := by
  simp only [squareSum, sq_abs]

lemma spatialMean_pos_of_nonneg (N : Size) (f : Vertex N → ℝ)
    (hf : ∀ x, 0 ≤ f x) (hf0 : f ≠ 0) : 0 < spatialMean N f := by
  apply div_pos _ (vertexCount_pos N)
  refine lt_of_le_of_ne (Finset.sum_nonneg (fun x _ => hf x)) ?_
  intro hz
  apply hf0
  funext x
  have hx := Finset.single_le_sum (s := (Finset.univ : Finset (Vertex N)))
    (f := f) (fun x _ => hf x) (Finset.mem_univ x)
  rw [← hz] at hx
  exact le_antisymm hx (hf x)

lemma killedEigenvalue_pos (N : Size) (A : Finset (Vertex N))
    (hne : A.Nonempty) (hA : A ≠ Finset.univ) : 0 < killedEigenvalue N A := by
  obtain ⟨f, hfA, hf1, hfe, _⟩ := exists_killed_minimizer N A hA
  rw [← hfe]
  refine lt_of_le_of_ne (energy_nonneg N f) ?_
  intro hfzero
  have hconst := energy_zero_constant N f hfzero.symm
  obtain ⟨z, hz⟩ := hne
  have hf0 : f = 0 := by
    funext x
    calc
      f x = f 0 := hconst x
      _ = f z := (hconst z).symm
      _ = 0 := hfA z hz
  have h := (squareSum_eq_zero N f).mpr hf0
  linarith

lemma exists_nonnegative_killed_minimizer (N : Size) (A : Finset (Vertex N))
    (hA : A ≠ Finset.univ) :
    ∃ f : Vertex N → ℝ, vanishesOn N A f ∧ squareSum N f = 1 ∧
      (∀ x, 0 ≤ f x) ∧ energy N f = killedEigenvalue N A := by
  obtain ⟨u, huA, hu1, hue, _⟩ := exists_killed_minimizer N A hA
  have hvA : vanishesOn N A (fun x => |u x|) := by
    intro x hx
    change |u x| = 0
    rw [huA x hx, abs_zero]
  have hv1 : squareSum N (fun x => |u x|) = 1 := by rw [squareSum_abs, hu1]
  refine ⟨fun x => |u x|, hvA, hv1, (fun x => abs_nonneg _), ?_⟩
  apply le_antisymm
  · exact (energy_abs_le N u).trans_eq hue
  · have h := killed_rayleigh N A hA (fun x => |u x|) hvA
    simpa only [hv1, mul_one] using h

lemma exists_principalMode (N : Size) (A : Finset (Vertex N))
    (hA : A ≠ Finset.univ) : ∃ f : Vertex N → ℝ, IsPrincipalMode N A f := by
  obtain ⟨u, huA, hu1, hu0, hue⟩ := exists_nonnegative_killed_minimizer N A hA
  have huNe : u ≠ 0 := by
    intro hu
    have h := (squareSum_eq_zero N u).mpr hu
    linarith
  have hm := spatialMean_pos_of_nonneg N u hu0 huNe
  have heigen := killed_minimizer_eigenfunction N A hA u huA (by rw [hu1, mul_one, hue])
  let c := (spatialMean N u)⁻¹
  refine ⟨c • u, vanishesOn_smul N A c u huA, ?_, ?_, ?_⟩
  · rw [spatialMean_smul]
    exact inv_mul_cancel₀ hm.ne'
  · intro x
    exact mul_nonneg (inv_nonneg.mpr hm.le) (hu0 x)
  · intro x hx
    change -generator N (fun z => c * u z) x = killedEigenvalue N A * (c * u x)
    rw [generator_mul_left, neg_mul_eq_mul_neg, heigen x hx]
    ring

lemma principalMode_valid (N : Size) (A : Finset (Vertex N)) (hA : A ≠ Finset.univ) :
    IsPrincipalMode N A (principalMode N A) :=
  Classical.epsilon_spec (exists_principalMode N A hA)

lemma killed_eigenfunction_pairing (N : Size) (A : Finset (Vertex N))
    (f g : Vertex N → ℝ) (hf : vanishesOn N A f)
    (hg : ∀ x, x ∉ A → -generator N g x = killedEigenvalue N A * g x) :
    dirichletPairing N f g = killedEigenvalue N A * ∑ x : Vertex N, f x * g x := by
  rw [dirichletPairing, Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro x _
  by_cases hx : x ∈ A
  · rw [hf x hx]
    ring
  · rw [hg x hx]
    ring

lemma principalMode_energy (N : Size) (A : Finset (Vertex N)) (hA : A ≠ Finset.univ) :
    energy N (principalMode N A) = killedEigenvalue N A * squareSum N (principalMode N A) := by
  have hf := principalMode_valid N A hA
  simpa only [dirichletPairing, energy, squareSum, ← sq] using
    killed_eigenfunction_pairing N A (principalMode N A) (principalMode N A) hf.1 hf.2.2.2

end TorusCoverTime.Blocks.B
