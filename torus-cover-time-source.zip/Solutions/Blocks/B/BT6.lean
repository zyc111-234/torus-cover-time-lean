import Solutions.Blocks.B.BT6DirichletConclusion
import Solutions.Blocks.B.BT6EventMeasurable
import Solutions.Blocks.B.DirichletWholeFieldConditioning

/-! Single import for completed B-T6. The quantitative bound is
`bt6_dirichlet_conclusion`; the event below uses its genuine conditional law. -/

noncomputable section
open MeasureTheory ProbabilityTheory Classical
namespace TorusCoverTime.Blocks.B

theorem bt6_badField_condExp (N : Size) (root : Vertex N) (E : Finset (Vertex N))
    (hroot : root∉E) (x : Vertex N) (hV : 0<dirichletClockLS N root E x) (γ η δ : ℝ) :
    (finiteFieldLaw N)[fun ξ => if bt6BadField N x γ η δ (dirichletFieldLS N root E ξ) then (1:ℝ) else 0 |
      MeasurableSpace.comap (fun ξ => dirichletFieldLS N root E ξ x) inferInstance] =ᵐ[finiteFieldLaw N]
      fun ξ => (finiteFieldLaw N).real {ζ | bt6BadField N x γ η δ
        (dirichletConditionedField N root E x (dirichletFieldLS N root E ξ x) ζ)} := by
  let F := fun f : Vertex N → ℝ => if bt6BadField N x γ η δ f then (1:ℝ) else 0
  have hm := bt6BadField_measurableSet N x γ η δ
  have hF : Measurable F := measurable_const.piecewise hm measurable_const
  have hh := dirichletConditionedField_condExp_functional N root E hroot x hV F hF 1
    (fun f => by dsimp only [F]; split_ifs <;> norm_num)
  filter_upwards [hh] with ξ hξ
  rw [hξ]
  have hs := hm.preimage (dirichletConditionedField_measurable N root E x (dirichletFieldLS N root E ξ x))
  convert (integral_indicator_one (μ := finiteFieldLaw N) hs) using 1
  · apply integral_congr_ae
    exact Filter.Eventually.of_forall (fun ζ => by simp [F,Set.indicator])
  · rfl

end TorusCoverTime.Blocks.B
