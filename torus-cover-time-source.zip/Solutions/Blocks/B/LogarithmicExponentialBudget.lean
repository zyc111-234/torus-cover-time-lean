import Solutions.Blocks.B.HarmonicShellCenter

/-! Quantitative absorption at the L log L scale. The statement preserves a
strict exponential remainder, rather than only proving convergence to zero. -/

noncomputable section
open Filter
open scoped Topology
namespace TorusCoverTime.Blocks.B

theorem polynomial_logarithmic_exponential_absorption (c K A : ℝ) (hc : 0 < c) (m : ℕ) :
    ∀ᶠ L : ℝ in atTop, K*L^m*Real.exp (A*L-c*L*Real.log L) ≤
      Real.exp (-(c/2)*L*Real.log L) := by
  have ht := (Real.tendsto_pow_mul_exp_neg_atTop_nhds_zero m).const_mul K
  simp only [mul_zero] at ht
  have hl := Real.tendsto_log_atTop
  filter_upwards [eventually_ge_atTop (0:ℝ),ht.eventually_le_const zero_lt_one,
    hl.eventually_ge_atTop (2*(A+1)/c)] with L hL hpoly hlog
  have hlog' : 2*(A+1) ≤ Real.log L*c := (div_le_iff₀ hc).mp hlog
  have hlogL := mul_le_mul_of_nonneg_right hlog' hL
  have he : K*L^m*Real.exp (A*L-c*L*Real.log L) =
      (K*(L^m*Real.exp (-L)))*Real.exp ((A+1)*L-c*L*Real.log L) := by
    calc
      _ = K*L^m*Real.exp (-L+((A+1)*L-c*L*Real.log L)) := by congr 2; ring
      _ = _ := by rw [Real.exp_add]; ring
  rw [he]
  calc
    _ ≤ 1*Real.exp ((A+1)*L-c*L*Real.log L) :=
      mul_le_mul_of_nonneg_right hpoly (Real.exp_pos _).le
    _ ≤ _ := by
      rw [one_mul]
      exact Real.exp_le_exp.mpr (by nlinarith)

theorem r7_shell_remainder_absorption (c K : ℝ) (hc : 0 < c) (hK : 0 ≤ K) :
    ∀ᶠ N : Size in atTop,
      K*Real.sqrt (logSize N)*vertexCount N*logSize N^2*
        Real.exp (-c*logSize N*Real.log (logSize N)) ≤
      Real.exp (-(c/2)*logSize N*Real.log (logSize N)) := by
  filter_upwards [blockB_logSize_tendsto.eventually (polynomial_logarithmic_exponential_absorption c K 2 hc 3),
    blockB_logSize_tendsto.eventually_ge_atTop 1] with N hN hL
  have hs : Real.sqrt (logSize N) ≤ logSize N := by
    apply (Real.sqrt_le_iff).mpr
    exact ⟨(logSize_pos N).le,by nlinarith⟩
  calc
    _ ≤ K*logSize N*vertexCount N*logSize N^2*
        Real.exp (-c*logSize N*Real.log (logSize N)) := by have := (vertexCount_pos N).le; gcongr
    _ = K*logSize N^3*Real.exp (2*logSize N-c*logSize N*Real.log (logSize N)) := by
      rw [D.vertexCount_eq_exp_two_logSize,Real.exp_sub]
      simp only [neg_mul,Real.exp_neg]
      ring
    _ ≤ _ := hN

end TorusCoverTime.Blocks.B
