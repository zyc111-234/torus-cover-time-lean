import Solutions.Blocks.B.AdaptivePrefixScan

/-! Every erased inner outward record forces just one inner phase, derived from the original exit law. -/
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B


theorem erasedTraversalScan_ae (N : Size) (I J Q O : Finset (Vertex N))
    (hIJ : I ⊆ J) (hI : I.Nonempty) (hJQ : J ⊆ Q) (hQO : Q ⊆ O)
    (root c : Vertex N) (hr : root ∉ J) (hc : c ∈ Q) :
    ∀ᵐ ω ∂walkLaw, ∀ j k,
      adaptiveRecordScanAction N Q O (alternatingDomain N I J) root ω (2*j+1) k =
        traversalPhaseStep N Q O k c := by
  filter_upwards [alternatingExitIndex_strictMono_ae N I J hIJ hI root hr,
    adaptiveExit_spec_ae N _ (alternatingDomain_proper N I J hI ⟨root,hr⟩) root] with ω hi hs
  intro j k
  rw [adaptiveRecordScanAction_eq_tail]
  apply traversalPrefixScan_inner N Q O hQO c _ hc
  · have h := hi (Nat.lt_succ_self (2*j+1))
    change adaptiveExitIndex N (alternatingDomain N I J) root (2*j+1) ω <
      adaptiveExitIndex N (alternatingDomain N I J) root (2*j+1+1) ω at h
    rw [adaptiveExitIndex_succ N (alternatingDomain N I J) root (2*j+1) ω] at h
    omega
  · intro v hv
    have hx := (hs (2*j+1)).2.2 ⟨v,hv⟩
    apply hJQ
    simpa only [alternatingDomain_odd] using hx


end TorusCoverTime.Blocks.B
