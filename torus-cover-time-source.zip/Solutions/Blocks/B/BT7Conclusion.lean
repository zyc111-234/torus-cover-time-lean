import Solutions.Blocks.B.BT7ScalarLimit
import Solutions.Blocks.B.BT7Count

/-! B-T7 / B.35--B.36: expected bad-point count for the original periodic
Fourier field, both signs, tends to zero. No unproved probability estimate,
independence assertion, or geometric estimate is a hypothesis of the conclusion. -/
noncomputable section
open MeasureTheory ProbabilityTheory Classical Filter
open scoped Topology
namespace TorusCoverTime.Blocks.B

def bt7ExpectedConstant (ρ : ℝ) : ℝ :=
  8*Real.exp (8*bt6ClockError ρ)*Real.exp (bt7EnvelopeMomentScale ρ*(8+1)^2/2)/bt7FreshSlabMass

theorem bt7_expected_bound (ρ γ ε C₀ C₁ : ℝ) (hρ : 0<ρ) (hρhi : ρ<1/4)
    (hγ : 0<γ) (hγhi : 32*γ<1/10) (hε : 0≤ε) (hC₀ : 0≤C₀) (hC₁ : 0≤C₁) :
    ∃ F : ℝ, 0<F ∧ ∀ᶠ N : Size in atTop,
      (∫ ξ, bt7BadCount N γ ε C₀ C₁ ξ ∂finiteFieldLaw N)≤
        bt7ExpectedConstant ρ*bt7ScalarBound (logSize N) γ ε (2*C₀+dirichletMassProfileBound) (bt7EnvelopeMomentScale ρ) F := by
  obtain ⟨F,hF,hwide⟩ := bt7_wide_dirichlet γ ρ hγ hγhi hρ hρhi
  refine ⟨F,hF,?_⟩
  filter_upwards [hwide,bt7_error_parameters γ ε C₀ C₁ hγ hγhi hε hC₀ hC₁,
    bt7_geometric_parameters ρ γ hρ hρhi hγ] with N hw hp hg
  let L := logSize N
  let P := F*L^(160*γ)/(L*Real.sqrt (L^(1/10:ℝ)))+F*Real.exp (-(Real.log L)^2/4)
  let M := bt7ExpectedConstant ρ*bt7ScalarBound L γ ε (2*C₀+dirichletMassProfileBound) (bt7EnvelopeMomentScale ρ) F
  have hL : 0<L := logSize_pos N
  have hn := vertexCount_pos N
  have hP : 0≤P := by dsimp [P]; positivity
  have hpoint (x : Vertex N) : (finiteFieldLaw N).real {ξ | bt7BadPoint N γ ε C₀ C₁ (periodicFieldLS N ξ) x}≤M/(2*vertexCount N) := by
    have hproper := torusDisk_proper N x (ρ*(N.val:ℝ)) (by positivity [size_real_gt_one N]) hg.2.1
    obtain ⟨root,hroot⟩ : ∃ root : Vertex N, root∉torusDisk N x (ρ*(N.val:ℝ)) := by
      by_contra! hh
      exact hproper (Finset.eq_univ_iff_forall.mpr hh)
    have hc (t : ℝ) (ht : |t-harmonicExtremeCenter N|≤L^(16*γ)) :
        (finiteFieldLaw N).real {ζ | bt6BadField N x γ (L^(16*γ)) (L^(16*γ))
          (dirichletConditionedField N root (torusDisk N x (ρ*(N.val:ℝ))) x t ζ)}≤P := by
      have hh := hw root x x hroot (by rw [periodicDistance_self_zero]; positivity [size_real_gt_one N]) t ht
      have hh' := ENNReal.toReal_mono (ENNReal.ofReal_ne_top) hh
      change _≤(ENNReal.ofReal P).toReal at hh'
      rw [ENNReal.toReal_ofReal hP] at hh'
      exact hh'
    have hb := bt7_finite_point_bound N root x ρ γ ε C₀ C₁ (L^(16*γ)) (L^(12*γ)) P
      hρ hg.1 hg.2.1 hroot hg.2.2.1 hp.1 hp.2.1 (by positivity) hP hp.2.2.1 hp.2.2.2.1 hp.2.2.2.2 hg.2.2.2 hc
    have he : (2*Real.exp (8*bt6ClockError ρ)/vertexCount N*L)*
        (2*(bt7EndpointWidth N ε C₀+1)*Real.exp (8*bt7EndpointWidth N ε C₀+bt7EnvelopeMomentScale ρ*(8+1)^2/2)*
          (P+Real.exp (-(L^(12*γ))^2/(2*bt7EnvelopeMomentScale ρ))))=
        bt7FreshSlabMass*(M/(2*vertexCount N)) := by
      dsimp only [M,P,bt7ExpectedConstant,bt7ScalarBound,bt7EndpointWidth]
      change _= _
      rw [Real.exp_add]
      dsimp only [L]
      have hs : Real.sqrt ((logSize N)^(1/10:ℝ))≠0 := (Real.sqrt_pos.mpr (Real.rpow_pos_of_pos (logSize_pos N) _)).ne'
      field_simp [hn.ne',bt7FreshSlabMass_pos.ne',(logSize_pos N).ne',hs]
      ring
    rw [he] at hb
    exact (mul_le_mul_iff_right₀ bt7FreshSlabMass_pos).mp hb
  have hh := bt7BadCount_expectation_le N γ ε C₀ C₁ (M/(2*vertexCount N)) hpoint
  exact hh.trans_eq (by field_simp [hn.ne']; ring)

/-- The full B-T7 target, with the paper's original events and both signs. -/
theorem bt7_conclusion (γ C₀ C₁ : ℝ) (hγ : 0<γ) (hmargin : 160*γ<1/20)
    (hC₀ : 0≤C₀) (hC₁ : 0≤C₁) : BT7Conclusion γ C₀ C₁ := by
  let ε := (1/20-160*γ)/16
  have hε : 0<ε := by dsimp [ε]; linarith
  have heps : 8*ε+160*γ<1/20 := by dsimp [ε]; linarith
  obtain ⟨F,hF,hbound⟩ := bt7_expected_bound (1/8) γ ε C₀ C₁ (by norm_num) (by norm_num)
    hγ (by linarith) hε.le hC₀ hC₁
  refine ⟨ε,hε,?_⟩
  have hh := ((bt7ScalarBound_tendsto_zero γ ε (2*C₀+dirichletMassProfileBound)
    (bt7EnvelopeMomentScale (1/8)) F hγ (bt7EnvelopeMomentScale_pos _) heps).comp blockB_logSize_tendsto).const_mul
      (bt7ExpectedConstant (1/8))
  simp only [mul_zero] at hh
  exact squeeze_zero' (Filter.Eventually.of_forall (fun N => integral_nonneg (fun ξ =>
    (bt7BadCount_bounds N γ ε C₀ C₁ ξ).1))) hbound hh

theorem bt7_paper_gamma (C₀ C₁ : ℝ) (hC₀ : 0≤C₀) (hC₁ : 0≤C₁) : BT7Conclusion (1/8192) C₀ C₁ :=
  bt7_conclusion _ C₀ C₁ (by norm_num) (by norm_num) hC₀ hC₁

end TorusCoverTime.Blocks.B
