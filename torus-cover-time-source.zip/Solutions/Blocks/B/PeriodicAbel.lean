import Solutions.Blocks.B.ContinuousFourier
import Solutions.Blocks.B.SpatialCharacters
import Solutions.Blocks.B.ComplexCenteredSums

/-! Exact periodic summation by parts, including arbitrary iterated frequency differences.
These are algebraic tools; the annular multiplier bounds remain separate proof obligations. -/

noncomputable section
open Classical
open scoped BigOperators
namespace TorusCoverTime.Blocks.B

def periodicTransform (N : Size) (a : Vertex N → ℂ) (z : Vertex N) : ℂ :=
  ∑ k : Vertex N, a k * finiteCharacter N k z

def frequencyDifference (N : Size) (e : Vertex N) (a : Vertex N → ℂ) : Vertex N → ℂ :=
  fun k => a (k + e) - a k

lemma periodicTransform_add (N : Size) (a b : Vertex N → ℂ) (z : Vertex N) :
    periodicTransform N (a + b) z = periodicTransform N a z + periodicTransform N b z := by
  simp [periodicTransform, add_mul, Finset.sum_add_distrib]

lemma periodicTransform_sub (N : Size) (a b : Vertex N → ℂ) (z : Vertex N) :
    periodicTransform N (a - b) z = periodicTransform N a z - periodicTransform N b z := by
  simp [periodicTransform, sub_mul, Finset.sum_sub_distrib]

lemma periodicTransform_spatial_difference (N : Size) (a : Vertex N → ℂ) (z e : Vertex N) :
    periodicTransform N a (z + e) - periodicTransform N a z =
      periodicTransform N (fun k => a k * (finiteCharacter N k e - 1)) z := by
  simp only [periodicTransform, finiteCharacter_add, ← Finset.sum_sub_distrib]
  apply Finset.sum_congr rfl
  intro k _
  ring

lemma periodicTransform_shift (N : Size) (a : Vertex N → ℂ) (z e : Vertex N) :
    periodicTransform N (fun k => a (k + e)) z =
      finiteCharacter N (-e) z * periodicTransform N a z := by
  have hs : (∑ k : Vertex N, a (k + e) * finiteCharacter N ((k + e) - e) z) =
      ∑ k : Vertex N, a k * finiteCharacter N (k - e) z :=
    Fintype.sum_equiv (Equiv.addRight e) _ _ (fun _ => rfl)
  simp only [add_sub_cancel_right] at hs
  rw [periodicTransform, hs]
  simp only [sub_eq_add_neg, finiteCharacter_symm N _ z, finiteCharacter_add]
  simp only [periodicTransform, Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro k _
  rw [finiteCharacter_symm N k z]
  ring

lemma periodicTransform_frequency_difference (N : Size) (a : Vertex N → ℂ) (z e : Vertex N) :
    periodicTransform N (frequencyDifference N e a) z =
      (finiteCharacter N (-e) z - 1) * periodicTransform N a z := by
  change periodicTransform N ((fun k => a (k + e)) - a) z = _
  rw [periodicTransform_sub, periodicTransform_shift]
  ring

lemma periodicTransform_iterated_frequency_difference (N : Size) (a : Vertex N → ℂ)
    (z e : Vertex N) (p : ℕ) :
    periodicTransform N ((frequencyDifference N e)^[p] a) z =
      (finiteCharacter N (-e) z - 1) ^ p * periodicTransform N a z := by
  induction p with
  | zero => simp
  | succ p ih =>
    rw [Function.iterate_succ_apply', periodicTransform_frequency_difference, ih, pow_succ]
    ring

lemma periodicTransform_norm_le (N : Size) (a : Vertex N → ℂ) (z : Vertex N) :
    ‖periodicTransform N a z‖ ≤ ∑ k : Vertex N, ‖a k‖ := by
  apply (norm_sum_le _ _).trans
  apply Finset.sum_le_sum
  intro k _
  rw [norm_mul, finiteCharacter_norm, mul_one]

lemma periodicTransform_abel_bound (N : Size) (a : Vertex N → ℂ) (z e : Vertex N)
    (p : ℕ) (he : finiteCharacter N (-e) z ≠ 1) :
    ‖periodicTransform N a z‖ ≤
      (∑ k : Vertex N, ‖((frequencyDifference N e)^[p] a) k‖) /
        ‖finiteCharacter N (-e) z - 1‖ ^ p := by
  have hp : 0 < ‖finiteCharacter N (-e) z - 1‖ ^ p :=
    pow_pos (norm_pos_iff.mpr (sub_ne_zero.mpr he)) p
  apply (le_div_iff₀ hp).mpr
  have h := periodicTransform_norm_le N ((frequencyDifference N e)^[p] a) z
  rw [periodicTransform_iterated_frequency_difference, norm_mul, norm_pow] at h
  simpa only [mul_comm] using h

lemma frequencyDifference_mul (N : Size) (e : Vertex N) (a b : Vertex N → ℂ) :
    frequencyDifference N e (a * b) =
      (fun k => a (k + e) * frequencyDifference N e b k + frequencyDifference N e a k * b k) := by
  funext k
  simp only [frequencyDifference, Pi.mul_apply]
  ring

def greenMultiplier (N : Size) (k : Vertex N) : ℂ :=
  if k = 0 then 0 else ((1 / (vertexCount N * finiteEigenvalue N k) : ℝ) : ℂ)

lemma periodicTransform_green_real (N : Size) (z : Vertex N) :
    (periodicTransform N (greenMultiplier N) z).re = greenKernel N z 0 := by
  rw [periodicTransform]
  have hz : greenMultiplier N 0 * finiteCharacter N 0 z = 0 := by simp [greenMultiplier]
  rw [← Finset.sum_erase_add _ _ (Finset.mem_univ (0 : Vertex N)), hz, add_zero]
  have hre (s : Finset (Vertex N)) (f : Vertex N → ℂ) :
      (∑ k ∈ s, f k).re = ∑ k ∈ s, (f k).re := map_sum Complex.reAddGroupHom f s
  rw [hre]
  simp only [greenKernel, sub_zero, Finset.sum_div, nonzeroFrequencies]
  apply Finset.sum_congr rfl
  intro k hk
  have hk0 := (Finset.mem_erase.mp hk).1
  simp only [greenMultiplier, hk0, if_false, Complex.mul_re, Complex.ofReal_re,
    Complex.ofReal_im, zero_mul, sub_zero, finiteCharacter_re]
  ring

lemma green_difference_transform (N : Size) (z e : Vertex N) :
    greenKernel N (z + e) 0 - greenKernel N z 0 =
      (periodicTransform N (fun k => greenMultiplier N k * (finiteCharacter N k e - 1)) z).re := by
  rw [← periodicTransform_spatial_difference, Complex.sub_re, periodicTransform_green_real,
    periodicTransform_green_real]

lemma green_second_difference_transform (N : Size) (z e e' : Vertex N) :
    greenKernel N (z + e + e') 0 - greenKernel N (z + e) 0 -
        greenKernel N (z + e') 0 + greenKernel N z 0 =
      (periodicTransform N (fun k => greenMultiplier N k *
        (finiteCharacter N k e - 1) * (finiteCharacter N k e' - 1)) z).re := by
  rw [← periodicTransform_spatial_difference, Complex.sub_re,
    ← green_difference_transform, ← green_difference_transform]
  rw [show z + e' + e = z + e + e' by abel]
  ring

end TorusCoverTime.Blocks.B
