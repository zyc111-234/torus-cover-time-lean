import Solutions.Blocks.B.R8MarginalTangent

/-! Logarithmic centering and denominator losses are absorbed uniformly
into L^(2 gamma), independently of the count excess. -/
noncomputable section
open Filter
open scoped Topology
namespace TorusCoverTime.Blocks.B

theorem r8_marginal_error_absorption (γ C : ℝ) (hγ : 0 < γ) :
    ∀ᶠ N : Size in atTop,
      2*Real.sqrt 2*((logSize N)^(2*γ)+(C+3/(4*Real.sqrt 2))*Real.log (logSize N))+2*C ≤
        8*(logSize N)^(2*γ) := by
  have hpow := (tendsto_rpow_atTop (by positivity : 0 < 2*γ)).comp blockB_logSize_tendsto
  filter_upwards [blockB_logSize_tendsto.eventually
    (log_eventually_le_power (C+3/(4*Real.sqrt 2)) (2*γ) 1 (by positivity) zero_lt_one),
    hpow.eventually_ge_atTop (2*C)] with N hlog hC
  dsimp only [Function.comp_def] at hC
  have hs : Real.sqrt (2:ℝ) ≤ 3/2 := by nlinarith [Real.sq_sqrt (by norm_num : (0:ℝ) ≤ 2),Real.sqrt_nonneg (2:ℝ)]
  have hh := mul_le_mul_of_nonneg_left hlog (by positivity : 0 ≤ 2*Real.sqrt (2:ℝ))
  have hmul := mul_le_mul_of_nonneg_right hs (Real.rpow_nonneg (logSize_pos N).le (2*γ))
  nlinarith only [hh,hC,hmul,Real.rpow_nonneg (logSize_pos N).le (2*γ)]

theorem r8_marginal_excess_exponent (γ C : ℝ) (hγ : 0 < γ) (hC : 0 ≤ C) :
    ∀ᶠ N : Size in atTop, ∀ q v : ℝ, q < logSize N →
      -(max (harmonicExtremeCenter N-v-(logSize N)^(2*γ)-C*Real.log (logSize N)) 0)^2/(logSize N-q+C) ≤
        -2*(logSize N-q)+2*Real.sqrt 2*(v-Real.sqrt 2*q)+8*(logSize N)^(2*γ) := by
  filter_upwards [r8_marginal_error_absorption γ C hγ] with N hN
  intro q v hq
  have hh := r8_marginal_excess_algebra N q v γ C hq hC
  linarith

end TorusCoverTime.Blocks.B
