import Mathlib.Probability.Moments.Basic
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Analysis.SpecialFunctions.Sqrt
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Ring

/-! S3: a Chernoff bound with a Bernoulli--exponential Laplace envelope.
No original theorem module is imported. -/

open MeasureTheory ProbabilityTheory Filter
open scoped BigOperators Topology

namespace TorusCoverTime.Blocks.B

lemma integrable_exp_neg_mul_of_nonneg
    {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsFiniteMeasure μ]
    {V : Ω → ℝ} (hV : Measurable V) (hV0 : ∀ᵐ ω ∂μ, 0 ≤ V ω)
    {theta : ℝ} (htheta : 0 ≤ theta) :
    Integrable (fun ω => Real.exp (-theta * V ω)) μ := by
  refine (integrable_const (1 : ℝ)).mono_nonneg
    ((hV.const_mul (-theta)).exp.aestronglyMeasurable)
    (ae_of_all _ fun _ => (Real.exp_pos _).le) ?_
  filter_upwards [hV0] with ω hω
  exact Real.exp_le_one_iff.mpr (mul_nonpos_of_nonpos_of_nonneg (neg_nonpos.mpr htheta) hω)

lemma laplace_envelope_le_exp (p lam theta : ℝ) (hden : lam + theta ≠ 0) :
    1 - p + p * lam / (lam + theta) ≤ Real.exp (-(p * theta / (lam + theta))) := by
  calc
    1 - p + p * lam / (lam + theta) = 1 - p * theta / (lam + theta) := by
      field_simp
      ring
    _ ≤ _ := Real.one_sub_le_exp_neg _

lemma bernoulli_exponential_chernoff
    {Ω : Type*} [MeasurableSpace Ω]
    (μ : Measure Ω) [IsProbabilityMeasure μ]
    (m : ℕ) (V : Fin m → Ω → ℝ)
    (h_measurable : ∀ i, Measurable (V i))
    (h_nonnegative : ∀ i, ∀ᵐ ω ∂μ, 0 ≤ V i ω)
    (h_independent : iIndepFun V μ)
    (p lam U theta : ℝ) (hlam : 0 < lam) (htheta : 0 ≤ theta)
    (h_laplace : ∀ i, (∫ ω, Real.exp (-theta * V i ω) ∂μ) ≤
      1 - p + p * lam / (lam + theta)) :
    μ.real {ω | (∑ i, V i ω) ≤ U} ≤
      Real.exp (theta * U - (m : ℝ) * p * theta / (lam + theta)) := by
  have hint (i : Fin m) :=
    integrable_exp_neg_mul_of_nonneg (h_measurable i) (h_nonnegative i) htheta
  have hsumint := h_independent.integrable_exp_mul_sum h_measurable
    (s := Finset.univ) (fun i _ => hint i)
  have hchernoff := measure_le_le_exp_mul_mgf U (neg_nonpos.mpr htheta) hsumint
  simp only [Finset.sum_apply, neg_neg] at hchernoff
  apply hchernoff.trans
  have hfactor (i : Fin m) : mgf (V i) μ (-theta) ≤
      Real.exp (-(p * theta / (lam + theta))) :=
    (h_laplace i).trans (laplace_envelope_le_exp p lam theta (by linarith))
  have hprod : mgf (∑ i, V i) μ (-theta) ≤
      Real.exp (-(p * theta / (lam + theta))) ^ m := by
    rw [h_independent.mgf_sum h_measurable]
    simpa using Finset.prod_le_prod (s := Finset.univ)
      (fun i _ => mgf_nonneg (X := V i) (μ := μ) (t := -theta))
      (fun i _ => hfactor i)
  calc
    Real.exp (theta * U) * mgf (∑ i, V i) μ (-theta)
        ≤ Real.exp (theta * U) * Real.exp (-(p * theta / (lam + theta))) ^ m := by
      exact mul_le_mul_of_nonneg_left hprod
        (Real.exp_pos _).le
    _ = Real.exp (theta * U - (m : ℝ) * p * theta / (lam + theta)) := by
      rw [← Real.exp_nat_mul, ← Real.exp_add]
      congr 1
      ring

lemma chernoff_optimize_sqrt_gap (q a lam U : ℝ)
    (ha : 0 ≤ a) (hlam : 0 < lam) (hU : 0 ≤ U) (hq : q ≤ 1)
    (hbound : ∀ theta : ℝ, 0 ≤ theta →
      q ≤ Real.exp (theta * U - a * theta / (lam + theta))) :
    q ≤ Real.exp (-((max (Real.sqrt a - Real.sqrt (lam * U)) 0) ^ 2)) := by
  by_cases hab : a ≤ lam * U
  · have hsqrt : Real.sqrt a ≤ Real.sqrt (lam * U) := Real.sqrt_le_sqrt hab
    simpa [max_eq_right (sub_nonpos.mpr hsqrt)] using hq
  have hab' : lam * U < a := lt_of_not_ge hab
  by_cases hU0 : U = 0
  · subst U
    have hlim : Tendsto (fun n : ℕ =>
        Real.exp (-(a * ((n : ℝ) / ((n : ℝ) + lam))))) atTop (𝓝 (Real.exp (-a))) := by
      exact Real.continuous_exp.continuousAt.tendsto.comp
        (by simpa using ((tendsto_natCast_div_add_atTop lam).const_mul a).neg)
    have hle := ge_of_tendsto hlim (Filter.Eventually.of_forall (fun n : ℕ => by
      have hn := hbound (n : ℝ) (Nat.cast_nonneg n)
      simpa only [mul_zero, zero_sub, add_comm (n : ℝ) lam, mul_div_assoc] using hn))
    simpa [max_eq_left (Real.sqrt_nonneg a), Real.sq_sqrt ha] using hle
  have hUpos : 0 < U := lt_of_le_of_ne hU (Ne.symm hU0)
  let x := Real.sqrt a
  let y := Real.sqrt (lam * U)
  have hypos : 0 < y := Real.sqrt_pos.mpr (mul_pos hlam hUpos)
  have hxy : y < x := Real.sqrt_lt_sqrt (mul_nonneg hlam.le hU) hab'
  have hxpos : 0 < x := lt_trans hypos hxy
  have hx_sq : x ^ 2 = a := Real.sq_sqrt ha
  have hy_sq : y ^ 2 = lam * U := Real.sq_sqrt (mul_nonneg hlam.le hU)
  let theta := lam * (x - y) / y
  have htheta : 0 ≤ theta := div_nonneg (mul_nonneg hlam.le (sub_nonneg.mpr hxy.le)) hypos.le
  have hden : lam + theta = lam * x / y := by
    dsimp [theta]
    field_simp
    ring
  have hfirst : theta * U = y * (x - y) := by
    calc
      theta * U = (lam * U) * (x - y) / y := by dsimp [theta]; ring
      _ = y * (x - y) := by
        rw [← hy_sq]
        field_simp
  have hsecond : a * theta / (lam + theta) = x * (x - y) := by
    rw [hden, ← hx_sq]
    dsimp [theta]
    field_simp
  have heq : theta * U - a * theta / (lam + theta) = -(x - y) ^ 2 := by
    rw [hfirst, hsecond]
    ring
  have hfinal := hbound theta htheta
  rw [heq] at hfinal
  simpa [x, y, max_eq_left (sub_nonneg.mpr hxy.le)] using hfinal

theorem bernoulli_exponential_domination
    {Ω : Type*} [MeasurableSpace Ω]
    (μ : Measure Ω) [IsProbabilityMeasure μ]
    (m : ℕ) (V : Fin m → Ω → ℝ)
    (h_measurable : ∀ i, Measurable (V i))
    (h_nonnegative : ∀ i, ∀ᵐ ω ∂μ, 0 ≤ V i ω)
    (h_independent : iIndepFun V μ)
    (p lam U : ℝ) (hp : 0 ≤ p) (_hp_one : p ≤ 1)
    (hlam : 0 < lam) (hU : 0 ≤ U)
    (h_laplace : ∀ (i : Fin m) (theta : ℝ), 0 ≤ theta →
      (∫ ω, Real.exp (-theta * V i ω) ∂μ) ≤
        1 - p + p * lam / (lam + theta)) :
    μ {ω | (∑ i : Fin m, V i ω) ≤ U} ≤
      ENNReal.ofReal (Real.exp
        (-((max (Real.sqrt ((m : ℝ) * p) - Real.sqrt (lam * U)) 0) ^ 2))) := by
  apply (ENNReal.le_ofReal_iff_toReal_le (measure_ne_top _ _) (Real.exp_pos _).le).mpr
  exact chernoff_optimize_sqrt_gap _ ((m : ℝ) * p) lam U
    (mul_nonneg (Nat.cast_nonneg m) hp) hlam hU measureReal_le_one
    (fun theta htheta => bernoulli_exponential_chernoff μ m V h_measurable
      h_nonnegative h_independent p lam U theta hlam htheta (fun i => h_laplace i theta htheta))

end TorusCoverTime.Blocks.B
