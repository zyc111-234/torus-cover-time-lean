import Solutions.Blocks.B.AnnulusWidthStability
import Solutions.Blocks.B.R7MeanCenter

/-! The actual smaller-inner/larger-outer radii used by the grid argument.
The original averaging circle remains exp(q+1). -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

def r7PerturbedInner (q h : ℝ) : ℝ := Real.exp (q+h)-2*Real.exp q
def r7PerturbedOuter (q h : ℝ) : ℝ := Real.exp (q+2*h)+2*Real.exp q
def r7PerturbedWidth (q h : ℝ) : ℝ := Real.log (r7PerturbedOuter q h)-Real.log (r7PerturbedInner q h)
def r7PerturbedBase (q h : ℝ) : ℝ := 2*Real.log (r7PerturbedInner q h)-Real.log (r7PerturbedOuter q h)
def r7PerturbedAverageWidth (q h : ℝ) : ℝ := (Real.log (r7PerturbedOuter q h)-q)/2

theorem r7PerturbedOuter_pos (q h : ℝ) : 0 < r7PerturbedOuter q h := by
  unfold r7PerturbedOuter
  positivity

theorem r7_perturbed_inner_log (q h : ℝ) (hh : Real.log 4 ≤ h) :
    0 < r7PerturbedInner q h ∧
      q+h-4*Real.exp (-h) ≤ Real.log (r7PerturbedInner q h) ∧
      Real.log (r7PerturbedInner q h) ≤ q+h := by
  have h4 : (4:ℝ) ≤ Real.exp h := by
    simpa only [Real.exp_log (by norm_num : (0:ℝ) < 4)] using Real.exp_le_exp.mpr hh
  have hhalf : Real.exp (q+h)/2 ≤ r7PerturbedInner q h := by
    have he := Real.exp_add q h
    have hm := mul_le_mul_of_nonneg_left h4 (Real.exp_pos q).le
    dsimp only [r7PerturbedInner]
    nlinarith
  have hi : 0 < r7PerturbedInner q h := (half_pos (Real.exp_pos _)).trans_le hhalf
  have ht := log_radius_relative_tolerance (r7PerturbedInner q h) (Real.exp (q+h))
    (2*Real.exp q) (Real.exp_pos _) hhalf (by
      dsimp only [r7PerturbedInner]
      rw [sub_sub_cancel_left,abs_neg,abs_of_pos (by positivity : 0 < 2*Real.exp q)])
  have he : 2*(2*Real.exp q)/Real.exp (q+h) = 4*Real.exp (-h) := by
    rw [Real.exp_add q h,Real.exp_neg]
    field_simp <;> norm_num
  rw [Real.log_exp,he] at ht
  have hlo := (abs_le.mp ht).1
  have hhi := Real.log_le_log hi (show r7PerturbedInner q h ≤ Real.exp (q+h) by
    dsimp only [r7PerturbedInner]; linarith [Real.exp_pos q])
  rw [Real.log_exp] at hhi
  exact ⟨hi,by linarith,hhi⟩

theorem r7_perturbed_outer_log (q h : ℝ) (hh : 0 ≤ h) :
    q+2*h ≤ Real.log (r7PerturbedOuter q h) ∧
      Real.log (r7PerturbedOuter q h) ≤ q+2*h+4*Real.exp (-h) := by
  have hR : Real.exp (q+2*h) ≤ r7PerturbedOuter q h := by
    dsimp only [r7PerturbedOuter]
    linarith [Real.exp_pos q]
  have ht := log_radius_relative_tolerance (r7PerturbedOuter q h) (Real.exp (q+2*h))
    (2*Real.exp q) (Real.exp_pos _) (by linarith [Real.exp_pos (q+2*h)]) (by
      dsimp only [r7PerturbedOuter]
      simp only [add_sub_cancel_left,abs_of_pos (by positivity : 0 < 2*Real.exp q),le_refl])
  have hdiv : 2*(2*Real.exp q)/Real.exp (q+2*h) ≤ 4*Real.exp (-h) := by
    have he : 2*(2*Real.exp q)/Real.exp (q+2*h) = 4*Real.exp (-(2*h)) := by
      rw [Real.exp_add q (2*h),Real.exp_neg]
      field_simp <;> norm_num
    rw [he]
    exact mul_le_mul_of_nonneg_left (Real.exp_le_exp.mpr (by linarith)) (by norm_num)
  rw [Real.log_exp] at ht
  have hlo := Real.log_le_log (Real.exp_pos (q+2*h)) hR
  rw [Real.log_exp] at hlo
  exact ⟨hlo,by linarith [(abs_le.mp ht).2]⟩

theorem r7_perturbed_parameter_bounds (q h : ℝ) (hh : Real.log 4 ≤ h) :
    q-12*Real.exp (-h) ≤ r7PerturbedBase q h ∧ r7PerturbedBase q h ≤ q ∧
    h ≤ r7PerturbedWidth q h ∧ r7PerturbedWidth q h ≤ h+8*Real.exp (-h) ∧
    h ≤ r7PerturbedAverageWidth q h ∧ r7PerturbedAverageWidth q h ≤ h+2*Real.exp (-h) := by
  obtain ⟨hi,hilo,hihi⟩ := r7_perturbed_inner_log q h hh
  obtain ⟨holo,hohi⟩ := r7_perturbed_outer_log q h
    ((Real.log_nonneg (by norm_num : (1:ℝ) ≤ 4)).trans hh)
  dsimp only [r7PerturbedBase,r7PerturbedWidth,r7PerturbedAverageWidth]
  exact ⟨by linarith,by linarith,by linarith,by linarith,by linarith,by linarith⟩

theorem r7_perturbed_exp_parameters (q h : ℝ) (hh : Real.log 4 ≤ h) :
    Real.exp (r7PerturbedBase q h+r7PerturbedWidth q h) = r7PerturbedInner q h ∧
    Real.exp (r7PerturbedBase q h+2*r7PerturbedWidth q h) = r7PerturbedOuter q h ∧
    Real.exp (q+2*r7PerturbedAverageWidth q h) = r7PerturbedOuter q h := by
  have hi := (r7_perturbed_inner_log q h hh).1
  have ho := r7PerturbedOuter_pos q h
  dsimp only [r7PerturbedBase,r7PerturbedWidth,r7PerturbedAverageWidth]
  constructor
  · convert Real.exp_log hi using 1 <;> congr 1 <;> ring
  constructor
  · convert Real.exp_log ho using 1 <;> congr 1 <;> ring
  · convert Real.exp_log ho using 1 <;> congr 1 <;> ring

theorem r7_perturbed_scale_conditions (γ : ℝ) (hγ : 0 < γ) (hγ1 : γ < 1) :
    ∀ᶠ q : ℝ in atTop, 128 ≤ q ∧ 1 ≤ q^γ ∧ 1+Real.log 16 ≤ q^γ ∧
      Real.exp (-q^γ) ≤ 1/16 ∧ 4*q^γ ≤ q := by
  filter_upwards [eventually_ge_atTop (128:ℝ),
    (tendsto_rpow_atTop hγ).eventually_ge_atTop (1+Real.log 16),
    power_eventually_le_power 4 γ 1 1 hγ1 (by norm_num)] with q hq hh hpower
  have hlog : 0 ≤ Real.log 16 := Real.log_nonneg (by norm_num)
  have hexp := Real.exp_le_exp.mpr (show -q^γ ≤ -Real.log 16 by linarith)
  rw [Real.exp_neg (Real.log 16),Real.exp_log (by norm_num : (0:ℝ) < 16)] at hexp
  exact ⟨hq,by linarith,hh,by norm_num at hexp ⊢; exact hexp,
    by simpa only [Real.rpow_one,one_mul] using hpower⟩

theorem r7_perturbed_parameter_geometry (γ : ℝ) (hγ : 0 < γ) (hγ1 : γ < 1) :
    ∀ᶠ q : ℝ in atTop, Real.log 4 ≤ q^γ ∧
      64 ≤ r7PerturbedBase q (q^γ) ∧ Real.log 8 ≤ r7PerturbedWidth q (q^γ) ∧
      r7PerturbedWidth q (q^γ) ≤ r7PerturbedBase q (q^γ) ∧
      1 ≤ r7PerturbedAverageWidth q (q^γ) ∧ r7PerturbedAverageWidth q (q^γ) ≤ 2*q^γ ∧
      q^γ ≤ r7PerturbedWidth q (q^γ) ∧ r7PerturbedWidth q (q^γ) ≤ 2*q^γ := by
  filter_upwards [r7_perturbed_scale_conditions γ hγ hγ1] with q hs
  have hl4 : Real.log 4 ≤ q^γ := by
    have := Real.log_le_log (by norm_num : (0:ℝ) < 4) (by norm_num : (4:ℝ) ≤ 16)
    linarith [hs.2.2.1]
  have hl8 : Real.log 8 ≤ q^γ := by
    have := Real.log_le_log (by norm_num : (0:ℝ) < 8) (by norm_num : (8:ℝ) ≤ 16)
    linarith [hs.2.2.1]
  obtain ⟨hb,hbq,hw,hwh,hav,havh⟩ := r7_perturbed_parameter_bounds q (q^γ) hl4
  obtain ⟨hq,hh,hl,he,hqh⟩ := hs
  exact ⟨hl4,by linarith,by linarith,by linarith,by linarith,by linarith,hw,by linarith⟩

end TorusCoverTime.Blocks.B
