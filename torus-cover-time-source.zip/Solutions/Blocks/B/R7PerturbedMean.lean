import Solutions.Blocks.B.R7PerturbedGeometry

/-! Exponentially accurate occupation mean for the shifted annulus, while
retaining the original harmonic averaging circle. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

theorem r7_perturbed_green_center (γ : ℝ) (hγ : 0 < γ) (hγ1 : γ < 1) :
    ∀ᶠ q : ℝ in atTop, ∀ N : Size, ∀ c a b : Vertex N,
      2*(r7PerturbedOuter q (q^γ)+1) < N.val →
      |periodicDistance a c-r7PerturbedInner q (q^γ)| ≤ 2 →
      diskExteriorNeighbor N c (r7PerturbedOuter q (q^γ)) b →
      |diskGreen N c (r7PerturbedOuter q (q^γ)) a c/g-r7PerturbedWidth q (q^γ)| ≤
        r7GreenCenterConstant*Real.exp (-q^γ/4) := by
  filter_upwards [r7_perturbed_parameter_geometry γ hγ hγ1] with q hs
  intro N c a b hsmall ha hb
  obtain ⟨hinner,houter,havg⟩ := r7_perturbed_exp_parameters q (q^γ) hs.1
  have ht := r7_green_center_explicit N c a b (r7PerturbedBase q (q^γ)) (r7PerturbedWidth q (q^γ))
    hs.2.1 hs.2.2.1 hs.2.2.2.1 (by rwa [houter]) (by rwa [hinner]) (by rwa [houter])
  rw [houter] at ht
  exact ht.trans (mul_le_mul_of_nonneg_left (Real.exp_le_exp.mpr (by linarith [hs.2.2.2.2.2.2.1]))
    r7GreenCenterConstant_pos.le)

def r7PerturbedMeanConstant : ℝ :=
  diskExitOscillationConstant*(2+r7GreenCenterConstant)+r7GreenCenterConstant

theorem r7PerturbedMeanConstant_pos : 0 < r7PerturbedMeanConstant := by
  unfold r7PerturbedMeanConstant
  have := diskExitOscillationConstant_pos
  have := r7GreenCenterConstant_pos
  positivity

theorem r7_perturbed_mean_center (hWalk : WalkModelRegular) (γ : ℝ)
    (hγ : 0 < γ) (hγ1 : γ < 1) :
    ∀ᶠ q : ℝ in atTop, ∀ N : Size, ∀ c a b : Vertex N,
      2*(r7PerturbedOuter q (q^γ)+1) < N.val →
      |periodicDistance a c-r7PerturbedInner q (q^γ)| ≤ 2 →
      diskExteriorNeighbor N c (r7PerturbedOuter q (q^γ)) b →
      |(∫ ω, harmonicExitOccupation N c (Real.exp (q+1)) (r7PerturbedOuter q (q^γ)) a ω
        ∂exactExitLaw N (torusDisk N c (r7PerturbedOuter q (q^γ))) a b)-r7PerturbedWidth q (q^γ)| ≤
        r7PerturbedMeanConstant*q^γ*Real.exp (-r7MeanExponent*q^γ) := by
  filter_upwards [r7_perturbed_green_center γ hγ hγ1, r7_perturbed_exit_ratio γ hγ,
    r7_perturbed_entrance_support γ hγ hγ1, r7_perturbed_parameter_geometry γ hγ hγ1,
    (tendsto_rpow_atTop hγ).eventually_ge_atTop (1:ℝ)] with q hgreen hratio hsupport hparam hh
  intro N c a b hsmall ha hb
  let K := diskGreen N c (r7PerturbedOuter q (q^γ)) a c/g
  let e := Real.exp (-r7MeanExponent*q^γ)
  have hK0 : 0 ≤ K := div_nonneg (diskGreen_nonneg N c _ (r7PerturbedOuter_pos q (q^γ)).le hsmall a c)
    (by unfold g; positivity)
  have hC := r7GreenCenterConstant_pos
  have hD := diskExitOscillationConstant_pos
  have hcond := harmonicExitOccupation_mean_error hWalk N c _ _ (Real.exp_pos _).le
    (hsupport N c).2.2 hsmall a b ((hsupport N c).1 a ha).1
    (diskExitOscillationConstant*Real.exp (-diskExitOscillationExponent*q^γ)) (by positivity)
    (fun z hz => hratio N c b z a hsmall hb ((hsupport N c).2.1 z hz) ((hsupport N c).1 a ha).2.1)
  have hg := hgreen N c a b hsmall ha hb
  have he1 : Real.exp (-diskExitOscillationExponent*q^γ) ≤ e := by
    apply Real.exp_le_exp.mpr
    have ht := mul_le_mul_of_nonneg_right (min_le_left diskExitOscillationExponent (1/4)) (by linarith : 0 ≤ q^γ)
    dsimp only [e,r7MeanExponent]
    linarith
  have he2 : Real.exp (-q^γ/4) ≤ e := by
    apply Real.exp_le_exp.mpr
    have ht := mul_le_mul_of_nonneg_right (min_le_right diskExitOscillationExponent (1/4)) (by linarith : 0 ≤ q^γ)
    dsimp only [e,r7MeanExponent]
    linarith
  have hKhi : K ≤ (2+r7GreenCenterConstant)*q^γ := by
    have ht := (abs_le.mp hg).2
    have he0 : Real.exp (-q^γ/4) ≤ 1 := Real.exp_le_one_iff.mpr (by linarith)
    have hw := (hparam).2.2.2.2.2.2.2
    have hc := mul_le_mul_of_nonneg_left he0 hC.le
    change K-r7PerturbedWidth q (q^γ) ≤ _ at ht
    nlinarith [mul_nonneg hC.le (show 0 ≤ q^γ-1 by linarith)]
  calc
    _ ≤ |(∫ ω, harmonicExitOccupation N c (Real.exp (q+1)) (r7PerturbedOuter q (q^γ)) a ω
        ∂exactExitLaw N (torusDisk N c (r7PerturbedOuter q (q^γ))) a b)-K|+
        |K-r7PerturbedWidth q (q^γ)| := abs_sub_le _ _ _
    _ ≤ (diskExitOscillationConstant*Real.exp (-diskExitOscillationExponent*q^γ))*K+
        r7GreenCenterConstant*Real.exp (-q^γ/4) := add_le_add hcond hg
    _ ≤ (diskExitOscillationConstant*e)*((2+r7GreenCenterConstant)*q^γ)+r7GreenCenterConstant*e*q^γ := by
      apply add_le_add
      · exact mul_le_mul (mul_le_mul_of_nonneg_left he1 hD.le) hKhi hK0 (by positivity)
      · exact (mul_le_mul_of_nonneg_left he2 hC.le).trans (le_mul_of_one_le_right (by positivity) hh)
    _ = _ := by dsimp only [r7PerturbedMeanConstant,e]; ring

end TorusCoverTime.Blocks.B
