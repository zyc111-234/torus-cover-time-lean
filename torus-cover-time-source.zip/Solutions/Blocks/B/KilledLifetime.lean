import Solutions.Blocks.B.DiskPhysicalExit

/-! Finite partial sums of actual killed survival are bounded by a proved
supersolution. Applied to disks, the total expected step-count tail is O(R^2). -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Classical
open scoped ENNReal Topology BigOperators
namespace TorusCoverTime.Blocks.B

lemma killedStep_monotone (N : Size) (A : Finset (Vertex N)) : Monotone (killedStep N A) := by
  intro f g hfg x
  by_cases hx : x ∈ A
  · simp [killedStep, hx]
  · simp only [killedStep, hx, if_false]
    exact div_le_div_of_nonneg_right (Finset.sum_le_sum (fun d _ => hfg _)) (by norm_num)

lemma killedStep_finset_sum (N : Size) (A : Finset (Vertex N))
    {ι : Type*} (s : Finset ι) (f : ι → Vertex N → ℝ) (x : Vertex N) :
    killedStep N A (fun y => ∑ i ∈ s, f i y) x = ∑ i ∈ s, killedStep N A (f i) x := by
  by_cases hx : x ∈ A
  · simp [killedStep, hx]
  · simp only [killedStep, hx, if_false, ← Finset.sum_div]
    rw [Finset.sum_comm]

lemma discreteSurvival_measure (N : Size) (A : Finset (Vertex N)) (x : Vertex N) (n : ℕ) :
    discreteSurvival N x A n = walkLaw.real {ω | discreteAvoids N x A ω n} := by
  exact integral_indicator_one (measurableSet_discreteAvoids N x A n)

lemma discreteSurvival_nonneg (N : Size) (A : Finset (Vertex N)) (x : Vertex N) (n : ℕ) :
    0 ≤ discreteSurvival N x A n := by
  rw [discreteSurvival_measure]
  exact ENNReal.toReal_nonneg

lemma discreteSurvival_antitone (N : Size) (A : Finset (Vertex N)) (x : Vertex N) :
    Antitone (discreteSurvival N x A) := by
  intro m n hmn
  simp only [discreteSurvival_measure, measureReal_def]
  apply ENNReal.toReal_mono (measure_ne_top walkLaw _)
  apply measure_mono
  intro ω hω k hk
  exact hω k (hk.trans hmn)

lemma discreteSurvival_sum_le_barrier (N : Size) (A : Finset (Vertex N))
    (b : Vertex N → ℝ) (hb : ∀ x, 0 ≤ b x)
    (hbar : ∀ x, complementIndicator N A x + killedStep N A b x ≤ b x) (n : ℕ) :
    ∀ x, ∑ j ∈ Finset.range n, discreteSurvival N x A j ≤ b x := by
  induction n with
  | zero => intro x; simpa using hb x
  | succ n ih =>
    intro x
    rw [Finset.sum_range_succ']
    simp only [discreteSurvival_zero, discreteSurvival_succ, ← killedStep_finset_sum]
    have hk := killedStep_monotone N A (show
      (fun y => ∑ j ∈ Finset.range n, discreteSurvival N y A j) ≤ b from ih) x
    linarith [hbar x]

lemma discreteSurvival_tsum_le_barrier (N : Size) (A : Finset (Vertex N))
    (b : Vertex N → ℝ) (hb : ∀ x, 0 ≤ b x)
    (hbar : ∀ x, complementIndicator N A x + killedStep N A b x ≤ b x) (x : Vertex N) :
    Summable (discreteSurvival N x A) ∧ (∑' n, discreteSurvival N x A n) ≤ b x := by
  have hsum := fun n => discreteSurvival_sum_le_barrier N A b hb hbar n x
  exact ⟨summable_of_sum_range_le (discreteSurvival_nonneg N A x) hsum,
    Real.tsum_le_of_sum_range_le (discreteSurvival_nonneg N A x) hsum⟩

def diskKilledBarrier (N : Size) (y : Vertex N) (R : ℝ) (x : Vertex N) : ℝ :=
  if x ∈ torusDisk N y R then diskBarrier N y R x else 0

lemma diskKilledBarrier_nonneg (N : Size) (y : Vertex N) (R : ℝ) (x : Vertex N) :
    0 ≤ diskKilledBarrier N y R x := by
  unfold diskKilledBarrier
  split_ifs
  · exact diskBarrier_nonneg N y R x
  · rfl

lemma diskKilledBarrier_le (N : Size) (y : Vertex N) (R : ℝ) (x : Vertex N) :
    diskKilledBarrier N y R x ≤ diskBarrier N y R x := by
  unfold diskKilledBarrier
  split_ifs
  · rfl
  · exact diskBarrier_nonneg N y R x

lemma diskKilledBarrier_supersolution (N : Size) (y : Vertex N) (R : ℝ) (hR : 0 ≤ R)
    (hsmall : 2*(R+1) < N.val) (x : Vertex N) :
    complementIndicator N (Finset.univ \ torusDisk N y R) x +
      killedStep N (Finset.univ \ torusDisk N y R) (diskKilledBarrier N y R) x ≤
        diskKilledBarrier N y R x := by
  by_cases hx : x ∈ torusDisk N y R
  · have hnot : x ∉ Finset.univ \ torusDisk N y R := by simpa using hx
    have hk := killedStep_monotone N (Finset.univ \ torusDisk N y R)
      (diskKilledBarrier_le N y R) x
    rw [killedStep_off_target N _ (diskBarrier N y R) x hnot] at hk
    have hg := diskBarrier_generator N y R hR hsmall x hx
    simp only [complementIndicator, hnot, if_false, diskKilledBarrier, hx, if_true]
    change 1 + killedStep N (Finset.univ \ torusDisk N y R) (diskKilledBarrier N y R) x ≤ _
    linarith
  · have hin : x ∈ Finset.univ \ torusDisk N y R := by simpa using hx
    simp [complementIndicator, killedStep, diskKilledBarrier, hx, hin]

theorem disk_discrete_survival_sum (N : Size) (y : Vertex N) (R : ℝ) (hR : 0 ≤ R)
    (hsmall : 2*(R+1) < N.val) (a : Vertex N) :
    Summable (discreteSurvival N a (Finset.univ \ torusDisk N y R)) ∧
      (∑' n, discreteSurvival N a (Finset.univ \ torusDisk N y R) n) ≤ (R+1)^2 := by
  have h := discreteSurvival_tsum_le_barrier N _ (diskKilledBarrier N y R)
    (diskKilledBarrier_nonneg N y R) (diskKilledBarrier_supersolution N y R hR hsmall) a
  exact ⟨h.1, h.2.trans ((diskKilledBarrier_le N y R a).trans (diskBarrier_le N y R a))⟩

lemma disk_discrete_survival_markov (N : Size) (y : Vertex N) (R : ℝ) (hR : 0 ≤ R)
    (hsmall : 2*(R+1) < N.val) (a : Vertex N) (n : ℕ) :
    discreteSurvival N a (Finset.univ \ torusDisk N y R) n ≤ (R+1)^2 / ((n : ℝ)+1) := by
  have hsum := discreteSurvival_sum_le_barrier N _ (diskKilledBarrier N y R)
    (diskKilledBarrier_nonneg N y R) (diskKilledBarrier_supersolution N y R hR hsmall) (n+1) a
  have hlo : ((n : ℝ)+1)*discreteSurvival N a (Finset.univ \ torusDisk N y R) n ≤
      ∑ j ∈ Finset.range (n+1), discreteSurvival N a (Finset.univ \ torusDisk N y R) j := by
    calc
      _ = ∑ _j ∈ Finset.range (n+1), discreteSurvival N a (Finset.univ \ torusDisk N y R) n := by simp
      _ ≤ _ := Finset.sum_le_sum fun j hj => discreteSurvival_antitone N _ a
        (by have := Finset.mem_range.mp hj; omega)
  apply (le_div_iff₀ (show (0 : ℝ) < (n : ℝ)+1 by positivity)).mpr
  have hh := hlo.trans (hsum.trans ((diskKilledBarrier_le N y R a).trans (diskBarrier_le N y R a)))
  nlinarith

end TorusCoverTime.Blocks.B
