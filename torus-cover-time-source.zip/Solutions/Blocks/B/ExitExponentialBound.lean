import Solutions.Blocks.B.ExitExponentialRenewal

/-! A proved positive supersolution bounds exponential occupation on all
actual finite exit words; monotone convergence removes the word cutoff. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

def exitExpWeight (N : Size) (D : Finset (Vertex N)) (b : Vertex N)
    (U : Vertex N → ℝ) (θ : ℝ) (a : Vertex N) (ω : WalkSample) : ℝ≥0∞ :=
  if ω ∈ exitsThrough N D a b then
    ENNReal.ofReal (Real.exp (θ*holdingPotentialSum N U a ω (finiteExitIndex N D a ω))) else 0

def exitExpPrefix (N : Size) (D : Finset (Vertex N)) (b : Vertex N)
    (U : Vertex N → ℝ) (θ : ℝ) (n : ℕ) (a : Vertex N) (ω : WalkSample) : ℝ≥0∞ :=
  if finiteExitIndex N D a ω ≤ n then exitExpWeight N D b U θ a ω else 0

theorem measurable_exitExpWeight (N : Size) (D : Finset (Vertex N)) (b : Vertex N)
    (U : Vertex N → ℝ) (θ : ℝ) (a : Vertex N) : Measurable (exitExpWeight N D b U θ a) := by
  have hm : Measurable (fun p : WalkSample × ℕ => holdingPotentialSum N U a p.1 p.2) :=
    measurable_from_prod_countable_left (measurable_holdingPotentialSum N U a)
  have ht := hm.comp (measurable_id.prodMk (measurable_finiteExitIndex N D a))
  have hi := (ht.const_mul θ).exp.ennreal_ofReal.indicator (measurableSet_exitsThrough N D a b)
  have he : exitExpWeight N D b U θ a = (exitsThrough N D a b).indicator
      (fun ω => ENNReal.ofReal (Real.exp (θ*holdingPotentialSum N U a ω (finiteExitIndex N D a ω)))) := rfl
  rw [he]
  exact hi

theorem measurable_exitExpPrefix (N : Size) (D : Finset (Vertex N)) (b : Vertex N)
    (U : Vertex N → ℝ) (θ : ℝ) (n : ℕ) (a : Vertex N) : Measurable (exitExpPrefix N D b U θ n a) := by
  unfold exitExpPrefix
  exact Measurable.ite (measurableSet_le (measurable_finiteExitIndex N D a) measurable_const)
    (measurable_exitExpWeight N D b U θ a) measurable_const

theorem exitExpPrefix_monotone (N : Size) (D : Finset (Vertex N)) (b : Vertex N)
    (U : Vertex N → ℝ) (θ : ℝ) (a : Vertex N) : Monotone (fun n => exitExpPrefix N D b U θ n a) := by
  intro n m hnm ω
  dsimp only [exitExpPrefix]
  split_ifs with hn hm
  · exact le_rfl
  · exact False.elim (hm (hn.trans hnm))
  · exact bot_le
  · exact le_rfl

theorem exitExpWeight_eq_iSup (N : Size) (D : Finset (Vertex N)) (b : Vertex N)
    (U : Vertex N → ℝ) (θ : ℝ) (a : Vertex N) (ω : WalkSample) :
    exitExpWeight N D b U θ a ω = ⨆ n, exitExpPrefix N D b U θ n a ω := by
  apply le_antisymm
  · apply le_iSup_of_le (finiteExitIndex N D a ω)
    simp only [exitExpPrefix, le_refl, if_true]
  · apply iSup_le
    intro n
    unfold exitExpPrefix
    split_ifs <;> simp

theorem exitExpPrefix_boundary (N : Size) (D : Finset (Vertex N)) (b : Vertex N)
    (U : Vertex N → ℝ) (θ : ℝ) (n : ℕ) (a : Vertex N) (ha : a ∉ D) (ω : WalkSample) :
    exitExpPrefix N D b U θ n a ω = if a = b then 1 else 0 := by
  have hj : finiteExitIndex N D a ω = 0 := finiteExitIndex_of_exit_word N D a a ω 0
    ⟨ha, by simp [position], by intro i; exact Fin.elim0 i⟩
  simp only [exitExpPrefix, exitExpWeight, hj, Nat.zero_le, if_true,
    exitsThrough_outside N D a b ha ω, holdingPotentialSum, Finset.range_zero,
    Finset.sum_empty, mul_zero, Real.exp_zero, ENNReal.ofReal_one]

theorem exitExpPrefix_zero_inside (N : Size) (D : Finset (Vertex N)) (b : Vertex N)
    (U : Vertex N → ℝ) (θ : ℝ) (a : Vertex N) (ha : a ∈ D) (ω : WalkSample) :
    exitExpPrefix N D b U θ 0 a ω = 0 := by
  unfold exitExpPrefix exitExpWeight
  split_ifs with hj he
  · obtain ⟨n,hn⟩ := he
    rw [finiteExitIndex_of_exit_word N D a b ω n hn] at hj
    have hn0 : n = 0 := Nat.eq_zero_of_le_zero hj
    subst n
    have heq : a = b := by simpa only [position_zero] using hn.2.1
    exact False.elim (hn.1 (heq ▸ ha))
  · rfl
  · rfl

theorem exitExpPrefix_succ_inside (N : Size) (D : Finset (Vertex N)) (b : Vertex N)
    (U : Vertex N → ℝ) (θ : ℝ) (n : ℕ) (a : Vertex N) (ha : a ∈ D) (ω : WalkSample) :
    exitExpPrefix N D b U θ (n+1) a ω = ENNReal.ofReal (Real.exp ((θ*U a)*holdingTime ω 0))*
      exitExpPrefix N D b U θ n (a+direction N (ω 0).2) (walkTail ω) := by
  by_cases he : ω ∈ exitsThrough N D a b
  · have ht := (exitsThrough_shift N D a b ha ω).mp he
    obtain ⟨j,hj⟩ := ht
    have hjo := (exitsThroughAt_succ_shift N D a b ω j).mpr ⟨ha,hj⟩
    have hti := finiteExitIndex_of_exit_word N D (a+direction N (ω 0).2) b (walkTail ω) j hj
    simp only [exitExpPrefix, exitExpWeight, if_pos he,
      if_pos (show walkTail ω ∈ exitsThrough N D (a+direction N (ω 0).2) b from ⟨j,hj⟩),
      finiteExitIndex_of_exit_word N D a b ω (j+1) hjo, hti, Nat.add_le_add_iff_right]
    split_ifs
    · rw [holdingPotentialSum_succ_shift, mul_add, Real.exp_add, ENNReal.ofReal_mul (Real.exp_pos _).le,
        mul_assoc]
    · simp
  · have ht := mt (exitsThrough_shift N D a b ha ω).mpr he
    simp only [exitExpPrefix, exitExpWeight, if_neg he, if_neg ht, ite_self, mul_zero]

theorem exitExpPrefix_lintegral_bound (N : Size) (D : Finset (Vertex N)) (b : Vertex N)
    (U : Vertex N → ℝ) (θ : ℝ) (f : Vertex N → ℝ) (hf : ∀ a, 0 ≤ f a)
    (hb : ∀ a, a ∉ D → (if a = b then 1 else 0) ≤ f a)
    (ht : ∀ a ∈ D, θ*U a < 1)
    (hstep : ∀ a ∈ D, (∑ d : Fin 4, f (a+direction N d))/(4*(1-θ*U a)) ≤ f a)
    (n : ℕ) (a : Vertex N) :
    (∫⁻ ω, exitExpPrefix N D b U θ n a ω ∂walkLaw) ≤ ENNReal.ofReal (f a) := by
  induction n generalizing a with
  | zero =>
    by_cases ha : a ∈ D
    · simp only [exitExpPrefix_zero_inside N D b U θ a ha, lintegral_zero, zero_le]
    · simp_rw [exitExpPrefix_boundary N D b U θ 0 a ha]
      have he : (if a = b then (1:ℝ≥0∞) else 0) = ENNReal.ofReal (if a = b then (1:ℝ) else 0) := by
        split_ifs <;> simp
      rw [lintegral_const, measure_univ, mul_one, he]
      exact ENNReal.ofReal_le_ofReal (hb a ha)
  | succ n ih =>
    by_cases ha : a ∈ D
    · simp_rw [exitExpPrefix_succ_inside N D b U θ n a ha]
      rw [lintegral_first_step_exp (θ*U a) (ht a ha)
        (fun d => exitExpPrefix N D b U θ n (a+direction N d))
        (fun d => measurable_exitExpPrefix N D b U θ n _)]
      have hs : (∑ d : Fin 4, ∫⁻ ω, exitExpPrefix N D b U θ n (a+direction N d) ω ∂walkLaw) ≤
          ∑ d : Fin 4, ENNReal.ofReal (f (a+direction N d)) := Finset.sum_le_sum fun d _ => ih _
      have hu := mul_le_mul' (le_refl (ENNReal.ofReal (1/(1-θ*U a)))) (ENNReal.div_le_div_right hs 4)
      apply hu.trans
      rw [← ENNReal.ofReal_sum_of_nonneg (fun d _ => hf _),
        show (4:ℝ≥0∞) = ENNReal.ofReal (4:ℝ) by norm_num,
        ← ENNReal.ofReal_div_of_pos (by norm_num : (0:ℝ)<4),
        ← ENNReal.ofReal_mul (by have := ht a ha; positivity : 0 ≤ 1/(1-θ*U a))]
      apply ENNReal.ofReal_le_ofReal
      calc
        _ = (∑ d : Fin 4, f (a+direction N d))/(4*(1-θ*U a)) := by
          simp only [div_eq_mul_inv, mul_inv_rev]
          ring
        _ ≤ f a := hstep a ha
    · simp_rw [exitExpPrefix_boundary N D b U θ (n+1) a ha]
      have he : (if a = b then (1:ℝ≥0∞) else 0) = ENNReal.ofReal (if a = b then (1:ℝ) else 0) := by
        split_ifs <;> simp
      rw [lintegral_const, measure_univ, mul_one, he]
      exact ENNReal.ofReal_le_ofReal (hb a ha)

theorem exitExpWeight_lintegral_bound (N : Size) (D : Finset (Vertex N)) (b : Vertex N)
    (U : Vertex N → ℝ) (θ : ℝ) (f : Vertex N → ℝ) (hf : ∀ a, 0 ≤ f a)
    (hb : ∀ a, a ∉ D → (if a = b then 1 else 0) ≤ f a)
    (ht : ∀ a ∈ D, θ*U a < 1)
    (hstep : ∀ a ∈ D, (∑ d : Fin 4, f (a+direction N d))/(4*(1-θ*U a)) ≤ f a)
    (a : Vertex N) :
    (∫⁻ ω, exitExpWeight N D b U θ a ω ∂walkLaw) ≤ ENNReal.ofReal (f a) := by
  simp_rw [exitExpWeight_eq_iSup]
  rw [lintegral_iSup (fun n => measurable_exitExpPrefix N D b U θ n a)
    (exitExpPrefix_monotone N D b U θ a)]
  exact iSup_le (fun n => exitExpPrefix_lintegral_bound N D b U θ f hf hb ht hstep n a)

end TorusCoverTime.Blocks.B
