import Solutions.Blocks.B.SmoothPositivePart
import Solutions.Blocks.B.GreenLogarithm
import Solutions.Blocks.B.GreenArbitraryDifferences

/-! A compactly supported smooth truncation of the actual torus potential.
It is affine near its source and has a radius-squared generator bound away
from the source. This supplies the upper harmonic mean inequality. -/

noncomputable section
open Classical
namespace TorusCoverTime.Blocks.B

def harmonicCutoffOffset : ℝ := greenDiagonalErrorConstant + greenLogErrorConstant + 1
def harmonicCutoffScale : ℝ := Real.exp ((2*harmonicCutoffOffset+2)/g)

theorem harmonicCutoffOffset_pos : 0 < harmonicCutoffOffset := by
  have := greenDiagonalErrorConstant_pos
  have := greenLogErrorConstant_pos
  unfold harmonicCutoffOffset
  positivity

theorem harmonicCutoffScale_ge_one : 1 ≤ harmonicCutoffScale := by
  have := harmonicCutoffOffset_pos
  unfold harmonicCutoffScale g
  apply Real.one_le_exp_iff.mpr
  positivity

def harmonicCutoffPotential (N : Size) (c : Vertex N) (R : ℝ) (z : Vertex N) : ℝ :=
  g*Real.log R - harmonicCutoffOffset - (greenDiagonal N - greenKernel N z c)

def harmonicCutoff (N : Size) (c : Vertex N) (R : ℝ) (z : Vertex N) : ℝ :=
  smoothPositivePart (harmonicCutoffPotential N c R z)

theorem harmonicCutoffPotential_generator (N : Size) (c : Vertex N) (R : ℝ) (z : Vertex N) :
    generator N (harmonicCutoffPotential N c R) z = (1/vertexCount N) - (if z = c then 1 else 0) := by
  have hg := greenKernel_generator N z c
  change generator N ((fun _ => g*Real.log R-harmonicCutoffOffset) -
    ((fun _ => greenDiagonal N)-(fun y => greenKernel N y c))) z = _
  rw [generator_sub, generator_sub, generator_const, generator_const]
  linarith

theorem harmonicCutoffPotential_outside (N : Size) (c : Vertex N) (R : ℝ) (hR : 0 < R)
    (z : Vertex N) (hz : R ≤ periodicDistance z c) : harmonicCutoffPotential N c R z ≤ 0 := by
  have hd0 : 0 < periodicDistance z c := hR.trans_le hz
  have hzc : z ≠ c := by intro he; subst z; rw [periodicDistance_self_zero] at hd0; linarith
  have he := (abs_le.mp (green_increment_log_error N z c hzc)).1
  rw [greenKernel_diagonal] at he
  have hg : 0 ≤ g := by unfold g; positivity
  have hl := mul_le_mul_of_nonneg_left (Real.log_le_log hR hz) hg
  unfold harmonicCutoffPotential harmonicCutoffOffset
  linarith

theorem harmonicCutoff_outside (N : Size) (c : Vertex N) (R : ℝ) (hR : 0 < R)
    (z : Vertex N) (hz : R ≤ periodicDistance z c) : harmonicCutoff N c R z = 0 :=
  smoothPositivePart_zero _ (harmonicCutoffPotential_outside N c R hR z hz)

theorem harmonicCutoffPotential_inside (N : Size) (c : Vertex N) (R : ℝ)
    (hR : harmonicCutoffScale ≤ R) (z : Vertex N)
    (hz : periodicDistance z c ≤ R/harmonicCutoffScale) : 1 ≤ harmonicCutoffPotential N c R z := by
  have hL := harmonicCutoffScale_ge_one
  have hL0 : 0 < harmonicCutoffScale := by linarith
  have hR0 : 0 < R := hL0.trans_le hR
  have hg : 0 < g := by unfold g; positivity
  have hA := harmonicCutoffOffset_pos
  have hlogL : g*Real.log harmonicCutoffScale = 2*harmonicCutoffOffset+2 := by
    unfold harmonicCutoffScale
    rw [Real.log_exp]
    field_simp
  by_cases hzc : z = c
  · subst z
    have hl := mul_le_mul_of_nonneg_left (Real.log_le_log hL0 hR) hg.le
    unfold harmonicCutoffPotential
    rw [greenKernel_diagonal]
    linarith
  · have hd0 : 0 < periodicDistance z c := by
      have hd := periodicDistance_nonzero_ge_one N (z-c) (sub_ne_zero.mpr hzc)
      rw [periodicDistance_sub_zero] at hd
      linarith
    have he := (abs_le.mp (green_increment_log_error N z c hzc)).2
    rw [greenKernel_diagonal] at he
    have hl := Real.log_le_log hd0 hz
    rw [Real.log_div hR0.ne' hL0.ne'] at hl
    have hm := mul_le_mul_of_nonneg_left hl hg.le
    unfold harmonicCutoffPotential harmonicCutoffOffset at *
    linarith

theorem harmonicCutoff_generator_inner (N : Size) (c : Vertex N) (R : ℝ)
    (hR : 2*harmonicCutoffScale ≤ R) (z : Vertex N)
    (hz : periodicDistance z c ≤ R/(2*harmonicCutoffScale)) :
    generator N (harmonicCutoff N c R) z = (1/vertexCount N) - (if z = c then 1 else 0) := by
  have hL := harmonicCutoffScale_ge_one
  have hL0 : 0 < harmonicCutoffScale := by linarith
  have hR0 : 0 < R := by linarith
  have hhalf : R/(2*harmonicCutoffScale) ≤ R/harmonicCutoffScale :=
    div_le_div_of_nonneg_left hR0.le hL0 (by linarith)
  have hone : 1 ≤ R/(2*harmonicCutoffScale) := (le_div_iff₀ (by positivity)).mpr (by linarith)
  have hz0 := harmonicCutoffPotential_inside N c R (by linarith) z (hz.trans hhalf)
  have hstep (d : Fin 4) : 1 ≤ harmonicCutoffPotential N c R (z+direction N d) := by
    apply harmonicCutoffPotential_inside N c R (by linarith)
    have hd := periodicDistance_step_le N c z d
    have hid : R/(2*harmonicCutoffScale)+R/(2*harmonicCutoffScale) = R/harmonicCutoffScale := by ring
    linarith
  rw [← harmonicCutoffPotential_generator N c R z]
  unfold generator harmonicCutoff
  simp only [smoothPositivePart_linear _ hz0, smoothPositivePart_linear _ (hstep _)]
  congr 1
  apply Finset.sum_congr rfl
  intro d _
  ring

theorem harmonicCutoff_generator_outside (N : Size) (c : Vertex N) (R : ℝ) (hR : 0 < R)
    (z : Vertex N) (hz : R+1 ≤ periodicDistance z c) : generator N (harmonicCutoff N c R) z = 0 := by
  have hz0 := harmonicCutoff_outside N c R hR z (by linarith)
  have hstep (d : Fin 4) : harmonicCutoff N c R (z+direction N d) = 0 := by
    apply harmonicCutoff_outside N c R hR
    have ht := periodicDistance_triangle N z (z+direction N d) c
    rw [periodicDistance_comm z (z+direction N d), periodicDistance_step] at ht
    linarith
  simp only [generator, hz0, hstep, sub_self, Finset.sum_const_zero, mul_zero]

def harmonicCutoffGradientConstant : ℝ := Classical.choose green_nearest_differences

theorem harmonicCutoffGradientConstant_pos : 0 < harmonicCutoffGradientConstant :=
  (Classical.choose_spec green_nearest_differences).1

theorem harmonicCutoffGradientConstant_control : NearestGreenControl harmonicCutoffGradientConstant :=
  (Classical.choose_spec green_nearest_differences).2

def harmonicCutoffSourceConstant : ℝ := 1+2*(harmonicCutoffGradientConstant*harmonicCutoffScale)^2

theorem harmonicCutoffSourceConstant_pos : 0 < harmonicCutoffSourceConstant := by
  unfold harmonicCutoffSourceConstant
  positivity

theorem harmonicCutoff_generator_bound (N : Size) (c : Vertex N) (R : ℝ)
    (hR : 2*harmonicCutoffScale ≤ R) (hRN : R ≤ N.val) (z : Vertex N) (hzc : z ≠ c) :
    generator N (harmonicCutoff N c R) z ≤ harmonicCutoffSourceConstant/R^2 := by
  have hL := harmonicCutoffScale_ge_one
  have hL0 : 0 < harmonicCutoffScale := by linarith
  have hR0 : 0 < R := by linarith
  have hC := harmonicCutoffGradientConstant_pos
  have hv : 1/vertexCount N ≤ 1/R^2 := by
    apply one_div_le_one_div_of_le (sq_pos_of_pos hR0)
    unfold vertexCount
    exact pow_le_pow_left₀ hR0.le hRN 2
  by_cases hz : periodicDistance z c ≤ R/(2*harmonicCutoffScale)
  · rw [harmonicCutoff_generator_inner N c R hR z hz, if_neg hzc, sub_zero]
    apply hv.trans
    apply div_le_div_of_nonneg_right _ (sq_nonneg R)
    unfold harmonicCutoffSourceConstant
    linarith [sq_nonneg (harmonicCutoffGradientConstant*harmonicCutoffScale)]
  · have hd : 0 < periodicDistance z c := (div_pos hR0 (by positivity)).trans (not_le.mp hz)
    have hstep (d : Fin 4) :
        |harmonicCutoffPotential N c R (z+direction N d) - harmonicCutoffPotential N c R z| ≤
          (2*harmonicCutoffGradientConstant*harmonicCutoffScale)/R := by
      have he := green_step_first harmonicCutoffGradientConstant_control N z c hd d
      have hid : harmonicCutoffPotential N c R (z+direction N d) - harmonicCutoffPotential N c R z =
          greenKernel N (z+direction N d) c - greenKernel N z c := by unfold harmonicCutoffPotential; ring
      rw [hid]
      apply he.trans
      calc
        _ ≤ harmonicCutoffGradientConstant/(R/(2*harmonicCutoffScale)) :=
          div_le_div_of_nonneg_left hC.le (div_pos hR0 (by positivity)) (not_le.mp hz).le
        _ = _ := by field_simp
    have he := (smoothPositivePart_generator_bound N (harmonicCutoffPotential N c R) z
      ((2*harmonicCutoffGradientConstant*harmonicCutoffScale)/R) (by positivity) hstep).2
    rw [harmonicCutoffPotential_generator, if_neg hzc, sub_zero] at he
    have hm := mul_le_mul_of_nonneg_right (smoothPositiveSlope_bounds (harmonicCutoffPotential N c R z)).2
      (one_div_nonneg.mpr (vertexCount_pos N).le)
    change generator N (harmonicCutoff N c R) z ≤ _ at he
    have hid : 1/R^2+((2*harmonicCutoffGradientConstant*harmonicCutoffScale)/R)^2/2 =
        harmonicCutoffSourceConstant/R^2 := by unfold harmonicCutoffSourceConstant; field_simp
    rw [← hid]
    linarith

end TorusCoverTime.Blocks.B
