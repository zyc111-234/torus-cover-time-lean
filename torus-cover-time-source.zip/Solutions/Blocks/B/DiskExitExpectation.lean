import Solutions.Blocks.B.KilledLifetime
import Solutions.Blocks.B.ExitVisit

/-! The physical disk exit has mean at most (R+1)^2. The holding-time sum is
integrated using independence from the entire direction sequence, at unbounded exit indices. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Classical
open scoped ENNReal Topology BigOperators
namespace TorusCoverTime.Blocks.B

lemma holdingLaw_lintegral_mean : (∫⁻ s, ENNReal.ofReal (max s 0) ∂holdingLaw) = 1 := by
  change (∫⁻ s, ENNReal.ofReal (max s 0) ∂volume.withDensity (exponentialPDF 1)) = 1
  have hpdf : Measurable (exponentialPDF 1) := (measurable_exponentialPDFReal 1).ennreal_ofReal
  rw [lintegral_withDensity_eq_lintegral_mul _ hpdf (by fun_prop)]
  have hg : Real.Gamma 2 = 1 := by
    simpa using Real.Gamma_nat_eq_factorial 1
  have heq (s : ℝ) : exponentialPDF 1 s * ENNReal.ofReal (max s 0) = gammaPDF 2 1 s := by
    by_cases hs : 0 ≤ s
    · norm_num [exponentialPDF_eq, gammaPDF_eq, hs, hg]
      exact mul_comm _ _
    · simp [exponentialPDF_eq, gammaPDF_eq, hs]
  simp only [Pi.mul_apply]
  simp_rw [heq]
  exact lintegral_gammaPDF_eq_one (by norm_num) (by norm_num)

lemma holdingTime_lintegral_mean (j : ℕ) :
    (∫⁻ ω : WalkSample, ENNReal.ofReal (holdingTime ω j) ∂walkLaw) = 1 := by
  have hm : Measurable (fun s : ℝ => ENNReal.ofReal (max s 0)) := by fun_prop
  have hmap := lintegral_map' (μ := walkLaw) hm.aemeasurable
    (show Measurable (fun ω : WalkSample => (ω j).1) by fun_prop).aemeasurable
  rw [holding_coordinate_law] at hmap
  exact hmap.symm.trans holdingLaw_lintegral_mean

lemma holdingTime_lintegral_direction_event (j : ℕ)
    (E : Set (ℕ → Fin 4)) (hE : MeasurableSet E) :
    (∫⁻ ω : WalkSample, if walkDirections ω ∈ E then ENNReal.ofReal (holdingTime ω j) else 0
      ∂walkLaw) = walkLaw (walkDirections ⁻¹' E) := by
  have hmE := hE.preimage measurable_walkDirections
  have hmG : Measurable (E.indicator (fun _ => (1 : ℝ≥0∞))) := measurable_const.indicator hE
  have hi := (holdingTime_independent_directions j).comp measurable_id.ennreal_ofReal hmG
  have hp := lintegral_mul_eq_lintegral_mul_lintegral_of_indepFun
    ((measurable_holdingTime j).ennreal_ofReal) (hmG.comp measurable_walkDirections) hi
  have heq (ω : WalkSample) : ENNReal.ofReal (holdingTime ω j) *
      E.indicator (fun _ => (1 : ℝ≥0∞)) (walkDirections ω) =
      if walkDirections ω ∈ E then ENNReal.ofReal (holdingTime ω j) else 0 := by
    simp only [Set.indicator]
    split_ifs <;> simp
  have hG : (fun ω : WalkSample => E.indicator (fun _ => (1 : ℝ≥0∞)) (walkDirections ω)) =
      (walkDirections ⁻¹' E).indicator (fun _ => (1 : ℝ≥0∞)) := rfl
  change (∫⁻ ω, ENNReal.ofReal (holdingTime ω j) *
    E.indicator (fun _ => (1 : ℝ≥0∞)) (walkDirections ω) ∂walkLaw) = _ at hp
  simp_rw [heq] at hp
  rw [holdingTime_lintegral_mean, one_mul] at hp
  simp only [Function.comp_apply] at hp
  rw [hG, lintegral_indicator hmE] at hp
  simpa using hp

lemma finiteExitDuration_eq_tsum (N : Size) (D : Finset (Vertex N))
    (a : Vertex N) (ω : WalkSample) :
    ENNReal.ofReal (finiteExitDuration N D a ω) =
      ∑' j : ℕ, if j < finiteExitIndex N D a ω then ENNReal.ofReal (holdingTime ω j) else 0 := by
  rw [tsum_eq_sum (s := Finset.range (finiteExitIndex N D a ω)) (fun j hj =>
    if_neg (by simpa only [Finset.mem_range] using hj))]
  rw [finiteExitDuration, jumpTime, ENNReal.ofReal_sum_of_nonneg
    (fun j _ => (show 0 ≤ holdingTime ω j from le_max_right _ _))]
  exact Finset.sum_congr rfl fun j hj => (if_pos (Finset.mem_range.mp hj)).symm

lemma finiteExitIndex_gt_implies_survival (N : Size) (D : Finset (Vertex N))
    (a : Vertex N) (ω : WalkSample) (n : ℕ) (hn : n < finiteExitIndex N D a ω) :
    discreteAvoids N a (Finset.univ \ D) ω n := by
  have he : ∃ j : ℕ, position N a ω j ∉ D := by
    by_contra he
    simp [finiteExitIndex, he] at hn
  rw [finiteExitIndex, dif_pos he] at hn
  intro j hj
  have hm := not_not.mp (Nat.find_min he (hj.trans_lt hn))
  simpa using hm

lemma finiteExitDuration_lintegral_eq_tail_sum (N : Size) (D : Finset (Vertex N))
    (a : Vertex N) :
    (∫⁻ ω, ENNReal.ofReal (finiteExitDuration N D a ω) ∂walkLaw) =
      ∑' j : ℕ, walkLaw {ω | j < finiteExitIndex N D a ω} := by
  simp_rw [finiteExitDuration_eq_tsum]
  rw [lintegral_tsum (fun j => (show Measurable (fun ω : WalkSample =>
    if j < finiteExitIndex N D a ω then ENNReal.ofReal (holdingTime ω j) else 0) from
      Measurable.ite (measurableSet_lt measurable_const (measurable_finiteExitIndex N D a))
        (measurable_holdingTime j).ennreal_ofReal measurable_const).aemeasurable)]
  apply tsum_congr
  intro j
  let E : Set (ℕ → Fin 4) := {d | j < finiteExitIndex N D a (skeletonSample d)}
  have hE : MeasurableSet E := measurableSet_lt measurable_const
    ((measurable_finiteExitIndex N D a).comp measurable_skeletonSample)
  have hset : walkDirections ⁻¹' E = {ω | j < finiteExitIndex N D a ω} := by
    ext ω
    rfl
  calc
    _ = ∫⁻ ω : WalkSample, if walkDirections ω ∈ E then
        ENNReal.ofReal (holdingTime ω j) else 0 ∂walkLaw := by
      apply lintegral_congr
      intro ω
      by_cases hj : j < finiteExitIndex N D a ω
      · have he : walkDirections ω ∈ E := hj
        rw [if_pos hj, if_pos he]
      · have he : walkDirections ω ∉ E := hj
        rw [if_neg hj, if_neg he]
    _ = walkLaw (walkDirections ⁻¹' E) := by
      convert holdingTime_lintegral_direction_event j E hE using 1
      apply lintegral_congr
      intro ω
      split_ifs <;> rfl
    _ = _ := congrArg walkLaw hset

theorem disk_finiteExitDuration_mean_le (N : Size) (y : Vertex N) (R : ℝ) (hR : 0 ≤ R)
    (hsmall : 2*(R+1) < N.val) (a : Vertex N) :
    (∫⁻ ω, ENNReal.ofReal (finiteExitDuration N (torusDisk N y R) a ω) ∂walkLaw) ≤
      ENNReal.ofReal ((R+1)^2) := by
  rw [finiteExitDuration_lintegral_eq_tail_sum]
  have hsum := disk_discrete_survival_sum N y R hR hsmall a
  calc
    _ ≤ ∑' j : ℕ, walkLaw {ω | discreteAvoids N a (Finset.univ \ torusDisk N y R) ω j} := by
      apply ENNReal.tsum_le_tsum
      intro j
      exact measure_mono fun ω hω => finiteExitIndex_gt_implies_survival N _ a ω j hω
    _ = ∑' j : ℕ, ENNReal.ofReal (discreteSurvival N a (Finset.univ \ torusDisk N y R) j) := by
      apply tsum_congr
      intro j
      rw [discreteSurvival_measure, measureReal_def, ENNReal.ofReal_toReal (measure_ne_top walkLaw _)]
    _ = ENNReal.ofReal (∑' j, discreteSurvival N a (Finset.univ \ torusDisk N y R) j) :=
      (ENNReal.ofReal_tsum_of_nonneg (discreteSurvival_nonneg N _ a) hsum.1).symm
    _ ≤ _ := ENNReal.ofReal_le_ofReal hsum.2

theorem disk_finiteExitDuration_integrable (N : Size) (y : Vertex N) (R : ℝ) (hR : 0 ≤ R)
    (hsmall : 2*(R+1) < N.val) (a : Vertex N) :
    Integrable (finiteExitDuration N (torusDisk N y R) a) walkLaw := by
  refine ⟨(measurable_finiteExitDuration N _ a).aestronglyMeasurable, ?_⟩
  apply (hasFiniteIntegral_iff_ofReal (Eventually.of_forall
    (fun ω => jumpTime_nonneg ω (finiteExitIndex N (torusDisk N y R) a ω)))).mpr
  exact (disk_finiteExitDuration_mean_le N y R hR hsmall a).trans_lt ENNReal.ofReal_lt_top

theorem disk_finiteExitDuration_integral_le (N : Size) (y : Vertex N) (R : ℝ) (hR : 0 ≤ R)
    (hsmall : 2*(R+1) < N.val) (a : Vertex N) :
    (∫ ω, finiteExitDuration N (torusDisk N y R) a ω ∂walkLaw) ≤ (R+1)^2 := by
  have hn (ω : WalkSample) : 0 ≤ finiteExitDuration N (torusDisk N y R) a ω := jumpTime_nonneg ω _
  have h := ENNReal.toReal_mono ENNReal.ofReal_ne_top (disk_finiteExitDuration_mean_le N y R hR hsmall a)
  rw [← ofReal_integral_eq_lintegral_ofReal (disk_finiteExitDuration_integrable N y R hR hsmall a)
      (Eventually.of_forall hn), ENNReal.toReal_ofReal (integral_nonneg hn),
    ENNReal.toReal_ofReal (sq_nonneg _)] at h
  exact h

theorem disk_physical_exit_mean_le (hWalk : WalkModelRegular)
    (N : Size) (y : Vertex N) (R : ℝ) (hR : 0 < R) (hsmall : 2*(R+1) < N.val)
    (a : Vertex N) :
    (∫⁻ ω, domainExitTime N (torusDisk N y R) a ω ∂walkLaw) ≤ ENNReal.ofReal ((R+1)^2) := by
  rw [lintegral_congr_ae (disk_finiteExitDuration_eq_physical_ae hWalk N y R hR hsmall a)]
  exact disk_finiteExitDuration_mean_le N y R hR.le hsmall a

end TorusCoverTime.Blocks.B
