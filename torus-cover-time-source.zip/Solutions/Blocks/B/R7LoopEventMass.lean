import Solutions.Blocks.B.R7BarrierEvents

/-! Finite unions under the original normalized, root-summed physical-time
loop measure. These operations do not replace the clock by a product law. -/

noncomputable section
open MeasureTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

def r7LoopEventTest (N : Size) (root : Vertex N) (E : Set (WalkSample × ℝ)) (l r : ℝ)
    (z : WalkSample × ℝ) : ℝ≥0∞ :=
  if z ∈ E ∧ walk N root z.1 z.2 = root ∧ z.2 ∈ Icc l r then 1 else 0

theorem r7LoopEventTest_measurable (N : Size) (root : Vertex N) (E : Set (WalkSample × ℝ))
    (hE : MeasurableSet E) (l r : ℝ) : Measurable (r7LoopEventTest N root E l r) :=
  measurable_const.ite (hE.inter ((measurable_walk_eq_joint N root root).setOf.inter
    (measurable_snd measurableSet_Icc))) measurable_const

def r7LoopEventMass (N : Size) (E : Vertex N → Set (WalkSample × ℝ)) (l r : ℝ) : ℝ≥0∞ :=
  (ENNReal.ofReal (timeScale N))⁻¹ * ∑ root : Vertex N,
    ∫⁻ ω, ∫⁻ t in Ioi (0:ℝ), r7LoopEventTest N root (E root) l r (ω,t) ∂volume ∂walkLaw

theorem r7LoopEventMass_mono_ae (N : Size) (E F : Vertex N → Set (WalkSample × ℝ))
    (hEF : ∀ root, ∀ᵐ ω ∂walkLaw, ∀ t : ℝ, 0 ≤ t → (ω,t) ∈ E root → (ω,t) ∈ F root)
    (l r : ℝ) : r7LoopEventMass N E l r ≤ r7LoopEventMass N F l r := by
  apply mul_le_mul' le_rfl
  apply Finset.sum_le_sum
  intro root _
  apply lintegral_mono_ae
  filter_upwards [hEF root] with ω hω
  apply lintegral_mono_ae
  filter_upwards [ae_restrict_mem (measurableSet_Ioi (a := (0:ℝ)))] with t ht
  unfold r7LoopEventTest
  split_ifs with hE hF hF
  · rfl
  · exact False.elim (hF ⟨hω t ht.le hE.1,hE.2⟩)
  · exact bot_le
  · rfl

theorem r7LoopEventMass_biUnion_le (N : Size) {ι : Type*} (s : Finset ι)
    (E : ι → Vertex N → Set (WalkSample × ℝ))
    (hE : ∀ i ∈ s, ∀ root, MeasurableSet (E i root)) (l r : ℝ) :
    r7LoopEventMass N (fun root => ⋃ i ∈ s, E i root) l r ≤
      ∑ i ∈ s, r7LoopEventMass N (E i) l r := by
  have hroot (root : Vertex N) :
      (∫⁻ ω, ∫⁻ t in Ioi (0:ℝ), r7LoopEventTest N root (⋃ i ∈ s, E i root) l r (ω,t) ∂volume ∂walkLaw) ≤
        ∑ i ∈ s, ∫⁻ ω, ∫⁻ t in Ioi (0:ℝ), r7LoopEventTest N root (E i root) l r (ω,t) ∂volume ∂walkLaw := by
    rw [← lintegral_finsetSum s (fun i hi =>
      (r7LoopEventTest_measurable N root _ (hE i hi root) l r).lintegral_prod_right')]
    apply lintegral_mono
    intro ω
    dsimp only
    have hm (i : ι) (hi : i ∈ s) : Measurable (fun t : ℝ => r7LoopEventTest N root (E i root) l r (ω,t)) :=
      (r7LoopEventTest_measurable N root _ (hE i hi root) l r).comp (measurable_const.prodMk measurable_id)
    rw [← lintegral_finsetSum s hm]
    apply lintegral_mono
    intro t
    change r7LoopEventTest N root (⋃ i ∈ s, E i root) l r (ω,t) ≤
      ∑ i ∈ s, r7LoopEventTest N root (E i root) l r (ω,t)
    by_cases h : (ω,t) ∈ (⋃ i ∈ s, E i root) ∧ walk N root ω t = root ∧ t ∈ Icc l r
    · obtain ⟨i,hi⟩ := mem_iUnion.mp h.1
      obtain ⟨hi,hEi⟩ := mem_iUnion.mp hi
      have hf : r7LoopEventTest N root (E i root) l r (ω,t) = 1 := if_pos ⟨hEi,h.2⟩
      have hleft : r7LoopEventTest N root (⋃ i ∈ s, E i root) l r (ω,t) = 1 := if_pos h
      calc
        _ = 1 := hleft
        _ = r7LoopEventTest N root (E i root) l r (ω,t) := hf.symm
        _ ≤ _ := Finset.single_le_sum (fun j _ => (bot_le : (0:ℝ≥0∞) ≤ r7LoopEventTest N root (E j root) l r (ω,t))) hi
    · have hleft : r7LoopEventTest N root (⋃ i ∈ s, E i root) l r (ω,t) = 0 := if_neg h
      rw [hleft]
      exact bot_le
  unfold r7LoopEventMass
  rw [← Finset.mul_sum,Finset.sum_comm]
  exact mul_le_mul' le_rfl (Finset.sum_le_sum (fun root _ => hroot root))

theorem r7LoopEventMass_perturbed (N : Size) (c : Vertex N) (γ q l r : ℝ) :
    r7LoopEventMass N (fun root => r7PerturbedBarrierEvent N root c γ q) l r =
      r7PerturbedIntegratedLowCount N c γ q (r7ShiftedBarrier N γ q) l r := by
  unfold r7LoopEventMass r7LoopEventTest r7PerturbedBarrierEvent r7PerturbedIntegratedLowCount
  simp only [mem_ofPred_eq,and_assoc]

theorem r7_lower_barrier_grid_mass (γ : ℝ) (hγ : 0 < γ) :
    ∀ᶠ N : Size in atTop, ∀ q : ℝ,
      (logSize N)^(16*γ) ≤ q → q ≤ logSize N-(logSize N)^(16*γ) → ∀ l r : ℝ,
      r7LoopEventMass N (fun root => r7LowerBarrierFailure N root γ q) l r ≤
        ∑ y ∈ r7Grid N q, r7PerturbedIntegratedLowCount N y γ q (r7ShiftedBarrier N γ q) l r := by
  filter_upwards [r7_lower_barrier_grid_ae γ hγ] with N hN
  intro q hq hqL l r
  calc
    _ ≤ r7LoopEventMass N (fun root => ⋃ y ∈ r7Grid N q, r7PerturbedBarrierEvent N root y γ q) l r :=
      r7LoopEventMass_mono_ae N _ _ (fun root => hN root q hq hqL) l r
    _ ≤ ∑ y ∈ r7Grid N q, r7LoopEventMass N (fun root => r7PerturbedBarrierEvent N root y γ q) l r :=
      r7LoopEventMass_biUnion_le N (r7Grid N q) (fun y root => r7PerturbedBarrierEvent N root y γ q)
        (fun y _ root => r7PerturbedBarrierEvent_measurable N root y γ q) l r
    _ = _ := Finset.sum_congr rfl (fun y _ => r7LoopEventMass_perturbed N y γ q l r)

end TorusCoverTime.Blocks.B
