import Solutions.Blocks.B.BT10SpatialSum

/-! Vanishing mass of all noncontact wide witnesses, followed by the
registered defect count bound under the same physical loop measure. -/
noncomputable section
open MeasureTheory Filter Set Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

theorem bt10_all_slice_tendsto (hWalk : WalkModelRegular) (γ U H : ℝ)
    (hγ : 0<γ) (hγ1 : 16*γ<1) (hU : 0≤U) (hH : 0≤H) (l r : Size → ℝ)
    (hwin : ∀ᶠ N : Size in atTop, l N≤r N ∧ phaseACenter N-H*timeScale N≤l N ∧
      r N≤phaseACenter N+H*timeScale N) :
    Tendsto (fun N => bt10AllSliceMass N γ U (l N) (r N)) atTop (𝓝 0) := by
  obtain ⟨a,C,ha,hC,hbound⟩ := bt10_slice_bound hWalk γ U H hγ hγ1 hU hH
  have ht := ENNReal.tendsto_ofReal ((bt10_aggregate_envelope_tendsto γ H a C hγ hH ha).comp blockB_logSize_tendsto)
  simp only [ENNReal.ofReal_zero] at ht
  apply tendsto_of_tendsto_of_tendsto_of_le_of_le' tendsto_const_nhds ht (Eventually.of_forall fun _ => bot_le)
  filter_upwards [hbound,hwin,blockB_logSize_tendsto.eventually_ge_atTop 1] with N hN hw hL
  apply bt10_spatial_sum_bound N γ U H a C (l N) (r N) hL hH hC.le
  intro q hq x y m hm
  have hqr := (mem_r8InteriorIntegerScales N γ q).mp hq
  have hQ := Real.rpow_nonneg (logSize_pos N).le (16*γ)
  exact hN x y m hm q (l N) (r N) (by linarith) (by linarith) hw.1 hw.2.1 hw.2.2

theorem bt10_witness_tendsto (hWalk : WalkModelRegular) (γ u H : ℝ)
    (hγ : 0<γ) (hγhi : 32*γ<1/10) (hu : 0≤u) (hH : 0≤H) (l r : Size → ℝ)
    (hwin : ∀ᶠ N : Size in atTop, l N≤r N ∧ phaseACenter N-H*timeScale N≤l N ∧
      r N≤phaseACenter N+H*timeScale N) :
    Tendsto (fun N => r7LoopEventMass N (fun root => bt10WitnessEvent N root γ u) (l N) (r N)) atTop (𝓝 0) := by
  have hg : 0<g := by unfold g; positivity
  have hU : 0≤2*u/g := by positivity
  have ht := bt10_all_slice_tendsto hWalk γ (2*u/g) H hγ (by linarith) hU hH l r hwin
  apply tendsto_of_tendsto_of_tendsto_of_le_of_le' tendsto_const_nhds ht (Eventually.of_forall fun _ => bot_le)
  filter_upwards [bt10_witness_cover γ hγ hγhi] with N hN
  exact (r7LoopEventMass_mono_ae N _ _ (fun root => Eventually.of_forall (fun _ _ _ hz => hN root u hz))
    (l N) (r N)).trans (bt10_all_slice_union_bound N γ (2*u/g) (l N) (r N))

theorem bt10_defect_count_le_contact (N : Size) (root : Vertex N) (γ u : ℝ) (z : WalkSample × ℝ)
    (hg : bt8Good N root γ u z) (hw : z∉bt10WitnessEvent N root γ u) :
    bt10DefectCount N root u z≤bt8SoftCount N root γ u z := by
  let S := Finset.univ.filter (fun x : Vertex N => bt8SoftPoint N root x γ u z)
  have hsub : wideDefects N (softSet N root z.1 u z.2)⊆S := by
    intro x hx
    obtain ⟨hx,y,hy,hlo,hhi⟩ := Finset.mem_filter.mp hx
    have hx' : localTime N root z.1 z.2 x≤u := (Finset.mem_filter.mp hx).2
    have hy' : localTime N root z.1 z.2 y≤u := (Finset.mem_filter.mp hy).2
    apply Finset.mem_filter.mpr
    refine ⟨Finset.mem_univ x,?_⟩
    by_contra hn
    exact hw ⟨hg,x,y,⟨hlo,hhi⟩,hx',hy',hn⟩
  have hc : ((wideDefects N (softSet N root z.1 u z.2)).card:ℝ)≤(S.card:ℝ) := by
    exact_mod_cast Finset.card_le_card hsub
  have hS : (S.card:ℝ)=bt8SoftCount N root γ u z := by
    simp only [S,Finset.card_eq_sum_ones,Finset.sum_filter,Nat.cast_sum,Nat.cast_ite,Nat.cast_one,Nat.cast_zero,bt8SoftCount]
  exact hc.trans_eq hS

theorem bt10_defect_event_bound (N : Size) (γ u η l r : ℝ) :
    r7LoopEventMass N (fun root => {z | η*Real.sqrt (logSize N)<bt10DefectCount N root u z}) l r ≤
      r7LoopEventMass N (fun root => {z | ¬bt8Good N root γ u z}) l r+
      (r7LoopEventMass N (fun root => bt10WitnessEvent N root γ u) l r+
        r7LoopEventMass N (fun root => {z | η*Real.sqrt (logSize N)<bt8SoftCount N root γ u z}) l r) := by
  let E := fun root => {z | ¬bt8Good N root γ u z}
  let F := fun root => bt10WitnessEvent N root γ u
  let G := fun root => {z | η*Real.sqrt (logSize N)<bt8SoftCount N root γ u z}
  have hG (root : Vertex N) : MeasurableSet (G root) :=
    measurableSet_lt measurable_const (bt8SoftCount_measurable N root γ u)
  have hF := fun root => bt10WitnessEvent_measurable N root γ u
  have hE (root : Vertex N) : MeasurableSet (E root) := by
    simpa only [E,Set.compl_ofPred] using (bt8Good_measurable N root γ u).compl
  have hsub := r7LoopEventMass_mono_ae N
    (fun root => {z | η*Real.sqrt (logSize N)<bt10DefectCount N root u z})
    (fun root => E root∪(F root∪G root)) (fun root => Eventually.of_forall (by
      intro ω t ht hz
      by_cases hg : bt8Good N root γ u (ω,t)
      · by_cases hw : (ω,t)∈bt10WitnessEvent N root γ u
        · exact Or.inr (Or.inl hw)
        · exact Or.inr (Or.inr (hz.trans_le (bt10_defect_count_le_contact N root γ u (ω,t) hg hw)))
      · exact Or.inl hg)) l r
  exact hsub.trans ((r7LoopEventMass_union_le N E (fun root => F root∪G root)
    hE (fun root => (hF root).union (hG root)) l r).trans
    (add_le_add le_rfl (r7LoopEventMass_union_le N F G hF hG l r)))

theorem bt10_conclusion (hWalk : WalkModelRegular) (γ u : ℝ)
    (hγ : 0<γ) (hmargin : 160*γ<1/20) (hu : 0≤u) : BT10Conclusion u := by
  intro H η hH hη l r hwin
  have hgood := bt8Good_failure_tendsto hWalk γ u H hγ (by linarith) hu hH l r hwin
  have hw := bt10_witness_tendsto hWalk γ u H hγ (by linarith) hu hH l r hwin
  have hs := bt8_conclusion hWalk γ u hγ hmargin hu H η hH hη l r hwin
  have ht := hgood.add (hw.add hs)
  simp only [add_zero] at ht
  exact tendsto_of_tendsto_of_tendsto_of_le_of_le' tendsto_const_nhds ht
    (Eventually.of_forall fun _ => bot_le)
    (Eventually.of_forall fun N => bt10_defect_event_bound N γ u η (l N) (r N))

end TorusCoverTime.Blocks.B
