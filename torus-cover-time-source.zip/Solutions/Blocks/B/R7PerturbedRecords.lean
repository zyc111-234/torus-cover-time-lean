import Solutions.Blocks.B.R7PerturbedUpperTail
import Solutions.Blocks.B.R7PerturbedDuration
import Solutions.Blocks.B.R7PositiveWordBounds

/-! Transfer the perturbed estimates to finite records and actual positive
endpoint words, with the intermediate returns retained. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B
theorem r7_perturbed_record_sqrt_upper (hWalk : WalkModelRegular) (γ : ℝ)
    (hγ : 0 < γ) (hγ1 : γ < 1) :
    ∀ᶠ q : ℝ in atTop, ∀ N : Size, ∀ c : Vertex N, ∀ m : ℕ, ∀ a b : Fin m → Vertex N,
      2*(r7PerturbedOuter q (q^γ)+1) < N.val →
      (∀ i, |periodicDistance (a i) c-r7PerturbedInner q (q^γ)| ≤ 2) →
      (∀ i, diskExteriorNeighbor N c (r7PerturbedOuter q (q^γ)) (b i)) →
      ∀ v Δ : ℝ, 0 ≤ v → (m:ℝ)*r7PerturbedWidth q (q^γ) ≤ v^2 → 0 ≤ Δ →
      2*r7PerturbedMeanConstant*Real.exp (-r7MeanExponent*q^γ)*v ≤ Δ →
      (exactExitRecordProductLaw N (torusDisk N c (r7PerturbedOuter q (q^γ))) m a b).real
        {p | v+Δ < Real.sqrt (recordProductOccupation N m a
          (fun z => diskHarmonicWeight N c (Real.exp (q+1)) z/g) p)} ≤
        2*Real.exp (-(r7PerturbedConcentrationConstant/4)*Δ^2/q^γ) := by
  filter_upwards [r7_perturbed_occupation_sqrt_upper hWalk γ hγ hγ1] with q hq
  intro N c m a b hsmall ha hb v Δ hv hmv hΔ hlo
  let U := fun z => diskHarmonicWeight N c (Real.exp (q+1)) z/g
  have hE : MeasurableSet {x : ℝ | v+Δ < Real.sqrt x} := measurableSet_lt measurable_const measurable_id.sqrt
  have hh := congrArg (fun μ : Measure ℝ => μ {x | v+Δ < Real.sqrt x})
    (exactExitRecordProduct_occupation_law N (torusDisk N c (r7PerturbedOuter q (q^γ))) m a b U)
  have hw : Measurable (fun ω : Fin m → WalkSample => ∑ i,
      weightedExitOccupation N (torusDisk N c (r7PerturbedOuter q (q^γ))) (a i) U (ω i)) :=
    Finset.measurable_sum _ fun i _ => (weightedExitOccupation_measurable N _ (a i) U).comp (measurable_pi_apply i)
  rw [Measure.map_apply (recordProductOccupation_measurable N m a U) hE,Measure.map_apply hw hE] at hh
  have he := congrArg ENNReal.toReal hh
  change (exactExitRecordProductLaw N (torusDisk N c (r7PerturbedOuter q (q^γ))) m a b).real _ =
    (exactExitProductLaw N (torusDisk N c (r7PerturbedOuter q (q^γ))) m a b).real
      {ω | v+Δ < Real.sqrt (harmonicExitBlockSum N c (Real.exp (q+1)) (r7PerturbedOuter q (q^γ)) m a ω)} at he
  exact he.le.trans (hq N c m a b hsmall ha hb v Δ hv hmv hΔ hlo)

theorem r7_perturbed_record_coarse_duration (hWalk : WalkModelRegular) (γ : ℝ)
    (hγ : 0 < γ) (hγ1 : γ < 1) :
    ∀ᶠ N : Size in atTop, ∀ c : Vertex N, ∀ m : ℕ, ∀ a b : Fin m → Vertex N, ∀ q : ℝ,
      (logSize N)^(16*γ) ≤ q → q ≤ logSize N-(logSize N)^(16*γ) → (m:ℝ) ≤ (logSize N)^4+1 →
      (∀ i, |periodicDistance (a i) c-r7PerturbedInner q (q^γ)| ≤ 2) →
      (∀ i, diskExteriorNeighbor N c (r7PerturbedOuter q (q^γ)) (b i)) →
      exactExitRecordProductLaw N (torusDisk N c (r7PerturbedOuter q (q^γ))) m a b {p |
        (m:ℝ)*Real.exp (2*logSize N-(logSize N)^(16*γ)) < recordsDuration m p} ≤
        ENNReal.ofReal (Real.exp (-Real.exp ((logSize N)^(16*γ)/2))) := by
  filter_upwards [r7_perturbed_coarse_duration hWalk γ hγ hγ1] with N hN
  intro c m a b q hq hqL hm ha hb
  have hbound : exactExitRecordProductLaw N (torusDisk N c (r7PerturbedOuter q (q^γ))) m a b
      {p | ∃ i, Real.exp (2*logSize N-(logSize N)^(16*γ)) < excursionRecordDuration (p i)} ≤
        ENNReal.ofReal (Real.exp (-Real.exp ((logSize N)^(16*γ)/2))) := by
    rw [exactExitRecordProduct_duration_event]
    exact hN c m a b q hq hqL hm ha hb
  exact (measure_mono (fun p hp => record_duration_sum_tail p _ (by simpa [recordsDuration] using hp))).trans hbound

end TorusCoverTime.Blocks.B
