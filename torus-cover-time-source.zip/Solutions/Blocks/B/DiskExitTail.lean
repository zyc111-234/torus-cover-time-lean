import Solutions.Blocks.B.DiskBarrier
import Solutions.Blocks.B.DiskCardinality

/-! Actual disk exit duration bounds at the radius-squared scale. Endpoint conditioning
retains its exact probability cost, pending the separate polynomial exit lower bound. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

lemma disk_survival_tail (hWalk : WalkModelRegular)
    (N : Size) (y : Vertex N) (R : ℝ) (hR : 0 < R)
    (hsmall : 2*(R+1) < N.val) (a : Vertex N) (t : ℝ) (ht : 0 ≤ t) :
    (walkLaw {ω | ∀ x ∈ Finset.univ \ torusDisk N y R,
      ENNReal.ofReal t < hittingTime N a ω x}).toReal ≤
        (2*R+1)^2 * Real.exp (-t/(R+1)^2) := by
  let D := torusDisk N y R
  let A := Finset.univ \ D
  have hA : A ≠ Finset.univ := by
    obtain ⟨x, hx⟩ := torusDisk_nonempty N y R hR
    intro heq
    have hm : x ∈ A := heq ▸ Finset.mem_univ x
    exact (Finset.mem_sdiff.mp hm).2 hx
  have hc : Finset.univ \ A = D := by ext x; simp [A]
  have hreal := survival_point_le_principal hWalk N A hA a t ht
  rw [hc] at hreal
  apply hreal.trans
  apply mul_le_mul (torusDisk_card_le N y R hR.le) ?_ (Real.exp_pos _).le (by positivity)
  apply Real.exp_le_exp.mpr
  have hr := mul_le_mul_of_nonneg_right (killedEigenvalue_disk_bound N y R hR hsmall) ht
  change 1/(R+1)^2 * t ≤ killedEigenvalue N A * t at hr
  calc
    _ ≤ -(1/(R+1)^2 * t) := by linarith
    _ = _ := by ring

lemma diskExitDuration_tail (hWalk : WalkModelRegular)
    (N : Size) (y : Vertex N) (R : ℝ) (hR : 0 < R)
    (hsmall : 2*(R+1) < N.val) (a : Vertex N) (t : ℝ) (ht : 0 ≤ t) :
    walkLaw {ω | t < finiteExitDuration N (torusDisk N y R) a ω} ≤
      ENNReal.ofReal ((2*R+1)^2 * Real.exp (-t/(R+1)^2)) := by
  apply (ENNReal.le_ofReal_iff_toReal_le (measure_ne_top walkLaw _) (by positivity)).mpr
  exact (ENNReal.toReal_mono (measure_ne_top walkLaw _)
    (finiteExitDuration_tail_le_survival hWalk N (torusDisk N y R) a t ht)).trans
      (disk_survival_tail hWalk N y R hR hsmall a t ht)

lemma diskExitDuration_tail_quadratic (hWalk : WalkModelRegular)
    (N : Size) (y : Vertex N) (R : ℝ) (hR : 1 ≤ R)
    (hsmall : 2*(R+1) < N.val) (a : Vertex N) (t : ℝ) (ht : 0 ≤ t) :
    walkLaw {ω | t < finiteExitDuration N (torusDisk N y R) a ω} ≤
      ENNReal.ofReal (9*R^2 * Real.exp (-t/(4*R^2))) := by
  apply (diskExitDuration_tail hWalk N y R (by linarith) hsmall a t ht).trans
  apply ENNReal.ofReal_le_ofReal
  apply mul_le_mul ?_ ?_ (Real.exp_pos _).le (by positivity)
  · nlinarith [sq_nonneg (R-1)]
  · apply Real.exp_le_exp.mpr
    have hd : (R+1)^2 ≤ 4*R^2 := by nlinarith [sq_nonneg (R-1)]
    have hb := div_le_div_of_nonneg_left ht (show (0 : ℝ) < (R+1)^2 by positivity) hd
    simpa only [neg_div] using neg_le_neg hb

lemma exactExitLaw_bound_of_probability_lower (N : Size) (D : Finset (Vertex N))
    (a b : Vertex N) (δ U : ℝ) (hδ : 0 < δ)
    (hexit : ENNReal.ofReal δ ≤ walkLaw (exitsThrough N D a b))
    (S : Set WalkSample) (hS : walkLaw S ≤ ENNReal.ofReal U) :
    exactExitLaw N D a b S ≤ ENNReal.ofReal (U/δ) := by
  rw [exactExitLaw, cond_apply (measurableSet_exitsThrough N D a b)]
  have hupper : walkLaw (exitsThrough N D a b ∩ S) ≤ ENNReal.ofReal U :=
    (measure_mono Set.inter_subset_right).trans hS
  have h := mul_le_mul' (ENNReal.inv_le_inv.mpr hexit) hupper
  apply h.trans_eq
  rw [ENNReal.ofReal_div_of_pos hδ, div_eq_mul_inv, mul_comm]

lemma diskExitDuration_conditioned_tail (hWalk : WalkModelRegular)
    (N : Size) (y : Vertex N) (R : ℝ) (hR : 1 ≤ R)
    (hsmall : 2*(R+1) < N.val) (a b : Vertex N) (t δ : ℝ) (ht : 0 ≤ t) (hδ : 0 < δ)
    (hexit : ENNReal.ofReal δ ≤ walkLaw (exitsThrough N (torusDisk N y R) a b)) :
    exactExitLaw N (torusDisk N y R) a b
      {ω | t < finiteExitDuration N (torusDisk N y R) a ω} ≤
        ENNReal.ofReal (9*R^2/δ * Real.exp (-t/(4*R^2))) := by
  have h := exactExitLaw_bound_of_probability_lower N (torusDisk N y R) a b δ
    (9*R^2 * Real.exp (-t/(4*R^2))) hδ hexit _
    (diskExitDuration_tail_quadratic hWalk N y R hR hsmall a t ht)
  convert h using 2; ring

lemma r6_disk_duration_of_endpoint_lower (hWalk : WalkModelRegular)
    (N : Size) (y : Vertex N) (R : ℝ) (hR : 1 ≤ R)
    (hsmall : 2*(R+1) < N.val) (a b : Vertex N) (t c C : ℝ) (ht : 0 ≤ t) (hc : 0 < c)
    (hexit : ENNReal.ofReal (c*R^(-C)) ≤ walkLaw (exitsThrough N (torusDisk N y R) a b)) :
    exactExitLaw N (torusDisk N y R) a b
      {ω | t < finiteExitDuration N (torusDisk N y R) a ω} ≤
        ENNReal.ofReal ((9/c)*R^(C+2) * Real.exp (-t/(4*R^2))) := by
  have hRp : 0 < R := by linarith
  have hδ := mul_pos hc (Real.rpow_pos_of_pos hRp (-C))
  have h := diskExitDuration_conditioned_tail hWalk N y R hR hsmall a b t
    (c*R^(-C)) ht hδ hexit
  have heq : 9*R^2/(c*R^(-C)) = (9/c)*R^(C+2) := by
    rw [Real.rpow_add hRp, Real.rpow_neg hRp.le, Real.rpow_two]
    field_simp
  simpa only [heq] using h

end TorusCoverTime.Blocks.B
