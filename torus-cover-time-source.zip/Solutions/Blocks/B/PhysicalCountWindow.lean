import Solutions.Blocks.B.PhysicalWordWindow
import Solutions.Blocks.B.TraversalCountPartition

/-! Exact fixed-count physical windows, with boundary times removed only as null sets. -/
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B


def physicalCountWindow (N : Size) (I O : Finset (Vertex N)) (root : Vertex N) (m : ℕ)
    (F : WalkSample × ℝ → ℝ≥0∞) (l r : ℝ) : ℝ≥0∞ :=
  ∫⁻ ω, ∫⁻ t in Ioi (0:ℝ), if completedTraversalCount N I O root ω t = m ∧
    walk N root ω t = root ∧ t ∈ Icc l r then F (ω,t) else 0 ∂volume ∂walkLaw

theorem physicalCountWindow_eq_slice (N : Size) (I O : Finset (Vertex N)) (hIO : I ⊆ O)
    (hI : I.Nonempty) (root : Vertex N) (hr : root ∉ O) (m : ℕ)
    (F : WalkSample × ℝ → ℝ≥0∞) (l r : ℝ) :
    physicalCountWindow N I O root m F l r =
      ∫⁻ ω, ∫⁻ t in Ioi (adaptiveExitTime N (alternatingDomain N I O) root (2*m) ω),
        if t < adaptiveExitTime N (alternatingDomain N I O) root (2*m+1) ω ∧
          walk N root ω t = root ∧ t ∈ Icc l r then F (ω,t) else 0 ∂volume ∂walkLaw := by
  let G := fun z : WalkSample × ℝ => if z.2 ∈ Icc l r then F z else 0
  have hs (ω : WalkSample) :
      (∫⁻ t in Ioi (0:ℝ), traversalSliceTest N I O root m G (ω,t)) =
      ∫⁻ t in Ioi (adaptiveExitTime N (alternatingDomain N I O) root (2*m) ω),
        if t < adaptiveExitTime N (alternatingDomain N I O) root (2*m+1) ω ∧
          walk N root ω t = root ∧ t ∈ Icc l r then F (ω,t) else 0 := by
    rw [traversalSliceTest_lintegral]
    apply lintegral_congr
    intro t
    dsimp only [G]
    split_ifs <;> simp_all
  simp_rw [← hs]
  apply lintegral_congr_ae
  filter_upwards [completedTraversalCount_loop_iff_ae N I O hIO hI root hr] with ω hω
  have hne : ∀ᵐ t : ℝ ∂(volume : Measure ℝ),
      t ≠ adaptiveExitTime N (alternatingDomain N I O) root (2*m) ω := ae_iff.mpr (by simp)
  apply lintegral_congr_ae
  filter_upwards [ae_restrict_mem (measurableSet_Ioi (a := (0:ℝ))),
    (Measure.absolutelyContinuous_restrict (μ := volume) (s := Ioi (0:ℝ))).ae_le hne] with t ht hne
  by_cases hloop : walk N root ω t = root
  · have hi : completedTraversalCount N I O root ω t = m ↔
        adaptiveExitTime N (alternatingDomain N I O) root (2*m) ω < t ∧
        t < adaptiveExitTime N (alternatingDomain N I O) root (2*m+1) ω := by
      rw [hω t ht.le hloop m]
      exact and_congr_left fun _ => ⟨fun h => lt_of_le_of_ne h (Ne.symm hne),fun h => h.le⟩
    simp only [traversalSliceTest,G,hloop,and_true,← hi]
    split_ifs <;> simp_all
  · simp [traversalSliceTest,hloop]

theorem physicalCountWindow_mono (N : Size) (I O : Finset (Vertex N)) (root : Vertex N) (m : ℕ)
    (F G : WalkSample × ℝ → ℝ≥0∞) (hFG : ∀ z, F z ≤ G z) (l r : ℝ) :
    physicalCountWindow N I O root m F l r ≤ physicalCountWindow N I O root m G l r := by
  apply lintegral_mono
  intro ω
  apply lintegral_mono
  intro t
  dsimp only
  split_ifs
  · exact hFG _
  · rfl


end TorusCoverTime.Blocks.B
