import Solutions.Blocks.B.R6KernelEstimates

/-! R6.7 in the coarse window, including arbitrary injective selections
from a larger collection of actual specified-exit blocks. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

theorem r6_selected_block_occupation_tail (hWalk : WalkModelRegular)
    (γ : ℝ) (hγ : 0 < γ) (hγ1 : γ ≤ 1) :
    ∀ᶠ q : ℝ in atTop, ∀ N : Size, ∀ c : Vertex N, ∀ n m : ℕ,
      ∀ a b : Fin n → Vertex N, ∀ e : Fin m → Fin n, Function.Injective e →
      2*(Real.exp (q+2*q^γ)+1) < N.val →
      (∀ i, |periodicDistance (a i) c-Real.exp (q+q^γ)| ≤ 2) →
      (∀ i, diskExteriorNeighbor N c (Real.exp (q+2*q^γ)) (b i)) →
      ∀ x ∈ torusDisk N c (Real.exp q), ∀ u : ℝ,
      (exactExitProductLaw N (torusDisk N c (Real.exp (q+2*q^γ))) n a b).real
        {ω | exitBlockOccupation N (torusDisk N c (Real.exp (q+2*q^γ))) n a ω x ≤ u} ≤
          Real.exp (u-(m:ℝ)*(q^γ/(8*diskHarnackConstant*q))/2) := by
  filter_upwards [r6_endpoint_probability_pos γ hγ, r6_conditioned_point_hit_lower hWalk γ hγ hγ1]
    with q hpos hhit
  intro N c n m a b e he hsmall ha hb x hx u
  apply exitBlock_occupation_lower_tail_selected hWalk N _ n m a b e he
    (fun i => (hpos N c (a i) (b i) hsmall (ha i) (hb i)).ne') x _ u
  intro i
  rw [← visitsBeforeExit_probability_eq_physical hWalk N _ (a (e i)) (b (e i)) x]
  exact hhit N c (a (e i)) (b (e i)) x hsmall (ha (e i)) (hb (e i)) hx

theorem r6_coarse_excessive_count (hWalk : WalkModelRegular)
    (γ : ℝ) (hγ : 0 < γ) (hγ1 : γ ≤ 1) :
    ∀ᶠ N : Size in atTop, ∀ c : Vertex N, ∀ n m : ℕ,
      ∀ a b : Fin n → Vertex N, ∀ e : Fin m → Fin n, Function.Injective e →
      ∀ q : ℝ, (logSize N)^(16*γ) ≤ q → q ≤ logSize N-(logSize N)^(16*γ) →
      (logSize N)^4 ≤ (m:ℝ) →
      (∀ i, |periodicDistance (a i) c-Real.exp (q+q^γ)| ≤ 2) →
      (∀ i, diskExteriorNeighbor N c (Real.exp (q+2*q^γ)) (b i)) →
      ∀ x ∈ torusDisk N c (Real.exp q), ∀ u : ℝ,
      (exactExitProductLaw N (torusDisk N c (Real.exp (q+2*q^γ))) n a b).real
        {ω | exitBlockOccupation N (torusDisk N c (Real.exp (q+2*q^γ))) n a ω x ≤ u} ≤
          Real.exp (u-(logSize N)^3/(16*diskHarnackConstant)) := by
  have hH : 0 < diskHarnackConstant := zero_lt_one.trans diskHarnackConstant_gt_one
  obtain ⟨q0,hq0⟩ := eventually_atTop.mp (r6_selected_block_occupation_tail hWalk γ hγ hγ1)
  have hQ := (tendsto_rpow_atTop (by positivity : 0 < 16*γ)).comp blockB_logSize_tendsto
  filter_upwards [r6_disk_radius_embedding γ hγ, hQ.eventually_ge_atTop (max 1 q0)]
    with N hsmall hQ
  intro c n m a b e he q hq hqL hm ha hb x hx u
  have hq1 : 1 ≤ q := (le_max_left 1 q0).trans (hQ.trans hq)
  have hq' : q0 ≤ q := (le_max_right 1 q0).trans (hQ.trans hq)
  have hqnon : 0 ≤ q := by linarith
  have hqL' : q ≤ logSize N := hqL.trans (sub_le_self _ (Real.rpow_nonneg (logSize_pos N).le _))
  have hw : 1 ≤ q^γ := Real.one_le_rpow hq1 hγ.le
  have ht := hq0 q hq' N c n m a b e he (hsmall q hqnon hqL) ha hb x hx u
  have hexp := r6_occupation_count_exponent (logSize N) q (q^γ)
    (1/(8*diskHarnackConstant)) u m (logSize_pos N) (by linarith) hqL' hw (by positivity) hm
  have hid : (1/(8*diskHarnackConstant))*(q^γ)/q = q^γ/(8*diskHarnackConstant*q) := by ring
  have hid' : (1/(8*diskHarnackConstant))*(logSize N)^3/2 =
      (logSize N)^3/(16*diskHarnackConstant) := by ring
  rw [hid,hid'] at hexp
  exact ht.trans hexp

theorem r6_coarse_softness_count_bound (hWalk : WalkModelRegular)
    (γ : ℝ) (hγ : 0 < γ) (hγ1 : γ ≤ 1) :
    ∀ᶠ N : Size in atTop, ∀ c : Vertex N, ∀ n m : ℕ,
      ∀ a b : Fin n → Vertex N, ∀ e : Fin m → Fin n, Function.Injective e →
      ∀ q : ℝ, (logSize N)^(16*γ) ≤ q → q ≤ logSize N-(logSize N)^(16*γ) →
      (logSize N)^4 ≤ (m:ℝ) →
      (∀ i, |periodicDistance (a i) c-Real.exp (q+q^γ)| ≤ 2) →
      (∀ i, diskExteriorNeighbor N c (Real.exp (q+2*q^γ)) (b i)) →
      ∀ u : ℝ,
      (exactExitProductLaw N (torusDisk N c (Real.exp (q+2*q^γ))) n a b).real
        (exitBlockSoftness N (torusDisk N c (Real.exp (q+2*q^γ)))
          (torusDisk N c (Real.exp q)) n a u) ≤
          ((torusDisk N c (Real.exp q)).card:ℝ)*
            Real.exp (u-(logSize N)^3/(16*diskHarnackConstant)) := by
  filter_upwards [r6_coarse_excessive_count hWalk γ hγ hγ1] with N hN
  intro c n m a b e he q hq hqL hm ha hb u
  have (i : Fin n) : IsZeroOrProbabilityMeasure
      (exactExitLaw N (torusDisk N c (Real.exp (q+2*q^γ))) (a i) (b i)) := by
    unfold exactExitLaw
    infer_instance
  let μ := exactExitProductLaw N (torusDisk N c (Real.exp (q+2*q^γ))) n a b
  have : IsFiniteMeasure μ := by unfold μ exactExitProductLaw; infer_instance
  let E := fun x => {ω | exitBlockOccupation N (torusDisk N c (Real.exp (q+2*q^γ))) n a ω x ≤ u}
  have hu : μ.real (exitBlockSoftness N (torusDisk N c (Real.exp (q+2*q^γ)))
      (torusDisk N c (Real.exp q)) n a u) ≤ ∑ x ∈ torusDisk N c (Real.exp q), μ.real (E x) := by
    have hset : exitBlockSoftness N (torusDisk N c (Real.exp (q+2*q^γ)))
        (torusDisk N c (Real.exp q)) n a u = ⋃ x ∈ torusDisk N c (Real.exp q), E x := by
      ext ω
      simp only [exitBlockSoftness, Set.mem_ofPred_eq, Set.mem_iUnion, E, exists_prop]
    rw [hset]
    exact measureReal_biUnion_finset_le (torusDisk N c (Real.exp q)) E
  exact hu.trans ((Finset.sum_le_sum (fun x hx => hN c n m a b e he q hq hqL hm ha hb x hx u)).trans_eq
    (by simp))

theorem r6_coarse_unconditioned_duration (hWalk : WalkModelRegular)
    (γ : ℝ) (hγ : 0 < γ) (hγ1 : γ ≤ 1) :
    ∀ᶠ N : Size in atTop, ∀ c : Vertex N, ∀ m : ℕ,
      ∀ a b : Fin m → Vertex N, ∀ q : ℝ,
      (logSize N)^(16*γ) ≤ q → q ≤ logSize N-(logSize N)^(16*γ) →
      (m:ℝ) ≤ (logSize N)^4+1 →
      (∀ i, |periodicDistance (a i) c-Real.exp (q+q^γ)| ≤ 2) →
      (∀ i, diskExteriorNeighbor N c (Real.exp (q+2*q^γ)) (b i)) →
      exactExitProductLaw N (torusDisk N c (Real.exp (q+2*q^γ))) m a b {ω | ∃ i,
        Real.exp (2*logSize N-(logSize N)^(16*γ)) <
          finiteExitDuration N (torusDisk N c (Real.exp (q+2*q^γ))) (a i) (ω i)} ≤
            ENNReal.ofReal (Real.exp (-Real.exp ((logSize N)^(16*γ)/2))) := by
  let C := max 1 (max (9/diskExitLowerConstant) ((diskExitPower:ℝ)+2))
  have hC : 0 < C := lt_of_lt_of_le (by norm_num : (0:ℝ)<1) (le_max_left _ _)
  have hcE := diskExitLowerConstant_pos
  have hc : (0:ℝ) < 1/8 := by norm_num
  obtain ⟨qE,hqE⟩ := eventually_atTop.mp (r6_endpoint_probability_lower γ hγ)
  have hQ := (tendsto_rpow_atTop (by positivity : 0 < 16*γ)).comp blockB_logSize_tendsto
  filter_upwards [r6_disk_radius_embedding γ hγ, hQ.eventually_ge_atTop (max 0 qE),
    blockB_logSize_tendsto.eventually (r6_duration_prefactor_superexponential γ C (1/8) hγ hγ1 hC hc)]
      with N hsmall hQ hscalar
  intro c m a b q hq hqL hm ha hb
  have hq0 : 0 ≤ q := (le_max_left 0 qE).trans (hQ.trans hq)
  have hqE' : qE ≤ q := (le_max_right 0 qE).trans (hQ.trans hq)
  let R := Real.exp (q+2*q^γ)
  let d := Real.exp (2*logSize N-(logSize N)^(16*γ))
  have hR : 1 ≤ R := Real.one_le_exp_iff.mpr (by positivity)
  have hexit (i : Fin m) := hqE q hqE' N c (a i) (b i) (hsmall q hq0 hqL) (ha i) (hb i)
  have hpos (i : Fin m) : walkLaw (exitsThrough N (torusDisk N c R) (a i) (b i)) ≠ 0 :=
    ((ENNReal.ofReal_pos.mpr (mul_pos hcE (Real.rpow_pos_of_pos (Real.exp_pos _) _))).trans_le (hexit i)).ne'
  have htail (i : Fin m) := r6_disk_conditioned_tail_constants hWalk N c R hR
    (hsmall q hq0 hqL) (a i) (b i) d diskExitLowerConstant diskExitPower (1/8) C
    (Real.exp_pos _).le hcE ((le_max_left _ _).trans (le_max_right _ _))
    ((le_max_right _ _).trans (le_max_right _ _)) (by norm_num) (hexit i)
  have hu := exactExit_duration_union_bound N (torusDisk N c R) m a b hpos d
    (ENNReal.ofReal (C*R^C*Real.exp (-(1/8)*d/R^2))) htail
  apply hu.trans
  rw [← ENNReal.ofReal_natCast m, ← ENNReal.ofReal_mul (Nat.cast_nonneg m)]
  apply ENNReal.ofReal_le_ofReal
  have hdiv : (m:ℝ)*(C*R^C*Real.exp (-(1/8)*d/R^2)) ≤
      C*(m:ℝ)*R^C/(1/8:ℝ)^m*Real.exp (-(1/8)*d/R^2) := by
    have hp : (1/8:ℝ)^m ≤ 1 := pow_le_one₀ (by norm_num) (by norm_num)
    have hn : 0 ≤ C*(m:ℝ)*R^C*Real.exp (-(1/8)*d/R^2) := by positivity
    have ht := mul_le_mul_of_nonneg_left hp hn
    have hd := (le_div_iff₀ (pow_pos hc m)).mpr (by simpa only [mul_one] using ht)
    calc
      _ = C*(m:ℝ)*R^C*Real.exp (-(1/8)*d/R^2) := by ring
      _ ≤ (C*(m:ℝ)*R^C*Real.exp (-(1/8)*d/R^2))/(1/8:ℝ)^m := hd
      _ = _ := by ring
  exact hdiv.trans (hscalar q m hq0 hqL hm)

end TorusCoverTime.Blocks.B
