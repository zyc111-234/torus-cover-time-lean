import Solutions.Blocks.B.DirichletClockNormalization
import Solutions.Blocks.B.BridgeDensityNormalization
import Solutions.Blocks.B.BridgeRegressionError

/-! The regression bound is applied to the original exit weights and
the same LS-normalized C4 field, retaining its actual terminal value. -/

noncomputable section
open MeasureTheory ProbabilityTheory
open scoped BigOperators
namespace TorusCoverTime.Blocks.B

def dirichletLSHarmonicAverage (N : Size) (root : Vertex N) (D E : Finset (Vertex N))
    (ξ : FiniteFieldSample N) (x : Vertex N) : ℝ :=
  ∑ z, exitHarmonic N D z x*dirichletFieldLS N root E ξ z

theorem dirichlet_LS_harmonic_average (N : Size) (root : Vertex N) (D E : Finset (Vertex N))
    (hDE : D⊆E) (hroot : root∉E) (ξ : FiniteFieldSample N) (x : Vertex N) :
    dirichletLSHarmonicAverage N root D E ξ x = dirichletFieldLS N root E ξ x-dirichletFieldLS N root D ξ x := by
  unfold dirichletLSHarmonicAverage dirichletFieldLS
  simp_rw [← mul_div_assoc]
  rw [← Finset.sum_div,dirichlet_harmonic_average N root D E hDE hroot ξ x]
  ring

def dirichletLSClockPath (N : Size) (root : Vertex N) (n : ℕ)
    (D : Fin (n+1) → Finset (Vertex N)) (hD : Monotone D) (hroot : ∀ i, root∉D i)
    (hzero : D 0=∅) (x : Vertex N) : GaussianClockPath (finiteFieldLaw N) n :=
  (dirichletClockPath N root n D hD hroot hzero x).scale (1/Real.sqrt (2*g))

theorem dirichlet_LS_harmonic_bridge {n : ℕ} (N : Size) (root : Vertex N)
    (D : Fin (n+1) → Finset (Vertex N)) (hD : Monotone D) (hroot : ∀ i, root∉D i)
    (hzero : D 0=∅) (x : Vertex N) (ξ : FiniteFieldSample N) (i : Fin (n+1)) :
    dirichletLSHarmonicAverage N root (D i) (D (Fin.last n)) ξ x =
      (1-dirichletClockLS N root (D i) x/dirichletClockLS N root (D (Fin.last n)) x)*dirichletFieldLS N root (D (Fin.last n)) ξ x-
        (dirichletLSClockPath N root n D hD hroot hzero x).bridge ξ i := by
  rw [dirichlet_LS_harmonic_average N root _ _ (hD (Fin.le_last i)) (hroot _) ξ x]
  dsimp only [GaussianClockPath.bridge,dirichletLSClockPath]
  rw [dirichlet_normalized_path,dirichlet_normalized_path,dirichlet_normalized_clock,dirichlet_normalized_clock]
  ring

theorem dirichlet_LS_harmonic_regression_error {n : ℕ} (N : Size) (root : Vertex N)
    (D : Fin (n+1) → Finset (Vertex N)) (hD : Monotone D) (hroot : ∀ i, root∉D i)
    (hzero : D 0=∅) (x : Vertex N) (i : Fin (n+1)) (q C : ℝ) (hC : 0≤C) (hL : 1≤logSize N)
    (hV : 0<dirichletClockLS N root (D (Fin.last n)) x)
    (hi : |dirichletClockLS N root (D i) x-q/2|≤C)
    (hglobal : |dirichletClockLS N root (D (Fin.last n)) x-logSize N/2|≤C)
    (ξ : FiniteFieldSample N) :
    |dirichletLSHarmonicAverage N root (D i) (D (Fin.last n)) ξ x-harmonicExtremeCenter N+
      Real.sqrt 2*q+(dirichletLSClockPath N root n D hD hroot hzero x).bridge ξ i| ≤
      4*Real.sqrt 2*C+Real.log (logSize N)+|dirichletFieldLS N root (D (Fin.last n)) ξ x-harmonicExtremeCenter N| := by
  let W := dirichletLSClockPath N root n D hD hroot hzero x
  have hv : 0≤dirichletClockLS N root (D i) x := by
    simpa only [W,dirichletLSClockPath,dirichlet_normalized_clock] using W.clock_nonneg i
  have hvV : dirichletClockLS N root (D i) x≤dirichletClockLS N root (D (Fin.last n)) x := by
    simpa only [W,dirichletLSClockPath,dirichlet_normalized_clock] using W.clock_mono (Fin.le_last i)
  have he := bridge_regression_error q (logSize N) _ _ C (harmonicExtremeCenter N)
    (dirichletFieldLS N root (D (Fin.last n)) ξ x-harmonicExtremeCenter N) hV hv hvV hC hi hglobal
  rw [dirichlet_LS_harmonic_bridge N root D hD hroot hzero x ξ i]
  have hid : (1-dirichletClockLS N root (D i) x/dirichletClockLS N root (D (Fin.last n)) x)*dirichletFieldLS N root (D (Fin.last n)) ξ x-
      W.bridge ξ i-harmonicExtremeCenter N+Real.sqrt 2*q+W.bridge ξ i =
      Real.sqrt 2*q-(dirichletClockLS N root (D i) x/dirichletClockLS N root (D (Fin.last n)) x)*harmonicExtremeCenter N+
      (1-dirichletClockLS N root (D i) x/dirichletClockLS N root (D (Fin.last n)) x)*
        (dirichletFieldLS N root (D (Fin.last n)) ξ x-harmonicExtremeCenter N) := by ring
  change |(1-_)*_-W.bridge ξ i-_+_+W.bridge ξ i| ≤ _
  rw [hid]
  exact he.trans (add_le_add (add_le_add le_rfl (harmonicExtremeCenter_log_error N hL)) le_rfl)

end TorusCoverTime.Blocks.B
