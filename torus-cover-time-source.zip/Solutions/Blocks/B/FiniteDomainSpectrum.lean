import Solutions.Blocks.B.KilledSpectral
import Solutions.Blocks.B.GreenStructure

/-! A finite-domain Dirichlet rate bound from the actual torus Green kernel.
No strong Markov or exit-time estimate is assumed. -/

noncomputable section
open Classical
open scoped BigOperators RealInnerProductSpace
namespace TorusCoverTime.Blocks.B

lemma sum_neg_generator_zero (N : Size) (f : Vertex N → ℝ) :
    (∑ x : Vertex N, -generator N f x) = 0 := by
  have h := dirichletPairing_symm N (fun _ => 1) f
  simpa only [dirichletPairing, one_mul, generator_const, neg_zero, mul_zero,
    Finset.sum_const_zero] using h

lemma green_inverse_generator (N : Size) (f : Vertex N → ℝ) (x : Vertex N) :
    greenOperator N (fun y => -generator N f y) x = f x - spatialMean N f := by
  calc
    _ = dirichletPairing N (fun y => greenKernel N y x) f := by
      simp only [greenOperator, dirichletPairing, greenKernel_symm N x]
    _ = dirichletPairing N f (fun y => greenKernel N y x) := dirichletPairing_symm N _ _
    _ = _ := by
      simp only [dirichletPairing, greenKernel_generator, mul_sub, mul_ite,
        mul_one, mul_zero, Finset.sum_sub_distrib]
      simp only [Finset.sum_ite_eq', Finset.mem_univ, if_true, ← Finset.sum_mul, spatialMean]
      ring

lemma oscillation_le_green_source (N : Size) (f : Vertex N → ℝ) (x z : Vertex N) :
    |f x - f z| ≤ 2 * greenDiagonal N * ∑ y : Vertex N, |-generator N f y| := by
  have hid : f x - f z = ∑ y : Vertex N,
      (greenKernel N x y - greenKernel N z y) * (-generator N f y) := by
    simp only [sub_mul, Finset.sum_sub_distrib]
    change f x - f z = greenOperator N _ x - greenOperator N _ z
    rw [green_inverse_generator, green_inverse_generator]
    ring
  rw [hid, Finset.mul_sum]
  apply (Finset.abs_sum_le_sum_abs _ _).trans
  apply Finset.sum_le_sum
  intro y _
  rw [abs_mul]
  apply mul_le_mul_of_nonneg_right _ (abs_nonneg _)
  have h := (abs_sub (greenKernel N x y) (greenKernel N z y)).trans
    (add_le_add (abs_greenKernel_le_diagonal N x y) (abs_greenKernel_le_diagonal N z y))
  linarith

lemma principal_generator_abs_sum (N : Size) (A : Finset (Vertex N)) (hA : A ≠ Finset.univ) :
    (∑ y : Vertex N, |-generator N (principalMode N A) y|) =
      2 * killedEigenvalue N A * ∑ y : Vertex N, principalMode N A y := by
  have hf := principalMode_valid N A hA
  have hlam := killedEigenvalue_nonneg N A hA
  have hterm (y : Vertex N) : |-generator N (principalMode N A) y| =
      2 * killedEigenvalue N A * principalMode N A y - (-generator N (principalMode N A) y) := by
    by_cases hy : y ∈ A
    · have hg : 0 ≤ generator N (principalMode N A) y := by
        unfold generator
        apply mul_nonneg (by norm_num)
        apply Finset.sum_nonneg
        intro d _
        rw [hf.1 y hy, sub_zero]
        exact hf.2.2.1 _
      rw [abs_of_nonpos (neg_nonpos.mpr hg), hf.1 y hy]
      ring
    · rw [hf.2.2.2 y hy, abs_of_nonneg (mul_nonneg hlam (hf.2.2.1 y))]
      ring
  simp only [hterm, Finset.sum_sub_distrib, ← Finset.mul_sum, sum_neg_generator_zero, sub_zero]

lemma killedEigenvalue_domain_bound (N : Size) (A : Finset (Vertex N))
    (hne : A.Nonempty) (hA : A ≠ Finset.univ) :
    1 ≤ 4 * greenDiagonal N * ((Finset.univ \ A).card : ℝ) * killedEigenvalue N A := by
  have hf := principalMode_valid N A hA
  obtain ⟨x, _, hx⟩ := Finset.exists_max_image (Finset.univ : Finset (Vertex N))
    (principalMode N A) Finset.univ_nonempty
  have hmax (y : Vertex N) : principalMode N A y ≤ principalMode N A x := hx y (Finset.mem_univ y)
  have hxpos : 0 < principalMode N A x := by
    have hsum : (∑ y : Vertex N, principalMode N A y) = vertexCount N :=
      (div_eq_one_iff_eq (vertexCount_pos N).ne').mp hf.2.1
    by_contra hxpos
    have hall : ∑ y : Vertex N, principalMode N A y ≤ 0 :=
      Finset.sum_nonpos (fun y _ => (hmax y).trans (le_of_not_gt hxpos))
    rw [hsum] at hall
    exact (vertexCount_pos N).not_ge hall
  obtain ⟨z, hz⟩ := hne
  have hb := oscillation_le_green_source N (principalMode N A) x z
  rw [hf.1 z hz, sub_zero, abs_of_pos hxpos, principal_generator_abs_sum N A hA] at hb
  have hsum : (∑ y : Vertex N, principalMode N A y) ≤
      ((Finset.univ \ A).card : ℝ) * principalMode N A x := by
    have heq : (∑ y : Vertex N, principalMode N A y) =
        ∑ y ∈ Finset.univ \ A, principalMode N A y := by
      symm
      apply Finset.sum_subset (Finset.subset_univ _)
      intro y _ hy
      exact hf.1 y (by simpa using hy)
    rw [heq]
    calc
      _ ≤ ∑ _y ∈ Finset.univ \ A, principalMode N A x := Finset.sum_le_sum (fun y _ => hmax y)
      _ = _ := by simp
  have hm := mul_le_mul_of_nonneg_left hsum
    (show 0 ≤ 4 * greenDiagonal N * killedEigenvalue N A by
      exact mul_nonneg (mul_nonneg (by norm_num) (greenDiagonal_pos N).le)
        (killedEigenvalue_nonneg N A hA))
  apply (mul_le_mul_iff_right₀ hxpos).mp
  nlinarith [hb, hm]

lemma killedBasis_squareSum (N : Size) (A : Finset (Vertex N))
    (i : Fin (Module.finrank ℝ (KilledSpace N A))) :
    squareSum N (killedValue (killedBasis N A i)) = 1 := by
  rw [show squareSum N (killedValue (killedBasis N A i)) =
      ⟪killedBasis N A i, killedBasis N A i⟫ by simp only [squareSum, killed_inner, pow_two]]
  rw [real_inner_self_eq_norm_sq, (killedBasis N A).orthonormal.1 i]
  norm_num

lemma killedBasis_energy (N : Size) (A : Finset (Vertex N))
    (i : Fin (Module.finrank ℝ (KilledSpace N A))) :
    energy N (killedValue (killedBasis N A i)) = killedModeRate N A i := by
  calc
    _ = killedModeRate N A i * squareSum N (killedValue (killedBasis N A i)) := by
      rw [energy, squareSum, Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro x _
      by_cases hx : x ∈ A
      · rw [killedValue_vanishes (killedBasis N A i) x hx]
        ring
      · rw [killedBasis_generator N A i x hx]
        ring
    _ = _ := by rw [killedBasis_squareSum, mul_one]

lemma killedModeRate_ge_principal (N : Size) (A : Finset (Vertex N)) (hA : A ≠ Finset.univ)
    (i : Fin (Module.finrank ℝ (KilledSpace N A))) :
    killedEigenvalue N A ≤ killedModeRate N A i := by
  have h := killed_rayleigh N A hA _ (killedValue_vanishes (killedBasis N A i))
  simpa only [killedBasis_squareSum, killedBasis_energy, mul_one] using h

end TorusCoverTime.Blocks.B
