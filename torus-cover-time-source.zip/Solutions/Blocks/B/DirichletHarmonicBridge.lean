import Solutions.Blocks.B.GaussianClockPath
import Solutions.Blocks.B.DiskHarmonicMeasure

/-! The bridge path really is the outer Dirichlet field minus its original
exit-harmonic averages, on the same Fourier sample.  No comparable surrogate
radial field or independent copy is introduced. -/

noncomputable section
open MeasureTheory ProbabilityTheory Classical
open scoped BigOperators
namespace TorusCoverTime.Blocks.B
open Blocks.C.C4

theorem dirichlet_harmonic_average (N : Size) (root : Vertex N)
    (D E : Finset (Vertex N)) (hDE : D ⊆ E) (hroot : root ∉ E)
    (ξ : FiniteFieldSample N) (x : Vertex N) :
    (∑ z, exitHarmonic N D z x * pinnedDomainField N root E ξ z) =
      pinnedDomainField N root E ξ x - pinnedDomainField N root D ξ x := by
  have hD : D ≠ Finset.univ := domain_proper_of_root_outside N root D (fun h => hroot (hDE h))
  have hav := congrFun (harmonic_exit_representation N D hD
    (pinnedDomainIncrement N root D E ξ)
    (fun z hz => pinnedDomainIncrement_harmonic N root D E hDE ξ z hz)) x
  change _ = pinnedDomainIncrement N root D E ξ x
  rw [hav]
  unfold exitExtension
  apply Finset.sum_congr rfl
  intro z _
  by_cases hz : z ∈ D
  · simp only [exitHarmonic_zero_inside N D x z hz, mul_zero, zero_mul]
  · simp only [pinnedDomainIncrement, pinnedDomainField_boundary N root D ξ z hz, sub_zero]
    ring

theorem dirichlet_disk_harmonic_average (N : Size) (root c : Vertex N)
    (E : Finset (Vertex N)) (r : ℝ) (hDE : torusDisk N c r ⊆ E) (hroot : root ∉ E)
    (ξ : FiniteFieldSample N) :
    (∑ z, diskHarmonicWeight N c r z * pinnedDomainField N root E ξ z) =
      pinnedDomainField N root E ξ c - pinnedDomainField N root (torusDisk N c r) ξ c :=
  dirichlet_harmonic_average N root _ E hDE hroot ξ c

def dirichletClockPath (N : Size) (root : Vertex N) (n : ℕ)
    (D : Fin (n + 1) → Finset (Vertex N)) (hD : Monotone D)
    (hroot : ∀ i, root ∉ D i) (hzero : D 0 = ∅) (x : Vertex N) :
    GaussianClockPath (finiteFieldLaw N) n where
  path := pinnedScalePath N root D x
  clock := pinnedScaleClock N root D x
  measurable := pinnedScalePath_measurable N root D x
  gaussian := pinnedScalePath_gaussian N root D x
  mean_zero := pinnedScalePath_mean N root D x
  covariance := pinnedScalePath_covariance N root D hD hroot x
  clock_zero := by
    change pinnedDomainKernel N root (D 0) x x = 0
    rw [hzero]
    exact pinnedDomainKernel_boundary N root ∅ x x (by simp)
  clock_mono := pinnedScaleClock_mono N root D hD hroot x
  start_zero ξ := by
    change pinnedDomainField N root (D 0) ξ x = 0
    rw [hzero]
    exact pinnedDomainField_boundary N root ∅ ξ x (by simp)

theorem dirichlet_harmonic_bridge_decomposition {n : ℕ} (N : Size) (root : Vertex N)
    (D : Fin (n + 1) → Finset (Vertex N)) (hD : Monotone D)
    (hroot : root ∉ D (Fin.last n)) (x : Vertex N) (ξ : FiniteFieldSample N)
    (i : Fin (n + 1)) :
    (∑ z, exitHarmonic N (D i) z x * pinnedDomainField N root (D (Fin.last n)) ξ z) =
      (1 - pinnedScaleClock N root D x i / pinnedScaleClock N root D x (Fin.last n)) *
        pinnedScalePath N root D x ξ (Fin.last n) -
      pinnedScaleBridge N root D x (Fin.last n) ξ i := by
  rw [dirichlet_harmonic_average N root _ _ (hD (Fin.le_last i)) hroot]
  dsimp [pinnedScaleBridge, pinnedScalePath]
  ring

end TorusCoverTime.Blocks.B
