import Solutions.Blocks.B.DirichletResidualGreenTail

/-! The spatial Green inputs of the residual tail are supplied by the
project's proved disk Green estimates, for an actual interior exit circle. -/

noncomputable section
open MeasureTheory ProbabilityTheory Classical
namespace TorusCoverTime.Blocks.B
open Blocks.C.C4

def dirichletLogError : ℝ := diskGreenLogErrorConstant/(2*g)
def dirichletResidualCrossBound : ℝ := 3*dirichletLogError+Real.log 3/2
def dirichletResidualVarianceBound (r : ℝ) : ℝ := Real.log r+Real.log 3+4*dirichletLogError

theorem dirichletLogError_pos : 0<dirichletLogError := by
  exact div_pos diskGreenLogErrorConstant_pos (by unfold g; positivity)

theorem dirichlet_LS_disk_offdiagonal_log (N : Size) (root c : Vertex N) (R : ℝ)
    (hR : 1≤R) (hsmall : 2*(R+1)<N.val) (hroot : root∉torusDisk N c R)
    (z x : Vertex N) (hz : z∈torusDisk N c R) (hx : periodicDistance x c≤R/2) (hzx : z≠x) :
    |dirichletKernelLS N root (torusDisk N c R) z x-Real.log (R/periodicDistance z x)/2|≤dirichletLogError := by
  have hh := diskGreen_offdiagonal_log_error N c R hR hsmall z x hz hx hzx
  have hg : 0<g := by unfold g; positivity
  unfold dirichletKernelLS dirichletLogError
  rw [congrFun (pinnedDomainKernel_eq_diskGreen N root c R (by linarith) hsmall hroot x) z]
  have he : diskGreen N c R z x/(2*g)-Real.log (R/periodicDistance z x)/2=
      (diskGreen N c R z x-g*Real.log (R/periodicDistance z x))/(2*g) := by field_simp
  rw [he,abs_div,abs_of_pos (by unfold g; positivity : 0<2*g)]
  exact div_le_div_of_nonneg_right hh (by unfold g; positivity)

theorem dirichlet_disk_residual_Green_bounds (N : Size) (root c x : Vertex N) (R r : ℝ)
    (hr : 1≤r) (hsmall : 2*(R+1)<N.val) (hroot : root∉torusDisk N c R)
    (hdeep : periodicDistance x c+(r+1)≤R/2) :
    torusDisk N x r⊆torusDisk N c R ∧
      ∀ z, exitHarmonic N (torusDisk N x r) z x≠0 →
        dirichletClockLS N root (torusDisk N c R) z+dirichletClockLS N root (torusDisk N c R) x-
            2*dirichletKernelLS N root (torusDisk N c R) z x≤dirichletResidualVarianceBound r ∧
          |dirichletKernelLS N root (torusDisk N c R) z x-
            (dirichletClockLS N root (torusDisk N c R) x-dirichletClockLS N root (torusDisk N x r) x)|≤
              dirichletResidualCrossBound := by
  have hr0 : 0<r := by linarith
  have hx0 : 0≤periodicDistance x c := by unfold periodicDistance; positivity
  have hR : 1≤R := by linarith
  have hR0 : 0<R := by linarith
  have hDE : torusDisk N x r⊆torusDisk N c R := by
    intro z hz
    have hzx := (mem_torusDisk N x z r).mp hz
    apply (mem_torusDisk N c z R).mpr
    have htri := periodicDistance_triangle N z x c
    linarith
  have hrroot : root∉torusDisk N x r := fun hh => hroot (hDE hh)
  have hrsmall : 2*(r+1)<N.val := by linarith
  have hxdeep : periodicDistance x c≤R/2 := by linarith
  have hxinner : x∈torusDisk N x r := by
    apply (mem_torusDisk N x x r).mpr
    rw [periodicDistance_self_zero]
    exact hr0
  have hv := dirichlet_LS_disk_clock_log N root c R hR hsmall hroot x hxdeep
  have hi := dirichlet_LS_disk_clock_log N root x r hr hrsmall hrroot x
    (by rw [periodicDistance_self_zero]; positivity)
  refine ⟨hDE,?_⟩
  intro z hz
  have hzb : diskExteriorNeighbor N x r z := by
    by_contra hn
    exact hz (exitHarmonic_disk_support N x r x z hxinner hn)
  have hdist := diskExteriorNeighbor_radius N x r z hzb
  have hd0 : 0<periodicDistance z x := hr0.trans_le hdist.1
  have hzx : z≠x := by intro he; subst z; rw [periodicDistance_self_zero] at hd0; linarith
  have hzdeep : periodicDistance z c≤R/2 := by
    have htri := periodicDistance_triangle N z x c
    linarith [hdist.2]
  have hzE : z∈torusDisk N c R := (mem_torusDisk N c z R).mpr (by linarith)
  have hvz := dirichlet_LS_disk_clock_log N root c R hR hsmall hroot z hzdeep
  have hc := dirichlet_LS_disk_offdiagonal_log N root c R hR hsmall hroot z x hzE hxdeep hzx
  have hl := log_comparable_radius r (periodicDistance z x) hr0 (by linarith [hdist.1]) (by linarith [hdist.2])
  rw [Real.log_div hR0.ne' hd0.ne'] at hc
  change |_-_|≤dirichletLogError at hv hi hvz
  have hc' := abs_le.mp hc
  have hv' := abs_le.mp hv
  have hi' := abs_le.mp hi
  have hvz' := abs_le.mp hvz
  have hl' := abs_le.mp hl
  constructor
  · unfold dirichletResidualVarianceBound
    linarith
  · unfold dirichletResidualCrossBound
    rw [abs_le]
    constructor <;> linarith

end TorusCoverTime.Blocks.B
