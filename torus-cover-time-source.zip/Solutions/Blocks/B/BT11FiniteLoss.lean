import Solutions.Blocks.B.BT11BridgeOccupation

/-! Finite witness losses need no independence. The estimates are joint
with the bridge endpoint, so conditioning never creates an untracked factor. -/
noncomputable section
open MeasureTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

def bt11LossCount {I Ω : Type*} (S : Finset I) (F : I → Set Ω) (ω : Ω) : ℝ :=
  ∑ i∈S,if ω∈F i then 1 else 0

theorem bt11LossCount_nonneg {I Ω : Type*} (S : Finset I) (F : I → Set Ω) (ω : Ω) :
    0≤bt11LossCount S F ω := Finset.sum_nonneg (fun _ _ => by split_ifs <;> norm_num)

theorem bt11LossCount_measurable {I Ω : Type*} [MeasurableSpace Ω] (S : Finset I)
    (F : I → Set Ω) (hF : ∀ i,MeasurableSet (F i)) : Measurable (bt11LossCount S F) :=
  Finset.measurable_sum _ (fun i _ => measurable_const.ite (hF i) measurable_const)

theorem bt11LossCount_card {I Ω : Type*} (S : Finset I) (F : I → Set Ω) (ω : Ω) :
    bt11LossCount S F ω=((S.filter (fun i => ω∈F i)).card:ℝ) := by
  simp only [bt11LossCount,Finset.card_eq_sum_ones,Finset.sum_filter,Nat.cast_sum,Nat.cast_ite,Nat.cast_one,Nat.cast_zero]

theorem bt11_finite_loss {I Ω : Type*} [MeasurableSpace Ω] (μ : Measure Ω) [IsProbabilityMeasure μ]
    (S : Finset I) (hS : S.Nonempty) (F : I → Set Ω) (hF : ∀ i,MeasurableSet (F i))
    (R : Set Ω) (hR : MeasurableSet R) (β : ℝ)
    (hb : ∀ i∈S,μ.real (F i∩R)≤β) :
    μ.real R-2*β≤μ.real {ω | ω∈R ∧ bt11LossCount S F ω≤(S.card:ℝ)/2} := by
  let M : ℝ := S.card
  have hM : 0<M := by dsimp [M]; exact_mod_cast Finset.card_pos.mpr hS
  let E : Set Ω := {ω | ω∈R ∧ M/2<bt11LossCount S F ω}
  let G : Set Ω := {ω | ω∈R ∧ bt11LossCount S F ω≤M/2}
  let J := fun ω => R.indicator (bt11LossCount S F) ω
  have hE : MeasurableSet E := hR.inter (measurableSet_lt measurable_const (bt11LossCount_measurable S F hF))
  have hG : MeasurableSet G := hR.inter (measurableSet_le (bt11LossCount_measurable S F hF) measurable_const)
  have hJi : Integrable J μ := by
    apply Integrable.of_bound ((bt11LossCount_measurable S F hF).indicator hR).aestronglyMeasurable M
    apply Eventually.of_forall
    intro ω
    by_cases hr : ω∈R
    · rw [indicator_of_mem hr,Real.norm_eq_abs,
        abs_of_nonneg (bt11LossCount_nonneg S F ω),bt11LossCount_card]
      dsimp only [M]
      exact_mod_cast Finset.card_le_card (Finset.filter_subset (fun i => ω∈F i) S)
    · simp only [J,indicator_of_notMem hr,Real.norm_eq_abs,abs_zero]
      exact hM.le
  have hJE : (M/2)*μ.real E≤∫ ω,J ω ∂μ := by
    have h := integral_mono (((integrable_const (1:ℝ)).indicator hE).const_mul (M/2)) hJi (fun ω => ?_)
    · simpa only [integral_const_mul,integral_indicator_const _ hE,smul_eq_mul,mul_one] using h
    by_cases he : ω∈E
    · rw [indicator_of_mem he,mul_one,show J ω=bt11LossCount S F ω from indicator_of_mem he.1 _]
      exact he.2.le
    · rw [indicator_of_notMem he,mul_zero]
      exact indicator_nonneg (fun ω _ => bt11LossCount_nonneg S F ω) ω
  have hJ : (∫ ω,J ω ∂μ)≤M*β := by
    have he (ω : Ω) : J ω=∑ i∈S,(F i∩R).indicator (fun _ => (1:ℝ)) ω := by
      by_cases hr : ω∈R
      · simp [J,bt11LossCount,indicator_of_mem hr,Set.indicator,hr]
      · simp [J,Set.indicator,hr]
    simp_rw [he]
    rw [integral_finsetSum _ (fun i _ => (integrable_const (1:ℝ)).indicator ((hF i).inter hR))]
    simp_rw [integral_indicator_const _ ((hF _).inter hR),smul_eq_mul,mul_one]
    exact (Finset.sum_le_sum hb).trans_eq (by simp [M,nsmul_eq_mul])
  have hbE : μ.real E≤2*β := by nlinarith [hJE.trans hJ]
  have he : R=E∪G := by
    ext ω
    simp only [E,G,mem_setOf_eq,mem_union]
    constructor
    · intro hr
      rcases lt_or_ge (M/2) (bt11LossCount S F ω) with h|h
      · exact Or.inl ⟨hr,h⟩
      · exact Or.inr ⟨hr,h⟩
    · rintro (h|h) <;> exact h.1
  have hR' : μ.real R≤μ.real E+μ.real G := by rw [he]; exact measureReal_union_le _ _
  change μ.real R-2*β≤μ.real G
  linarith

end TorusCoverTime.Blocks.B
