import Solutions.Blocks.B.PointNearProbability
import Solutions.Blocks.B.R8LoopPrefixBound

/-! Root-neighborhood exclusion under the project's original root-summed,
physical-time loop measure, including its timeScale normalization. -/
noncomputable section
open MeasureTheory Filter Set Classical
open scoped ENNReal Topology BigOperators
namespace TorusCoverTime.Blocks.B

theorem point_loop_event_mass_bound (N : Size) (E : Vertex N → Set (WalkSample × ℝ))
    (hE : ∀ root, MeasurableSet (E root)) (l r : ℝ) (ρ : ℝ≥0∞)
    (hρ : ∀ root t, 0 < t → t ∈ Icc l r →
      walkLaw {ω | (ω,t) ∈ E root ∧ walk N root ω t=root} ≤ ρ) :
    r7LoopEventMass N E l r ≤ ENNReal.ofReal (vertexCount N*(r-l)/timeScale N)*ρ := by
  apply r8_loop_normalized_root_bound N E l r ρ
  intro root
  have hswap := lintegral_lintegral_swap (μ := walkLaw) (ν := volume.restrict (Ioi (0:ℝ)))
    (f := fun ω t => r7LoopEventTest N root (E root) l r (ω,t))
    (by exact (r7LoopEventTest_measurable N root _ (hE root) l r).aemeasurable)
  rw [hswap]
  calc
    _ ≤ ∫⁻ t in Ioi (0:ℝ), (Icc l r).indicator (fun _ => ρ) t ∂volume := by
      apply lintegral_mono_ae
      filter_upwards [ae_restrict_mem (measurableSet_Ioi (a := (0:ℝ)))] with t ht
      by_cases htime : t ∈ Icc l r
      · rw [indicator_of_mem htime]
        have hm : MeasurableSet {ω | (ω,t) ∈ E root ∧ walk N root ω t=root} :=
          ((hE root).preimage (measurable_id.prodMk measurable_const)).inter
            (((measurable_walk_eq_joint N root root).comp (measurable_id.prodMk measurable_const)).setOf)
        have hi : (∫⁻ ω, r7LoopEventTest N root (E root) l r (ω,t) ∂walkLaw) =
            walkLaw {ω | (ω,t) ∈ E root ∧ walk N root ω t=root} := by
          simpa [r7LoopEventTest,htime,Set.indicator,and_assoc] using
            lintegral_indicator_const hm (1:ℝ≥0∞)
        rw [hi]
        exact hρ root t ht htime
      · simp [r7LoopEventTest,htime]
    _ ≤ ∫⁻ t, (Icc l r).indicator (fun _ => ρ) t ∂volume :=
      lintegral_mono' Measure.restrict_le_self le_rfl
    _ = _ := by rw [lintegral_indicator_const measurableSet_Icc,Real.volume_Icc,mul_comm]

theorem point_near_loop_joint_bound (N : Size) (root : Vertex N) (R u t J : ℝ)
    (hR : 0 ≤ R) (hJ0 : 0 ≤ J)
    (hJ : ∀ c : Vertex N, walkLaw.real {ω | localTime N root ω t c ≤ u ∧ walk N root ω t=root} ≤ J) :
    walkLaw {ω | (ω,t) ∈ pointNearSoftEvent N root root R u ∧ walk N root ω t=root} ≤
      ENNReal.ofReal ((2*R+1)^2*J) := by
  have h := (point_soft_sites_joint N root root (torusDisk N root R) t u J (fun c _ => hJ c)).trans
    (mul_le_mul_of_nonneg_right (torusDisk_card_le N root R hR) hJ0)
  have hh := ENNReal.ofReal_le_ofReal h
  simpa only [Measure.real,ENNReal.ofReal_toReal (measure_ne_top _ _),pointNearSoftEvent,mem_setOf_eq] using hh

theorem point_near_loop_central_bound (hWalk : WalkModelRegular) (γ C u H : ℝ)
    (hC : 0 ≤ C) (hH : 0 ≤ H) :
    ∀ᶠ N : Size in atTop, ∀ l r : ℝ, l ≤ r →
      phaseACenter N-H*timeScale N ≤ l → r ≤ phaseACenter N+H*timeScale N →
      r7LoopEventMass N (fun root => pointNearSoftEvent N root root (pointNearRadius N γ C) u) l r ≤
        ENNReal.ofReal (2*H*pointNearEnvelope N γ C u H) := by
  filter_upwards [point_soft_joint_central hWalk u H hH] with N hN
  intro l r hlr hlo hhi
  let R := pointNearRadius N γ C
  let J := pointSoftJointBound N u H
  have hR : 0 ≤ R := pointNearRadius_nonneg N γ C hC
  have hJ : 0 ≤ J := pointSoftJointBound_nonneg N u H
  have hmass := point_loop_event_mass_bound N (fun root => pointNearSoftEvent N root root R u)
    (fun root => pointNearSoftEvent_measurable N root root R u) l r (ENNReal.ofReal ((2*R+1)^2*J))
    (fun root t _ htime => point_near_loop_joint_bound N root R u t J hR hJ
      (fun c => hN c root root t (hlo.trans htime.1)))
  apply hmass.trans
  have hn : 0 ≤ vertexCount N*(r-l)/timeScale N := by
    exact div_nonneg (mul_nonneg (vertexCount_pos N).le (sub_nonneg.mpr hlr)) (timeScale_pos N).le
  rw [← ENNReal.ofReal_mul hn]
  apply ENNReal.ofReal_le_ofReal
  have hlen : (r-l)/timeScale N ≤ 2*H := (div_le_iff₀ (timeScale_pos N)).mpr (by linarith)
  have hlen0 : 0 ≤ (r-l)/timeScale N := div_nonneg (sub_nonneg.mpr hlr) (timeScale_pos N).le
  have h := mul_le_mul hlen (point_near_spatial_budget N γ C u H)
    (mul_nonneg (mul_nonneg (vertexCount_pos N).le (sq_nonneg _)) hJ)
    (by positivity : 0 ≤ 2*H)
  calc
    vertexCount N*(r-l)/timeScale N*((2*R+1)^2*J) =
        (r-l)/timeScale N*(vertexCount N*(2*R+1)^2*J) := by ring
    _ ≤ _ := h

theorem point_near_loop_uniform (hWalk : WalkModelRegular) (γ C u H : ℝ)
    (hγ : 0 < γ) (hC : 0 ≤ C) (hH : 0 ≤ H) :
    ∀ ε : ℝ, 0 < ε → ∀ᶠ N : Size in atTop, ∀ l r : ℝ, l ≤ r →
      phaseACenter N-H*timeScale N ≤ l → r ≤ phaseACenter N+H*timeScale N →
      r7LoopEventMass N (fun root => pointNearSoftEvent N root root (pointNearRadius N γ C) u) l r ≤
        ENNReal.ofReal ε := by
  intro ε hε
  have ht := (point_near_envelope_tendsto γ C u H hγ).const_mul (2*H)
  simp only [mul_zero] at ht
  filter_upwards [point_near_loop_central_bound hWalk γ C u H hC hH,
    ht.eventually (eventually_lt_nhds hε)] with N hN hεN
  intro l r hlr hlo hhi
  exact (hN l r hlr hlo hhi).trans (ENNReal.ofReal_le_ofReal hεN.le)

theorem point_near_loop_window_tendsto (hWalk : WalkModelRegular) (γ C u H : ℝ)
    (hγ : 0 < γ) (hC : 0 ≤ C) (hH : 0 ≤ H) (l r : Size → ℝ)
    (hwindow : ∀ᶠ N : Size in atTop, l N ≤ r N ∧ phaseACenter N-H*timeScale N ≤ l N ∧
      r N ≤ phaseACenter N+H*timeScale N) :
    Tendsto (fun N : Size => r7LoopEventMass N
      (fun root => pointNearSoftEvent N root root (pointNearRadius N γ C) u) (l N) (r N)) atTop (𝓝 0) := by
  have ht := (ENNReal.continuous_ofReal.tendsto _).comp
    ((point_near_envelope_tendsto γ C u H hγ).const_mul (2*H))
  simp only [mul_zero,ENNReal.ofReal_zero] at ht
  apply tendsto_of_tendsto_of_tendsto_of_le_of_le' tendsto_const_nhds ht
    (Eventually.of_forall fun _ => bot_le)
  filter_upwards [point_near_loop_central_bound hWalk γ C u H hC hH,hwindow] with N hN hw
  exact hN (l N) (r N) hw.1 hw.2.1 hw.2.2

end TorusCoverTime.Blocks.B
