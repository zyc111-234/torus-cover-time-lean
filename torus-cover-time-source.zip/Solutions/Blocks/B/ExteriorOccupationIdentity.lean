import Solutions.Blocks.B.ExteriorOccupationObservable

/-! Exact original-path identification when the potential vanishes on the erased outer disk. -/
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B


theorem exteriorOccupation_actual_ae (N : Size) (I O : Finset (Vertex N))
    (hI : I.Nonempty) (root : Vertex N) (hr : root ∉ O)
    (U : Vertex N → ℝ) (hU : ∀ x ∈ O, U x = 0) (m : ℕ) (w : Fin (2*m) → Vertex N) :
    ∀ᵐ ω ∂walkLaw[|{ω | adaptiveExitWord N (alternatingDomain N I O) root (2*m) ω = w}],
      ∀ t, adaptiveExitTime N (alternatingDomain N I O) root (2*m) ω ≤ t →
      (∑ x, U x*localTime N root ω t x) =
        exteriorOccupation N root m w U
          (traversalExteriorData N I O root m ω,t-adaptiveExitTime N (alternatingDomain N I O) root (2*m) ω) := by
  have hac : walkLaw[|{ω | adaptiveExitWord N (alternatingDomain N I O) root (2*m) ω = w}] ≪ walkLaw :=
    cond_absolutelyContinuous
  filter_upwards [hac.ae_le (adaptiveExit_occupation_restart_ae N (alternatingDomain N I O) root U),
    hac.ae_le (adaptiveExit_spec_ae N _ (alternatingDomain_proper N I O hI ⟨root,hr⟩) root),
    ae_cond_mem (μ := walkLaw) ((adaptiveExitWord_measurable N _ root (2*m)) (measurableSet_singleton w))]
    with ω hocc hs hw
  intro t ht
  have he := hocc (2*m) (t-adaptiveExitTime N (alternatingDomain N I O) root (2*m) ω)
    (sub_nonneg.mpr ht)
  rw [add_sub_cancel] at he
  have hz : ∀ k < m, excursionRecordCost N
      (adaptiveExitStart N (alternatingDomain N I O) root (2*k+1) ω) U
      (adaptiveExitRecord N (alternatingDomain N I O) root (2*k+1) ω) = 0 := by
    intro k _
    apply finiteExitRecord_cost_zero N _ _ _ _ U _ (hs (2*k+1))
    simpa only [alternatingDomain_odd] using hU
  rw [sum_range_pairs_of_odd_zero _ m hz,
    ← exteriorReturnOccupation_of_word N I O root m w U ω hw,
    adaptiveExitStart_of_word N _ root (2*m) w ω hw (2*m) le_rfl] at he
  exact he


end TorusCoverTime.Blocks.B

