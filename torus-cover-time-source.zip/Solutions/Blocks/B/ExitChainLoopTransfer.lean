import Solutions.Blocks.B.ExitChainResampling
import Mathlib.MeasureTheory.Group.Measure

/-! Exact translation of the rooted-loop time integral after the last complete
segment. The original physical clock is the sum of recorded durations plus
the common exterior time; the terminal return event is retained. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

theorem lintegral_Ioi_translate (f : ℝ → ℝ≥0∞) (hf : Measurable f) (s : ℝ) :
    (∫⁻ t in Ioi s, f t) = ∫⁻ u in Ioi (0 : ℝ), f (s+u) := by
  have hm := hf.indicator (measurableSet_Ioi (a := s))
  calc
    _ = ∫⁻ t, (Ioi s).indicator f t := (lintegral_indicator (μ := volume) measurableSet_Ioi f).symm
    _ = ∫⁻ u, (Ioi s).indicator f (s+u) := by
      have hs : Measurable (fun u : ℝ => s+u) := measurable_const.add measurable_id
      have hh := lintegral_map (μ := volume) hm hs
      rw [map_add_left_eq_self volume s] at hh
      exact hh
    _ = _ := by
      rw [← lintegral_indicator (measurableSet_Ioi (a := (0 : ℝ)))]
      apply lintegral_congr
      intro u
      simp only [Set.indicator, mem_Ioi, lt_add_iff_pos_right]

def shiftedExitLoopTest (N : Size) (root endpoint : Vertex N) (n : ℕ)
    (F : ℝ × WalkSample → ℝ≥0∞) (q : (Fin n → ℕ × WalkSample) × WalkSample) : ℝ≥0∞ :=
  ∫⁻ u in Ioi (0 : ℝ), if walk N endpoint q.2 u = root then
    F (recordsDuration n q.1+u, recordsJoin n q.1 q.2) else 0

theorem shiftedExitLoopTest_measurable (N : Size) (root endpoint : Vertex N) (n : ℕ)
    (F : ℝ × WalkSample → ℝ≥0∞) (hF : Measurable F) :
    Measurable (shiftedExitLoopTest N root endpoint n F) := by
  have hm : Measurable (fun z : ((Fin n → ℕ × WalkSample) × WalkSample) × ℝ =>
      if walk N endpoint z.1.2 z.2 = root then
        F (recordsDuration n z.1.1+z.2, recordsJoin n z.1.1 z.1.2) else 0) :=
    (hF.comp (((recordsDuration_measurable n).comp measurable_fst.fst).add measurable_snd |>.prodMk
      ((recordsJoin_measurable n).comp measurable_fst))).ite
      (((measurable_walk_eq_joint N endpoint root).comp (measurable_fst.snd.prodMk measurable_snd)).setOf)
      measurable_const
  exact hm.lintegral_prod_right'

theorem exitChain_loop_lintegral (N : Size) (D : ℕ → Finset (Vertex N))
    (hD : ∀ k, ∃ b : Vertex N, b ∉ D k) (a b : ℕ → Vertex N) (n : ℕ)
    (hab : ∀ k < n, b k = a (k+1))
    (F : ℝ × WalkSample → ℝ≥0∞) (hF : Measurable F) :
    (∫⁻ ω, (∫⁻ t in Ioi (exitChainTime N D a n ω),
      if walk N (a 0) ω t = a 0 then F (t,ω) else 0)
      ∂walkLaw[|exitChainEndpoints N D a b n]) =
      ∫⁻ p, ∫⁻ η, (∫⁻ u in Ioi (0 : ℝ), if walk N (a n) η u = a 0 then
        F (recordsDuration n p+u, recordsJoin n p η) else 0) ∂walkLaw
        ∂Measure.pi (fun j : Fin n => exactExitRecordLaw N (D j.val) (a j.val) (b j.val)) := by
  have he : (fun ω => ∫⁻ t in Ioi (exitChainTime N D a n ω),
      if walk N (a 0) ω t = a 0 then F (t,ω) else 0)
      =ᵐ[walkLaw[|exitChainEndpoints N D a b n]]
      (fun ω => shiftedExitLoopTest N (a 0) (a n) n F
        ((fun j : Fin n => exitChainRecord N D a j.val ω), exitChainTail N D a n ω)) := by
    filter_upwards [exitChain_walk_future_ae N D hD a b n hab] with ω hω
    have hm : Measurable (fun t : ℝ => if walk N (a 0) ω t = a 0 then F (t,ω) else 0) :=
      (hF.comp (measurable_id.prodMk measurable_const)).ite
        (((measurable_walk_eq_joint N (a 0) (a 0)).comp
          (measurable_const.prodMk measurable_id)).setOf) measurable_const
    rw [lintegral_Ioi_translate _ hm]
    simp only [shiftedExitLoopTest, recordsDuration_exitChain, recordsJoin_exitChain]
    apply lintegral_congr_ae
    filter_upwards [ae_restrict_mem (measurableSet_Ioi (a := (0 : ℝ)))] with u hu
    simp only [hω u hu.le]
  rw [lintegral_congr_ae he]
  exact lintegral_exitChain_record_tail N D hD a b n _
    (shiftedExitLoopTest_measurable N (a 0) (a n) n F hF)

end TorusCoverTime.Blocks.B
