import Solutions.Blocks.B.KilledSpectral

/-! Identification of the unique principal term and the rates of all remaining modes. -/

noncomputable section
open Classical
open scoped BigOperators RealInnerProductSpace
namespace TorusCoverTime.Blocks.B

def principalLift (N : Size) (A : Finset (Vertex N)) (hA : A ≠ Finset.univ) :
    KilledSpace N A :=
  killedLift N A (principalMode N A) (principalMode_valid N A hA).1

lemma principalLift_sum (N : Size) (A : Finset (Vertex N)) (hA : A ≠ Finset.univ) :
    (∑ x : Vertex N, killedValue (principalLift N A hA) x) = vertexCount N := by
  have h := (principalMode_valid N A hA).2.1
  exact (div_eq_one_iff_eq (vertexCount_pos N).ne').mp h

lemma principalLift_ne_zero (N : Size) (A : Finset (Vertex N)) (hA : A ≠ Finset.univ) :
    principalLift N A hA ≠ 0 := by
  intro h
  have hs := principalLift_sum N A hA
  rw [h] at hs
  simp only [killedValue, Submodule.coe_zero, PiLp.zero_apply, Finset.sum_const_zero] at hs
  exact (vertexCount_pos N).ne' hs.symm

lemma principalLift_inner_self (N : Size) (A : Finset (Vertex N)) (hA : A ≠ Finset.univ) :
    ⟪principalLift N A hA, principalLift N A hA⟫ =
      vertexCount N * (1 + principalVariance N A) := by
  rw [killed_inner]
  change (∑ x : Vertex N, principalMode N A x * principalMode N A x) = _
  simpa only [squareSum, pow_two] using principalMode_squareSum N A

lemma principalLift_eigen (N : Size) (A : Finset (Vertex N)) (hA : A ≠ Finset.univ) :
    killedTransition N A (principalLift N A hA) =
      (1 - killedEigenvalue N A) • principalLift N A hA := by
  apply Subtype.ext
  ext x
  change killedStep N A (principalMode N A) x =
    (1 - killedEigenvalue N A) * principalMode N A x
  by_cases hx : x ∈ A
  · simp [killedStep, hx, (principalMode_valid N A hA).1 x hx]
  · rw [killedStep_off_target N A _ x hx]
    have h := (principalMode_valid N A hA).2.2.2 x hx
    linarith

lemma killedBasis_principal (N : Size) (A : Finset (Vertex N))
    (hA : A ≠ Finset.univ) (hd : capacityRatio N A < 1) :
    ∃ i : Fin (Module.finrank ℝ (KilledSpace N A)), ∃ c : ℝ,
      c ≠ 0 ∧ killedModeRate N A i = killedEigenvalue N A ∧
      killedBasis N A i = c • principalLift N A hA := by
  have heig : Module.End.HasEigenvector (killedTransition N A)
      (1 - killedEigenvalue N A) (principalLift N A hA) :=
    ⟨Module.End.mem_eigenspace_iff.mpr (principalLift_eigen N A hA),
      principalLift_ne_zero N A hA⟩
  obtain ⟨i, hi⟩ := (killedTransition_symmetric N A).exists_eigenvalues_eq rfl
    (Module.End.hasEigenvalue_of_hasEigenvector heig)
  have hrate : killedModeRate N A i = killedEigenvalue N A := by
    simp only [killedModeRate]
    simpa using congrArg (fun r : ℝ => 1 - r) hi
  obtain ⟨c, hc⟩ := killed_eigenspace_simple N A hA hd
    (killedValue (killedBasis N A i)) (killedValue_vanishes _)
    (by intro x hx; rw [← hrate]; exact killedBasis_generator N A i x hx)
  have heq : killedBasis N A i = c • principalLift N A hA := by
    apply Subtype.ext
    ext x
    exact congrFun hc x
  refine ⟨i, c, ?_, hrate, heq⟩
  intro hc0
  rw [hc0, zero_smul] at heq
  exact (killedBasis N A).orthonormal.ne_zero i heq

lemma killedWeight_principal (N : Size) (A : Finset (Vertex N))
    (hA : A ≠ Finset.univ)
    (i : Fin (Module.finrank ℝ (KilledSpace N A))) (c : ℝ)
    (hc : killedBasis N A i = c • principalLift N A hA) :
    killedWeight N A i = 1 / (1 + principalVariance N A) := by
  have hv := principalVariance_nonneg N A hA
  have hvp : 0 < 1 + principalVariance N A := by linarith
  have hnorm : ⟪killedBasis N A i, killedBasis N A i⟫ = 1 := by
    rw [real_inner_self_eq_norm_sq, (killedBasis N A).orthonormal.1 i]
    norm_num
  rw [hc, real_inner_smul_left (principalLift N A hA) (c • principalLift N A hA) c,
    real_inner_smul_right (principalLift N A hA) (principalLift N A hA) c,
    principalLift_inner_self] at hnorm
  have hsum : ⟪killedBasis N A i, killedStart N A⟫ = c * vertexCount N := by
    rw [hc, real_inner_smul_left (principalLift N A hA) (killedStart N A) c, real_inner_comm,
      killedStart_inner, principalLift_sum]
  rw [killedWeight, hsum]
  apply (eq_div_iff hvp.ne').mpr
  rw [div_mul_eq_mul_div]
  apply (div_eq_iff (vertexCount_pos N).ne').mpr
  nlinarith [congrArg (fun r : ℝ => r * vertexCount N) hnorm]

lemma killedModeRate_ge_gap (N : Size) (A : Finset (Vertex N))
    (hA : A ≠ Finset.univ) (hd : capacityRatio N A < 1)
    (i₀ : Fin (Module.finrank ℝ (KilledSpace N A))) (c : ℝ) (hc0 : c ≠ 0)
    (hc : killedBasis N A i₀ = c • principalLift N A hA)
    (i : Fin (Module.finrank ℝ (KilledSpace N A))) (hi : i ≠ i₀) :
    spectralGap N ≤ killedModeRate N A i := by
  have horth := (killedBasis N A).orthonormal.2 hi
  change ⟪killedBasis N A i, killedBasis N A i₀⟫ = 0 at horth
  rw [hc, real_inner_smul_right (killedBasis N A i) (principalLift N A hA) c] at horth
  have horthp := (mul_eq_zero.mp horth).resolve_left hc0
  have hsum : (∑ x : Vertex N, killedValue (killedBasis N A i) x * principalMode N A x) = 0 := by
    simpa only [killed_inner, principalLift, killedLift, killedValue, WithLp.ofLp_toLp] using horthp
  have hgap := killed_orthogonal_gap N A hA hd (killedValue (killedBasis N A i))
    (killedValue_vanishes _) hsum
  have hnorm : (∑ x : Vertex N, killedValue (killedBasis N A i) x ^ 2) = 1 := by
    rw [show (∑ x : Vertex N, killedValue (killedBasis N A i) x ^ 2) =
        ⟪killedBasis N A i, killedBasis N A i⟫ by simp only [killed_inner, pow_two]]
    rw [real_inner_self_eq_norm_sq, (killedBasis N A).orthonormal.1 i]
    norm_num
  have henergy : energy N (killedValue (killedBasis N A i)) = killedModeRate N A i := by
    calc
      _ = killedModeRate N A i * ∑ x : Vertex N, killedValue (killedBasis N A i) x ^ 2 := by
        rw [energy, Finset.mul_sum]
        apply Finset.sum_congr rfl
        intro x _
        by_cases hx : x ∈ A
        · rw [killedValue_vanishes (killedBasis N A i) x hx]
          ring
        · rw [killedBasis_generator N A i x hx]
          ring
      _ = _ := by rw [hnorm, mul_one]
  simpa only [hnorm, mul_one, henergy] using hgap

end TorusCoverTime.Blocks.B
