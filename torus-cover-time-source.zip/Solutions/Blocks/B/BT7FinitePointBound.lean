import Solutions.Blocks.B.BT7EnvelopeTest
import Solutions.Blocks.B.BT7EventMeasurable
import Solutions.Blocks.B.FreshDirichletIndependence
import Solutions.Blocks.B.IndependentSlabTransfer
import Solutions.Blocks.B.GaussianEnvelopeWeightedTail

noncomputable section
open MeasureTheory ProbabilityTheory Classical Set
namespace TorusCoverTime.Blocks.B

def bt7EndpointWidth (N : Size) (ε C₀ : ℝ) : ℝ := ε*Real.log (logSize N)+2*C₀+dirichletMassProfileBound

/-- The actual periodic one-point bound, retaining the endpoint density in
both binding-envelope regimes. Only the previously proved Dirichlet bound
and explicit deterministic scale conditions enter as inputs. -/
theorem bt7_finite_point_bound (N : Size) (root x : Vertex N) (ρ γ ε C₀ C₁ η U P : ℝ)
    (hρ : 0<ρ) (hR : 4*diskHarnackRadiusThreshold≤ρ*(N.val:ℝ))
    (hsmall : 2*(ρ*(N.val:ℝ)+1)<N.val) (hroot : root∉torusDisk N x (ρ*(N.val:ℝ)))
    (hL : 8*(bt6ClockError ρ+1)≤logSize N)
    (hAS : (logSize N)^(32*γ)≤(logSize N)^(1/10:ℝ))
    (hb : 0≤bt7EndpointWidth N ε C₀) (hU : 0≤U) (hP : 0≤P)
    (hη₁ : ε*Real.log (logSize N)+C₀≤η)
    (hη₂ : C₁*(logSize N)^(8*γ)+U+dirichletMassProfileBound≤η)
    (hη₃ : bt7EndpointWidth N ε C₀+U≤η)
    (hscale : ∀ q : ℕ, (logSize N)^(32*γ)≤(q:ℝ) → (q:ℝ)≤logSize N-(logSize N)^(32*γ) →
      2*(Real.exp ((q:ℝ)+1)+1)<N.val ∧ Real.exp ((q:ℝ)+1)+1≤(ρ*(N.val:ℝ)/4)/(4*diskGreenInnerScale))
    (hcond : ∀ t : ℝ, |t-harmonicExtremeCenter N|≤η →
      (finiteFieldLaw N).real {ζ | bt6BadField N x γ η η
        (dirichletConditionedField N root (torusDisk N x (ρ*(N.val:ℝ))) x t ζ)}≤P) :
    bt7FreshSlabMass*(finiteFieldLaw N).real {ξ | bt7BadPoint N γ ε C₀ C₁ (periodicFieldLS N ξ) x}≤
      (2*Real.exp (8*bt6ClockError ρ)/vertexCount N*logSize N)*
        (2*(bt7EndpointWidth N ε C₀+1)*Real.exp (8*bt7EndpointWidth N ε C₀+bt7EnvelopeMomentScale ρ*(8+1)^2/2)*
          (P+Real.exp (-U^2/(2*bt7EnvelopeMomentScale ρ)))) := by
  let D := torusDisk N x (ρ*(N.val:ℝ))
  let T := periodicBindingEnvelope N root x ρ
  let b := bt7EndpointWidth N ε C₀
  let k := 2*Real.exp (8*bt6ClockError ρ)/vertexCount N*logSize N
  have hg : 0<g := by unfold g; positivity
  have hQ : 0≤dirichletMassProfileBound := by unfold dirichletMassProfileBound; positivity
  have hR4 : 4≤ρ*(N.val:ℝ) := by linarith [diskHarnackRadiusThreshold_ge_one]
  have hV : 0<dirichletMassVariance N root D :=
    lt_of_lt_of_le (by positivity) (dirichletMassVariance_disk_lower N root x _ (by linarith) hsmall hroot)
  have hT := periodicBindingEnvelope_measurable N root x ρ
  have hT0 := periodicBindingEnvelope_nonneg N root x ρ
  have hmoment := periodicBindingEnvelope_exp N root x ρ hρ hR hsmall hroot
  obtain ⟨hweighted,hweightedb⟩ := envelope_weighted_split T hT hT0
    (bt7EnvelopeMomentScale ρ) 8 b U P (bt7EnvelopeMomentScale_pos ρ) hb hU hP hmoment.1 hmoment.2
  let B := fun ξ => k*((b+T ξ)*Real.exp (8*(b+T ξ))*(if T ξ≤U then P else 1))
  have hk : 0≤k := by dsimp [k]; positivity [vertexCount_pos N,logSize_pos N]
  have hB : Integrable B (finiteFieldLaw N) := hweighted.const_mul k
  have hbound (ξ : FiniteFieldSample N) :
      (finiteFieldLaw N).real {ζ | (dirichletFieldLS N root D ζ,T ξ)∈bt7EnvelopeTest N x γ η b U}≤B ξ :=
    bt7EnvelopeTest_section_bound N root x x ρ γ η b U P hρ hb (by linarith) hsmall hroot
      (by rw [periodicDistance_self_zero]; linarith) hL hη₃ hP hcond (T ξ) (hT0 ξ)
  have hsub (ξ : FiniteFieldSample N) (hbad : bt7BadPoint N γ ε C₀ C₁ (periodicFieldLS N ξ) x)
      (ζ : FiniteFieldSample N) (hz : |normalizedDirichletMass N root D ζ|≤1) :
      (freshDirichletField N root D (ξ,ζ),T ξ)∈bt7EnvelopeTest N x γ η b U := by
    have hclose := freshDirichletField_close N root x ρ hR hsmall hroot (ξ,ζ) hz
    have hx : |periodicFieldLS N ξ x-freshDirichletField N root D (ξ,ζ) x|≤T ξ+dirichletMassProfileBound :=
      hclose x (by rw [periodicDistance_self_zero]; positivity [diskGreenInnerScale_ge_four])
    have hsc (q : ℕ) (hq : (logSize N)^(32*γ)≤(q:ℝ)) (hq' : (q:ℝ)≤logSize N-(logSize N)^(32*γ)) :
        2*(Real.exp ((q:ℝ)+1)+1)<N.val ∧ ∀ z,
          exitHarmonic N (torusDisk N x (Real.exp ((q:ℝ)+1))) z x≠0 →
            |periodicFieldLS N ξ z-freshDirichletField N root D (ξ,ζ) z|≤T ξ+dirichletMassProfileBound := by
      refine ⟨(hscale q hq hq').1,?_⟩
      intro z hz'
      apply hclose z
      have hrad := diskExteriorNeighbor_radius N x _ z (diskHarmonicWeight_support N x _ (Real.exp_pos _) z hz')
      exact hrad.2.le.trans (hscale q hq hq').2
    have ht := bt7BadPoint_transfer N γ ε C₀ C₁ (periodicFieldLS N ξ) (freshDirichletField N root D (ξ,ζ)) x
      (T ξ+dirichletMassProfileBound) (add_nonneg (hT0 ξ) hQ) hAS hx hsc hbad
    refine ⟨?_,?_⟩
    · change |freshDirichletField N root D (ξ,ζ) x-harmonicExtremeCenter N|≤b+T ξ
      dsimp only [b,bt7EndpointWidth]
      linarith [ht.1]
    · intro hlow
      exact bt6BadField_mono N x γ _ _ η η hη₁ (by linarith) _ ht.2
  have hA := (bt7BadPoint_measurableSet N γ ε C₀ C₁ x).preimage (periodicFieldLS_measurable N)
  have hS : MeasurableSet {ζ | |normalizedDirichletMass N root D ζ|≤1} :=
    measurableSet_le (((dirichletMass_measurable N root D).div_const _).abs) measurable_const
  have hh := independent_slab_transfer _ _ hA hS (freshDirichletField N root D) (dirichletFieldLS N root D) T
    (by apply measurable_pi_lambda; exact dirichletFieldLS_measurable N root D) hT
    (bt7EnvelopeTest N x γ η b U) (bt7EnvelopeTest_measurableSet N x γ η b U)
    (freshDirichletField_envelope_joint_law N root x ρ hroot hV) hsub bt7FreshSlabMass
    (normalizedDirichletMass_slab N root D hroot hV) B hB hbound
  refine hh.trans ?_
  change (∫ ξ, k*((b+T ξ)*Real.exp (8*(b+T ξ))*(if T ξ≤U then P else 1)) ∂finiteFieldLaw N)≤_
  rw [integral_const_mul]
  exact mul_le_mul_of_nonneg_left hweightedb hk

end TorusCoverTime.Blocks.B
