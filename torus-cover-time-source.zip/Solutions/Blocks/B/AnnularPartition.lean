import Solutions.Blocks.B.AnnularSupport

/-! A finite exact dyadic partition of the original Green multiplier, with both endpoints proved. -/

noncomputable section
open Classical
open scoped BigOperators
namespace TorusCoverTime.Blocks.B

lemma frequencyCutoff_one (N : Size) (R : ℝ) (hR : (N.val : ℝ) ≤ R) (k : Vertex N) :
    frequencyCutoff N R k = 1 := by
  have hN : 0 < (N.val : ℝ) := lt_trans zero_lt_one (size_real_gt_one N)
  have hRp : 0 < R := hN.trans_le hR
  have hc (b : ZMod N.val) : |frequencySineCoordinate N R b| ≤ 1 := by
    rw [frequencySineCoordinate_formula N R hRp.ne', abs_mul,
      abs_of_pos (div_pos hN (mul_pos Real.pi_pos hRp))]
    calc
      _ ≤ (N.val : ℝ) / (Real.pi * R) * 1 :=
        mul_le_mul_of_nonneg_left (Real.abs_sin_le_one _) (by positivity)
      _ ≤ 1 := by
        rw [mul_one]
        apply (div_le_one (by positivity)).mpr
        nlinarith [Real.two_le_pi]
  simp only [frequencyCutoff, rectangleCutoff, frequencyBump_one _ (hc k.1),
    frequencyBump_one _ (hc k.2), mul_one]

lemma frequencyCutoff_quarter_zero (N : Size) (k : Vertex N) (hk : k ≠ 0) :
    frequencyCutoff N (1 / 4) k = 0 := by
  have hc (b : ZMod N.val) (hb : b ≠ 0) : 2 ≤ |frequencySineCoordinate N (1 / 4) b| := by
    have hl := sineCoordinate_lower ((1 / 4) / N.val) ((b.valMinAbs : ℝ) / (1 / 4))
      (scaled_centered_fundamental N (1 / 4) (by norm_num) b)
    have hd : 1 ≤ |(b.valMinAbs : ℝ)| := by
      rw [← coordinateDistance_eq_abs_centered]
      exact coordinateDistance_nonzero_ge_one N b hb
    change 2 ≤ |sineCoordinate ((1 / 4) / N.val) ((b.valMinAbs : ℝ) / (1 / 4))|
    apply le_trans _ hl
    rw [abs_div, abs_of_pos (by norm_num : (0 : ℝ) < 1 / 4)]
    have hdiv : 2 / Real.pi * (|(b.valMinAbs : ℝ)| / (1 / 4)) =
        (8 * |(b.valMinAbs : ℝ)|) / Real.pi := by ring
    rw [hdiv]
    apply (le_div_iff₀ Real.pi_pos).mpr
    nlinarith [Real.pi_le_four]
  apply rectangleCutoff_zero
  by_cases h1 : k.1 = 0
  · exact Or.inr (hc k.2 (fun h2 => hk (Prod.ext h1 h2)))
  · exact Or.inl (hc k.1 h1)

lemma annularArray_zero_large_scale (N : Size) (R : ℝ) (hR : 2 ≤ R / N.val)
    (ds : List (Fin 4)) : annularArray N R ds = 0 := by
  have hN : 0 < (N.val : ℝ) := lt_trans zero_lt_one (size_real_gt_one N)
  have hh := (le_div_iff₀ hN).mp hR
  funext k
  simp only [annularArray, frequencyCutoff_one N R (by linarith),
    frequencyCutoff_one N (R / 2) (by linarith), sub_self, Complex.ofReal_zero, zero_mul,
    Pi.zero_apply]

def greenStepArray (N : Size) (ds : List (Fin 4)) (k : Vertex N) : ℂ :=
  greenMultiplier N k * (ds.map (fun d => finiteCharacter N k (direction N d) - 1)).prod

def dyadicFrequencyRadius (j : ℕ) : ℝ := (2 : ℝ) ^ j / 2

lemma dyadicFrequencyRadius_pos (j : ℕ) : 0 < dyadicFrequencyRadius j := by
  unfold dyadicFrequencyRadius
  positivity

lemma dyadicFrequencyRadius_lower (j : ℕ) : 1 / 4 ≤ dyadicFrequencyRadius j := by
  have h := one_le_pow₀ (show (1 : ℝ) ≤ 2 by norm_num) (n := j)
  dsimp [dyadicFrequencyRadius]
  linarith

lemma dyadicFrequencyRadius_succ_half (j : ℕ) :
    dyadicFrequencyRadius (j + 1) / 2 = dyadicFrequencyRadius j := by
  simp only [dyadicFrequencyRadius, pow_succ]
  ring

lemma annularArray_dyadic_sum (N : Size) (ds : List (Fin 4)) (J : ℕ) (k : Vertex N) :
    (∑ j ∈ Finset.range (J + 1), annularArray N (dyadicFrequencyRadius j) ds k) =
      (frequencyCutoff N (dyadicFrequencyRadius J) k : ℂ) * greenStepArray N ds k := by
  by_cases hk : k = 0
  · subst k
    simp [annularArray, greenStepArray, greenMultiplier]
  · induction J with
    | zero =>
      simp only [Finset.sum_range_succ, Finset.sum_range_zero, zero_add]
      change annularArray N (1 / 2) ds k = (frequencyCutoff N (1 / 2) k : ℂ) * greenStepArray N ds k
      rw [annularArray, show (1 / 2 : ℝ) / 2 = 1 / 4 by norm_num,
        frequencyCutoff_quarter_zero N k hk, sub_zero]
      exact mul_assoc _ _ _
    | succ J ih =>
      rw [Finset.sum_range_succ, ih]
      simp only [annularArray, dyadicFrequencyRadius_succ_half, Complex.ofReal_sub, greenStepArray]
      ring

lemma greenStepArray_finite_partition (N : Size) (ds : List (Fin 4)) :
    ∃ J : ℕ, ∀ k : Vertex N,
      greenStepArray N ds k = ∑ j ∈ Finset.range (J + 1), annularArray N (dyadicFrequencyRadius j) ds k := by
  obtain ⟨J, hJ⟩ := pow_unbounded_of_one_lt (2 * (N.val : ℝ)) (by norm_num : (1 : ℝ) < 2)
  refine ⟨J, fun k => ?_⟩
  rw [annularArray_dyadic_sum, frequencyCutoff_one N _ (by dsimp [dyadicFrequencyRadius]; linarith),
    Complex.ofReal_one, one_mul]

end TorusCoverTime.Blocks.B
