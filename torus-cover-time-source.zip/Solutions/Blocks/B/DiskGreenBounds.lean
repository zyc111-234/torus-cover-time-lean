import Solutions.Blocks.B.DirichletGreen
import Solutions.Blocks.B.GreenBounds
import Solutions.Blocks.B.DiskConnectivity
import Solutions.Blocks.D.Base.PinnedGreen

/-! Uniform logarithmic upper bounds for the actual disk Green function.
The comparison root is an actual exterior neighbor, so the bound depends on
the disk radius and not on the ambient torus size. -/

noncomputable section
open Classical
namespace TorusCoverTime.Blocks.B

theorem pinnedGreen_diagonal (N : Size) (r x : Vertex N) :
    Blocks.D.pinnedGreen N r x x = 2 * (greenDiagonal N - greenKernel N x r) := by
  unfold Blocks.D.pinnedGreen
  rw [greenKernel_diagonal, greenKernel_symm N r x]
  ring

theorem pinnedGreen_nonneg (N : Size) (r x y : Vertex N) :
    0 ≤ Blocks.D.pinnedGreen N r x y := by
  have hrep := punctured_harmonic_representation N (Finset.univ.erase r) y
    (fun z => Blocks.D.pinnedGreen N r z y) (by
      intro a ha
      have har : a = r := by simpa using ha
      subst a
      exact Blocks.D.pinnedGreen_root_left N r y) (by
      intro a ha hay
      have har := (Finset.mem_erase.mp ha).1
      have h := Blocks.D.pinnedGreen_killed_inverse N r a y har
      rw [if_neg hay] at h
      linarith)
  rw [congrFun hrep x, pinnedGreen_diagonal]
  have hd := green_difference_nonneg N y r
  rw [greenKernel_diagonal] at hd
  exact mul_nonneg (mul_nonneg (by norm_num) hd) (exitHarmonic_nonneg N _ y x)

theorem domainGreenFromBarrier_pinned_representation
    (N : Size) (D : Finset (Vertex N)) (b : Vertex N → ℝ)
    (hb : ∀ a ∈ D, -generator N b a = 1) (r : Vertex N) (hr : r ∉ D)
    (y : Vertex N) :
    (fun x => domainGreenFromBarrier N D b x y) =
      (fun x => Blocks.D.pinnedGreen N r x y -
        exitExtension N D (fun z => Blocks.D.pinnedGreen N r z y) x) := by
  have hD : D ≠ Finset.univ := by intro he; exact hr (he ▸ Finset.mem_univ r)
  apply domain_harmonic_unique N D hD
  · intro x hx
    rw [domainGreenFromBarrier_boundary N D b x y hx,
      exitExtension_boundary N D _ x hx, sub_self]
  · intro x hx
    have hxr : x ≠ r := by intro he; subst x; exact hr hx
    have h1 := domainGreenFromBarrier_generator N D b hb x y hx
    have h2 := Blocks.D.pinnedGreen_killed_inverse N r x y hxr
    change generator N (fun z => domainGreenFromBarrier N D b z y) x =
      generator N ((fun z => Blocks.D.pinnedGreen N r z y) -
        exitExtension N D (fun z => Blocks.D.pinnedGreen N r z y)) x
    rw [generator_sub, exitExtension_generator N D _ x hx, sub_zero]
    linarith

theorem domainGreenFromBarrier_le_pinned
    (N : Size) (D : Finset (Vertex N)) (b : Vertex N → ℝ)
    (hb : ∀ a ∈ D, -generator N b a = 1) (r : Vertex N) (hr : r ∉ D)
    (x y : Vertex N) :
    domainGreenFromBarrier N D b x y ≤ Blocks.D.pinnedGreen N r x y := by
  rw [congrFun (domainGreenFromBarrier_pinned_representation N D b hb r hr y) x]
  have hh : 0 ≤ exitExtension N D (fun z => Blocks.D.pinnedGreen N r z y) x :=
    Finset.sum_nonneg fun z _ => mul_nonneg (pinnedGreen_nonneg N r z y)
      (exitHarmonic_nonneg N D z x)
  linarith

theorem domainGreenFromBarrier_diagonal_log_bound
    (N : Size) (D : Finset (Vertex N)) (b : Vertex N → ℝ)
    (hb : ∀ a ∈ D, -generator N b a = 1) (r : Vertex N) (hr : r ∉ D)
    (x : Vertex N) :
    domainGreenFromBarrier N D b x x ≤
      2 * greenIncrementConstant * Real.log (2 + periodicDistance x r) := by
  have hp := domainGreenFromBarrier_le_pinned N D b hb r hr x x
  rw [pinnedGreen_diagonal] at hp
  have h := green_increment_log_bound N x r
  rw [greenKernel_diagonal] at h
  linarith

theorem diskExteriorNeighbor_radius (N : Size) (c : Vertex N) (R : ℝ)
    (b : Vertex N) (hb : diskExteriorNeighbor N c R b) :
    R ≤ periodicDistance b c ∧ periodicDistance b c < R + 1 := by
  refine ⟨le_of_not_gt (fun h => hb.1 ((mem_torusDisk N c b R).mpr h)), ?_⟩
  obtain ⟨z, hz, _, d, hd⟩ := hb.2
  have hs := periodicDistance_step_le N c z d
  rw [← hd] at hs
  have hzR := (mem_torusDisk N c z R).mp hz
  linarith

theorem diskExteriorNeighbor_distance (N : Size) (c : Vertex N) (R : ℝ)
    (b x : Vertex N) (hb : diskExteriorNeighbor N c R b) (hx : x ∈ torusDisk N c R) :
    periodicDistance x b < 2 * R + 1 := by
  have ht := periodicDistance_triangle N x c b
  have hsym : periodicDistance c b = periodicDistance b c := by
    unfold periodicDistance coordinateDistance
    simp only [abs_sub_comm]
  rw [hsym] at ht
  have hr := (diskExteriorNeighbor_radius N c R b hb).2
  have hxr := (mem_torusDisk N c x R).mp hx
  linarith

theorem diskGreen_diagonal_log_bound (N : Size) (c : Vertex N) (R : ℝ) (hR : 0 ≤ R)
    (hsmall : 2 * (R + 1) < N.val) (b x : Vertex N)
    (hb : diskExteriorNeighbor N c R b) (hx : x ∈ torusDisk N c R) :
    diskGreen N c R x x ≤ 2 * greenIncrementConstant * Real.log (3 + 2 * R) := by
  have h := domainGreenFromBarrier_diagonal_log_bound N (torusDisk N c R)
    (diskBarrier N c R) (fun a ha => diskBarrier_generator N c R hR hsmall a ha) b hb.1 x
  have hd := diskExteriorNeighbor_distance N c R b x hb hx
  have hd0 : 0 ≤ periodicDistance x b := Real.sqrt_nonneg _
  have hl : Real.log (2 + periodicDistance x b) ≤ Real.log (3 + 2 * R) :=
    Real.log_le_log (by linarith) (by linarith)
  exact h.trans (mul_le_mul_of_nonneg_left hl (mul_nonneg (by norm_num) greenIncrementConstant_pos.le))

end TorusCoverTime.Blocks.B
