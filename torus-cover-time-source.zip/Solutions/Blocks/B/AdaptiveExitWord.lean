import Solutions.Blocks.B.AdaptiveExitChain

/-! Actual endpoint words partition all paths. On each word, the adaptive
construction agrees with the fixed compatible chain already disintegrated. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

def adaptiveExitWord (N : Size) (D : ℕ → Finset (Vertex N)) (root : Vertex N)
    (n : ℕ) (ω : WalkSample) : Fin n → Vertex N :=
  fun j => adaptiveExitStart N D root (j.val+1) ω

def endpointWordEnd {N : Size} {n : ℕ} (root : Vertex N) (w : Fin n → Vertex N) (k : ℕ) : Vertex N :=
  if h : k < n then w ⟨k,h⟩ else root

def endpointWordStart {N : Size} {n : ℕ} (root : Vertex N) (w : Fin n → Vertex N) : ℕ → Vertex N
  | 0 => root
  | k+1 => endpointWordEnd root w k

@[simp] theorem endpointWordStart_zero {N : Size} {n : ℕ} (root : Vertex N) (w : Fin n → Vertex N) :
    endpointWordStart root w 0 = root := rfl

@[simp] theorem endpointWordStart_succ {N : Size} {n : ℕ} (root : Vertex N) (w : Fin n → Vertex N)
    (k : ℕ) : endpointWordStart root w (k+1) = endpointWordEnd root w k := rfl

theorem adaptiveExitWord_measurable (N : Size) (D : ℕ → Finset (Vertex N))
    (root : Vertex N) (n : ℕ) : Measurable (adaptiveExitWord N D root n) :=
  measurable_pi_lambda _ fun j => adaptiveExitStart_measurable N D root (j.val+1)

theorem adaptiveExitStart_of_word (N : Size) (D : ℕ → Finset (Vertex N))
    (root : Vertex N) (n : ℕ) (w : Fin n → Vertex N) (ω : WalkSample)
    (hw : adaptiveExitWord N D root n ω = w) (k : ℕ) (hk : k ≤ n) :
    adaptiveExitStart N D root k ω = endpointWordStart root w k := by
  cases k with
  | zero => simp
  | succ k =>
    have he := congrFun hw (⟨k, by omega⟩ : Fin n)
    simpa only [adaptiveExitWord, endpointWordStart_succ, endpointWordEnd, dif_pos (show k < n by omega)] using he

theorem adaptiveExitIndex_of_word (N : Size) (D : ℕ → Finset (Vertex N))
    (root : Vertex N) (n : ℕ) (w : Fin n → Vertex N) (ω : WalkSample)
    (hw : adaptiveExitWord N D root n ω = w) : ∀ k ≤ n,
    adaptiveExitIndex N D root k ω = exitChainIndex N D (endpointWordStart root w) k ω := by
  intro k
  induction k with
  | zero => intro _; simp
  | succ k ih =>
    intro hk
    rw [adaptiveExitIndex_succ, exitChainIndex_succ,
      adaptiveExitStart_of_word N D root n w ω hw k (by omega)]
    have ht : adaptiveExitTail N D root k ω = exitChainTail N D (endpointWordStart root w) k ω := by
      rw [exitChainTail_eq_shift]
      change (fun j => ω (adaptiveExitIndex N D root k ω+j)) = _
      rw [ih (by omega)]
    rw [ih (by omega), ht]

theorem adaptiveExitIndex_of_fixed (N : Size) (D : ℕ → Finset (Vertex N))
    (root : Vertex N) (n : ℕ) (w : Fin n → Vertex N) (ω : WalkSample)
    (hw : ω ∈ exitChainEndpoints N D (endpointWordStart root w) (endpointWordEnd root w) n) :
    ∀ k ≤ n, adaptiveExitIndex N D root k ω = exitChainIndex N D (endpointWordStart root w) k ω := by
  intro k
  induction k with
  | zero => intro _; simp
  | succ k ih =>
    intro hk
    have hp := exitChain_position N D (endpointWordStart root w) (endpointWordEnd root w) n
      (fun _ _ => rfl) ω hw k (by omega)
    rw [endpointWordStart_zero] at hp
    rw [adaptiveExitIndex_succ, exitChainIndex_succ]
    have ht : adaptiveExitTail N D root k ω = exitChainTail N D (endpointWordStart root w) k ω := by
      rw [exitChainTail_eq_shift]
      change (fun j => ω (adaptiveExitIndex N D root k ω+j)) = _
      rw [ih (by omega)]
    simp only [adaptiveExitStart, ih (by omega), hp, ht]

theorem adaptiveExitWord_of_fixed (N : Size) (D : ℕ → Finset (Vertex N))
    (root : Vertex N) (n : ℕ) (w : Fin n → Vertex N) (ω : WalkSample)
    (hw : ω ∈ exitChainEndpoints N D (endpointWordStart root w) (endpointWordEnd root w) n) :
    adaptiveExitWord N D root n ω = w := by
  funext j
  have hp := exitChain_position N D (endpointWordStart root w) (endpointWordEnd root w) n
    (fun _ _ => rfl) ω hw (j.val+1) (by omega)
  simp only [endpointWordStart_zero, endpointWordStart_succ, endpointWordEnd, dif_pos j.isLt] at hp
  change position N root ω (adaptiveExitIndex N D root (j.val+1) ω) = w j
  rw [adaptiveExitIndex_of_fixed N D root n w ω hw (j.val+1) (by omega)]
  exact hp

theorem adaptiveExitWord_event_eq_ae (N : Size) (D : ℕ → Finset (Vertex N))
    (hD : ∀ k, ∃ b : Vertex N, b ∉ D k) (root : Vertex N) (n : ℕ) (w : Fin n → Vertex N) :
    {ω | adaptiveExitWord N D root n ω = w} =ᵐ[walkLaw]
      exitChainEndpoints N D (endpointWordStart root w) (endpointWordEnd root w) n := by
  filter_upwards [adaptiveExit_spec_ae N D hD root] with ω hω
  apply propext
  constructor
  · intro hw
    change adaptiveExitWord N D root n ω = w at hw
    intro j
    have hs := hω j.val
    rw [adaptiveExitStart_of_word N D root n w ω hw j.val j.isLt.le,
      adaptiveExitStart_of_word N D root n w ω hw (j.val+1) (by omega), endpointWordStart_succ] at hs
    have ht : adaptiveExitTail N D root j.val ω =
        exitChainTail N D (endpointWordStart root w) j.val ω := by
      rw [exitChainTail_eq_shift]
      change (fun i => ω (adaptiveExitIndex N D root j.val ω+i)) = _
      rw [adaptiveExitIndex_of_word N D root n w ω hw j.val j.isLt.le]
    rw [ht] at hs
    change exitsThroughAt N (D j.val) (endpointWordStart root w j.val) (endpointWordEnd root w j.val)
      (finiteExitRecord N (D j.val) (endpointWordStart root w j.val)
        (exitChainTail N D (endpointWordStart root w) j.val ω)).2 _
    exact (exitsThroughAt_prefix N _ _ _ _ (finiteExitRecord_agrees N _ _ _)).mpr hs
  · exact adaptiveExitWord_of_fixed N D root n w ω

theorem conditional_measure_congr_event {Ω : Type*} [MeasurableSpace Ω]
    (μ : Measure Ω) {E F : Set Ω} (h : E =ᵐ[μ] F) : μ[|E] = μ[|F] := by
  unfold ProbabilityTheory.cond
  rw [measure_congr h, Measure.restrict_congr_set h]

theorem adaptiveExitWord_cond_eq (N : Size) (D : ℕ → Finset (Vertex N))
    (hD : ∀ k, ∃ b : Vertex N, b ∉ D k) (root : Vertex N) (n : ℕ) (w : Fin n → Vertex N) :
    walkLaw[|{ω | adaptiveExitWord N D root n ω = w}] =
      walkLaw[|exitChainEndpoints N D (endpointWordStart root w) (endpointWordEnd root w) n] :=
  conditional_measure_congr_event walkLaw (adaptiveExitWord_event_eq_ae N D hD root n w)

theorem adaptiveExitWord_lintegral_partition (N : Size) (D : ℕ → Finset (Vertex N))
    (root : Vertex N) (n : ℕ) (F : WalkSample → ℝ≥0∞) :
    (∫⁻ ω, F ω ∂walkLaw) = ∑ w : Fin n → Vertex N,
      ∫⁻ ω in {ω | adaptiveExitWord N D root n ω = w}, F ω ∂walkLaw := by
  have he : (Set.univ : Set WalkSample) = ⋃ w, {ω | adaptiveExitWord N D root n ω = w} := by ext ω; simp
  calc
    _ = ∫⁻ ω in (Set.univ : Set WalkSample), F ω ∂walkLaw := by rw [Measure.restrict_univ]
    _ = _ := by
      rw [he, lintegral_iUnion]
      · exact tsum_fintype _
      · intro w
        exact (adaptiveExitWord_measurable N D root n) (measurableSet_singleton w)
      · intro w v hwv
        apply Set.disjoint_left.mpr
        exact fun ω hw hv => hwv (hw.symm.trans hv)

end TorusCoverTime.Blocks.B
