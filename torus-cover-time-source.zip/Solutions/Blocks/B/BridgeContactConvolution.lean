import Solutions.Blocks.B.BridgeContactSeries

/-! Summing both three-halves survival costs retains the factor 1/n.
The estimate is finite, symmetric, and includes every middle index. -/

noncomputable section
open scoped BigOperators
namespace TorusCoverTime.Blocks.B

theorem bridge_contact_half (x y : ℝ) (hx : 0<x) (hy : 0<y) (hhalf : x+y ≤ 2*y) :
    Real.sqrt (x+y)/((x*Real.sqrt x)*(y*Real.sqrt y)) ≤ (4/(x+y))*(1/(x*Real.sqrt x)) := by
  have hn : 0<x+y := by positivity
  have hs : Real.sqrt (x+y) ≤ 2*Real.sqrt y := by
    nlinarith [Real.sq_sqrt hy.le,Real.sq_sqrt hn.le,Real.sqrt_nonneg (x+y),Real.sqrt_nonneg y]
  have hd : (x+y)*Real.sqrt (x+y) ≤ 4*(y*Real.sqrt y) := by
    have hh := mul_le_mul hhalf hs (Real.sqrt_nonneg _) (by positivity : 0≤2*y)
    nlinarith
  have hh : Real.sqrt (x+y)/(y*Real.sqrt y) ≤ 4/(x+y) :=
    (div_le_div_iff₀ (mul_pos hy (Real.sqrt_pos.mpr hy)) hn).mpr (by nlinarith [hd])
  calc
    _ = (Real.sqrt (x+y)/(y*Real.sqrt y))*(1/(x*Real.sqrt x)) := by ring
    _ ≤ _ := mul_le_mul_of_nonneg_right hh (by positivity)

theorem bridge_contact_symmetric (x y : ℝ) (hx : 0<x) (hy : 0<y) :
    Real.sqrt (x+y)/((x*Real.sqrt x)*(y*Real.sqrt y)) ≤
      (4/(x+y))*(1/(x*Real.sqrt x)+1/(y*Real.sqrt y)) := by
  rcases le_total x y with hxy | hyx
  · exact (bridge_contact_half x y hx hy (by linarith)).trans
      (mul_le_mul_of_nonneg_left (le_add_of_nonneg_right (by positivity)) (by positivity))
  · have hh := bridge_contact_half y x hy hx (by linarith)
    rw [add_comm y x,mul_comm (y*Real.sqrt y) (x*Real.sqrt x)] at hh
    exact hh.trans (mul_le_mul_of_nonneg_left (le_add_of_nonneg_left (by positivity)) (by positivity))

theorem bridge_contact_Icc_reflect (n r : ℕ) (hn : r ≤ n) (f : ℕ → ℝ) :
    (∑ k ∈ Finset.Icc r (n-r), f (n-k)) = ∑ k ∈ Finset.Icc r (n-r), f k := by
  apply Finset.sum_bij (fun k _ => n-k)
  · intro k hk
    have hh := Finset.mem_Icc.mp hk
    exact Finset.mem_Icc.mpr ⟨by omega,by omega⟩
  · intro i hi j hj hij
    have hi' := Finset.mem_Icc.mp hi
    have hj' := Finset.mem_Icc.mp hj
    omega
  · intro j hj
    have hh := Finset.mem_Icc.mp hj
    refine ⟨n-j,Finset.mem_Icc.mpr ⟨by omega,by omega⟩,?_⟩
    omega
  · intro k hk
    rfl

theorem bridge_contact_convolution (n r : ℕ) (hr : 1 ≤ r) (hrn : 2*r ≤ n) :
    (∑ k ∈ Finset.Icc r (n-r), Real.sqrt (n : ℝ)/
      (((k : ℝ)*Real.sqrt k)*(((n-k : ℕ) : ℝ)*Real.sqrt ((n-k : ℕ) : ℝ)))) ≤ 32/((n : ℝ)*Real.sqrt r) := by
  have hn : 0<n := by omega
  have hn0 : (0 : ℝ)<n := by exact_mod_cast hn
  calc
    _ ≤ ∑ k ∈ Finset.Icc r (n-r), (4/(n : ℝ))*(1/((k : ℝ)*Real.sqrt k)+1/(((n-k : ℕ) : ℝ)*Real.sqrt ((n-k : ℕ) : ℝ))) := by
      apply Finset.sum_le_sum
      intro k hk
      have hh := Finset.mem_Icc.mp hk
      have hk0 : (0 : ℝ)<k := by exact_mod_cast (show 0<k by omega)
      have hl0 : (0 : ℝ)<(n-k : ℕ) := by exact_mod_cast (show 0<n-k by omega)
      have he : (k : ℝ)+(n-k : ℕ)=n := by rw [Nat.cast_sub (by omega : k≤n)]; ring
      have hs := bridge_contact_symmetric (k : ℝ) ((n-k : ℕ) : ℝ) hk0 hl0
      rwa [he] at hs
    _ = (4/(n : ℝ))*((∑ k ∈ Finset.Icc r (n-r), 1/((k : ℝ)*Real.sqrt k))+
      ∑ k ∈ Finset.Icc r (n-r), 1/(((n-k : ℕ) : ℝ)*Real.sqrt ((n-k : ℕ) : ℝ))) := by rw [← Finset.mul_sum,Finset.sum_add_distrib]
    _ = (4/(n : ℝ))*(2*∑ k ∈ Finset.Icc r (n-r), 1/((k : ℝ)*Real.sqrt k)) := by
      rw [bridge_contact_Icc_reflect n r (by omega) (fun k => 1/((k : ℝ)*Real.sqrt k))]
      ring
    _ ≤ (4/(n : ℝ))*(2*(4/Real.sqrt r)) := by
      gcongr
      exact inverse_three_halves_Icc r (n-r) hr
    _ = _ := by ring

end TorusCoverTime.Blocks.B
