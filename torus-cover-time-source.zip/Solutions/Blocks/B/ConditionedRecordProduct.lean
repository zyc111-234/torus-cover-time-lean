import Solutions.Blocks.B.SequentialRecords
import Solutions.Blocks.B.ConditionedExitRestart

/-! Conditioning a whole independent record vector on its specified endpoint
events gives the product of the individual endpoint-conditioned record laws. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

theorem map_cond_preimage_law {Ω Z : Type*} [MeasurableSpace Ω] [MeasurableSpace Z]
    (μ : Measure Ω) (f : Ω → Z) (hf : Measurable f) (E : Set Z) (hE : MeasurableSet E) :
    (μ[|f ⁻¹' E]).map f = (μ.map f)[|E] := by
  ext S hS
  rw [Measure.map_apply hf hS, cond_apply (hE.preimage hf), cond_apply hE,
    Measure.map_apply hf hE, Measure.map_apply hf (hE.inter hS), preimage_inter]

theorem cond_pi_law {ι Z : Type*} [Fintype ι] [MeasurableSpace Z]
    (μ : ι → Measure Z) [∀ i, IsFiniteMeasure (μ i)]
    (E : ι → Set Z) (hE : ∀ i, MeasurableSet (E i)) :
    (Measure.pi μ)[|Set.pi Set.univ E] = Measure.pi (fun i => (μ i)[|E i]) := by
  symm
  apply Measure.pi_eq
  intro S hS
  rw [cond_apply (MeasurableSet.univ_pi hE), Measure.pi_pi]
  have he : Set.pi Set.univ E ∩ Set.pi Set.univ S =
      Set.pi Set.univ (fun i => E i ∩ S i) := by
    ext x
    simp only [mem_inter_iff, Set.mem_pi, mem_univ, forall_const, forall_and]
  rw [he, Measure.pi_pi]
  simp_rw [cond_apply (hE _)]
  rw [Finset.prod_mul_distrib, ENNReal.prod_inv_distrib]
  exact fun _ _ j _ _ => Or.inr (measure_ne_top (μ j) _)

theorem exactExitRecordLaw_eq_cond (N : Size) (D : Finset (Vertex N)) (a b : Vertex N) :
    exactExitRecordLaw N D a b =
      (walkLaw.map (finiteExitRecord N D a))[|exitRecordEvent N D a b] := by
  rw [exactExitRecordLaw, exactExitLaw, exitsThrough_eq_record_preimage,
    map_cond_preimage_law walkLaw _ (finiteExitRecord_measurable N D a) _
      (exitRecordEvent_measurable N D a b)]

def exitChainTail (N : Size) (D : ℕ → Finset (Vertex N)) (a : ℕ → Vertex N) :=
  sequentialTail (fun k => finiteExitTail N (D k) (a k))

def exitChainRecord (N : Size) (D : ℕ → Finset (Vertex N)) (a : ℕ → Vertex N) :=
  sequentialRecord (fun k => finiteExitRecord N (D k) (a k))
    (fun k => finiteExitTail N (D k) (a k))

def exitChainEndpoints (N : Size) (D : ℕ → Finset (Vertex N)) (a b : ℕ → Vertex N)
    (n : ℕ) : Set WalkSample :=
  {ω | ∀ j : Fin n, exitChainRecord N D a j.val ω ∈ exitRecordEvent N (D j.val) (a j.val) (b j.val)}

theorem exitChainTail_measurePreserving (N : Size) (D : ℕ → Finset (Vertex N))
    (hD : ∀ k, ∃ b : Vertex N, b ∉ D k) (a : ℕ → Vertex N) (k : ℕ) :
    MeasurePreserving (exitChainTail N D a k) walkLaw walkLaw :=
  sequentialTail_measurePreserving _ (fun j => finiteExitTail_measurePreserving N (D j) (hD j) (a j)) k

theorem exitChainRecord_measurable (N : Size) (D : ℕ → Finset (Vertex N))
    (hD : ∀ k, ∃ b : Vertex N, b ∉ D k) (a : ℕ → Vertex N) (k : ℕ) :
    Measurable (exitChainRecord N D a k) :=
  sequentialRecord_measurable _ _ (fun j => finiteExitRecord_measurable N (D j) (a j))
    (fun j => finiteExitTail_measurePreserving N (D j) (hD j) (a j)) k

theorem exitChainRecord_prefix_law (N : Size) (D : ℕ → Finset (Vertex N))
    (hD : ∀ k, ∃ b : Vertex N, b ∉ D k) (a : ℕ → Vertex N) (n : ℕ) :
    walkLaw.map (fun ω => fun j : Fin n => exitChainRecord N D a j.val ω) =
      Measure.pi (fun j : Fin n => walkLaw.map (finiteExitRecord N (D j.val) (a j.val))) :=
  sequentialRecord_prefix_law _ _ (fun j => finiteExitRecord_measurable N (D j) (a j))
    (fun j => finiteExitTail_measurePreserving N (D j) (hD j) (a j))
    (fun j => finiteExitRecord_tail_independent N (D j) (hD j) (a j)) n

theorem exitChainRecord_conditioned_law (N : Size) (D : ℕ → Finset (Vertex N))
    (hD : ∀ k, ∃ b : Vertex N, b ∉ D k) (a b : ℕ → Vertex N) (n : ℕ) :
    (walkLaw[|exitChainEndpoints N D a b n]).map
      (fun ω => fun j : Fin n => exitChainRecord N D a j.val ω) =
      Measure.pi (fun j : Fin n => exactExitRecordLaw N (D j.val) (a j.val) (b j.val)) := by
  let X := fun ω => fun j : Fin n => exitChainRecord N D a j.val ω
  let E := fun j : Fin n => exitRecordEvent N (D j.val) (a j.val) (b j.val)
  have hX : Measurable X := measurable_pi_lambda _ fun j => exitChainRecord_measurable N D hD a j.val
  have hE : MeasurableSet (Set.pi Set.univ E) :=
    MeasurableSet.univ_pi fun j => exitRecordEvent_measurable N (D j.val) (a j.val) (b j.val)
  have he : exitChainEndpoints N D a b n = X ⁻¹' Set.pi Set.univ E := by
    ext ω
    simp [exitChainEndpoints, X, E]
  rw [he, map_cond_preimage_law walkLaw X hX _ hE]
  change (walkLaw.map (fun ω => fun j : Fin n => exitChainRecord N D a j.val ω))[|Set.pi Set.univ E] = _
  rw [exitChainRecord_prefix_law N D hD a n, cond_pi_law _ E
    (fun j => exitRecordEvent_measurable N (D j.val) (a j.val) (b j.val))]
  dsimp only [E]
  simp_rw [← exactExitRecordLaw_eq_cond]

end TorusCoverTime.Blocks.B
