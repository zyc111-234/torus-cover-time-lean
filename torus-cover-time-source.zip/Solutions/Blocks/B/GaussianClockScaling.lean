import Solutions.Blocks.B.GaussianClockPath

/-! A change of field units scales the exact clock by the square factor. -/

noncomputable section
open MeasureTheory ProbabilityTheory
namespace TorusCoverTime.Blocks.B.GaussianClockPath
variable {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
variable {n : ℕ} (W : GaussianClockPath μ n)

def scale (s : ℝ) : GaussianClockPath μ n where
  path ω i := s*W.path ω i
  clock i := s^2*W.clock i
  measurable := by fun_prop
  gaussian := W.gaussian.map_fun (s • ContinuousLinearMap.id ℝ (Fin (n+1) → ℝ))
  mean_zero i := by rw [integral_const_mul, W.mean_zero, mul_zero]
  covariance i j := by
    rw [covariance_const_mul_left, covariance_const_mul_right, W.covariance]
    ring
  clock_zero := by rw [W.clock_zero, mul_zero]
  clock_mono := fun _ _ hij => mul_le_mul_of_nonneg_left (W.clock_mono hij) (sq_nonneg s)
  start_zero ω := by rw [W.start_zero, mul_zero]

end TorusCoverTime.Blocks.B.GaussianClockPath
