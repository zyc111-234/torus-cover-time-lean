import Mathlib.MeasureTheory.Integral.Bochner.Set
import Mathlib.MeasureTheory.Function.L1Space.Integrable
import Mathlib.MeasureTheory.Measure.WithDensity

/-! Eventwise total-variation control from an actual L1 density error, including
the normalization error. No probability comparison is assumed. -/

noncomputable section
open MeasureTheory Filter
open scoped ENNReal
namespace TorusCoverTime.Blocks.B

variable {α : Type*} [MeasurableSpace α]

def realDensityProbability (μ : Measure α) (f : α → ℝ) : Measure α :=
  (ENNReal.ofReal (∫ x, f x ∂μ))⁻¹ • μ.withDensity (fun x => ENNReal.ofReal (f x))

lemma realDensity_apply (μ : Measure α) (f : α → ℝ) (hf : Integrable f μ)
    (hn : ∀ x, 0 ≤ f x) (E : Set α) (hE : MeasurableSet E) :
    (μ.withDensity (fun x => ENNReal.ofReal (f x))).real E = ∫ x in E, f x ∂μ := by
  rw [measureReal_def, withDensity_apply _ hE,
    ← ofReal_integral_eq_lintegral_ofReal hf.integrableOn (Eventually.of_forall hn),
    ENNReal.toReal_ofReal (integral_nonneg hn)]

lemma integral_sub_event_abs_bound (μ : Measure α) (f g : α → ℝ)
    (hf : Integrable f μ) (hg : Integrable g μ) (E : Set α) :
    |(∫ x in E, f x ∂μ) - ∫ x in E, g x ∂μ| ≤ ∫ x, |f x - g x| ∂μ := by
  rw [← integral_sub hf.integrableOn hg.integrableOn]
  exact abs_integral_le_integral_abs.trans
    (setIntegral_le_integral (hf.sub hg).abs (Eventually.of_forall fun x => abs_nonneg _))

theorem realDensityProbability_event_bound (μ : Measure α) (f g : α → ℝ)
    (hf : Integrable f μ) (hg : Integrable g μ) (hfn : ∀ x, 0 ≤ f x) (hgn : ∀ x, 0 ≤ g x)
    (hm : 0 < ∫ x, f x ∂μ) (hg1 : (∫ x, g x ∂μ) = 1) (E : Set α) (hE : MeasurableSet E) :
    |(realDensityProbability μ f).real E - (μ.withDensity (fun x => ENNReal.ofReal (g x))).real E| ≤
      (2 / (∫ x, f x ∂μ)) * ∫ x, |f x - g x| ∂μ := by
  rw [realDensityProbability, measureReal_ennreal_smul_apply, ENNReal.toReal_inv,
    ENNReal.toReal_ofReal hm.le, realDensity_apply μ f hf hfn E hE,
    realDensity_apply μ g hg hgn E hE]
  let m := ∫ x, f x ∂μ
  let a := ∫ x in E, f x ∂μ
  let b := ∫ x in E, g x ∂μ
  let e := ∫ x, |f x - g x| ∂μ
  have hab : |a - b| ≤ e := integral_sub_event_abs_bound μ f g hf hg E
  have hmass : |m - 1| ≤ e := by
    have h := integral_sub_event_abs_bound μ f g hf hg Set.univ
    simpa [m, e, hg1] using h
  have hb0 : 0 ≤ b := integral_nonneg hgn
  have hb1 : b ≤ 1 := (setIntegral_le_integral hg (Eventually.of_forall hgn)).trans_eq hg1
  have he0 : 0 ≤ e := integral_nonneg fun x => abs_nonneg _
  have heq : m⁻¹ * a - b = ((a - b) + (1 - m) * b) / m := by
    field_simp [show m ≠ 0 from hm.ne'] ; ring
  change |m⁻¹ * a - b| ≤ 2 / m * e
  rw [heq, abs_div, abs_of_pos hm]
  have hmul : |(1 - m) * b| ≤ e := by
    rw [abs_mul, abs_of_nonneg hb0, abs_sub_comm]
    exact (mul_le_mul hmass hb1 hb0 he0).trans_eq (mul_one e)
  calc
    _ ≤ (|a - b| + |(1 - m) * b|) / m :=
      div_le_div_of_nonneg_right (abs_add_le _ _) hm.le
    _ ≤ (e + e) / m := div_le_div_of_nonneg_right (add_le_add hab hmul) hm.le
    _ = _ := by ring

end TorusCoverTime.Blocks.B
