import Solutions.Blocks.B.OddRecordReindex

/-! Uniform R6/R7 bounds for every positive actual traversal word. Entrance
geometry and nonzero conditioning probabilities follow from that word's
support; they are not extra inputs to the concentration estimate. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

def traversalWordRecordLaw (N : Size) (I O : Finset (Vertex N)) (root : Vertex N)
    (m : ℕ) (w : Fin (2*m) → Vertex N) (j : Fin (2*m)) : Measure (ℕ × WalkSample) :=
  exactExitRecordLaw N (alternatingDomain N I O j.val)
    (endpointWordStart root w j.val) (endpointWordEnd root w j.val)

def traversalWordOutwardLaw (N : Size) (I O : Finset (Vertex N)) (root : Vertex N)
    (m : ℕ) (w : Fin (2*m) → Vertex N) : Measure ({j : Fin (2*m) // j.val % 2 = 1} → ℕ × WalkSample) :=
  Measure.pi (fun j => traversalWordRecordLaw N I O root m w j.val)

theorem traversalWordRecordLaw_probability (N : Size) (I O : Finset (Vertex N)) (root : Vertex N)
    (hI : I.Nonempty) (hr : root ∉ O) (m : ℕ) (w : Fin (2*m) → Vertex N)
    (hw : walkLaw {ω | adaptiveExitWord N (alternatingDomain N I O) root (2*m) ω = w} ≠ 0) :
    ∀ j, IsProbabilityMeasure (traversalWordRecordLaw N I O root m w j) := by
  have hp := adaptiveExitWord_positive_factors N _ (alternatingDomain_proper N I O hI ⟨root,hr⟩) root (2*m) w hw
  intro j
  have : IsProbabilityMeasure (exactExitLaw N (alternatingDomain N I O j.val)
      (endpointWordStart root w j.val) (endpointWordEnd root w j.val)) := cond_isProbabilityMeasure (hp j)
  exact Measure.isProbabilityMeasure_map (finiteExitRecord_measurable N _ _).aemeasurable

theorem traversalWordOutwardLaw_probability (N : Size) (I O : Finset (Vertex N)) (root : Vertex N)
    (hI : I.Nonempty) (hr : root ∉ O) (m : ℕ) (w : Fin (2*m) → Vertex N)
    (hw : walkLaw {ω | adaptiveExitWord N (alternatingDomain N I O) root (2*m) ω = w} ≠ 0) :
    IsProbabilityMeasure (traversalWordOutwardLaw N I O root m w) := by
  have := traversalWordRecordLaw_probability N I O root hI hr m w hw
  unfold traversalWordOutwardLaw
  infer_instance

theorem traversalWordOutwardLaw_duration (N : Size) (I O : Finset (Vertex N)) (root : Vertex N)
    (hI : I.Nonempty) (hr : root ∉ O) (m : ℕ) (w : Fin (2*m) → Vertex N)
    (hw : walkLaw {ω | adaptiveExitWord N (alternatingDomain N I O) root (2*m) ω = w} ≠ 0) (d : ℝ) :
    traversalWordOutwardLaw N I O root m w {p | d < ∑ j, excursionRecordDuration (p j)} =
      exactExitRecordProductLaw N O m (fun i => endpointWordStart root w (2*i.val+1))
        (fun i => endpointWordEnd root w (2*i.val+1)) {p | d < recordsDuration m p} := by
  rw [← outwardRecordProjection_law N I O root hI hr m w hw,
    Measure.map_apply (outwardRecordProjection_measurable m)
      (measurableSet_lt measurable_const (recordsDuration_measurable m))]
  congr 1
  ext p
  simp only [Set.mem_preimage,Set.mem_ofPred_eq,outwardRecordProjection_duration]

def traversalWordOutwardOccupation (N : Size) (root : Vertex N) (m : ℕ)
    (w : Fin (2*m) → Vertex N) (U : Vertex N → ℝ)
    (p : {j : Fin (2*m) // j.val % 2 = 1} → ℕ × WalkSample) : ℝ :=
  recordProductOccupation N m (fun i => endpointWordStart root w (2*i.val+1)) U (outwardRecordProjection m p)

theorem traversalWordOutwardOccupation_measurable (N : Size) (root : Vertex N) (m : ℕ)
    (w : Fin (2*m) → Vertex N) (U : Vertex N → ℝ) :
    Measurable (traversalWordOutwardOccupation N root m w U) :=
  (recordProductOccupation_measurable N m _ U).comp (outwardRecordProjection_measurable m)

theorem r7_positive_word_upper (hWalk : WalkModelRegular) (γ : ℝ) (hγ : 0 < γ) (hγ1 : γ ≤ 1) :
    ∀ᶠ q : ℝ in atTop, ∀ N : Size, ∀ c root : Vertex N, ∀ m : ℕ, ∀ w : Fin (2*m) → Vertex N,
      root ∉ torusDisk N c (Real.exp (q+2*q^γ)) → 2*(Real.exp (q+2*q^γ)+1) < N.val →
      walkLaw {ω | adaptiveExitWord N (alternatingDomain N (torusDisk N c (Real.exp (q+q^γ)))
        (torusDisk N c (Real.exp (q+2*q^γ)))) root (2*m) ω = w} ≠ 0 →
      ∀ v Δ : ℝ, 0 ≤ v → (m:ℝ)*q^γ ≤ v^2 → 0 ≤ Δ →
      2*r7MeanConstant*Real.exp (-r7MeanExponent*q^γ)*v ≤ Δ → Δ ≤ v →
      (traversalWordOutwardLaw N (torusDisk N c (Real.exp (q+q^γ)))
        (torusDisk N c (Real.exp (q+2*q^γ))) root m w).real {p | v+Δ < Real.sqrt
          (traversalWordOutwardOccupation N root m w (fun z => diskHarmonicWeight N c (Real.exp (q+1)) z/g) p)} ≤
        2*Real.exp (-(r7ConcentrationConstant/4)*Δ^2/q^γ) := by
  filter_upwards [r7_record_sqrt_upper_concentration hWalk γ hγ hγ1,eventually_ge_atTop (0:ℝ)] with q hq hq0
  intro N c root m w hr hsmall hw v Δ hv hmv hΔ hlo hhi
  have hrad : Real.exp (q+q^γ) ≤ Real.exp (q+2*q^γ) :=
    Real.exp_le_exp.mpr (by linarith [Real.rpow_nonneg hq0 γ])
  have hgeo := diskTraversal_positive_word_geometry N c root _ _ (Real.exp_pos _) hrad hr m w hw
  let U := fun z => diskHarmonicWeight N c (Real.exp (q+1)) z/g
  have hE : MeasurableSet {p : Fin m → ℕ × WalkSample | v+Δ < Real.sqrt (recordProductOccupation N m
      (fun i => endpointWordStart root w (2*i.val+1)) U p)} :=
    measurableSet_lt measurable_const (recordProductOccupation_measurable N m _ U).sqrt
  have hh := congrArg (fun μ => μ {p : Fin m → ℕ × WalkSample | v+Δ < Real.sqrt
      (recordProductOccupation N m (fun i => endpointWordStart root w (2*i.val+1)) U p)})
    (outwardRecordProjection_law N _ _ root (torusDisk_nonempty N c _ (Real.exp_pos _)) hr m w hw)
  rw [Measure.map_apply (outwardRecordProjection_measurable m) hE] at hh
  exact (congrArg ENNReal.toReal hh).le.trans (hq N c m _ _ hsmall
    (fun i => (hgeo i).1.trans (by norm_num)) (fun i => (hgeo i).2) v Δ hv hmv hΔ hlo hhi)

theorem r6_positive_word_duration (hWalk : WalkModelRegular) (γ : ℝ) (hγ : 0 < γ) (hγ1 : γ ≤ 1) :
    ∀ᶠ N : Size in atTop, ∀ c root : Vertex N, ∀ m : ℕ, ∀ w : Fin (2*m) → Vertex N, ∀ q : ℝ,
      (logSize N)^(16*γ) ≤ q → q ≤ logSize N-(logSize N)^(16*γ) → (m:ℝ) ≤ (logSize N)^4+1 →
      root ∉ torusDisk N c (Real.exp (q+2*q^γ)) →
      walkLaw {ω | adaptiveExitWord N (alternatingDomain N (torusDisk N c (Real.exp (q+q^γ)))
        (torusDisk N c (Real.exp (q+2*q^γ)))) root (2*m) ω = w} ≠ 0 →
      traversalWordOutwardLaw N (torusDisk N c (Real.exp (q+q^γ))) (torusDisk N c (Real.exp (q+2*q^γ))) root m w
        {p | (m:ℝ)*Real.exp (2*logSize N-(logSize N)^(16*γ)) < ∑ j, excursionRecordDuration (p j)} ≤
        ENNReal.ofReal (Real.exp (-Real.exp ((logSize N)^(16*γ)/2))) := by
  filter_upwards [r6_record_coarse_duration hWalk γ hγ hγ1] with N hN
  intro c root m w q hq hqL hm hr hw
  have hq0 : 0 ≤ q := (Real.rpow_nonneg (logSize_pos N).le _).trans hq
  have hrad : Real.exp (q+q^γ) ≤ Real.exp (q+2*q^γ) :=
    Real.exp_le_exp.mpr (by linarith [Real.rpow_nonneg hq0 γ])
  have hgeo := diskTraversal_positive_word_geometry N c root _ _ (Real.exp_pos _) hrad hr m w hw
  rw [traversalWordOutwardLaw_duration N _ _ root (torusDisk_nonempty N c _ (Real.exp_pos _)) hr m w hw]
  exact hN c m _ _ q hq hqL hm (fun i => (hgeo i).1.trans (by norm_num)) (fun i => (hgeo i).2)

end TorusCoverTime.Blocks.B
