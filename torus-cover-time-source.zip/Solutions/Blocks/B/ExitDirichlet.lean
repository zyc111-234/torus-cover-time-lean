import Solutions.Blocks.B.ExitHarmonic

/-! Uniqueness and the exact harmonic-measure representation for a proper
finite torus domain. The kernel is the actual exterior exit distribution. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

theorem domain_harmonic_unique (N : Size) (D : Finset (Vertex N)) (hD : D ≠ Finset.univ)
    (f g : Vertex N → ℝ) (hb : ∀ x, x ∉ D → f x = g x)
    (hg : ∀ x, x ∈ D → generator N f x = generator N g x) : f = g := by
  have he : energy N (f - g) = 0 := by
    unfold energy
    apply Finset.sum_eq_zero
    intro x _
    by_cases hx : x ∈ D
    · rw [generator_sub, hg x hx, sub_self, neg_zero, mul_zero]
    · simp only [Pi.sub_apply, hb x hx, sub_self, zero_mul]
  have hex : ∃ r, r ∉ D := by
    by_contra hn
    push Not at hn
    exact hD (Finset.eq_univ_of_forall hn)
  obtain ⟨r, hr⟩ := hex
  have hc := energy_zero_constant N (f - g) he
  have hz := hc r
  simp only [Pi.sub_apply, hb r hr, sub_self] at hz
  funext x
  have hx := hc x
  simp only [Pi.sub_apply] at hx
  linarith

def exitExtension (N : Size) (D : Finset (Vertex N)) (f : Vertex N → ℝ) : Vertex N → ℝ :=
  fun a => ∑ b, f b * exitHarmonic N D b a

theorem exitExtension_boundary (N : Size) (D : Finset (Vertex N)) (f : Vertex N → ℝ)
    (a : Vertex N) (ha : a ∉ D) : exitExtension N D f a = f a := by
  unfold exitExtension
  simp only [exitHarmonic_boundary N D _ a ha, mul_ite, mul_one, mul_zero]
  simp

theorem exitExtension_generator (N : Size) (D : Finset (Vertex N)) (f : Vertex N → ℝ)
    (a : Vertex N) (ha : a ∈ D) : generator N (exitExtension N D f) a = 0 := by
  unfold exitExtension
  rw [generator_sum]
  apply Finset.sum_eq_zero
  intro b _
  rw [generator_mul_left, exitHarmonic_generator N D b a ha, mul_zero]

theorem harmonic_exit_representation (N : Size) (D : Finset (Vertex N)) (hD : D ≠ Finset.univ)
    (f : Vertex N → ℝ) (hf : ∀ a ∈ D, generator N f a = 0) :
    f = exitExtension N D f := by
  apply domain_harmonic_unique N D hD
  · intro a ha
    exact (exitExtension_boundary N D f a ha).symm
  · intro a ha
    rw [hf a ha, exitExtension_generator N D f a ha]

theorem exitHarmonic_sum_one (N : Size) (D : Finset (Vertex N)) (hD : D ≠ Finset.univ)
    (a : Vertex N) : (∑ b, exitHarmonic N D b a) = 1 := by
  have h := congrFun (harmonic_exit_representation N D hD (fun _ => (1 : ℝ))
    (fun a _ => generator_const N 1 a)) a
  simpa only [exitExtension, one_mul] using h.symm

theorem harmonic_exit_bounds (N : Size) (D : Finset (Vertex N)) (hD : D ≠ Finset.univ)
    (f : Vertex N → ℝ) (hf : ∀ a ∈ D, generator N f a = 0)
    (l u : ℝ) (hb : ∀ b, b ∉ D → l ≤ f b ∧ f b ≤ u) (a : Vertex N) : l ≤ f a ∧ f a ≤ u := by
  have hz (b : Vertex N) (hb : b ∈ D) : exitHarmonic N D b a = 0 := by
    unfold exitHarmonic
    have he : exitsThrough N D a b = ∅ := by
      ext ω
      simp only [exitsThrough, Set.mem_ofPred_eq, Set.mem_empty_iff_false, iff_false, not_exists]
      intro n hn
      exact hn.1 hb
    rw [he, measureReal_empty]
  have he := congrFun (harmonic_exit_representation N D hD f hf) a
  rw [he]
  constructor
  · calc
      l = ∑ b, l * exitHarmonic N D b a := by rw [← Finset.mul_sum, exitHarmonic_sum_one N D hD a, mul_one]
      _ ≤ _ := Finset.sum_le_sum (fun b _ => by
        by_cases hbD : b ∈ D
        · rw [hz b hbD, mul_zero, mul_zero]
        · exact mul_le_mul_of_nonneg_right (hb b hbD).1 (exitHarmonic_nonneg N D b a))
  · calc
      _ ≤ ∑ b, u * exitHarmonic N D b a := Finset.sum_le_sum (fun b _ => by
        by_cases hbD : b ∈ D
        · rw [hz b hbD, mul_zero, mul_zero]
        · exact mul_le_mul_of_nonneg_right (hb b hbD).2 (exitHarmonic_nonneg N D b a))
      _ = u := by rw [← Finset.mul_sum, exitHarmonic_sum_one N D hD a, mul_one]

end TorusCoverTime.Blocks.B
