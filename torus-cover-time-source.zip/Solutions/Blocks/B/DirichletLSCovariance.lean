import Solutions.Blocks.B.DirichletHarmonicRegression

/-! Coordinates and covariances in the paper's LS units, on the original
finite Fourier sample space. -/

noncomputable section
open MeasureTheory ProbabilityTheory
namespace TorusCoverTime.Blocks.B
open Blocks.C.C4

def dirichletKernelLS (N : Size) (root : Vertex N) (D : Finset (Vertex N))
    (x y : Vertex N) : ℝ := pinnedDomainKernel N root D x y/(2*g)

def dirichletLSCoordinateMap (N : Size) (root : Vertex N) (D : Finset (Vertex N))
    (x : Vertex N) : FiniteFieldSample N →L[ℝ] ℝ :=
  (1/Real.sqrt (2*g)) • Blocks.D.pinnedProjectionMap N root (domainResidualWeight N D x)

theorem dirichletLSCoordinateMap_apply (N : Size) (root : Vertex N) (D : Finset (Vertex N))
    (x : Vertex N) (ξ : FiniteFieldSample N) :
    dirichletLSCoordinateMap N root D x ξ=dirichletFieldLS N root D ξ x := by
  simp only [dirichletLSCoordinateMap,smul_apply,smul_eq_mul,Blocks.D.pinnedProjectionMap_apply,
    dirichletFieldLS,pinnedDomainField]
  ring

@[fun_prop] theorem dirichletFieldLS_measurable (N : Size) (root : Vertex N)
    (D : Finset (Vertex N)) (x : Vertex N) : Measurable (fun ξ => dirichletFieldLS N root D ξ x) := by
  have hh := (dirichletLSCoordinateMap N root D x).continuous.measurable
  change Measurable (fun ξ => dirichletLSCoordinateMap N root D x ξ) at hh
  simpa only [dirichletLSCoordinateMap_apply] using hh

theorem dirichletFieldLS_gaussian (N : Size) (root : Vertex N) (D : Finset (Vertex N)) (x : Vertex N) :
    HasGaussianLaw (fun ξ => dirichletFieldLS N root D ξ x) (finiteFieldLaw N) := by
  simpa only [dirichletLSCoordinateMap_apply,id_eq] using
    (Blocks.D.finiteFieldSample_gaussian N).map_fun (dirichletLSCoordinateMap N root D x)

theorem dirichletFieldLS_memLp (N : Size) (root : Vertex N) (D : Finset (Vertex N)) (x : Vertex N) :
    MemLp (fun ξ => dirichletFieldLS N root D ξ x) 2 (finiteFieldLaw N) :=
  (dirichletFieldLS_gaussian N root D x).memLp_two

theorem dirichletFieldLS_mean (N : Size) (root : Vertex N) (D : Finset (Vertex N)) (x : Vertex N) :
    (∫ ξ, dirichletFieldLS N root D ξ x ∂finiteFieldLaw N)=0 := by
  unfold dirichletFieldLS
  rw [integral_div,pinnedDomainField_mean,zero_div]

theorem dirichletFieldLS_covariance (N : Size) (root : Vertex N) (D : Finset (Vertex N))
    (hroot : root∉D) (x y : Vertex N) :
    cov[fun ξ => dirichletFieldLS N root D ξ x,fun ξ => dirichletFieldLS N root D ξ y;finiteFieldLaw N]=
      dirichletKernelLS N root D x y := by
  unfold dirichletFieldLS dirichletKernelLS
  rw [covariance_fun_div_left,covariance_fun_div_right,pinnedDomainField_covariance N root D hroot,
    div_div,← sq,Real.sq_sqrt (by unfold g; positivity)]

theorem dirichletFieldLS_variance (N : Size) (root : Vertex N) (D : Finset (Vertex N))
    (hroot : root∉D) (x : Vertex N) :
    Var[fun ξ => dirichletFieldLS N root D ξ x;finiteFieldLaw N]=dirichletClockLS N root D x := by
  rw [← covariance_self (dirichletFieldLS_gaussian N root D x).aemeasurable,
    dirichletFieldLS_covariance N root D hroot]
  rfl

theorem dirichletFieldLS_covariance_nested (N : Size) (root : Vertex N) (D E : Finset (Vertex N))
    (hDE : D⊆E) (hroot : root∉D) (x y : Vertex N) :
    cov[fun ξ => dirichletFieldLS N root D ξ x,fun ξ => dirichletFieldLS N root E ξ y;finiteFieldLaw N]=
      dirichletKernelLS N root D x y := by
  unfold dirichletFieldLS dirichletKernelLS
  rw [covariance_fun_div_left,covariance_fun_div_right,pinnedDomainField_covariance_nested N root D E hDE hroot,
    div_div,← sq,Real.sq_sqrt (by unfold g; positivity)]

theorem dirichletFieldLS_covariance_nested_rev (N : Size) (root : Vertex N) (D E : Finset (Vertex N))
    (hDE : D⊆E) (hroot : root∉D) (x y : Vertex N) :
    cov[fun ξ => dirichletFieldLS N root E ξ x,fun ξ => dirichletFieldLS N root D ξ y;finiteFieldLaw N]=
      dirichletKernelLS N root D x y := by
  unfold dirichletFieldLS dirichletKernelLS
  rw [covariance_fun_div_left,covariance_fun_div_right,pinnedDomainField_covariance_nested_rev N root D E hDE hroot,
    div_div,← sq,Real.sq_sqrt (by unfold g; positivity)]

end TorusCoverTime.Blocks.B
