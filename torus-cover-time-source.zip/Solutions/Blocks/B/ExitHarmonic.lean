import Solutions.Blocks.B.FiniteExitWords
import Solutions.Blocks.B.WalkRenewal
import Solutions.Blocks.B.EnergyAlgebra

/-! The actual exact-exit probabilities are harmonic, with the original
exterior endpoint retained. These are concrete kernels, not assumed
Harnack functions. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

theorem exitsThroughAt_succ_shift (N : Size) (D : Finset (Vertex N)) (a b : Vertex N)
    (ω : WalkSample) (n : ℕ) :
    exitsThroughAt N D a b ω (n + 1) ↔ a ∈ D ∧
      exitsThroughAt N D (a + direction N (ω 0).2) b (walkTail ω) n := by
  constructor
  · rintro ⟨hb, hend, hpre⟩
    refine ⟨by simpa [position] using hpre ⟨0, by omega⟩, hb, ?_, ?_⟩
    · rw [position_succ_shift] at hend
      exact hend
    · intro j
      have h := hpre ⟨j.val + 1, by omega⟩
      rw [position_succ_shift] at h
      exact h
  · rintro ⟨ha, hb, hend, hpre⟩
    refine ⟨hb, ?_, ?_⟩
    · rw [position_succ_shift]
      exact hend
    · rintro ⟨j, hj⟩
      cases j with
      | zero => simpa [position] using ha
      | succ j =>
        have h := hpre ⟨j, by omega⟩
        rw [position_succ_shift]
        exact h

theorem exitsThrough_shift (N : Size) (D : Finset (Vertex N)) (a b : Vertex N)
    (ha : a ∈ D) (ω : WalkSample) :
    ω ∈ exitsThrough N D a b ↔
      walkTail ω ∈ exitsThrough N D (a + direction N (ω 0).2) b := by
  constructor
  · rintro ⟨n, hn⟩
    cases n with
    | zero =>
      have hab : a = b := by simpa [position] using hn.2.1
      exact False.elim (hn.1 (hab ▸ ha))
    | succ n => exact ⟨n, ((exitsThroughAt_succ_shift N D a b ω n).mp hn).2⟩
  · rintro ⟨n, hn⟩
    exact ⟨n + 1, (exitsThroughAt_succ_shift N D a b ω n).mpr ⟨ha, hn⟩⟩

theorem exitsThrough_outside (N : Size) (D : Finset (Vertex N)) (a b : Vertex N)
    (ha : a ∉ D) (ω : WalkSample) : ω ∈ exitsThrough N D a b ↔ a = b := by
  constructor
  · rintro ⟨n, hn⟩
    cases n with
    | zero => simpa [position] using hn.2.1
    | succ n => exact False.elim (ha ((exitsThroughAt_succ_shift N D a b ω n).mp hn).1)
  · intro hab
    subst b
    exact ⟨0, ha, by simp [position], by intro j; exact Fin.elim0 j⟩

def exitHarmonic (N : Size) (D : Finset (Vertex N)) (b a : Vertex N) : ℝ :=
  walkLaw.real (exitsThrough N D a b)

theorem exitHarmonic_eq_integral (N : Size) (D : Finset (Vertex N)) (b a : Vertex N) :
    exitHarmonic N D b a = ∫ ω, if ω ∈ exitsThrough N D a b then (1 : ℝ) else 0 ∂walkLaw :=
  (integral_indicator_one (measurableSet_exitsThrough N D a b)).symm

theorem exitHarmonic_nonneg (N : Size) (D : Finset (Vertex N)) (b a : Vertex N) :
    0 ≤ exitHarmonic N D b a := ENNReal.toReal_nonneg

theorem exitHarmonic_le_one (N : Size) (D : Finset (Vertex N)) (b a : Vertex N) :
    exitHarmonic N D b a ≤ 1 := measureReal_le_one

theorem exitHarmonic_first_step (N : Size) (D : Finset (Vertex N)) (b a : Vertex N) (ha : a ∈ D) :
    exitHarmonic N D b a = (∑ d : Fin 4, exitHarmonic N D b (a + direction N d)) / 4 := by
  rw [exitHarmonic_eq_integral]
  have he (ω : WalkSample) : (if ω ∈ exitsThrough N D a b then (1 : ℝ) else 0) =
      Real.exp (-(0 : ℝ) * holdingTime ω 0) *
        (if walkTail ω ∈ exitsThrough N D (a + direction N (ω 0).2) b then 1 else 0) := by
    rw [exitsThrough_shift N D a b ha ω]
    simp
  simp_rw [he]
  have h := integral_first_step_weighted 0 le_rfl
    (fun d ω => if ω ∈ exitsThrough N D (a + direction N d) b then (1 : ℝ) else 0)
    (fun d => measurable_const.ite (measurableSet_exitsThrough N D _ b) measurable_const)
    (by intro d ω; split_ifs <;> norm_num)
  simpa only [zero_add, add_zero, one_mul, mul_one, ← exitHarmonic_eq_integral] using h

theorem exitHarmonic_boundary (N : Size) (D : Finset (Vertex N)) (b a : Vertex N) (ha : a ∉ D) :
    exitHarmonic N D b a = if a = b then 1 else 0 := by
  rw [exitHarmonic_eq_integral]
  simp_rw [exitsThrough_outside N D a b ha]
  simp

theorem exitHarmonic_generator (N : Size) (D : Finset (Vertex N)) (b a : Vertex N) (ha : a ∈ D) :
    generator N (exitHarmonic N D b) a = 0 := by
  have h := exitHarmonic_first_step N D b a ha
  simp only [generator, Finset.sum_sub_distrib, Finset.sum_const, Finset.card_univ,
    Fintype.card_fin, nsmul_eq_mul, Nat.cast_ofNat]
  linarith

theorem exitHarmonic_neighbor_le (N : Size) (D : Finset (Vertex N)) (b a : Vertex N)
    (ha : a ∈ D) (d : Fin 4) :
    exitHarmonic N D b (a + direction N d) ≤ 4 * exitHarmonic N D b a := by
  have h := Finset.single_le_sum (fun e _ => exitHarmonic_nonneg N D b (a + direction N e))
    (Finset.mem_univ d)
  rw [exitHarmonic_first_step N D b a ha]
  linarith

end TorusCoverTime.Blocks.B
