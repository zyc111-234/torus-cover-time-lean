import Solutions.Blocks.B.DiskHarmonicMeasure
import Solutions.Blocks.D.Base.GaussianProjection

/-! Exact covariance of the torus field averaged against disk exit weights.
The finite-torus correction appears twice and is bounded explicitly. This
gives the sharp (L-q)/2 variance scale used by the R7 image Gaussian tail. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal NNReal
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

def diskCenterCorrection (N : Size) (c : Vertex N) (R : ℝ) : ℝ :=
  (1/vertexCount N)*(diskBarrier N c R c-exitExtension N (torusDisk N c R) (diskBarrier N c R) c)

theorem disk_harmonic_kernel_average (N : Size) (c : Vertex N) (R : ℝ) (y : Vertex N) :
    (∑ z, diskHarmonicWeight N c R z*greenKernel N z y) =
      greenKernel N c y+diskCenterCorrection N c R-diskGreen N c R c y := by
  have he : exitExtension N (torusDisk N c R) (fun z => greenKernel N z y) c =
      ∑ z, diskHarmonicWeight N c R z*greenKernel N z y := by
    unfold exitExtension diskHarmonicWeight
    apply Finset.sum_congr rfl
    intro z _
    ring
  unfold diskGreen domainGreenFromBarrier
  rw [he]
  unfold diskCenterCorrection
  ring

theorem disk_harmonic_green_boundary_zero (N : Size) (c : Vertex N) (R : ℝ)
    (hR : 0 < R) (hsmall : 2*(R+1) < N.val) (y : Vertex N) :
    diskHarmonicWeight N c R y*diskGreen N c R c y = 0 := by
  by_cases hy : diskHarmonicWeight N c R y = 0
  · rw [hy,zero_mul]
  · have hout := (diskHarmonicWeight_support N c R hR y hy).1
    rw [diskGreen_symm N c R hR.le hsmall]
    change diskHarmonicWeight N c R y*domainGreenFromBarrier N _ _ y c = 0
    rw [domainGreenFromBarrier_boundary N _ _ y c hout,mul_zero]

theorem disk_harmonic_covariance_identity (N : Size) (c : Vertex N) (R : ℝ)
    (hR : 0 < R) (hsmall : 2*(R+1) < N.val) :
    (∑ x, ∑ y, diskHarmonicWeight N c R x*greenKernel N x y*diskHarmonicWeight N c R y) =
      greenDiagonal N-diskGreen N c R c c+2*diskCenterCorrection N c R := by
  have hsum := diskHarmonicWeight_sum N c R hR.le hsmall
  calc
    _ = ∑ y, diskHarmonicWeight N c R y*(∑ x, diskHarmonicWeight N c R x*greenKernel N x y) := by
      rw [Finset.sum_comm]
      apply Finset.sum_congr rfl
      intro y _
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro x _
      ring
    _ = ∑ y, diskHarmonicWeight N c R y*(greenKernel N c y+diskCenterCorrection N c R-diskGreen N c R c y) := by
      simp_rw [disk_harmonic_kernel_average]
    _ = (∑ y, diskHarmonicWeight N c R y*greenKernel N y c)+diskCenterCorrection N c R := by
      simp only [mul_sub,mul_add,disk_harmonic_green_boundary_zero N c R hR hsmall,sub_zero,
        Finset.sum_add_distrib,← Finset.sum_mul,hsum,one_mul,greenKernel_symm N c]
    _ = _ := by
      rw [disk_harmonic_kernel_average,greenKernel_diagonal]
      ring

def harmonicGaussianAverage (N : Size) (c : Vertex N) (q : ℝ) (ξ : FiniteFieldSample N) : ℝ :=
  (Real.sqrt (2*g))⁻¹*D.fieldProjection N (diskHarmonicWeight N c (Real.exp (q+1))) ξ

theorem harmonicGaussianAverage_gaussian (N : Size) (c : Vertex N) (q : ℝ) :
    HasGaussianLaw (harmonicGaussianAverage N c q) (finiteFieldLaw N) := by
  have h := (D.fieldProjection_gaussian N (diskHarmonicWeight N c (Real.exp (q+1)))).smul (Real.sqrt (2*g))⁻¹
  change HasGaussianLaw (fun ξ => (Real.sqrt (2*g))⁻¹*
    D.fieldProjection N (diskHarmonicWeight N c (Real.exp (q+1))) ξ) (finiteFieldLaw N) at h
  exact h

theorem harmonicGaussianAverage_mean (N : Size) (c : Vertex N) (q : ℝ) :
    (∫ ξ, harmonicGaussianAverage N c q ξ ∂finiteFieldLaw N) = 0 := by
  unfold harmonicGaussianAverage
  rw [integral_const_mul,D.fieldProjection_mean,mul_zero]

def harmonicVarianceErrorConstant : ℝ :=
  (greenDiagonalErrorConstant+diskGreenLogErrorConstant+2)/(2*g)

theorem harmonicVarianceErrorConstant_pos : 0 < harmonicVarianceErrorConstant := by
  have := greenDiagonalErrorConstant_pos
  have := diskGreenLogErrorConstant_pos
  unfold harmonicVarianceErrorConstant g
  positivity

theorem harmonicGaussianAverage_variance_bound (N : Size) (c : Vertex N) (q : ℝ) (hq : 0 ≤ q)
    (hsmall : 2*(Real.exp (q+1)+1) < N.val) :
    Var[harmonicGaussianAverage N c q;finiteFieldLaw N] ≤ (logSize N-q)/2+harmonicVarianceErrorConstant := by
  have hg : 0 < g := by unfold g; positivity
  let R := Real.exp (q+1)
  have hR : 1 ≤ R := Real.one_le_exp_iff.mpr (by linarith)
  have hcov := D.fieldProjection_covariance N (diskHarmonicWeight N c R) (diskHarmonicWeight N c R)
  rw [covariance_self (D.fieldProjection_gaussian N _).aemeasurable,
    disk_harmonic_covariance_identity N c R (Real.exp_pos _) hsmall] at hcov
  have hD := diskGreen_diagonal_precise N c R hR hsmall c (by rw [periodicDistance_self_zero]; positivity)
  have hG := abs_le.mp (greenDiagonal_log_error N)
  have hC := abs_le.mp (diskBarrier_correction_bound N c R (Real.exp_pos _).le hsmall c)
  change -1 ≤ diskCenterCorrection N c R ∧ diskCenterCorrection N c R ≤ 1 at hC
  have hlog : Real.log R = q+1 := Real.log_exp _
  rw [hlog] at hD
  unfold harmonicGaussianAverage
  rw [variance_const_mul,hcov,inv_pow,Real.sq_sqrt (by positivity : 0 ≤ 2*g)]
  change (2*g)⁻¹*(greenDiagonal N-diskGreen N c R c c+2*diskCenterCorrection N c R) ≤ _
  have hb : greenDiagonal N-diskGreen N c R c c+2*diskCenterCorrection N c R ≤
      g*(logSize N-q)+greenDiagonalErrorConstant+diskGreenLogErrorConstant+2 := by
    have hd := (abs_le.mp hD).1
    linarith
  calc
    _ ≤ (2*g)⁻¹*(g*(logSize N-q)+greenDiagonalErrorConstant+diskGreenLogErrorConstant+2) :=
      mul_le_mul_of_nonneg_left hb (by positivity)
    _ = _ := by
      unfold harmonicVarianceErrorConstant
      field_simp [hg.ne']
      <;> ring

end TorusCoverTime.Blocks.B
