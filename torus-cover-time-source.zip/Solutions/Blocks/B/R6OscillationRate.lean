import Solutions.Blocks.B.ExitOscillation

/-! R6.5 with an explicit positive exponent, uniformly on the entire
twice-entrance-radius disk. The number of contractions grows with q. -/

noncomputable section
open Filter Classical
open scoped Topology
namespace TorusCoverTime.Blocks.B

def diskExitOscillationExponent : ℝ :=
  -Real.log diskOscillationFactor/(2*Real.log diskOscillationScale)

def diskExitOscillationConstant : ℝ := diskHarnackConstant/diskOscillationFactor

theorem diskExitOscillationExponent_pos : 0 < diskExitOscillationExponent := by
  have hF := Real.log_neg diskOscillationFactor_bounds.1 diskOscillationFactor_bounds.2
  have hS := Real.log_pos (show 1 < diskOscillationScale by
    linarith [diskOscillationScale_ge_two])
  exact div_pos (neg_pos.mpr hF) (by positivity)

theorem diskExitOscillationConstant_pos : 0 < diskExitOscillationConstant :=
  div_pos (zero_lt_one.trans diskHarnackConstant_gt_one) diskOscillationFactor_bounds.1

def diskOscillationSteps (w : ℝ) : ℕ := ⌊w/(2*Real.log diskOscillationScale)⌋₊

theorem diskOscillationSteps_scale (w : ℝ) (hw : 0 ≤ w) :
    diskOscillationScale^(diskOscillationSteps w) ≤ Real.exp (w/2) := by
  have hS : 0 < Real.log diskOscillationScale := Real.log_pos (by
    linarith [diskOscillationScale_ge_two])
  have hk : ((diskOscillationSteps w):ℝ) ≤ w/(2*Real.log diskOscillationScale) :=
    Nat.floor_le (by positivity)
  rw [← Real.rpow_natCast, Real.rpow_def_of_pos (by linarith [diskOscillationScale_ge_two])]
  apply Real.exp_le_exp.mpr
  have h := (le_div_iff₀ (by positivity : 0 < 2*Real.log diskOscillationScale)).mp hk
  nlinarith

theorem diskOscillationSteps_decay (w : ℝ) :
    diskHarnackConstant*diskOscillationFactor^(diskOscillationSteps w) ≤
      diskExitOscillationConstant*Real.exp (-diskExitOscillationExponent*w) := by
  have hF := diskOscillationFactor_bounds.1
  have hlog := Real.log_neg hF diskOscillationFactor_bounds.2
  have hk : w/(2*Real.log diskOscillationScale) < ((diskOscillationSteps w):ℝ)+1 :=
    Nat.lt_floor_add_one _
  have hmul := mul_le_mul_of_nonpos_left (show
    w/(2*Real.log diskOscillationScale)-1 ≤ ((diskOscillationSteps w):ℝ) by linarith) hlog.le
  have hexp := Real.exp_le_exp.mpr hmul
  have heq : Real.exp (Real.log diskOscillationFactor*
      (w/(2*Real.log diskOscillationScale)-1)) =
      Real.exp (-diskExitOscillationExponent*w)/diskOscillationFactor := by
    rw [show Real.log diskOscillationFactor*(w/(2*Real.log diskOscillationScale)-1) =
      -diskExitOscillationExponent*w-Real.log diskOscillationFactor by
        unfold diskExitOscillationExponent; ring,
      Real.exp_sub, Real.exp_log hF]
  rw [heq] at hexp
  have hh := mul_le_mul_of_nonneg_left hexp
    (show 0 ≤ diskHarnackConstant from (zero_lt_one.trans diskHarnackConstant_gt_one).le)
  rw [← Real.rpow_natCast, Real.rpow_def_of_pos hF]
  simpa only [diskExitOscillationConstant, div_mul_eq_mul_div, mul_div_assoc] using hh

theorem r6_oscillation_rate_geometry (γ : ℝ) (hγ : 0 < γ) :
    ∀ᶠ q : ℝ in atTop,
      3*diskHarnackRadiusThreshold ≤ Real.exp (q+2*q^γ) ∧
      2*diskHarnackRadiusThreshold ≤
        (Real.exp (q+2*q^γ)/(24*diskGreenInnerScale))/diskOscillationScale^(diskOscillationSteps (q^γ)) ∧
      2*Real.exp (q+q^γ) ≤
        (Real.exp (q+2*q^γ)/(24*diskGreenInnerScale))/diskOscillationScale^(diskOscillationSteps (q^γ)) := by
  have hL := diskGreenInnerScale_ge_four
  have hL0 : 0 < diskGreenInnerScale := by linarith
  have hS0 : 0 < diskOscillationScale := by linarith [diskOscillationScale_ge_two]
  have hT0 : 0 < 3*diskHarnackRadiusThreshold := by linarith [diskHarnackRadiusThreshold_ge_one]
  filter_upwards [eventually_ge_atTop (1:ℝ),
    eventually_ge_atTop (Real.log (3*diskHarnackRadiusThreshold)),
    (tendsto_rpow_atTop hγ).eventually_ge_atTop (2*Real.log (192*diskGreenInnerScale))]
      with q hq hqt hqw
  have hw0 : 0 ≤ q^γ := Real.rpow_nonneg (by linarith) _
  have hρ0 := Real.exp_pos (q+q^γ)
  have hρT : 3*diskHarnackRadiusThreshold ≤ Real.exp (q+q^γ) := by
    have h := Real.exp_le_exp.mpr (hqt.trans (by linarith : q ≤ q+q^γ))
    rwa [Real.exp_log hT0] at h
  have hw : 192*diskGreenInnerScale ≤ Real.exp (q^γ/2) := by
    have h := Real.exp_le_exp.mpr (show Real.log (192*diskGreenInnerScale) ≤ q^γ/2 by linarith)
    simpa only [Real.exp_log (by positivity : 0 < 192*diskGreenInnerScale)] using h
  have hpow := diskOscillationSteps_scale (q^γ) hw0
  have hexp : 192*diskGreenInnerScale*diskOscillationScale^(diskOscillationSteps (q^γ)) ≤
      Real.exp (q^γ) := by
    have hm := mul_le_mul hw hpow (pow_nonneg hS0.le _) (Real.exp_pos _).le
    simpa only [← Real.exp_add, add_halves] using hm
  have hRρ : 8*Real.exp (q+q^γ) ≤
      (Real.exp (q+2*q^γ)/(24*diskGreenInnerScale))/diskOscillationScale^(diskOscillationSteps (q^γ)) := by
    rw [div_div]
    apply (le_div_iff₀ (by positivity)).mpr
    rw [show q+2*q^γ = (q+q^γ)+q^γ by ring, Real.exp_add (q+q^γ) (q^γ)]
    have hm := mul_le_mul_of_nonneg_left hexp hρ0.le
    nlinarith
  refine ⟨?_, by linarith, by linarith⟩
  exact hρT.trans (Real.exp_le_exp.mpr (by linarith))

theorem r6_exit_ratio_exponential (γ : ℝ) (hγ : 0 < γ) :
    ∀ᶠ q : ℝ in atTop, ∀ N : Size, ∀ c b z z' : Vertex N,
      2*(Real.exp (q+2*q^γ)+1) < N.val →
      diskExteriorNeighbor N c (Real.exp (q+2*q^γ)) b →
      z ∈ torusDisk N c (2*Real.exp (q+q^γ)) →
      z' ∈ torusDisk N c (2*Real.exp (q+q^γ)) →
      |exitHarmonic N (torusDisk N c (Real.exp (q+2*q^γ))) b z /
        exitHarmonic N (torusDisk N c (Real.exp (q+2*q^γ))) b z'-1| ≤
          diskExitOscillationConstant*Real.exp (-diskExitOscillationExponent*q^γ) := by
  filter_upwards [r6_oscillation_rate_geometry γ hγ] with q hq
  intro N c b z z' hsmall hb hz hz'
  have hzR := (mem_torusDisk N c z _).mpr (((mem_torusDisk N c z _).mp hz).trans_le hq.2.2)
  have hzR' := (mem_torusDisk N c z' _).mpr (((mem_torusDisk N c z' _).mp hz').trans_le hq.2.2)
  exact (disk_exit_relative_oscillation N c _ hq.1 hsmall z' b z hb
    (diskOscillationSteps (q^γ)) hq.2.1 hzR' hzR).trans (diskOscillationSteps_decay (q^γ))

end TorusCoverTime.Blocks.B
