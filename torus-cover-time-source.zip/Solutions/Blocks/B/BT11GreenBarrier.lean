import Solutions.Blocks.B.BT11KernelAction

/-! A Green barrier gives a lower bound on survival with rate-one killing
at a point. This uses the proved occupation kernel, not a new hitting axiom. -/
noncomputable section
open MeasureTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

theorem bt11_green_lower (hWalk : WalkModelRegular) (N : Size) (a c : Vertex N) :
    -17≤greenKernel N a c := by
  have hn := vertexCount_pos N
  have he : Real.exp (-4)≤(1/2:ℝ) := by
    rw [Real.exp_neg]
    apply (inv_le_comm₀ (Real.exp_pos _) (by norm_num)).mpr
    norm_num
    linarith [Real.add_one_le_exp (4:ℝ)]
  have hq : Real.exp (-(4*vertexCount N/vertexCount N))≤(1/2:ℝ) := by
    simpa only [mul_div_cancel_right₀ _ hn.ne'] using he
  have hs := eigenmode_sum_bound N (vertexCount N) hn.le hq
  have ht := (tailGreen_abs_le_eigenmode_sum N (vertexCount N) a c).trans hs
  have ht' : |tailGreen N (vertexCount N) a c|≤8 := by
    have hh := mul_le_mul_of_nonneg_left hq (by norm_num : (0:ℝ)≤16)
    exact ht.trans (by linarith)
  have ho := ((fourier_walk_identities hWalk).2.2.1 N (vertexCount N) hn.le a c).2
  have hp : 0≤∫ ω,localTime N a ω (vertexCount N) c ∂walkLaw :=
    integral_nonneg (fun ω => localTime_nonneg N a c ω _)
  rw [ho,div_self hn.ne'] at hp
  linarith [(abs_le.mp ht').1]

def bt11GreenDenom (N : Size) : ℝ := greenDiagonal N+18

theorem bt11GreenDenom_pos (N : Size) : 0<bt11GreenDenom N := by
  have := greenDiagonal_pos N
  unfold bt11GreenDenom
  linarith

def bt11GreenBarrier (N : Size) (c x : Vertex N) : ℝ :=
  (greenDiagonal N+1-greenKernel N x c)/bt11GreenDenom N

theorem bt11GreenBarrier_bounds (hWalk : WalkModelRegular) (N : Size) (c x : Vertex N) :
    0≤bt11GreenBarrier N c x ∧ bt11GreenBarrier N c x≤1 := by
  have hg := green_difference_nonneg N x c
  rw [greenKernel_diagonal] at hg
  have hlo := bt11_green_lower hWalk N x c
  constructor
  · exact div_nonneg (by linarith) (bt11GreenDenom_pos N).le
  · apply (div_le_one (bt11GreenDenom_pos N)).mpr
    unfold bt11GreenDenom
    linarith

theorem bt11GreenBarrier_generator (N : Size) (c x : Vertex N) :
    generator N (bt11GreenBarrier N c) x-(if x=c then bt11GreenBarrier N c x else 0)=
      -(vertexCount N*bt11GreenDenom N)⁻¹ := by
  have hf : bt11GreenBarrier N c = fun y => (bt11GreenDenom N)⁻¹*
      ((fun _ : Vertex N => greenDiagonal N+1)-(fun y => greenKernel N y c)) y := by
    funext y
    simp only [bt11GreenBarrier,Pi.sub_apply,div_eq_mul_inv,mul_comm]
  rw [hf,generator_mul_left,generator_sub,generator_const]
  have hg := greenKernel_generator N x c
  by_cases hxc : x=c
  · subst x
    simp only [if_true] at hg ⊢
    simp only [Pi.sub_apply,greenKernel_diagonal]
    rw [neg_eq_iff_eq_neg.mp hg]
    field_simp [(vertexCount_pos N).ne',(bt11GreenDenom_pos N).ne']
    <;> ring
  · simp only [if_neg hxc,sub_zero,zero_sub] at hg ⊢
    rw [hg]
    simp only [mul_inv_rev,one_div]
    ring

theorem bt11KillAction_barrier_deriv (N : Size) (c a : Vertex N) (t : ℝ) :
    HasDerivAt (fun s => bt11KillAction N c s (bt11GreenBarrier N c) a)
      (-(vertexCount N*bt11GreenDenom N)⁻¹*bt11KillAction N c t (fun _ => 1) a) t := by
  have hd := bt11KillAction_hasDerivAt N c a (bt11GreenBarrier N c) t
  simp_rw [bt11GreenBarrier_generator] at hd
  simpa only [bt11KillAction,mul_one,one_mul,Finset.mul_sum,mul_comm] using hd

theorem bt11_killing_row_deficit (hWalk : WalkModelRegular) (N : Size) (c a : Vertex N)
    (T : ℝ) (hT : 0≤T) :
    1-bt11KillAction N c T (fun _ => 1) a≤
      (17+greenKernel N a c+T/vertexCount N)/bt11GreenDenom N := by
  let r := (vertexCount N*bt11GreenDenom N)⁻¹
  let F := fun t => bt11KillAction N c t (bt11GreenBarrier N c) a+r*t
  have hr : 0≤r := by dsimp [r]; exact inv_nonneg.mpr (mul_nonneg (vertexCount_pos N).le (bt11GreenDenom_pos N).le)
  have hd (t : ℝ) : HasDerivAt F (r*(1-bt11KillAction N c t (fun _ => 1) a)) t := by
    convert (bt11KillAction_barrier_deriv N c a t).add ((hasDerivAt_id t).const_mul r) using 1 <;>
      (try rfl)
    dsimp [r]
    ring
  have hmono : MonotoneOn F (Ici 0) := monotoneOn_of_hasDerivWithinAt_nonneg (convex_Ici 0)
    (continuous_iff_continuousAt.mpr (fun t => (hd t).continuousAt)).continuousOn
    (fun t _ => (hd t).hasDerivWithinAt)
    (fun t ht => mul_nonneg hr (sub_nonneg.mpr
      (bt11KillAction_one_le N c a t (interior_subset ht))))
  have hm := hmono (by simp : (0:ℝ)∈Ici 0) (mem_Ici.mpr hT) hT
  have hc := bt11KillAction_mono N c a T hT (fun x => (bt11GreenBarrier_bounds hWalk N c x).2)
  dsimp only [F] at hm
  rw [bt11KillAction_zero,mul_zero,add_zero] at hm
  have hid : 1-bt11GreenBarrier N c a+r*T=
      (17+greenKernel N a c+T/vertexCount N)/bt11GreenDenom N := by
    unfold bt11GreenBarrier r bt11GreenDenom
    field_simp [(vertexCount_pos N).ne',show greenDiagonal N+18≠0 from (bt11GreenDenom_pos N).ne']
    <;> ring
  linarith

end TorusCoverTime.Blocks.B
