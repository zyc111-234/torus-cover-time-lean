import Solutions.Blocks.B.BT7Goal
import Solutions.Blocks.B.DirichletMassRegression

noncomputable section
open MeasureTheory ProbabilityTheory Classical
open scoped BigOperators
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B
open Blocks.C.C4

def periodicLSCoordinateMap (N : Size) (x : Vertex N) : FiniteFieldSample N →L[ℝ] ℝ :=
  (1/Real.sqrt (2*g)) • Blocks.D.finiteFieldEvaluation N x
def harmonicBindingLS (N : Size) (root : Vertex N) (D : Finset (Vertex N))
    (ξ : FiniteFieldSample N) (x : Vertex N) : ℝ :=
  centerFiniteField N (pinnedBindingField N root D ξ) x/Real.sqrt (2*g)
def harmonicBindingLSMap (N : Size) (root : Vertex N) (D : Finset (Vertex N)) (x : Vertex N) :
    FiniteFieldSample N →L[ℝ] ℝ :=
  periodicLSCoordinateMap N x-dirichletLSCoordinateMap N root D x+(1/vertexCount N) • dirichletMassMap N root D

theorem periodicLSCoordinateMap_apply (N : Size) (x : Vertex N) (ξ : FiniteFieldSample N) :
    periodicLSCoordinateMap N x ξ=periodicFieldLS N ξ x := by
  simp only [periodicLSCoordinateMap,smul_apply,smul_eq_mul,Blocks.D.finiteFieldEvaluation_apply,periodicFieldLS]
  ring

theorem periodicFieldLS_decomposition (N : Size) (root : Vertex N) (D : Finset (Vertex N))
    (ξ : FiniteFieldSample N) (x : Vertex N) :
    periodicFieldLS N ξ x=dirichletFieldLS N root D ξ x-dirichletMass N root D ξ/vertexCount N+
      harmonicBindingLS N root D ξ x := by
  have he := congrFun (finiteGaussianField_domain_decomposition N root D ξ) x
  change finiteGaussianField N ξ x=pinnedDomainField N root D ξ x-spatialMean N (pinnedDomainField N root D ξ)+
    centerFiniteField N (pinnedBindingField N root D ξ) x at he
  unfold periodicFieldLS harmonicBindingLS dirichletFieldLS dirichletMass
  simp only [dirichletFieldLS,← Finset.sum_div]
  rw [he]
  unfold spatialMean
  ring

theorem harmonicBindingLSMap_apply (N : Size) (root : Vertex N) (D : Finset (Vertex N))
    (x : Vertex N) (ξ : FiniteFieldSample N) :
    harmonicBindingLSMap N root D x ξ=harmonicBindingLS N root D ξ x := by
  have he := periodicFieldLS_decomposition N root D ξ x
  simp only [harmonicBindingLSMap,add_apply,sub_apply,smul_apply,smul_eq_mul,
    periodicLSCoordinateMap_apply,dirichletLSCoordinateMap_apply,dirichletMassMap_apply]
  rw [one_div_mul_eq_div]
  linarith

@[fun_prop] theorem periodicFieldLS_measurable (N : Size) : Measurable (periodicFieldLS N) := by
  apply measurable_pi_lambda
  intro x
  have h := (periodicLSCoordinateMap N x).continuous.measurable
  change Measurable (fun ξ => periodicLSCoordinateMap N x ξ) at h
  simpa only [periodicLSCoordinateMap_apply] using h
theorem periodicFieldLS_gaussian (N : Size) (x : Vertex N) :
    HasGaussianLaw (fun ξ => periodicFieldLS N ξ x) (finiteFieldLaw N) := by
  simpa only [id_eq,periodicLSCoordinateMap_apply] using
    (Blocks.D.finiteFieldSample_gaussian N).map_fun (periodicLSCoordinateMap N x)
theorem periodicFieldLS_mean (N : Size) (x : Vertex N) :
    (∫ ξ, periodicFieldLS N ξ x ∂finiteFieldLaw N)=0 := by
  unfold periodicFieldLS
  rw [integral_div,Blocks.C.finiteGaussianField_mean,zero_div]

@[fun_prop] theorem harmonicBindingLS_measurable (N : Size) (root : Vertex N) (D : Finset (Vertex N)) :
    Measurable (harmonicBindingLS N root D) := by
  apply measurable_pi_lambda
  intro x
  have h := (harmonicBindingLSMap N root D x).continuous.measurable
  change Measurable (fun ξ => harmonicBindingLSMap N root D x ξ) at h
  simpa only [harmonicBindingLSMap_apply] using h
theorem harmonicBindingLS_gaussian (N : Size) (root : Vertex N) (D : Finset (Vertex N)) (x : Vertex N) :
    HasGaussianLaw (fun ξ => harmonicBindingLS N root D ξ x) (finiteFieldLaw N) := by
  simpa only [id_eq,harmonicBindingLSMap_apply] using
    (Blocks.D.finiteFieldSample_gaussian N).map_fun (harmonicBindingLSMap N root D x)
theorem harmonicBindingLS_mean (N : Size) (root : Vertex N) (D : Finset (Vertex N)) (x : Vertex N) :
    (∫ ξ, harmonicBindingLS N root D ξ x ∂finiteFieldLaw N)=0 := by
  have he : (fun ξ => harmonicBindingLS N root D ξ x)=fun ξ =>
      periodicFieldLS N ξ x-dirichletFieldLS N root D ξ x+dirichletMass N root D ξ/vertexCount N := by
    funext ξ
    linarith [periodicFieldLS_decomposition N root D ξ x]
  have hp := (periodicFieldLS_gaussian N x).memLp_two.integrable (by norm_num)
  have hd := (dirichletFieldLS_memLp N root D x).integrable (by norm_num)
  have hm := (dirichletMass_gaussian N root D).memLp_two.integrable (by norm_num)
  have hsub : Integrable (fun ξ => periodicFieldLS N ξ x-dirichletFieldLS N root D ξ x) (finiteFieldLaw N) := hp.sub hd
  rw [he,integral_add hsub (hm.div_const _),integral_sub hp hd,integral_div,
    periodicFieldLS_mean,dirichletFieldLS_mean,dirichletMass_mean]
  ring

theorem dirichletFieldLS_indep_harmonicBinding (N : Size) (root : Vertex N) (D : Finset (Vertex N))
    (hroot : root∉D) : IndepFun (dirichletFieldLS N root D) (harmonicBindingLS N root D) (finiteFieldLaw N) := by
  exact (pinnedDomainField_indep_binding N root D hroot).comp
    (show Measurable (fun f : Vertex N → ℝ => fun x => f x/Real.sqrt (2*g)) by fun_prop)
    (show Measurable (fun f : Vertex N → ℝ => fun x => centerFiniteField N f x/Real.sqrt (2*g)) by
      apply measurable_pi_lambda; intro x; exact ((measurable_pi_apply x).comp (centerFiniteField_measurable N)).div_const _)

theorem harmonicBindingLS_harmonic (N : Size) (root : Vertex N) (D : Finset (Vertex N))
    (ξ : FiniteFieldSample N) (x : Vertex N) (hx : x∈D) : generator N (harmonicBindingLS N root D ξ) x=0 := by
  have he := centeredBinding_harmonic N root D ξ x hx
  unfold harmonicBindingLS generator at *
  simp only [div_sub_div_same,← Finset.sum_div]
  rw [← mul_div_assoc,he,zero_div]

end TorusCoverTime.Blocks.B
