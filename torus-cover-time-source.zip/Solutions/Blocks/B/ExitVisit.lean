import Solutions.Blocks.B.OccupationHolding
import Solutions.Blocks.B.DirectionSelectedHolding

/-! First visits before the actual exit, their dependence only on directions, and the
holding-time contribution that they force in the physical occupation integral. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Classical
open scoped ENNReal Topology BigOperators
namespace TorusCoverTime.Blocks.B

def skeletonSample (d : ℕ → Fin 4) : WalkSample := fun j => (1, d j)

lemma measurable_skeletonSample : Measurable skeletonSample := by
  unfold skeletonSample
  fun_prop

@[simp] lemma position_skeletonSample_directions (N : Size) (a : Vertex N)
    (ω : WalkSample) (j : ℕ) :
    position N a (skeletonSample (walkDirections ω)) j = position N a ω j := rfl

@[simp] lemma finiteExitIndex_skeletonSample_directions (N : Size) (D : Finset (Vertex N))
    (a : Vertex N) (ω : WalkSample) :
    finiteExitIndex N D a (skeletonSample (walkDirections ω)) = finiteExitIndex N D a ω := rfl

lemma exitsThrough_direction_preimage (N : Size) (D : Finset (Vertex N)) (a b : Vertex N) :
    walkDirections ⁻¹' (skeletonSample ⁻¹' exitsThrough N D a b) = exitsThrough N D a b := by
  ext ω
  simp [exitsThrough, exitsThroughAt]

def firstVisitIndex (N : Size) (a x : Vertex N) (ω : WalkSample) : ℕ :=
  if h : ∃ j : ℕ, position N a ω j = x then Nat.find h else 0

lemma measurable_firstVisitIndex (N : Size) (a x : Vertex N) :
    Measurable (firstVisitIndex N a x) := by
  let E : Set WalkSample := {ω | ∃ j : ℕ, position N a ω j = x}
  have hE : MeasurableSet E := by
    simp only [E, Set.ofPred_exists]
    exact MeasurableSet.iUnion fun j => (measurable_position_eq N a x j).setOf
  have hf : Measurable (fun ω : E => Nat.find ω.property) := by
    apply measurable_find
    intro j
    exact (measurable_position_eq N a x j).setOf.preimage measurable_subtype_coe
  exact hf.dite (measurable_const (a := (0 : ℕ))) hE

@[simp] lemma firstVisitIndex_skeletonSample_directions (N : Size) (a x : Vertex N)
    (ω : WalkSample) :
    firstVisitIndex N a x (skeletonSample (walkDirections ω)) = firstVisitIndex N a x ω := rfl

def visitsBeforeExit (N : Size) (D : Finset (Vertex N)) (a x : Vertex N) : Set WalkSample :=
  {ω | ∃ j : ℕ, j < finiteExitIndex N D a ω ∧ position N a ω j = x}

lemma measurableSet_visitsBeforeExit (N : Size) (D : Finset (Vertex N)) (a x : Vertex N) :
    MeasurableSet (visitsBeforeExit N D a x) := by
  simp only [visitsBeforeExit, Set.ofPred_exists, Set.ofPred_and]
  exact MeasurableSet.iUnion fun j =>
    (measurableSet_lt measurable_const (measurable_finiteExitIndex N D a)).inter
      (measurable_position_eq N a x j).setOf

lemma visitsBeforeExit_direction_preimage (N : Size) (D : Finset (Vertex N)) (a x : Vertex N) :
    walkDirections ⁻¹' (skeletonSample ⁻¹' visitsBeforeExit N D a x) =
      visitsBeforeExit N D a x := by
  ext ω
  simp [visitsBeforeExit]

lemma firstVisitIndex_of_visit (N : Size) (a x : Vertex N) (ω : WalkSample) (j : ℕ)
    (hx : position N a ω j = x) :
    firstVisitIndex N a x ω ≤ j ∧ position N a ω (firstVisitIndex N a x ω) = x := by
  have he : ∃ k : ℕ, position N a ω k = x := ⟨j, hx⟩
  rw [firstVisitIndex, dif_pos he]
  exact ⟨Nat.find_min' he hx, Nat.find_spec he⟩

lemma first_holdingTime_le_exit_occupation (N : Size) (D : Finset (Vertex N)) (a x : Vertex N)
    {ω : WalkSample} (hpos : ∀ j, 0 < (ω j).1)
    (hnon : Tendsto (jumpTime ω) atTop atTop) (hx : ω ∈ visitsBeforeExit N D a x) :
    holdingTime ω (firstVisitIndex N a x ω) ≤
      localTime N a ω (finiteExitDuration N D a ω) x := by
  obtain ⟨j, hj, hvisit⟩ := hx
  obtain ⟨hle, heq⟩ := firstVisitIndex_of_visit N a x ω j hvisit
  exact holdingTime_le_localTime_jumpTime N a x hpos hnon _ _ (hle.trans_lt hj) heq

lemma hittingTime_lt_jumpTime_iff_visit (N : Size) (a x : Vertex N)
    {ω : WalkSample} (hpos : ∀ j, 0 < (ω j).1)
    (hnon : Tendsto (jumpTime ω) atTop atTop) (n : ℕ) :
    hittingTime N a ω x < ENNReal.ofReal (jumpTime ω n) ↔
      ∃ j < n, position N a ω j = x := by
  rw [hittingTime_eq_discrete N a hpos hnon, discreteHittingTime]
  constructor
  · intro h
    obtain ⟨j, hj⟩ := iInf_lt_iff.mp h
    by_cases hx : position N a ω j = x
    · rw [if_pos hx] at hj
      have htime := (ENNReal.ofReal_lt_ofReal_iff_of_nonneg (jumpTime_nonneg ω j)).mp hj
      exact ⟨j, (jumpTime_strictMono hpos).lt_iff_lt.mp htime, hx⟩
    · simp only [if_neg hx, not_top_lt] at hj
  · rintro ⟨j, hj, hx⟩
    calc
      _ ≤ (if position N a ω j = x then ENNReal.ofReal (jumpTime ω j) else ∞) := iInf_le _ j
      _ = ENNReal.ofReal (jumpTime ω j) := if_pos hx
      _ < ENNReal.ofReal (jumpTime ω n) :=
        (ENNReal.ofReal_lt_ofReal_iff_of_nonneg (jumpTime_nonneg ω j)).mpr
          (jumpTime_strictMono hpos hj)

lemma hittingTime_lt_domainExitTime_iff_visit (N : Size) (D : Finset (Vertex N))
    (a b x : Vertex N) {ω : WalkSample} (hpos : ∀ j, 0 < (ω j).1)
    (hnon : Tendsto (jumpTime ω) atTop atTop) (hexit : ω ∈ exitsThrough N D a b) :
    hittingTime N a ω x < domainExitTime N D a ω ↔ ω ∈ visitsBeforeExit N D a x := by
  obtain ⟨n, hn⟩ := hexit
  rw [domainExitTime_of_exit_word N D a b hpos hnon n hn, finiteExitDuration,
    hittingTime_lt_jumpTime_iff_visit N a x hpos hnon]
  rfl

end TorusCoverTime.Blocks.B
