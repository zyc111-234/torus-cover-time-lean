import Mathlib.Analysis.Real.Sqrt
import Mathlib.Algebra.BigOperators.Intervals
import Mathlib.Tactic

/-! Finite three-halves tail estimates by an explicit telescoping bound.
These are numerical inequalities, independent of the probability model. -/

noncomputable section
open scoped BigOperators
namespace TorusCoverTime.Blocks.B

theorem inverse_three_halves_step (x : ℝ) (hx : 1 ≤ x) :
    1/(x*Real.sqrt x) ≤ 4*(1/Real.sqrt x - 1/Real.sqrt (x+1)) := by
  let s := Real.sqrt x
  let t := Real.sqrt (x+1)
  have hx0 : 0<x := by linarith
  have hs : 0<s := Real.sqrt_pos.mpr hx0
  have ht : 0<t := Real.sqrt_pos.mpr (by linarith)
  have hs2 : s^2=x := Real.sq_sqrt hx0.le
  have ht2 : t^2=x+1 := Real.sq_sqrt (by linarith)
  have hts : t≤2*s := by nlinarith
  have hp : t*(t+s) ≤ 4*x := by nlinarith [mul_nonneg hs.le (sub_nonneg.mpr hts)]
  have hid : (t-s)*(t+s)=1 := by nlinarith
  have hh : t ≤ 4*x*(t-s) := by
    apply (mul_le_mul_iff_left₀ (show 0<t+s by positivity)).mp
    calc
      t*(t+s) ≤ 4*x := hp
      _ = (4*x*(t-s))*(t+s) := by rw [mul_assoc, hid, mul_one]
  change 1/(x*s) ≤ 4*(1/s-1/t)
  rw [div_sub_div _ _ hs.ne' ht.ne', ← mul_div_assoc]
  apply (div_le_div_iff₀ (mul_pos hx0 hs) (mul_pos hs ht)).mpr
  nlinarith [mul_nonneg hs.le (sub_nonneg.mpr hh)]

theorem inverse_three_halves_Icc (r m : ℕ) (hr : 1 ≤ r) :
    (∑ k ∈ Finset.Icc r m, 1/((k : ℝ)*Real.sqrt k)) ≤ 4/Real.sqrt r := by
  by_cases hm : r ≤ m
  · have ht := Finset.sum_Icc_sub hm (fun k : ℕ => -(1/Real.sqrt (k : ℝ)))
    have he : (∑ k ∈ Finset.Icc r m, 4*(1/Real.sqrt (k : ℝ)-1/Real.sqrt ((k+1 : ℕ) : ℝ))) =
        4*(1/Real.sqrt r-1/Real.sqrt ((m+1 : ℕ) : ℝ)) := by
      rw [← Finset.mul_sum]
      have hh : (∑ k ∈ Finset.Icc r m, (1/Real.sqrt (k : ℝ)-1/Real.sqrt ((k+1 : ℕ) : ℝ))) =
          1/Real.sqrt r-1/Real.sqrt ((m+1 : ℕ) : ℝ) := by
        simpa only [sub_eq_add_neg, neg_neg, add_comm] using ht
      rw [hh]
    calc
      _ ≤ ∑ k ∈ Finset.Icc r m, 4*(1/Real.sqrt (k : ℝ)-1/Real.sqrt ((k+1 : ℕ) : ℝ)) := by
        apply Finset.sum_le_sum
        intro k hk
        have hkr := (Finset.mem_Icc.mp hk).1
        have h1 : (1:ℝ) ≤ k := by exact_mod_cast hr.trans hkr
        simpa only [Nat.cast_add, Nat.cast_one] using inverse_three_halves_step (k : ℝ) h1
      _ = _ := he
      _ ≤ _ := by
        have hh : 0 ≤ 1/Real.sqrt ((m+1 : ℕ) : ℝ) := by positivity
        calc
          _ ≤ 4*(1/Real.sqrt (r : ℝ)) := mul_le_mul_of_nonneg_left (sub_le_self _ hh) (by norm_num)
          _ = _ := by ring
  · rw [Finset.Icc_eq_empty_of_lt (Nat.lt_of_not_ge hm), Finset.sum_empty]
    positivity

end TorusCoverTime.Blocks.B
