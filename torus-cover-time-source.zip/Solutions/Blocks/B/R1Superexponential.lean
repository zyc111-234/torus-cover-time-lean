import Solutions.Blocks.B.R1DurationConditioning

/-! Uniform superexponential duration error at the manuscript's actual R1 scales. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Classical Asymptotics
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

lemma eighth_power_eventually_le_linear (C δ : ℝ) (hδ : 0 < δ) :
    ∀ᶠ L : ℝ in atTop, C * L ^ (1 / 8 : ℝ) ≤ δ * L := by
  have ht : Tendsto (fun L : ℝ => C * L ^ (-7 / 8 : ℝ)) atTop (𝓝 0) := by
    simpa only [mul_zero, neg_div] using
      (tendsto_rpow_neg_atTop (by norm_num : (0 : ℝ) < 7 / 8)).const_mul C
  filter_upwards [eventually_gt_atTop (0 : ℝ), ht.eventually_lt_const hδ] with L hL hsmall
  have heq : C * L ^ (1 / 8 : ℝ) / L = C * L ^ (-7 / 8 : ℝ) := by
    rw [show (-7 / 8 : ℝ) = 1 / 8 - 1 by norm_num, Real.rpow_sub hL, Real.rpow_one]
    ring
  rw [← heq] at hsmall
  exact (div_le_iff₀ hL).mp hsmall.le

lemma const_exp_eventually_le_exp (C a b : ℝ) (hab : a < b) :
    ∀ᶠ L : ℝ in atTop, C * Real.exp (a * L) ≤ Real.exp (b * L) := by
  have h := ((isLittleO_exp_mul_rpow_of_lt 0 hab).const_mul_left C).bound one_pos
  filter_upwards [h] with L hL
  have hb : |C * Real.exp (a * L)| ≤ Real.exp (b * L) := by
    simpa only [Real.rpow_zero, mul_one, Real.norm_eq_abs, abs_of_pos (Real.exp_pos _), one_mul] using hL
  exact (le_abs_self _).trans hb

lemma linear_eventually_le_exp (C b : ℝ) (hb : 0 < b) :
    ∀ᶠ L : ℝ in atTop, C * L ≤ Real.exp (b * L) := by
  have h := ((isLittleO_rpow_exp_pos_mul_atTop 1 hb).const_mul_left C).bound one_pos
  filter_upwards [h] with L hL
  have hbound : |C * L| ≤ Real.exp (b * L) := by
    simpa only [Real.rpow_one, Real.norm_eq_abs, abs_of_pos (Real.exp_pos _), one_mul] using hL
  exact (le_abs_self _).trans hbound

lemma r1_scalar_superexponential (CG CD : ℝ) :
    ∀ᶠ L : ℝ in atTop, ∀ G D m : ℝ, 0 < G → 0 < D → 0 ≤ m →
      G ≤ CG * L → D ≤ Real.exp (CD * L ^ (1 / 8 : ℝ)) →
      m ≤ Real.exp (L / 8) + 1 →
      m * D * Real.exp (-Real.exp (L / 2) / (4 * G * D) +
        (m + 1) * (D + 1) * Real.log 4) ≤ Real.exp (-Real.exp ((49 / 100 : ℝ) * L)) := by
  filter_upwards [eventually_ge_atTop (0 : ℝ),
    eighth_power_eventually_le_linear CD (1 / 1000) (by norm_num),
    linear_eventually_le_exp CG (1 / 1000) (by norm_num),
    const_exp_eventually_le_exp 4 0 (1 / 1000) (by norm_num),
    const_exp_eventually_le_exp 2 (63 / 500) (1 / 5) (by norm_num),
    const_exp_eventually_le_exp (6 * Real.log 4) (63 / 500) (1 / 5) (by norm_num),
    linear_eventually_le_exp (3 / 5) (497 / 1000) (by norm_num),
    const_exp_eventually_le_exp 3 (1 / 5) (497 / 1000) (by norm_num),
    const_exp_eventually_le_exp 3 (49 / 100) (497 / 1000) (by norm_num)]
    with L hL hsmall hGexp hfour hpref hover hlinear hmiddle hterminal
  intro G D m hG hD hm hGb hDb hmb
  let e := Real.exp ((1 / 1000 : ℝ) * L)
  let p := Real.exp (L / 8)
  have he : 1 ≤ e := Real.one_le_exp_iff.mpr (by positivity)
  have hp : 1 ≤ p := Real.one_le_exp_iff.mpr (by positivity)
  have hGe : G ≤ e := hGb.trans hGexp
  have hDe : D ≤ e := hDb.trans (Real.exp_le_exp.mpr hsmall)
  have h4e : 4 ≤ e := by simpa only [zero_mul, Real.exp_zero, mul_one] using hfour
  have hm2 : m ≤ 2 * p := by dsimp [p] at hp ⊢; linarith
  have hm3 : m + 1 ≤ 3 * p := by linarith
  have hD2 : D + 1 ≤ 2 * e := by linarith
  have hepos : 0 < e := Real.exp_pos _
  have hppos : 0 < p := Real.exp_pos _
  have hpe : p * e = Real.exp ((63 / 500 : ℝ) * L) := by
    dsimp [p, e]
    rw [← Real.exp_add]
    congr 1
    ring
  have hMD : m * D ≤ Real.exp ((1 / 5 : ℝ) * L) := by
    calc
      _ ≤ (2 * p) * e := mul_le_mul hm2 hDe hD.le (by positivity)
      _ = 2 * Real.exp ((63 / 500 : ℝ) * L) := by rw [mul_assoc, hpe]
      _ ≤ _ := hpref
  have hlog4 : 0 ≤ Real.log 4 := (Real.log_pos (by norm_num)).le
  have hcost : (m + 1) * (D + 1) * Real.log 4 ≤ Real.exp ((1 / 5 : ℝ) * L) := by
    calc
      _ ≤ (3 * p) * (2 * e) * Real.log 4 :=
        mul_le_mul_of_nonneg_right (mul_le_mul hm3 hD2 (by linarith) (by positivity)) hlog4
      _ = (6 * Real.log 4) * Real.exp ((63 / 500 : ℝ) * L) := by rw [← hpe]; ring
      _ ≤ _ := hover
  have hden : 4 * G * D ≤ Real.exp ((3 / 1000 : ℝ) * L) := by
    calc
      _ ≤ (e * e) * e := mul_le_mul (mul_le_mul h4e hGe hG.le hepos.le) hDe hD.le (by positivity)
      _ = _ := by dsimp [e]; rw [← Real.exp_add, ← Real.exp_add]; congr 1; ring
  have hmain : Real.exp ((497 / 1000 : ℝ) * L) ≤ Real.exp (L / 2) / (4 * G * D) := by
    calc
      _ = Real.exp (L / 2) / Real.exp ((3 / 1000 : ℝ) * L) := by
        rw [← Real.exp_sub]
        congr 1
        ring
      _ ≤ _ := div_le_div_of_nonneg_left (Real.exp_pos _).le (by positivity) hden
  calc
    _ ≤ Real.exp ((1 / 5 : ℝ) * L) * Real.exp
        (-Real.exp (L / 2) / (4 * G * D) + (m + 1) * (D + 1) * Real.log 4) :=
      mul_le_mul_of_nonneg_right hMD (Real.exp_pos _).le
    _ = Real.exp ((1 / 5 : ℝ) * L - Real.exp (L / 2) / (4 * G * D) +
        (m + 1) * (D + 1) * Real.log 4) := by rw [← Real.exp_add]; congr 1; ring
    _ ≤ _ := by
      apply Real.exp_le_exp.mpr
      linarith

theorem r1_duration_superexponential (hWalk : WalkModelRegular) (hGreen : GreenEstimates)
    (C : ℝ) : ∀ᶠ N : Size in atTop, ∀ D K : Finset (Vertex N), ∀ m : ℕ,
      ∀ a b : Fin m → Vertex N, D.Nonempty → D ≠ Finset.univ →
      (D.card : ℝ) ≤ Real.exp (C * (logSize N) ^ (1 / 8 : ℝ)) →
      (m : ℝ) ≤ Real.exp (logSize N / 8) + 1 →
      (∀ i, FeasibleAvoidingExit N D K (a i) (b i)) → K.Nonempty →
      ∀ u₀ : ℝ, 0 ≤ u₀ →
        (exactExitProductLaw N D m a b)[{ω | ∃ i : Fin m,
          Real.exp (logSize N / 2) < finiteExitDuration N D (a i) (ω i)} |
            exitBlockSoftness N D K m a u₀] ≤
          ENNReal.ofReal (Real.exp (-Real.exp ((49 / 100 : ℝ) * logSize N))) := by
  obtain ⟨CG, _, hCG⟩ := greenDiagonal_eventually_linear hGreen
  filter_upwards [hCG, blockB_logSize_tendsto.eventually (r1_scalar_superexponential CG C)]
    with N hG hscalar
  intro D K m a b hD hproper hsize hm hpath hK u₀ hu₀
  apply (conditioned_duration_bound_actual hWalk N D K m a b hD hproper hpath hK u₀ hu₀
    (Real.exp (logSize N / 2)) (Real.exp_pos _).le).trans
  exact ENNReal.ofReal_le_ofReal (hscalar (greenDiagonal N) D.card m (greenDiagonal_pos N)
    (Nat.cast_pos.mpr hD.card_pos) (Nat.cast_nonneg _) hG hsize hm)

end TorusCoverTime.Blocks.B
