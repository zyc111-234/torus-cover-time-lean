import Solutions.Blocks.B.DiskCardinality
import Solutions.Blocks.B.FourierCutoff
import Solutions.Blocks.B.SquareShells

/-! A radius-linear reciprocal-distance sum, using exact square-shell counts.
The bound has no dependence on the ambient torus size. -/

noncomputable section
open Classical
namespace TorusCoverTime.Blocks.B

theorem centeredSquare_reciprocal_sum (N : Size) (m : ℕ) (hm : m ≤ (N.val-1)/2) :
    (∑ z ∈ centeredCore N m ×ˢ centeredCore N m,
      1 / max 1 (max (coordinateDistance z.1 0) (coordinateDistance z.2 0))) = 1 + 8*m := by
  rw [Finset.sum_product]
  have hin (a : ZMod N.val) :
      (∑ b ∈ centeredCore N m,
        1 / max 1 (max (coordinateDistance a 0) (coordinateDistance b 0))) =
      symmetricCoordinateSum m (fun t => 1/max 1 (max (coordinateDistance a 0) t)) :=
    sum_centeredCore_distance N m hm (fun t => 1/max 1 (max (coordinateDistance a 0) t))
  simp only [hin]
  rw [sum_centeredCore_distance N m hm (fun s =>
    symmetricCoordinateSum m (fun t => 1/max 1 (max s t)))]
  change symmetricMaxSum m (fun t => 1 / max 1 t) = _
  rw [symmetricMaxSum_shells]
  have he (j : ℕ) : ((j : ℝ)+1) * (1/max 1 ((j : ℝ)+1)) = 1 := by
    rw [max_eq_right (by have := Nat.cast_nonneg (α := ℝ) j; linarith : (1:ℝ) ≤ (j:ℝ)+1)]
    field_simp
  simp only [he, max_eq_left (by norm_num : (0:ℝ) ≤ 1), div_one,
    Finset.sum_const, Finset.card_range, nsmul_eq_mul, mul_one]

theorem disk_reciprocal_sum (N : Size) (c : Vertex N) (R : ℝ) (hR : 1 ≤ R)
    (hsmall : 2*(R+1) < N.val) :
    (∑ z ∈ torusDisk N c R, 1 / max 1 (periodicDistance z c)) ≤ 17*R := by
  let m : ℕ := ⌈R⌉₊
  have hmR : (m : ℝ) < R+1 := Nat.ceil_lt_add_one (by linarith)
  have hRm : R ≤ (m : ℝ) := Nat.le_ceil R
  have hmN : m ≤ (N.val-1)/2 := by
    have hi : 2*m < N.val := by exact_mod_cast (show 2*(m:ℝ) < N.val by linarith)
    omega
  let S := (torusDisk N c R).image (fun z => z-c)
  let E := centeredCore N m ×ˢ centeredCore N m
  have hSE : S ⊆ E := by
    intro z hz
    obtain ⟨a, ha, rfl⟩ := Finset.mem_image.mp hz
    have hd := periodicDistance_coordinate_le N (a-c)
    rw [periodicDistance_sub_zero] at hd
    have haR := (mem_torusDisk N c a R).mp ha
    exact Finset.mem_product.mpr
      ⟨(mem_centeredCore N m _).mpr (by linarith [hd.1]),
       (mem_centeredCore N m _).mpr (by linarith [hd.2])⟩
  have he : (∑ z ∈ torusDisk N c R, 1 / max 1 (periodicDistance z c)) =
      ∑ z ∈ S, 1 / max 1 (periodicDistance z 0) := by
    rw [Finset.sum_image (by intros a ha b hb he; exact sub_left_inj.mp he)]
    simp only [periodicDistance_sub_zero]
  rw [he]
  calc
    _ ≤ ∑ z ∈ S, 1/max 1 (max (coordinateDistance z.1 0) (coordinateDistance z.2 0)) := by
      apply Finset.sum_le_sum
      intro z _
      apply one_div_le_one_div_of_le (lt_of_lt_of_le zero_lt_one (le_max_left _ _))
      exact max_le_max_left 1 (max_le (periodicDistance_coordinate_le N z).1
        (periodicDistance_coordinate_le N z).2)
    _ ≤ ∑ z ∈ E, 1/max 1 (max (coordinateDistance z.1 0) (coordinateDistance z.2 0)) :=
      Finset.sum_le_sum_of_subset_of_nonneg hSE (fun z _ _ => by positivity)
    _ = 1+8*m := centeredSquare_reciprocal_sum N m hmN
    _ ≤ 17*R := by linarith

end TorusCoverTime.Blocks.B
