import Solutions.Blocks.B.BT11GreenBarrier
import Solutions.Blocks.B.PointSoftSpatialSum

/-! Exact point-killed semigroup composition and a finite flat-kernel
comparison. No time-reversal theorem for continuous paths is assumed. -/
noncomputable section
open MeasureTheory Filter Set Classical
open scoped ENNReal Topology RealInnerProductSpace
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

theorem bt11_killing_semigroup (N : Size) (c a b : Vertex N) (s t : ℝ) :
    (∑ z,pointKillingKernel N c s a z*pointKillingKernel N c t z b)=
      pointKillingKernel N c (s+t) a b := by
  let v := pointKillingBasis N c
  let e := fun r i => Real.exp (-pointKillingModeRate N c i*r)
  have ho (i j : PointKillingIndex N) : (∑ z : Vertex N,v i z*v j z)=if i=j then 1 else 0 := by
    simpa only [pointKilling_inner] using (orthonormal_iff_ite.mp v.orthonormal i j)
  change (∑ z,(∑ i,e s i*v i a*v i z)*(∑ j,e t j*v j z*v j b))=∑ i,e (s+t) i*v i a*v i b
  simp_rw [Finset.sum_mul,Finset.mul_sum]
  rw [Finset.sum_comm]
  calc
    _ = ∑ i,∑ j,∑ z : Vertex N,(e s i*v i a*v i z)*(e t j*v j z*v j b) := by
      apply Finset.sum_congr rfl
      intro i _
      rw [Finset.sum_comm]
    _ = ∑ i,∑ j,(e s i*v i a*e t j*v j b)*(if i=j then 1 else 0) := by
      apply Finset.sum_congr rfl
      intro i _
      apply Finset.sum_congr rfl
      intro j _
      rw [← ho,Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro z _
      ring
    _ = ∑ i,e (s+t) i*v i a*v i b := by
      simp only [mul_ite,mul_one,mul_zero,Finset.sum_ite_eq,Finset.mem_univ,if_true]
      apply Finset.sum_congr rfl
      intro i _
      dsimp only [e]
      rw [show -pointKillingModeRate N c i*(s+t)=
        -pointKillingModeRate N c i*s+ -pointKillingModeRate N c i*t by ring,Real.exp_add]
      ring

theorem bt11_flat_product_lower {I : Type*} [Fintype I] (f h : I → ℝ) (M : ℝ)
    (hf : ∀ i,f i≤M) (hh : ∀ i,h i≤M) :
    M*(∑ i,f i)+M*(∑ i,h i)-(Fintype.card I:ℝ)*M^2≤∑ i,f i*h i := by
  have hnon := Finset.sum_nonneg (s := Finset.univ)
    (fun i _ => mul_nonneg (sub_nonneg.mpr (hf i)) (sub_nonneg.mpr (hh i)))
  have he : (∑ i,(M-f i)*(M-h i))=
      (Fintype.card I:ℝ)*M^2-M*(∑ i,f i)-M*(∑ i,h i)+(∑ i,f i*h i) := by
    simp only [sub_mul,mul_sub,Finset.sum_sub_distrib,Finset.sum_add_distrib,
      Finset.sum_const,Finset.card_univ,nsmul_eq_mul,← Finset.mul_sum,← Finset.sum_mul]
    ring
  rw [he] at hnon
  linarith

theorem bt11_bridge_kernel_deficit (N : Size) (c a b : Vertex N) (T : ℝ)
    (hhalf : ∀ x y : Vertex N, transitionProbability N x y (T/2)≤(1+1/1024)/vertexCount N)
    (hfull : transitionProbability N a b T≤(1+1/1024)/vertexCount N)
    (hT : 0≤T)
    (ha : 1-bt11KillAction N c (T/2) (fun _ => 1) a≤1/1024)
    (hb : 1-bt11KillAction N c (T/2) (fun _ => 1) b≤1/1024) :
    transitionProbability N a b T-pointKillingKernel N c T a b≤1/(64*vertexCount N) := by
  let M := (1+1/1024)/vertexCount N
  have hM : 0≤M := by have := vertexCount_pos N; dsimp [M]; positivity
  have hk (x y : Vertex N) : pointKillingKernel N c (T/2) x y≤M :=
    (pointKillingKernel_le_transition N c x y (T/2) (by linarith)).trans (hhalf x y)
  have h := bt11_flat_product_lower (fun z => pointKillingKernel N c (T/2) a z)
    (fun z => pointKillingKernel N c (T/2) z b) M (hk a) (fun z => hk z b)
  rw [bt11_killing_semigroup,show T/2+T/2=T by ring] at h
  have hs : (∑ z,pointKillingKernel N c (T/2) z b)=bt11KillAction N c (T/2) (fun _ => 1) b := by
    simp only [bt11KillAction,mul_one,pointKillingKernel_symm N c _ _ b]
  rw [hs,show (∑ z,pointKillingKernel N c (T/2) a z)=bt11KillAction N c (T/2) (fun _ => 1) a by
    simp only [bt11KillAction,mul_one],point_soft_vertex_count] at h
  have ham := mul_le_mul_of_nonneg_left (show 1-1/1024≤bt11KillAction N c (T/2) (fun _ => 1) a by linarith) hM
  have hbm := mul_le_mul_of_nonneg_left (show 1-1/1024≤bt11KillAction N c (T/2) (fun _ => 1) b by linarith) hM
  have he : M-(M*(1-1/1024)+M*(1-1/1024)-vertexCount N*M^2)≤1/(64*vertexCount N) := by
    have hid : M-(M*(1-1/1024)+M*(1-1/1024)-vertexCount N*M^2)=
        (3075/1048576:ℝ)/vertexCount N := by
      dsimp only [M]
      field_simp [(vertexCount_pos N).ne']
      <;> ring
    rw [hid]
    have hh := div_le_div_of_nonneg_right (by norm_num : (3075/1048576:ℝ)≤1/64) (vertexCount_pos N).le
    simpa only [div_div] using hh
  change transitionProbability N a b T≤M at hfull
  linarith

end TorusCoverTime.Blocks.B
