import Solutions.Blocks.B.PeriodicSliceBounds

/-! Exact sampling identities transfer real differences to the cyclic frequency grid. -/

noncomputable section
open Function
open scoped Topology ContDiff
namespace TorusCoverTime.Blocks.B

lemma periodic_centered_sample (N : Size) (R : ℝ) (f : ℝ → ℂ)
    (hf : Periodic f ((N.val : ℝ) / R)) (n : ℤ) :
    f (((n : ZMod N.val).valMinAbs : ℝ) / R) = f ((n : ℝ) / R) := by
  have hd : (N.val : ℤ) ∣ n - (n : ZMod N.val).valMinAbs := by
    apply (ZMod.intCast_zmod_eq_zero_iff_dvd _ _).mp
    simp
  obtain ⟨m, hm⟩ := hd
  have hmr : (n : ℝ) - ((n : ZMod N.val).valMinAbs : ℝ) = (N.val : ℝ) * (m : ℝ) := by
    exact_mod_cast hm
  have heq : (n : ℝ) / R - (m : ℝ) * ((N.val : ℝ) / R) =
      ((n : ZMod N.val).valMinAbs : ℝ) / R := by
    calc
      _ = ((n : ℝ) - (N.val : ℝ) * (m : ℝ)) / R := by ring
      _ = _ := by congr 1; linarith
  rw [← heq]
  exact hf.sub_int_mul_eq m

def cyclicDifference (N : Size) (f : ZMod N.val → ℂ) : ZMod N.val → ℂ :=
  fun b => f (b + 1) - f b

def cyclicSample (N : Size) (R : ℝ) (f : ℝ → ℂ) : ZMod N.val → ℂ :=
  fun b => f ((b.valMinAbs : ℝ) / R)

lemma realDifference_periodic (h T : ℝ) (f : ℝ → ℂ) (hf : Periodic f T) :
    Periodic (realDifference h f) T := by
  intro x
  change f (x + T + h) - f (x + T) = f (x + h) - f x
  rw [add_right_comm x T h, hf, hf]

lemma cyclicDifference_sample (N : Size) (R : ℝ) (f : ℝ → ℂ)
    (hf : Periodic f ((N.val : ℝ) / R)) :
    cyclicDifference N (cyclicSample N R f) = cyclicSample N R (realDifference (1 / R) f) := by
  funext b
  change f (((b + 1).valMinAbs : ℝ) / R) - f ((b.valMinAbs : ℝ) / R) =
    f ((b.valMinAbs : ℝ) / R + 1 / R) - f ((b.valMinAbs : ℝ) / R)
  have h := periodic_centered_sample N R f hf (b.valMinAbs + 1)
  simpa only [Int.cast_add, Int.cast_one, ZMod.coe_valMinAbs, add_div] using
    congrArg (fun z => z - f ((b.valMinAbs : ℝ) / R)) h

lemma cyclicDifference_sample_iterate (N : Size) (R : ℝ) (f : ℝ → ℂ)
    (hf : Periodic f ((N.val : ℝ) / R)) (p : ℕ) :
    (cyclicDifference N)^[p] (cyclicSample N R f) =
      cyclicSample N R ((realDifference (1 / R))^[p] f) := by
  induction p generalizing f with
  | zero => rfl
  | succ p ih =>
    rw [Function.iterate_succ_apply, Function.iterate_succ_apply,
      cyclicDifference_sample N R f hf]
    exact ih _ (realDifference_periodic _ _ f hf)

def axisPoint (N : Size) (axis : Bool) (q b : ZMod N.val) : Vertex N :=
  if axis then (q, b) else (b, q)

def axisUnit (N : Size) (axis : Bool) : Vertex N := if axis then (0, 1) else (1, 0)

lemma axisPoint_add_one (N : Size) (axis : Bool) (q b : ZMod N.val) :
    axisPoint N axis q (b + 1) = axisPoint N axis q b + axisUnit N axis := by
  cases axis <;> simp [axisPoint, axisUnit]

lemma frequencyDifference_restrict_axis (N : Size) (axis : Bool) (q : ZMod N.val)
    (a : Vertex N → ℂ) (p : ℕ) (b : ZMod N.val) :
    ((frequencyDifference N (axisUnit N axis))^[p] a) (axisPoint N axis q b) =
      ((cyclicDifference N)^[p] (fun c => a (axisPoint N axis q c))) b := by
  induction p generalizing b with
  | zero => rfl
  | succ p ih =>
    rw [Function.iterate_succ_apply', Function.iterate_succ_apply']
    change ((frequencyDifference N (axisUnit N axis))^[p] a)
      (axisPoint N axis q b + axisUnit N axis) -
      ((frequencyDifference N (axisUnit N axis))^[p] a) (axisPoint N axis q b) = _
    rw [← axisPoint_add_one, ih, ih]
    rfl

lemma cyclicDifference_const_mul_iterate (N : Size) (c : ℂ) (f : ZMod N.val → ℂ)
    (p : ℕ) : (cyclicDifference N)^[p] (fun b => c * f b) =
      fun b => c * ((cyclicDifference N)^[p] f) b := by
  induction p with
  | zero => rfl
  | succ p ih =>
    rw [Function.iterate_succ_apply', Function.iterate_succ_apply', ih]
    funext b
    exact mul_sub c _ _ |>.symm

end TorusCoverTime.Blocks.B
