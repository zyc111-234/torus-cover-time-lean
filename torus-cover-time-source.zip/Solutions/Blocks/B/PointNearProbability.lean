import Solutions.Blocks.B.PointNearScale

/-! B-T1 for ordinary paths: initial and random terminal neighborhoods,
uniformly over the actual starting vertex and central physical times. -/
noncomputable section
open MeasureTheory Filter Set Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

theorem point_near_central_probabilities (hWalk : WalkModelRegular) (γ C u H : ℝ)
    (hC : 0 ≤ C) (hH : 0 ≤ H) :
    ∀ᶠ N : Size in atTop, ∀ a root : Vertex N, ∀ t : ℝ,
      phaseACenter N-H*timeScale N ≤ t →
      walkLaw.real {ω | (ω,t) ∈ pointNearSoftEvent N a root (pointNearRadius N γ C) u} ≤
        pointNearEnvelope N γ C u H ∧
      walkLaw.real {ω | (ω,t) ∈ pointNearTerminalEvent N a (pointNearRadius N γ C) u} ≤
        pointNearEnvelope N γ C u H := by
  filter_upwards [point_soft_joint_central hWalk u H hH] with N hN
  intro a root t ht
  have hJ := fun c b => hN c a b t ht
  exact ⟨(point_near_fixed_probability N a root _ t u _ (pointNearRadius_nonneg N γ C hC)
    (pointSoftJointBound_nonneg N u H) hJ).trans (point_near_spatial_budget N γ C u H),
    (point_near_terminal_probability N a _ t u _ (pointNearRadius_nonneg N γ C hC)
    (pointSoftJointBound_nonneg N u H) hJ).trans (point_near_spatial_budget N γ C u H)⟩

theorem point_near_central_uniform (hWalk : WalkModelRegular) (γ C u H : ℝ)
    (hγ : 0 < γ) (hC : 0 ≤ C) (hH : 0 ≤ H) :
    ∀ ε : ℝ, 0 < ε → ∀ᶠ N : Size in atTop, ∀ a root : Vertex N, ∀ t : ℝ,
      phaseACenter N-H*timeScale N ≤ t →
      walkLaw.real {ω | (ω,t) ∈ pointNearSoftEvent N a root (pointNearRadius N γ C) u} ≤ ε ∧
      walkLaw.real {ω | (ω,t) ∈ pointNearTerminalEvent N a (pointNearRadius N γ C) u} ≤ ε := by
  intro ε hε
  filter_upwards [point_near_central_probabilities hWalk γ C u H hC hH,
    (point_near_envelope_tendsto γ C u H hγ).eventually (eventually_lt_nhds hε)] with N hN hεN
  intro a root t ht
  exact ⟨(hN a root t ht).1.trans hεN.le,(hN a root t ht).2.trans hεN.le⟩

theorem point_soft_single_central (hWalk : WalkModelRegular) (u H : ℝ) (hH : 0 ≤ H) :
    ∀ᶠ N : Size in atTop, ∀ a c : Vertex N, ∀ t : ℝ,
      phaseACenter N-H*timeScale N ≤ t →
      walkLaw.real {ω | localTime N a ω t c ≤ u} ≤
        pointSoftConstant u H*(logSize N)^(3/2:ℝ)/vertexCount N := by
  filter_upwards [point_soft_joint_central hWalk u H hH] with N hN
  intro a c t ht
  apply (point_soft_single_marginal N a c t u _ (pointSoftJointBound_nonneg N u H)
    (fun b => hN c a b t ht)).trans_eq
  unfold pointSoftJointBound
  field_simp [(vertexCount_pos N).ne']

end TorusCoverTime.Blocks.B
