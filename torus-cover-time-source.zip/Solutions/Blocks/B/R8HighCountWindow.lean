import Solutions.Blocks.B.R8LoopPrefixBound

/-! Actual high-count soft-site mass in a physical window, after summing the
original root. The fixed-prefix bound makes a duration error unnecessary here. -/
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

def r8FarHighCountSoftEvent (N : Size) (c root : Vertex N) (γ q U : ℝ) : Set (WalkSample × ℝ) :=
  {z | (N.val:ℝ)*Real.exp (-((logSize N)^(16*γ))/2) ≤ periodicDistance c root ∧
    z ∈ r8HighCountSoftEvent N c root γ q U}

theorem r8FarHighCountSoftEvent_measurable (N : Size) (c root : Vertex N) (γ q U : ℝ) :
    MeasurableSet (r8FarHighCountSoftEvent N c root γ q U) :=
  (MeasurableSet.const _).inter (r8HighCountSoftEvent_measurable N c root γ q U)

def r8HighCountWindowMass (N : Size) (c : Vertex N) (γ q U l r : ℝ) : ℝ≥0∞ :=
  r7LoopEventMass N (fun root => r8FarHighCountSoftEvent N c root γ q U) l r

theorem r8_high_count_window_bound (hWalk : WalkModelRegular) (γ U : ℝ)
    (hγ : 0 < γ) (hγ1 : γ < 1) (hU : 0 ≤ U) :
    ∀ᶠ N : Size in atTop, ∀ c : Vertex N, ∀ q : ℝ,
      (logSize N)^(16*γ) ≤ q → q ≤ logSize N-(logSize N)^(16*γ) → ∀ l r : ℝ,
      r8HighCountWindowMass N c γ q U l r ≤
        ENNReal.ofReal (vertexCount N*(r-l)/timeScale N)*ENNReal.ofReal (Real.exp (-40*logSize N)) := by
  filter_upwards [r8_high_count_prefix_probability hWalk γ U hγ hγ1 hU,r7_far_root_outside γ hγ] with N hp hout
  intro c q hq hqL l r
  have hqpos : 0 < q := (Real.rpow_pos_of_pos (logSize_pos N) _).trans_le hq
  apply r8_loop_normalized_root_bound
  intro root
  by_cases hfar : (N.val:ℝ)*Real.exp (-((logSize N)^(16*γ))/2) ≤ periodicDistance c root
  · have hr := hout c root q hqpos.le hqL hfar
    let B : Set WalkSample := {ω | traversalOccupation N (torusDisk N c (Real.exp (q+q^γ)))
      (torusDisk N c (Real.exp (q+2*q^γ))) root (r8SitePotential N c) (r8HighCountCutoff (logSize N) q γ) ω ≤ U}
    have hB : MeasurableSet B := measurableSet_le (traversalOccupation_measurable N _ _ root _ _) measurable_const
    have he : ∀ᵐ ω ∂walkLaw, ∀ t : ℝ, 0 ≤ t → walk N root ω t = root →
        (ω,t) ∈ r8FarHighCountSoftEvent N c root γ q U → ω ∈ B := by
      filter_upwards [r8_high_count_event_prefix_ae N c root γ q U hqpos hr] with ω hω
      exact fun t ht hloop hbad => hω t ht hloop hbad.2
    exact (r8_root_loop_prefix_bound N root _ B hB he l r).trans (mul_le_mul' le_rfl (hp c root q hq hqL hr))
  · simp only [r8FarHighCountSoftEvent,r7LoopEventTest,mem_ofPred_eq,hfar,false_and,if_false,lintegral_zero]
    exact bot_le

end TorusCoverTime.Blocks.B
