import Solutions.Blocks.B.NestedTraversalWindow
import Solutions.Blocks.B.TraversalExteriorResampling

/-! Actual low inner counts compared with record events while retaining the complete exterior weight. -/
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B


def nestedPhysicalExteriorSlice (N : Size) (Q O I J : Finset (Vertex N)) (root : Vertex N)
    (m : ℕ) (w : Fin (2*m) → Vertex N) (h U : ℝ)
    (E : TraversalExteriorSample m × ℝ → ℝ≥0∞) (l r : ℝ) : ℝ≥0∞ :=
  ∫⁻ ω, (∫⁻ t in Ioi (adaptiveExitTime N (alternatingDomain N Q O) root (2*m) ω),
    if t < adaptiveExitTime N (alternatingDomain N Q O) root (2*m+1) ω ∧
      walk N root ω t = root ∧ t ∈ Icc l r ∧ h*(completedTraversalCount N I J root ω t:ℝ) ≤ U then
        E (traversalExteriorData N Q O root m ω,t-adaptiveExitTime N (alternatingDomain N Q O) root (2*m) ω)
      else 0)
    ∂walkLaw[|{ω | adaptiveExitWord N (alternatingDomain N Q O) root (2*m) ω = w}]

theorem nestedPhysicalExteriorSlice_le_records (N : Size) (Q O I J : Finset (Vertex N))
    (hQO : Q ⊆ O) (hQ : Q.Nonempty) (hIJ : I ⊆ J) (hI : I.Nonempty)
    (hJO : J ⊆ O) (root : Vertex N) (hr : root ∉ O) (m : ℕ) (w : Fin (2*m) → Vertex N)
    (hentry : ∀ᵐ ω ∂walkLaw, ∀ j : ℕ,
      adaptiveExitStart N (alternatingDomain N Q O) root (2*j+1) ω ∉ J)
    (h U : ℝ) (hh : 0 ≤ h) (E : TraversalExteriorSample m × ℝ → ℝ≥0∞) (l r : ℝ) :
    nestedPhysicalExteriorSlice N Q O I J root m w h U E l r ≤
      conditionalTraversalExteriorSlice N Q O root m w
        {p | h*recordProductNestedCount N I J m (fun i => endpointWordStart root w (2*i.val+1))
          (outwardRecordProjection m p) ≤ U} E l r := by
  have hac : walkLaw[|{ω | adaptiveExitWord N (alternatingDomain N Q O) root (2*m) ω = w}] ≪ walkLaw :=
    cond_absolutelyContinuous
  apply lintegral_mono_ae
  filter_upwards [wordRecordNestedCount_path_le_ae N Q O I J hQO hQ hIJ hI hJO root hr m w hentry,
    hac.ae_le (completedTraversalCount_loop_iff_ae N Q O hQO hQ root hr)] with ω hcount hslice
  apply lintegral_mono_ae
  filter_upwards [ae_restrict_mem (measurableSet_Ioi (a :=
    adaptiveExitTime N (alternatingDomain N Q O) root (2*m) ω))] with t ht
  by_cases hb : t < adaptiveExitTime N (alternatingDomain N Q O) root (2*m+1) ω ∧
      walk N root ω t = root ∧ t ∈ Icc l r ∧ h*(completedTraversalCount N I J root ω t:ℝ) ≤ U
  · have ht0 : 0 ≤ t := (jumpTime_nonneg ω _).trans ht.le
    have hm := (hslice t ht0 hb.2.1 m).mpr ⟨ht.le,hb.1⟩
    have hlow := (mul_le_mul_of_nonneg_left (hcount t ht0 hm) hh).trans hb.2.2.2
    have hwin : t < adaptiveExitTime N (alternatingDomain N Q O) root (2*m+1) ω ∧
        walk N root ω t = root ∧ t ∈ Icc l r := ⟨hb.1,hb.2.1,hb.2.2.1⟩
    dsimp only [wordRecordNestedCount] at hlow
    simp only [if_pos hb,if_pos hwin,traversalExteriorMarkedTest,mem_ofPred_eq]
    change _ ≤ if h*wordRecordNestedCount N I J root m w
      (fun j => adaptiveExitRecord N (alternatingDomain N Q O) root j.val ω) ≤ U then _ else 0
    simp only [wordRecordNestedCount]
    rw [if_pos hlow]
    exact le_rfl
  · simp only [if_neg hb,zero_le]


end TorusCoverTime.Blocks.B
