import Solutions.Blocks.B.HoldingDirections
import Solutions.Blocks.B.FourierFromTransition

/-! Connecting the actual continuous-time path model to its finite Fourier semigroup. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter
open scoped BigOperators ENNReal Topology

namespace TorusCoverTime.Blocks.B

lemma finiteCharacter_norm (N : Size) (k x : Vertex N) : ‖finiteCharacter N k x‖ = 1 := by
  rw [finiteCharacter_eq_exp, Complex.norm_exp]
  simp

lemma measurable_walk_character (N : Size) (start k : Vertex N) (t : ℝ) :
    Measurable (fun ω : WalkSample => finiteCharacter N k (walk N start ω t)) := by
  classical
  have hsum : Measurable (fun ω : WalkSample => ∑ y : Vertex N,
      if walk N start ω t = y then finiteCharacter N k y else 0) := by
    apply Finset.measurable_fun_sum
    intro y _
    exact Measurable.ite
      (((measurable_walk_eq_joint N start y).comp (measurable_prodMk_right (y := t))).setOf)
      measurable_const measurable_const
  simpa using hsum

lemma integrable_walk_character (N : Size) (start k : Vertex N) (t : ℝ) :
    Integrable (fun ω : WalkSample => finiteCharacter N k (walk N start ω t)) walkLaw := by
  exact Integrable.of_bound (measurable_walk_character N start k t).aestronglyMeasurable 1
    (Filter.Eventually.of_forall (fun ω => (finiteCharacter_norm N k _).le))

lemma integral_character_on_jumpCount (hWalk : WalkModelRegular)
    (N : Size) (start k : Vertex N) (t : ℝ) (ht : 0 ≤ t) (n : ℕ) :
    (∫ ω in {ω | jumpCount ω t = n}, finiteCharacter N k (position N start ω n) ∂walkLaw) =
      ((walkLaw {ω | jumpCount ω t = n}).toReal : ℂ) *
        (∫ ω, finiteCharacter N k (position N start ω n) ∂walkLaw) := by
  classical
  let H := fun ω : WalkSample => fun j : Fin (n + 1) => (ω j.val).1
  let D := fun ω : WalkSample => fun j : Fin (n + 1) => (ω j.val).2
  let fH : (Fin (n + 1) → ℝ) → ℂ := fun u =>
    if (∑ j : Fin n, max (u j.castSucc) 0) ≤ t ∧
        t < ∑ j : Fin (n + 1), max (u j) 0 then 1 else 0
  let fD : (Fin (n + 1) → Fin 4) → ℂ := fun u =>
    finiteCharacter N k (start + ∑ j : Fin n, direction N (u j.castSucc))
  have hH : Measurable H := by fun_prop
  have hD : Measurable D := by fun_prop
  have hfH : Measurable fH := by
    have hs0 : Measurable (fun u : Fin (n + 1) → ℝ => ∑ j : Fin n, max (u j.castSucc) 0) := by
      fun_prop
    have hs1 : Measurable (fun u : Fin (n + 1) → ℝ => ∑ j : Fin (n + 1), max (u j) 0) := by
      fun_prop
    exact Measurable.ite ((measurableSet_le hs0 measurable_const).inter
      (measurableSet_lt measurable_const hs1)) measurable_const measurable_const
  have hfD : Measurable fD := measurable_of_finite _
  have hindep : IndepFun (fun ω : WalkSample => fH (H ω)) (fun ω => fD (D ω)) walkLaw :=
    (holding_direction_prefix_independent (n + 1)).comp hfH hfD
  have hfactor := hindep.integral_fun_mul_eq_mul_integral (hfH.comp hH).aestronglyMeasurable
    (hfD.comp hD).aestronglyMeasurable
  have heqD (ω : WalkSample) : fD (D ω) = finiteCharacter N k (position N start ω n) := by
    dsimp [fD, D, position]
    rw [Fin.sum_univ_eq_sum_range (fun j => direction N (ω j).2)]
  have heqH : (fun ω : WalkSample => fH (H ω)) =ᵐ[walkLaw]
      (fun ω => if jumpCount ω t = n then (1 : ℂ) else 0) := by
    filter_upwards [jumpCount_event_ae hWalk t ht n] with ω hω
    have hS0 : (∑ j : Fin n, max ((H ω) j.castSucc) 0) = jumpTime ω n := by
      dsimp [H, jumpTime, holdingTime]
      rw [Fin.sum_univ_eq_sum_range (fun j => max (ω j).1 0)]
    have hS1 : (∑ j : Fin (n + 1), max ((H ω) j) 0) = jumpTime ω (n + 1) := by
      dsimp [H, jumpTime, holdingTime]
      rw [Fin.sum_univ_eq_sum_range (fun j => max (ω j).1 0)]
    dsimp [fH]
    rw [hS0, hS1]
    simp only [← hω]
  have hcount : Measurable (fun ω : WalkSample => jumpCount ω t) :=
    measurable_jumpCount_joint.comp (measurable_prodMk_right (y := t))
  have hevent : MeasurableSet {ω : WalkSample | jumpCount ω t = n} :=
    (measurableSet_singleton n).preimage hcount
  have hleft : (∫ ω : WalkSample, fH (H ω) * fD (D ω) ∂walkLaw) =
      ∫ ω in {ω | jumpCount ω t = n}, finiteCharacter N k (position N start ω n) ∂walkLaw := by
    rw [← integral_indicator hevent]
    apply integral_congr_ae
    filter_upwards [heqH] with ω hω
    rw [hω, heqD]
    split_ifs <;> simp_all [Set.indicator]
  have hprob : (∫ ω : WalkSample, fH (H ω) ∂walkLaw) =
      ((walkLaw {ω | jumpCount ω t = n}).toReal : ℂ) := by
    rw [integral_congr_ae heqH]
    simpa [Set.indicator, Measure.real] using integral_indicator_const (μ := walkLaw) (1 : ℂ) hevent
  have hright : (∫ ω : WalkSample, fD (D ω) ∂walkLaw) =
      ∫ ω, finiteCharacter N k (position N start ω n) ∂walkLaw :=
    integral_congr_ae (Filter.Eventually.of_forall heqD)
  change (∫ ω : WalkSample, fH (H ω) * fD (D ω) ∂walkLaw) =
    (∫ ω : WalkSample, fH (H ω) ∂walkLaw) * (∫ ω : WalkSample, fD (D ω) ∂walkLaw) at hfactor
  rw [hleft, hprob, hright] at hfactor
  exact hfactor

lemma poisson_fourier_hasSum (t lam : ℝ) (z : ℂ) :
    HasSum (fun n : ℕ => ((Real.exp (-t) * t ^ n / (n.factorial : ℝ) : ℝ) : ℂ) *
      (z * ((1 - lam : ℝ) : ℂ) ^ n)) (z * (Real.exp (-t * lam) : ℂ)) := by
  have h := (NormedSpace.expSeries_div_hasSum_exp (((t * (1 - lam) : ℝ) : ℂ))).mul_left
    (z * (Real.exp (-t) : ℂ))
  have hterm (n : ℕ) : ((Real.exp (-t) * t ^ n / (n.factorial : ℝ) : ℝ) : ℂ) *
      (z * ((1 - lam : ℝ) : ℂ) ^ n) =
      (z * (Real.exp (-t) : ℂ)) * ((((t * (1 - lam) : ℝ) : ℂ)) ^ n / (n.factorial : ℂ)) := by
    push_cast
    rw [mul_pow]
    ring
  have hlimit : (z * (Real.exp (-t) : ℂ)) * NormedSpace.exp (((t * (1 - lam) : ℝ) : ℂ)) =
      z * (Real.exp (-t * lam) : ℂ) := by
    rw [← Complex.exp_eq_exp_ℂ, ← Complex.ofReal_exp, mul_assoc, ← Complex.ofReal_mul,
      ← Real.exp_add]
    rw [show -t + t * (1 - lam) = -t * lam by ring]
  simpa only [hterm, hlimit] using h

lemma integral_walk_character (hWalk : WalkModelRegular)
    (N : Size) (start k : Vertex N) (t : ℝ) (ht : 0 ≤ t) :
    (∫ ω : WalkSample, finiteCharacter N k (walk N start ω t) ∂walkLaw) =
      finiteCharacter N k start * (Real.exp (-t * finiteEigenvalue N k) : ℂ) := by
  classical
  let events := fun n : ℕ => {ω : WalkSample | jumpCount ω t = n}
  have hcount : Measurable (fun ω : WalkSample => jumpCount ω t) :=
    measurable_jumpCount_joint.comp (measurable_prodMk_right (y := t))
  have hmeas (n : ℕ) : MeasurableSet (events n) := (measurableSet_singleton n).preimage hcount
  have hdisj : Pairwise (fun i j => Disjoint (events i) (events j)) := by
    intro i j hij
    apply Set.disjoint_left.mpr
    intro ω hi hj
    exact hij (hi.symm.trans hj)
  have hunion : (⋃ n : ℕ, events n) = Set.univ := by
    apply Set.eq_univ_of_forall
    intro ω
    exact Set.mem_iUnion.mpr ⟨jumpCount ω t, rfl⟩
  have hsum := hasSum_integral_iUnion hmeas hdisj
    (integrable_walk_character N start k t).integrableOn
  rw [hunion, Measure.restrict_univ] at hsum
  have hterm (n : ℕ) :
      (∫ ω in events n, finiteCharacter N k (walk N start ω t) ∂walkLaw) =
        ((Real.exp (-t) * t ^ n / (n.factorial : ℝ) : ℝ) : ℂ) *
          (finiteCharacter N k start * ((1 - finiteEigenvalue N k : ℝ) : ℂ) ^ n) := by
    have heq : Set.EqOn (fun ω => finiteCharacter N k (walk N start ω t))
        (fun ω => finiteCharacter N k (position N start ω n)) (events n) := by
      intro ω hω
      change jumpCount ω t = n at hω
      simp only [walk, if_neg (not_lt.mpr ht), hω]
    rw [setIntegral_congr_fun (hmeas n) heq,
      integral_character_on_jumpCount hWalk N start k t ht n,
      jumpCount_probability hWalk t ht n, integral_position_character]
  simp_rw [hterm] at hsum
  exact hsum.unique (poisson_fourier_hasSum t (finiteEigenvalue N k) (finiteCharacter N k start))

lemma integrable_walk_cosine (N : Size) (start k : Vertex N) (t : ℝ) :
    Integrable (fun ω : WalkSample => finiteCosine N k (walk N start ω t)) walkLaw := by
  simpa only [RCLike.re_eq_complex_re, finiteCharacter_re] using
    (integrable_walk_character N start k t).re

lemma integral_walk_cosine (hWalk : WalkModelRegular)
    (N : Size) (start k : Vertex N) (t : ℝ) (ht : 0 ≤ t) :
    (∫ ω : WalkSample, finiteCosine N k (walk N start ω t) ∂walkLaw) =
      Real.exp (-t * finiteEigenvalue N k) * finiteCosine N k start := by
  have h := integral_re (integrable_walk_character N start k t)
  rw [integral_walk_character hWalk N start k t ht] at h
  simpa only [RCLike.re_eq_complex_re, finiteCharacter_re, Complex.mul_re,
    Complex.ofReal_re, Complex.ofReal_im, mul_zero, zero_mul, sub_zero, mul_comm] using h

lemma walk_start_sub (N : Size) (x y : Vertex N) (ω : WalkSample) (t : ℝ) :
    walk N (x - y) ω t = walk N x ω t - y := by
  unfold walk
  split_ifs <;> simp [position, sub_eq_add_neg, add_assoc, add_left_comm, add_comm]

lemma fourier_transition_formula (hWalk : WalkModelRegular)
    (N : Size) (t : ℝ) (ht : 0 ≤ t) (x y : Vertex N) :
    vertexCount N * transitionProbability N x y t = 1 +
      ∑ k ∈ nonzeroFrequencies N, Real.exp (-t * finiteEigenvalue N k) *
        finiteCosine N k (x - y) := by
  classical
  have hpoint (ω : WalkSample) :
      (∑ k : Vertex N, finiteCosine N k (walk N (x - y) ω t)) =
        if walk N x ω t = y then vertexCount N else 0 := by
    rw [finiteCosine_sum, walk_start_sub]
    simp only [sub_eq_zero]
  have hevent : MeasurableSet {ω : WalkSample | walk N x ω t = y} :=
    ((measurable_walk_eq_joint N x y).comp (measurable_prodMk_right (y := t))).setOf
  have hsum : (∑ k : Vertex N, Real.exp (-t * finiteEigenvalue N k) * finiteCosine N k (x - y)) =
      vertexCount N * transitionProbability N x y t := by
    have hint : (∫ ω : WalkSample, ∑ k : Vertex N, finiteCosine N k (walk N (x - y) ω t) ∂walkLaw) =
        ∑ k : Vertex N, Real.exp (-t * finiteEigenvalue N k) * finiteCosine N k (x - y) := by
      rw [integral_finsetSum _ (fun k _ => integrable_walk_cosine N (x - y) k t)]
      simp_rw [integral_walk_cosine hWalk N (x - y) _ t ht]
    rw [← hint, integral_congr_ae (Filter.Eventually.of_forall hpoint)]
    simpa [Set.indicator, Measure.real, transitionProbability, mul_comm] using
      integral_indicator_const (μ := walkLaw) (vertexCount N) hevent
  rw [← hsum]
  have hid := Finset.sum_erase_add (s := (Finset.univ : Finset (Vertex N)))
    (fun k => Real.exp (-t * finiteEigenvalue N k) * finiteCosine N k (x - y))
    (Finset.mem_univ 0)
  have hz : Real.exp (-t * finiteEigenvalue N 0) * finiteCosine N 0 (x - y) = 1 := by
    simp [finiteEigenvalue, finiteCosine, fourierAngle]
  rw [hz] at hid
  simpa only [nonzeroFrequencies, add_comm] using hid.symm

theorem fourier_walk_identities (hWalk : WalkModelRegular) : FourierWalkIdentities :=
  fourier_walk_identities_of_transition (fourier_transition_formula hWalk)

end TorusCoverTime.Blocks.B
