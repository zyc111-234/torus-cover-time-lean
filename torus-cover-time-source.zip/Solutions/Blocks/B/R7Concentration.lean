import Solutions.Blocks.B.R7MomentBounds
import Solutions.Blocks.B.BernsteinConcentration
import Solutions.Blocks.B.R6KernelEstimates

/-! R7.3 for the actual independent exact-exit blocks. Each factor uses its
own entrance, exit, and exact expectation; there is no common-law assumption. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

def r7VarianceConstant : ℝ := 256*r7GreenAverageConstant^2

theorem r7VarianceConstant_pos : 0 < r7VarianceConstant := by
  unfold r7VarianceConstant
  exact mul_pos (by norm_num) (sq_pos_of_pos r7GreenAverageConstant_pos)

theorem r7_centered_occupation_exp (hWalk : WalkModelRegular) (γ : ℝ) (hγ : 0 < γ) :
    ∀ᶠ q : ℝ in atTop, ∀ N : Size, ∀ c a b : Vertex N,
      2*(Real.exp (q+2*q^γ)+1) < N.val →
      |periodicDistance a c-Real.exp (q+q^γ)| ≤ 2 →
      diskExteriorNeighbor N c (Real.exp (q+2*q^γ)) b →
      ∀ θ : ℝ, |θ| ≤ 1/(r7MomentConstant*q^γ) →
      let A := harmonicExitOccupation N c (Real.exp (q+1)) (Real.exp (q+2*q^γ)) a
      let μ := exactExitLaw N (torusDisk N c (Real.exp (q+2*q^γ))) a b
      Integrable (fun ω => Real.exp (θ*(A ω-∫ ω, A ω ∂μ))) μ ∧
        (∫ ω, Real.exp (θ*(A ω-∫ ω, A ω ∂μ)) ∂μ) ≤
          Real.exp ((r7VarianceConstant*(q^γ)^2)*θ^2) := by
  filter_upwards [r7_occupation_exp_bound hWalk γ hγ, r6_endpoint_probability_pos γ hγ,
    (tendsto_rpow_atTop hγ).eventually_ge_atTop (1:ℝ)] with q he hp hw
  intro N c a b hsmall ha hb θ hθ
  have hCpos := r7GreenAverageConstant_pos
  have hw0 : 0 < q^γ := by linarith
  let μ := exactExitLaw N (torusDisk N c (Real.exp (q+2*q^γ))) a b
  have : IsProbabilityMeasure μ := cond_isProbabilityMeasure (hp N c a b hsmall ha hb).ne'
  have hlam : 0 < 1/(4*r7GreenAverageConstant*q^γ) := by positivity
  have hθ' : |θ| ≤ (1/(4*r7GreenAverageConstant*q^γ))/2 := by
    have heq : (1/(4*r7GreenAverageConstant*q^γ))/2 = 1/(r7MomentConstant*q^γ) := by
      unfold r7MomentConstant
      field_simp
      <;> ring
    rw [heq]
    exact hθ
  have h := centered_exp_bound_of_positive_exp μ _ (measurable_harmonicExitOccupation N c _ _ a)
    (harmonicExitOccupation_nonneg N c _ _ a) _ hlam (he N c a b hsmall hb) θ hθ'
  have hC : 16/(1/(4*r7GreenAverageConstant*q^γ))^2 = r7VarianceConstant*(q^γ)^2 := by
    simp only [one_div, inv_pow, div_inv_eq_mul, r7VarianceConstant]
    ring
  simpa only [hC] using h

def harmonicExitBlockSum (N : Size) (c : Vertex N) (r R : ℝ) (m : ℕ)
    (a : Fin m → Vertex N) (ω : Fin m → WalkSample) : ℝ :=
  ∑ i, harmonicExitOccupation N c r R (a i) (ω i)

def harmonicExitMeanSum (N : Size) (c : Vertex N) (r R : ℝ) (m : ℕ)
    (a b : Fin m → Vertex N) : ℝ :=
  ∑ i, ∫ ω, harmonicExitOccupation N c r R (a i) ω ∂exactExitLaw N (torusDisk N c R) (a i) (b i)

theorem harmonicExitBlockSum_nonneg (N : Size) (c : Vertex N) (r R : ℝ) (m : ℕ)
    (a : Fin m → Vertex N) (ω : Fin m → WalkSample) : 0 ≤ harmonicExitBlockSum N c r R m a ω :=
  Finset.sum_nonneg (fun i _ => harmonicExitOccupation_nonneg N c r R (a i) (ω i))

theorem r7_independent_occupation_concentration (hWalk : WalkModelRegular) (γ : ℝ) (hγ : 0 < γ) :
    ∀ᶠ q : ℝ in atTop, ∀ N : Size, ∀ c : Vertex N, ∀ m : ℕ, 0 < m →
      ∀ a b : Fin m → Vertex N,
      2*(Real.exp (q+2*q^γ)+1) < N.val →
      (∀ i, |periodicDistance (a i) c-Real.exp (q+q^γ)| ≤ 2) →
      (∀ i, diskExteriorNeighbor N c (Real.exp (q+2*q^γ)) (b i)) → ∀ z : ℝ, 0 ≤ z →
      (exactExitProductLaw N (torusDisk N c (Real.exp (q+2*q^γ))) m a b).real
        {ω | z < |harmonicExitBlockSum N c (Real.exp (q+1)) (Real.exp (q+2*q^γ)) m a ω-
          harmonicExitMeanSum N c (Real.exp (q+1)) (Real.exp (q+2*q^γ)) m a b|} ≤
        2*Real.exp (-min (z^2/(4*(m:ℝ)*(r7VarianceConstant*(q^γ)^2)))
          (z/(2*r7MomentConstant*q^γ))) := by
  filter_upwards [r7_centered_occupation_exp hWalk γ hγ, r6_endpoint_probability_pos γ hγ,
    (tendsto_rpow_atTop hγ).eventually_ge_atTop (1:ℝ)] with q hc hp hw
  intro N c m hm a b hsmall ha hb z hz
  let R := Real.exp (q+2*q^γ)
  let r := Real.exp (q+1)
  let D := torusDisk N c R
  let ν := fun i => exactExitLaw N D (a i) (b i)
  have (i : Fin m) : IsProbabilityMeasure (ν i) :=
    cond_isProbabilityMeasure (hp N c (a i) (b i) hsmall (ha i) (hb i)).ne'
  let μ := Measure.pi ν
  let A := fun i => harmonicExitOccupation N c r R (a i)
  let X := fun i ω => A i ω-∫ ω, A i ω ∂ν i
  let Y := fun i (ω : Fin m → WalkSample) => X i (ω i)
  have hX : ∀ i, Measurable (X i) := fun i => (measurable_harmonicExitOccupation N c r R (a i)).sub_const _
  have hY : ∀ i, Measurable (Y i) := fun i => (hX i).comp (measurable_pi_apply i)
  have hind : iIndepFun Y μ := iIndepFun_pi (fun i => (hX i).aemeasurable)
  have hmgf : ∀ θ : ℝ, |θ| ≤ 1/(r7MomentConstant*q^γ) → ∀ i,
      Integrable (fun ω => Real.exp (θ*Y i ω)) μ ∧
        (∫ ω, Real.exp (θ*Y i ω) ∂μ) ≤ Real.exp ((r7VarianceConstant*(q^γ)^2)*θ^2) := by
    intro θ hθ i
    have hi := hc N c (a i) (b i) hsmall (ha i) (hb i) θ hθ
    have hpres := measurePreserving_eval ν i
    refine ⟨hpres.integrable_comp_of_integrable hi.1, ?_⟩
    have he := integral_map (μ := μ) (φ := fun ω : Fin m → WalkSample => ω i)
      (f := fun ω => Real.exp (θ*X i ω))
      (measurable_pi_apply i).aemeasurable ((hX i).const_mul θ).exp.aestronglyMeasurable
    rw [hpres.map_eq] at he
    exact he.symm.le.trans hi.2
  have h := independent_bernstein_tail μ m hm Y hY hind
    (r7VarianceConstant*(q^γ)^2) (1/(r7MomentConstant*q^γ))
      (mul_pos r7VarianceConstant_pos (sq_pos_of_pos (by linarith)))
      (by have := r7MomentConstant_pos; positivity) hmgf z hz
  have he : (1/(r7MomentConstant*q^γ))*z/2 = z/(2*r7MomentConstant*q^γ) := by field_simp <;> ring
  simpa only [he, Y, X, A, μ, ν, D, r, R, Finset.sum_sub_distrib,
    harmonicExitBlockSum, harmonicExitMeanSum, exactExitProductLaw] using h

end TorusCoverTime.Blocks.B

