import Solutions.Blocks.B.PointFeynmanKac
import Solutions.Blocks.B.ContinuousFourier

/-! A sharp smoothed bound for the actual single-site soft event, with a
specified terminal vertex. All local occupation before time t is retained. -/
noncomputable section
open MeasureTheory Filter Set Classical
open scoped ENNReal Topology BigOperators
namespace TorusCoverTime.Blocks.B

theorem pointKillingKernel_smoothed (N : Size) (c a b : Vertex N) (s t M : ℝ)
    (hs : 0 ≤ s) (hst : s ≤ t) (hM : 0 ≤ M)
    (hmix : ∀ x : Vertex N, transitionProbability N x x s ≤ M) :
    pointKillingKernel N c t a b ≤ M*Real.exp (-pointKillingRate N*(t-s)) := by
  let B := M*Real.exp (-pointKillingRate N*(t-s))
  have hB : 0 ≤ B := mul_nonneg hM (Real.exp_pos _).le
  have hd (x : Vertex N) : pointKillingKernel N c t x x ≤ B := by
    apply (pointKillingKernel_diag_decay N c x s t hst).trans
    have h := (pointKillingKernel_le_transition N c x x s hs).trans (hmix x)
    simpa only [B,mul_comm] using mul_le_mul_of_nonneg_left h (Real.exp_pos (-pointKillingRate N*(t-s))).le
  have h := (pointKillingKernel_cauchy N c a b t).trans
    (mul_le_mul (hd a) (hd b) (pointKillingKernel_diag_nonneg N c b t) hB)
  change pointKillingKernel N c t a b ≤ B
  nlinarith

theorem point_soft_joint_laplace (N : Size) (c a b : Vertex N) (t u : ℝ) (ht : 0 ≤ t) :
    walkLaw.real {ω | localTime N a ω t c ≤ u ∧ walk N a ω t = b} ≤
      Real.exp u*pointKillingKernel N c t a b := by
  let E : Set WalkSample := {ω | localTime N a ω t c ≤ u ∧ walk N a ω t = b}
  have hE : MeasurableSet E :=
    (measurableSet_le ((localTime_joint_measurable N a c).comp
      (measurable_id.prodMk measurable_const)) measurable_const).inter
      (((measurable_walk_eq_joint N a b).comp (measurable_id.prodMk measurable_const)).setOf)
  have hi : Integrable (E.indicator (fun _ => (1:ℝ))) walkLaw := (integrable_const 1).indicator hE
  have hbound (ω : WalkSample) : E.indicator (fun _ => (1:ℝ)) ω ≤
      Real.exp u*pointOccupationWeight N c a b t ω := by
    by_cases hω : ω ∈ E
    · rw [indicator_of_mem hω,pointOccupationWeight,if_pos hω.2,← Real.exp_add]
      exact Real.one_le_exp_iff.mpr (by linarith [hω.1])
    · rw [indicator_of_notMem hω]
      exact mul_nonneg (Real.exp_pos _).le (pointOccupationWeight_nonneg N c a b t ω)
  have h := integral_mono hi ((pointOccupationWeight_integrable N c a b t).const_mul (Real.exp u)) hbound
  rw [integral_indicator_const _ hE,smul_eq_mul,mul_one,integral_const_mul] at h
  rw [pointKillingKernel_eq_occupation N c a b t ht]
  exact h

theorem point_soft_joint_smoothed (N : Size) (c a b : Vertex N) (s t u M : ℝ)
    (hs : 0 ≤ s) (hst : s ≤ t) (hM : 0 ≤ M)
    (hmix : ∀ x : Vertex N, transitionProbability N x x s ≤ M) :
    walkLaw.real {ω | localTime N a ω t c ≤ u ∧ walk N a ω t = b} ≤
      Real.exp u*M*Real.exp (-pointKillingRate N*(t-s)) := by
  apply (point_soft_joint_laplace N c a b t u (hs.trans hst)).trans
  simpa only [mul_assoc] using mul_le_mul_of_nonneg_left
    (pointKillingKernel_smoothed N c a b s t M hs hst hM hmix) (Real.exp_pos u).le

theorem point_soft_joint_after_mixing (hWalk : WalkModelRegular) :
    ∀ᶠ N : Size in atTop, 0 ≤ mixingTime N ∧ ∀ c a b : Vertex N, ∀ t u : ℝ,
      mixingTime N ≤ t →
      walkLaw.real {ω | localTime N a ω t c ≤ u ∧ walk N a ω t = b} ≤
        Real.exp u*(2/vertexCount N)*Real.exp (-pointKillingRate N*(t-mixingTime N)) := by
  filter_upwards [(fourier_walk_identities hWalk).2.2.2,
    blockB_logSize_tendsto.eventually (eventually_ge_atTop 1)] with N hmix hL
  have hs : 0 ≤ mixingTime N := by
    unfold mixingTime
    exact mul_nonneg (by have := vertexCount_pos N; positivity) (Real.log_nonneg hL)
  refine ⟨hs,?_⟩
  intro c a b t u ht
  apply point_soft_joint_smoothed N c a b (mixingTime N) t u (2/vertexCount N) hs ht
    (by have := vertexCount_pos N; positivity)
  intro x
  apply (le_div_iff₀ (vertexCount_pos N)).mpr
  have hh := (le_abs_self _).trans (hmix (mixingTime N) le_rfl x x).1
  have hpow : (logSize N)^(-8:ℝ) ≤ 1 := Real.rpow_le_one_of_one_le_of_nonpos hL (by norm_num)
  nlinarith

end TorusCoverTime.Blocks.B
