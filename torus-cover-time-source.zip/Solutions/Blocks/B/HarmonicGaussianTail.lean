import Solutions.Blocks.B.HarmonicFieldVariance

/-! Sharp Gaussian tails with a variance upper bound. The bound also covers
zero variance and a zero threshold, using a positive comparison variance. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal NNReal
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

theorem centered_gaussian_upper_tail {Ω : Type*} [MeasurableSpace Ω]
    (μ : Measure Ω) [IsProbabilityMeasure μ] (X : Ω → ℝ) (hX : HasGaussianLaw X μ)
    (hmean : (∫ ω, X ω ∂μ) = 0) (V a : ℝ) (hV : 0 < V) (ha : 0 ≤ a) (hvar : Var[X;μ] ≤ V) :
    μ.real {ω | a ≤ X ω} ≤ Real.exp (-a^2/(2*V)) := by
  have hlaw := hX.map_eq_gaussianReal
  rw [hmean] at hlaw
  have hmgf (t : ℝ) : mgf X μ t = Real.exp (Var[X;μ]*t^2/2) := by
    rw [mgf_gaussianReal hlaw,Real.coe_toNNReal _ (variance_nonneg X μ),zero_mul,zero_add]
  have hint : Integrable (fun ω => Real.exp ((a/V)*X ω)) μ := by
    rw [← mgf_pos_iff,hmgf]
    exact Real.exp_pos _
  have hh := measure_ge_le_exp_mul_mgf (μ := μ) (X := X) a (div_nonneg ha hV.le) hint
  rw [hmgf,← Real.exp_add] at hh
  apply hh.trans
  apply Real.exp_le_exp.mpr
  have hm := mul_le_mul_of_nonneg_right hvar (sq_nonneg (a/V))
  have he : -(a/V)*a+V*(a/V)^2/2 = -a^2/(2*V) := by field_simp; ring
  rw [← he]
  linarith

theorem centered_gaussian_abs_tail {Ω : Type*} [MeasurableSpace Ω]
    (μ : Measure Ω) [IsProbabilityMeasure μ] (X : Ω → ℝ) (hX : HasGaussianLaw X μ)
    (hmean : (∫ ω, X ω ∂μ) = 0) (V a : ℝ) (hV : 0 < V) (ha : 0 ≤ a) (hvar : Var[X;μ] ≤ V) :
    μ.real {ω | a ≤ |X ω|} ≤ 2*Real.exp (-a^2/(2*V)) := by
  have hneg : HasGaussianLaw (fun ω => -X ω) μ := by
    have h := hX.neg
    change HasGaussianLaw (fun ω => -X ω) μ at h
    exact h
  have hmneg : (∫ ω, -X ω ∂μ) = 0 := by rw [integral_neg,hmean,neg_zero]
  have hvneg : Var[fun ω => -X ω;μ] ≤ V := by simpa only [variance_fun_neg] using hvar
  have h1 := centered_gaussian_upper_tail μ X hX hmean V a hV ha hvar
  have h2 := centered_gaussian_upper_tail μ (fun ω => -X ω) hneg hmneg V a hV ha hvneg
  have hs : {ω | a ≤ |X ω|} ⊆ {ω | a ≤ X ω} ∪ {ω | a ≤ -X ω} := by
    intro ω hω
    change a ≤ |X ω| at hω
    change a ≤ X ω ∨ a ≤ -X ω
    by_cases hx : 0 ≤ X ω
    · exact Or.inl (by simpa only [abs_of_nonneg hx] using hω)
    · exact Or.inr (by simpa only [abs_of_neg (lt_of_not_ge hx)] using hω)
  have hh := (measureReal_mono (μ := μ) hs).trans (measureReal_union_le (μ := μ) _ _)
  linarith

theorem harmonicGaussianAverage_abs_tail (N : Size) (c : Vertex N) (q a : ℝ)
    (hq : 0 ≤ q) (hqL : q ≤ logSize N) (ha : 0 ≤ a)
    (hsmall : 2*(Real.exp (q+1)+1) < N.val) :
    (finiteFieldLaw N).real {ξ | a ≤ |harmonicGaussianAverage N c q ξ|} ≤
      2*Real.exp (-a^2/(logSize N-q+2*harmonicVarianceErrorConstant)) := by
  have hV : 0 < (logSize N-q)/2+harmonicVarianceErrorConstant := by
    have := harmonicVarianceErrorConstant_pos
    linarith
  have hh := centered_gaussian_abs_tail (finiteFieldLaw N) _ (harmonicGaussianAverage_gaussian N c q)
    (harmonicGaussianAverage_mean N c q) _ a hV ha (harmonicGaussianAverage_variance_bound N c q hq hsmall)
  have he : 2*((logSize N-q)/2+harmonicVarianceErrorConstant) = logSize N-q+2*harmonicVarianceErrorConstant := by ring
  rwa [he] at hh

end TorusCoverTime.Blocks.B
