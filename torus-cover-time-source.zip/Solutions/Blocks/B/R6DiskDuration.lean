import Solutions.Blocks.B.DiskExitTail
import Solutions.Blocks.B.R6DurationScale

/-! The actual disk duration estimate feeds into the manuscript's coarse window.
Only the separately open R6.1 endpoint and R6.3 avoidance bounds remain inputs. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

lemma r6_disk_radius_embedding_real (γ : ℝ) (hγ : 0 < γ) :
    ∀ᶠ L : ℝ in atTop, ∀ q : ℝ, 0 ≤ q → q ≤ L-L^(16*γ) →
      2*(Real.exp (q+2*q^γ)+1) < Real.exp L := by
  filter_upwards [eventually_ge_atTop (0 : ℝ), eventually_ge_atTop (Real.log 8),
    power_eventually_le_power 2 γ (16*γ) (1/2) (by linarith) (by norm_num),
    (tendsto_rpow_atTop (by positivity : 0 < 16*γ)).eventually_ge_atTop (2*Real.log 8)]
      with L hL hL8 hpow hQ
  intro q hq hqL
  have hqL' : q ≤ L := hqL.trans (sub_le_self L (Real.rpow_nonneg hL _))
  have hqpow := Real.rpow_le_rpow hq hqL' hγ.le
  have hr : Real.exp (q+2*q^γ) ≤ Real.exp L / 8 := by
    calc
      _ ≤ Real.exp (L-Real.log 8) := Real.exp_le_exp.mpr (by linarith)
      _ = _ := by rw [Real.exp_sub, Real.exp_log (by norm_num : (0 : ℝ) < 8)]
  have h8 : (8 : ℝ) ≤ Real.exp L := by
    have h := Real.exp_le_exp.mpr hL8
    simpa only [Real.exp_log (by norm_num : (0 : ℝ) < 8)] using h
  linarith

lemma r6_disk_radius_embedding (γ : ℝ) (hγ : 0 < γ) :
    ∀ᶠ N : Size in atTop, ∀ q : ℝ, 0 ≤ q → q ≤ logSize N-(logSize N)^(16*γ) →
      2*(Real.exp (q+2*q^γ)+1) < (N.val : ℝ) := by
  filter_upwards [blockB_logSize_tendsto.eventually (r6_disk_radius_embedding_real γ hγ)] with N hN
  intro q hq hqL
  have h := hN q hq hqL
  simpa only [logSize, Real.exp_log (show (0 : ℝ) < N.val by
    exact_mod_cast (show 0 < N.val by have := N.property; omega))] using h

lemma r6_disk_conditioned_tail_constants (hWalk : WalkModelRegular)
    (N : Size) (y : Vertex N) (R : ℝ) (hR : 1 ≤ R) (hsmall : 2*(R+1) < N.val)
    (a b : Vertex N) (t cE CE c C : ℝ) (ht : 0 ≤ t) (hcE : 0 < cE)
    (hcoeff : 9/cE ≤ C) (hpower : CE+2 ≤ C) (hdecay : c ≤ 1/4)
    (hexit : ENNReal.ofReal (cE*R^(-CE)) ≤ walkLaw (exitsThrough N (torusDisk N y R) a b)) :
    exactExitLaw N (torusDisk N y R) a b
      {ω | t < finiteExitDuration N (torusDisk N y R) a ω} ≤
        ENNReal.ofReal (C*R^C*Real.exp (-c*t/R^2)) := by
  apply (r6_disk_duration_of_endpoint_lower hWalk N y R hR hsmall a b t cE CE ht hcE hexit).trans
  apply ENNReal.ofReal_le_ofReal
  have hC : 0 ≤ C := (by positivity : (0 : ℝ) ≤ 9/cE).trans hcoeff
  apply mul_le_mul ?_ ?_ (Real.exp_pos _).le (mul_nonneg hC (Real.rpow_nonneg (by linarith) _))
  · exact mul_le_mul hcoeff (Real.rpow_le_rpow_of_exponent_le hR hpower)
      (Real.rpow_nonneg (by linarith) _) hC
  · apply Real.exp_le_exp.mpr
    have hm := mul_le_mul_of_nonneg_right hdecay (div_nonneg ht (sq_nonneg R))
    calc
      _ = -(1/4*(t/R^2)) := by ring
      _ ≤ -(c*(t/R^2)) := neg_le_neg hm
      _ = _ := by ring

theorem r6_duration_superexponential_of_endpoint_avoidance (hWalk : WalkModelRegular)
    (γ cE CE cA : ℝ) (hγ : 0 < γ) (hγ1 : γ ≤ 1) (hcE : 0 < cE) (hcA : 0 < cA) :
    ∀ᶠ N : Size in atTop, ∀ y : Vertex N, ∀ K : Finset (Vertex N), ∀ m : ℕ,
      ∀ a b : Fin m → Vertex N, ∀ q u : ℝ,
      0 ≤ q → q ≤ logSize N-(logSize N)^(16*γ) → (m : ℝ) ≤ (logSize N)^4+1 →
      K.Nonempty → 0 ≤ u →
      (∀ i, ENNReal.ofReal (cE*(Real.exp (q+2*q^γ))^(-CE)) ≤
        walkLaw (exitsThrough N (torusDisk N y (Real.exp (q+2*q^γ))) (a i) (b i))) →
      (∀ i, ENNReal.ofReal cA ≤ exactExitLaw N (torusDisk N y (Real.exp (q+2*q^γ))) (a i) (b i)
        (exitsThroughAvoiding N (torusDisk N y (Real.exp (q+2*q^γ))) K (a i) (b i))) →
      (exactExitProductLaw N (torusDisk N y (Real.exp (q+2*q^γ))) m a b)[{ω | ∃ i,
        Real.exp (2*logSize N-(logSize N)^(16*γ)) <
          finiteExitDuration N (torusDisk N y (Real.exp (q+2*q^γ))) (a i) (ω i)} |
        exitBlockSoftness N (torusDisk N y (Real.exp (q+2*q^γ))) K m a u] ≤
          ENNReal.ofReal (Real.exp (-Real.exp ((logSize N)^(16*γ)/2))) := by
  let c := min cA (1/4 : ℝ)
  let C := max 1 (max (9/cE) (CE+2))
  have hc : 0 < c := lt_min hcA (by norm_num)
  have hC : 0 < C := lt_of_lt_of_le (by norm_num : (0 : ℝ) < 1) (le_max_left _ _)
  have hcoeff : 9/cE ≤ C := (le_max_left _ _).trans (le_max_right _ _)
  have hpower : CE+2 ≤ C := (le_max_right _ _).trans (le_max_right _ _)
  filter_upwards [r6_disk_radius_embedding γ hγ, blockB_logSize_tendsto.eventually
    (r6_duration_superexponential_of_disk_bounds hWalk γ C c hγ hγ1 hC hc)] with N hsmall hscalar
  intro y K m a b q u hq hqL hm hK hu hexit havoid
  let R := Real.exp (q+2*q^γ)
  let D := torusDisk N y R
  have hR : 1 ≤ R := Real.one_le_exp_iff.mpr (by positivity)
  have hRsmall : 2*(R+1) < N.val := hsmall q hq hqL
  apply hscalar N D K m a b q u hq hqL hm hK hu
  · intro i
    have hp : 0 < cE*R^(-CE) := mul_pos hcE (Real.rpow_pos_of_pos (Real.exp_pos _) _)
    exact ne_of_gt ((ENNReal.ofReal_pos.mpr hp).trans_le (hexit i))
  · intro i
    exact (ENNReal.ofReal_le_ofReal (min_le_left cA (1/4))).trans (havoid i)
  · intro i
    exact r6_disk_conditioned_tail_constants hWalk N y R hR hRsmall (a i) (b i)
      (Real.exp (2*logSize N-(logSize N)^(16*γ))) cE CE c C (Real.exp_pos _).le hcE
      hcoeff hpower (min_le_right _ _) (hexit i)

end TorusCoverTime.Blocks.B
