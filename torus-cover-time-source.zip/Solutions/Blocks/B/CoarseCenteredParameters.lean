import Solutions.Blocks.B.R7IterationParameters

/-! The R8 deviation threshold discharges the mean-bias and small-deviation inputs uniformly. -/
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B


theorem r8_centered_side_conditions (γ : ℝ) (hγ : 0 < γ) :
    ∀ᶠ N : Size in atTop, ∀ q v : ℝ,
      (logSize N)^(16*γ) ≤ q → q ≤ logSize N → q ≤ v → v ≤ 10*logSize N →
      0 ≤ (logSize N)^(4*γ)/2 ∧ (logSize N)^(4*γ)/2 ≤ v ∧
      2*r7MeanConstant*Real.exp (-r7MeanExponent*q^γ)*v ≤ (logSize N)^(4*γ)/2 := by
  filter_upwards [r7_iteration_side_conditions γ 10 hγ (by norm_num),
    blockB_logSize_tendsto.eventually_ge_atTop 1,
    ((tendsto_rpow_atTop (by positivity : 0 < 2*γ)).comp blockB_logSize_tendsto).eventually_ge_atTop 2]
    with N hN hL hpow
  intro q v hq hqL hqv hvL
  change 2 ≤ (logSize N)^(2*γ) at hpow
  have hs := hN q v hq hqL hqv hvL
  have hlarge : (logSize N)^(2*γ) ≤ (logSize N)^(4*γ)/2 := by
    have he : (logSize N)^(4*γ) = ((logSize N)^(2*γ))^2 := by
      rw [← Real.rpow_mul_natCast (logSize_pos N).le]
      congr 1
      ring
    rw [he]
    nlinarith
  have hupper : (logSize N)^(4*γ)/2 ≤ q :=
    (by have ht := Real.rpow_le_rpow_of_exponent_le hL (by linarith : 4*γ ≤ 16*γ)
        have hz := Real.rpow_nonneg (logSize_pos N).le (4*γ)
        linarith : (logSize N)^(4*γ)/2 ≤ (logSize N)^(16*γ)).trans hq
  exact ⟨by positivity,hupper.trans hqv,hs.2.2.2.2.2.1.trans hlarge⟩

theorem r8_centered_exponent_scale (L q γ : ℝ) (hL : 0 < L) (hq : 0 < q)
    (hqL : q ≤ L) (hγ : 0 ≤ γ) :
    L^(7*γ)/4 ≤ (L^(4*γ)/2)^2/q^γ := by
  have hpow : q^γ ≤ L^γ := Real.rpow_le_rpow hq.le hqL hγ
  have he : L^(7*γ)*L^γ = (L^(4*γ))^2 := by
    rw [← Real.rpow_add hL,← Real.rpow_mul_natCast hL.le]
    congr 1
    ring
  apply (le_div_iff₀ (Real.rpow_pos_of_pos hq γ)).mpr
  have hm := mul_le_mul_of_nonneg_left hpow (Real.rpow_nonneg hL.le (7*γ))
  rw [he] at hm
  nlinarith


end TorusCoverTime.Blocks.B
