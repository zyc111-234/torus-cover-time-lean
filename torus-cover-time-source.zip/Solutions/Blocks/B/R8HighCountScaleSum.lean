import Solutions.Blocks.B.R8HighCountSpatialSum

/-! Summation of the actual high-count soft-site mass over every coarse
integer scale, without discretizing time or discarding the spatial cost. -/
noncomputable section
open MeasureTheory Filter Set Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

def r8AllHighCountMass (N : Size) (γ U l r : ℝ) : ℝ≥0∞ :=
  ∑ k ∈ r7CoarseIntegerScales N γ, ∑ c : Vertex N, r8HighCountWindowMass N c γ k U l r

theorem r8_all_high_count_bound (hWalk : WalkModelRegular) (γ U H : ℝ)
    (hγ : 0 < γ) (hγ1 : γ < 1) (hU : 0 ≤ U) (hH : 0 ≤ H) :
    ∀ᶠ N : Size in atTop, ∀ l r : ℝ, r-l ≤ 2*H*timeScale N →
      r8AllHighCountMass N γ U l r ≤ ENNReal.ofReal (4*H*logSize N*Real.exp (-36*logSize N)) := by
  filter_upwards [r8_high_count_spatial_sum hWalk γ U H hγ hγ1 hU hH,
    blockB_logSize_tendsto.eventually_ge_atTop 1] with N hN hL
  intro l r hlen
  unfold r8AllHighCountMass
  calc
    _ ≤ ∑ _k ∈ r7CoarseIntegerScales N γ, ENNReal.ofReal (2*H*Real.exp (-36*logSize N)) := by
      apply Finset.sum_le_sum
      intro k hk
      have hks := (mem_r7CoarseIntegerScales N γ k).mp hk
      exact hN k l r hks.1 hks.2 hlen
    _ ≤ ENNReal.ofReal (2*logSize N)*ENNReal.ofReal (2*H*Real.exp (-36*logSize N)) := by
      rw [Finset.sum_const,nsmul_eq_mul]
      apply mul_le_mul' _ le_rfl
      simpa only [ENNReal.ofReal_natCast] using ENNReal.ofReal_le_ofReal (r7_coarse_integer_scales_card N γ hL)
    _ = _ := by rw [← ENNReal.ofReal_mul (by positivity : 0 ≤ 2*logSize N)]; congr 1; ring

end TorusCoverTime.Blocks.B
