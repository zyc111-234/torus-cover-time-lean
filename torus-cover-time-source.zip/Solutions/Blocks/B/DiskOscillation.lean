import Solutions.Blocks.B.DiskHarnack

/-! Quantitative oscillation contraction from the proved Harnack inequality.
Only local bounds are required; truncation extends the shifted function
nonnegatively outside the disk without changing its interior generator. -/

noncomputable section
open Classical
namespace TorusCoverTime.Blocks.B

def diskOscillationScale : ℝ := 8*diskGreenInnerScale
def diskOscillationFactor : ℝ := 1-1/diskHarnackConstant

theorem diskOscillationScale_ge_two : 2 ≤ diskOscillationScale := by
  have := diskGreenInnerScale_ge_four
  unfold diskOscillationScale
  linarith

theorem diskOscillationFactor_bounds : 0 < diskOscillationFactor ∧ diskOscillationFactor < 1 := by
  have hH := diskHarnackConstant_gt_one
  have hH0 : 0 < diskHarnackConstant := by linarith
  have hlt : 1/diskHarnackConstant < 1 := (div_lt_one hH0).mpr hH
  have hp : 0 < 1/diskHarnackConstant := one_div_pos.mpr hH0
  unfold diskOscillationFactor
  constructor <;> linarith

theorem disk_shift_harnack (N : Size) (c : Vertex N) (R : ℝ)
    (hR : 2*diskHarnackRadiusThreshold ≤ R) (hsmall : 4*(R+1) < N.val)
    (f : Vertex N → ℝ) (l : ℝ)
    (hl : ∀ z ∈ torusDisk N c R, l ≤ f z)
    (hg : ∀ z ∈ torusDisk N c R, generator N f z = 0)
    (x y : Vertex N) (hx : periodicDistance x c ≤ R/diskOscillationScale)
    (hy : periodicDistance y c ≤ R/diskOscillationScale) :
    f y-l ≤ diskHarnackConstant*(f x-l) := by
  have hT := diskHarnackRadiusThreshold_ge_one
  have hR2 : 2 ≤ R := by linarith
  have hS := diskOscillationScale_ge_two
  have hS0 : 0 < diskOscillationScale := by linarith
  have hr : R/diskOscillationScale ≤ R/2 :=
    div_le_div_of_nonneg_left (by linarith) (by norm_num) hS
  have hxD : x ∈ torusDisk N c R := (mem_torusDisk N c x R).mpr (by linarith)
  have hyD : y ∈ torusDisk N c R := (mem_torusDisk N c y R).mpr (by linarith)
  let F := fun z => max (f z-l) 0
  have hF (z : Vertex N) (hz : z ∈ torusDisk N c R) : F z = f z-l :=
    max_eq_left (sub_nonneg.mpr (hl z hz))
  have hgen : ∀ z ∈ torusDisk N c (R/2), generator N F z = 0 := by
    intro z hz
    have hd := (mem_torusDisk N c z (R/2)).mp hz
    have hzD : z ∈ torusDisk N c R := (mem_torusDisk N c z R).mpr (by linarith)
    have hn (d : Fin 4) : z+direction N d ∈ torusDisk N c R := by
      have ht := periodicDistance_step_le N c z d
      exact (mem_torusDisk N c _ R).mpr (by linarith)
    have hid : generator N F z = generator N f z := by
      unfold generator
      simp only [hF z hzD, hF _ (hn _)]
      congr 1
      apply Finset.sum_congr rfl
      intro d _
      ring
    rw [hid, hg z hzD]
  have he := disk_harnack N c (R/2) (by linarith) (by linarith) F
    (fun z => le_max_right _ _) hgen x y (by
      have hid : (R/2)/(4*diskGreenInnerScale) = R/diskOscillationScale := by unfold diskOscillationScale; ring
      rwa [hid]) (by
      have hid : (R/2)/(4*diskGreenInnerScale) = R/diskOscillationScale := by unfold diskOscillationScale; ring
      rwa [hid])
  rwa [hF y hyD, hF x hxD] at he

theorem disk_oscillation_contract (N : Size) (c : Vertex N) (R : ℝ)
    (hR : 2*diskHarnackRadiusThreshold ≤ R) (hsmall : 4*(R+1) < N.val)
    (f : Vertex N → ℝ) (l u : ℝ)
    (hb : ∀ z ∈ torusDisk N c R, l ≤ f z ∧ f z ≤ u)
    (hg : ∀ z ∈ torusDisk N c R, generator N f z = 0) :
    ∃ l' u' : ℝ, l ≤ l' ∧ u' ≤ u ∧ l' ≤ u' ∧
      u'-l' ≤ diskOscillationFactor*(u-l) ∧
      ∀ z ∈ torusDisk N c (R/diskOscillationScale), l' ≤ f z ∧ f z ≤ u' := by
  have hR0 : 0 < R := by have := diskHarnackRadiusThreshold_ge_one; linarith
  have hS := diskOscillationScale_ge_two
  have hS0 : 0 < diskOscillationScale := by linarith
  have hr0 : 0 < R/diskOscillationScale := div_pos hR0 hS0
  have hrR : R/diskOscillationScale ≤ R := by
    apply (div_le_iff₀ hS0).mpr
    nlinarith
  let K := torusDisk N c (R/diskOscillationScale)
  have hK : K.Nonempty := torusDisk_nonempty N c _ hr0
  have hKD : K ⊆ torusDisk N c R := by
    intro z hz
    exact (mem_torusDisk N c z R).mpr (((mem_torusDisk N c z _).mp hz).trans_le hrR)
  obtain ⟨x, hx, hmin⟩ := Finset.exists_min_image K f hK
  obtain ⟨y, hy, hmax⟩ := Finset.exists_max_image K f hK
  have hh := disk_shift_harnack N c R hR hsmall f l (fun z hz => (hb z hz).1) hg x y
    ((mem_torusDisk N c x _).mp hx).le ((mem_torusDisk N c y _).mp hy).le
  have hyl := (hb y (hKD hy)).1
  have hyu := (hb y (hKD hy)).2
  have hH := diskHarnackConstant_gt_one
  have hH0 : 0 < diskHarnackConstant := by linarith
  have hF := diskOscillationFactor_bounds.1.le
  have hh' : (f y-l)/diskHarnackConstant ≤ f x-l := (div_le_iff₀ hH0).mpr (by nlinarith)
  have hid : f y-l-(f y-l)/diskHarnackConstant = diskOscillationFactor*(f y-l) := by
    unfold diskOscillationFactor
    ring
  have hup := mul_le_mul_of_nonneg_left (show f y-l ≤ u-l by linarith) hF
  refine ⟨f x, f y, (hb x (hKD hx)).1, hyu, hmin y hy, ?_, fun z hz => ⟨hmin z hz, hmax z hz⟩⟩
  calc
    f y-f x ≤ f y-l-(f y-l)/diskHarnackConstant := by linarith
    _ = diskOscillationFactor*(f y-l) := hid
    _ ≤ diskOscillationFactor*(u-l) := hup

end TorusCoverTime.Blocks.B
