import Solutions.Blocks.B.GaussianClockBounds

/-! Independent prefixPath and forward suffix, preserving the original sample
and the original contact coordinate. -/

noncomputable section
open MeasureTheory ProbabilityTheory Classical
namespace TorusCoverTime.Blocks.B.GaussianClockPath
variable {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
variable {n : ℕ} (W : GaussianClockPath μ n)

@[simp] theorem prefix_path (k : Fin (n + 1)) (ω : Ω) (i : Fin (k.val + 1)) :
    (W.prefixPath k).path ω i = W.path ω (prefixIndex k i) := by
  change W.path ω (prefixIndex k i) - W.path ω 0 = _
  rw [W.start_zero, sub_zero]

@[simp] theorem prefix_last (k : Fin (n + 1)) (ω : Ω) :
    (W.prefixPath k).path ω (Fin.last k.val) = W.path ω k := by
  rw [W.prefix_path]
  rfl

@[simp] theorem suffix_path (k : Fin (n + 1)) (ω : Ω) (i : Fin (n-k.val+1)) :
    (W.suffix k).path ω i = W.path ω (suffixIndex k i) - W.path ω k := by
  change W.path ω (suffixIndex k i) - W.path ω (suffixIndex k 0) = _
  have he : suffixIndex k 0 = k := by apply Fin.ext; simp [suffixIndex]
  rw [he]

@[simp] theorem suffix_last (k : Fin (n + 1)) (ω : Ω) :
    (W.suffix k).path ω (Fin.last (n-k.val)) = W.path ω (Fin.last n) - W.path ω k := by
  rw [W.suffix_path]
  have he : suffixIndex k (Fin.last (n-k.val)) = Fin.last n := by
    apply Fin.ext
    simp only [suffixIndex, Fin.val_last]
    have := k.isLt
    omega
  rw [he]

theorem prefix_indep_suffix (k : Fin (n + 1)) :
    IndepFun (W.prefixPath k).path (W.suffix k).path μ := by
  let P := fun f : {i : Fin (n+1) // i ≤ k} → ℝ =>
    fun i : Fin (k.val+1) => f ⟨prefixIndex k i, Nat.le_of_lt_succ i.isLt⟩
  let Q := fun f : {i : Fin (n+1) // k ≤ i} → ℝ =>
    fun i : Fin (n-k.val+1) => f ⟨suffixIndex k i, Nat.le_add_right _ _⟩
  have hp : Measurable P := by fun_prop
  have hq : Measurable Q := by fun_prop
  have h := (W.past_indep_future k).comp hp hq
  have heP : P ∘ (fun ω (i : {i : Fin (n+1) // i ≤ k}) => W.path ω i.val) = (W.prefixPath k).path := by
    funext ω i
    exact (W.prefix_path k ω i).symm
  have heQ : Q ∘ (fun ω (i : {i : Fin (n+1) // k ≤ i}) => W.path ω i.val - W.path ω k) =
      (W.suffix k).path := by
    funext ω i
    exact (W.suffix_path k ω i).symm
  rwa [heP, heQ] at h

end TorusCoverTime.Blocks.B.GaussianClockPath
