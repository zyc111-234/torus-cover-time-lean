import Solutions.Blocks.B.NestedSoftWordWindow
import Solutions.Blocks.B.WordWindowMixture

/-! The first resampling after averaging every actual endpoint word, with only one duration remainder. -/
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B


theorem r8_nested_soft_count_window (hWalk : WalkModelRegular) (γ U : ℝ)
    (hγ : 0 < γ) (hγ1 : γ < 1) (hU : 0 ≤ U) :
    ∀ᶠ N : Size in atTop, ∀ c root : Vertex N, ∀ m : ℕ, ∀ q : ℝ,
      2*(logSize N)^(16*γ) ≤ q → q ≤ logSize N-2*(logSize N)^(16*γ) →
      (m:ℝ) ≤ (logSize N)^4+1 → root ∉ torusDisk N c (Real.exp (q+2*q^γ)) →
      ∀ k : ℕ, ∀ v Δ l r : ℝ,
      let I := torusDisk N c (Real.exp (r8NestedScale γ q+(r8NestedScale γ q)^γ))
      let J := torusDisk N c (Real.exp (r8NestedScale γ q+2*(r8NestedScale γ q)^γ))
      let Q := torusDisk N c (Real.exp (q+q^γ))
      let O := torusDisk N c (Real.exp (q+2*q^γ))
      let F := outerCountHarmonicTest N Q O c root k q v Δ
      let d := (m:ℝ)*Real.exp (2*logSize N-(logSize N)^(16*γ))
      physicalCountWindow N I J root m (fun z => if localTime N root z.1 z.2 c/g ≤ U then F z else 0) l r ≤
        2*ENNReal.ofReal (r8SoftLaplaceEnvelope (r8NestedScale γ q) γ U m)*
          physicalCountWindow N I J root m F (l-d) (r+d) +
        ENNReal.ofReal (r-l)*ENNReal.ofReal (Real.exp (-Real.exp ((logSize N)^(16*γ)/2))) := by
  filter_upwards [r8_nested_soft_word_window hWalk γ U hγ hγ1 hU,r8_nested_coarse_range γ hγ hγ1]
    with N hword hgeom
  intro c root m q hq hqL hm hr k v Δ l r
  have hs := hgeom q hq hqL
  have hQ0 := Real.rpow_nonneg (logSize_pos N).le (16*γ)
  have hi := r8_nested_disk_inclusions N c γ q (by linarith) (hQ0.trans hs.1) hs.2.2.2.2
  exact physicalCountWindow_of_word_bound N _ _ hi.1 (torusDisk_nonempty N c _ (Real.exp_pos _))
    root (fun h => hr (hi.2.2 (hi.2.1 h))) m _ _ l r _ _ _ _
    (fun w hw => hword c root m w q hq hqL hm hr hw k v Δ l r)


end TorusCoverTime.Blocks.B

