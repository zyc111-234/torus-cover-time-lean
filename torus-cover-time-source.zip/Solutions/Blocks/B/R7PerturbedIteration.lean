import Solutions.Blocks.B.R7PerturbedRootWindow
import Solutions.Blocks.B.R7CountedIteration

/-! Normalized recurrence and finite iteration for the perturbed annulus. The harmonic
source and its far-root cutoff remain the original ones. -/

noncomputable section
open MeasureTheory Filter Set Classical
open scoped ENNReal NNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B
theorem r7_perturbed_normalized_counted_recurrence (hWalk : WalkModelRegular) (γ : ℝ) (hγ : 0 < γ) (hγ1 : γ < 1) :
    ∀ᶠ N : Size in atTop, ∀ c : Vertex N, ∀ M : ℕ, ∀ q : ℝ,
      (logSize N)^(16*γ) ≤ q → q ≤ logSize N-(logSize N)^(16*γ) → (M:ℝ) ≤ (logSize N)^4+1 →
      ∀ v Δ : ℝ, 0 ≤ v → (M:ℝ)*r7PerturbedWidth q (q^γ) ≤ v^2 → 0 ≤ Δ →
      2*r7PerturbedMeanConstant*Real.exp (-r7MeanExponent*q^γ)*v ≤ Δ → ∀ l r : ℝ,
      let d := (M:ℝ)*Real.exp (2*logSize N-(logSize N)^(16*γ))
      normalizedPerturbedFarRootCountedMass N c γ q M l r ≤ normalizedFarRootLowHarmonicMass N c γ q (v+Δ) l r +
        ENNReal.ofReal (4*Real.exp (-(r7PerturbedConcentrationConstant/4)*Δ^2/q^γ)) *
          normalizedPerturbedFarRootCountedMass N c γ q M (l-d) (r+d) +
        ENNReal.ofReal (vertexCount N*((M:ℝ)+1)*(r-l)*
          Real.exp (-Real.exp ((logSize N)^(16*γ)/2))/timeScale N) := by
  filter_upwards [perturbed_far_root_counted_recurrence hWalk γ hγ hγ1] with N hN
  intro c M q hq hqL hM v Δ hv hMv hΔ hlo l r
  have hh := hN c M q hq hqL hM v Δ hv hMv hΔ hlo l r
  have hp : 2*ENNReal.ofReal (2*Real.exp (-(r7PerturbedConcentrationConstant/4)*Δ^2/q^γ)) =
      ENNReal.ofReal (4*Real.exp (-(r7PerturbedConcentrationConstant/4)*Δ^2/q^γ)) := by
    rw [show (2:ℝ≥0∞) = ENNReal.ofReal (2:ℝ) by norm_num,← ENNReal.ofReal_mul (by norm_num : (0:ℝ) ≤ 2)]
    congr 1
    ring
  have he : ENNReal.ofReal (vertexCount N)*((M+1:ℕ):ℝ≥0∞)*ENNReal.ofReal (r-l)*
      ENNReal.ofReal (Real.exp (-Real.exp ((logSize N)^(16*γ)/2))) =
      ENNReal.ofReal (vertexCount N*((M:ℝ)+1)*(r-l)*Real.exp (-Real.exp ((logSize N)^(16*γ)/2))) := by
    rw [show ((M+1:ℕ):ℝ≥0∞) = ENNReal.ofReal ((M:ℝ)+1) by simp [ENNReal.ofReal_add],
      ← ENNReal.ofReal_mul (vertexCount_pos N).le,
      ← ENNReal.ofReal_mul (by have := vertexCount_pos N; positivity : 0 ≤ vertexCount N*((M:ℝ)+1)),
      ← ENNReal.ofReal_mul' (Real.exp_pos _).le]
  rw [hp,he] at hh
  exact normalize_root_recurrence N _ _ _ _ _ hh

theorem r7_perturbed_counted_window_iteration (N : Size) (c : Vertex N) (γ q : ℝ)
    (M J : ℕ) (l r d B ε p : ℝ) (hd : 0 ≤ d) (hlr : l ≤ r)
    (hp : 0 ≤ p) (hp1 : p < 1) (hB : 0 ≤ B) (hε : 0 ≤ ε)
    (hrec : ∀ j < J,
      normalizedPerturbedFarRootCountedMass N c γ q M (l-(j:ℝ)*d) (r+(j:ℝ)*d) ≤ ENNReal.ofReal B+
        ENNReal.ofReal p*normalizedPerturbedFarRootCountedMass N c γ q M
          (l-((j+1:ℕ):ℝ)*d) (r+((j+1:ℕ):ℝ)*d)+ENNReal.ofReal ε) :
    (normalizedPerturbedFarRootCountedMass N c γ q M l r).toReal ≤ (B+ε)/(1-p)+
      (vertexCount N*(r-l+2*(J:ℝ)*d)/timeScale N)*p^J := by
  let a := fun j : ℕ => (normalizedPerturbedFarRootCountedMass N c γ q M (l-(j:ℝ)*d) (r+(j:ℝ)*d)).toReal
  have ha (j : ℕ) := normalizedPerturbedFarRootCountedMass_ne_top N c γ q M (l-(j:ℝ)*d) (r+(j:ℝ)*d)
  have hstep (j : ℕ) (hj : j < J) : a j ≤ B+p*a (j+1)+ε := by
    simpa only [ENNReal.toReal_ofReal hB] using finite_window_recurrence_real _ _ _ p ε
      (ha j) ENNReal.ofReal_ne_top (ha (j+1)) hp hε (hrec j hj)
  have hterminal : a J ≤ vertexCount N*(r-l+2*(J:ℝ)*d)/timeScale N := by
    have hh := ENNReal.toReal_mono ENNReal.ofReal_ne_top
      (normalizedPerturbedFarRootCountedMass_le_length N c γ q M (l-(J:ℝ)*d) (r+(J:ℝ)*d))
    have hpos : 0 ≤ vertexCount N*((r+(J:ℝ)*d)-(l-(J:ℝ)*d))/timeScale N := by
      apply div_nonneg _ (timeScale_pos N).le
      apply mul_nonneg (vertexCount_pos N).le
      nlinarith [mul_nonneg (Nat.cast_nonneg J) hd]
    rw [ENNReal.toReal_ofReal hpos] at hh
    exact hh.trans_eq (by ring)
  have hh := r7_window_iteration a J B ε _ p hp hp1 (add_nonneg hB hε) hstep hterminal
  simpa only [a,Nat.cast_zero,zero_mul,sub_zero,add_zero] using hh

end TorusCoverTime.Blocks.B

