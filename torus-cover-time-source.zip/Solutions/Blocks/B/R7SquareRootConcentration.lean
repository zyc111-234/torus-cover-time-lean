import Solutions.Blocks.B.R7MeanCenter
import Solutions.Blocks.B.SquareRootDeviation

/-! R7.4 and R7.5 for independent blocks conditioned on their actual exit
words, with the mean error discharged by R7.1. Empty block families are
included. The later global random-window decomposition is separate. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

theorem square_root_bernstein_scale (m : ℕ) (hm : 0 < m) (w v Δ : ℝ)
    (hw : 0 < w) (hv : 0 ≤ v) (hΔ : 0 ≤ Δ) (hΔv : Δ ≤ v) (hmv : (m:ℝ)*w ≤ v^2) :
    Δ^2/(4*w) ≤ min ((v*Δ/2)^2/((m:ℝ)*w^2)) ((v*Δ/2)/w) := by
  have hm0 : 0 < (m:ℝ) := by exact_mod_cast hm
  apply le_min
  · apply (div_le_div_iff₀ (by positivity : 0 < 4*w) (by positivity : 0 < (m:ℝ)*w^2)).mpr
    nlinarith [mul_le_mul_of_nonneg_right hmv (mul_nonneg (sq_nonneg Δ) hw.le)]
  · calc
      _ = (Δ^2/4)/w := by ring
      _ ≤ (v*Δ/2)/w := div_le_div_of_nonneg_right
        (by nlinarith [mul_nonneg hΔ (sub_nonneg.mpr hΔv)]) hw.le

theorem sqrt_bernstein_center_tail {Ω : Type*} [MeasurableSpace Ω]
    (μ : Measure Ω) [IsFiniteMeasure μ] (S : Ω → ℝ) (M : ℝ)
    (m : ℕ) (hm : 0 < m) (w Y Δ c : ℝ) (hw : 0 < w) (hY : 0 ≤ Y)
    (hYsq : Y^2 = (m:ℝ)*w) (hΔ : 0 ≤ Δ) (hΔY : Δ ≤ Y) (hc : 0 ≤ c)
    (hS : ∀ ω, 0 ≤ S ω) (hmean : |M-Y^2| ≤ Y*Δ/2)
    (htail : ∀ z : ℝ, 0 ≤ z → μ.real {ω | z < |S ω-M|} ≤
      2*Real.exp (-c*min (z^2/((m:ℝ)*w^2)) (z/w))) :
    μ.real {ω | Δ < |Real.sqrt (S ω)-Y|} ≤ 2*Real.exp (-(c/4)*Δ^2/w) := by
  have hset : {ω | Δ < |Real.sqrt (S ω)-Y|} ⊆ {ω | Y*Δ/2 < |S ω-M|} := by
    intro ω hω
    exact square_root_centered_deviation (S ω) Y M Δ (hS ω) hY hΔ hmean hω
  apply (measureReal_mono (μ := μ) hset).trans ((htail _ (by positivity)).trans _)
  apply mul_le_mul_of_nonneg_left _ (by norm_num : (0:ℝ) ≤ 2)
  apply Real.exp_le_exp.mpr
  have he := mul_le_mul_of_nonneg_left
    (square_root_bernstein_scale m hm w Y Δ hw hY hΔ hΔY hYsq.symm.le) hc
  rw [show c*(Δ^2/(4*w)) = (c/4)*Δ^2/w by ring] at he
  simpa only [neg_mul, neg_div] using neg_le_neg he

theorem sqrt_bernstein_upper_tail {Ω : Type*} [MeasurableSpace Ω]
    (μ : Measure Ω) [IsFiniteMeasure μ] (S : Ω → ℝ) (M : ℝ)
    (m : ℕ) (hm : 0 < m) (w v Δ c : ℝ) (hw : 0 < w) (hv : 0 ≤ v)
    (hmv : (m:ℝ)*w ≤ v^2) (hΔ : 0 ≤ Δ) (hΔv : Δ ≤ v) (hc : 0 ≤ c)
    (hS : ∀ ω, 0 ≤ S ω) (hmean : M ≤ v^2+v*Δ/2)
    (htail : ∀ z : ℝ, 0 ≤ z → μ.real {ω | z < |S ω-M|} ≤
      2*Real.exp (-c*min (z^2/((m:ℝ)*w^2)) (z/w))) :
    μ.real {ω | v+Δ < Real.sqrt (S ω)} ≤ 2*Real.exp (-(c/4)*Δ^2/w) := by
  have hset : {ω | v+Δ < Real.sqrt (S ω)} ⊆ {ω | v*Δ/2 < |S ω-M|} := by
    intro ω hω
    exact (square_root_upper_centered_deviation (S ω) v M Δ (hS ω) hv hΔ hmean hω).trans_le
      (le_abs_self _)
  apply (measureReal_mono (μ := μ) hset).trans ((htail _ (by positivity)).trans _)
  apply mul_le_mul_of_nonneg_left _ (by norm_num : (0:ℝ) ≤ 2)
  apply Real.exp_le_exp.mpr
  have he := mul_le_mul_of_nonneg_left (square_root_bernstein_scale m hm w v Δ hw hv hΔ hΔv hmv) hc
  rw [show c*(Δ^2/(4*w)) = (c/4)*Δ^2/w by ring] at he
  simpa only [neg_mul, neg_div] using neg_le_neg he

theorem r7_exactExitProduct_probability (γ : ℝ) (hγ : 0 < γ) :
    ∀ᶠ q : ℝ in atTop, ∀ N : Size, ∀ c : Vertex N, ∀ m : ℕ,
      ∀ a b : Fin m → Vertex N,
      2*(Real.exp (q+2*q^γ)+1) < N.val →
      (∀ i, |periodicDistance (a i) c-Real.exp (q+q^γ)| ≤ 2) →
      (∀ i, diskExteriorNeighbor N c (Real.exp (q+2*q^γ)) (b i)) →
      IsProbabilityMeasure (exactExitProductLaw N (torusDisk N c (Real.exp (q+2*q^γ))) m a b) := by
  filter_upwards [r6_endpoint_probability_pos γ hγ] with q hp
  intro N c m a b hsmall ha hb
  have hi (i : Fin m) : IsProbabilityMeasure
      (exactExitLaw N (torusDisk N c (Real.exp (q+2*q^γ))) (a i) (b i)) :=
    cond_isProbabilityMeasure (hp N c (a i) (b i) hsmall (ha i) (hb i)).ne'
  unfold exactExitProductLaw
  infer_instance

theorem r7_occupation_sqrt_concentration (hWalk : WalkModelRegular) (γ : ℝ)
    (hγ : 0 < γ) (hγ1 : γ ≤ 1) :
    ∀ᶠ q : ℝ in atTop, ∀ N : Size, ∀ c : Vertex N, ∀ m : ℕ,
      ∀ a b : Fin m → Vertex N,
      2*(Real.exp (q+2*q^γ)+1) < N.val →
      (∀ i, |periodicDistance (a i) c-Real.exp (q+q^γ)| ≤ 2) →
      (∀ i, diskExteriorNeighbor N c (Real.exp (q+2*q^γ)) (b i)) →
      let Y := Real.sqrt ((m:ℝ)*q^γ)
      ∀ Δ : ℝ, 0 ≤ Δ → 2*r7MeanConstant*Real.exp (-r7MeanExponent*q^γ)*Y ≤ Δ → Δ ≤ Y →
      (exactExitProductLaw N (torusDisk N c (Real.exp (q+2*q^γ))) m a b).real
        {ω | Δ < |Real.sqrt (harmonicExitBlockSum N c (Real.exp (q+1)) (Real.exp (q+2*q^γ)) m a ω)-Y|} ≤
        2*Real.exp (-(r7ConcentrationConstant/4)*Δ^2/q^γ) := by
  filter_upwards [r7_mean_sum_center hWalk γ hγ hγ1, r7_occupation_concentration hWalk γ hγ,
    r7_exactExitProduct_probability γ hγ, (tendsto_rpow_atTop hγ).eventually_ge_atTop (1:ℝ)]
    with q hm hc hp hw
  intro N c m a b hsmall ha hb
  dsimp only
  intro Δ hΔ hlower hupper
  by_cases hm0 : m = 0
  · subst m
    simp only [harmonicExitBlockSum, Finset.univ_eq_empty, Finset.sum_empty, Real.sqrt_zero,
      Nat.cast_zero, zero_mul, sub_zero, abs_zero, not_lt_of_ge hΔ, Set.ofPred_false, measureReal_empty]
    positivity
  · let Y := Real.sqrt ((m:ℝ)*q^γ)
    have hw0 : 0 < q^γ := by linarith
    have hY : 0 ≤ Y := Real.sqrt_nonneg _
    have hYsq : Y^2 = (m:ℝ)*q^γ := Real.sq_sqrt (by positivity)
    have hmean := hm N c m a b hsmall ha hb
    have hmean' : |harmonicExitMeanSum N c (Real.exp (q+1)) (Real.exp (q+2*q^γ)) m a b-Y^2| ≤ Y*Δ/2 := by
      rw [hYsq]
      apply hmean.trans
      have hh := mul_le_mul_of_nonneg_right hlower hY
      change (2*r7MeanConstant*Real.exp (-r7MeanExponent*q^γ)*Y)*Y ≤ Δ*Y at hh
      rw [← hYsq]
      nlinarith
    have : IsProbabilityMeasure (exactExitProductLaw N (torusDisk N c (Real.exp (q+2*q^γ))) m a b) :=
      hp N c m a b hsmall ha hb
    exact sqrt_bernstein_center_tail _ _ _ m (Nat.pos_of_ne_zero hm0) _ Y Δ _ hw0 hY hYsq hΔ hupper
      r7ConcentrationConstant_pos.le (harmonicExitBlockSum_nonneg N c _ _ m a) hmean'
      (hc N c m a b hsmall ha hb)

theorem r7_occupation_sqrt_upper_concentration (hWalk : WalkModelRegular) (γ : ℝ)
    (hγ : 0 < γ) (hγ1 : γ ≤ 1) :
    ∀ᶠ q : ℝ in atTop, ∀ N : Size, ∀ c : Vertex N, ∀ m : ℕ,
      ∀ a b : Fin m → Vertex N,
      2*(Real.exp (q+2*q^γ)+1) < N.val →
      (∀ i, |periodicDistance (a i) c-Real.exp (q+q^γ)| ≤ 2) →
      (∀ i, diskExteriorNeighbor N c (Real.exp (q+2*q^γ)) (b i)) →
      ∀ v Δ : ℝ, 0 ≤ v → (m:ℝ)*q^γ ≤ v^2 → 0 ≤ Δ →
      2*r7MeanConstant*Real.exp (-r7MeanExponent*q^γ)*v ≤ Δ → Δ ≤ v →
      (exactExitProductLaw N (torusDisk N c (Real.exp (q+2*q^γ))) m a b).real
        {ω | v+Δ < Real.sqrt (harmonicExitBlockSum N c (Real.exp (q+1)) (Real.exp (q+2*q^γ)) m a ω)} ≤
        2*Real.exp (-(r7ConcentrationConstant/4)*Δ^2/q^γ) := by
  filter_upwards [r7_mean_sum_center hWalk γ hγ hγ1, r7_occupation_concentration hWalk γ hγ,
    r7_exactExitProduct_probability γ hγ, (tendsto_rpow_atTop hγ).eventually_ge_atTop (1:ℝ)]
    with q hm hc hp hw
  intro N c m a b hsmall ha hb v Δ hv hmv hΔ hlower hupper
  by_cases hm0 : m = 0
  · subst m
    have hn : ¬ v+Δ < 0 := not_lt_of_ge (add_nonneg hv hΔ)
    simp only [harmonicExitBlockSum, Finset.univ_eq_empty, Finset.sum_empty, Real.sqrt_zero,
      hn, Set.ofPred_false, measureReal_empty]
    positivity
  · have hw0 : 0 < q^γ := by linarith
    have hmean := (abs_le.mp (hm N c m a b hsmall ha hb)).2
    have hmean' : harmonicExitMeanSum N c (Real.exp (q+1)) (Real.exp (q+2*q^γ)) m a b ≤ v^2+v*Δ/2 := by
      have hε : 0 ≤ r7MeanConstant*Real.exp (-r7MeanExponent*q^γ) :=
        mul_nonneg r7MeanConstant_pos.le (Real.exp_pos _).le
      have hh := mul_le_mul_of_nonneg_left hmv hε
      have hlow := mul_le_mul_of_nonneg_right hlower hv
      nlinarith
    have : IsProbabilityMeasure (exactExitProductLaw N (torusDisk N c (Real.exp (q+2*q^γ))) m a b) :=
      hp N c m a b hsmall ha hb
    exact sqrt_bernstein_upper_tail _ _ _ m (Nat.pos_of_ne_zero hm0) _ v Δ _ hw0 hv hmv hΔ hupper
      r7ConcentrationConstant_pos.le (harmonicExitBlockSum_nonneg N c _ _ m a) hmean'
      (hc N c m a b hsmall ha hb)

end TorusCoverTime.Blocks.B
