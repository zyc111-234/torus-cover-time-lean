import Solutions.Blocks.B.BT7EndpointDensity
import Solutions.Blocks.B.BT7WideDirichlet

noncomputable section
open MeasureTheory ProbabilityTheory Classical Set
open scoped NNReal
namespace TorusCoverTime.Blocks.B

theorem bt7_endpoint_interval (N : Size) (C b : ℝ) (V : ℝ≥0) (hC : 0≤C) (hb : 0≤b)
    (hL : 8*(C+1)≤logSize N) (hv : |(V:ℝ)-logSize N/2|≤C) :
    (gaussianReal 0 V).real (Icc (harmonicExtremeCenter N-b) (harmonicExtremeCenter N+b))≤
      2*b*(Real.exp (8*C)/vertexCount N*logSize N*Real.exp (8*b)) := by
  have hV := (bt6_clock_comparison (logSize N) C V hC hL hv).1
  have hV0 : V≠0 := by exact_mod_cast hV.ne'
  have hpdf (t : ℝ) (ht : t∈Icc (harmonicExtremeCenter N-b) (harmonicExtremeCenter N+b)) :
      gaussianPDFReal 0 V t≤Real.exp (8*C)/vertexCount N*logSize N*Real.exp (8*b) := by
    have ht' : |t-harmonicExtremeCenter N|≤b := abs_le.mpr ⟨by linarith [ht.1],by linarith [ht.2]⟩
    have hh := bt7_endpoint_density N C V (t-harmonicExtremeCenter N) hC hL hv
    rw [add_sub_cancel] at hh
    refine hh.trans (mul_le_mul_of_nonneg_left (Real.exp_le_exp.mpr (by linarith)) ?_)
    positivity [vertexCount_pos N,logSize_pos N]
  have hi := setIntegral_mono_on (integrable_gaussianPDFReal 0 V).integrableOn (integrable_const _)
    measurableSet_Icc hpdf
  rw [Measure.real,gaussianReal_apply_eq_integral 0 hV0,
    ENNReal.toReal_ofReal (integral_nonneg (fun t => gaussianPDFReal_nonneg 0 V t))]
  refine hi.trans_eq ?_
  simp only [integral_const,smul_eq_mul,Measure.real,Measure.restrict_apply_univ,Real.volume_Icc]
  rw [ENNReal.toReal_ofReal (by linarith : 0≤harmonicExtremeCenter N+b-(harmonicExtremeCenter N-b))]
  ring

theorem dirichlet_endpoint_interval (N : Size) (root c x : Vertex N) (ρ b : ℝ)
    (hρ : 0<ρ) (hb : 0≤b) (hR : 1≤ρ*(N.val:ℝ)) (hsmall : 2*(ρ*(N.val:ℝ)+1)<N.val)
    (hroot : root∉torusDisk N c (ρ*(N.val:ℝ))) (hx : periodicDistance x c≤ρ*(N.val:ℝ)/2)
    (hL : 8*(bt6ClockError ρ+1)≤logSize N) :
    (finiteFieldLaw N).real {ξ | |dirichletFieldLS N root (torusDisk N c (ρ*(N.val:ℝ))) ξ x-harmonicExtremeCenter N|≤b}≤
      2*b*(Real.exp (8*bt6ClockError ρ)/vertexCount N*logSize N*Real.exp (8*b)) := by
  let D := torusDisk N c (ρ*(N.val:ℝ))
  have hv := dirichlet_macroscopic_clock N root c x ρ hρ hR hsmall hroot hx
  have hv0 := (bt6_clock_comparison (logSize N) (bt6ClockError ρ) _ (bt6ClockError_pos ρ).le hL hv).1
  have hlaw := (dirichletFieldLS_gaussian N root D x).map_eq_gaussianReal
  rw [dirichletFieldLS_mean,dirichletFieldLS_variance N root D hroot] at hlaw
  have hh := bt7_endpoint_interval N (bt6ClockError ρ) b (dirichletClockLS N root D x).toNNReal
    (bt6ClockError_pos ρ).le hb hL (by dsimp [D]; rw [max_eq_left hv0.le]; exact hv)
  have he := congrArg (fun ν : Measure ℝ => ν.real (Icc (harmonicExtremeCenter N-b) (harmonicExtremeCenter N+b))) hlaw
  rw [Measure.real,Measure.map_apply (dirichletFieldLS_measurable N root D x) measurableSet_Icc] at he
  have hs : (fun ξ => dirichletFieldLS N root D ξ x) ⁻¹' Icc (harmonicExtremeCenter N-b) (harmonicExtremeCenter N+b)=
      {ξ | |dirichletFieldLS N root D ξ x-harmonicExtremeCenter N|≤b} := by
    ext ξ
    simp only [mem_preimage,mem_Icc,Set.mem_ofPred_eq,abs_le]
    constructor <;> rintro ⟨h1,h2⟩ <;> constructor <;> linarith
  rw [hs] at he
  exact he.trans_le hh

theorem bt6_endpoint_restricted_probability (N : Size) (root : Vertex N) (D : Finset (Vertex N))
    (hroot : root∉D) (x : Vertex N) (hV : 0<dirichletClockLS N root D x) (γ η δ b P : ℝ)
    (hcond : ∀ t : ℝ, |t-harmonicExtremeCenter N|≤b →
      (finiteFieldLaw N).real {ζ | bt6BadField N x γ η δ (dirichletConditionedField N root D x t ζ)}≤P) :
    (finiteFieldLaw N).real {ξ | |dirichletFieldLS N root D ξ x-harmonicExtremeCenter N|≤b ∧
      bt6BadField N x γ η δ (dirichletFieldLS N root D ξ)}≤
        P*(finiteFieldLaw N).real {ξ | |dirichletFieldLS N root D ξ x-harmonicExtremeCenter N|≤b} := by
  let X := fun ξ => dirichletFieldLS N root D ξ x
  let S := {ξ | |X ξ-harmonicExtremeCenter N|≤b}
  let A := {ξ | bt6BadField N x γ η δ (dirichletFieldLS N root D ξ)}
  let F := A.indicator (fun _ => (1:ℝ))
  let m := MeasurableSpace.comap X inferInstance
  let : MeasurableSpace (FiniteFieldSample N) := MeasurableSpace.pi
  have hX : Measurable X := dirichletFieldLS_measurable N root D x
  have hm : m ≤ (inferInstance : MeasurableSpace (FiniteFieldSample N)) := hX.comap_le
  have hA : MeasurableSet A := (bt6BadField_measurableSet N x γ η δ).preimage (by apply measurable_pi_lambda; exact dirichletFieldLS_measurable N root D)
  have hS : MeasurableSet[m] S := ⟨{t : ℝ | |t-harmonicExtremeCenter N|≤b},
    measurableSet_le ((measurable_id.sub_const _).abs) measurable_const,rfl⟩
  have hi : Integrable F (finiteFieldLaw N) := (integrable_const (1:ℝ)).indicator hA
  have he : (finiteFieldLaw N)[F|m] =ᵐ[finiteFieldLaw N] fun ξ =>
      (finiteFieldLaw N).real {ζ | bt6BadField N x γ η δ (dirichletConditionedField N root D x (X ξ) ζ)} := by
    have hf : F=(fun ξ => if bt6BadField N x γ η δ (dirichletFieldLS N root D ξ) then (1:ℝ) else 0) := by
      funext ξ
      simp [F,A,Set.indicator]
    rw [hf]
    exact bt6_badField_condExp N root D hroot x hV γ η δ
  have hh := setIntegral_mono_on_ae (s := S) integrable_condExp.integrableOn (integrable_const P) (hm S hS)
    (he.mono (fun ξ hξ hmem => by rw [hξ]; exact hcond (X ξ) hmem))
  rw [setIntegral_condExp hm hi hS] at hh
  have hleft : (∫ ξ in S, F ξ ∂finiteFieldLaw N)=(finiteFieldLaw N).real (S∩A) := by
    rw [show F=A.indicator (fun _ => (1:ℝ)) by rfl,setIntegral_indicator hA,setIntegral_const,smul_eq_mul,mul_one]
  rw [hleft,setIntegral_const,smul_eq_mul,mul_comm] at hh
  exact hh

end TorusCoverTime.Blocks.B
