import Solutions.Blocks.B.R7PerturbedMean

/-! Kac exponential and factorial moments on the actual enlarged disk.
The harmonic averaging measure still uses the original circle exp(q+1). -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

theorem r7_perturbed_support_exit_control (γ : ℝ) (hγ : 0 < γ) (hγ1 : γ < 1) :
    ∀ᶠ q : ℝ in atTop, ∀ N : Size, ∀ c b : Vertex N,
      2*(r7PerturbedOuter q (q^γ)+1) < N.val →
      diskExteriorNeighbor N c (r7PerturbedOuter q (q^γ)) b →
      (∀ z, diskHarmonicWeight N c (Real.exp (q+1)) z ≠ 0 →
        0 < exitHarmonic N (torusDisk N c (r7PerturbedOuter q (q^γ))) b z) ∧
      (∀ z z', diskHarmonicWeight N c (Real.exp (q+1)) z ≠ 0 →
        diskHarmonicWeight N c (Real.exp (q+1)) z' ≠ 0 →
        exitHarmonic N (torusDisk N c (r7PerturbedOuter q (q^γ))) b z' ≤
          2*exitHarmonic N (torusDisk N c (r7PerturbedOuter q (q^γ))) b z) := by
  have hdecay : Tendsto (fun q : ℝ => diskExitOscillationConstant*
      Real.exp (-diskExitOscillationExponent*q^γ)) atTop (𝓝 0) := by
    have ht := (tendsto_rpow_atTop hγ).const_mul_atTop diskExitOscillationExponent_pos
    simpa only [mul_zero, neg_mul, Function.comp_def] using
      (Real.tendsto_exp_neg_atTop_nhds_zero.comp ht).const_mul diskExitOscillationConstant
  filter_upwards [r7_perturbed_exit_ratio γ hγ,
    r7_perturbed_entrance_support γ hγ hγ1,
    (tendsto_order.mp hdecay).2 (1/2) (by norm_num)] with q hrat hs hε
  intro N c b hsmall hb
  have hzP := (hs N c).2.1
  have hp : ∀ z, diskHarmonicWeight N c (Real.exp (q+1)) z ≠ 0 →
      0 < exitHarmonic N (torusDisk N c (r7PerturbedOuter q (q^γ))) b z := by
    intro z hz
    have h := hrat N c b z z hsmall hb (hzP z hz) (hzP z hz)
    have hn := exitHarmonic_nonneg N (torusDisk N c (r7PerturbedOuter q (q^γ))) b z
    by_contra hnot
    have heq := le_antisymm (not_lt.mp hnot) hn
    rw [heq, zero_div, zero_sub, abs_neg, abs_one] at h
    linarith
  refine ⟨hp, ?_⟩
  intro z z' hz hz'
  have h := (abs_le.mp (hrat N c b z' z hsmall hb (hzP z' hz') (hzP z hz))).2
  apply (div_le_iff₀ (hp z hz)).mp
  linarith

def r7PerturbedMomentConstant : ℝ := 16*r7GreenAverageConstant

theorem r7PerturbedMomentConstant_pos : 0 < r7PerturbedMomentConstant := by
  unfold r7PerturbedMomentConstant
  exact mul_pos (by norm_num) r7GreenAverageConstant_pos

theorem r7_perturbed_occupation_exp_bound (hWalk : WalkModelRegular) (γ : ℝ)
    (hγ : 0 < γ) (hγ1 : γ < 1) :
    ∀ᶠ q : ℝ in atTop, ∀ N : Size, ∀ c a b : Vertex N,
      2*(r7PerturbedOuter q (q^γ)+1) < N.val →
      diskExteriorNeighbor N c (r7PerturbedOuter q (q^γ)) b →
      (∫⁻ ω, ENNReal.ofReal (Real.exp ((1/(8*r7GreenAverageConstant*q^γ))*
        harmonicExitOccupation N c (Real.exp (q+1)) (r7PerturbedOuter q (q^γ)) a ω))
        ∂exactExitLaw N (torusDisk N c (r7PerturbedOuter q (q^γ))) a b) ≤ 2 := by
  filter_upwards [r7_perturbed_support_exit_control γ hγ hγ1,
    r7_perturbed_parameter_geometry γ hγ hγ1, eventually_ge_atTop (0:ℝ),
    (tendsto_rpow_atTop hγ).eventually_ge_atTop (1:ℝ)] with q hc hg hq hw
  intro N c a b hsmall hb
  have hC := r7GreenAverageConstant_pos
  have hw0 : 0 < q^γ := by linarith
  have houter := (r7_perturbed_exp_parameters q (q^γ) hg.1).2.2
  let U := fun z => diskHarmonicWeight N c (Real.exp (q+1)) z/g
  have hU : ∀ z, 0 ≤ U z := fun z => div_nonneg (diskHarmonicWeight_nonneg N c _ z) (by unfold g; positivity)
  have hne : ∀ z, U z ≠ 0 → diskHarmonicWeight N c (Real.exp (q+1)) z ≠ 0 := by
    intro z hz he
    exact hz (by dsimp only [U]; rw [he, zero_div])
  obtain ⟨hpos,hratio⟩ := hc N c b hsmall hb
  have hav : ∀ z, U z ≠ 0 → (∑ z', U z'*diskGreen N c (r7PerturbedOuter q (q^γ)) z z') ≤
      2*r7GreenAverageConstant*q^γ := by
    intro z hz
    have ht := r7_harmonic_green_average_bound N c q (r7PerturbedAverageWidth q (q^γ))
      hq hg.2.2.2.2.1 (by rwa [houter]) z (hne z hz)
    rw [houter] at ht
    have hle := mul_le_mul_of_nonneg_left hg.2.2.2.2.2.1 hC.le
    have ht' : (∑ z', U z'*diskGreen N c (r7PerturbedOuter q (q^γ)) z z') ≤
        r7GreenAverageConstant*r7PerturbedAverageWidth q (q^γ) := by
      simpa only [U,div_mul_eq_mul_div] using ht
    exact ht'.trans (by nlinarith)
  have hK : 0 < 4*r7GreenAverageConstant*q^γ := by positivity
  have hθ : 0 < 1/(8*r7GreenAverageConstant*q^γ) := by positivity
  have hθK : (1/(8*r7GreenAverageConstant*q^γ))*(4*r7GreenAverageConstant*q^γ) ≤ 1/2 := by
    apply le_of_eq
    field_simp [hC.ne',hw0.ne'] <;> ring
  exact disk_conditioned_occupation_exp_lintegral hWalk N c _ (r7PerturbedOuter_pos q (q^γ)).le
    hsmall b U hU _ _ hK.le hθ.le hθK (fun z _ hz => hpos z (hne z hz)) (by
      intro z _ hz
      have ht := disk_harmonic_potential_bound N c _ (r7PerturbedOuter_pos q (q^γ)).le
        hsmall b U hU (2*r7GreenAverageConstant*q^γ) 2 (by norm_num) hav
        (fun z z' hz hz' => hratio z z' (hne z hz) (hne z' hz')) z hz
      convert ht using 1 <;> ring) a

theorem r7_perturbed_occupation_factorial_moments (hWalk : WalkModelRegular) (γ : ℝ)
    (hγ : 0 < γ) (hγ1 : γ < 1) :
    ∀ᶠ q : ℝ in atTop, ∀ N : Size, ∀ c a b : Vertex N,
      2*(r7PerturbedOuter q (q^γ)+1) < N.val →
      diskExteriorNeighbor N c (r7PerturbedOuter q (q^γ)) b → ∀ j : ℕ, 1 ≤ j →
      Integrable (fun ω => (harmonicExitOccupation N c (Real.exp (q+1)) (r7PerturbedOuter q (q^γ)) a ω)^j)
        (exactExitLaw N (torusDisk N c (r7PerturbedOuter q (q^γ))) a b) ∧
      (∫ ω, (harmonicExitOccupation N c (Real.exp (q+1)) (r7PerturbedOuter q (q^γ)) a ω)^j
        ∂exactExitLaw N (torusDisk N c (r7PerturbedOuter q (q^γ))) a b) ≤
        (j.factorial:ℝ)*(r7PerturbedMomentConstant*q^γ)^j := by
  filter_upwards [r7_perturbed_occupation_exp_bound hWalk γ hγ hγ1,
    (tendsto_rpow_atTop hγ).eventually_ge_atTop (1:ℝ)] with q he hw
  intro N c a b hsmall hb j hj
  have hC := r7GreenAverageConstant_pos
  have hw0 : 0 < q^γ := by linarith
  have hθ : 0 < 1/(8*r7GreenAverageConstant*q^γ) := by positivity
  have hh := power_moments_of_exp_bound _ _ (measurable_harmonicExitOccupation N c _ _ a)
    (harmonicExitOccupation_nonneg N c _ _ a) _ 2 hθ (by norm_num)
      (by simpa only [ENNReal.ofReal_ofNat] using he N c a b hsmall hb) j
  refine ⟨hh.1,hh.2.trans ?_⟩
  have h2 : (2:ℝ) ≤ 2^j := by
    simpa only [pow_one] using pow_le_pow_right₀ (by norm_num : (1:ℝ) ≤ 2) hj
  have hmul := mul_le_mul_of_nonneg_right h2
    (show 0 ≤ (j.factorial:ℝ)*(8*r7GreenAverageConstant*q^γ)^j by positivity)
  simpa only [r7PerturbedMomentConstant,one_div,inv_pow,div_inv_eq_mul,
    show 16*r7GreenAverageConstant*q^γ = 2*(8*r7GreenAverageConstant*q^γ) by ring,
    mul_pow,mul_assoc,mul_left_comm] using hmul

end TorusCoverTime.Blocks.B
