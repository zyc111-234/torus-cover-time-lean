import Solutions.Blocks.B.DiskHitting
import Solutions.Blocks.B.R6DiskDuration

/-! The actual Green estimates in the original three R6 radii and the
unconditioned point-hit lower bound. Endpoint conditioning still requires
the separate harmonic-measure ratio estimate. -/

noncomputable section
open MeasureTheory Filter Classical
open scoped Topology
namespace TorusCoverTime.Blocks.B

theorem r6_green_geometry (N : Size) (c a x : Vertex N) (q w : ℝ)
    (hq : 0 ≤ q) (hw : Real.log 8 ≤ w)
    (ha : |periodicDistance a c - Real.exp (q+w)| ≤ 2)
    (hx : x ∈ torusDisk N c (Real.exp q)) :
    1 ≤ Real.exp (q+2*w) ∧ a ∈ torusDisk N c (Real.exp (q+2*w)) ∧
    periodicDistance x c ≤ Real.exp (q+2*w)/2 ∧
    periodicDistance a c ≤ Real.exp (q+2*w)/2 ∧ a ≠ x ∧
    Real.exp (q+w)/2 ≤ periodicDistance a x ∧ periodicDistance a x ≤ 2*Real.exp (q+w) := by
  have hr : 1 ≤ Real.exp q := Real.one_le_exp_iff.mpr hq
  have hs : 8 ≤ Real.exp w := by
    simpa only [Real.exp_log (by norm_num : (0 : ℝ) < 8)] using Real.exp_le_exp.mpr hw
  have hρ : 8*Real.exp q ≤ Real.exp (q+w) := by
    rw [Real.exp_add]
    nlinarith [Real.exp_pos q]
  have hR : 8*Real.exp (q+w) ≤ Real.exp (q+2*w) := by
    rw [show q+2*w = (q+w)+w by ring, Real.exp_add (q+w) w]
    nlinarith [Real.exp_pos (q+w)]
  have haxc := abs_le.mp ha
  have hxc := (mem_torusDisk N c x (Real.exp q)).mp hx
  have ht := periodicDistance_triangle N a x c
  have ht' := periodicDistance_triangle N a c x
  rw [periodicDistance_comm c x] at ht'
  refine ⟨by linarith, (mem_torusDisk N c a _).mpr (by linarith),
    by linarith, by linarith, ?_, by linarith, by linarith⟩
  intro he
  subst a
  linarith

def r6GreenErrorConstant : ℝ := diskGreenLogErrorConstant + g*Real.log 3

theorem r6GreenErrorConstant_pos : 0 < r6GreenErrorConstant := by
  have := diskGreenLogErrorConstant_pos
  have hl : 0 < Real.log 3 := Real.log_pos (by norm_num)
  unfold r6GreenErrorConstant g
  positivity

theorem r6_green_estimates (N : Size) (c a x : Vertex N) (q w : ℝ)
    (hq : 0 ≤ q) (hw : Real.log 8 ≤ w)
    (hsmall : 2*(Real.exp (q+2*w)+1) < N.val)
    (ha : |periodicDistance a c - Real.exp (q+w)| ≤ 2)
    (hx : x ∈ torusDisk N c (Real.exp q)) :
    |diskGreen N c (Real.exp (q+2*w)) a x - g*w| ≤ r6GreenErrorConstant ∧
    |diskGreen N c (Real.exp (q+2*w)) x x - g*(q+2*w)| ≤ r6GreenErrorConstant ∧
    |diskGreen N c (Real.exp (q+2*w)) a a - g*(q+2*w)| ≤ r6GreenErrorConstant := by
  obtain ⟨hR, haD, hxR, haR, hax, hdlo, hdhi⟩ := r6_green_geometry N c a x q w hq hw ha hx
  have hg := diskGreen_offdiagonal_log_error N c _ hR hsmall a x haD hxR hax
  have hxx := diskGreen_diagonal_precise N c _ hR hsmall x hxR
  have haa := diskGreen_diagonal_precise N c _ hR hsmall a haR
  rw [Real.log_exp] at hxx haa
  have hC : diskGreenLogErrorConstant ≤ r6GreenErrorConstant := by
    have hl : 0 ≤ Real.log 3 := Real.log_nonneg (by norm_num)
    have hg : 0 ≤ g := by unfold g; positivity
    unfold r6GreenErrorConstant
    linarith [mul_nonneg hg hl]
  refine ⟨?_, hxx.trans hC, haa.trans hC⟩
  have hd : 0 < periodicDistance a x := (half_pos (Real.exp_pos _)).trans_le hdlo
  have hl := log_comparable_radius (Real.exp (q+w)) (periodicDistance a x) (Real.exp_pos _) hdlo
    (hdhi.trans (by linarith [Real.exp_pos (q+w)]))
  rw [Real.log_exp] at hl
  have hlog : |g*Real.log (Real.exp (q+2*w)/periodicDistance a x) - g*w| ≤ g*Real.log 3 := by
    rw [Real.log_div (Real.exp_pos _).ne' hd.ne', Real.log_exp]
    rw [show g*(q+2*w-Real.log (periodicDistance a x))-g*w =
        -g*(Real.log (periodicDistance a x)-(q+w)) by ring,
      abs_mul, abs_neg, abs_of_pos (by unfold g; positivity)]
    exact mul_le_mul_of_nonneg_left hl (by unfold g; positivity)
  calc
    _ = |(diskGreen N c (Real.exp (q+2*w)) a x - g*Real.log (Real.exp (q+2*w)/periodicDistance a x)) +
        (g*Real.log (Real.exp (q+2*w)/periodicDistance a x) - g*w)| := by congr 1; ring
    _ ≤ _ := abs_add_le _ _
    _ ≤ _ := add_le_add hg hlog

theorem r6_point_hit_lower (hWalk : WalkModelRegular) (γ : ℝ) (hγ : 0 < γ) (hγ1 : γ ≤ 1) :
    ∀ᶠ q : ℝ in atTop, ∀ N : Size, ∀ c a x : Vertex N,
      2*(Real.exp (q+2*q^γ)+1) < N.val →
      |periodicDistance a c - Real.exp (q+q^γ)| ≤ 2 →
      x ∈ torusDisk N c (Real.exp q) →
      q^γ/(8*q) ≤ walkLaw.real (visitsBeforeExit N (torusDisk N c (Real.exp (q+2*q^γ))) a x) := by
  have hg : 0 < g := by unfold g; positivity
  filter_upwards [eventually_ge_atTop (1 : ℝ),
    eventually_ge_atTop (r6GreenErrorConstant / g),
    (tendsto_rpow_atTop hγ).eventually_ge_atTop (Real.log 8),
    (tendsto_rpow_atTop hγ).eventually_ge_atTop (2*r6GreenErrorConstant/g)] with q hq hCq hw hCw
  intro N c a x hsmall ha hx
  have hq0 : 0 < q := zero_lt_one.trans_le hq
  have hw0 : 0 < q^γ := Real.rpow_pos_of_pos hq0 γ
  have hwq : q^γ ≤ q := by
    simpa only [Real.rpow_one] using Real.rpow_le_rpow_of_exponent_le hq hγ1
  have hCq' := (div_le_iff₀ hg).mp hCq
  have hCw' := (div_le_iff₀ hg).mp hCw
  have hgeom := r6_green_geometry N c a x q (q^γ) hq0.le hw ha hx
  have hest := r6_green_estimates N c a x q (q^γ) hq0.le hw hsmall ha hx
  have hxD : x ∈ torusDisk N c (Real.exp (q+2*q^γ)) :=
    (mem_torusDisk N c x _).mpr (by have hp := Real.exp_pos (q+2*q^γ); linarith [hgeom.2.2.1])
  have hdiag := diskGreen_diagonal N c _ (Real.exp_pos _).le hsmall x hxD
  have hlo : g*q^γ/2 ≤ diskGreen N c (Real.exp (q+2*q^γ)) a x := by
    have h := (abs_le.mp hest.1).1
    nlinarith
  have hhi : diskGreen N c (Real.exp (q+2*q^γ)) x x ≤ 4*g*q := by
    have h := (abs_le.mp hest.2.1).2
    nlinarith
  rw [disk_visit_green_ratio hWalk N c _ (Real.exp_pos _) hsmall a x hxD]
  calc
    _ = (g*q^γ/2)/(4*g*q) := by field_simp; ring
    _ ≤ (g*q^γ/2)/diskGreen N c (Real.exp (q+2*q^γ)) x x :=
      div_le_div_of_nonneg_left (by positivity) (by linarith) hhi
    _ ≤ _ := div_le_div_of_nonneg_right hlo (by linarith)

end TorusCoverTime.Blocks.B
