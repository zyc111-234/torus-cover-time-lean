import Solutions.Blocks.B.DomainGreenOperator
import Solutions.Blocks.B.DiskGreenLogarithm

/-! The actual inner-disk exit weights and their exact Green average.
The cancellation proves the R7.2 scale without estimating each diagonal
logarithmic singularity separately. -/

noncomputable section
open Classical
namespace TorusCoverTime.Blocks.B

def diskHarmonicWeight (N : Size) (c : Vertex N) (r : ℝ) (z : Vertex N) : ℝ :=
  exitHarmonic N (torusDisk N c r) z c

theorem diskHarmonicWeight_nonneg (N : Size) (c : Vertex N) (r : ℝ) (z : Vertex N) :
    0 ≤ diskHarmonicWeight N c r z := exitHarmonic_nonneg N _ z c

theorem diskHarmonicWeight_sum (N : Size) (c : Vertex N) (r : ℝ)
    (hr : 0 ≤ r) (hsmall : 2*(r+1) < N.val) :
    (∑ z, diskHarmonicWeight N c r z) = 1 :=
  exitHarmonic_sum_one N _ (torusDisk_proper N c r hr hsmall) c

theorem diskHarmonicWeight_support (N : Size) (c : Vertex N) (r : ℝ) (hr : 0 < r)
    (z : Vertex N) (hz : diskHarmonicWeight N c r z ≠ 0) :
    diskExteriorNeighbor N c r z := by
  by_contra hn
  exact hz (exitHarmonic_disk_support N c r c z
    ((mem_torusDisk N c c r).mpr (by rw [periodicDistance_self_zero]; exact hr)) hn)

theorem diskHarmonicWeight_green_average (N : Size) (c : Vertex N) (r R : ℝ)
    (hr : 0 ≤ r) (hrR : r ≤ R) (hsmall : 2*(R+1) < N.val) (a : Vertex N) :
    (∑ z, diskHarmonicWeight N c r z*diskGreen N c R a z) =
      diskGreen N c R a c-diskGreen N c r a c := by
  have hR := hr.trans hrR
  have hrsmall : 2*(r+1) < N.val := by linarith
  let f := fun z => diskGreen N c R z a-diskGreen N c r z a
  have hgen : ∀ z ∈ torusDisk N c r, generator N f z = 0 := by
    intro z hz
    have hzR := (mem_torusDisk N c z R).mpr (((mem_torusDisk N c z r).mp hz).trans_le hrR)
    have h1 := diskGreen_generator N c R hR hsmall z a hzR
    have h2 := diskGreen_generator N c r hr hrsmall z a hz
    change generator N ((fun z => diskGreen N c R z a)-(fun z => diskGreen N c r z a)) z = 0
    rw [generator_sub]
    linarith
  have hav := congrFun (harmonic_exit_representation N (torusDisk N c r)
    (torusDisk_proper N c r hr hrsmall) f hgen) c
  have hsum : exitExtension N (torusDisk N c r) f c =
      ∑ z, diskHarmonicWeight N c r z*diskGreen N c R a z := by
    apply Finset.sum_congr rfl
    intro z _
    by_cases hz : z ∈ torusDisk N c r
    · simp only [diskHarmonicWeight, exitHarmonic_zero_inside N (torusDisk N c r) c z hz,
        mul_zero, zero_mul]
    · have hg0 := domainGreenFromBarrier_boundary N (torusDisk N c r) (diskBarrier N c r) z a hz
      change diskGreen N c r z a = 0 at hg0
      dsimp only [f, diskHarmonicWeight]
      rw [hg0, sub_zero, diskGreen_symm N c R hR hsmall z a]
      ring
  rw [hsum] at hav
  rw [← hav]
  dsimp only [f]
  rw [diskGreen_symm N c R hR hsmall c a, diskGreen_symm N c r hr hrsmall c a]

theorem diskHarmonicWeight_green_average_outside (N : Size) (c : Vertex N) (r R : ℝ)
    (hr : 0 ≤ r) (hrR : r ≤ R) (hsmall : 2*(R+1) < N.val)
    (a : Vertex N) (ha : a ∉ torusDisk N c r) :
    (∑ z, diskHarmonicWeight N c r z*diskGreen N c R a z) = diskGreen N c R a c := by
  rw [diskHarmonicWeight_green_average N c r R hr hrR hsmall a]
  have hg0 := domainGreenFromBarrier_boundary N (torusDisk N c r) (diskBarrier N c r) a c ha
  change diskGreen N c r a c = 0 at hg0
  rw [hg0, sub_zero]

def r7GreenAverageConstant : ℝ := 2+diskGreenLogErrorConstant/g

theorem r7GreenAverageConstant_pos : 0 < r7GreenAverageConstant := by
  have := diskGreenLogErrorConstant_pos
  have hg : 0 < g := by unfold g; positivity
  unfold r7GreenAverageConstant
  positivity

theorem r7_harmonic_green_average_bound (N : Size) (c : Vertex N) (q w : ℝ)
    (hq : 0 ≤ q) (hw : 1 ≤ w) (hsmall : 2*(Real.exp (q+2*w)+1) < N.val)
    (z : Vertex N) (hz : diskHarmonicWeight N c (Real.exp (q+1)) z ≠ 0) :
    (∑ z', diskHarmonicWeight N c (Real.exp (q+1)) z'*
      diskGreen N c (Real.exp (q+2*w)) z z'/g) ≤ r7GreenAverageConstant*w := by
  have hg : 0 < g := by unfold g; positivity
  have hb := diskHarmonicWeight_support N c _ (Real.exp_pos _) z hz
  have hrad := diskExteriorNeighbor_radius N c _ z hb
  have hr : 0 < Real.exp (q+1) := Real.exp_pos _
  have hR1 : 1 ≤ Real.exp (q+2*w) := Real.one_le_exp_iff.mpr (by linarith)
  have hr1 : 1 ≤ Real.exp (q+1) := Real.one_le_exp_iff.mpr (by linarith)
  have hexp : 2 < Real.exp (2*w-1) := by
    have he : 2 < Real.exp 1 := by
      linarith [Real.add_one_lt_exp (show (1:ℝ) ≠ 0 by norm_num)]
    exact he.trans_le (Real.exp_le_exp.mpr (by linarith))
  have hrR : 2*Real.exp (q+1) < Real.exp (q+2*w) := by
    rw [show q+2*w = (q+1)+(2*w-1) by ring, Real.exp_add (q+1) (2*w-1)]
    nlinarith
  have hzD : z ∈ torusDisk N c (Real.exp (q+2*w)) := (mem_torusDisk N c z _).mpr (by linarith)
  have hzc : z ≠ c := by
    intro he
    subst z
    rw [periodicDistance_self_zero] at hrad
    linarith [hrad.1]
  have hmean := diskHarmonicWeight_green_average_outside N c _ _ hr.le
    (by linarith : Real.exp (q+1) ≤ Real.exp (q+2*w)) hsmall z hb.1
  rw [← Finset.sum_div, hmean]
  have hlog := (abs_le.mp (diskGreen_offdiagonal_log_error N c _ hR1 hsmall z c hzD
    (by rw [periodicDistance_self_zero]; positivity) hzc)).2
  have hd : 0 < periodicDistance z c := hr.trans_le hrad.1
  have hl := Real.log_le_log hr hrad.1
  rw [Real.log_exp] at hl
  rw [Real.log_div (Real.exp_pos _).ne' hd.ne', Real.log_exp] at hlog
  apply (div_le_iff₀ hg).mpr
  have hC := mul_le_mul_of_nonneg_left hw diskGreenLogErrorConstant_pos.le
  have heq : r7GreenAverageConstant*w*g = 2*g*w+diskGreenLogErrorConstant*w := by
    unfold r7GreenAverageConstant
    field_simp
  rw [heq]
  nlinarith

end TorusCoverTime.Blocks.B
