import Solutions.Blocks.B.ExteriorTraversalMeasurable

/-! The erased-record finite composition equals the actual original prefix scan, under the positive-word law. -/
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B


theorem exteriorTraversal_prefix_identity (N : Size) (I J Q O : Finset (Vertex N))
    (hIJ : I ⊆ J) (hI : I.Nonempty) (hJQ : J ⊆ Q) (hQO : Q ⊆ O)
    (root c : Vertex N) (hr : root ∉ J) (hc : c ∈ Q) (m : ℕ) (w : Fin (2*m) → Vertex N) :
    ∀ᵐ ω ∂walkLaw[|{ω | adaptiveExitWord N (alternatingDomain N I J) root (2*m) ω = w}],
      finiteActionScan (exteriorTraversalAction N Q O root c m w (traversalExteriorData N I J root m ω)) (2*m) 0 =
        traversalPrefixScan N Q O root ω (adaptiveExitIndex N (alternatingDomain N I J) root (2*m) ω) 0 := by
  have hac : walkLaw[|{ω | adaptiveExitWord N (alternatingDomain N I J) root (2*m) ω = w}] ≪ walkLaw :=
    cond_absolutelyContinuous
  filter_upwards [hac.ae_le (erasedTraversalScan_ae N I J Q O hIJ hI hJQ hQO root c hr hc),
    ae_cond_mem (μ := walkLaw) ((adaptiveExitWord_measurable N _ root (2*m)) (measurableSet_singleton w))]
    with ω herase hw
  rw [← adaptive_record_scan_prefix N Q O (alternatingDomain N I J) root ω (2*m) 0]
  apply finiteActionScan_congr
  intro j hj k
  unfold exteriorTraversalAction
  rw [dif_pos hj]
  by_cases ho : j % 2 = 1
  · rw [dif_pos ho]
    have he : j = 2*(j/2)+1 := by omega
    have hh := herase (j/2) k
    rw [← he] at hh
    exact hh.symm
  · rw [dif_neg ho]
    dsimp only [traversalExteriorData]
    unfold adaptiveRecordScanAction
    rw [adaptiveExitStart_of_word N _ root (2*m) w ω hw j (by omega)]


end TorusCoverTime.Blocks.B
