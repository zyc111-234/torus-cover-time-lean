import Solutions.Blocks.B.DiskGeometry
import Solutions.Blocks.B.FiniteExitTail

/-! Quadratic barriers for the actual rate-one walk in Euclidean torus disks.
The barrier gives a radius-squared Dirichlet rate without a Green logarithm. -/

noncomputable section
open Classical
open scoped BigOperators
namespace TorusCoverTime.Blocks.B

lemma periodicDistance_self_zero (N : Size) (x : Vertex N) :
    periodicDistance x x = 0 := by
  simp [periodicDistance, coordinateDistance, (show (0 : ℝ) ≤ N.val by positivity)]

lemma torusDisk_nonempty (N : Size) (y : Vertex N) (R : ℝ) (hR : 0 < R) :
    (torusDisk N y R).Nonempty :=
  ⟨y, (mem_torusDisk N y y R).mpr (by simpa [periodicDistance_self_zero] using hR)⟩

lemma latticeRadius_direction (d : Fin 4) : latticeRadius (latticeDirection d) = 1 := by
  fin_cases d <;> simp [latticeDirection, latticeRadius]

lemma periodicDistance_step (N : Size) (x : Vertex N) (d : Fin 4) :
    periodicDistance (x + direction N d) x = 1 := by
  have hd := latticeDirection_coordinates d
  have hN : (2 : ℝ) < N.val := by exact_mod_cast (show 2 < N.val by have := N.property; omega)
  have h := periodicDistance_projection_of_small N x (latticeDirection d)
    (by linarith [hd.1]) (by linarith [hd.2])
  have hp : torusProjection N x (latticeDirection d) = x + direction N d := by
    fin_cases d <;> simp [torusProjection, latticeDirection, direction]
  rw [hp, latticeRadius_direction] at h
  exact h

lemma periodicDistance_step_le (N : Size) (y x : Vertex N) (d : Fin 4) :
    periodicDistance (x + direction N d) y ≤ periodicDistance x y + 1 := by
  have h := periodicDistance_triangle N (x + direction N d) x y
  rw [periodicDistance_step] at h
  linarith

lemma latticeRadius_sq (z : LatticePoint) :
    latticeRadius z ^ 2 = (z.1 : ℝ)^2 + (z.2 : ℝ)^2 :=
  Real.sq_sqrt (by positivity)

lemma lattice_quadratic_generator (z : LatticePoint) :
    (1 / 4 : ℝ) * ∑ d : Fin 4,
      (latticeRadius (z + latticeDirection d)^2 - latticeRadius z^2) = 1 := by
  simp [latticeRadius_sq, Fin.sum_univ_succ, latticeDirection,
    Prod.fst_add, Prod.snd_add]
  ring

lemma generator_periodicDistance_sq (N : Size) (y x : Vertex N)
    (hsmall : 2 * (periodicDistance x y + 1) < N.val) :
    generator N (fun z => periodicDistance z y ^ 2) x = 1 := by
  unfold generator
  have heq (d : Fin 4) : periodicDistance (x + direction N d) y =
      latticeRadius (centeredLift N y x + latticeDirection d) := by
    rw [← centeredLift_add_direction N y x d hsmall, latticeRadius_centeredLift]
  simp only [heq, ← latticeRadius_centeredLift N y x]
  exact lattice_quadratic_generator _

def diskBarrier (N : Size) (y : Vertex N) (R : ℝ) (x : Vertex N) : ℝ :=
  max ((R+1)^2 - periodicDistance x y ^ 2) 0

lemma diskBarrier_nonneg (N : Size) (y : Vertex N) (R : ℝ) (x : Vertex N) :
    0 ≤ diskBarrier N y R x := le_max_right _ _

lemma diskBarrier_le (N : Size) (y : Vertex N) (R : ℝ) (x : Vertex N) :
    diskBarrier N y R x ≤ (R+1)^2 := by
  apply max_le
  · linarith [sq_nonneg (periodicDistance x y)]
  · positivity

lemma diskBarrier_eq_quadratic (N : Size) (y : Vertex N) (R : ℝ) (hR : 0 ≤ R)
    (x : Vertex N) (hx : periodicDistance x y ≤ R+1) :
    diskBarrier N y R x = (R+1)^2 - periodicDistance x y ^ 2 := by
  apply max_eq_left
  have hp : 0 ≤ periodicDistance x y := Real.sqrt_nonneg _
  nlinarith

lemma diskBarrier_generator (N : Size) (y : Vertex N) (R : ℝ) (hR : 0 ≤ R)
    (hsmall : 2 * (R+1) < N.val) (x : Vertex N) (hx : x ∈ torusDisk N y R) :
    -generator N (diskBarrier N y R) x = 1 := by
  have hxr := (mem_torusDisk N y x R).mp hx
  have h0 := diskBarrier_eq_quadratic N y R hR x (by linarith)
  have hstep (d : Fin 4) := diskBarrier_eq_quadratic N y R hR (x + direction N d)
    ((periodicDistance_step_le N y x d).trans (by linarith))
  have hg := generator_periodicDistance_sq N y x (by linarith)
  have heq : -generator N (diskBarrier N y R) x =
      generator N (fun z => periodicDistance z y ^ 2) x := by
    unfold generator
    simp only [h0, hstep]
    rw [← mul_neg, ← Finset.sum_neg_distrib]
    congr 1
    apply Finset.sum_congr rfl
    intro d _
    ring
  exact heq.trans hg

lemma killedEigenvalue_barrier_bound (N : Size) (A : Finset (Vertex N))
    (hA : A ≠ Finset.univ) (b : Vertex N → ℝ) (B : ℝ)
    (hb : ∀ x, 0 ≤ b x) (hB : ∀ x, b x ≤ B)
    (hgen : ∀ x, x ∉ A → 1 ≤ -generator N b x) :
    1 ≤ B * killedEigenvalue N A := by
  have hf := principalMode_valid N A hA
  have hlam := killedEigenvalue_nonneg N A hA
  have hsum : (∑ x : Vertex N, principalMode N A x) = vertexCount N :=
    (div_eq_one_iff_eq (vertexCount_pos N).ne').mp hf.2.1
  have hlo : (∑ x : Vertex N, principalMode N A x) ≤
      dirichletPairing N (principalMode N A) b := by
    apply Finset.sum_le_sum
    intro x _
    by_cases hx : x ∈ A
    · simp [hf.1 x hx]
    · simpa using mul_le_mul_of_nonneg_left (hgen x hx) (hf.2.2.1 x)
  have hhi : dirichletPairing N b (principalMode N A) ≤
      B * killedEigenvalue N A * ∑ x : Vertex N, principalMode N A x := by
    rw [Finset.mul_sum]
    apply Finset.sum_le_sum
    intro x _
    by_cases hx : x ∈ A
    · have hg : 0 ≤ generator N (principalMode N A) x := by
        unfold generator
        apply mul_nonneg (by norm_num)
        apply Finset.sum_nonneg
        intro d _
        rw [hf.1 x hx, sub_zero]
        exact hf.2.2.1 _
      rw [hf.1 x hx, mul_zero]
      exact mul_nonpos_of_nonneg_of_nonpos (hb x) (neg_nonpos.mpr hg)
    · rw [hf.2.2.2 x hx, mul_assoc B]
      exact mul_le_mul_of_nonneg_right (hB x) (mul_nonneg hlam (hf.2.2.1 x))
  rw [dirichletPairing_symm N (principalMode N A) b] at hlo
  have h := hlo.trans hhi
  rw [hsum] at h
  exact (mul_le_mul_iff_left₀ (vertexCount_pos N)).mp (by nlinarith [h])

lemma killedEigenvalue_disk_bound (N : Size) (y : Vertex N) (R : ℝ) (hR : 0 < R)
    (hsmall : 2 * (R+1) < N.val) :
    1 / (R+1)^2 ≤ killedEigenvalue N (Finset.univ \ torusDisk N y R) := by
  have hA : Finset.univ \ torusDisk N y R ≠ Finset.univ := by
    intro heq
    have hmem : y ∈ Finset.univ \ torusDisk N y R := by rw [heq]; exact Finset.mem_univ y
    have hy : y ∈ torusDisk N y R := by
      simpa only [mem_torusDisk, periodicDistance_self_zero] using hR
    exact (Finset.mem_sdiff.mp hmem).2 hy
  apply (div_le_iff₀ (show (0 : ℝ) < (R+1)^2 by positivity)).mpr
  have h := killedEigenvalue_barrier_bound N _ hA (diskBarrier N y R) ((R+1)^2)
    (diskBarrier_nonneg N y R) (diskBarrier_le N y R) (by
      intro x hx
      have hm : x ∈ torusDisk N y R := by simpa using hx
      rw [diskBarrier_generator N y R hR.le hsmall x hm])
  nlinarith

end TorusCoverTime.Blocks.B
