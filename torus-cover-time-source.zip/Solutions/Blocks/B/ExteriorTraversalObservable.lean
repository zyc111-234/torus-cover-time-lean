import Solutions.Blocks.B.ErasedTraversalScan
import Solutions.Blocks.B.ExteriorReturnOccupation

/-! An explicit exterior counter: retained returns, one inner marker per erased record, and the terminal tail. -/
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B


def exteriorTraversalAction (N : Size) (Q O : Finset (Vertex N)) (root c : Vertex N)
    (m : ℕ) (w : Fin (2*m) → Vertex N) (y : TraversalExteriorSample m) (j k : ℕ) : ℕ :=
  if hj : j < 2*m then
    if ho : j % 2 = 1 then traversalPhaseStep N Q O k c else
      traversalPrefixScan N Q O (endpointWordStart root w j)
        (y.1 ⟨⟨j,hj⟩,ho⟩).2 (y.1 ⟨⟨j,hj⟩,ho⟩).1 k
  else k

def exteriorTraversalPhase (N : Size) (Q O : Finset (Vertex N)) (root c : Vertex N)
    (m : ℕ) (w : Fin (2*m) → Vertex N) (z : TraversalExteriorSample m × ℝ) : ℕ :=
  traversalPrefixScan N Q O (endpointWordStart root w (2*m)) z.1.2 (jumpCount z.1.2 z.2+1)
    (finiteActionScan (exteriorTraversalAction N Q O root c m w z.1) (2*m) 0)

def exteriorTraversalCount (N : Size) (Q O : Finset (Vertex N)) (root c : Vertex N)
    (m : ℕ) (w : Fin (2*m) → Vertex N) (z : TraversalExteriorSample m × ℝ) : ℕ :=
  exteriorTraversalPhase N Q O root c m w z / 2

theorem exteriorTraversalAction_measurable (N : Size) (Q O : Finset (Vertex N))
    (root c : Vertex N) (m : ℕ) (w : Fin (2*m) → Vertex N) (j k : ℕ) :
    Measurable (fun y => exteriorTraversalAction N Q O root c m w y j k) := by
  unfold exteriorTraversalAction
  split_ifs with hj ho
  · exact measurable_const
  · exact (traversalRecordScan_measurable N Q O _ k).comp
      ((measurable_pi_apply (⟨⟨j,hj⟩,ho⟩ : {i : Fin (2*m) // ¬i.val % 2 = 1})).comp measurable_fst)
  · exact measurable_const


end TorusCoverTime.Blocks.B
