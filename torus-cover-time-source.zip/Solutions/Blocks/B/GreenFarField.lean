import Solutions.Blocks.B.GreenKernelSpatial

/-! The distantRadius/4 consequence of the spatial Green bound, uniformly for every Size. -/

noncomputable section
namespace TorusCoverTime.Blocks.B

def minimumLogRoot : ℝ := (Real.log 3) ^ (1 / 8 : ℝ)

lemma minimumLogRoot_pos : 0 < minimumLogRoot :=
  Real.rpow_pos_of_pos (Real.log_pos (by norm_num)) _

lemma minimumLogRoot_le (N : Size) : minimumLogRoot ≤ (logSize N) ^ (1 / 8 : ℝ) := by
  have hN : (3 : ℝ) ≤ N.val := by exact_mod_cast N.property
  apply Real.rpow_le_rpow (Real.log_nonneg (by norm_num))
    (Real.log_le_log (by norm_num) hN) (by norm_num)

def greenFarConstant : ℝ :=
  greenSpatialConstant * (1 + (1 + Real.log 4) / minimumLogRoot)

lemma greenFarConstant_pos : 0 < greenFarConstant := by
  have := greenSpatialConstant_pos
  have := minimumLogRoot_pos
  have hlog : 0 ≤ Real.log 4 := Real.log_nonneg (by norm_num)
  unfold greenFarConstant
  positivity

lemma greenKernel_far_bound (N : Size) (x y : Vertex N)
    (hfar : distantRadius N / 4 ≤ periodicDistance x y) :
    |greenKernel N x y| ≤ greenFarConstant * (logSize N) ^ (1 / 8 : ℝ) := by
  let q := (logSize N) ^ (1 / 8 : ℝ)
  let d := max (periodicDistance x y) 1
  have hd : 0 < d := lt_of_lt_of_le zero_lt_one (le_max_right _ _)
  have hn : 0 < (N.val : ℝ) := lt_trans zero_lt_one (size_real_gt_one N)
  have hD : (N.val : ℝ) * Real.exp (-q) / 4 ≤ d :=
    hfar.trans (le_max_left _ _)
  have hprod := mul_le_mul_of_nonneg_right hD (show 0 ≤ 4 * Real.exp q by positivity)
  have hid : ((N.val : ℝ) * Real.exp (-q) / 4) * (4 * Real.exp q) = N.val := by
    rw [Real.exp_neg]
    field_simp
  rw [hid] at hprod
  have hquot : (N.val : ℝ) / d ≤ 4 * Real.exp q := (div_le_iff₀ hd).mpr (by nlinarith)
  have hlog := Real.log_le_log (div_pos hn hd) hquot
  rw [Real.log_mul (by norm_num) (Real.exp_pos q).ne', Real.log_exp] at hlog
  have hmin := minimumLogRoot_le N
  have hcoef : 0 ≤ (1 + Real.log 4) / minimumLogRoot := by
    have := minimumLogRoot_pos
    have : 0 ≤ Real.log 4 := Real.log_nonneg (by norm_num)
    positivity
  have hmul := mul_le_mul_of_nonneg_left hmin hcoef
  rw [div_mul_cancel₀ _ minimumLogRoot_pos.ne'] at hmul
  have hfactor : 1 + Real.log ((N.val : ℝ) / d) ≤
      (1 + (1 + Real.log 4) / minimumLogRoot) * q := by
    change 1 + Real.log 4 ≤ (1 + Real.log 4) / minimumLogRoot * q at hmul
    nlinarith
  calc
    _ ≤ greenSpatialConstant * (1 + Real.log ((N.val : ℝ) / d)) :=
      greenKernel_spatial_bound N x y
    _ ≤ greenSpatialConstant * ((1 + (1 + Real.log 4) / minimumLogRoot) * q) :=
      mul_le_mul_of_nonneg_left hfactor greenSpatialConstant_pos.le
    _ = _ := by unfold greenFarConstant; ring

end TorusCoverTime.Blocks.B
