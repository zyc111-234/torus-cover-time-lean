import Solutions.Blocks.B.NestedTraversalEvent
import Solutions.Blocks.B.AlternatingTraversalClock

/-! Connect the nested restart event to the original greedy traversal count,
at the actual physical outer-exit time. No new clock or independent count is used. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

theorem adaptiveExitIndex_add_restart (N : Size) (D : ℕ → Finset (Vertex N))
    (a : Vertex N) (ω : WalkSample) (m k : ℕ) :
    adaptiveExitIndex N D a (m+k) ω = adaptiveExitIndex N D a m ω +
      adaptiveExitIndex N (fun j => D (m+j)) (adaptiveExitStart N D a m ω)
        k (adaptiveExitTail N D a m ω) := by
  induction k with
  | zero => simp
  | succ k ih =>
    have hs : adaptiveExitStart N D a (m+k) ω =
        adaptiveExitStart N (fun j => D (m+j)) (adaptiveExitStart N D a m ω)
          k (adaptiveExitTail N D a m ω) := by
      change position N a ω (adaptiveExitIndex N D a (m+k) ω) = _
      rw [ih,position_shift_sample]
      rfl
    have ht : adaptiveExitTail N D a (m+k) ω =
        adaptiveExitTail N (fun j => D (m+j)) (adaptiveExitStart N D a m ω)
          k (adaptiveExitTail N D a m ω) := by
      funext j
      change ω (adaptiveExitIndex N D a (m+k) ω+j) =
        ω (adaptiveExitIndex N D a m ω+
          (adaptiveExitIndex N (fun j => D (m+j)) (adaptiveExitStart N D a m ω)
            k (adaptiveExitTail N D a m ω)+j))
      rw [ih,Nat.add_assoc]
    rw [show m+(k+1) = (m+k)+1 by omega, adaptiveExitIndex_succ,
      adaptiveExitIndex_succ, ih, hs, ht,Nat.add_assoc]

theorem alternatingDomain_add_two (N : Size) (I J : Finset (Vertex N)) :
    (fun j => alternatingDomain N I J (2+j)) = alternatingDomain N I J := by
  funext j
  simp [alternatingDomain]

theorem nestedTraversalEvent_index_bound (N : Size) (O I J : Finset (Vertex N))
    (hJO : J ⊆ O) (b : Vertex N) (k : ℕ) (a : Vertex N) (ω : WalkSample)
    (hω : ω ∈ nestedTraversalEvent N O I J b k a) :
    adaptiveExitIndex N (alternatingDomain N I J) a (2*k) ω ≤ finiteExitIndex N O a ω := by
  induction k generalizing a ω with
  | zero => simp
  | succ k ih =>
    obtain ⟨z,hz,hrest⟩ := mem_iUnion.mp hω
    change finiteExitTail N (O\I) a ω ∈
      (if z ∈ I then exitRestartEvent N J z (nestedTraversalEvent N O I J b k) else ∅) at hrest
    have hzI : z ∈ I := by
      by_contra hn
      simp only [if_neg hn,mem_empty_iff_false] at hrest
    rw [if_pos hzI] at hrest
    obtain ⟨y,hy,hη⟩ := mem_iUnion.mp hrest
    change finiteExitTail N J z (finiteExitTail N (O\I) a ω) ∈
      nestedTraversalEvent N O I J b k y at hη
    obtain ⟨m,hm⟩ := hz
    have ht : finiteExitTail N (O\I) a ω = fun j => ω (m+j) := by
      change (fun j => ω (finiteExitIndex N (O\I) a ω+j)) = _
      rw [finiteExitIndex_of_exit_word N (O\I) a z ω m hm]
    rw [ht] at hy hη
    obtain ⟨n,hn⟩ := hy
    have ht' : finiteExitTail N J z (fun j => ω (m+j)) = fun j => ω (m+n+j) := by
      change (fun j => ω (m+(finiteExitIndex N J z (fun j => ω (m+j))+j))) = _
      rw [finiteExitIndex_of_exit_word N J z y _ n hn]
      simp only [Nat.add_assoc]
    rw [ht'] at hη
    have hm' : exitsThroughAt N (Finset.univ\I) a z ω m :=
      ⟨by simpa using hzI,hm.2.1,fun j =>
        Finset.mem_sdiff.mpr ⟨Finset.mem_univ _,(Finset.mem_sdiff.mp (hm.2.2 j)).2⟩⟩
    let D := alternatingDomain N I J
    have hi1 : adaptiveExitIndex N D a 1 ω = m := by
      change 0+finiteExitIndex N (Finset.univ\I) (position N a ω 0)
        (fun j => ω (0+j)) = m
      simpa using
        finiteExitIndex_of_exit_word N (Finset.univ\I) a z ω m hm'
    have hs1 : adaptiveExitStart N D a 1 ω = z := by
      simpa only [adaptiveExitStart,hi1] using hm.2.1
    have ht1 : adaptiveExitTail N D a 1 ω = fun j => ω (m+j) := by
      funext j
      change ω (adaptiveExitIndex N D a 1 ω+j) = ω (m+j)
      rw [hi1]
    have hi2 : adaptiveExitIndex N D a 2 ω = m+n := by
      rw [show (2:ℕ)=1+1 from rfl,adaptiveExitIndex_succ,hi1,hs1,ht1]
      change m+finiteExitIndex N J z (fun j => ω (m+j)) = m+n
      rw [finiteExitIndex_of_exit_word N J z y _ n hn]
    have hs2 : adaptiveExitStart N D a 2 ω = y := by
      rw [adaptiveExitStart,hi2,position_shift_sample,hm.2.1]
      exact hn.2.1
    have ht2 : adaptiveExitTail N D a 2 ω = fun j => ω (m+n+j) := by
      funext j
      change ω (adaptiveExitIndex N D a 2 ω+j) = ω (m+n+j)
      rw [hi2]
    have hk := ih y _ hη
    obtain ⟨t,htO⟩ := nestedTraversalEvent_subset_exit N O I J hJO b k y hη
    have hnt : exitsThroughAt N O z b (fun j => ω (m+j)) (n+t) := by
      apply exitsThroughAt_append N J O hJO z y b _ n t hn
      simpa only [Nat.add_assoc] using htO
    have hmt := exitsThroughAt_append N (O\I) O Finset.sdiff_subset a z b ω m (n+t) hm hnt
    rw [finiteExitIndex_of_exit_word N O a b ω _ hmt]
    change adaptiveExitIndex N D a (2*(k+1)) ω ≤ _
    rw [show 2*(k+1)=2+2*k by omega,adaptiveExitIndex_add_restart,
      show (fun j => D (2+j)) = D from alternatingDomain_add_two N I J,
      hi2,hs2,ht2]
    rw [finiteExitIndex_of_exit_word N O y b _ t htO] at hk
    dsimp only [D]
    omega

theorem physicalSegmentCount_ge_of_time (T : ℕ → ℝ) (hT : Monotone T)
    (hT0 : T 0 = 0) (hdiv : Tendsto T atTop atTop) (t : ℝ) (ht : 0 ≤ t)
    (k : ℕ) (hk : T k ≤ t) : k ≤ physicalSegmentCount T t := by
  have hb := physicalSegmentCount_bounds T hT0 hdiv t ht
  by_contra hn
  have h := (hT (show physicalSegmentCount T t+1 ≤ k by omega)).trans hk
  exact (not_lt_of_ge h) hb.2

def nestedTraversalCount (N : Size) (O I J : Finset (Vertex N)) (a : Vertex N)
    (ω : WalkSample) : ℕ :=
  completedTraversalCount N I J a ω (finiteExitDuration N O a ω)

theorem nestedTraversalCount_measurable (N : Size) (O I J : Finset (Vertex N)) (a : Vertex N) :
    Measurable (nestedTraversalCount N O I J a) :=
  (completedTraversalCount_measurable N I J a).comp
    (measurable_id.prodMk (measurable_finiteExitDuration N O a))

theorem nestedTraversalEvent_count_bound_ae (N : Size) (O I J : Finset (Vertex N))
    (hJO : J ⊆ O) (hIJ : I ⊆ J) (hI : I.Nonempty) (a b : Vertex N) (ha : a ∉ J)
    (k : ℕ) :
    ∀ᵐ ω ∂walkLaw, ω ∈ nestedTraversalEvent N O I J b k a →
      k ≤ nestedTraversalCount N O I J a ω := by
  filter_upwards [alternatingExitTime_regular_ae N I J hIJ hI a ha,
    A.holding_positive_and_nonexplosive] with ω hT hreg
  intro hω
  have hi := nestedTraversalEvent_index_bound N O I J hJO b k a ω hω
  have ht := (jumpTime_strictMono hreg.1).monotone hi
  have hcount := physicalSegmentCount_ge_of_time
    (fun j => adaptiveExitTime N (alternatingDomain N I J) a j ω) hT.1.monotone
    (by simp [adaptiveExitTime]) hT.2 (finiteExitDuration N O a ω)
    (jumpTime_nonneg ω _) (2*k) ht
  change k ≤ physicalSegmentCount _ _ / 2
  omega

/-- A lower bound on the restart event is a lower bound on the actual
completed count under the specified original outer exit. -/
theorem nestedTraversalCount_tail_of_event (N : Size) (O I J : Finset (Vertex N))
    (hJO : J ⊆ O) (hIJ : I ⊆ J) (hI : I.Nonempty) (a b : Vertex N) (ha : a ∉ J)
    (k : ℕ) (L : ℝ) (hpos : 0 < exitHarmonic N O b a)
    (hmass : L*exitHarmonic N O b a ≤ walkLaw.real (nestedTraversalEvent N O I J b k a)) :
    L ≤ (exactExitLaw N O a b).real {ω | k ≤ nestedTraversalCount N O I J a ω} := by
  have : IsFiniteMeasure (exactExitLaw N O a b) := by
    unfold exactExitLaw
    infer_instance
  have he := exactExitLaw_real_of_subset N O a b (nestedTraversalEvent N O I J b k a)
    (nestedTraversalEvent_subset_exit N O I J hJO b k a)
  have hl : L ≤ (exactExitLaw N O a b).real (nestedTraversalEvent N O I J b k a) := by
    rw [he]
    exact (le_div_iff₀ hpos).mpr hmass
  apply hl.trans
  apply ENNReal.toReal_mono (measure_ne_top _ _)
  apply measure_mono_ae
  exact (show exactExitLaw N O a b ≪ walkLaw from cond_absolutelyContinuous).ae_le
      (nestedTraversalEvent_count_bound_ae N O I J hJO hIJ hI a b ha k)

end TorusCoverTime.Blocks.B
