import Solutions.Blocks.B.FiniteExitWords

/-! The finite exit word is tied to actual physical exit time and actual occupation time. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

def finiteExitIndex (N : Size) (D : Finset (Vertex N)) (a : Vertex N) (ω : WalkSample) : ℕ :=
  if h : ∃ n : ℕ, position N a ω n ∉ D then Nat.find h else 0

def finiteExitDuration (N : Size) (D : Finset (Vertex N)) (a : Vertex N) (ω : WalkSample) : ℝ :=
  jumpTime ω (finiteExitIndex N D a ω)

def domainExitTime (N : Size) (D : Finset (Vertex N)) (a : Vertex N) (ω : WalkSample) : ℝ≥0∞ :=
  sInf {u | ∃ t : ℝ, 0 ≤ t ∧ walk N a ω t ∉ D ∧ u = ENNReal.ofReal t}

lemma finiteExitIndex_of_exit_word (N : Size) (D : Finset (Vertex N)) (a b : Vertex N)
    (ω : WalkSample) (n : ℕ) (hn : exitsThroughAt N D a b ω n) : finiteExitIndex N D a ω = n := by
  have he : ∃ j : ℕ, position N a ω j ∉ D := ⟨n, by simpa only [hn.2.1] using hn.1⟩
  rw [finiteExitIndex, dif_pos he]
  apply (Nat.find_eq_iff he).mpr
  exact ⟨by simpa only [hn.2.1] using hn.1, fun j hj => not_not.mpr (hn.2.2 ⟨j, hj⟩)⟩

lemma measurable_finiteExitIndex (N : Size) (D : Finset (Vertex N)) (a : Vertex N) :
    Measurable (finiteExitIndex N D a) := by
  let E : Set WalkSample := {ω | ∃ n : ℕ, position N a ω n ∉ D}
  have hE : MeasurableSet E := by
    simp only [E, Set.ofPred_exists]
    exact MeasurableSet.iUnion fun n => (measurableSet_position_mem N a D n).compl
  have hf : Measurable (fun ω : E => Nat.find ω.property) := by
    apply measurable_find
    intro n
    exact ((measurableSet_position_mem N a D n).compl).preimage measurable_subtype_coe
  exact hf.dite (measurable_const (a := (0 : ℕ))) hE

lemma measurable_finiteExitDuration (N : Size) (D : Finset (Vertex N)) (a : Vertex N) :
    Measurable (finiteExitDuration N D a) := by
  have hm : Measurable (fun p : WalkSample × ℕ => jumpTime p.1 p.2) :=
    measurable_from_prod_countable_left fun n => measurable_jumpTime n
  exact hm.comp (measurable_id.prodMk (measurable_finiteExitIndex N D a))

lemma localTime_measurable_random_time (N : Size) (a x : Vertex N)
    (τ : WalkSample → ℝ) (hτ : Measurable τ) :
    Measurable (fun ω => localTime N a ω (τ ω) x) := by
  have hm : Measurable (fun p : WalkSample × ℝ =>
      if 0 ≤ p.2 ∧ p.2 ≤ τ p.1 then
        (if walk N a p.1 p.2 = x then (1 : ℝ) else 0) else 0) :=
    Measurable.ite ((measurableSet_le measurable_const measurable_snd).inter
      (measurableSet_le measurable_snd (hτ.comp measurable_fst)))
      (measurable_walk_indicator_joint N a x) measurable_const
  have hi := (hm.stronglyMeasurable.integral_prod_right' (ν := volume)).measurable
  convert hi using 1
  ext ω
  rw [localTime, ← integral_indicator measurableSet_Icc]
  simp only [Set.indicator, Set.mem_Icc]

lemma jumpCount_le_at_jumpTime {ω : WalkSample} (hpos : ∀ j, 0 < (ω j).1)
    (hnon : Tendsto (jumpTime ω) atTop atTop) (n : ℕ) (t : ℝ) (ht : 0 ≤ t) (htn : t ≤ jumpTime ω n) :
    jumpCount ω t ≤ n := by
  have hlow := jumpTime_jumpCount_le hpos hnon ht
  by_contra hn
  have hlt := jumpTime_strictMono hpos (show n < jumpCount ω t by omega)
  linarith

lemma exitsThroughAt_physical (N : Size) (D : Finset (Vertex N)) (a b : Vertex N)
    {ω : WalkSample} (hpos : ∀ j, 0 < (ω j).1) (hnon : Tendsto (jumpTime ω) atTop atTop)
    (n : ℕ) (hn : exitsThroughAt N D a b ω n) :
    (∀ t : ℝ, 0 ≤ t → t < jumpTime ω n → walk N a ω t ∈ D) ∧
      walk N a ω (jumpTime ω n) = b := by
  constructor
  · intro t ht htn
    have hlow := jumpTime_jumpCount_le hpos hnon ht
    have hi : jumpCount ω t < n := by
      by_contra hi
      have hm := (jumpTime_strictMono hpos).monotone (show n ≤ jumpCount ω t by omega)
      linarith
    simpa only [walk, not_lt.mpr ht, if_false] using hn.2.2 ⟨jumpCount ω t, hi⟩
  · simpa only [walk, not_lt.mpr (jumpTime_nonneg ω n), if_false, jumpCount_jumpTime hpos] using hn.2.1

lemma domainExitTime_of_exit_word (N : Size) (D : Finset (Vertex N)) (a b : Vertex N)
    {ω : WalkSample} (hpos : ∀ j, 0 < (ω j).1) (hnon : Tendsto (jumpTime ω) atTop atTop)
    (n : ℕ) (hn : exitsThroughAt N D a b ω n) :
    domainExitTime N D a ω = ENNReal.ofReal (finiteExitDuration N D a ω) := by
  rw [finiteExitDuration, finiteExitIndex_of_exit_word N D a b ω n hn]
  have hp := exitsThroughAt_physical N D a b hpos hnon n hn
  apply le_antisymm
  · exact sInf_le ⟨jumpTime ω n, jumpTime_nonneg ω n, by simpa only [hp.2] using hn.1, rfl⟩
  · apply le_sInf
    rintro u ⟨t, ht, hx, rfl⟩
    have hnt : jumpTime ω n ≤ t := by
      by_contra hnt
      exact hx (hp.1 t ht (lt_of_not_ge hnt))
    exact ENNReal.ofReal_le_ofReal hnt

lemma localTime_zero_of_prefix_avoidance (N : Size) (a : Vertex N) (K : Finset (Vertex N))
    {ω : WalkSample} (hpos : ∀ j, 0 < (ω j).1) (hnon : Tendsto (jumpTime ω) atTop atTop)
    (n : ℕ) (hAvoid : discreteAvoids N a K ω n) (x : Vertex N) (hx : x ∈ K) :
    localTime N a ω (jumpTime ω n) x = 0 := by
  unfold localTime
  apply integral_eq_zero_of_ae
  filter_upwards [ae_restrict_mem measurableSet_Icc] with t ht
  have hi := jumpCount_le_at_jumpTime hpos hnon n t ht.1 ht.2
  have hne : walk N a ω t ≠ x := by
    rw [walk, if_neg (not_lt.mpr ht.1)]
    intro heq
    exact hAvoid _ hi (heq.symm ▸ hx)
  simp only [hne, if_false, Pi.zero_apply]

lemma localTime_zero_on_avoiding_exit (N : Size) (D K : Finset (Vertex N)) (a b : Vertex N)
    {ω : WalkSample} (hpos : ∀ j, 0 < (ω j).1) (hnon : Tendsto (jumpTime ω) atTop atTop)
    (hAvoid : ω ∈ exitsThroughAvoiding N D K a b) (x : Vertex N) (hx : x ∈ K) :
    localTime N a ω (finiteExitDuration N D a ω) x = 0 := by
  obtain ⟨n, hn, ha⟩ := hAvoid
  rw [finiteExitDuration, finiteExitIndex_of_exit_word N D a b ω n hn]
  exact localTime_zero_of_prefix_avoidance N a K hpos hnon n ha x hx

end TorusCoverTime.Blocks.B
