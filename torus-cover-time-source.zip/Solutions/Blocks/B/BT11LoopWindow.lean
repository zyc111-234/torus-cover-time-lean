import Solutions.Blocks.B.BT11ClosingTransfer

/-! Integrate the fixed-prefix comparison over a positive physical
closing window and sum all roots, cancelling their exact cardinality. -/
noncomputable section
open MeasureTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

def bt11LoopJoint (N : Size) (a : Vertex N) (u η t : ℝ) : ℝ≥0∞ :=
  walkLaw {ω | ω∈bt11Bad N a u η t ∧ walk N a ω t=a}

theorem bt11LoopJoint_eq_lintegral (N : Size) (a : Vertex N) (u η t : ℝ) :
    bt11LoopJoint N a u η t=∫⁻ ω,
      if η*Real.sqrt (logSize N)<bt10DefectCount N a u (ω,t) ∧ walk N a ω t=a then (1:ℝ≥0∞) else 0 ∂walkLaw := by
  have hE : MeasurableSet {ω | ω∈bt11Bad N a u η t ∧ walk N a ω t=a} :=
    (bt11Bad_measurable N a u η t).inter
      (((measurable_walk_eq_joint N a a).comp (measurable_id.prodMk measurable_const)).setOf)
  simpa only [bt11LoopJoint,bt11Bad,Set.indicator,Pi.one_apply,mem_setOf_eq] using
    (lintegral_indicator_one (μ := walkLaw) hE).symm

theorem bt11LoopJoint_measurable (N : Size) (a : Vertex N) (u η : ℝ) :
    Measurable (bt11LoopJoint N a u η) := by
  have hm : Measurable (fun z : WalkSample × ℝ =>
      if η*Real.sqrt (logSize N)<bt10DefectCount N a u z ∧ walk N a z.1 z.2=a then (1:ℝ≥0∞) else 0) :=
    measurable_const.ite ((measurableSet_lt measurable_const (bt10DefectCount_measurable N a u)).inter
      (measurable_walk_eq_joint N a a).setOf) measurable_const
  change Measurable (fun t => bt11LoopJoint N a u η t)
  simp_rw [bt11LoopJoint_eq_lintegral]
  exact hm.lintegral_prod_left

theorem bt11_loop_window_identity (N : Size) (u η l r : ℝ) (hl : 0<l) :
    r7LoopEventMass N (fun a => {z | η*Real.sqrt (logSize N)<bt10DefectCount N a u z}) l r=
      (ENNReal.ofReal (timeScale N))⁻¹*∫⁻ t in Icc l r,∑ a : Vertex N,bt11LoopJoint N a u η t := by
  have hroot (a : Vertex N) :
      (∫⁻ ω,∫⁻ t in Ioi (0:ℝ),r7LoopEventTest N a
        {z | η*Real.sqrt (logSize N)<bt10DefectCount N a u z} l r (ω,t) ∂volume ∂walkLaw)=
      ∫⁻ t in Icc l r,bt11LoopJoint N a u η t := by
    rw [lintegral_lintegral_swap (by exact (r7LoopEventTest_measurable N a _
      (measurableSet_lt measurable_const (bt10DefectCount_measurable N a u)) l r).aemeasurable)]
    have he (t : ℝ) : (∫⁻ ω,r7LoopEventTest N a
        {z | η*Real.sqrt (logSize N)<bt10DefectCount N a u z} l r (ω,t) ∂walkLaw)=
        (Icc l r).indicator (bt11LoopJoint N a u η) t := by
      by_cases ht : t∈Icc l r
      · rw [indicator_of_mem ht,bt11LoopJoint_eq_lintegral]
        apply lintegral_congr
        intro ω
        simp only [r7LoopEventTest,mem_setOf_eq,ht,and_true]
      · simp only [r7LoopEventTest,ht,and_false,if_false,lintegral_zero,indicator_of_notMem ht]
    simp_rw [he]
    have hsub : Icc l r⊆Ioi (0:ℝ) := fun _ ht => mem_Ioi.mpr (hl.trans_le ht.1)
    rw [lintegral_indicator measurableSet_Icc,Measure.restrict_restrict measurableSet_Icc,
      inter_eq_left.mpr hsub]
  unfold r7LoopEventMass
  simp_rw [hroot]
  rw [lintegral_finsetSum _ (fun a _ => bt11LoopJoint_measurable N a u η)]

theorem bt11_closing_root_upper (hWalk : WalkModelRegular) (u H : ℝ) (hH : 0≤H) :
    ∀ᶠ N : Size in atTop, ∀ η s T : ℝ, 0<η → 0≤s →
    phaseACenter N-H*timeScale N≤s → bt11ShortTime N≤T → T≤2*bt11ShortTime N →
      walkLaw (bt11Bad N 0 u η s)≤4*(∑ a : Vertex N,bt11LoopJoint N a (u+1) (η/2) (s+T))+
        ENNReal.ofReal (2*pointNearEnvelope N (1/8192) 1 u H) := by
  filter_upwards [bt11_closing_point_upper hWalk u H hH] with N hN
  intro η s T hη hs htime hlo hhi
  have hsum := Finset.sum_le_sum (s := (Finset.univ:Finset (Vertex N))) (fun a _ => hN a η s T hη hs htime hlo hhi)
  let n := ENNReal.ofReal (vertexCount N)
  have hn : n≠0 := ENNReal.ofReal_ne_zero_iff.mpr (vertexCount_pos N)
  have he : (Fintype.card (Vertex N):ℝ≥0∞)=n := by
    dsimp [n]
    rw [D.vertexCount_eq_card,ENNReal.ofReal_natCast]
  simp only [Finset.sum_const,Finset.card_univ,nsmul_eq_mul,Finset.sum_add_distrib,← Finset.mul_sum,he] at hsum
  have h4 : ENNReal.ofReal (4*vertexCount N)=4*n := by rw [ENNReal.ofReal_mul (by norm_num : (0:ℝ)≤4)]; norm_num; rfl
  rw [h4] at hsum
  have hh := mul_le_mul' (le_refl n⁻¹) hsum
  have hr : n⁻¹*((4*n)*(∑ a : Vertex N,bt11LoopJoint N a (u+1) (η/2) (s+T))+
      n*ENNReal.ofReal (2*pointNearEnvelope N (1/8192) 1 u H))=
      4*(∑ a : Vertex N,bt11LoopJoint N a (u+1) (η/2) (s+T))+
      ENNReal.ofReal (2*pointNearEnvelope N (1/8192) 1 u H) := by
    rw [mul_add]
    have hn' : n⁻¹*n=1 := ENNReal.inv_mul_cancel hn ENNReal.ofReal_ne_top
    calc
      _ = 4*(n⁻¹*n)*(∑ a : Vertex N,bt11LoopJoint N a (u+1) (η/2) (s+T))+
          (n⁻¹*n)*ENNReal.ofReal (2*pointNearEnvelope N (1/8192) 1 u H) := by ring
      _ = _ := by rw [hn',mul_one,one_mul]
  change n⁻¹*(n*walkLaw (bt11Bad N 0 u η s))≤_ at hh
  rw [← mul_assoc,ENNReal.inv_mul_cancel hn ENNReal.ofReal_ne_top,one_mul] at hh
  exact hh.trans_eq hr

theorem bt11_window_upper (hWalk : WalkModelRegular) (u H : ℝ) (hH : 0≤H) :
    ∀ᶠ N : Size in atTop, ∀ η s : ℝ, 0<η → 0≤s → phaseACenter N-H*timeScale N≤s →
      walkLaw (bt11Bad N 0 u η s)≤65536*r7LoopEventMass N
        (fun a => {z | (η/2)*Real.sqrt (logSize N)<bt10DefectCount N a (u+1) z})
        (s+bt11ShortTime N) (s+2*bt11ShortTime N)+
          ENNReal.ofReal (2*pointNearEnvelope N (1/8192) 1 u H) := by
  filter_upwards [bt11_closing_root_upper hWalk u H hH] with N hN
  intro η s hη hs htime
  let l := s+bt11ShortTime N
  let r := s+2*bt11ShortTime N
  let J := fun t => ∑ a : Vertex N,bt11LoopJoint N a (u+1) (η/2) t
  let P := walkLaw (bt11Bad N 0 u η s)
  let E := ENNReal.ofReal (2*pointNearEnvelope N (1/8192) 1 u H)
  have hJ : Measurable J := Finset.measurable_sum _ (fun a _ => bt11LoopJoint_measurable N a (u+1) (η/2))
  have hI : ENNReal.ofReal (r-l)*P≤4*(∫⁻ t in Icc l r,J t)+ENNReal.ofReal (r-l)*E := by
    have hi := lintegral_mono_ae (μ := volume.restrict (Icc l r)) (f := fun _ => P) (g := fun t => 4*J t+E) (by
      filter_upwards [ae_restrict_mem measurableSet_Icc] with t ht
      have hh := hN η s (t-s) hη hs htime (by dsimp [l] at ht; linarith [ht.1])
        (by dsimp [r] at ht; linarith [ht.2])
      simpa only [add_sub_cancel] using hh)
    rw [lintegral_const,lintegral_add_left (hJ.const_mul 4),lintegral_const_mul' _ _ (by norm_num),
      lintegral_const,Measure.restrict_apply_univ,Real.volume_Icc] at hi
    simpa only [mul_comm] using hi
  let A := ENNReal.ofReal (16384/timeScale N)
  have hA : A*ENNReal.ofReal (r-l)=1 := by
    dsimp only [A]
    rw [← ENNReal.ofReal_mul (by have := timeScale_pos N; positivity : 0≤16384/timeScale N)]
    dsimp only [l,r,bt11ShortTime]
    have hid : 16384/timeScale N*(s+2*(timeScale N/16384)-(s+timeScale N/16384))=1 := by
      field_simp [(timeScale_pos N).ne']
      <;> ring
    rw [hid,ENNReal.ofReal_one]
  have hcoef : A*4=65536*(ENNReal.ofReal (timeScale N))⁻¹ := by
    dsimp only [A]
    rw [show (4:ℝ≥0∞)=ENNReal.ofReal 4 by norm_num,
      ← ENNReal.ofReal_mul (by have := timeScale_pos N; positivity : 0≤16384/timeScale N),
      ← ENNReal.ofReal_inv_of_pos (timeScale_pos N),
      show (65536:ℝ≥0∞)=ENNReal.ofReal 65536 by norm_num,
      ← ENNReal.ofReal_mul (by norm_num : (0:ℝ)≤65536)]
    congr 1
    ring
  have hh := mul_le_mul' (le_refl A) hI
  rw [← mul_assoc,hA,one_mul,mul_add,← mul_assoc,← mul_assoc,hcoef,hA,one_mul] at hh
  rw [bt11_loop_window_identity N (u+1) (η/2) l r (by dsimp [l]; linarith [bt11ShortTime_pos N])]
  exact hh.trans_eq (by dsimp only [J,E]; ring)

end TorusCoverTime.Blocks.B
