import Solutions.Blocks.B.SpatialCharacters
import Solutions.Blocks.B.AbelBounds

/-! Signed centered frequency sums and the geometric characters of each coordinate. -/

noncomputable section
open scoped BigOperators
namespace TorusCoverTime.Blocks.B

lemma sum_zmod_centered_complex (N : Size) (F : ZMod N.val → ℂ) :
    (∑ a, F a) = F 0 +
      (∑ j ∈ Finset.range (N.val / 2), F ((j + 1 : ℕ) : ZMod N.val)) +
      (∑ j ∈ Finset.range ((N.val - 1) / 2), F (-((j + 1 : ℕ) : ZMod N.val))) := by
  classical
  have hlow : (∑ a ∈ Finset.univ.filter (fun a : ZMod N.val => a.val ≤ N.val / 2), F a) =
      ∑ j ∈ Finset.range (N.val / 2 + 1), F (j : ZMod N.val) := by
    apply Finset.sum_bij (fun a _ => a.val)
    · intro a ha
      exact Finset.mem_range.mpr (by have := (Finset.mem_filter.mp ha).2; omega)
    · intro a _ b _ hab
      exact ZMod.val_injective N.val hab
    · intro j hj
      have hj' := Finset.mem_range.mp hj
      have hjN : j < N.val := by have := N.property; omega
      refine ⟨(j : ZMod N.val), ?_, ZMod.val_cast_of_lt hjN⟩
      simp only [Finset.mem_filter, Finset.mem_univ, true_and, ZMod.val_cast_of_lt hjN]
      omega
    · intro a _
      simp
  have hhigh : (∑ a ∈ Finset.univ.filter (fun a : ZMod N.val => ¬ a.val ≤ N.val / 2), F a) =
      ∑ j ∈ Finset.range ((N.val - 1) / 2), F (-((j + 1 : ℕ) : ZMod N.val)) := by
    apply Finset.sum_bij (fun a _ => N.val - a.val - 1)
    · intro a ha
      have hv := ZMod.val_lt a
      have hhalf := (Finset.mem_filter.mp ha).2
      apply Finset.mem_range.mpr
      omega
    · intro a _ b _ hab
      apply ZMod.val_injective N.val
      have := ZMod.val_lt a
      have := ZMod.val_lt b
      omega
    · intro j hj
      have hj' := Finset.mem_range.mp hj
      have hjN : N.val - (j + 1) < N.val := by have := N.property; omega
      refine ⟨((N.val - (j + 1) : ℕ) : ZMod N.val), ?_, ?_⟩
      · simp only [Finset.mem_filter, Finset.mem_univ, true_and, ZMod.val_cast_of_lt hjN]
        omega
      · rw [ZMod.val_cast_of_lt hjN]
        omega
    · intro a _
      have hv := ZMod.val_lt a
      have heq : N.val - a.val - 1 + 1 = N.val - a.val := by omega
      rw [heq, Nat.cast_sub hv.le]
      simp
  rw [← Finset.sum_filter_add_sum_filter_not (p := fun a : ZMod N.val => a.val ≤ N.val / 2),
    hlow, hhigh, Finset.sum_range_succ']
  simp only [Nat.cast_zero]
  ring

lemma coordinateDistance_natCast_half (N : Size) (j : ℕ) (hj : j ≤ N.val / 2) :
    coordinateDistance (j : ZMod N.val) 0 = (j : ℝ) := by
  rw [coordinateDistance_eq_abs_centered, ZMod.valMinAbs_natCast_of_le_half hj]
  simp

lemma coordinateCharacter_norm (N : Size) (a : ZMod N.val) : ‖coordinateCharacter N a‖ = 1 := by
  exact Circle.norm_coe _

lemma coordinateCharacter_nat_mul (N : Size) (j : ℕ) (z : ZMod N.val) :
    coordinateCharacter N ((j : ZMod N.val) * z) = coordinateCharacter N z ^ j := by
  induction j with
  | zero => simp
  | succ j ih =>
    simp only [Nat.cast_add, Nat.cast_one, add_mul, one_mul, coordinateCharacter_add, ih, pow_succ]

lemma coordinateCharacter_neg (N : Size) (a : ZMod N.val) :
    coordinateCharacter N (-a) = (coordinateCharacter N a)⁻¹ := by
  have hmul : coordinateCharacter N a * coordinateCharacter N (-a) = 1 := by
    rw [← coordinateCharacter_add, add_neg_cancel, coordinateCharacter_zero]
  have ha : coordinateCharacter N a ≠ 0 := by
    intro h
    have hn := coordinateCharacter_norm N a
    rw [h, norm_zero] at hn
    norm_num at hn
  exact ((mul_eq_one_iff_inv_eq₀ ha).mp hmul).symm

lemma coordinateCharacter_inv_gap (N : Size) (a : ZMod N.val) :
    ‖(coordinateCharacter N a)⁻¹ - 1‖ = ‖coordinateCharacter N a - 1‖ := by
  have ha : coordinateCharacter N a ≠ 0 := by
    intro h
    have hn := coordinateCharacter_norm N a
    rw [h, norm_zero] at hn
    norm_num at hn
  have hid : (coordinateCharacter N a)⁻¹ - 1 =
      -(coordinateCharacter N a - 1) / coordinateCharacter N a := by field_simp; ring
  rw [hid, norm_div, norm_neg, coordinateCharacter_norm, div_one]

end TorusCoverTime.Blocks.B
