import Solutions.Blocks.B.ExitOccupationRenewal

/-! Green representation for the expectation of the original physical
occupation under the actual specified-exit probability law. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

theorem holdingTime_integrable (j : ℕ) : Integrable (fun ω => holdingTime ω j) walkLaw := by
  refine ⟨(measurable_holdingTime j).aestronglyMeasurable, ?_⟩
  have hnon : ∀ᵐ ω : WalkSample ∂walkLaw, 0 ≤ holdingTime ω j :=
    Eventually.of_forall (fun ω => le_max_right (ω j).1 0)
  apply (hasFiniteIntegral_iff_ofReal hnon).mpr
  rw [holdingTime_lintegral_mean]
  exact ENNReal.one_lt_top

def exitPotentialMean (N : Size) (D : Finset (Vertex N)) (b : Vertex N)
    (U : Vertex N → ℝ) (a : Vertex N) : ℝ :=
  ∫ ω, exitPotentialWeight N D b U a ω ∂walkLaw

theorem disk_exitPotentialMean_first_step (N : Size) (c : Vertex N) (R : ℝ)
    (hR : 0 ≤ R) (hsmall : 2*(R+1) < N.val) (b : Vertex N)
    (U : Vertex N → ℝ) (hU : ∀ z, 0 ≤ U z) (a : Vertex N) (ha : a ∈ torusDisk N c R) :
    exitPotentialMean N (torusDisk N c R) b U a = U a*exitHarmonic N (torusDisk N c R) b a +
      (∑ d : Fin 4, exitPotentialMean N (torusDisk N c R) b U (a+direction N d))/4 := by
  let D := torusDisk N c R
  have hi : Integrable (fun ω => if ω ∈ exitsThrough N D a b then holdingTime ω 0 else 0) walkLaw :=
    (holdingTime_integrable 0).indicator (measurableSet_exitsThrough N D a b)
  have ht := first_direction_tail_integrable (fun d => exitPotentialWeight N D b U (a+direction N d))
    (fun d => measurable_exitPotentialWeight N D b U _) (fun d => disk_exitPotentialWeight_integrable N c R hR hsmall b U hU _)
  change (∫ ω, exitPotentialWeight N D b U a ω ∂walkLaw) = U a*exitHarmonic N D b a +
    (∑ d : Fin 4, ∫ ω, exitPotentialWeight N D b U (a+direction N d) ω ∂walkLaw)/4
  simp_rw [exitPotentialWeight_first_step N D b U a ha]
  rw [integral_add (hi.const_mul (U a)) ht, integral_const_mul, integral_holdingTime_on_exit,
    integral_first_direction_tail (fun d => exitPotentialWeight N D b U (a+direction N d))
      (fun d => measurable_exitPotentialWeight N D b U _)
      (fun d => disk_exitPotentialWeight_integrable N c R hR hsmall b U hU _)]

theorem disk_exitPotentialMean_generator (N : Size) (c : Vertex N) (R : ℝ)
    (hR : 0 ≤ R) (hsmall : 2*(R+1) < N.val) (b : Vertex N)
    (U : Vertex N → ℝ) (hU : ∀ z, 0 ≤ U z) (a : Vertex N) (ha : a ∈ torusDisk N c R) :
    -generator N (exitPotentialMean N (torusDisk N c R) b U) a =
      U a*exitHarmonic N (torusDisk N c R) b a := by
  have hm := disk_exitPotentialMean_first_step N c R hR hsmall b U hU a ha
  simp only [generator, Finset.sum_sub_distrib, Finset.sum_const, Finset.card_univ,
    Fintype.card_fin, nsmul_eq_mul, Nat.cast_ofNat]
  linarith

theorem disk_exitPotentialMean_green (N : Size) (c : Vertex N) (R : ℝ)
    (hR : 0 ≤ R) (hsmall : 2*(R+1) < N.val) (b : Vertex N)
    (U : Vertex N → ℝ) (hU : ∀ z, 0 ≤ U z) (a : Vertex N) :
    exitPotentialMean N (torusDisk N c R) b U a =
      ∑ z, U z*exitHarmonic N (torusDisk N c R) b z*diskGreen N c R a z := by
  have hb : ∀ z, z ∉ torusDisk N c R → exitPotentialMean N (torusDisk N c R) b U z = 0 := by
    intro z hz
    simp only [exitPotentialMean, exitPotentialWeight_boundary N (torusDisk N c R) b U z hz, integral_zero]
  exact congrFun (domainGreenFromBarrier_solution N (torusDisk N c R)
    (torusDisk_proper N c R hR hsmall) (diskBarrier N c R)
    (fun z hz => diskBarrier_generator N c R hR hsmall z hz)
    (fun z => U z*exitHarmonic N (torusDisk N c R) b z)
    (exitPotentialMean N (torusDisk N c R) b U) hb
    (fun z hz => disk_exitPotentialMean_generator N c R hR hsmall b U hU z hz)) a

theorem exitPotentialWeight_eq_physical_ae (hWalk : WalkModelRegular) (N : Size)
    (D : Finset (Vertex N)) (b : Vertex N) (U : Vertex N → ℝ) (a : Vertex N) :
    exitPotentialWeight N D b U a =ᵐ[walkLaw] (exitsThrough N D a b).indicator
      (fun ω => ∑ z, U z*localTime N a ω (finiteExitDuration N D a ω) z) := by
  filter_upwards [hWalk.1] with ω hω
  simp only [exitPotentialWeight, Set.indicator]
  split_ifs
  · exact holdingPotentialSum_eq_localTime N U a hω.1 hω.2 _
  · rfl

theorem disk_conditioned_occupation_integrable (hWalk : WalkModelRegular) (N : Size)
    (c : Vertex N) (R : ℝ) (hR : 0 ≤ R) (hsmall : 2*(R+1) < N.val) (a b : Vertex N)
    (U : Vertex N → ℝ) (hU : ∀ z, 0 ≤ U z) :
    Integrable (fun ω => ∑ z, U z*localTime N a ω (finiteExitDuration N (torusDisk N c R) a ω) z)
      (exactExitLaw N (torusDisk N c R) a b) := by
  let E := exitsThrough N (torusDisk N c R) a b
  have hE := measurableSet_exitsThrough N (torusDisk N c R) a b
  have hia := (disk_exitPotentialWeight_integrable N c R hR hsmall b U hU a).congr
    (exitPotentialWeight_eq_physical_ae hWalk N _ b U a)
  have hi := (integrable_indicator_iff hE).mp hia
  have hav := hi.to_average
  simpa only [Measure.restrict_apply_univ, exactExitLaw, ProbabilityTheory.cond] using hav

theorem disk_conditioned_occupation_green (hWalk : WalkModelRegular) (N : Size)
    (c : Vertex N) (R : ℝ) (hR : 0 ≤ R) (hsmall : 2*(R+1) < N.val) (a b : Vertex N)
    (U : Vertex N → ℝ) (hU : ∀ z, 0 ≤ U z) :
    (∫ ω, (∑ z, U z*localTime N a ω (finiteExitDuration N (torusDisk N c R) a ω) z)
      ∂exactExitLaw N (torusDisk N c R) a b) =
        (∑ z, U z*exitHarmonic N (torusDisk N c R) b z*diskGreen N c R a z)/
          exitHarmonic N (torusDisk N c R) b a := by
  rw [exactExitLaw, ProbabilityTheory.cond, integral_smul_measure,
    ← integral_indicator (measurableSet_exitsThrough N (torusDisk N c R) a b),
    ← integral_congr_ae (exitPotentialWeight_eq_physical_ae hWalk N _ b U a)]
  change _ * exitPotentialMean N (torusDisk N c R) b U a = _
  rw [disk_exitPotentialMean_green N c R hR hsmall b U hU a, ENNReal.toReal_inv]
  unfold exitHarmonic Measure.real
  ring

theorem disk_conditioned_localTime_green (hWalk : WalkModelRegular) (N : Size)
    (c : Vertex N) (R : ℝ) (hR : 0 ≤ R) (hsmall : 2*(R+1) < N.val) (a b x : Vertex N) :
    (∫ ω, localTime N a ω (finiteExitDuration N (torusDisk N c R) a ω) x
      ∂exactExitLaw N (torusDisk N c R) a b) =
        diskGreen N c R a x*exitHarmonic N (torusDisk N c R) b x/
          exitHarmonic N (torusDisk N c R) b a := by
  simpa only [ite_mul, mul_ite, one_mul, zero_mul, mul_zero, Finset.sum_ite_eq', Finset.mem_univ, if_true, mul_comm]
    using disk_conditioned_occupation_green hWalk N c R hR hsmall a b
      (fun z => if z = x then (1:ℝ) else 0) (fun z => by split_ifs <;> norm_num)

end TorusCoverTime.Blocks.B
