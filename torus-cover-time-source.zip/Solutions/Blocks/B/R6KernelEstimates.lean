import Solutions.Blocks.B.DiskExitPolynomial
import Solutions.Blocks.B.R6DiskDuration
import Solutions.Blocks.B.R6ConditionedAvoidance
import Solutions.Blocks.B.R6OccupationCount

/-! R6.1--R6.4 and their block consequences for the actual specified-exit
law. The polynomial endpoint mass, avoidance and point hitting estimates
are proved inputs, with all geometric hypotheses stated explicitly. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

theorem disk_exit_interior_probability_lower (N : Size) (c : Vertex N) (R : ℝ)
    (hR : 3*diskHarnackRadiusThreshold ≤ R) (hsmall : 2*(R+1) < N.val)
    (a b : Vertex N) (ha : periodicDistance a c ≤ R/(12*diskGreenInnerScale))
    (hb : diskExteriorNeighbor N c R b) :
    ENNReal.ofReal (diskExitLowerConstant*R^(-(diskExitPower:ℝ))) ≤
      walkLaw (exitsThrough N (torusDisk N c R) a b) :=
  (ENNReal.ofReal_le_ofReal
    (disk_exit_interior_polynomial N c R hR hsmall a b ha hb)).trans
      ENNReal.ofReal_toReal_le

theorem r6_endpoint_probability_lower (γ : ℝ) (hγ : 0 < γ) :
    ∀ᶠ q : ℝ in atTop, ∀ N : Size, ∀ c a b : Vertex N,
      2*(Real.exp (q+2*q^γ)+1) < N.val →
      |periodicDistance a c-Real.exp (q+q^γ)| ≤ 2 →
      diskExteriorNeighbor N c (Real.exp (q+2*q^γ)) b →
      ENNReal.ofReal (diskExitLowerConstant*
        (Real.exp (q+2*q^γ))^(-(diskExitPower:ℝ))) ≤
          walkLaw (exitsThrough N (torusDisk N c (Real.exp (q+2*q^γ))) a b) := by
  filter_upwards [r6_harnack_geometry γ hγ] with q hgeom
  intro N c a b hsmall ha hb
  obtain ⟨hR,haR,_⟩ := hgeom N c a c ha
    ((mem_torusDisk N c c _).mpr (by rw [periodicDistance_self_zero]; positivity))
  exact disk_exit_interior_probability_lower N c _ hR hsmall a b haR hb

theorem r6_endpoint_probability_pos (γ : ℝ) (hγ : 0 < γ) :
    ∀ᶠ q : ℝ in atTop, ∀ N : Size, ∀ c a b : Vertex N,
      2*(Real.exp (q+2*q^γ)+1) < N.val →
      |periodicDistance a c-Real.exp (q+q^γ)| ≤ 2 →
      diskExteriorNeighbor N c (Real.exp (q+2*q^γ)) b →
      0 < walkLaw (exitsThrough N (torusDisk N c (Real.exp (q+2*q^γ))) a b) := by
  filter_upwards [r6_endpoint_probability_lower γ hγ] with q hq
  intro N c a b hsmall ha hb
  exact (ENNReal.ofReal_pos.mpr (mul_pos diskExitLowerConstant_pos
    (Real.rpow_pos_of_pos (Real.exp_pos _) _))).trans_le (hq N c a b hsmall ha hb)

theorem r6_specified_exit_duration (hWalk : WalkModelRegular) (γ : ℝ) (hγ : 0 < γ) :
    ∀ᶠ q : ℝ in atTop, ∀ N : Size, ∀ c a b : Vertex N,
      2*(Real.exp (q+2*q^γ)+1) < N.val →
      |periodicDistance a c-Real.exp (q+q^γ)| ≤ 2 →
      diskExteriorNeighbor N c (Real.exp (q+2*q^γ)) b →
      ∀ t : ℝ, 0 ≤ t →
      exactExitLaw N (torusDisk N c (Real.exp (q+2*q^γ))) a b
        {ω | t < finiteExitDuration N (torusDisk N c (Real.exp (q+2*q^γ))) a ω} ≤
          ENNReal.ofReal ((9/diskExitLowerConstant)*
            (Real.exp (q+2*q^γ))^((diskExitPower:ℝ)+2)*
              Real.exp (-t/(4*(Real.exp (q+2*q^γ))^2))) := by
  filter_upwards [r6_endpoint_probability_lower γ hγ, eventually_ge_atTop (0:ℝ)] with q he hq
  intro N c a b hsmall ha hb t ht
  exact r6_disk_duration_of_endpoint_lower hWalk N c _
    (Real.one_le_exp_iff.mpr (by positivity)) hsmall a b t
    diskExitLowerConstant diskExitPower ht diskExitLowerConstant_pos (he N c a b hsmall ha hb)

theorem r6_softness_probability_lower (hWalk : WalkModelRegular) (γ : ℝ) (hγ : 0 < γ) :
    ∀ᶠ q : ℝ in atTop, ∀ N : Size, ∀ c : Vertex N, ∀ m : ℕ,
      ∀ a b : Fin m → Vertex N,
      2*(Real.exp (q+2*q^γ)+1) < N.val →
      (∀ i, |periodicDistance (a i) c-Real.exp (q+q^γ)| ≤ 2) →
      (∀ i, diskExteriorNeighbor N c (Real.exp (q+2*q^γ)) (b i)) →
      ∀ u : ℝ, 0 ≤ u →
      (1/8 : ℝ≥0∞)^m ≤ exactExitProductLaw N (torusDisk N c (Real.exp (q+2*q^γ))) m a b
        (exitBlockSoftness N (torusDisk N c (Real.exp (q+2*q^γ)))
          (torusDisk N c (Real.exp q)) m a u) := by
  filter_upwards [r6_endpoint_probability_pos γ hγ, r6_conditioned_avoiding_exit γ hγ]
    with q hpos havoid
  intro N c m a b hsmall ha hb u hu
  exact exitBlockSoftness_probability_of_avoidance hWalk N _ _ m a b
    (fun i => (hpos N c (a i) (b i) hsmall (ha i) (hb i)).ne')
    (torusDisk_nonempty N c _ (Real.exp_pos _)) u hu (1/8)
    (fun i => havoid N c (a i) (b i) hsmall (ha i) (hb i))

theorem r6_block_occupation_lower_tail (hWalk : WalkModelRegular)
    (γ : ℝ) (hγ : 0 < γ) (hγ1 : γ ≤ 1) :
    ∀ᶠ q : ℝ in atTop, ∀ N : Size, ∀ c : Vertex N, ∀ m : ℕ,
      ∀ a b : Fin m → Vertex N,
      2*(Real.exp (q+2*q^γ)+1) < N.val →
      (∀ i, |periodicDistance (a i) c-Real.exp (q+q^γ)| ≤ 2) →
      (∀ i, diskExteriorNeighbor N c (Real.exp (q+2*q^γ)) (b i)) →
      ∀ x ∈ torusDisk N c (Real.exp q), ∀ u : ℝ,
      (exactExitProductLaw N (torusDisk N c (Real.exp (q+2*q^γ))) m a b).real
        {ω | exitBlockOccupation N (torusDisk N c (Real.exp (q+2*q^γ))) m a ω x ≤ u} ≤
          Real.exp (u-(m:ℝ)*(q^γ/(8*diskHarnackConstant*q))/2) := by
  filter_upwards [r6_endpoint_probability_pos γ hγ, r6_conditioned_point_hit_lower hWalk γ hγ hγ1]
    with q hpos hhit
  intro N c m a b hsmall ha hb x hx u
  exact exitBlock_occupation_lower_tail hWalk N _ m a b
    (fun i => (hpos N c (a i) (b i) hsmall (ha i) (hb i)).ne') x _ u
    (fun i => hhit N c (a i) (b i) x hsmall (ha i) (hb i) hx)

theorem r6_coarse_duration_given_softness (hWalk : WalkModelRegular)
    (γ : ℝ) (hγ : 0 < γ) (hγ1 : γ ≤ 1) :
    ∀ᶠ N : Size in atTop, ∀ c : Vertex N, ∀ m : ℕ,
      ∀ a b : Fin m → Vertex N, ∀ q u : ℝ,
      (logSize N)^(16*γ) ≤ q → q ≤ logSize N-(logSize N)^(16*γ) →
      (m:ℝ) ≤ (logSize N)^4+1 → 0 ≤ u →
      (∀ i, |periodicDistance (a i) c-Real.exp (q+q^γ)| ≤ 2) →
      (∀ i, diskExteriorNeighbor N c (Real.exp (q+2*q^γ)) (b i)) →
      (exactExitProductLaw N (torusDisk N c (Real.exp (q+2*q^γ))) m a b)[{ω | ∃ i,
        Real.exp (2*logSize N-(logSize N)^(16*γ)) <
          finiteExitDuration N (torusDisk N c (Real.exp (q+2*q^γ))) (a i) (ω i)} |
        exitBlockSoftness N (torusDisk N c (Real.exp (q+2*q^γ)))
          (torusDisk N c (Real.exp q)) m a u] ≤
            ENNReal.ofReal (Real.exp (-Real.exp ((logSize N)^(16*γ)/2))) := by
  obtain ⟨qE,hqE⟩ := eventually_atTop.mp (r6_endpoint_probability_lower γ hγ)
  obtain ⟨qA,hqA⟩ := eventually_atTop.mp (r6_conditioned_avoiding_exit γ hγ)
  have hQ := (tendsto_rpow_atTop (by positivity : 0 < 16*γ)).comp blockB_logSize_tendsto
  filter_upwards [r6_duration_superexponential_of_endpoint_avoidance hWalk γ
    diskExitLowerConstant diskExitPower (1/8) hγ hγ1 diskExitLowerConstant_pos (by norm_num),
    r6_disk_radius_embedding γ hγ, hQ.eventually_ge_atTop (max 0 (max qE qA))]
    with N hduration hsmall hQ
  intro c m a b q u hq hqL hm hu ha hb
  have hq0 : 0 ≤ q := (le_max_left 0 _).trans (hQ.trans hq)
  have he : qE ≤ q := (le_max_left qE qA).trans ((le_max_right 0 _).trans (hQ.trans hq))
  have hav : qA ≤ q := (le_max_right qE qA).trans ((le_max_right 0 _).trans (hQ.trans hq))
  apply hduration c (torusDisk N c (Real.exp q)) m a b q u hq0 hqL hm
    (torusDisk_nonempty N c _ (Real.exp_pos _)) hu
  · exact fun i => hqE q he N c (a i) (b i) (hsmall q hq0 hqL) (ha i) (hb i)
  · intro i
    have hh := hqA q hav N c (a i) (b i) (hsmall q hq0 hqL) (ha i) (hb i)
    simpa only [ENNReal.ofReal_div_of_pos (by norm_num : (0:ℝ)<8),
      ENNReal.ofReal_one, ENNReal.ofReal_ofNat] using hh

end TorusCoverTime.Blocks.B
