import Solutions.Blocks.B.R7CountedWindowRecurrence
import Solutions.Blocks.B.TraversalOccupation
import Solutions.Blocks.B.RootTimeMeasurability

/-! The low-record term in the actual window recurrence is the low harmonic
occupation event of the original path. The finite traversal-count restriction
can then be dropped by positivity, without assuming independence of that count. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

theorem traversalWordOutwardOccupation_of_word (N : Size) (I O : Finset (Vertex N))
    (root : Vertex N) (m : ℕ) (w : Fin (2*m) → Vertex N) (U : Vertex N → ℝ)
    (ω : WalkSample) (hw : adaptiveExitWord N (alternatingDomain N I O) root (2*m) ω = w) :
    traversalWordOutwardOccupation N root m w U
      (fun j => adaptiveExitRecord N (alternatingDomain N I O) root j.val.val ω) =
        traversalOccupation N I O root U m ω := by
  unfold traversalWordOutwardOccupation recordProductOccupation outwardRecordProjection
  simp only [outwardRecordEquiv, outwardRecordIndex, Equiv.coe_fn_mk]
  have he (i : Fin m) : endpointWordStart root w (2*i.val+1) =
      adaptiveExitStart N (alternatingDomain N I O) root (2*i.val+1) ω :=
    (adaptiveExitStart_of_word N _ root (2*m) w ω hw (2*i.val+1) (by omega)).symm
  simp_rw [he]
  exact Fin.sum_univ_eq_sum_range (fun k : ℕ => excursionRecordCost N
    (adaptiveExitStart N (alternatingDomain N I O) root (2*k+1) ω) U
    (adaptiveExitRecord N (alternatingDomain N I O) root (2*k+1) ω)) m

def harmonicPathOccupation (N : Size) (c root : Vertex N) (q : ℝ) (z : WalkSample × ℝ) : ℝ :=
  ∑ x, (diskHarmonicWeight N c (Real.exp (q+1)) x/g)*localTime N root z.1 z.2 x

theorem harmonicPathOccupation_measurable (N : Size) (c root : Vertex N) (q : ℝ) :
    Measurable (harmonicPathOccupation N c root q) :=
  Finset.measurable_sum _ fun x _ => (localTime_joint_measurable N root x).const_mul _

def lowHarmonicLoopWindowMass (N : Size) (c root : Vertex N) (q a l r : ℝ) : ℝ≥0∞ :=
  ∫⁻ ω, ∫⁻ t in Ioi (0 : ℝ), if walk N root ω t = root ∧ t ∈ Icc l r ∧
    Real.sqrt (harmonicPathOccupation N c root q (ω,t)) ≤ a then 1 else 0 ∂volume ∂walkLaw

theorem conditional_low_word_slice (N : Size) (c root : Vertex N) (I O : Finset (Vertex N))
    (hIO : I ⊆ O) (hI : I.Nonempty) (hr : root ∉ O) (q : ℝ)
    (hU : ∀ x, x ∉ I → diskHarmonicWeight N c (Real.exp (q+1)) x/g = 0)
    (m : ℕ) (w : Fin (2*m) → Vertex N) (v Δ l r : ℝ) :
    conditionalTraversalSlice N I O root m w
      (lowOutwardRecordTest m (r7WordHighOccupation N c root m w q v Δ)) l r =
      ∫⁻ ω, (∫⁻ t in Ioi (adaptiveExitTime N (alternatingDomain N I O) root (2*m) ω),
        if t < adaptiveExitTime N (alternatingDomain N I O) root (2*m+1) ω ∧ walk N root ω t = root then
          (if t ∈ Icc l r ∧ Real.sqrt (harmonicPathOccupation N c root q (ω,t)) ≤ v+Δ then 1 else 0) else 0)
        ∂walkLaw[|{ω | adaptiveExitWord N (alternatingDomain N I O) root (2*m) ω = w}] := by
  apply lintegral_congr_ae
  have hc := (cond_absolutelyContinuous (μ := walkLaw)
    (s := {ω | adaptiveExitWord N (alternatingDomain N I O) root (2*m) ω = w})).ae_le
      (completedTraversalCount_loop_iff_ae N I O hIO hI root hr)
  have hl := (cond_absolutelyContinuous (μ := walkLaw)
    (s := {ω | adaptiveExitWord N (alternatingDomain N I O) root (2*m) ω = w})).ae_le
      (traversalOccupation_loop_localTime_ae N I O hIO hI root hr _ hU)
  filter_upwards [hc,hl,ae_cond_mem (μ := walkLaw)
    ((adaptiveExitWord_measurable N (alternatingDomain N I O) root (2*m)) (measurableSet_singleton w))]
    with ω hc hl hw
  apply lintegral_congr_ae
  filter_upwards [ae_restrict_mem (measurableSet_Ioi
    (a := adaptiveExitTime N (alternatingDomain N I O) root (2*m) ω))] with t ht
  by_cases hb : t < adaptiveExitTime N (alternatingDomain N I O) root (2*m+1) ω ∧
      walk N root ω t = root ∧ t ∈ Icc l r
  · have ht0 : 0 ≤ t := (jumpTime_nonneg ω _).trans ht.le
    have hcount := (hc t ht0 hb.2.1 m).mpr ⟨ht.le,hb.1⟩
    have he := hl t ht0 hb.2.1
    rw [hcount] at he
    have hword := traversalWordOutwardOccupation_of_word N I O root m w
      (fun x => diskHarmonicWeight N c (Real.exp (q+1)) x/g) ω hw
    have hcost : traversalWordOutwardOccupation N root m w
        (fun x => diskHarmonicWeight N c (Real.exp (q+1)) x/g)
        (fun j => adaptiveExitRecord N (alternatingDomain N I O) root j.val.val ω) =
          harmonicPathOccupation N c root q (ω,t) := hword.trans he.symm
    simp only [if_pos hb,lowOutwardRecordTest,r7WordHighOccupation,Set.mem_ofPred_eq,hcost,not_lt]
    simp [hb.1,hb.2.1,hb.2.2]
  · simp only [if_neg hb]
    split_ifs <;> simp_all

theorem lowWordWindowSum_eq_counted_harmonic (N : Size) (c root : Vertex N)
    (I O : Finset (Vertex N)) (hIO : I ⊆ O) (hI : I.Nonempty) (hr : root ∉ O)
    (M : ℕ) (q v Δ l r : ℝ)
    (hU : ∀ x, x ∉ I → diskHarmonicWeight N c (Real.exp (q+1)) x/g = 0) :
    lowWordWindowSum N c root I O M q v Δ l r =
      ∫⁻ ω, ∫⁻ t in Ioi (0 : ℝ), if completedTraversalCount N I O root ω t ≤ M ∧
        walk N root ω t = root then
          (if t ∈ Icc l r ∧ Real.sqrt (harmonicPathOccupation N c root q (ω,t)) ≤ v+Δ then 1 else 0)
          else 0 ∂volume ∂walkLaw := by
  let F := fun z : WalkSample × ℝ => if z.2 ∈ Icc l r ∧
    Real.sqrt (harmonicPathOccupation N c root q z) ≤ v+Δ then (1 : ℝ≥0∞) else 0
  have hF : Measurable F := measurable_const.ite
    ((measurable_snd measurableSet_Icc).inter
      (measurableSet_le (harmonicPathOccupation_measurable N c root q).sqrt measurable_const)) measurable_const
  rw [loop_count_window_partition N I O hIO hI root hr M F hF]
  unfold lowWordWindowSum
  apply Finset.sum_congr rfl
  intro m _
  rw [adaptiveExitWord_conditional_partition N (alternatingDomain N I O) root (2*m)]
  apply Finset.sum_congr rfl
  intro w _
  congr 1
  exact conditional_low_word_slice N c root I O hIO hI hr q hU m w v Δ l r

theorem lowWordWindowSum_le_harmonic (N : Size) (c root : Vertex N)
    (I O : Finset (Vertex N)) (hIO : I ⊆ O) (hI : I.Nonempty) (hr : root ∉ O)
    (M : ℕ) (q v Δ l r : ℝ)
    (hU : ∀ x, x ∉ I → diskHarmonicWeight N c (Real.exp (q+1)) x/g = 0) :
    lowWordWindowSum N c root I O M q v Δ l r ≤ lowHarmonicLoopWindowMass N c root q (v+Δ) l r := by
  rw [lowWordWindowSum_eq_counted_harmonic N c root I O hIO hI hr M q v Δ l r hU]
  apply lintegral_mono
  intro ω
  apply lintegral_mono
  intro t
  dsimp only
  split_ifs <;> simp_all

end TorusCoverTime.Blocks.B
