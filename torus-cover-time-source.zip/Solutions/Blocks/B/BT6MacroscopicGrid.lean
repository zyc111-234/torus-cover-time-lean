import Solutions.Blocks.B.BT6GridChoice
import Solutions.Blocks.B.DirichletMacroscopicClock
import Solutions.Blocks.B.FixedCapacity

noncomputable section
open Filter
namespace TorusCoverTime.Blocks.B

theorem bt6_exists_step (ρ : ℝ) (hρ : 0<ρ) :
    ∃ K : ℕ, 0<K ∧ 4*bt6ClockError ρ+2≤(K:ℝ) ∧ Real.exp (1-(K:ℝ))≤ρ/8 := by
  obtain ⟨K,hK⟩ := exists_nat_gt (max (4*bt6ClockError ρ+2) (1-Real.log (ρ/8)))
  have hs : 4*bt6ClockError ρ+2<(K:ℝ) := (le_max_left _ _).trans_lt hK
  have hl : 1-Real.log (ρ/8)<(K:ℝ) := (le_max_right _ _).trans_lt hK
  refine ⟨K,?_,hs.le,?_⟩
  · exact_mod_cast (show (0:ℝ)<K by linarith [bt6ClockError_pos ρ])
  · calc
      _ ≤ Real.exp (Real.log (ρ/8)) := Real.exp_le_exp.mpr (by linarith)
      _ = _ := Real.exp_log (by positivity)

theorem bt6_macroscopic_geometry (ρ : ℝ) (K : ℕ) (hρ : 0<ρ) (hρhi : ρ<1/4)
    (hstep : Real.exp (1-(K:ℝ))≤ρ/8) :
    ∀ᶠ N : Size in atTop,
      1≤ρ*(N.val:ℝ) ∧ 2*(ρ*(N.val:ℝ)+1)<N.val ∧
      ∀ M : ℕ, (M:ℝ)+1≤logSize N-K+1 →
        ∀ c x : Vertex N, periodicDistance x c≤ρ*(N.val:ℝ)/4 →
          periodicDistance x c+(Real.exp ((M:ℝ)+1)+1)≤ρ*(N.val:ℝ)/2 := by
  have ht : Tendsto (fun N : Size => (N.val:ℝ)) atTop atTop :=
    tendsto_natCast_atTop_atTop.comp blockB_size_nat_tendsto
  filter_upwards [ht.eventually_ge_atTop (8/ρ),ht.eventually_gt_atTop 4] with N hN hN4
  have hn0 : (0:ℝ)<N.val := by linarith
  have hR8 : 8≤ρ*(N.val:ℝ) := by have := (div_le_iff₀ hρ).mp hN; nlinarith
  refine ⟨by linarith,?_,?_⟩
  · have hh := mul_lt_mul_of_pos_right hρhi hn0
    nlinarith
  · intro M hM c x hx
    have he : Real.exp ((M:ℝ)+1)≤(N.val:ℝ)*(ρ/8) := by
      calc
        _ ≤ Real.exp (logSize N+(1-(K:ℝ))) := Real.exp_le_exp.mpr (by linarith)
        _ = (N.val:ℝ)*Real.exp (1-(K:ℝ)) := by rw [Real.exp_add]; unfold logSize; rw [Real.exp_log hn0]
        _ ≤ _ := mul_le_mul_of_nonneg_left hstep hn0.le
    linarith

end TorusCoverTime.Blocks.B
