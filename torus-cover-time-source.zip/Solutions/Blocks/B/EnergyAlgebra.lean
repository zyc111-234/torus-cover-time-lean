import Solutions.Blocks.B.DirichletEnergy

/-! Bilinear and mean identities used by the capacity and killed variational problems. -/

noncomputable section
open scoped BigOperators
namespace TorusCoverTime.Blocks.B

lemma generator_add (N : Size) (f g : Vertex N → ℝ) (x : Vertex N) :
    generator N (f + g) x = generator N f x + generator N g x := by
  simp only [generator, Pi.add_apply]
  simp_rw [show ∀ a b c d : ℝ, (a + b) - (c + d) = (a - c) + (b - d) by intros; ring]
  rw [Finset.sum_add_distrib, mul_add]

lemma generator_sub (N : Size) (f g : Vertex N → ℝ) (x : Vertex N) :
    generator N (f - g) x = generator N f x - generator N g x := by
  simp only [generator, Pi.sub_apply]
  simp_rw [show ∀ a b c d : ℝ, (a - b) - (c - d) = (a - c) - (b - d) by intros; ring]
  rw [Finset.sum_sub_distrib, mul_sub]

lemma dirichletPairing_add_left (N : Size) (f g h : Vertex N → ℝ) :
    dirichletPairing N (f + g) h = dirichletPairing N f h + dirichletPairing N g h := by
  simp only [dirichletPairing, Pi.add_apply, add_mul, Finset.sum_add_distrib]

lemma dirichletPairing_sub_left (N : Size) (f g h : Vertex N → ℝ) :
    dirichletPairing N (f - g) h = dirichletPairing N f h - dirichletPairing N g h := by
  simp only [dirichletPairing, Pi.sub_apply, sub_mul, Finset.sum_sub_distrib]

lemma dirichletPairing_add_right (N : Size) (f g h : Vertex N → ℝ) :
    dirichletPairing N f (g + h) = dirichletPairing N f g + dirichletPairing N f h := by
  rw [dirichletPairing_symm, dirichletPairing_add_left]
  rw [dirichletPairing_symm N g f, dirichletPairing_symm N h f]

lemma dirichletPairing_sub_right (N : Size) (f g h : Vertex N → ℝ) :
    dirichletPairing N f (g - h) = dirichletPairing N f g - dirichletPairing N f h := by
  rw [dirichletPairing_symm, dirichletPairing_sub_left]
  rw [dirichletPairing_symm N g f, dirichletPairing_symm N h f]

lemma dirichletPairing_smul_left (N : Size) (c : ℝ) (f g : Vertex N → ℝ) :
    dirichletPairing N (c • f) g = c * dirichletPairing N f g := by
  simp only [dirichletPairing, Pi.smul_apply, smul_eq_mul, mul_assoc, Finset.mul_sum]

lemma energy_sub (N : Size) (f g : Vertex N → ℝ) :
    energy N (f - g) = energy N f + energy N g - 2 * dirichletPairing N f g := by
  change dirichletPairing N (f - g) (f - g) = _
  rw [dirichletPairing_sub_left, dirichletPairing_sub_right, dirichletPairing_sub_right,
    dirichletPairing_symm N g f]
  change energy N f - dirichletPairing N f g - (dirichletPairing N f g - energy N g) = _
  ring

lemma dirichletPairing_smul_right (N : Size) (c : ℝ) (f g : Vertex N → ℝ) :
    dirichletPairing N f (c • g) = c * dirichletPairing N f g := by
  rw [dirichletPairing_symm, dirichletPairing_smul_left, dirichletPairing_symm]

lemma energy_add (N : Size) (f g : Vertex N → ℝ) :
    energy N (f + g) = energy N f + energy N g + 2 * dirichletPairing N f g := by
  change dirichletPairing N (f + g) (f + g) = _
  rw [dirichletPairing_add_left, dirichletPairing_add_right, dirichletPairing_add_right,
    dirichletPairing_symm N g f]
  change energy N f + dirichletPairing N f g + (dirichletPairing N f g + energy N g) = _
  ring

lemma energy_smul (N : Size) (c : ℝ) (f : Vertex N → ℝ) :
    energy N (c • f) = c ^ 2 * energy N f := by
  simp only [energy_edges, Pi.smul_apply, smul_eq_mul, ← mul_sub, mul_pow, ← Finset.mul_sum]
  ring

lemma energy_const_sub (N : Size) (c : ℝ) (f : Vertex N → ℝ) :
    energy N ((fun _ => c) - f) = energy N f := by
  simp only [energy_edges, Pi.sub_apply]
  have h (a b : ℝ) : ((c - a) - (c - b)) ^ 2 = (a - b) ^ 2 := by ring
  simp only [h]

lemma spatialMean_add (N : Size) (f g : Vertex N → ℝ) :
    spatialMean N (f + g) = spatialMean N f + spatialMean N g := by
  simp only [spatialMean, Pi.add_apply, Finset.sum_add_distrib, add_div]

lemma spatialMean_sub (N : Size) (f g : Vertex N → ℝ) :
    spatialMean N (f - g) = spatialMean N f - spatialMean N g := by
  simp only [spatialMean, Pi.sub_apply, Finset.sum_sub_distrib, sub_div]

lemma spatialMean_smul (N : Size) (c : ℝ) (f : Vertex N → ℝ) :
    spatialMean N (c • f) = c * spatialMean N f := by
  simp only [spatialMean, Pi.smul_apply, smul_eq_mul, ← Finset.mul_sum, mul_div_assoc]

end TorusCoverTime.Blocks.B
