import Solutions.Blocks.B.DiskReciprocal
import Solutions.Blocks.B.DiskGreenLogarithm
import Solutions.Blocks.B.GreenResolvent

/-! Radius-squared bounds for Green square sums and convolutions. The
logarithmic singularity is summed, rather than bounded by its diagonal value. -/

noncomputable section
open Classical
namespace TorusCoverTime.Blocks.B

theorem log_sq_le_four_mul (t : ℝ) (ht : 1 ≤ t) : (Real.log t)^2 ≤ 4*t := by
  have ht0 : 0 ≤ t := by linarith
  have hs := Real.log_le_self (Real.sqrt_nonneg t)
  rw [Real.log_sqrt ht0] at hs
  have hsq := Real.sq_sqrt ht0
  have hlog := Real.log_nonneg ht
  have hm := mul_nonneg (show 0 ≤ 2*Real.sqrt t - Real.log t by linarith)
    (show 0 ≤ 2*Real.sqrt t + Real.log t by positivity)
  nlinarith

theorem diskGreen_nonneg (N : Size) (c : Vertex N) (R : ℝ) (hR : 0 ≤ R)
    (hsmall : 2*(R+1) < N.val) (x y : Vertex N) : 0 ≤ diskGreen N c R x y :=
  domainGreenFromBarrier_nonneg_all N _ _ (fun z hz => diskBarrier_generator N c R hR hsmall z hz) x y

def diskGreenSquareConstant : ℝ := 8*g^2 + 2*diskGreenLogErrorConstant^2

theorem diskGreenSquareConstant_pos : 0 < diskGreenSquareConstant := by
  have := diskGreenLogErrorConstant_pos
  unfold diskGreenSquareConstant
  positivity

theorem diskGreen_uniform_log_upper (N : Size) (c : Vertex N) (R : ℝ) (hR : 1 ≤ R)
    (hsmall : 2*(R+1) < N.val) (z x : Vertex N) (hz : z ∈ torusDisk N c R)
    (hx : periodicDistance x c ≤ R/2) :
    diskGreen N c R z x ≤ g * Real.log (2*R / max 1 (periodicDistance z x)) +
      diskGreenLogErrorConstant := by
  have hR0 : 0 < R := by linarith
  have hg0 : 0 ≤ g := by unfold g; positivity
  by_cases hzx : z = x
  · subst z
    rw [periodicDistance_self_zero, max_eq_left (by norm_num : (0:ℝ) ≤ 1), div_one]
    have hd := (abs_le.mp (diskGreen_diagonal_precise N c R hR hsmall x hx)).2
    have hl := mul_le_mul_of_nonneg_left (Real.log_le_log hR0 (show R ≤ 2*R by linarith)) hg0
    linarith
  · have hd : 1 ≤ periodicDistance z x := by
      have h := periodicDistance_nonzero_ge_one N (z-x) (sub_ne_zero.mpr hzx)
      rwa [periodicDistance_sub_zero] at h
    rw [max_eq_right hd]
    have he := (abs_le.mp (diskGreen_offdiagonal_log_error N c R hR hsmall z x hz hx hzx)).2
    have hd0 : 0 < periodicDistance z x := by linarith
    have hl := Real.log_le_log (div_pos hR0 hd0)
      (div_le_div_of_nonneg_right (show R ≤ 2*R by linarith) hd0.le)
    have hm := mul_le_mul_of_nonneg_left hl hg0
    linarith

theorem diskGreen_square_point_bound (N : Size) (c : Vertex N) (R : ℝ) (hR : 1 ≤ R)
    (hsmall : 2*(R+1) < N.val) (z x : Vertex N) (hz : z ∈ torusDisk N c R)
    (hx : periodicDistance x c ≤ R/2) :
    diskGreen N c R z x ^ 2 ≤ diskGreenSquareConstant *
      (2*R / max 1 (periodicDistance z x)) := by
  let t := 2*R/max 1 (periodicDistance z x)
  have hd : 0 < max 1 (periodicDistance z x) := lt_of_lt_of_le zero_lt_one (le_max_left _ _)
  have hdist := periodicDistance_triangle N z c x
  rw [periodicDistance_comm c x] at hdist
  have hzr := (mem_torusDisk N c z R).mp hz
  have ht : 1 ≤ t := by
    apply (le_div_iff₀ hd).mpr
    simp only [one_mul]
    exact max_le (by linarith) (by linarith)
  have hlog0 := Real.log_nonneg ht
  have hlog := log_sq_le_four_mul t ht
  have he := diskGreen_uniform_log_upper N c R hR hsmall z x hz hx
  have hg := diskGreen_nonneg N c R (by linarith) hsmall z x
  have hC := diskGreenLogErrorConstant_pos
  have hsq : diskGreen N c R z x ^ 2 ≤ (g*Real.log t + diskGreenLogErrorConstant)^2 := by
    apply pow_le_pow_left₀ hg he
  have htwo : (g*Real.log t + diskGreenLogErrorConstant)^2 ≤
      2*g^2*(Real.log t)^2 + 2*diskGreenLogErrorConstant^2 := by
    nlinarith [sq_nonneg (g*Real.log t - diskGreenLogErrorConstant)]
  have hlogmul := mul_le_mul_of_nonneg_left hlog (show 0 ≤ 2*g^2 by positivity)
  have hCmul := mul_le_mul_of_nonneg_left ht (show 0 ≤ 2*diskGreenLogErrorConstant^2 by positivity)
  change _ ≤ diskGreenSquareConstant*t
  unfold diskGreenSquareConstant
  nlinarith

def diskGreenConvolutionConstant : ℝ := 68*diskGreenSquareConstant

theorem diskGreenConvolutionConstant_pos : 0 < diskGreenConvolutionConstant := by
  unfold diskGreenConvolutionConstant
  exact mul_pos (by norm_num) diskGreenSquareConstant_pos

theorem diskGreen_column_square_sum (N : Size) (c : Vertex N) (R : ℝ) (hR : 1 ≤ R)
    (hsmall : 4*(R+1) < N.val) (x : Vertex N) (hx : periodicDistance x c ≤ R/2) :
    (∑ z, diskGreen N c R z x ^ 2) ≤ diskGreenConvolutionConstant * R^2 := by
  have hs : 2*(R+1) < N.val := by linarith
  have he : (∑ z, diskGreen N c R z x ^ 2) = ∑ z ∈ torusDisk N c R, diskGreen N c R z x ^ 2 := by
    symm
    apply Finset.sum_subset (Finset.subset_univ _)
    intro z _ hz
    have h := domainGreenFromBarrier_boundary N (torusDisk N c R) (diskBarrier N c R) z x hz
    change diskGreen N c R z x = 0 at h
    rw [h, zero_pow (by decide : 2 ≠ 0)]
  have hsub : torusDisk N c R ⊆ torusDisk N x (2*R) := by
    intro z hz
    have ht := periodicDistance_triangle N z c x
    rw [periodicDistance_comm c x] at ht
    have hzR := (mem_torusDisk N c z R).mp hz
    exact (mem_torusDisk N x z (2*R)).mpr (by linarith)
  have hr := disk_reciprocal_sum N x (2*R) (by linarith) (by linarith)
  rw [he]
  calc
    _ ≤ ∑ z ∈ torusDisk N c R, diskGreenSquareConstant*(2*R/max 1 (periodicDistance z x)) :=
      Finset.sum_le_sum fun z hz => diskGreen_square_point_bound N c R hR hs z x hz hx
    _ = (diskGreenSquareConstant*(2*R)) *
        ∑ z ∈ torusDisk N c R, 1/max 1 (periodicDistance z x) := by
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro z _
      ring
    _ ≤ (diskGreenSquareConstant*(2*R)) *
        ∑ z ∈ torusDisk N x (2*R), 1/max 1 (periodicDistance z x) := by
      apply mul_le_mul_of_nonneg_left _ (by have := diskGreenSquareConstant_pos; positivity)
      exact Finset.sum_le_sum_of_subset_of_nonneg hsub (fun z _ _ => by positivity)
    _ ≤ (diskGreenSquareConstant*(2*R)) * (17*(2*R)) :=
      mul_le_mul_of_nonneg_left hr (by have := diskGreenSquareConstant_pos; positivity)
    _ = _ := by unfold diskGreenConvolutionConstant; ring

theorem diskGreen_convolution_bound (N : Size) (c : Vertex N) (R : ℝ) (hR : 1 ≤ R)
    (hsmall : 4*(R+1) < N.val) (x y : Vertex N)
    (hx : periodicDistance x c ≤ R/2) (hy : periodicDistance y c ≤ R/2) :
    (∑ z, diskGreen N c R x z * diskGreen N c R z y) ≤ diskGreenConvolutionConstant*R^2 := by
  have hxsum := diskGreen_column_square_sum N c R hR hsmall x hx
  have hysum := diskGreen_column_square_sum N c R hR hsmall y hy
  have hs : 2*(R+1) < N.val := by linarith
  have he : ∀ z, diskGreen N c R x z = diskGreen N c R z x :=
    diskGreen_symm N c R (by linarith) hs x
  simp only [he]
  have ht : 2*(∑ z, diskGreen N c R z x * diskGreen N c R z y) ≤
      (∑ z, diskGreen N c R z x ^ 2) + (∑ z, diskGreen N c R z y ^ 2) := by
    rw [Finset.mul_sum, ← Finset.sum_add_distrib]
    apply Finset.sum_le_sum
    intro z _
    nlinarith [sq_nonneg (diskGreen N c R z x - diskGreen N c R z y)]
  linarith

end TorusCoverTime.Blocks.B
