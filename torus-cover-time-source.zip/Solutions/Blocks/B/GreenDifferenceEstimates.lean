import Solutions.Blocks.B.GreenArbitraryDifferences
import Definitions.Quantitative

/-! The complete registered Green difference interface, with the original hypotheses retained. -/

noncomputable section
namespace TorusCoverTime.Blocks.B

theorem green_difference_estimates (_hFourier : FourierWalkIdentities) (_hGreen : GreenEstimates) :
    GreenDifferenceEstimates := by
  obtain ⟨C, hC, hNear⟩ := green_nearest_differences
  have hCsmall : C ≤ 16 * C + 1 := by linarith
  have hClarge : 16 * C ≤ 16 * C + 1 := by linarith
  refine ⟨16 * C + 1, by positivity, fun N => ⟨?_, ?_, ?_⟩⟩
  · intro z hz d d'
    have hd : 0 < periodicDistance z 0 := by linarith
    exact ⟨((hNear N z hd d d').1).trans (div_le_div_of_nonneg_right hCsmall hd.le),
      ((hNear N z hd d d').2).trans (div_le_div_of_nonneg_right hCsmall (by positivity))⟩
  · intro D hD x x' y y' hx hy _ _ hsep _
    have h := green_arbitrary_differences_of_nearest C hC hNear N D hD x x' y y' hx hy hsep
    have hdx : 0 ≤ periodicDistance x x' := Real.sqrt_nonneg _
    have hdy : 0 ≤ periodicDistance y y' := Real.sqrt_nonneg _
    exact ⟨h.1.trans (div_le_div_of_nonneg_right (mul_le_mul_of_nonneg_right hClarge hdx) hD.le),
      h.2.trans (div_le_div_of_nonneg_right
        (mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right hClarge hdx) hdy) (by positivity))⟩
  · exact (green_spectral_square_sum N).trans (by linarith)

end TorusCoverTime.Blocks.B
