import Solutions.Blocks.B.GaussianProbeMass
import Solutions.Blocks.B.GreenBounds

/-! Narrow-slab estimates for the actual pinned field phi(z)-phi(root).
The full source energy and each local quadratic form are controlled on the
same slab; the covariance is the proved torus Green kernel. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal NNReal
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

def pinnedCoordinateVariance (N : Size) (root x : Vertex N) : ℝ :=
  2*(greenDiagonal N-greenKernel N x root)

theorem pinned_coordinate_pair_gaussian (N : Size) (root x y : Vertex N) :
    HasGaussianLaw (fun ξ => (D.pinnedField N root ξ x,D.pinnedField N root ξ y)) (finiteFieldLaw N) := by
  let f := D.finiteFieldEvaluation N x-D.finiteFieldEvaluation N root
  let g := D.finiteFieldEvaluation N y-D.finiteFieldEvaluation N root
  simpa [f,g,D.pinnedField,D.finiteFieldEvaluation_apply] using
    (D.finiteFieldSample_gaussian N).map_fun (f.prod g)

theorem pinned_coordinate_measurable (N : Size) (root x : Vertex N) :
    Measurable (fun ξ => D.pinnedField N root ξ x) := by
  unfold D.pinnedField finiteGaussianField
  fun_prop

theorem pinned_coordinate_variance (N : Size) (root x : Vertex N) :
    Var[fun ξ => D.pinnedField N root ξ x;finiteFieldLaw N] = pinnedCoordinateVariance N root x := by
  rw [variance_eq_integral (pinned_coordinate_measurable N root x).aemeasurable,D.pinnedField_mean]
  simp only [sub_zero,pow_two,D.pinnedField_covariance,greenKernel_diagonal,
    greenKernel_symm N root,pinnedCoordinateVariance]
  ring

theorem pinned_coordinate_variance_nonneg (N : Size) (root x : Vertex N) :
    0 ≤ pinnedCoordinateVariance N root x := by
  rw [← pinned_coordinate_variance]
  exact variance_nonneg _ _

theorem pinned_coordinate_variance_le (N : Size) (root x : Vertex N) :
    pinnedCoordinateVariance N root x ≤ 4*greenDiagonal N := by
  have hh := abs_le.mp (abs_greenKernel_le_diagonal N x root)
  unfold pinnedCoordinateVariance
  linarith

theorem pinned_increment_variance (N : Size) (root x y : Vertex N) :
    Var[fun ξ => D.pinnedField N root ξ y-D.pinnedField N root ξ x;finiteFieldLaw N] =
      2*(greenDiagonal N-greenKernel N y x) := by
  have he : (fun ξ => D.pinnedField N root ξ y-D.pinnedField N root ξ x) =
      fun ξ => D.pinnedField N x ξ y := by funext ξ; unfold D.pinnedField; ring
  rw [he,pinned_coordinate_variance]
  rfl

theorem pinned_coordinate_variance_sum (N : Size) (root : Vertex N) :
    (∑ x, pinnedCoordinateVariance N root x) = 2*vertexCount N*greenDiagonal N := by
  simp only [pinnedCoordinateVariance,← Finset.mul_sum,Finset.sum_sub_distrib,
    Finset.sum_const,Finset.card_univ,nsmul_eq_mul,← D.vertexCount_eq_card,greenKernel_sum_left]
  ring

def pinnedSlab (N : Size) (root x : Vertex N) : Set (FiniteFieldSample N) :=
  {ξ | |D.pinnedField N root ξ x| ≤ 1}

theorem pinnedSlab_measurable (N : Size) (root x : Vertex N) : MeasurableSet (pinnedSlab N root x) :=
  measurableSet_le (pinned_coordinate_measurable N root x).abs measurable_const

theorem pinned_slab_square_integral (N : Size) (root x y : Vertex N)
    (hV : 0 < pinnedCoordinateVariance N root x) :
    (∫ ξ in pinnedSlab N root x, D.pinnedField N root ξ y^2 ∂finiteFieldLaw N) ≤
      (4*greenIncrementConstant*Real.log (2+periodicDistance y x)+
        8*greenDiagonal N/pinnedCoordinateVariance N root x)*(finiteFieldLaw N).real (pinnedSlab N root x) := by
  have hh := gaussian_slab_square_increment_bound (finiteFieldLaw N) _ _
    (pinned_coordinate_measurable N root x) (pinned_coordinate_measurable N root y)
    (pinned_coordinate_pair_gaussian N root x y) (by rwa [pinned_coordinate_variance])
    (D.pinnedField_mean N root x) (D.pinnedField_mean N root y)
  rw [pinned_increment_variance,pinned_coordinate_variance,pinned_coordinate_variance] at hh
  have hinc := green_increment_log_bound N y x
  rw [greenKernel_diagonal] at hinc
  have hvy := div_le_div_of_nonneg_right (pinned_coordinate_variance_le N root y) hV.le
  apply hh.trans
  apply mul_le_mul_of_nonneg_right _ measureReal_nonneg
  calc
    _ ≤ 4*greenIncrementConstant*Real.log (2+periodicDistance y x)+
        2*(4*greenDiagonal N/pinnedCoordinateVariance N root x) := by nlinarith
    _ = _ := by ring

theorem pinned_slab_energy_integral (N : Size) (root x : Vertex N)
    (hV : 1 ≤ pinnedCoordinateVariance N root x) :
    (∫ ξ in pinnedSlab N root x, D.pinnedEnergy N root ξ ∂finiteFieldLaw N) ≤
      8*vertexCount N*greenDiagonal N*(finiteFieldLaw N).real (pinnedSlab N root x) := by
  unfold pinnedSlab
  have hVp : 0 < pinnedCoordinateVariance N root x := by linarith
  have hh (y : Vertex N) := gaussian_slab_square_global_bound (finiteFieldLaw N) _ _
    (pinned_coordinate_measurable N root x) (pinned_coordinate_measurable N root y)
    (pinned_coordinate_pair_gaussian N root x y) (by rwa [pinned_coordinate_variance])
    (D.pinnedField_mean N root x) (D.pinnedField_mean N root y)
  have hi (y : Vertex N) : Integrable (fun ξ => D.pinnedField N root ξ y^2) (finiteFieldLaw N) := by
    have hh := (D.pinnedField_memLp N root y).integrable_mul (D.pinnedField_memLp N root y)
    change Integrable (fun ξ => D.pinnedField N root ξ y*D.pinnedField N root ξ y) (finiteFieldLaw N) at hh
    simpa only [pow_two] using hh
  unfold D.pinnedEnergy
  rw [integral_finsetSum _ (fun y _ => (hi y).integrableOn)]
  have hsum := Finset.sum_le_sum (s := Finset.univ) (fun y _ => hh y)
  simp_rw [pinned_coordinate_variance] at hsum
  rw [← Finset.sum_mul,← Finset.mul_sum,pinned_coordinate_variance_sum] at hsum
  apply hsum.trans
  have hcoef : 2+2/pinnedCoordinateVariance N root x ≤ 4 := by
    have h := (div_le_iff₀ hVp).mpr (show (2:ℝ) ≤ 2*pinnedCoordinateVariance N root x by linarith)
    linarith
  have hn := vertexCount_pos N
  have hg := greenDiagonal_pos N
  calc
    _ ≤ 4*(2*vertexCount N*greenDiagonal N)*(finiteFieldLaw N).real {ξ | |D.pinnedField N root ξ x| ≤ 1} :=
      mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right hcoef (by positivity)) measureReal_nonneg
    _ = _ := by ring

theorem pinned_slab_mass (N : Size) (root x : Vertex N) (hV : 1 ≤ pinnedCoordinateVariance N root x) :
    2*Real.exp (-(1:ℝ)/2)/Real.sqrt (2*Real.pi*pinnedCoordinateVariance N root x) ≤
      (finiteFieldLaw N).real (pinnedSlab N root x) := by
  simpa only [pinned_coordinate_variance,pinnedSlab] using gaussian_variable_unit_slab_mass (finiteFieldLaw N)
    (fun ξ => D.pinnedField N root ξ x) (pinned_coordinate_measurable N root x)
    (pinned_coordinate_pair_gaussian N root x x).fst (D.pinnedField_mean N root x)
    (by rwa [pinned_coordinate_variance])

end TorusCoverTime.Blocks.B
