import Solutions.Blocks.B.LatticeLogGenerator
import Solutions.Blocks.B.LogBoundaryFlux

/-! Exact telescoping of the actual lattice generator over a centered
square, followed by its quantitative flux normalization. -/

noncomputable section
open Classical
namespace TorusCoverTime.Blocks.B

theorem centered_even_sum (f : ℤ → ℝ) (hf : ∀ k, f (-k) = f k) (n : ℕ) :
    (∑ i ∈ Finset.range (2*n+1), f ((i:ℤ)-n)) =
      2*(∑ i ∈ Finset.range (n+1), f i)-f 0 := by
  have hneg : (∑ i ∈ Finset.range n, f ((i:ℤ)-n)) = ∑ i ∈ Finset.range n, f ((i:ℤ)+1) := by
    calc
      _ = ∑ i ∈ Finset.range n, f (((n-1-i:ℕ):ℤ)+1) := by
        apply Finset.sum_congr rfl
        intro i hi
        have hi' := Finset.mem_range.mp hi
        rw [show (i:ℤ)-n = -(((n-1-i:ℕ):ℤ)+1) by omega, hf]
      _ = _ := Finset.sum_range_reflect (fun i : ℕ => f ((i:ℤ)+1)) n
  rw [show 2*n+1 = n+(n+1) by omega, Finset.sum_range_add, hneg]
  have htail : (∑ i ∈ Finset.range (n+1), f (((n+i:ℕ):ℤ)-n)) =
      ∑ i ∈ Finset.range (n+1), f i := by
    apply Finset.sum_congr rfl
    intro i _
    congr 1
    omega
  rw [htail]
  have hs := Finset.sum_range_succ' (fun i : ℕ => f (i:ℤ)) n
  push_cast at hs
  linarith

theorem centered_second_difference_sum (f : ℤ → ℝ) (n : ℕ) :
    (∑ i ∈ Finset.range (2*n+1), (f ((i:ℤ)-n+1)+f ((i:ℤ)-n-1)-2*f ((i:ℤ)-n))) =
      f ((n:ℤ)+1)-f (-(n:ℤ))+f (-(n:ℤ)-1)-f n := by
  have hp := Finset.sum_range_sub (fun i : ℕ => f ((i:ℤ)-n)) (2*n+1)
  have hm := Finset.sum_range_sub (fun i : ℕ => f ((i:ℤ)-n-1)) (2*n+1)
  push_cast at hp hm
  have hep : (2*(n:ℤ)+1)-(n:ℤ) = (n:ℤ)+1 := by ring
  have hem (i : ℕ) : (i:ℤ)+1-(n:ℤ)-1 = (i:ℤ)-(n:ℤ) := by ring
  simp only [hep, hem, zero_sub, add_sub_cancel_right] at hp hm
  have he : (∑ i ∈ Finset.range (2*n+1), (f ((i:ℤ)-n+1)+f ((i:ℤ)-n-1)-2*f ((i:ℤ)-n))) =
      (∑ i ∈ Finset.range (2*n+1), (f ((i:ℤ)+1-n)-f ((i:ℤ)-n)))-
      ∑ i ∈ Finset.range (2*n+1), (f ((i:ℤ)-n)-f ((i:ℤ)-n-1)) := by
    rw [← Finset.sum_sub_distrib]
    apply Finset.sum_congr rfl
    intro i _
    rw [show (i:ℤ)-n+1 = (i:ℤ)+1-n by ring]
    ring
  rw [he,hp,hm]
  ring

theorem latticeLogPotential_neg_first (x y : ℤ) : latticeLogPotential (-x,y) = latticeLogPotential (x,y) := by
  simp [latticeLogPotential, latticeRadius]

theorem latticeLogPotential_swap (x y : ℤ) : latticeLogPotential (x,y) = latticeLogPotential (y,x) := by
  simp only [latticeLogPotential, latticeRadius]
  rw [add_comm]

theorem latticeLogPotential_formula (x y : ℤ) :
    latticeLogPotential (x,y) = Real.log ((x:ℝ)^2+(y:ℝ)^2)/2 := Real.log_sqrt (by positivity)

theorem lattice_log_row_flux (n : ℕ) (y : ℤ) :
    (∑ i ∈ Finset.range (2*n+1),
      (latticeLogPotential ((i:ℤ)-n+1,y)+latticeLogPotential ((i:ℤ)-n-1,y)-
        2*latticeLogPotential ((i:ℤ)-n,y))) = 2*logBoundaryDifference n y := by
  rw [centered_second_difference_sum (fun x => latticeLogPotential (x,y)),
    show -(n:ℤ)-1 = -((n:ℤ)+1) by ring, latticeLogPotential_neg_first, latticeLogPotential_neg_first]
  simp only [latticeLogPotential_formula, logBoundaryDifference]
  push_cast
  ring

def latticeSquareLogMass (n : ℕ) : ℝ :=
  (1/4)*(∑ i ∈ Finset.range (2*n+1), ∑ j ∈ Finset.range (2*n+1),
    ∑ d : Fin 4, (latticeLogPotential (((i:ℤ)-n,(j:ℤ)-n)+latticeDirection d)-
      latticeLogPotential ((i:ℤ)-n,(j:ℤ)-n)))

theorem latticeSquareLogMass_flux (n : ℕ) : latticeSquareLogMass n = logSquareFlux n := by
  have hd (x y : ℤ) : (∑ d : Fin 4, (latticeLogPotential ((x,y)+latticeDirection d)-latticeLogPotential (x,y))) =
      (latticeLogPotential (x+1,y)+latticeLogPotential (x-1,y)-2*latticeLogPotential (x,y))+
      (latticeLogPotential (x,y+1)+latticeLogPotential (x,y-1)-2*latticeLogPotential (x,y)) := by
    simp [Fin.sum_univ_succ,latticeDirection]
    <;> ring
  have hcol (x : ℤ) : (∑ j ∈ Finset.range (2*n+1),
      (latticeLogPotential (x,(j:ℤ)-n+1)+latticeLogPotential (x,(j:ℤ)-n-1)-
        2*latticeLogPotential (x,(j:ℤ)-n))) = 2*logBoundaryDifference n x := by
    simp_rw [latticeLogPotential_swap x]
    exact lattice_log_row_flux n x
  have heven : ∀ k : ℤ, logBoundaryDifference n ((-k : ℤ) : ℝ) = logBoundaryDifference n k := by
    intro k
    rw [Int.cast_neg, logBoundaryDifference_even]
  have heq := centered_even_sum (fun k : ℤ => logBoundaryDifference n k) heven n
  unfold latticeSquareLogMass
  simp_rw [hd, Finset.sum_add_distrib]
  rw [Finset.sum_comm (f := fun (i j : ℕ) =>
    latticeLogPotential ((i:ℤ)-n+1,(j:ℤ)-n)+latticeLogPotential ((i:ℤ)-n-1,(j:ℤ)-n)-
      2*latticeLogPotential ((i:ℤ)-n,(j:ℤ)-n))]
  simp_rw [lattice_log_row_flux, hcol]
  simp only [← Finset.mul_sum, heq, Int.cast_natCast, Int.cast_zero]
  change (1/4)*(2*(2*(∑ i ∈ Finset.range (n+1), logBoundaryDifference n i)-logBoundaryDifference n 0)+
    2*(2*(∑ i ∈ Finset.range (n+1), logBoundaryDifference n i)-logBoundaryDifference n 0)) = _
  unfold logSquareFlux
  ring

theorem latticeSquareLogMass_error (n : ℕ) (hn : 0 < n) :
    |latticeSquareLogMass n-Real.pi/2| ≤ 32/(n:ℝ) := by
  rw [latticeSquareLogMass_flux]
  exact logSquareFlux_error n hn

theorem latticeSquareLogMass_normalized (n : ℕ) (hn : 0 < n) :
    |g*latticeSquareLogMass n-1| ≤ (32*g)/(n:ℝ) := by
  have hg : 0 < g := by unfold g; positivity
  have he : g*(Real.pi/2) = 1 := by unfold g; field_simp
  have h := mul_le_mul_of_nonneg_left (latticeSquareLogMass_error n hn) hg.le
  calc
    |g*latticeSquareLogMass n-1| = g*|latticeSquareLogMass n-Real.pi/2| := by
      rw [← he, ← mul_sub, abs_mul, abs_of_pos hg]
    _ ≤ g*(32/(n:ℝ)) := h
    _ = (32*g)/(n:ℝ) := by ring

end TorusCoverTime.Blocks.B
