import Solutions.Blocks.B.PointKillingEnergy

/-! The exact Phase A center gives the 3/2 logarithmic correction after
point killing and mixing. Constants are independent of the vertices and N. -/
noncomputable section
open Filter
open scoped Topology
namespace TorusCoverTime.Blocks.B

def pointSoftExponentConstant (H : ℝ) : ℝ :=
  H+4/g+2*(greenDiagonalErrorConstant+5/4)/g

theorem pointSoftExponentConstant_pos (H : ℝ) (hH : 0 ≤ H) : 0 < pointSoftExponentConstant H := by
  have hg : 0 < g := by unfold g; positivity
  have := greenDiagonalErrorConstant_pos
  unfold pointSoftExponentConstant
  positivity

theorem point_soft_phaseA_rate (N : Size) (H t : ℝ) (hH : 0 ≤ H)
    (hL : 1 ≤ logSize N) (hLK : 2*pointSoftExponentConstant H ≤ logSize N)
    (ht : phaseACenter N-H*timeScale N ≤ t) :
    mixingTime N ≤ t ∧
      2*logSize N-(3/2:ℝ)*Real.log (logSize N)-pointSoftExponentConstant H ≤
        pointKillingRate N*(t-mixingTime N) := by
  let L := logSize N
  let C := greenDiagonalErrorConstant+5/4
  let K := pointSoftExponentConstant H
  let n := vertexCount N
  have hg : 0 < g := by unfold g; positivity
  have hC : 0 < C := by dsimp only [C]; have := greenDiagonalErrorConstant_pos; linarith
  have hK : 0 < K := pointSoftExponentConstant_pos H hH
  have hn : 0 < n := vertexCount_pos N
  have hlog : 0 ≤ Real.log L := Real.log_nonneg hL
  have hlogL : Real.log L ≤ L := (Real.log_le_sub_one_of_pos (logSize_pos N)).trans (by linarith)
  have hA : 0 ≤ 2*L-(3/2:ℝ)*Real.log L-K := by change 2*K ≤ L at hLK; linarith
  have hk : g*K=g*H+4+2*C := by
    dsimp only [K,C,pointSoftExponentConstant]
    field_simp
  have hscalar : (g*L+C)*(2*L-(3/2:ℝ)*Real.log L-K) ≤
      g*L*(2*L-(3/2:ℝ)*Real.log L-H)-4*Real.log L := by
    have hnon : 0 ≤ 4*(L-Real.log L)+C*((3/2:ℝ)*Real.log L+K) := by positivity
    have hid : g*L*(2*L-(3/2:ℝ)*Real.log L-H)-4*Real.log L-
        (g*L+C)*(2*L-(3/2:ℝ)*Real.log L-K) =
        4*(L-Real.log L)+C*((3/2:ℝ)*Real.log L+K) := by
      linear_combination L*hk
    linarith only [hid,hnon]
  have hbase : n*(g*L*(2*L-(3/2:ℝ)*Real.log L-H)) ≤ phaseACenter N-H*timeScale N := by
    have he : 0 ≤ (9*g/32)*(N.val:ℝ)^2*(Real.log L)^2 := by positivity
    dsimp only [n,L,phaseACenter,observationTime,timeScale,vertexCount] at *
    nlinarith only [he]
  have hraw : (n*(g*L+C))*(2*L-(3/2:ℝ)*Real.log L-K) ≤ t-mixingTime N := by
    have h := mul_le_mul_of_nonneg_left hscalar hn.le
    have htime := hbase.trans ht
    change _ ≤ t-4*n*Real.log L
    nlinarith only [h,htime]
  have hden : 0 < n*(g*L+C) := by have := logSize_pos N; positivity
  have hs : mixingTime N ≤ t := by
    have hz := mul_nonneg hden.le hA
    linarith only [hraw,hz]
  refine ⟨hs,?_⟩
  have hd : 2*L-(3/2:ℝ)*Real.log L-K ≤ (t-mixingTime N)/(n*(g*L+C)) :=
    (le_div_iff₀ hden).mpr (by simpa only [mul_comm] using hraw)
  apply hd.trans
  have h := mul_le_mul_of_nonneg_right (point_killing_rate_log_lower N) (sub_nonneg.mpr hs)
  simpa only [n,L,C,div_eq_mul_inv,mul_comm] using h

theorem point_soft_phaseA_rate_eventually (H : ℝ) (hH : 0 ≤ H) :
    ∀ᶠ N : Size in atTop, ∀ t : ℝ, phaseACenter N-H*timeScale N ≤ t →
      mixingTime N ≤ t ∧
      2*logSize N-(3/2:ℝ)*Real.log (logSize N)-pointSoftExponentConstant H ≤
        pointKillingRate N*(t-mixingTime N) := by
  filter_upwards [blockB_logSize_tendsto.eventually (eventually_ge_atTop 1),
    blockB_logSize_tendsto.eventually (eventually_ge_atTop (2*pointSoftExponentConstant H))] with N hL hK
  exact fun t ht => point_soft_phaseA_rate N H t hH hL hK ht

theorem point_soft_exp_center (N : Size) (K : ℝ) :
    Real.exp (-(2*logSize N-(3/2:ℝ)*Real.log (logSize N)-K)) =
      Real.exp K*(logSize N)^(3/2:ℝ)/vertexCount N := by
  have heN : Real.exp (2*logSize N) = vertexCount N := by
    rw [show 2*logSize N=logSize N+logSize N by ring,Real.exp_add]
    simp [logSize,Real.exp_log (lt_trans zero_lt_one (size_real_gt_one N)),vertexCount,pow_two]
  rw [show -(2*logSize N-(3/2:ℝ)*Real.log (logSize N)-K) =
    (K+Real.log (logSize N)*(3/2:ℝ))-2*logSize N by ring,
    Real.exp_sub,Real.exp_add,heN,Real.rpow_def_of_pos (logSize_pos N)]

end TorusCoverTime.Blocks.B
