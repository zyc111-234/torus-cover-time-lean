import Solutions.Blocks.B.TruncatedHarmonic

/-! The low and high frequency split for logarithmic local Green increments. -/

noncomputable section
open MeasureTheory
open scoped BigOperators
namespace TorusCoverTime.Blocks.B

lemma harmonic_interval_sum_bound (m n : ℕ) (hm : 0 < m) (hmn : m ≤ n) :
    (∑ j ∈ Finset.Ico m n, 1 / ((j : ℝ) + 1)) ≤ Real.log ((n : ℝ) / m) := by
  have hmR : 0 < (m : ℝ) := by exact_mod_cast hm
  have hnR : 0 < (n : ℝ) := by exact_mod_cast hm.trans_le hmn
  have hanti : AntitoneOn (fun x : ℝ => 1 / x) (Set.Icc (m : ℝ) n) := by
    intro x hx y hy hxy
    exact one_div_le_one_div_of_le (hmR.trans_le hx.1) hxy
  have h := hanti.sum_le_integral_Ico hmn
  simp only [Nat.cast_add, Nat.cast_one, integral_one_div_of_pos hmR hnR] at h
  exact h

lemma local_frequency_cutoff_sum (t : ℝ) (ht : 1 ≤ t) (n : ℕ) :
    (∑ j ∈ Finset.range n, ((j : ℝ) + 1) *
      min (1 / t ^ 2) (1 / ((j : ℝ) + 1) ^ 2)) ≤
        2 + Real.log (max ((n : ℝ) / t) 1) := by
  let m := Nat.floor t
  let f := fun j : ℕ => ((j : ℝ) + 1) * min (1 / t ^ 2) (1 / ((j : ℝ) + 1) ^ 2)
  have ht0 : 0 < t := lt_of_lt_of_le zero_lt_one ht
  have hm : 0 < m := Nat.floor_pos.mpr ht
  have hmR : 0 < (m : ℝ) := by exact_mod_cast hm
  have hmt : (m : ℝ) ≤ t := Nat.floor_le ht0.le
  have htm : t ≤ 2 * (m : ℝ) := by
    have h := Nat.lt_floor_add_one t
    have hm1 : (1 : ℝ) ≤ m := by exact_mod_cast hm
    change t < (m : ℝ) + 1 at h
    linarith
  have hf (j : ℕ) : 0 ≤ f j := by dsimp [f]; positivity
  have hsmall : (∑ j ∈ Finset.range m, f j) ≤ 1 := by
    calc
      _ ≤ ∑ _j ∈ Finset.range m, 1 / t := by
        apply Finset.sum_le_sum
        intro j hj
        have hjm : (j : ℝ) + 1 ≤ m := by exact_mod_cast (Finset.mem_range.mp hj)
        calc
          _ ≤ ((j : ℝ) + 1) * (1 / t ^ 2) :=
            mul_le_mul_of_nonneg_left (min_le_left _ _) (by positivity)
          _ ≤ t * (1 / t ^ 2) := mul_le_mul_of_nonneg_right (hjm.trans hmt) (by positivity)
          _ = 1 / t := by field_simp
      _ = (m : ℝ) / t := by simp [div_eq_mul_inv]
      _ ≤ 1 := (div_le_one ht0).mpr hmt
  have hlog0 : 0 ≤ Real.log (max ((n : ℝ) / t) 1) := Real.log_nonneg (le_max_right _ _)
  by_cases hnm : n ≤ m
  · have hmono : (∑ j ∈ Finset.range n, f j) ≤ ∑ j ∈ Finset.range m, f j := by
      apply Finset.sum_le_sum_of_subset_of_nonneg (Finset.range_mono hnm)
      intro j _ _
      exact hf j
    exact (hmono.trans hsmall).trans (by linarith)
  · have hmn : m ≤ n := by omega
    have hnR : 0 < (n : ℝ) := hmR.trans_le (by exact_mod_cast hmn)
    have htail : (∑ j ∈ Finset.Ico m n, f j) ≤ Real.log ((n : ℝ) / m) := by
      apply le_trans _ (harmonic_interval_sum_bound m n hm hmn)
      apply Finset.sum_le_sum
      intro j _
      have hj0 : 0 < (j : ℝ) + 1 := by positivity
      calc
        _ ≤ ((j : ℝ) + 1) * (1 / ((j : ℝ) + 1) ^ 2) :=
          mul_le_mul_of_nonneg_left (min_le_right _ _) (by positivity)
        _ = _ := by field_simp
    have hquot : (n : ℝ) / m ≤ 2 * max ((n : ℝ) / t) 1 := by
      calc
        _ ≤ 2 * n / t := (div_le_div_iff₀ hmR ht0).mpr (by nlinarith [mul_le_mul_of_nonneg_left htm hnR.le])
        _ = 2 * ((n : ℝ) / t) := by ring
        _ ≤ _ := mul_le_mul_of_nonneg_left (le_max_left _ _) (by norm_num)
    have hlog := Real.log_le_log (div_pos hnR hmR) hquot
    rw [Real.log_mul (by norm_num) (ne_of_gt (lt_of_lt_of_le zero_lt_one (le_max_right _ _)))] at hlog
    have hlog2 : Real.log 2 ≤ 1 := by
      have h := Real.log_le_sub_one_of_pos (by norm_num : (0 : ℝ) < 2)
      norm_num at h
      exact h
    have hsplit := Finset.sum_range_add_sum_Ico f hmn
    change (∑ j ∈ Finset.range n, f j) ≤ _
    linarith

end TorusCoverTime.Blocks.B
