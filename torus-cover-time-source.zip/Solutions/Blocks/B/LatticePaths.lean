import Solutions.Blocks.B.DiskConnectivity

/-! Concrete integer-coordinate paths, with membership at every intermediate
vertex. These paths will be used in a disk with a concentric core removed. -/

noncomputable section
open Classical
namespace TorusCoverTime.Blocks.B

lemma latticeDirection_reversed (d : Fin 4) :
    latticeDirection (reversedDirection d) = -latticeDirection d := by
  fin_cases d <;> simp [latticeDirection, reversedDirection]

def latticeNeighborGraph : SimpleGraph LatticePoint where
  Adj x y := ∃ d : Fin 4, y = x + latticeDirection d
  symm := by
    constructor
    rintro x y ⟨d, hd⟩
    refine ⟨reversedDirection d, ?_⟩
    rw [latticeDirection_reversed, hd]
    simp
  loopless := ⟨by
    intro x ⟨d, hd⟩
    fin_cases d <;> simp [latticeDirection, Prod.ext_iff] at hd⟩

def latticeReachWithin (S : Set LatticePoint) (x y : LatticePoint) : Prop :=
  ∃ hx : x ∈ S, ∃ hy : y ∈ S,
    (latticeNeighborGraph.induce S).Reachable ⟨x, hx⟩ ⟨y, hy⟩

lemma latticeReachWithin_refl {S : Set LatticePoint} {x : LatticePoint} (hx : x ∈ S) :
    latticeReachWithin S x x := ⟨hx, hx, .rfl⟩

lemma latticeReachWithin_symm {S : Set LatticePoint} {x y : LatticePoint}
    (h : latticeReachWithin S x y) : latticeReachWithin S y x := by
  obtain ⟨hx, hy, h⟩ := h
  exact ⟨hy, hx, h.symm⟩

lemma latticeReachWithin_trans {S : Set LatticePoint} {x y z : LatticePoint}
    (h : latticeReachWithin S x y) (h' : latticeReachWithin S y z) : latticeReachWithin S x z := by
  obtain ⟨hx, hy, h⟩ := h
  obtain ⟨hy', hz, h'⟩ := h'
  exact ⟨hx, hz, h.trans h'⟩

lemma latticeReachWithin_step {S : Set LatticePoint} {x y : LatticePoint}
    (hx : x ∈ S) (hy : y ∈ S) (hd : ∃ d, y = x + latticeDirection d) :
    latticeReachWithin S x y := ⟨hx, hy, (show (latticeNeighborGraph.induce S).Adj ⟨x, hx⟩ ⟨y, hy⟩ from hd).reachable⟩

lemma latticeReachWithin_mono {S T : Set LatticePoint} {x y : LatticePoint}
    (hST : S ⊆ T) (h : latticeReachWithin S x y) : latticeReachWithin T x y := by
  obtain ⟨hx, hy, h⟩ := h
  exact ⟨hST hx, hST hy, h.map (latticeNeighborGraph.induceHomOfLE hST).toHom⟩

lemma lattice_line_nat (S : Set LatticePoint) (f : ℤ → LatticePoint)
    (hf : ∀ j, ∃ d, f (j + 1) = f j + latticeDirection d) (a : ℤ) (n : ℕ)
    (hS : ∀ j : ℕ, j ≤ n → f (a + j) ∈ S) : latticeReachWithin S (f a) (f (a + n)) := by
  induction n with
  | zero => simpa using latticeReachWithin_refl (hS 0 le_rfl)
  | succ n ih =>
    have hprev := ih (fun j hj => hS j (by omega))
    apply latticeReachWithin_trans hprev
    apply latticeReachWithin_step (hS n (by omega)) (hS (n + 1) le_rfl)
    simpa only [Nat.cast_add, Nat.cast_one, add_assoc] using hf (a + n)

lemma lattice_line_interval (S : Set LatticePoint) (f : ℤ → LatticePoint)
    (hf : ∀ j, ∃ d, f (j + 1) = f j + latticeDirection d) (a b : ℤ)
    (hS : ∀ j : ℤ, min a b ≤ j → j ≤ max a b → f j ∈ S) : latticeReachWithin S (f a) (f b) := by
  have ordered (u v : ℤ) (huv : u ≤ v)
      (hmem : ∀ j : ℤ, u ≤ j → j ≤ v → f j ∈ S) : latticeReachWithin S (f u) (f v) := by
    have he : u + ((v - u).toNat : ℤ) = v := by rw [Int.toNat_of_nonneg (sub_nonneg.mpr huv)]; omega
    have h := lattice_line_nat S f hf u (v - u).toNat (by
      intro j hj
      apply hmem
      · exact le_add_of_nonneg_right (by positivity)
      · have hj' : (j : ℤ) ≤ (v - u).toNat := by exact_mod_cast hj
        omega)
    simpa only [he] using h
  rcases le_total a b with hab | hba
  · exact ordered a b hab (by simpa only [min_eq_left hab, max_eq_right hab] using hS)
  · apply latticeReachWithin_symm
    exact ordered b a hba (by simpa only [min_eq_right hba, max_eq_left hba] using hS)

lemma lattice_horizontal (S : Set LatticePoint) (a b y : ℤ)
    (hS : ∀ j : ℤ, min a b ≤ j → j ≤ max a b → (j, y) ∈ S) :
    latticeReachWithin S (a, y) (b, y) :=
  lattice_line_interval S (fun j => (j, y)) (fun j => ⟨0, by simp [latticeDirection]⟩) a b hS

lemma lattice_vertical (S : Set LatticePoint) (x a b : ℤ)
    (hS : ∀ j : ℤ, min a b ≤ j → j ≤ max a b → (x, j) ∈ S) :
    latticeReachWithin S (x, a) (x, b) :=
  lattice_line_interval S (fun j => (x, j)) (fun j => ⟨2, by simp [latticeDirection]⟩) a b hS

lemma latticeReachWithin_projection (N : Size) (center : Vertex N) (S : Set LatticePoint)
    (W : Finset (Vertex N)) (hW : ∀ z ∈ S, torusProjection N center z ∈ W)
    (x y : LatticePoint) (h : latticeReachWithin S x y) :
    ∃ hx : torusProjection N center x ∈ W, ∃ hy : torusProjection N center y ∈ W,
      ((torusNeighborGraph N).induce (W : Set (Vertex N))).Reachable
        ⟨torusProjection N center x, hx⟩ ⟨torusProjection N center y, hy⟩ := by
  obtain ⟨hx, hy, h⟩ := h
  let f : (latticeNeighborGraph.induce S) →g ((torusNeighborGraph N).induce (W : Set (Vertex N))) := {
    toFun := fun z => ⟨torusProjection N center z.val, hW z.val z.property⟩
    map_rel' := by
      rintro a b ⟨d, hd⟩
      change b.val = a.val + latticeDirection d at hd
      change (torusNeighborGraph N).Adj (torusProjection N center a.val) (torusProjection N center b.val)
      rw [hd, torusProjection_add_direction]
      exact torus_neighbor_step N _ d }
  exact ⟨hW x hx, hW y hy, h.map f⟩

lemma int_segment_abs_le (a b j : ℤ) (h1 : min a b ≤ j) (h2 : j ≤ max a b) :
    |j| ≤ max |a| |b| := by
  rcases le_total a b with hab | hba
  · exact abs_le_max_abs_abs (by simpa only [min_eq_left hab] using h1)
      (by simpa only [max_eq_right hab] using h2)
  · simpa only [max_comm] using abs_le_max_abs_abs
      (show b ≤ j by simpa only [min_eq_right hba] using h1)
      (show j ≤ a by simpa only [max_eq_left hba] using h2)

lemma latticeRadius_nonneg (z : LatticePoint) : 0 ≤ latticeRadius z := Real.sqrt_nonneg _

lemma latticeRadius_swap (z : LatticePoint) : latticeRadius z.swap = latticeRadius z := by
  simp [latticeRadius, add_comm]

lemma latticeDirection_swap (d : Fin 4) : ∃ e : Fin 4, latticeDirection e = (latticeDirection d).swap := by
  fin_cases d
  · exact ⟨2, by simp [latticeDirection]⟩
  · exact ⟨3, by simp [latticeDirection]⟩
  · exact ⟨0, by simp [latticeDirection]⟩
  · exact ⟨1, by simp [latticeDirection]⟩

lemma latticeReachWithin_swap {S : Set LatticePoint} (hS : ∀ z ∈ S, z.swap ∈ S)
    {x y : LatticePoint} (h : latticeReachWithin S x y) : latticeReachWithin S x.swap y.swap := by
  obtain ⟨hx, hy, h⟩ := h
  let f : (latticeNeighborGraph.induce S) →g (latticeNeighborGraph.induce S) := {
    toFun := fun z => ⟨z.val.swap, hS z.val z.property⟩
    map_rel' := by
      rintro a b ⟨d, hd⟩
      change b.val = a.val + latticeDirection d at hd
      obtain ⟨e, he⟩ := latticeDirection_swap d
      change ∃ e, b.val.swap = a.val.swap + latticeDirection e
      refine ⟨e, ?_⟩
      rw [he, hd]
      rfl }
  exact ⟨hS x hx, hS y hy, h.map f⟩

lemma lattice_segment_radius_bound (a b j y : ℤ) (h1 : min a b ≤ j) (h2 : j ≤ max a b) :
    latticeRadius (j, y) ≤ max (latticeRadius (a, y)) (latticeRadius (b, y)) := by
  have ht := int_segment_abs_le a b j h1 h2
  rcases le_total |a| |b| with hab | hba
  · rw [max_eq_right hab] at ht
    have hr : |(j : ℝ)| ≤ |(b : ℝ)| := by exact_mod_cast ht
    apply le_trans _ (le_max_right _ _)
    nlinarith [latticeRadius_sq (j, y), latticeRadius_sq (b, y), latticeRadius_nonneg (j, y),
      latticeRadius_nonneg (b, y), sq_abs (j : ℝ), sq_abs (b : ℝ), abs_nonneg (j : ℝ)]
  · rw [max_eq_left hba] at ht
    have hr : |(j : ℝ)| ≤ |(a : ℝ)| := by exact_mod_cast ht
    apply le_trans _ (le_max_left _ _)
    nlinarith [latticeRadius_sq (j, y), latticeRadius_sq (a, y), latticeRadius_nonneg (j, y),
      latticeRadius_nonneg (a, y), sq_abs (j : ℝ), sq_abs (a : ℝ), abs_nonneg (j : ℝ)]

end TorusCoverTime.Blocks.B
