import Solutions.Blocks.B.R7PerturbedRecords

/-! Actual entrance/exit words discharge all local geometric hypotheses. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

theorem r7_perturbed_annulus_geometry (γ : ℝ) (hγ : 0 < γ) (hγ1 : γ < 1) :
    ∀ᶠ q : ℝ in atTop, 0 < r7PerturbedInner q (q^γ) ∧
      r7PerturbedInner q (q^γ) ≤ r7PerturbedOuter q (q^γ) ∧
      ∀ N : Size, ∀ c x : Vertex N, x ∉ torusDisk N c (r7PerturbedInner q (q^γ)) →
        diskHarmonicWeight N c (Real.exp (q+1)) x/g = 0 := by
  filter_upwards [r7_perturbed_probe_geometry γ hγ hγ1] with q hs
  refine ⟨by linarith [Real.exp_pos (q+1)],by linarith,?_⟩
  intro N c x hx
  have hz : diskHarmonicWeight N c (Real.exp (q+1)) x = 0 := by
    by_contra hne
    have hd := (diskExteriorNeighbor_radius N c _ x
      (diskHarmonicWeight_support N c _ (Real.exp_pos _) x hne)).2
    exact hx ((mem_torusDisk N c x _).mpr (by linarith))
  rw [hz,zero_div]

theorem r7_perturbed_positive_word_upper (hWalk : WalkModelRegular) (γ : ℝ)
    (hγ : 0 < γ) (hγ1 : γ < 1) :
    ∀ᶠ q : ℝ in atTop, ∀ N : Size, ∀ c root : Vertex N, ∀ m : ℕ, ∀ w : Fin (2*m) → Vertex N,
      root ∉ torusDisk N c (r7PerturbedOuter q (q^γ)) →
      2*(r7PerturbedOuter q (q^γ)+1) < N.val →
      walkLaw {ω | adaptiveExitWord N (alternatingDomain N (torusDisk N c (r7PerturbedInner q (q^γ)))
        (torusDisk N c (r7PerturbedOuter q (q^γ)))) root (2*m) ω = w} ≠ 0 →
      ∀ v Δ : ℝ, 0 ≤ v → (m:ℝ)*r7PerturbedWidth q (q^γ) ≤ v^2 → 0 ≤ Δ →
      2*r7PerturbedMeanConstant*Real.exp (-r7MeanExponent*q^γ)*v ≤ Δ →
      (traversalWordOutwardLaw N (torusDisk N c (r7PerturbedInner q (q^γ)))
        (torusDisk N c (r7PerturbedOuter q (q^γ))) root m w).real {p | v+Δ < Real.sqrt
          (traversalWordOutwardOccupation N root m w (fun z => diskHarmonicWeight N c (Real.exp (q+1)) z/g) p)} ≤
        2*Real.exp (-(r7PerturbedConcentrationConstant/4)*Δ^2/q^γ) := by
  filter_upwards [r7_perturbed_record_sqrt_upper hWalk γ hγ hγ1,
    r7_perturbed_annulus_geometry γ hγ hγ1] with q hq hg
  intro N c root m w hr hsmall hw v Δ hv hmv hΔ hlo
  have hgeo := diskTraversal_positive_word_geometry N c root _ _ hg.1 hg.2.1 hr m w hw
  let U := fun z => diskHarmonicWeight N c (Real.exp (q+1)) z/g
  have hE : MeasurableSet {p : Fin m → ℕ × WalkSample | v+Δ < Real.sqrt (recordProductOccupation N m
      (fun i => endpointWordStart root w (2*i.val+1)) U p)} :=
    measurableSet_lt measurable_const (recordProductOccupation_measurable N m _ U).sqrt
  have hh := congrArg (fun μ => μ {p : Fin m → ℕ × WalkSample | v+Δ < Real.sqrt
      (recordProductOccupation N m (fun i => endpointWordStart root w (2*i.val+1)) U p)})
    (outwardRecordProjection_law N _ _ root (torusDisk_nonempty N c _ hg.1) hr m w hw)
  rw [Measure.map_apply (outwardRecordProjection_measurable m) hE] at hh
  exact (congrArg ENNReal.toReal hh).le.trans (hq N c m _ _ hsmall
    (fun i => (hgeo i).1.trans (by norm_num)) (fun i => (hgeo i).2) v Δ hv hmv hΔ hlo)

theorem r7_perturbed_positive_word_duration (hWalk : WalkModelRegular) (γ : ℝ)
    (hγ : 0 < γ) (hγ1 : γ < 1) :
    ∀ᶠ N : Size in atTop, ∀ c root : Vertex N, ∀ m : ℕ, ∀ w : Fin (2*m) → Vertex N, ∀ q : ℝ,
      (logSize N)^(16*γ) ≤ q → q ≤ logSize N-(logSize N)^(16*γ) → (m:ℝ) ≤ (logSize N)^4+1 →
      root ∉ torusDisk N c (r7PerturbedOuter q (q^γ)) →
      walkLaw {ω | adaptiveExitWord N (alternatingDomain N (torusDisk N c (r7PerturbedInner q (q^γ)))
        (torusDisk N c (r7PerturbedOuter q (q^γ)))) root (2*m) ω = w} ≠ 0 →
      traversalWordOutwardLaw N (torusDisk N c (r7PerturbedInner q (q^γ)))
        (torusDisk N c (r7PerturbedOuter q (q^γ))) root m w
        {p | (m:ℝ)*Real.exp (2*logSize N-(logSize N)^(16*γ)) < ∑ j, excursionRecordDuration (p j)} ≤
        ENNReal.ofReal (Real.exp (-Real.exp ((logSize N)^(16*γ)/2))) := by
  obtain ⟨q0,hq0⟩ := eventually_atTop.mp (r7_perturbed_annulus_geometry γ hγ hγ1)
  have hQ := (tendsto_rpow_atTop (by positivity : 0 < 16*γ)).comp blockB_logSize_tendsto
  filter_upwards [r7_perturbed_record_coarse_duration hWalk γ hγ hγ1,
    hQ.eventually_ge_atTop q0] with N hN hbase
  intro c root m w q hq hqL hm hr hw
  have hg := hq0 q (hbase.trans hq)
  have hgeo := diskTraversal_positive_word_geometry N c root _ _ hg.1 hg.2.1 hr m w hw
  rw [traversalWordOutwardLaw_duration N _ _ root (torusDisk_nonempty N c _ hg.1) hr m w hw]
  exact hN c m _ _ q hq hqL hm (fun i => (hgeo i).1.trans (by norm_num)) (fun i => (hgeo i).2)

end TorusCoverTime.Blocks.B
