import Solutions.Blocks.B.BT8ShellCenter

noncomputable section
open MeasureTheory Filter Set Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

theorem bt8ImageBad_time (N : Size) (γ u : ℝ) (x : Vertex N) (s t : ℝ) (W : Vertex N → ℝ) :
    bt8ImageBad N γ u x (s,W) ↔ bt8ImageBad N γ u x (t,W) := Iff.rfl

theorem bt8_image_to_gaussian (N : Size) (γ u ε C₀ a : ℝ) (x : Vertex N)
    (f : Vertex N → ℝ) (y : D.CoareaImage N)
    (hW : ∀ z, y.2 z=(2*g)*(f z-a)^2)
    (ha : |a-harmonicExtremeCenter N|≤ε*Real.log (logSize N)+C₀)
    (hC : Real.sqrt (2*u+1)/Real.sqrt (2*g)≤C₀)
    (hb : bt8ImageBad N γ u x y) : bt7BadPoint N γ ε C₀ 4 f x := by
  have hg : 0<2*g := by positivity [coarseProbe_g_pos]
  have hn (q : ℕ) : harmonicImageRadius N x q y=bt6ExitNorm N x q f a := by
    unfold harmonicImageRadius bt6ExitNorm
    congr 1
    rw [Finset.sum_div]
    apply Finset.sum_congr rfl
    intro z _
    rw [hW z]
    unfold diskHarmonicWeight
    field_simp [coarseProbe_g_pos.ne']
  have hx : (f x-a)^2≤(2*u+1)/(2*g) := by
    apply (le_div_iff₀ hg).mpr
    have hh := hb.1
    rw [hW x] at hh
    nlinarith
  have hxc := Real.sqrt_le_sqrt hx
  have hnum : 0≤2*u+1 := by
    have hh := hb.1
    rw [hW x] at hh
    exact (mul_nonneg hg.le (sq_nonneg _)).trans hh
  rw [Real.sqrt_sq_eq_abs,Real.sqrt_div hnum] at hxc
  refine ⟨a,ha,hxc.trans hC,?_,?_⟩
  · intro q hq hq'
    rw [← hn]
    exact hb.2.1 q hq hq'
  · obtain ⟨q,hq,hq',hc⟩ := hb.2.2
    exact ⟨q,hq,hq',by rwa [← hn]⟩

theorem bt8_shifted_field_square (N : Size) (ξ : FiniteFieldSample N) (a : ℝ) (σ : Bool) (z : Vertex N) :
    (harmonicShiftedSquareImage N ξ a σ).2 z=(2*g)*
      ((if σ then -periodicFieldLS N ξ z else periodicFieldLS N ξ z)-a/Real.sqrt (2*g))^2 := by
  have hd : Real.sqrt (2*g)≠0 := (Real.sqrt_pos.mpr (by positivity [coarseProbe_g_pos])).ne'
  have hs := Real.sq_sqrt (show 0≤2*g by positivity [coarseProbe_g_pos])
  cases σ <;> simp only [harmonicShiftedSquareImage,Bool.false_eq_true,if_false,if_true,periodicFieldLS]
  all_goals
    field_simp
    nlinarith only [hs]

def bt8ShellTest (N : Size) (γ u : ℝ) (z : FiniteFieldSample N × (ℝ × Bool)) : ℝ≥0∞ :=
  bt8ImageCount N γ u (harmonicShiftedSquareImage N z.1 z.2.1 z.2.2)

theorem bt8ShiftedImage_measurable (N : Size) :
    Measurable (fun z : FiniteFieldSample N × (ℝ × Bool) => harmonicShiftedSquareImage N z.1 z.2.1 z.2.2) := by
  have hsign : Measurable (fun z : FiniteFieldSample N × (ℝ × Bool) => if z.2.2 then z.2.1 else -z.2.1) :=
    ((measurable_fst.comp measurable_snd).ite
      (measurableSet_eq_fun (measurable_snd.comp measurable_snd) measurable_const) (measurable_fst.comp measurable_snd).neg)
  apply measurable_const.prodMk
  apply measurable_pi_lambda
  intro x
  exact ((by unfold finiteGaussianField; fun_prop :
    Measurable (fun z : FiniteFieldSample N × (ℝ × Bool) => finiteGaussianField N z.1 x)).add hsign).pow_const 2

theorem bt8ShellTest_measurable (N : Size) (γ u : ℝ) : Measurable (bt8ShellTest N γ u) :=
  (bt8ImageCount_measurable N γ u).comp (bt8ShiftedImage_measurable N)

theorem bt8ShellTest_le (N : Size) (γ u : ℝ) (z : FiniteFieldSample N × (ℝ × Bool)) :
    bt8ShellTest N γ u z≤ENNReal.ofReal (vertexCount N) := bt8ImageCount_le N γ u _

theorem bt8_shell_envelope (N : Size) (γ u ε C₀ a : ℝ) (ξ : FiniteFieldSample N) (σ : Bool)
    (ha : |a/Real.sqrt (2*g)-harmonicExtremeCenter N|≤ε*Real.log (logSize N)+C₀)
    (hC : Real.sqrt (2*u+1)/Real.sqrt (2*g)≤C₀) :
    bt8ShellTest N γ u (ξ,a,σ)≤ENNReal.ofReal (bt7BadCount N γ ε C₀ 4 ξ) := by
  unfold bt8ShellTest bt8ImageCount bt7BadCount
  rw [ENNReal.ofReal_sum_of_nonneg (fun x _ => by split_ifs <;> norm_num)]
  apply Finset.sum_le_sum
  intro x _
  by_cases hb : bt8ImageBad N γ u x (harmonicShiftedSquareImage N ξ a σ)
  · have hh := bt8_image_to_gaussian N γ u ε C₀ (a/Real.sqrt (2*g)) x
      (fun z => if σ then -periodicFieldLS N ξ z else periodicFieldLS N ξ z)
      (harmonicShiftedSquareImage N ξ a σ) (bt8_shifted_field_square N ξ a σ) ha hC hb
    have hu : bt7BadPoint N γ ε C₀ 4 (periodicFieldLS N ξ) x ∨
        bt7BadPoint N γ ε C₀ 4 (fun z => -periodicFieldLS N ξ z) x := by
      cases σ
      · exact Or.inl (by simpa only [Bool.false_eq_true,if_false] using hh)
      · exact Or.inr (by simpa only [if_true] using hh)
    simp only [if_pos hb,if_pos hu,ENNReal.ofReal_one,le_refl]
  · simp only [if_neg hb]; exact bot_le

end TorusCoverTime.Blocks.B
