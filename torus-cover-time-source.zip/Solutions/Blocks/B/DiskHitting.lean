import Solutions.Blocks.B.DiskGreenLogarithm
import Solutions.Blocks.B.DiskPhysicalExit

/-! The actual pre-exit point-hit event has the proved Dirichlet Green ratio.
The non-exiting exceptional samples are handled through actual exit finiteness. -/

noncomputable section
open MeasureTheory Filter Classical
namespace TorusCoverTime.Blocks.B

theorem visitsBeforeExit_iff_punctured_exit (N : Size) (D : Finset (Vertex N)) (a x : Vertex N)
    (hx : x ∈ D) (ω : WalkSample) (he : ∃ n : ℕ, position N a ω n ∉ D) :
    ω ∈ visitsBeforeExit N D a x ↔ ω ∈ exitsThrough N (D.erase x) a x := by
  constructor
  · rintro ⟨j, hj, hjx⟩
    have hh : ∃ n, position N a ω n = x := ⟨j, hjx⟩
    have hn : Nat.find hh ≤ j := Nat.find_min' hh hjx
    have hj' : j < Nat.find he := by simpa only [finiteExitIndex, dif_pos he] using hj
    refine ⟨Nat.find hh, by simp, Nat.find_spec hh, ?_⟩
    intro k
    apply Finset.mem_erase.mpr
    refine ⟨Nat.find_min hh k.isLt, ?_⟩
    exact not_not.mp (Nat.find_min he (k.isLt.trans_le hn |>.trans hj'))
  · rintro ⟨n, _, hnx, hpre⟩
    refine ⟨n, ?_, hnx⟩
    rw [finiteExitIndex, dif_pos he]
    by_contra hle
    have hle' : Nat.find he ≤ n := le_of_not_gt hle
    rcases lt_or_eq_of_le hle' with hlt | heq
    · exact Nat.find_spec he (Finset.mem_erase.mp (hpre ⟨Nat.find he, hlt⟩)).2
    · have hbad := Nat.find_spec he
      rw [heq, hnx] at hbad
      exact hbad hx

theorem disk_visit_probability (hWalk : WalkModelRegular) (N : Size) (c : Vertex N) (R : ℝ)
    (hR : 0 < R) (hsmall : 2*(R+1) < N.val) (a x : Vertex N) (hx : x ∈ torusDisk N c R) :
    walkLaw.real (visitsBeforeExit N (torusDisk N c R) a x) =
      exitHarmonic N ((torusDisk N c R).erase x) x a := by
  unfold exitHarmonic
  apply congrArg ENNReal.toReal
  apply measure_congr
  filter_upwards [disk_physical_exit_ne_top_ae hWalk N c R hR hsmall a] with ω hfinite
  have he : ∃ n : ℕ, position N a ω n ∉ torusDisk N c R := by
    by_contra hno
    exact hfinite (domainExitTime_eq_top_of_no_exit N _ a ω hno)
  exact propext (visitsBeforeExit_iff_punctured_exit N _ a x hx ω he)

theorem disk_visit_green_ratio (hWalk : WalkModelRegular) (N : Size) (c : Vertex N) (R : ℝ)
    (hR : 0 < R) (hsmall : 2*(R+1) < N.val) (a x : Vertex N) (hx : x ∈ torusDisk N c R) :
    walkLaw.real (visitsBeforeExit N (torusDisk N c R) a x) = diskGreen N c R a x / diskGreen N c R x x := by
  rw [disk_visit_probability hWalk N c R hR hsmall a x hx]
  exact domainGreenFromBarrier_hit_ratio N _ _
    (fun z hz => diskBarrier_generator N c R hR.le hsmall z hz) a x hx

theorem disk_point_hit_log_lower (hWalk : WalkModelRegular) (N : Size) (c : Vertex N) (R : ℝ)
    (hR : 1 ≤ R) (hsmall : 2*(R+1) < N.val) (a x : Vertex N) (ha : a ∈ torusDisk N c R)
    (hx : periodicDistance x c ≤ R/2) (hax : a ≠ x) (s : ℝ) (hs : periodicDistance a x ≤ s) :
    (g*Real.log (R/s) - diskGreenLogErrorConstant) / (g*Real.log R + diskGreenLogErrorConstant) ≤
      walkLaw.real (visitsBeforeExit N (torusDisk N c R) a x) := by
  have hR0 : 0 < R := by linarith
  have hxD : x ∈ torusDisk N c R := (mem_torusDisk N c x R).mpr (by linarith)
  have hlo := diskGreen_lower_of_distance N c R hR hsmall a x ha hx hax s hs
  have hhi := (abs_le.mp (diskGreen_diagonal_precise N c R hR hsmall x hx)).2
  have hdiag := diskGreen_diagonal N c R hR0.le hsmall x hxD
  have hden : 0 < g*Real.log R + diskGreenLogErrorConstant := by linarith
  by_cases hnum : 0 ≤ g*Real.log (R/s) - diskGreenLogErrorConstant
  · rw [disk_visit_green_ratio hWalk N c R hR0 hsmall a x hxD]
    exact (div_le_div_of_nonneg_left hnum (by linarith) (by linarith :
      diskGreen N c R x x ≤ g*Real.log R + diskGreenLogErrorConstant)).trans
      (div_le_div_of_nonneg_right hlo (by linarith))
  · exact (div_nonpos_of_nonpos_of_nonneg (le_of_not_ge hnum) hden.le).trans measureReal_nonneg

end TorusCoverTime.Blocks.B
