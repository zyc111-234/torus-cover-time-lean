import Solutions.Blocks.B.R8ExactCountEvent

/-! The actual exact-count version of B.20, suitable for the two count
indices in the three-case argument. -/
noncomputable section
open MeasureTheory Filter Set Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

theorem r8_exact_count_marginal (hWalk : WalkModelRegular) (γ H : ℝ)
    (hγ : 0 < γ) (hγ1 : 16*γ < 1) (hH : 0 ≤ H) :
    ∃ c C : ℝ, 0 < c ∧ 0 < C ∧ ∀ᶠ N : Size in atTop, ∀ x : Vertex N, ∀ q : ℝ, ∀ m : ℕ, ∀ l r : ℝ,
      (logSize N)^(16*γ) ≤ q → q ≤ logSize N-(logSize N)^(16*γ) →
      q ≤ Real.sqrt (q^γ*(m:ℝ)) → Real.sqrt (q^γ*(m:ℝ)) ≤ 10*logSize N →
      l ≤ r → phaseACenter N-H*timeScale N ≤ l → r ≤ phaseACenter N+H*timeScale N →
      r8ExactCountMass N x γ q m l r ≤
        ENNReal.ofReal (C*Real.sqrt (logSize N)*Real.exp
          (-2*(logSize N-q)+2*Real.sqrt 2*(Real.sqrt (q^γ*(m:ℝ))-Real.sqrt 2*q)+8*(logSize N)^(2*γ))) +
        ENNReal.ofReal (Real.exp (-c*logSize N*Real.log (logSize N))) := by
  obtain ⟨c,C,hc,hC,hm⟩ := r8_moderate_low_count_marginal hWalk γ H hγ hγ1 hH
  refine ⟨c,C,hc,hC,?_⟩
  filter_upwards [hm] with N hN
  intro x q m l r hq hqL hv hvL hlr hlo hhi
  exact (r8_exact_count_mass_le_marginal N x γ q m l r).trans (hN x q _ l r hq hqL hv hvL hlr hlo hhi)

end TorusCoverTime.Blocks.B
