import Solutions.Blocks.B.R7Concentration

/-! The original R7.3 Bernstein scale, with one fixed positive constant and
all block counts, including the empty product. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Classical
open scoped ENNReal Topology
namespace TorusCoverTime.Blocks.B

def r7ConcentrationConstant : ℝ := min (1/(4*r7VarianceConstant)) (1/(2*r7MomentConstant))

theorem r7ConcentrationConstant_pos : 0 < r7ConcentrationConstant := by
  unfold r7ConcentrationConstant
  exact lt_min (by have := r7VarianceConstant_pos; positivity)
    (by have := r7MomentConstant_pos; positivity)

theorem r7_concentration_exponent (w z : ℝ) (m : ℕ) (hw : 0 < w) (hz : 0 ≤ z) :
    r7ConcentrationConstant*min (z^2/((m:ℝ)*w^2)) (z/w) ≤
      min (z^2/(4*(m:ℝ)*(r7VarianceConstant*w^2))) (z/(2*r7MomentConstant*w)) := by
  let A := z^2/((m:ℝ)*w^2)
  let B := z/w
  have hA : 0 ≤ A := by dsimp only [A]; positivity
  have hB : 0 ≤ B := div_nonneg hz hw.le
  have hc := r7ConcentrationConstant_pos.le
  have hc1 : r7ConcentrationConstant ≤ 1/(4*r7VarianceConstant) := min_le_left _ _
  have hc2 : r7ConcentrationConstant ≤ 1/(2*r7MomentConstant) := min_le_right _ _
  apply le_min
  · calc
      _ ≤ r7ConcentrationConstant*A := mul_le_mul_of_nonneg_left (min_le_left A B) hc
      _ ≤ (1/(4*r7VarianceConstant))*A := mul_le_mul_of_nonneg_right hc1 hA
      _ = _ := by dsimp only [A]; simp only [div_eq_mul_inv, mul_inv_rev, inv_pow]; ring
  · calc
      _ ≤ r7ConcentrationConstant*B := mul_le_mul_of_nonneg_left (min_le_right A B) hc
      _ ≤ (1/(2*r7MomentConstant))*B := mul_le_mul_of_nonneg_right hc2 hB
      _ = _ := by dsimp only [B]; simp only [div_eq_mul_inv, mul_inv_rev]; ring

theorem r7_occupation_concentration (hWalk : WalkModelRegular) (γ : ℝ) (hγ : 0 < γ) :
    ∀ᶠ q : ℝ in atTop, ∀ N : Size, ∀ c : Vertex N, ∀ m : ℕ,
      ∀ a b : Fin m → Vertex N,
      2*(Real.exp (q+2*q^γ)+1) < N.val →
      (∀ i, |periodicDistance (a i) c-Real.exp (q+q^γ)| ≤ 2) →
      (∀ i, diskExteriorNeighbor N c (Real.exp (q+2*q^γ)) (b i)) → ∀ z : ℝ, 0 ≤ z →
      (exactExitProductLaw N (torusDisk N c (Real.exp (q+2*q^γ))) m a b).real
        {ω | z < |harmonicExitBlockSum N c (Real.exp (q+1)) (Real.exp (q+2*q^γ)) m a ω-
          harmonicExitMeanSum N c (Real.exp (q+1)) (Real.exp (q+2*q^γ)) m a b|} ≤
        2*Real.exp (-r7ConcentrationConstant*min (z^2/((m:ℝ)*(q^γ)^2)) (z/q^γ)) := by
  filter_upwards [r7_independent_occupation_concentration hWalk γ hγ,
    (tendsto_rpow_atTop hγ).eventually_ge_atTop (1:ℝ)] with q hc hw
  intro N c m a b hsmall ha hb z hz
  by_cases hm : m = 0
  · subst m
    simp only [harmonicExitBlockSum, harmonicExitMeanSum, Finset.univ_eq_empty,
      Finset.sum_empty, sub_self, abs_zero, not_lt_of_ge hz, Set.ofPred_false, measureReal_empty]
    positivity
  · apply (hc N c m (Nat.pos_of_ne_zero hm) a b hsmall ha hb z hz).trans
    apply mul_le_mul_of_nonneg_left _ (by norm_num : (0:ℝ)≤2)
    apply Real.exp_le_exp.mpr
    simpa only [neg_mul] using neg_le_neg (r7_concentration_exponent (q^γ) z m (by linarith) hz)

end TorusCoverTime.Blocks.B
