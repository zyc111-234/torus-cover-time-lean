import Solutions.Blocks.B.R8PreparedDeviationMass

/-! B.19 has only the original lower-barrier indicator. Restore the
discarded high-count paths before taking the limit, paying every repetition. -/
noncomputable section
open MeasureTheory Filter Set Classical
open scoped ENNReal Topology
set_option backward.isDefEq.respectTransparency false
namespace TorusCoverTime.Blocks.B

def r8BarrierDeviationEvent (N : Size) (c root : Vertex N) (γ q U : ℝ) : Set (WalkSample × ℝ) :=
  {z | r7LowerBarrier N root γ z ∧
    2*((N.val:ℝ)*Real.exp (-((logSize N)^(16*γ))/2)) ≤ periodicDistance c root ∧
    z ∈ r8DeviationEvent N c root γ q U}

theorem r8BarrierDeviationEvent_measurable (N : Size) (c root : Vertex N) (γ q U : ℝ) :
    MeasurableSet (r8BarrierDeviationEvent N c root γ q U) := by
  have hΘ : MeasurableSet {z | r7LowerBarrier N root γ z} := by
    simpa only [compl_setOf,not_not] using (r7LowerBarrier_compl_measurable N root γ).compl
  exact hΘ.inter ((MeasurableSet.const _).inter (r8DeviationEvent_measurable N c root γ q U))

def r8BarrierDeviationMass (N : Size) (γ U l r : ℝ) : ℝ≥0∞ :=
  ∑ k ∈ r8InteriorIntegerScales N γ, ∑ c : Vertex N,
    r7LoopEventMass N (fun root => r8BarrierDeviationEvent N c root γ k U) l r

def r8RepeatedHighCountMass (N : Size) (γ U l r : ℝ) : ℝ≥0∞ :=
  ((r8InteriorIntegerScales N γ).card:ℝ≥0∞)*(Fintype.card (Vertex N):ℝ≥0∞)*r8AllHighCountMass N γ U l r

theorem r8_barrier_deviation_mass_bound (N : Size) (γ U l r : ℝ) :
    r8BarrierDeviationMass N γ U l r ≤
      r8PreparedDeviationMass N γ U l r+r8RepeatedHighCountMass N γ U l r := by
  have hlocal (k : ℕ) (c : Vertex N) :
      r7LoopEventMass N (fun root => r8BarrierDeviationEvent N c root γ k U) l r ≤
      r7LoopEventMass N (fun root => r8PreparedDeviationEvent N c root γ k U) l r+
      r8AllHighCountMass N γ U l r := by
    calc
      _ ≤ r7LoopEventMass N (fun root => r8PreparedDeviationEvent N c root γ k U ∪
          r8HighCountFailure N root γ U) l r := by
        apply r7LoopEventMass_mono_ae
        intro root
        exact Eventually.of_forall (by
          intro ω t ht hz
          by_cases hh : (ω,t) ∈ r8HighCountFailure N root γ U
          · exact Or.inr hh
          · exact Or.inl ⟨⟨hz.1,hh⟩,hz.2⟩)
      _ ≤ _ := (r7LoopEventMass_union_le N _ _
        (fun root => r8PreparedDeviationEvent_measurable N c root γ k U)
        (fun root => r8HighCountFailure_measurable N root γ U) l r).trans
          (add_le_add le_rfl (r8_high_count_failure_mass_le N γ U l r))
  calc
    _ ≤ ∑ k ∈ r8InteriorIntegerScales N γ, ∑ c : Vertex N,
        (r7LoopEventMass N (fun root => r8PreparedDeviationEvent N c root γ k U) l r+
          r8AllHighCountMass N γ U l r) :=
      Finset.sum_le_sum (fun k _ => Finset.sum_le_sum (fun c _ => hlocal k c))
    _ = _ := by
      simp only [Finset.sum_add_distrib,Finset.sum_const,Finset.card_univ,nsmul_eq_mul,
        r8PreparedDeviationMass,r8RepeatedHighCountMass,mul_assoc]

theorem r8_repeated_high_count_bound (hWalk : WalkModelRegular) (γ U H : ℝ)
    (hγ : 0 < γ) (hγ1 : γ < 1) (hU : 0 ≤ U) (hH : 0 ≤ H) :
    ∀ᶠ N : Size in atTop, ∀ l r : ℝ, r-l ≤ 2*H*timeScale N →
      r8RepeatedHighCountMass N γ U l r ≤ ENNReal.ofReal (8*H*(logSize N)^2*Real.exp (-34*logSize N)) := by
  filter_upwards [r8_all_high_count_bound hWalk γ U H hγ hγ1 hU hH,
    blockB_logSize_tendsto.eventually_ge_atTop 1] with N hN hL
  intro l r hlen
  have hcard : ((r8InteriorIntegerScales N γ).card:ℝ≥0∞) ≤ ENNReal.ofReal (2*logSize N) := by
    simpa only [ENNReal.ofReal_natCast] using ENNReal.ofReal_le_ofReal (r8_interior_scales_card N γ hL)
  have hvertex : (Fintype.card (Vertex N):ℝ≥0∞) = ENNReal.ofReal (Real.exp (2*logSize N)) := by
    rw [← ENNReal.ofReal_natCast,← D.vertexCount_eq_card,D.vertexCount_eq_exp_two_logSize]
  calc
    _ ≤ ENNReal.ofReal (2*logSize N)*ENNReal.ofReal (Real.exp (2*logSize N))*
        ENNReal.ofReal (4*H*logSize N*Real.exp (-36*logSize N)) :=
      mul_le_mul' (mul_le_mul' hcard hvertex.le) (hN l r hlen)
    _ = _ := by
      rw [← ENNReal.ofReal_mul (by positivity : 0 ≤ 2*logSize N),
        ← ENNReal.ofReal_mul (by positivity : 0 ≤ 2*logSize N*Real.exp (2*logSize N))]
      congr 1
      calc
        _ = 8*H*(logSize N)^2*(Real.exp (2*logSize N)*Real.exp (-36*logSize N)) := by ring
        _ = _ := by rw [← Real.exp_add]; congr 2; ring

theorem r8_repeated_high_count_tendsto (hWalk : WalkModelRegular) (γ U H : ℝ)
    (hγ : 0 < γ) (hγ1 : γ < 1) (hU : 0 ≤ U) (hH : 0 ≤ H) (l r : Size → ℝ)
    (hlen : ∀ᶠ N : Size in atTop, r N-l N ≤ 2*H*timeScale N) :
    Tendsto (fun N => r8RepeatedHighCountMass N γ U (l N) (r N)) atTop (𝓝 0) := by
  have ht := ENNReal.tendsto_ofReal
    (((polynomial_times_stretched_exp_tendsto_zero 1 34 2 (by norm_num) (by norm_num)).const_mul (8*H)).comp
      blockB_logSize_tendsto)
  simp only [Real.rpow_one,Real.rpow_two,mul_assoc,mul_zero,ENNReal.ofReal_zero,Function.comp_def] at ht
  apply tendsto_of_tendsto_of_tendsto_of_le_of_le' tendsto_const_nhds ht (Eventually.of_forall fun _ => bot_le)
  filter_upwards [r8_repeated_high_count_bound hWalk γ U H hγ hγ1 hU hH,hlen] with N hN hlenN
  simpa only [mul_assoc] using hN (l N) (r N) hlenN

theorem r8_barrier_deviation_mass_tendsto (hWalk : WalkModelRegular) (γ U H : ℝ)
    (hγ : 0 < γ) (hγ1 : 16*γ < 1) (hU : 0 ≤ U) (hH : 0 ≤ H) (l r : Size → ℝ)
    (hwin : ∀ᶠ N : Size in atTop, l N ≤ r N ∧
      phaseACenter N-H*timeScale N ≤ l N ∧ r N ≤ phaseACenter N+H*timeScale N) :
    Tendsto (fun N => r8BarrierDeviationMass N γ U (l N) (r N)) atTop (𝓝 0) := by
  have hlen : ∀ᶠ N : Size in atTop, r N-l N ≤ 2*H*timeScale N := by
    filter_upwards [hwin] with N hN
    linarith [hN.2.1,hN.2.2]
  have ht := (r8_prepared_deviation_mass_tendsto hWalk γ U H hγ hγ1 hU hH l r hwin).add
    (r8_repeated_high_count_tendsto hWalk γ U H hγ (by linarith) hU hH l r hlen)
  simp only [add_zero] at ht
  exact tendsto_of_tendsto_of_tendsto_of_le_of_le' tendsto_const_nhds ht
    (Eventually.of_forall fun _ => bot_le)
    (Eventually.of_forall fun N => r8_barrier_deviation_mass_bound N γ U (l N) (r N))

end TorusCoverTime.Blocks.B
