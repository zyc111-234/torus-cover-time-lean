import Solutions.Blocks.A.CoverageRestart
import Solutions.Blocks.A.TimeDisintegration

/-! Identification of the explicit future-walk formula with conditional expectation. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter Set
open scoped ENNReal Topology
open Classical

namespace TorusCoverTime.Blocks.A

theorem prefix_positive_ae (n : ℕ) : ∀ᵐ p ∂prefixLaw n, ∀ j, 0 < (p j).1 := by
  apply ae_all_iff.mpr
  intro j
  have hm : MeasurePreserving (fun p : WalkPrefix n => (p j).1) (prefixLaw n) holdingLaw :=
    measurePreserving_fst.comp (measurePreserving_eval_infinitePi (fun _ : Fin n => stepLaw) j)
  apply ae_of_ae_map hm.measurable.aemeasurable
  rw [hm.map_eq]
  exact holdingLaw_pos

theorem setCoverTime_aemeasurable (N : Size) (start : Vertex N) (U : Finset (Vertex N)) :
    AEMeasurable (setCoverTime N start U) walkLaw := by
  exact AEMeasurable.iSup fun x => AEMeasurable.iSup fun _ => hittingTime_aemeasurable N start x

theorem fresh_coverage_integral (N : Size) (start : Vertex N) (z : ℝ)
    (hz : observationTime N ≤ thresholdTime N z) (n : ℕ) {p : WalkPrefix n}
    (hp : ∀ j, 0 < (p j).1) (hs : prefixTime n p ≤ observationTime N)
    {S : Set WalkSample} (hS : @MeasurableSet WalkSample (observationHistory N start) S) :
    ∫⁻ η, S.indicator (fun ω => ENNReal.ofReal (historyKernel N start z ω))
        (glueAt n p (observationTime N) η) ∂walkLaw =
      ∫⁻ η, S.indicator (fun ω =>
        if measurableCoveredAt N start (thresholdTime N z) ω then (1 : ℝ≥0∞) else 0)
          (glueAt n p (observationTime N) η) ∂walkLaw := by
  let ψ := glueAt n p (observationTime N)
  let U := unvisited N start (ψ regularSample)
  let E : Set WalkSample := {η | setCoverTime N (prefixPosition N start n p) U η ≤
    ENNReal.ofReal (remainingTime N z)}
  have hE : NullMeasurableSet E walkLaw :=
    nullMeasurableSet_le (setCoverTime_aemeasurable N _ U) aemeasurable_const
  have hu : 0 ≤ remainingTime N z := sub_nonneg.mpr hz
  have hmem (η : WalkSample) (hη : ∀ j, 0 < (η j).1)
      (hnon : Tendsto (jumpTime η) atTop atTop) : ψ η ∈ S ↔ ψ regularSample ∈ S :=
    history_set_invariant N start
      (glueAt_history_eq N start n hp _ hs hη regularSample_spec.1 hnon) hS
  have hcov (η : WalkSample) (hη : ∀ j, 0 < (η j).1)
      (hnon : Tendsto (jumpTime η) atTop atTop) :
      measurableCoveredAt N start (thresholdTime N z) (ψ η) ↔ η ∈ E := by
    rw [measurableCoveredAt_iff N start _ (glueAt_pos n hp _ hs hη)
      (glueAt_nonexplosive n p _ hs hη hnon)]
    have ht : thresholdTime N z = observationTime N + remainingTime N z := by
      unfold remainingTime
      ring
    rw [ht]
    exact coverage_glueAt_iff N start n hp hs hη hnon _ hu
  by_cases hpast : ψ regularSample ∈ S
  · have hg : (fun η => S.indicator (fun ω => ENNReal.ofReal (historyKernel N start z ω)) (ψ η))
        =ᵐ[walkLaw] (fun _ => walkLaw E) := by
      filter_upwards [holding_positive_and_nonexplosive] with η hη
      rw [Set.indicator_of_mem ((hmem η hη.1 hη.2).mpr hpast),
        historyKernel_glueAt_late N start n hp hs hη.1 hη.2 z hz,
        ENNReal.ofReal_toReal (measure_ne_top _ _)]
    have hf : (fun η => S.indicator (fun ω =>
        if measurableCoveredAt N start (thresholdTime N z) ω then (1 : ℝ≥0∞) else 0) (ψ η))
        =ᵐ[walkLaw] E.indicator 1 := by
      filter_upwards [holding_positive_and_nonexplosive] with η hη
      rw [Set.indicator_of_mem ((hmem η hη.1 hη.2).mpr hpast)]
      simp only [hcov η hη.1 hη.2, Set.indicator, Pi.one_apply]
    rw [lintegral_congr_ae hg, lintegral_congr_ae hf, lintegral_const, measure_univ,
      mul_one, lintegral_indicator_one₀ hE]
  · have hzero (F : WalkSample → ℝ≥0∞) :
        (fun η => S.indicator F (ψ η)) =ᵐ[walkLaw] (fun _ => 0) := by
      filter_upwards [holding_positive_and_nonexplosive] with η hη
      exact Set.indicator_of_notMem (fun hm => hpast ((hmem η hη.1 hη.2).mp hm)) F
    rw [lintegral_congr_ae (hzero _), lintegral_congr_ae (hzero _)]

theorem lintegral_historyKernel_eq (N : Size) (start : Vertex N) (z : ℝ)
    (hz : observationTime N ≤ thresholdTime N z) {S : Set WalkSample}
    (hS : @MeasurableSet WalkSample (observationHistory N start) S) :
    ∫⁻ ω, S.indicator (fun ω => ENNReal.ofReal (historyKernel N start z ω)) ω ∂walkLaw =
      ∫⁻ ω, S.indicator (fun ω =>
        if measurableCoveredAt N start (thresholdTime N z) ω then (1 : ℝ≥0∞) else 0) ω ∂walkLaw := by
  have hS0 := observationHistory_le N start S hS
  have hg : Measurable (S.indicator (fun ω => ENNReal.ofReal (historyKernel N start z ω))) :=
    (((historyKernel_measurable N start z).mono (observationHistory_le N start) le_rfl).ennreal_ofReal).indicator hS0
  have hf : Measurable (S.indicator (fun ω =>
      if measurableCoveredAt N start (thresholdTime N z) ω then (1 : ℝ≥0∞) else 0)) :=
    (measurable_const.ite (measurableCoveredAt_measurableSet N start _) measurable_const).indicator hS0
  rw [lintegral_disintegrate_time (observationTime N) (observationTime_pos N).le hg,
    lintegral_disintegrate_time (observationTime N) (observationTime_pos N).le hf]
  apply tsum_congr
  intro n
  apply lintegral_congr_ae
  have hpre : MeasurableSet {p : WalkPrefix n | prefixTime n p ≤ observationTime N} :=
    measurableSet_le (prefixTime_measurable n) measurable_const
  filter_upwards [ae_restrict_of_ae (prefix_positive_ae n), ae_restrict_mem hpre] with p hp hs
  congr 1
  exact fresh_coverage_integral N start z hz n hp hs hS

theorem coverageKernel_setIntegral (N : Size) (start : Vertex N) (z : ℝ)
    (hz : observationTime N ≤ thresholdTime N z) {S : Set WalkSample}
    (hS : @MeasurableSet WalkSample (observationHistory N start) S) :
    ∫ ω in S, coverageKernel N start ω z ∂walkLaw =
      ∫ ω in S, if coveredBy N start ω (thresholdTime N z) then (1 : ℝ) else 0 ∂walkLaw := by
  have hS0 := observationHistory_le N start S hS
  have hgnon : ∀ ω, 0 ≤ S.indicator (fun ω => coverageKernel N start ω z) ω := by
    intro ω
    by_cases hω : ω ∈ S
    · rw [Set.indicator_of_mem hω]
      exact (coverageKernel_mem_Icc N start ω z).1
    · rw [Set.indicator_of_notMem hω]
  have hfnon : ∀ ω, 0 ≤ S.indicator (fun ω =>
      if coveredBy N start ω (thresholdTime N z) then (1 : ℝ) else 0) ω := by
    intro ω
    by_cases hω : ω ∈ S
    · rw [Set.indicator_of_mem hω]
      split_ifs <;> norm_num
    · rw [Set.indicator_of_notMem hω]
  rw [← integral_indicator hS0, ← integral_indicator hS0,
    integral_eq_lintegral_of_nonneg_ae (Eventually.of_forall hgnon)
      ((coverageKernel_integrable N start z).indicator hS0).aestronglyMeasurable,
    integral_eq_lintegral_of_nonneg_ae (Eventually.of_forall hfnon)
      ((coverageIndicator_integrable N start _).indicator hS0).aestronglyMeasurable]
  congr 1
  calc
    _ = ∫⁻ ω, S.indicator (fun ω => ENNReal.ofReal (historyKernel N start z ω)) ω ∂walkLaw := by
      apply lintegral_congr_ae
      filter_upwards [historyKernel_ae_eq N start z] with ω hω
      by_cases hSω : ω ∈ S <;> simp only [Set.indicator, hSω, if_true, if_false,
        ENNReal.ofReal_zero, hω]
    _ = ∫⁻ ω, S.indicator (fun ω =>
        if measurableCoveredAt N start (thresholdTime N z) ω then (1 : ℝ≥0∞) else 0) ω ∂walkLaw :=
      lintegral_historyKernel_eq N start z hz hS
    _ = _ := by
      apply lintegral_congr_ae
      filter_upwards [measurableCoveredAt_ae_iff N start (thresholdTime N z)] with ω hω
      by_cases hSω : ω ∈ S <;> by_cases hc : coveredBy N start ω (thresholdTime N z) <;>
        simp [Set.indicator, hSω, hω, hc]

theorem conditional_kernel_correct_late (N : Size) (start : Vertex N) (z : ℝ)
    (hz : observationTime N ≤ thresholdTime N z) :
    (fun ω => coverageKernel N start ω z) =ᵐ[walkLaw]
      condExp (observationHistory N start) walkLaw
        (fun ω => if coveredBy N start ω (thresholdTime N z) then (1 : ℝ) else 0) := by
  apply ae_eq_condExp_of_forall_setIntegral_eq (observationHistory_le N start)
    (coverageIndicator_integrable N start (thresholdTime N z))
  · exact fun _ _ _ => (coverageKernel_integrable N start z).integrableOn
  · exact fun _ hS _ => coverageKernel_setIntegral N start z hz hS
  · exact coverageKernel_aestronglyMeasurable_history N start z

theorem conditional_kernel_correct (_hWalk : WalkModelRegular) : ConditionalKernelCorrect := by
  intro N start
  refine ⟨observationHistory_le N start, fun z => ?_⟩
  by_cases hz : observationTime N ≤ thresholdTime N z
  · exact conditional_kernel_correct_late N start z hz
  · exact conditional_kernel_correct_early N start z (not_le.mp hz)

end TorusCoverTime.Blocks.A
