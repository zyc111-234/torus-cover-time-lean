import Solutions.Blocks.A.ObservablePaths
import Solutions.Blocks.A.HistoryCompletion

/-! The window supremum is measurable through countable path data.
For an empty unvisited set, its value is determined by coverage at the left endpoint. -/

noncomputable section
open MeasureTheory Filter
open scoped ENNReal Topology
open Classical

namespace TorusCoverTime.Blocks.A

theorem coveredBy_mono (N : Size) (start : Vertex N) (ω : WalkSample)
    {s t : ℝ} (hst : s ≤ t) (hs : coveredBy N start ω s) : coveredBy N start ω t :=
  ⟨hs.1.trans hst, hs.2.trans (ENNReal.ofReal_le_ofReal hst)⟩

theorem unvisited_empty_iff_covered (N : Size) (start : Vertex N) (ω : WalkSample) :
    unvisited N start ω = ∅ ↔ coveredBy N start ω (observationTime N) := by
  simp only [unvisited, Finset.filter_eq_empty_iff, Finset.mem_univ, true_implies,
    not_lt, coveredBy, (observationTime_pos N).le, true_and, coverTime, iSup_le_iff]

theorem selectorMass_eq_zero_of_empty (N : Size) (start : Vertex N) (ω : WalkSample)
    (hU : unvisited N start ω = ∅) : selectorMass N start ω = 0 := by
  simp [selectorMass, selectorMeasure, hU, representatives]

theorem coverageKernel_mem_Icc (N : Size) (start : Vertex N) (ω : WalkSample) (z : ℝ) :
    0 ≤ coverageKernel N start ω z ∧ coverageKernel N start ω z ≤ 1 := by
  unfold coverageKernel
  split_ifs
  · exact ⟨ENNReal.toReal_nonneg, measureReal_le_one⟩
  · exact ⟨zero_le_one, le_rfl⟩
  · exact ⟨le_rfl, zero_le_one⟩

theorem pointwiseError_le_one (N : Size) (start : Vertex N) (ω : WalkSample) (z : ℝ) :
    |coverageKernel N start ω z - Real.exp (-selectorMass N start ω * Real.exp (-z))| ≤ 1 := by
  have hk := coverageKernel_mem_Icc N start ω z
  have hm : 0 ≤ selectorMass N start ω := NNReal.coe_nonneg _
  have he0 := (Real.exp_pos (-selectorMass N start ω * Real.exp (-z))).le
  have he1 : Real.exp (-selectorMass N start ω * Real.exp (-z)) ≤ 1 :=
    Real.exp_le_one_iff.mpr (mul_nonpos_of_nonpos_of_nonneg (neg_nonpos.mpr hm) (Real.exp_pos _).le)
  exact abs_le.mpr ⟨by linarith, by linarith⟩

theorem windowError_bddAbove (N : Size) (start : Vertex N) (ω : WalkSample) (Z : ℝ) :
    BddAbove (Set.range fun z : {z : ℝ // |z| ≤ Z} =>
      |coverageKernel N start ω z.val - Real.exp (-selectorMass N start ω * Real.exp (-z.val))|) :=
  ⟨1, fun _ ⟨z, hz⟩ => hz ▸ pointwiseError_le_one N start ω z.val⟩

theorem conditionalWindowError_mem_Icc (N : Size) (start : Vertex N) (ω : WalkSample)
    (Z : ℝ) (hZ : 0 ≤ Z) :
    0 ≤ conditionalWindowError N start Z ω ∧ conditionalWindowError N start Z ω ≤ 1 := by
  let : Nonempty {z : ℝ // |z| ≤ Z} := ⟨⟨0, by simpa using hZ⟩⟩
  constructor
  · exact (abs_nonneg _).trans (le_ciSup (windowError_bddAbove N start ω Z) ⟨0, by simpa using hZ⟩)
  · exact ciSup_le fun z => pointwiseError_le_one N start ω z.val

theorem coverageKernel_eq_one_of_empty (N : Size) (start : Vertex N) (ω : WalkSample)
    (hU : unvisited N start ω = ∅) (z : ℝ) (hc : coveredBy N start ω (thresholdTime N z)) :
    coverageKernel N start ω z = 1 := by
  unfold coverageKernel
  split_ifs with ht
  · simp [hU, setCoverTime_empty]
  · simp

theorem thresholdTime_mono (N : Size) : Monotone (thresholdTime N) := by
  intro s t hst
  exact add_le_add le_rfl (mul_le_mul_of_nonneg_right hst (timeScale_pos N).le)

theorem windowError_of_empty (N : Size) (start : Vertex N) (ω : WalkSample)
    (Z : ℝ) (hZ : 0 ≤ Z) (hU : unvisited N start ω = ∅) :
    conditionalWindowError N start Z ω =
      if coveredBy N start ω (thresholdTime N (-Z)) then 0 else 1 := by
  let : Nonempty {z : ℝ // |z| ≤ Z} := ⟨⟨0, by simpa using hZ⟩⟩
  have hm := selectorMass_eq_zero_of_empty N start ω hU
  by_cases hc : coveredBy N start ω (thresholdTime N (-Z))
  · rw [if_pos hc]
    unfold conditionalWindowError
    have he (z : {z : ℝ // |z| ≤ Z}) :
        |coverageKernel N start ω z.val - Real.exp (-selectorMass N start ω * Real.exp (-z.val))| = 0 := by
      have hcz := coveredBy_mono N start ω (thresholdTime_mono N (abs_le.mp z.property).1) hc
      rw [coverageKernel_eq_one_of_empty N start ω hU z.val hcz, hm]
      norm_num
    simp only [he, ciSup_const]
  · rw [if_neg hc]
    apply le_antisymm (conditionalWindowError_mem_Icc N start ω Z hZ).2
    have ht : ¬ observationTime N ≤ thresholdTime N (-Z) := by
      intro ht
      exact hc (coveredBy_mono N start ω ht ((unvisited_empty_iff_covered N start ω).mp hU))
    have hk : coverageKernel N start ω (-Z) = 0 := by simp [coverageKernel, ht, hc]
    have hlow := le_ciSup (windowError_bddAbove N start ω Z)
      (⟨-Z, by simp [abs_of_nonneg hZ]⟩ : {z : ℝ // |z| ≤ Z})
    simpa only [conditionalWindowError, hk, hm, neg_zero, zero_mul, Real.exp_zero, zero_sub, abs_neg, abs_one]
      using hlow

def errorProfile (N : Size) (Z : ℝ) (a : Vertex N) (U : Finset (Vertex N)) : ℝ :=
  ⨆ z : {z : ℝ // |z| ≤ Z},
    |(if observationTime N ≤ thresholdTime N z.val then
        (walkLaw {ω | setCoverTime N a U ω ≤ ENNReal.ofReal (remainingTime N z.val)}).toReal
      else 0) - Real.exp (-(selectorFromSet N U).mass * Real.exp (-z.val))|

theorem windowError_of_nonempty (N : Size) (start : Vertex N) (ω : WalkSample) (Z : ℝ)
    (hU : unvisited N start ω ≠ ∅) :
    conditionalWindowError N start Z ω =
      errorProfile N Z (walk N start ω (observationTime N)) (unvisited N start ω) := by
  unfold conditionalWindowError errorProfile
  congr 1
  funext z
  have hk : coverageKernel N start ω z.val =
      if observationTime N ≤ thresholdTime N z.val then
        (walkLaw {ω' | setCoverTime N (walk N start ω (observationTime N))
          (unvisited N start ω) ω' ≤ ENNReal.ofReal (remainingTime N z.val)}).toReal else 0 := by
    by_cases ht : observationTime N ≤ thresholdTime N z.val
    · simp only [coverageKernel, if_pos ht]
    · have hc : ¬ coveredBy N start ω (thresholdTime N z.val) := by
        intro hc
        exact hU ((unvisited_empty_iff_covered N start ω).mpr
          (coveredBy_mono N start ω (not_le.mp ht).le hc))
      simp only [coverageKernel, if_neg ht, if_neg hc]
  rw [hk]
  rfl

def errorDataValue (N : Size) (Z : ℝ) (d : Vertex N × Finset (Vertex N) × ℕ) : ℝ :=
  if d.2.1 = ∅ then if d.2.2 = 1 then 0 else 1 else errorProfile N Z d.1 d.2.1

theorem conditionalWindowError_aemeasurable (N : Size) (start : Vertex N) (Z : ℝ) (hZ : 0 ≤ Z) :
    AEMeasurable (conditionalWindowError N start Z) walkLaw := by
  let flag : WalkSample → ℕ := fun ω =>
    if coveredBy N start ω (thresholdTime N (-Z)) then 1 else 0
  have hs : NullMeasurableSet {ω | coveredBy N start ω (thresholdTime N (-Z))} walkLaw := by
    by_cases ht : 0 ≤ thresholdTime N (-Z)
    · simpa only [coveredBy, ht, true_and] using
        nullMeasurableSet_le (coverTime_aemeasurable N start) aemeasurable_const
    · simpa only [coveredBy, ht, false_and, Set.ofPred_false] using
        (nullMeasurableSet_empty : NullMeasurableSet (∅ : Set WalkSample) walkLaw)
  have hf : AEMeasurable flag walkLaw := aemeasurable_const.indicator₀ hs
  have hd := (walk_measurable N start (observationTime N)).aemeasurable.prodMk
    ((unvisited_aemeasurable N start).prodMk hf)
  apply ((measurable_of_countable (errorDataValue N Z)).comp_aemeasurable hd).congr
  apply Eventually.of_forall
  intro ω
  by_cases hU : unvisited N start ω = ∅
  · rw [windowError_of_empty N start ω Z hZ hU]
    by_cases hc : coveredBy N start ω (thresholdTime N (-Z)) <;>
      simp [errorDataValue, hU, flag, hc]
  · simpa only [Function.comp_apply, errorDataValue, if_neg hU] using
      (windowError_of_nonempty N start ω Z hU).symm

theorem conditionalWindowError_integrable (N : Size) (start : Vertex N) (Z : ℝ) (hZ : 0 ≤ Z) :
    Integrable (conditionalWindowError N start Z) walkLaw := by
  apply Integrable.of_bound (conditionalWindowError_aemeasurable N start Z hZ).aestronglyMeasurable 1
  exact Eventually.of_forall fun ω => by
    rw [Real.norm_eq_abs, abs_of_nonneg (conditionalWindowError_mem_Icc N start ω Z hZ).1]
    exact (conditionalWindowError_mem_Icc N start ω Z hZ).2

end TorusCoverTime.Blocks.A
