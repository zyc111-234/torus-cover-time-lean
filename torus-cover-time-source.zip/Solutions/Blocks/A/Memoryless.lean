import Solutions.Blocks.A.Nonexplosion

/-! The residual holding-time law, proved from the exponential CDF. -/

noncomputable section
open MeasureTheory ProbabilityTheory Set
open scoped ENNReal

set_option backward.isDefEq.respectTransparency false

namespace TorusCoverTime.Blocks.A

theorem holdingLaw_real_Iic (t : ℝ) :
    holdingLaw.real (Iic t) = if 0 ≤ t then 1 - Real.exp (-t) else 0 := by
  rw [← cdf_eq_real, holdingLaw, cdf_expMeasure_eq (by norm_num : (0 : ℝ) < 1)]
  simp only [one_mul]

theorem holdingLaw_real_Ioi (t : ℝ) (ht : 0 ≤ t) :
    holdingLaw.real (Ioi t) = Real.exp (-t) := by
  rw [← compl_Iic, measureReal_compl measurableSet_Iic, probReal_univ,
    holdingLaw_real_Iic, if_pos ht]
  ring

theorem holdingLaw_real_Ioc (r a : ℝ) (hr : 0 ≤ r) (ha : 0 ≤ a) :
    holdingLaw.real (Ioc r (r + a)) = Real.exp (-r) * (1 - Real.exp (-a)) := by
  rw [← Iic_sdiff_Iic, measureReal_sdiff (Iic_subset_Iic.mpr (by linarith))
    measurableSet_Iic, holdingLaw_real_Iic, holdingLaw_real_Iic,
    if_pos (by linarith : 0 ≤ r + a), if_pos hr, neg_add, Real.exp_add]
  ring

theorem holdingLaw_residual_map (r : ℝ) (hr : 0 ≤ r) :
    (holdingLaw.restrict (Ioi r)).map (fun x => x - r) =
      ENNReal.ofReal (Real.exp (-r)) • holdingLaw := by
  apply Measure.ext_of_Iic
  intro a
  have hm : Measurable (fun x : ℝ => x - r) := measurable_id.sub_const r
  rw [Measure.map_apply hm measurableSet_Iic,
    Measure.restrict_apply (hm measurableSet_Iic), Measure.smul_apply, smul_eq_mul]
  have he : (fun x : ℝ => x - r) ⁻¹' Iic a ∩ Ioi r = Ioc r (r + a) := by
    ext x
    simp only [mem_inter_iff, mem_preimage, mem_Iic, mem_Ioi, mem_Ioc]
    constructor <;> intro h <;> constructor <;> linarith [h.1, h.2]
  rw [he]
  by_cases ha : 0 ≤ a
  · apply (ENNReal.toReal_eq_toReal_iff' (by finiteness) (by finiteness)).mp
    rw [ENNReal.toReal_mul, ENNReal.toReal_ofReal (Real.exp_pos _).le]
    change holdingLaw.real (Ioc r (r + a)) = Real.exp (-r) * holdingLaw.real (Iic a)
    rw [holdingLaw_real_Ioc r a hr ha, holdingLaw_real_Iic, if_pos ha]
  · have hI : Ioc r (r + a) = ∅ := Ioc_eq_empty (by linarith)
    have hz : holdingLaw (Iic a) = 0 := by
      rw [← ofReal_cdf, holdingLaw, cdf_expMeasure_eq (by norm_num : (0 : ℝ) < 1),
        if_neg ha, ENNReal.ofReal_zero]
    rw [hI, measure_empty, hz, mul_zero]

theorem holdingLaw_restrict_Ioi (r : ℝ) (hr : 0 ≤ r) :
    holdingLaw.restrict (Ioi r) =
      ENNReal.ofReal (Real.exp (-r)) • holdingLaw.map (fun x => x + r) := by
  have h := congrArg (Measure.map (fun x : ℝ => x + r)) (holdingLaw_residual_map r hr)
  rw [Measure.map_map
    (show Measurable (fun x : ℝ => x + r) by fun_prop)
    (show Measurable (fun x : ℝ => x - r) by fun_prop),
    Measure.map_smul] at h
  simpa only [Function.comp_def, sub_add_cancel, Measure.map_id'] using h

def stepDelay (r : ℝ) (q : ℝ × Fin 4) : ℝ × Fin 4 := (q.1 + r, q.2)

theorem stepDelay_measurable (r : ℝ) : Measurable (stepDelay r) := by
  unfold stepDelay
  fun_prop

theorem stepLaw_restrict_above (r : ℝ) (hr : 0 ≤ r) :
    stepLaw.restrict {q | r < q.1} =
      ENNReal.ofReal (Real.exp (-r)) • stepLaw.map (stepDelay r) := by
  have hs : {q : ℝ × Fin 4 | r < q.1} = Ioi r ×ˢ univ := by ext q; simp
  rw [hs, stepLaw, ← Measure.restrict_prod_eq_prod_univ, holdingLaw_restrict_Ioi r hr,
    Measure.prod_smul_left]
  congr 1
  change (holdingLaw.map (fun x => x + r)).prod (uniformOn (Set.univ : Set (Fin 4))) =
    Measure.map (fun p : ℝ × Fin 4 => (p.1 + r, p.2))
      (holdingLaw.prod (uniformOn (Set.univ : Set (Fin 4))))
  have hm := Measure.map_prod_map holdingLaw (uniformOn (Set.univ : Set (Fin 4)))
    (measurable_id.add_const r) measurable_id
  simpa only [Measure.map_id, Measure.map_id', Prod.map_def, id_eq, stepDelay] using hm

end TorusCoverTime.Blocks.A
