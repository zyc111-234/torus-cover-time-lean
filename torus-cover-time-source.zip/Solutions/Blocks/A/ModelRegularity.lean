import Solutions.Blocks.A.CoverFiniteness
import Solutions.Blocks.A.WindowError

/-! All regularity clauses for the concrete exponential-holding-time walk. -/

noncomputable section

namespace TorusCoverTime.Blocks.A

theorem walk_model_regular : WalkModelRegular :=
  ⟨holding_positive_and_nonexplosive,
    coverTime_ne_top,
    normalizedCoverTime_aemeasurable,
    selectorRandomMeasure_aemeasurable,
    conditionalWindowError_integrable⟩

end TorusCoverTime.Blocks.A
