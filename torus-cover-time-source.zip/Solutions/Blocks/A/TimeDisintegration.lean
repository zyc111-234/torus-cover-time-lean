import Solutions.Blocks.A.PathSplicing

/-! Disintegrating the sample law by the number of completed jumps at a fixed time. -/

noncomputable section
open MeasureTheory Filter Set
open scoped ENNReal Topology
open Classical

namespace TorusCoverTime.Blocks.A

def jumpSlice (s : ℝ) (n : ℕ) : Set WalkSample :=
  {ω | jumpTime ω n ≤ s ∧ s < jumpTime ω (n + 1)}

theorem jumpSlice_measurableSet (s : ℝ) (n : ℕ) : MeasurableSet (jumpSlice s n) :=
  (measurableSet_le (measurable_jumpTime n) measurable_const).inter
    (measurableSet_lt measurable_const (measurable_jumpTime (n + 1)))

theorem jumpTime_monotone (ω : WalkSample) : Monotone (jumpTime ω) := by
  apply monotone_nat_of_le_succ
  intro k
  simp only [jumpTime, Finset.sum_range_succ, le_add_iff_nonneg_right]
  exact le_max_right _ _

theorem jumpSlices_disjoint (s : ℝ) : Pairwise (fun n m => Disjoint (jumpSlice s n) (jumpSlice s m)) := by
  intro n m hnm
  rw [Set.disjoint_left]
  intro ω hn hm
  rcases lt_or_gt_of_ne hnm with hlt | hlt
  · exact (not_lt_of_ge ((jumpTime_monotone ω (Nat.succ_le_of_lt hlt)).trans hm.1)) hn.2
  · exact (not_lt_of_ge ((jumpTime_monotone ω (Nat.succ_le_of_lt hlt)).trans hn.1)) hm.2

theorem jumpSlices_ae_cover (s : ℝ) (hs : 0 ≤ s) :
    (⋃ n, jumpSlice s n) =ᵐ[walkLaw] univ := by
  filter_upwards [holding_positive_and_nonexplosive] with ω hω
  have hex : ∃ k, s < jumpTime ω (k + 1) := by
    obtain ⟨j, hj⟩ := (hω.2.eventually (eventually_gt_atTop s)).exists
    exact ⟨j, hj.trans (jumpTime_strictMono hω.1 (Nat.lt_succ_self j))⟩
  have hm : ω ∈ ⋃ n, jumpSlice s n := by
    apply mem_iUnion.mpr
    refine ⟨jumpCount ω s, jumpTime_jumpCount_le hω.1 hω.2 hs, ?_⟩
    simpa only [jumpCount, dif_pos hex] using Nat.find_spec hex
  exact propext ⟨fun _ => mem_univ ω, fun _ => hm⟩

theorem joinSequence_mem_jumpSlice (n : ℕ) (p : WalkPrefix n) (η : WalkSample) (s : ℝ)
    (hs : prefixTime n p ≤ s) :
    joinSequence n p η ∈ jumpSlice s n ↔ s - prefixTime n p < (η 0).1 := by
  simp only [jumpSlice, mem_ofPred_eq, jumpTime_join_prefix, jumpTime_join_add, hs, true_and]
  simp only [jumpTime, Finset.sum_range_one, holdingTime]
  rw [← sub_lt_iff_lt_add']
  simp only [lt_max_iff, not_lt.mpr (sub_nonneg.mpr hs), or_false]

theorem lintegral_jumpSlice (s : ℝ) (n : ℕ) {f : WalkSample → ℝ≥0∞} (hf : Measurable f) :
    ∫⁻ ω in jumpSlice s n, f ω ∂walkLaw =
      ∫⁻ p in {p | prefixTime n p ≤ s},
        ENNReal.ofReal (Real.exp (-(s - prefixTime n p))) *
          ∫⁻ η, f (glueAt n p s η) ∂walkLaw ∂prefixLaw n := by
  have hslice := jumpSlice_measurableSet s n
  have hpre : MeasurableSet {p : WalkPrefix n | prefixTime n p ≤ s} :=
    measurableSet_le (prefixTime_measurable n) measurable_const
  rw [← lintegral_indicator hslice]
  rw [← (joinSequence_measurePreserving n).lintegral_comp (hf.indicator hslice)]
  have hm : Measurable (fun q : WalkPrefix n × WalkSample =>
      (jumpSlice s n).indicator f (joinSequence n q.1 q.2)) :=
    (hf.indicator hslice).comp (joinSequence_measurable n)
  rw [lintegral_prod _ hm.aemeasurable]
  rw [← lintegral_indicator hpre]
  apply lintegral_congr
  intro p
  by_cases hp : prefixTime n p ≤ s
  · rw [Set.indicator_of_mem (show p ∈ {p | prefixTime n p ≤ s} from hp)]
    have he : (fun η => (jumpSlice s n).indicator f (joinSequence n p η)) =
        {η : WalkSample | s - prefixTime n p < (η 0).1}.indicator
          (fun η => f (joinSequence n p η)) := by
      funext η
      simp only [Set.indicator, joinSequence_mem_jumpSlice n p η s hp, mem_ofPred_eq]
    have hfp : Measurable (fun η => f (joinSequence n p η)) :=
      hf.comp ((joinSequence_measurable n).comp (measurable_const.prodMk measurable_id))
    rw [he, lintegral_indicator
      (measurableSet_lt measurable_const (measurable_pi_apply 0).fst),
      lintegral_restrict_first_above _ (sub_nonneg.mpr hp) hfp]
    rfl
  · rw [Set.indicator_of_notMem (show p ∉ {p | prefixTime n p ≤ s} from hp)]
    have he : (fun η => (jumpSlice s n).indicator f (joinSequence n p η)) = 0 := by
      funext η
      apply Set.indicator_of_notMem
      simp only [jumpSlice, mem_ofPred_eq, jumpTime_join_prefix, hp, false_and, not_false_eq_true]
    rw [he]
    exact lintegral_zero

theorem lintegral_disintegrate_time (s : ℝ) (hs : 0 ≤ s)
    {f : WalkSample → ℝ≥0∞} (hf : Measurable f) :
    ∫⁻ ω, f ω ∂walkLaw =
      ∑' n : ℕ, ∫⁻ p in {p | prefixTime n p ≤ s},
        ENNReal.ofReal (Real.exp (-(s - prefixTime n p))) *
          ∫⁻ η, f (glueAt n p s η) ∂walkLaw ∂prefixLaw n := by
  calc
    _ = ∫⁻ ω in ⋃ n, jumpSlice s n, f ω ∂walkLaw := by
      rw [setLIntegral_congr (jumpSlices_ae_cover s hs), Measure.restrict_univ]
    _ = ∑' n, ∫⁻ ω in jumpSlice s n, f ω ∂walkLaw :=
      lintegral_iUnion (jumpSlice_measurableSet s) (jumpSlices_disjoint s) f
    _ = _ := tsum_congr fun n => lintegral_jumpSlice s n hf

end TorusCoverTime.Blocks.A
