import Solutions.Blocks.A.Nonexplosion

/-! Measurable versions of the concrete hitting times and selector. -/

noncomputable section
open MeasureTheory Filter
open scoped ENNReal Topology

namespace TorusCoverTime.Blocks.A

theorem hittingTime_aemeasurable (N : Size) (start x : Vertex N) :
    AEMeasurable (fun ω => hittingTime N start ω x) walkLaw := by
  apply (measurable_discreteHittingTime N start x).aemeasurable.congr
  filter_upwards [holding_positive_and_nonexplosive] with ω hω
  exact (hittingTime_eq_discrete N start hω.1 hω.2 x).symm

theorem coverTime_aemeasurable (N : Size) (start : Vertex N) :
    AEMeasurable (coverTime N start) walkLaw := by
  exact AEMeasurable.iSup fun x => hittingTime_aemeasurable N start x

theorem normalizedCoverTime_aemeasurable (N : Size) (start : Vertex N) :
    AEMeasurable (normalizedCoverTime N start) walkLaw := by
  exact ((coverTime_aemeasurable N start).ennreal_toReal.sub_const (timeCenter N)).div_const
    (timeScale N)

def measurableUnvisited (N : Size) (start : Vertex N) (ω : WalkSample) : Finset (Vertex N) := by
  classical
  exact Finset.univ.filter fun x =>
    ENNReal.ofReal (observationTime N) < discreteHittingTime N start ω x

theorem measurable_measurableUnvisited (N : Size) (start : Vertex N) :
    Measurable (measurableUnvisited N start) := by
  classical
  apply measurable_finset_iff.2
  intro x
  apply measurableSet_setOfPred.mp
  simpa [measurableUnvisited] using
    measurableSet_lt measurable_const (measurable_discreteHittingTime N start x)

theorem measurableUnvisited_ae_eq (N : Size) (start : Vertex N) :
    measurableUnvisited N start =ᵐ[walkLaw] unvisited N start := by
  classical
  filter_upwards [holding_positive_and_nonexplosive] with ω hω
  ext x
  simp [measurableUnvisited, unvisited, hittingTime_eq_discrete N start hω.1 hω.2]

theorem unvisited_aemeasurable (N : Size) (start : Vertex N) :
    AEMeasurable (unvisited N start) walkLaw :=
  (measurable_measurableUnvisited N start).aemeasurable.congr (measurableUnvisited_ae_eq N start)

def selectorFromSet (N : Size) (U : Finset (Vertex N)) : TorusMeasure :=
  TorusMeasure.ofFinite (selectorWeight N • ∑ a ∈ representatives N U, pointMass (embed a))

theorem selectorRandomMeasure_aemeasurable (N : Size) (start : Vertex N) :
    AEMeasurable (selectorRandomMeasure N start) walkLaw := by
  exact (measurable_of_countable (selectorFromSet N)).comp_aemeasurable
    (unvisited_aemeasurable N start)

end TorusCoverTime.Blocks.A
