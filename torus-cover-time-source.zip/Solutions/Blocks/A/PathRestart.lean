import Solutions.Blocks.A.PathSplicing

/-! A spliced path has the prescribed past and evolves as the fresh path after the splice. -/

noncomputable section
open MeasureTheory Filter Set
open scoped ENNReal Topology

namespace TorusCoverTime.Blocks.A

theorem jumpCount_upper {ω : WalkSample} (hpos : ∀ j, 0 < (ω j).1)
    (hnon : Tendsto (jumpTime ω) atTop atTop) (t : ℝ) :
    t < jumpTime ω (jumpCount ω t + 1) := by
  have hex : ∃ k, t < jumpTime ω (k + 1) := by
    obtain ⟨j, hj⟩ := (hnon.eventually (eventually_gt_atTop t)).exists
    exact ⟨j, hj.trans (jumpTime_strictMono hpos (Nat.lt_succ_self j))⟩
  simpa only [jumpCount, dif_pos hex] using Nat.find_spec hex

theorem jumpCount_glueAt_future (n : ℕ) {p : WalkPrefix n} (hp : ∀ j, 0 < (p j).1)
    (s : ℝ) (hs : prefixTime n p ≤ s) {η : WalkSample} (hη : ∀ j, 0 < (η j).1)
    (hnon : Tendsto (jumpTime η) atTop atTop) (u : ℝ) (hu : 0 ≤ u) :
    jumpCount (glueAt n p s η) (s + u) = n + jumpCount η u := by
  apply jumpCount_eq_of_bounds (glueAt_pos n hp s hs hη)
  · have hl := jumpTime_jumpCount_le hη hnon hu
    cases hk : jumpCount η u with
    | zero =>
        simp only [Nat.add_zero, glueAt, jumpTime_join_prefix]
        linarith
    | succ k =>
        rw [jumpTime_glueAt_succ n p s hs hη]
        rw [hk] at hl
        linarith
  · rw [Nat.add_assoc, jumpTime_glueAt_succ n p s hs hη]
    linarith [jumpCount_upper hη hnon u]

theorem walk_glueAt_future (N : Size) (start : Vertex N) (n : ℕ)
    {p : WalkPrefix n} (hp : ∀ j, 0 < (p j).1) (s : ℝ) (hs : prefixTime n p ≤ s)
    {η : WalkSample} (hη : ∀ j, 0 < (η j).1) (hnon : Tendsto (jumpTime η) atTop atTop)
    (u : ℝ) (hu : 0 ≤ u) :
    walk N start (glueAt n p s η) (s + u) = walk N (prefixPosition N start n p) η u := by
  have hs0 := (prefixTime_nonneg n p).trans hs
  simp only [walk, if_neg (not_lt.mpr (add_nonneg hs0 hu)), if_neg (not_lt.mpr hu)]
  rw [jumpCount_glueAt_future n hp s hs hη hnon u hu, glueAt, position_join_add]
  simp only [position, delayHead_direction]

theorem walk_zero_of_positive (N : Size) (start : Vertex N) {ω : WalkSample}
    (hω : ∀ j, 0 < (ω j).1) : walk N start ω 0 = start := by
  have hc : jumpCount ω 0 = 0 := by simpa only [jumpTime_zero] using jumpCount_jumpTime hω 0
  simp [walk, hc]

theorem walk_glueAt_observation (N : Size) (start : Vertex N) (n : ℕ)
    {p : WalkPrefix n} (hp : ∀ j, 0 < (p j).1) (s : ℝ) (hs : prefixTime n p ≤ s)
    {η : WalkSample} (hη : ∀ j, 0 < (η j).1) (hnon : Tendsto (jumpTime η) atTop atTop) :
    walk N start (glueAt n p s η) s = prefixPosition N start n p := by
  simpa only [add_zero, walk_zero_of_positive N _ hη] using
    walk_glueAt_future N start n hp s hs hη hnon 0 le_rfl

theorem jumpTime_eq_of_prefix {ω η : WalkSample} (n : ℕ)
    (h : ∀ j < n, ω j = η j) (k : ℕ) (hk : k ≤ n) : jumpTime ω k = jumpTime η k := by
  apply Finset.sum_congr rfl
  intro j hj
  simp only [holdingTime, h j (lt_of_lt_of_le (Finset.mem_range.mp hj) hk)]

theorem position_eq_of_prefix (N : Size) (start : Vertex N) {ω η : WalkSample} (n : ℕ)
    (h : ∀ j < n, ω j = η j) (k : ℕ) (hk : k ≤ n) :
    position N start ω k = position N start η k := by
  unfold position
  congr 1
  apply Finset.sum_congr rfl
  intro j hj
  rw [h j (lt_of_lt_of_le (Finset.mem_range.mp hj) hk)]

theorem walk_eq_of_prefix (N : Size) (start : Vertex N) {ω η : WalkSample}
    (hω : ∀ j, 0 < (ω j).1) (hη : ∀ j, 0 < (η j).1)
    (hnon : Tendsto (jumpTime ω) atTop atTop) (n : ℕ)
    (h : ∀ j < n, ω j = η j) (t : ℝ) (ht : 0 ≤ t)
    (htω : t < jumpTime ω (n + 1)) (htη : t < jumpTime η (n + 1)) :
    walk N start ω t = walk N start η t := by
  have hk : jumpCount ω t ≤ n := by
    have hex : ∃ k, t < jumpTime ω (k + 1) := ⟨n, htω⟩
    simpa only [jumpCount, dif_pos hex] using Nat.find_le htω
  have hleft : jumpTime η (jumpCount ω t) ≤ t := by
    rw [← jumpTime_eq_of_prefix n h _ hk]
    exact jumpTime_jumpCount_le hω hnon ht
  have hright : t < jumpTime η (jumpCount ω t + 1) := by
    rcases hk.eq_or_lt with heq | hlt
    · simpa only [heq] using htη
    · rw [← jumpTime_eq_of_prefix n h _ (Nat.succ_le_of_lt hlt)]
      exact jumpCount_upper hω hnon t
  have hc := jumpCount_eq_of_bounds hη hleft hright
  simp only [walk, if_neg (not_lt.mpr ht), hc]
  exact position_eq_of_prefix N start n h _ hk

theorem glueAt_history_eq (N : Size) (start : Vertex N) (n : ℕ)
    {p : WalkPrefix n} (hp : ∀ j, 0 < (p j).1) (s : ℝ) (hs : prefixTime n p ≤ s)
    {η ξ : WalkSample} (hη : ∀ j, 0 < (η j).1) (hξ : ∀ j, 0 < (ξ j).1)
    (hnon : Tendsto (jumpTime η) atTop atTop) (t : ℝ) (ht : 0 ≤ t ∧ t ≤ s) :
    walk N start (glueAt n p s η) t = walk N start (glueAt n p s ξ) t := by
  apply walk_eq_of_prefix N start (glueAt_pos n hp s hs hη) (glueAt_pos n hp s hs hξ)
    (glueAt_nonexplosive n p s hs hη hnon) n
  · intro j hj
    simp only [glueAt, joinSequence, dif_pos hj]
  · exact ht.1
  · rw [show n + 1 = n + (0 + 1) by omega, jumpTime_glueAt_succ n p s hs hη]
    have hj : 0 < jumpTime η 1 := by
      simpa only [jumpTime_zero] using (jumpTime_strictMono hη (Nat.zero_lt_succ 0))
    linarith [ht.2]
  · rw [show n + 1 = n + (0 + 1) by omega, jumpTime_glueAt_succ n p s hs hξ]
    have hj : 0 < jumpTime ξ 1 := by
      simpa only [jumpTime_zero] using (jumpTime_strictMono hξ (Nat.zero_lt_succ 0))
    linarith [ht.2]

@[instance_reducible] def sameMembershipSpace (ω η : WalkSample) : MeasurableSpace WalkSample where
  MeasurableSet' S := ω ∈ S ↔ η ∈ S
  measurableSet_empty := Iff.rfl
  measurableSet_compl := fun _ h => not_congr h
  measurableSet_iUnion := fun S h => by
    simp only [mem_iUnion]
    exact exists_congr h

theorem history_set_invariant (N : Size) (start : Vertex N) {ω η : WalkSample}
    (h : ∀ t : ℝ, 0 ≤ t ∧ t ≤ observationTime N → walk N start ω t = walk N start η t)
    {S : Set WalkSample} (hS : @MeasurableSet WalkSample (observationHistory N start) S) :
    ω ∈ S ↔ η ∈ S := by
  have hle : observationHistory N start ≤ sameMembershipSpace ω η := by
    apply iSup_le
    intro t
    rintro A ⟨B, _, rfl⟩
    change walk N start ω t.val ∈ B ↔ walk N start η t.val ∈ B
    rw [h t.val t.property]
  exact hle S hS

end TorusCoverTime.Blocks.A
