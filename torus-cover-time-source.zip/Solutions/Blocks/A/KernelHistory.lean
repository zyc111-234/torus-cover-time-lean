import Solutions.Blocks.A.WindowError

/-! Measurable history versions of coverage events and the explicit coverage kernel. -/

noncomputable section
open MeasureTheory Filter Set
open scoped ENNReal Topology
open Classical

namespace TorusCoverTime.Blocks.A

theorem hittingTime_le_time_iff (N : Size) (start : Vertex N) {ω : WalkSample}
    (hpos : ∀ j, 0 < (ω j).1) (hnon : Tendsto (jumpTime ω) atTop atTop)
    (x : Vertex N) (t : ℝ) (ht : 0 ≤ t) :
    hittingTime N start ω x ≤ ENNReal.ofReal t ↔
      walk N start ω t = x ∨
        ∃ q : ℚ, 0 ≤ (q : ℝ) ∧ (q : ℝ) ≤ t ∧ walk N start ω (q : ℝ) = x := by
  constructor
  · intro hhit
    have hvisit : ∃ k, position N start ω k = x := by
      by_contra hnever
      have hinf : hittingTime N start ω x = ∞ := by
        rw [hittingTime_eq_discrete N start hpos hnon, discreteHittingTime]
        simp only [not_exists] at hnever
        simp [hnever]
      rw [hinf] at hhit
      exact ENNReal.ofReal_ne_top (top_le_iff.mp hhit)
    let k := Nat.find hvisit
    have hkx : position N start ω k = x := Nat.find_spec hvisit
    have hkt : jumpTime ω k ≤ t := by
      rw [hittingTime_eq_first N start hpos hnon x hvisit] at hhit
      exact (ENNReal.ofReal_le_ofReal_iff ht).mp hhit
    rcases hkt.eq_or_lt with heq | hlt
    · left
      rw [← heq]
      simpa [walk, not_lt.mpr (jumpTime_nonneg ω k), jumpCount_jumpTime hpos] using hkx
    · right
      obtain ⟨q, hql, hqr⟩ := exists_rat_btwn
        (lt_min ((jumpTime_strictMono hpos) (Nat.lt_succ_self k)) hlt)
      have hq0 : 0 ≤ (q : ℝ) := (jumpTime_nonneg ω k).trans hql.le
      refine ⟨q, hq0, (lt_min_iff.mp hqr).2.le, ?_⟩
      simpa [walk, not_lt.mpr hq0,
        jumpCount_eq_of_bounds hpos hql.le (lt_min_iff.mp hqr).1] using hkx
  · rintro (hx | ⟨q, hq0, hqt, hx⟩)
    · exact sInf_le ⟨t, ht, hx, rfl⟩
    · have hhit : hittingTime N start ω x ≤ ENNReal.ofReal (q : ℝ) :=
        sInf_le ⟨(q : ℝ), hq0, hx, rfl⟩
      exact hhit.trans (ENNReal.ofReal_le_ofReal hqt)

def historyCoveredAt (N : Size) (start : Vertex N) (t : ℝ) (ω : WalkSample) : Prop :=
  0 ≤ t ∧ ∀ x : Vertex N, walk N start ω t = x ∨
    ∃ q : ℚ, 0 ≤ (q : ℝ) ∧ (q : ℝ) ≤ t ∧ walk N start ω (q : ℝ) = x

theorem historyCoveredAt_ae_iff (N : Size) (start : Vertex N) (t : ℝ) :
    ∀ᵐ ω ∂walkLaw, historyCoveredAt N start t ω ↔ coveredBy N start ω t := by
  filter_upwards [holding_positive_and_nonexplosive] with ω hω
  by_cases ht : 0 ≤ t
  · simp only [historyCoveredAt, coveredBy, ht, true_and, coverTime, iSup_le_iff]
    exact forall_congr' fun x => (hittingTime_le_time_iff N start hω.1 hω.2 x t ht).symm
  · simp [historyCoveredAt, coveredBy, ht]

theorem historyCoveredAt_measurableSet (N : Size) (start : Vertex N) (t : ℝ)
    (hts : t ≤ observationTime N) :
    @MeasurableSet WalkSample (observationHistory N start) {ω | historyCoveredAt N start t ω} := by
  let : MeasurableSpace WalkSample := observationHistory N start
  by_cases ht : 0 ≤ t
  · have hm (u : ℝ) (hu : 0 ≤ u ∧ u ≤ observationTime N) :
        Measurable (fun ω => walk N start ω u) :=
      (history_walk_measurable N start u hu).mono le_rfl le_top
    simp only [historyCoveredAt, ht, true_and, Set.ofPred_forall]
    apply MeasurableSet.iInter
    intro x
    simp only [Set.ofPred_or, Set.ofPred_exists]
    refine (measurableSet_eq_fun (hm t ⟨ht, hts⟩) measurable_const).union ?_
    apply MeasurableSet.iUnion
    intro q
    by_cases hq : 0 ≤ (q : ℝ) ∧ (q : ℝ) ≤ t
    · simpa only [hq.1, hq.2, true_and] using
        measurableSet_eq_fun (hm (q : ℝ) ⟨hq.1, hq.2.trans hts⟩) measurable_const
    · have he : {ω : WalkSample | 0 ≤ (q : ℝ) ∧ (q : ℝ) ≤ t ∧
          walk N start ω (q : ℝ) = x} = ∅ := by
        ext ω
        simp only [mem_ofPred_eq, mem_empty_iff_false, iff_false]
        exact fun h => hq ⟨h.1, h.2.1⟩
      rw [he]
      exact MeasurableSet.empty
  · simp only [historyCoveredAt, ht, false_and, Set.ofPred_false]
    exact MeasurableSet.empty

def historyKernel (N : Size) (start : Vertex N) (z : ℝ) (ω : WalkSample) : ℝ :=
  if observationTime N ≤ thresholdTime N z then
    (walkLaw {η | setCoverTime N (walk N start ω (observationTime N))
      (historyUnvisited N start ω) η ≤ ENNReal.ofReal (remainingTime N z)}).toReal
  else if historyCoveredAt N start (thresholdTime N z) ω then 1 else 0

theorem historyKernel_measurable (N : Size) (start : Vertex N) (z : ℝ) :
    @Measurable WalkSample ℝ (observationHistory N start) inferInstance (historyKernel N start z) := by
  let : MeasurableSpace WalkSample := observationHistory N start
  unfold historyKernel
  by_cases ht : observationTime N ≤ thresholdTime N z
  · let f : Vertex N × Finset (Vertex N) → ℝ := fun p =>
      (walkLaw {η | setCoverTime N p.1 p.2 η ≤ ENNReal.ofReal (remainingTime N z)}).toReal
    have hp : Measurable (fun ω => (walk N start ω (observationTime N), historyUnvisited N start ω)) :=
      ((history_walk_measurable N start _ ⟨(observationTime_pos N).le, le_rfl⟩).mono le_rfl le_top).prodMk
        (historyUnvisited_measurable N start)
    simpa only [historyKernel, if_pos ht, f, Function.comp_def] using
      (measurable_of_countable f).comp hp
  · simpa only [historyKernel, if_neg ht] using
      (measurable_const.ite (historyCoveredAt_measurableSet N start _ (not_le.mp ht).le)
        measurable_const : Measurable (fun ω =>
          if historyCoveredAt N start (thresholdTime N z) ω then (1 : ℝ) else 0))

theorem historyKernel_ae_eq (N : Size) (start : Vertex N) (z : ℝ) :
    historyKernel N start z =ᵐ[walkLaw] (fun ω => coverageKernel N start ω z) := by
  filter_upwards [historyUnvisited_ae_eq N start,
    historyCoveredAt_ae_iff N start (thresholdTime N z)] with ω hU hc
  simp only [historyKernel, coverageKernel, hU, hc]

theorem coverageKernel_aestronglyMeasurable_history (N : Size) (start : Vertex N) (z : ℝ) :
    AEStronglyMeasurable[observationHistory N start] (fun ω => coverageKernel N start ω z) walkLaw :=
  (historyKernel_measurable N start z).stronglyMeasurable.aestronglyMeasurable.congr
    (historyKernel_ae_eq N start z)

theorem coverageKernel_integrable (N : Size) (start : Vertex N) (z : ℝ) :
    Integrable (fun ω => coverageKernel N start ω z) walkLaw := by
  have hm := (historyKernel_measurable N start z).mono (observationHistory_le N start) le_rfl
  have hae := hm.aestronglyMeasurable.congr (historyKernel_ae_eq N start z)
  apply Integrable.of_bound hae 1
  exact Eventually.of_forall fun ω => by
    rw [Real.norm_eq_abs, abs_of_nonneg (coverageKernel_mem_Icc N start ω z).1]
    exact (coverageKernel_mem_Icc N start ω z).2

theorem conditional_kernel_correct_early (N : Size) (start : Vertex N) (z : ℝ)
    (ht : thresholdTime N z < observationTime N) :
    (fun ω => coverageKernel N start ω z) =ᵐ[walkLaw]
      condExp (observationHistory N start) walkLaw
        (fun ω => if coveredBy N start ω (thresholdTime N z) then (1 : ℝ) else 0) := by
  have he : (fun ω => coverageKernel N start ω z) =
      (fun ω => if coveredBy N start ω (thresholdTime N z) then (1 : ℝ) else 0) := by
    funext ω
    simp only [coverageKernel, if_neg (not_le.mpr ht)]
  rw [← he]
  exact (condExp_of_aestronglyMeasurable' (observationHistory_le N start)
    (coverageKernel_aestronglyMeasurable_history N start z) (coverageKernel_integrable N start z)).symm

end TorusCoverTime.Blocks.A
