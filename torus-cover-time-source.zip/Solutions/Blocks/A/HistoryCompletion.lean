import Solutions.Blocks.A.PathMeasurability
import Mathlib.MeasureTheory.Integral.Bochner.Set

/-! Passing from raw observation history to its null-set completion. -/

noncomputable section
open MeasureTheory Filter
open scoped ENNReal Topology

set_option backward.isDefEq.respectTransparency false

namespace TorusCoverTime.Blocks.A

theorem completedHistory_eq_eventually (N : Size) (start : Vertex N) :
    completedObservationHistory N start =
      eventuallyMeasurableSpace (observationHistory N start) (ae walkLaw) := by
  apply le_antisymm
  · exact MeasurableSpace.generateFrom_le fun _ hs => hs
  · intro s hs
    exact MeasurableSpace.measurableSet_generateFrom hs

theorem history_le_completed (N : Size) (start : Vertex N) :
    observationHistory N start ≤ completedObservationHistory N start := by
  rw [completedHistory_eq_eventually]
  exact le_eventuallyMeasurableSpace

theorem completedHistory_le_null (N : Size) (start : Vertex N)
    (hm : observationHistory N start ≤ (inferInstance : MeasurableSpace WalkSample)) :
    completedObservationHistory N start ≤
      (inferInstance : MeasurableSpace (NullMeasurableSpace WalkSample walkLaw)) := by
  rw [completedHistory_eq_eventually]
  rintro s ⟨t, ht, hst⟩
  exact ⟨t, hm t ht, hst⟩

def forgetCompletion : NullMeasurableSpace WalkSample walkLaw → WalkSample := fun ω => ω

theorem completionId_measurePreserving :
    MeasurePreserving forgetCompletion
      walkLaw.completion walkLaw := by
  have hm : Measurable forgetCompletion := fun _ hs => hs.nullMeasurableSet
  refine ⟨hm, ?_⟩
  ext s hs
  rw [Measure.map_apply hm hs]
  rfl

theorem completion_integrable {f : WalkSample → ℝ} (hf : Integrable f walkLaw) :
    Integrable (f ∘ forgetCompletion) walkLaw.completion :=
  completionId_measurePreserving.integrable_comp_of_integrable hf

theorem completion_integral {f : WalkSample → ℝ} (hf : Integrable f walkLaw) :
    ∫ ω, f (forgetCompletion ω) ∂walkLaw.completion = ∫ ω, f ω ∂walkLaw := by
  have hm := completionId_measurePreserving
  have hi := integral_map hm.measurable.aemeasurable
    (show AEStronglyMeasurable f (Measure.map forgetCompletion walkLaw.completion) by
      rw [hm.map_eq]; exact hf.aestronglyMeasurable)
  simpa only [hm.map_eq] using hi.symm

theorem completion_setIntegral {f : WalkSample → ℝ} (hf : Integrable f walkLaw)
    {s : Set WalkSample} (hs : MeasurableSet s) :
    ∫ ω in forgetCompletion ⁻¹' s, f (forgetCompletion ω) ∂walkLaw.completion =
      ∫ ω in s, f ω ∂walkLaw := by
  rw [← integral_indicator (completionId_measurePreserving.measurable hs),
    ← integral_indicator hs]
  exact completion_integral (hf.indicator hs)

theorem condExp_completedHistory (N : Size) (start : Vertex N)
    (hm : observationHistory N start ≤ (inferInstance : MeasurableSpace WalkSample))
    (f : WalkSample → ℝ) (hf : Integrable f walkLaw) :
    condExp (observationHistory N start) walkLaw f =ᵐ[walkLaw]
      condExp (completedObservationHistory N start) walkLaw.completion f := by
  let : IsProbabilityMeasure walkLaw.completion := ⟨by
    change walkLaw Set.univ = 1
    exact measure_univ⟩
  have hg : Integrable (condExp (observationHistory N start) walkLaw f) walkLaw :=
    integrable_condExp
  apply ae_eq_condExp_of_forall_setIntegral_eq (completedHistory_le_null N start hm)
    (completion_integrable hf)
  · exact fun _ _ _ => (completion_integrable hg).integrableOn
  · intro s hs _
    rw [completedHistory_eq_eventually] at hs
    obtain ⟨t, ht, hst⟩ := hs
    calc
      _ = ∫ x in t, (condExp (observationHistory N start) walkLaw f) x ∂walkLaw.completion :=
        setIntegral_congr_set (μ := walkLaw.completion) hst
      _ = ∫ x in t, (condExp (observationHistory N start) walkLaw f) x ∂walkLaw :=
        completion_setIntegral hg (hm t ht)
      _ = ∫ x in t, f x ∂walkLaw := setIntegral_condExp hm hf ht
      _ = ∫ x in t, f x ∂walkLaw.completion := (completion_setIntegral hf (hm t ht)).symm
      _ = _ := (setIntegral_congr_set (μ := walkLaw.completion) (f := f) hst).symm
  · exact (stronglyMeasurable_condExp.mono (history_le_completed N start)).aestronglyMeasurable

open Classical in
theorem coverageIndicator_integrable (N : Size) (start : Vertex N) (t : ℝ) :
    Integrable (fun ω => if coveredBy N start ω t then (1 : ℝ) else 0) walkLaw := by
  classical
  have hs : NullMeasurableSet {ω | coveredBy N start ω t} walkLaw := by
    by_cases ht : 0 ≤ t
    · simpa only [coveredBy, ht, true_and] using
        nullMeasurableSet_le (coverTime_aemeasurable N start) aemeasurable_const
    · simp only [coveredBy, ht, false_and, Set.ofPred_false]
      exact nullMeasurableSet_empty
  exact (integrable_const (1 : ℝ)).indicator₀ hs

theorem history_completion_bridge (_hWalk : WalkModelRegular)
    (hKernel : ConditionalKernelCorrect) : HistoryCompletionBridge := by
  intro N start
  have hm := (hKernel N start).1
  refine ⟨history_le_completed N start, completedHistory_le_null N start hm,
    condExp_completedHistory N start hm, ?_⟩
  intro z
  exact ((hKernel N start).2 z).trans
    (condExp_completedHistory N start hm _
      (coverageIndicator_integrable N start (thresholdTime N z)))

end TorusCoverTime.Blocks.A
