import Solutions.Blocks.A.Nonexplosion

/-! Independent finite direction blocks occur almost surely. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter
open scoped ENNReal Topology

namespace TorusCoverTime.Blocks.A

def directionLaw : Measure (Fin 4) := uniformOn Set.univ
instance directionLaw_probability : IsProbabilityMeasure directionLaw := by
  unfold directionLaw
  infer_instance

def directionSequence (ω : WalkSample) : ℕ → Fin 4 := fun j => (ω j).2

theorem directionSequence_map :
    walkLaw.map directionSequence = Measure.infinitePi (fun _ : ℕ => directionLaw) := by
  have h := Measure.infinitePi_map_pi (fun _ : ℕ => stepLaw)
    (f := fun _ => Prod.snd) (fun _ => measurable_snd)
  change (Measure.infinitePi (fun _ : ℕ => stepLaw)).map (fun ω j => (ω j).2) = _
  simpa [stepLaw, directionLaw] using h

def directionBlock (k n : ℕ) (ω : WalkSample) : Fin k → Fin 4 :=
  fun j => (ω (n * k + j.val)).2

def directionBlockLaw (k : ℕ) : Measure (Fin k → Fin 4) :=
  Measure.infinitePi (fun _ : Fin k => directionLaw)

instance directionBlockLaw_probability (k : ℕ) : IsProbabilityMeasure (directionBlockLaw k) := by
  unfold directionBlockLaw
  infer_instance

theorem blockIndex_injective (k : ℕ) :
    Function.Injective (fun p : ℕ × Fin k => p.1 * k + p.2.val) := by
  intro p q hpq
  have hk : 0 < k := p.2.pos
  have he (r : ℕ × Fin k) : (r.1 * k + r.2.val) / k = r.1 := by
    rw [Nat.mul_comm r.1 k, Nat.mul_add_div hk]
    simp [Nat.div_eq_of_lt r.2.isLt]
  have hfst : p.1 = q.1 := by
    simpa only [he] using congrArg (fun x => x / k) hpq
  have hsnd : p.2 = q.2 := by
    apply Fin.ext
    simpa only [hfst, Nat.add_left_cancel_iff] using hpq
  exact Prod.ext hfst hsnd

theorem directionBlock_map (k : ℕ) :
    walkLaw.map (fun ω n => directionBlock k n ω) =
      Measure.infinitePi (fun _ : ℕ => directionBlockLaw k) := by
  let reindex : (ℕ → Fin 4) → (ℕ × Fin k → Fin 4) :=
    fun ω p => ω (p.1 * k + p.2.val)
  have hmap : (Measure.infinitePi (fun _ : ℕ => directionLaw)).map reindex =
      Measure.infinitePi (fun _ : ℕ × Fin k => directionLaw) :=
    Measure.map_infinitePi_infinitePi_of_inj (blockIndex_injective k)
  have hcur := Measure.infinitePi_map_curry (fun (_ : ℕ) (_ : Fin k) => directionLaw)
  change walkLaw.map ((MeasurableEquiv.curry ℕ (Fin k) (Fin 4)) ∘
    (reindex ∘ directionSequence)) = _
  rw [← Measure.map_map (by fun_prop) (by unfold reindex directionSequence; fun_prop),
    ← Measure.map_map (by unfold reindex; fun_prop) (by unfold directionSequence; fun_prop),
    directionSequence_map, hmap]
  exact hcur

theorem directionBlockLaw_singleton_pos (k : ℕ) (w : Fin k → Fin 4) :
    0 < directionBlockLaw k {w} := by
  rw [directionBlockLaw, Measure.infinitePi_singleton, tprod_fintype]
  rw [pos_iff_ne_zero, Finset.prod_ne_zero_iff]
  intro j _
  rw [directionLaw, Ne, uniformOn_eq_zero_iff (Set.toFinite _)]
  simp

theorem iid_hits_singleton {X : Type*} [MeasurableSpace X] [MeasurableSingletonClass X]
    (μ : Measure X) [IsProbabilityMeasure μ] (x : X) (hx : 0 < μ {x}) :
    ∀ᵐ ω ∂Measure.infinitePi (fun _ : ℕ => μ), ∃ n : ℕ, ω n = x := by
  classical
  let ν := Measure.infinitePi (fun _ : ℕ => μ)
  let φ : X → ℝ := Set.indicator {x} (fun _ => 1)
  have hφ : Measurable φ := measurable_const.indicator (measurableSet_singleton x)
  have hi : Integrable φ μ := (integrable_const (1 : ℝ)).indicator (measurableSet_singleton x)
  let Y : ℕ → (ℕ → X) → ℝ := fun n ω => φ (ω n)
  have hY (n : ℕ) : IdentDistrib (Y n) φ ν μ := by
    refine ⟨(hφ.comp (measurable_pi_apply n)).aemeasurable, hφ.aemeasurable, ?_⟩
    change ν.map (φ ∘ (fun ω => ω n)) = μ.map φ
    rw [← Measure.map_map hφ (measurable_pi_apply n), Measure.infinitePi_map_eval]
  have hident (n : ℕ) : IdentDistrib (Y n) (Y 0) ν ν := (hY n).trans (hY 0).symm
  have hind : iIndepFun Y ν := iIndepFun_infinitePi (fun _ => hφ)
  have hmean : ∫ ω, Y 0 ω ∂ν = (μ {x}).toReal := by
    rw [(hY 0).integral_eq]
    dsimp only [φ]
    rw [integral_indicator_const _ (measurableSet_singleton x)]
    simp only [smul_eq_mul, mul_one, measureReal_def]
  have hLLN := strong_law_ae_real Y ((hY 0).symm.integrable_snd hi)
    (fun _ _ h => hind.indepFun h) hident
  filter_upwards [hLLN] with ω hω
  by_contra hn
  have hzero : ∀ n, Y n ω = 0 := by
    intro n
    simp only [not_exists] at hn
    simp [Y, φ, hn n]
  have hlim : Tendsto (fun n : ℕ => (∑ i ∈ Finset.range n, Y i ω) / n) atTop (𝓝 0) := by
    simpa only [hzero, Finset.sum_const_zero, zero_div] using
      (tendsto_const_nhds : Tendsto (fun _ : ℕ => (0 : ℝ)) atTop (𝓝 0))
  have heq := tendsto_nhds_unique hω hlim
  rw [hmean] at heq
  exact (ENNReal.toReal_pos hx.ne' (measure_ne_top μ _)).ne' heq

theorem directionBlock_occurs (k : ℕ) (w : Fin k → Fin 4) :
    ∀ᵐ ω ∂walkLaw, ∃ n : ℕ, directionBlock k n ω = w := by
  apply ae_of_ae_map (μ := walkLaw) (f := fun ω n => directionBlock k n ω)
    (p := fun y : ℕ → (Fin k → Fin 4) => ∃ n, y n = w)
    ((measurable_pi_lambda _ fun n => measurable_pi_lambda _ fun j =>
      (measurable_pi_apply (n * k + j.val)).snd).aemeasurable)
  rw [directionBlock_map]
  exact iid_hits_singleton (directionBlockLaw k) w (directionBlockLaw_singleton_pos k w)

end TorusCoverTime.Blocks.A
