import Solutions.Core.WalkMeasurability
import Mathlib.Probability.StrongLaw
import Mathlib.Probability.Independence.InfinitePi

/-! The concrete exponential product law has positive, nonexplosive holding times.
The proof uses bounded truncation, so no moment formula for the exponential law is needed. -/

noncomputable section
open MeasureTheory ProbabilityTheory Filter
open scoped Topology ENNReal

namespace TorusCoverTime.Blocks.A

theorem rawHolding_measurePreserving (j : ℕ) :
    MeasurePreserving (fun ω : WalkSample => (ω j).1) walkLaw holdingLaw := by
  exact measurePreserving_fst.comp (measurePreserving_eval_infinitePi (fun _ : ℕ => stepLaw) j)

theorem holdingLaw_pos : ∀ᵐ x ∂holdingLaw, 0 < x := by
  have hc : (holdingLaw (Set.Iic 0)).toReal = 0 := by
    have h : cdf holdingLaw 0 = 0 := by
      simpa [holdingLaw] using (cdf_expMeasure_eq (by norm_num : (0 : ℝ) < 1) 0)
    simpa only [cdf_eq_real, measureReal_def] using h
  have hz : holdingLaw (Set.Iic 0) = 0 :=
    (ENNReal.toReal_eq_zero_iff _).mp hc |>.resolve_right (measure_ne_top _ _)
  rw [ae_iff]
  simpa only [not_lt, Set.Iic_def] using hz

theorem rawHolding_pos (j : ℕ) : ∀ᵐ ω ∂walkLaw, 0 < (ω j).1 := by
  apply MeasureTheory.ae_of_ae_map (rawHolding_measurePreserving j).measurable.aemeasurable
  rw [(rawHolding_measurePreserving j).map_eq]
  exact holdingLaw_pos

theorem all_rawHolding_pos : ∀ᵐ ω ∂walkLaw, ∀ j, 0 < (ω j).1 :=
  ae_all_iff.mpr rawHolding_pos

def cappedHolding (j : ℕ) (ω : WalkSample) : ℝ := min (holdingTime ω j) 1

theorem cappedHolding_measurable (j : ℕ) : Measurable (cappedHolding j) := by
  unfold cappedHolding holdingTime
  fun_prop

theorem cappedHolding_nonneg (j : ℕ) (ω : WalkSample) : 0 ≤ cappedHolding j ω := by
  exact le_min (le_max_right _ _) zero_le_one

theorem cappedHolding_integrable (j : ℕ) : Integrable (cappedHolding j) walkLaw := by
  apply Integrable.of_bound (cappedHolding_measurable j).aestronglyMeasurable 1
  exact Eventually.of_forall fun ω => by
    rw [Real.norm_eq_abs, abs_of_nonneg (cappedHolding_nonneg j ω)]
    exact min_le_right _ _

theorem cappedHolding_identDistrib (j : ℕ) :
    IdentDistrib (cappedHolding j) (cappedHolding 0) walkLaw walkLaw := by
  have hraw : IdentDistrib (fun ω : WalkSample => (ω j).1)
      (fun ω : WalkSample => (ω 0).1) walkLaw walkLaw :=
    ⟨(rawHolding_measurePreserving j).measurable.aemeasurable,
      (rawHolding_measurePreserving 0).measurable.aemeasurable,
      (rawHolding_measurePreserving j).map_eq.trans (rawHolding_measurePreserving 0).map_eq.symm⟩
  exact hraw.comp (u := fun x : ℝ => min (max x 0) 1) (by fun_prop)

theorem cappedHolding_iIndepFun : iIndepFun cappedHolding walkLaw := by
  exact iIndepFun_infinitePi (P := fun _ : ℕ => stepLaw)
    (X := fun _ x => min (max x.1 0) (1 : ℝ)) (by intro i; fun_prop)

theorem cappedHolding_integral_pos : 0 < ∫ ω, cappedHolding 0 ω ∂walkLaw := by
  have hnonneg : 0 ≤ ∫ ω, cappedHolding 0 ω ∂walkLaw :=
    integral_nonneg (cappedHolding_nonneg 0)
  by_contra hpos
  have hz := (integral_eq_zero_iff_of_nonneg (cappedHolding_nonneg 0)
    (cappedHolding_integrable 0)).mp (le_antisymm (not_lt.mp hpos) hnonneg)
  obtain ⟨ω, hω, hzero⟩ := ((rawHolding_pos 0).and hz).exists
  have hp : 0 < cappedHolding 0 ω :=
    lt_min (hω.trans_le (le_max_left _ _)) zero_lt_one
  exact (ne_of_gt hp) hzero

theorem jumpTime_tendsto_atTop : ∀ᵐ ω ∂walkLaw, Tendsto (jumpTime ω) atTop atTop := by
  have hLLN := strong_law_ae_real cappedHolding (cappedHolding_integrable 0)
    (fun _ _ hij => cappedHolding_iIndepFun.indepFun hij) cappedHolding_identDistrib
  filter_upwards [hLLN] with ω hω
  have hsum : Tendsto (fun n : ℕ => ∑ i ∈ Finset.range n, cappedHolding i ω) atTop atTop := by
    have h := hω.pos_mul_atTop cappedHolding_integral_pos tendsto_natCast_atTop_atTop
    convert h using 1
    funext n
    by_cases hn : n = 0
    · simp [hn]
    · rw [div_mul_cancel₀ _ (Nat.cast_ne_zero.mpr hn)]
  exact tendsto_atTop_mono (fun n =>
    Finset.sum_le_sum fun i _ => min_le_left (holdingTime ω i) 1) hsum

theorem holding_positive_and_nonexplosive :
    ∀ᵐ ω ∂walkLaw, (∀ j, 0 < (ω j).1) ∧ Tendsto (jumpTime ω) atTop atTop :=
  all_rawHolding_pos.and jumpTime_tendsto_atTop

end TorusCoverTime.Blocks.A
