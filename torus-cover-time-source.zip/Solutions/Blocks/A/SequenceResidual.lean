import Solutions.Blocks.A.SequenceSplit

/-! Memorylessness for a holding time together with all subsequent directions and steps. -/

noncomputable section
open MeasureTheory ProbabilityTheory Set
open scoped ENNReal

set_option backward.isDefEq.respectTransparency false

namespace TorusCoverTime.Blocks.A

def headTail (ω : WalkSample) : (ℝ × Fin 4) × WalkSample :=
  (ω 0, fun j => ω (j + 1))

def consSequence (q : (ℝ × Fin 4) × WalkSample) : WalkSample
  | 0 => q.1
  | j + 1 => q.2 j

theorem headTail_measurable : Measurable headTail := by unfold headTail; fun_prop

theorem consSequence_measurable : Measurable consSequence := by
  apply measurable_pi_lambda
  intro j
  cases j with
  | zero => exact measurable_fst
  | succ j => exact (measurable_pi_apply j).comp measurable_snd

@[simp] theorem consSequence_headTail (ω : WalkSample) : consSequence (headTail ω) = ω := by
  funext j
  cases j <;> rfl

@[simp] theorem headTail_consSequence (q : (ℝ × Fin 4) × WalkSample) :
    headTail (consSequence q) = q := rfl

theorem headTail_map : walkLaw.map headTail = stepLaw.prod walkLaw := by
  have hi := disjoint_coordinate_families_independent (fun _ : Unit => 0)
    (fun j : ℕ => j + 1) (by
      rw [Set.disjoint_left]
      rintro k ⟨i, rfl⟩ ⟨j, hj⟩
      dsimp only at hj
      omega)
  have hi' := hi.comp (measurable_pi_apply ()) measurable_id
  change IndepFun (fun ω : WalkSample => ω 0) (fun ω j => ω (j + 1)) walkLaw at hi'
  change walkLaw.map (fun ω => (ω 0, fun j => ω (j + 1))) = _
  rw [hi'.map_prod_eq_prod_map_map (measurable_pi_apply 0).aemeasurable
    (show Measurable (fun ω : WalkSample => fun j => ω (j + 1)) by fun_prop).aemeasurable]
  congr 1
  · exact Measure.infinitePi_map_eval (fun _ => stepLaw) 0
  · exact Measure.map_infinitePi_infinitePi_of_inj (P := fun _ => stepLaw)
      (fun _ _ h => Nat.add_right_cancel h)

theorem consSequence_measurePreserving :
    MeasurePreserving consSequence (stepLaw.prod walkLaw) walkLaw := by
  refine ⟨consSequence_measurable, ?_⟩
  rw [← headTail_map, Measure.map_map consSequence_measurable headTail_measurable]
  simp only [Function.comp_def, consSequence_headTail, Measure.map_id']

def delayHead (r : ℝ) (ω : WalkSample) : WalkSample :=
  consSequence (stepDelay r (ω 0), fun j => ω (j + 1))

theorem delayHead_measurable (r : ℝ) : Measurable (delayHead r) :=
  consSequence_measurable.comp (((stepDelay_measurable r).comp (measurable_pi_apply 0)).prodMk
    (measurable_pi_lambda _ fun j => measurable_pi_apply (j + 1)))

theorem walkLaw_restrict_first_above (r : ℝ) (hr : 0 ≤ r) :
    walkLaw.restrict {ω | r < (ω 0).1} =
      ENNReal.ofReal (Real.exp (-r)) • walkLaw.map (delayHead r) := by
  have hs : consSequence ⁻¹' {ω : WalkSample | r < (ω 0).1} =
      {q : ℝ × Fin 4 | r < q.1} ×ˢ (univ : Set WalkSample) := by
    ext q
    simp [consSequence]
  have hset : MeasurableSet {ω : WalkSample | r < (ω 0).1} :=
    measurableSet_lt measurable_const (measurable_pi_apply 0).fst
  have hmap : (stepLaw.map (stepDelay r)).prod walkLaw =
      (stepLaw.prod walkLaw).map (Prod.map (stepDelay r) id) := by
    simpa only [Measure.map_id, Measure.map_id'] using
      Measure.map_prod_map stepLaw walkLaw (stepDelay_measurable r) measurable_id
  calc
    _ = ((stepLaw.restrict {q | r < q.1}).prod walkLaw).map consSequence := by
      conv_lhs => rw [← consSequence_measurePreserving.map_eq]
      rw [Measure.restrict_map consSequence_measurable hset, hs,
        ← Measure.restrict_prod_eq_prod_univ]
    _ = ENNReal.ofReal (Real.exp (-r)) •
        ((stepLaw.map (stepDelay r)).prod walkLaw).map consSequence := by
      rw [stepLaw_restrict_above r hr, Measure.prod_smul_left, Measure.map_smul]
    _ = ENNReal.ofReal (Real.exp (-r)) • walkLaw.map (delayHead r) := by
      rw [hmap, Measure.map_map consSequence_measurable
        ((stepDelay_measurable r).prodMap measurable_id)]
      conv_rhs => rw [← consSequence_measurePreserving.map_eq,
        Measure.map_map (delayHead_measurable r) consSequence_measurable]
      rfl

theorem lintegral_restrict_first_above (r : ℝ) (hr : 0 ≤ r)
    {f : WalkSample → ℝ≥0∞} (hf : Measurable f) :
    ∫⁻ ω in {ω | r < (ω 0).1}, f ω ∂walkLaw =
      ENNReal.ofReal (Real.exp (-r)) * ∫⁻ ω, f (delayHead r ω) ∂walkLaw := by
  rw [walkLaw_restrict_first_above r hr, lintegral_smul_measure,
    lintegral_map hf (delayHead_measurable r), smul_eq_mul]

end TorusCoverTime.Blocks.A
