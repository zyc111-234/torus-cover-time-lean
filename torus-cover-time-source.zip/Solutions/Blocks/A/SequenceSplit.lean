import Solutions.Blocks.A.Memoryless
import Mathlib.Probability.Independence.InfinitePi

/-! Independent finite prefixes and infinite tails of the sample sequence. -/

noncomputable section
open MeasureTheory ProbabilityTheory Set
open scoped ENNReal

set_option backward.isDefEq.respectTransparency false

namespace TorusCoverTime.Blocks.A

abbrev WalkPrefix (n : ℕ) := Fin n → ℝ × Fin 4

def prefixLaw (n : ℕ) : Measure (WalkPrefix n) :=
  Measure.infinitePi (fun _ => stepLaw)

instance (n : ℕ) : IsProbabilityMeasure (prefixLaw n) := by
  unfold prefixLaw
  infer_instance

def splitSequence (n : ℕ) (ω : WalkSample) : WalkPrefix n × WalkSample :=
  (fun j => ω j.val, fun j => ω (n + j))

def joinSequence (n : ℕ) (p : WalkPrefix n) (η : WalkSample) : WalkSample :=
  fun j => if h : j < n then p ⟨j, h⟩ else η (j - n)

theorem splitSequence_measurable (n : ℕ) : Measurable (splitSequence n) := by
  unfold splitSequence
  fun_prop

theorem joinSequence_measurable (n : ℕ) :
    Measurable (fun q : WalkPrefix n × WalkSample => joinSequence n q.1 q.2) := by
  apply measurable_pi_lambda
  intro j
  by_cases hj : j < n
  · simpa only [joinSequence, dif_pos hj, Function.comp_def] using
      (measurable_pi_apply (⟨j, hj⟩ : Fin n)).comp measurable_fst
  · simpa only [joinSequence, dif_neg hj, Function.comp_def] using
      (measurable_pi_apply (j - n)).comp measurable_snd

@[simp] theorem joinSequence_split (n : ℕ) (ω : WalkSample) :
    joinSequence n (splitSequence n ω).1 (splitSequence n ω).2 = ω := by
  funext j
  by_cases hj : j < n
  · simp [joinSequence, splitSequence, hj]
  · simp [joinSequence, splitSequence, hj, Nat.add_sub_of_le (Nat.le_of_not_gt hj)]

@[simp] theorem splitSequence_join (n : ℕ) (p : WalkPrefix n) (η : WalkSample) :
    splitSequence n (joinSequence n p η) = (p, η) := by
  ext j : 2
  · simp [splitSequence, joinSequence]
  · simp [splitSequence, joinSequence]

theorem disjoint_coordinate_families_independent {I J : Type*} (f : I → ℕ) (g : J → ℕ)
    (hfg : Disjoint (range f) (range g)) :
    IndepFun (fun ω : WalkSample => fun i => ω (f i))
      (fun ω : WalkSample => fun j => ω (g j)) walkLaw := by
  let M (k : ℕ) := MeasurableSpace.comap (fun ω : WalkSample => ω k) inferInstance
  have hind : iIndep M walkLaw :=
    iIndepFun_infinitePi (X := fun _ x => x) (fun _ => measurable_id)
  have hab := indep_iSup_of_disjoint
    (fun k => (measurable_pi_apply k).comap_le) hind hfg
  have hleft : MeasurableSpace.comap (fun ω : WalkSample => fun i => ω (f i)) inferInstance ≤
      ⨆ k ∈ range f, M k := by
    simp only [MeasurableSpace.pi, MeasurableSpace.comap_iSup,
      MeasurableSpace.comap_comp, Function.comp_def]
    exact iSup_le fun i => le_iSup_of_le (f i) (le_iSup_of_le ⟨i, rfl⟩ le_rfl)
  have hright : MeasurableSpace.comap (fun ω : WalkSample => fun j => ω (g j)) inferInstance ≤
      ⨆ k ∈ range g, M k := by
    simp only [MeasurableSpace.pi, MeasurableSpace.comap_iSup,
      MeasurableSpace.comap_comp, Function.comp_def]
    exact iSup_le fun j => le_iSup_of_le (g j) (le_iSup_of_le ⟨j, rfl⟩ le_rfl)
  exact fun s t hs ht => hab s t (hleft s hs) (hright t ht)

theorem splitSequence_map (n : ℕ) :
    walkLaw.map (splitSequence n) = (prefixLaw n).prod walkLaw := by
  have hi := disjoint_coordinate_families_independent (fun i : Fin n => i.val)
    (fun j : ℕ => n + j) (by
      rw [Set.disjoint_left]
      rintro k ⟨i, rfl⟩ ⟨j, hj⟩
      dsimp only at hj
      have := i.isLt
      omega)
  change walkLaw.map (fun ω => ((fun i : Fin n => ω i.val), fun j => ω (n + j))) = _
  rw [hi.map_prod_eq_prod_map_map
    (show Measurable (fun ω : WalkSample => fun i : Fin n => ω i.val) by fun_prop).aemeasurable
    (show Measurable (fun ω : WalkSample => fun j => ω (n + j)) by fun_prop).aemeasurable]
  congr 1
  · exact Measure.map_infinitePi_infinitePi_of_inj (P := fun _ => stepLaw) Fin.val_injective
  · exact Measure.map_infinitePi_infinitePi_of_inj (P := fun _ => stepLaw)
      (fun _ _ h => Nat.add_left_cancel h)

theorem joinSequence_measurePreserving (n : ℕ) :
    MeasurePreserving (fun q : WalkPrefix n × WalkSample => joinSequence n q.1 q.2)
      ((prefixLaw n).prod walkLaw) walkLaw := by
  refine ⟨joinSequence_measurable n, ?_⟩
  rw [← splitSequence_map n, Measure.map_map (joinSequence_measurable n)
    (splitSequence_measurable n)]
  simp only [Function.comp_def, joinSequence_split, Measure.map_id']

def sequenceEquiv (n : ℕ) : WalkSample ≃ᵐ WalkPrefix n × WalkSample where
  toFun := splitSequence n
  invFun := fun q => joinSequence n q.1 q.2
  left_inv := joinSequence_split n
  right_inv := fun q => splitSequence_join n q.1 q.2
  measurable_toFun := splitSequence_measurable n
  measurable_invFun := joinSequence_measurable n

end TorusCoverTime.Blocks.A
