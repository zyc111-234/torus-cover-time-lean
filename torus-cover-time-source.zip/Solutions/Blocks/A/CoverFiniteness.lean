import Solutions.Blocks.A.FiniteWords
import Mathlib.Data.List.OfFn

/-! A finite direction tour, combined with independent word occurrence, gives finite cover time. -/

noncomputable section
open MeasureTheory Filter
open scoped ENNReal Topology

namespace TorusCoverTime.Blocks.A

def wordDisplacement (N : Size) (w : List (Fin 4)) : Vertex N := (w.map (direction N)).sum

@[simp] theorem wordDisplacement_append (N : Size) (p q : List (Fin 4)) :
    wordDisplacement N (p ++ q) = wordDisplacement N p + wordDisplacement N q := by
  simp [wordDisplacement]

def wordTo (N : Size) (x : Vertex N) : List (Fin 4) :=
  List.replicate x.1.val 0 ++ List.replicate x.2.val 2

@[simp] theorem wordTo_displacement (N : Size) (x : Vertex N) :
    wordDisplacement N (wordTo N x) = x := by
  ext <;> simp [wordDisplacement, wordTo, direction, nsmul_eq_mul]

theorem exists_covering_loop (N : Size) (S : Finset (Vertex N)) :
    ∃ w : List (Fin 4), wordDisplacement N w = 0 ∧
      ∀ x ∈ S, ∃ p q : List (Fin 4), w = p ++ q ∧ wordDisplacement N p = x := by
  classical
  induction S using Finset.induction_on with
  | empty => exact ⟨[], by simp [wordDisplacement], by simp⟩
  | @insert x S _ ih =>
      obtain ⟨w, hw0, hw⟩ := ih
      refine ⟨(wordTo N x ++ wordTo N (-x)) ++ w, by simp [hw0], ?_⟩
      intro y hy
      rcases Finset.mem_insert.mp hy with rfl | hy
      · exact ⟨wordTo N y, wordTo N (-y) ++ w, List.append_assoc _ _ _, wordTo_displacement N y⟩
      · obtain ⟨p, q, hpq, hp⟩ := hw y hy
        refine ⟨(wordTo N x ++ wordTo N (-x)) ++ p, q, ?_, by simp [hp]⟩
        simp only [hpq, List.append_assoc]

theorem position_after_prefix (N : Size) (start : Vertex N) (ω : WalkSample)
    (w p q : List (Fin 4)) (hw : w = p ++ q) (n : ℕ)
    (hblock : directionBlock w.length n ω = fun j => w[j.val]) :
    position N start ω (n * w.length + p.length) =
      position N start ω (n * w.length) + wordDisplacement N p := by
  have hsum : (∑ i ∈ Finset.range p.length, direction N (ω (n * w.length + i)).2) =
      wordDisplacement N p := by
    rw [← Fin.sum_univ_eq_sum_range (fun i => direction N (ω (n * w.length + i)).2)]
    have hp : p = List.ofFn (fun i : Fin p.length => p[i.val]) := (List.ofFn_get p).symm
    conv_rhs => rw [wordDisplacement, hp, List.map_ofFn, List.sum_ofFn]
    apply Finset.sum_congr rfl
    intro i _
    have hiw : i.val < w.length := by simp only [hw, List.length_append]; omega
    have heq := congrFun hblock ⟨i.val, hiw⟩
    change (ω (n * w.length + i.val)).2 = w[i.val] at heq
    rw [heq]
    congr 1
    simp [hw, List.getElem_append_left i.isLt]
  simp only [position, Finset.sum_range_add, hsum, add_assoc]

theorem coverTime_ne_top (N : Size) (start : Vertex N) :
    ∀ᵐ ω ∂walkLaw, coverTime N start ω ≠ ∞ := by
  classical
  obtain ⟨w, _, hw⟩ := exists_covering_loop N Finset.univ
  have hocc := directionBlock_occurs w.length (fun j => w[j.val])
  filter_upwards [all_rawHolding_pos, hocc] with ω hpos hω
  obtain ⟨n, hn⟩ := hω
  have hfinite (x : Vertex N) : hittingTime N start ω x < ∞ := by
    obtain ⟨p, q, hpq, hp⟩ := hw (x - position N start ω (n * w.length)) (Finset.mem_univ _)
    let k := n * w.length + p.length
    have hpx : position N start ω k = x := by
      rw [position_after_prefix N start ω w p q hpq n hn, hp]
      exact add_sub_cancel _ _
    have hhit : hittingTime N start ω x ≤ ENNReal.ofReal (jumpTime ω k) := by
      apply sInf_le
      refine ⟨jumpTime ω k, jumpTime_nonneg ω k, ?_, rfl⟩
      simpa [walk, not_lt.mpr (jumpTime_nonneg ω k), jumpCount_jumpTime hpos] using hpx
    exact hhit.trans_lt ENNReal.ofReal_lt_top
  exact iSup_ne_top (fun x => (hfinite x).ne)

end TorusCoverTime.Blocks.A
