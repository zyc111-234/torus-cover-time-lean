import Solutions.Blocks.A.PathMeasurability

/-! A countable history-measurable version of the selector, using rational observations
and the observation endpoint. These proofs do not assume a Markov property. -/

noncomputable section
open MeasureTheory Filter
open scoped ENNReal Topology

namespace TorusCoverTime.Blocks.A

theorem jumpCount_eq_of_bounds {ω : WalkSample} (hpos : ∀ j, 0 < (ω j).1)
    {t : ℝ} {k : ℕ} (hleft : jumpTime ω k ≤ t) (hright : t < jumpTime ω (k + 1)) :
    jumpCount ω t = k := by
  have hex : ∃ j, t < jumpTime ω (j + 1) := ⟨k, hright⟩
  rw [jumpCount, dif_pos hex]
  refine (Nat.find_eq_iff hex).2 ⟨hright, ?_⟩
  intro j hj
  exact not_lt_of_ge (((jumpTime_strictMono hpos).monotone (Nat.succ_le_of_lt hj)).trans hleft)

theorem hittingTime_eq_first (N : Size) (start : Vertex N) {ω : WalkSample}
    (hpos : ∀ j, 0 < (ω j).1) (hnon : Tendsto (jumpTime ω) atTop atTop)
    (x : Vertex N) (hvisit : ∃ k, position N start ω k = x) :
    hittingTime N start ω x = ENNReal.ofReal (jumpTime ω (Nat.find hvisit)) := by
  classical
  rw [hittingTime_eq_discrete N start hpos hnon, discreteHittingTime]
  apply le_antisymm
  · exact iInf_le_of_le (Nat.find hvisit) (by simp [Nat.find_spec hvisit])
  · refine le_iInf fun j => ?_
    split_ifs with hj
    · exact ENNReal.ofReal_le_ofReal ((jumpTime_strictMono hpos).monotone (Nat.find_le hj))
    · exact le_top

def RationalObservation (N : Size) :=
  {q : ℚ // 0 ≤ (q : ℝ) ∧ (q : ℝ) ≤ observationTime N}

instance (N : Size) : Countable (RationalObservation N) := inferInstanceAs (Countable (Subtype _))

theorem hittingTime_le_observation_iff (N : Size) (start : Vertex N) {ω : WalkSample}
    (hpos : ∀ j, 0 < (ω j).1) (hnon : Tendsto (jumpTime ω) atTop atTop) (x : Vertex N) :
    hittingTime N start ω x ≤ ENNReal.ofReal (observationTime N) ↔
      walk N start ω (observationTime N) = x ∨
        ∃ q : RationalObservation N, walk N start ω (q.val : ℝ) = x := by
  classical
  constructor
  · intro hhit
    have hvisit : ∃ k, position N start ω k = x := by
      by_contra hnever
      have hinf : hittingTime N start ω x = ∞ := by
        rw [hittingTime_eq_discrete N start hpos hnon, discreteHittingTime]
        simp only [not_exists] at hnever
        simp [hnever]
      rw [hinf] at hhit
      exact (ENNReal.ofReal_ne_top) (top_le_iff.mp hhit)
    let k := Nat.find hvisit
    have hkx : position N start ω k = x := Nat.find_spec hvisit
    have hks : jumpTime ω k ≤ observationTime N := by
      rw [hittingTime_eq_first N start hpos hnon x hvisit] at hhit
      exact (ENNReal.ofReal_le_ofReal_iff (observationTime_pos N).le).mp hhit
    rcases hks.eq_or_lt with heq | hlt
    · left
      rw [← heq]
      simpa [walk, not_lt.mpr (jumpTime_nonneg ω k), jumpCount_jumpTime hpos] using hkx
    · right
      obtain ⟨q, hqleft, hqright⟩ := exists_rat_btwn
        (lt_min ((jumpTime_strictMono hpos) (Nat.lt_succ_self k)) hlt)
      have hq0 : 0 ≤ (q : ℝ) := (jumpTime_nonneg ω k).trans hqleft.le
      refine ⟨⟨q, hq0, (lt_min_iff.mp hqright).2.le⟩, ?_⟩
      simpa [walk, not_lt.mpr hq0,
        jumpCount_eq_of_bounds hpos hqleft.le (lt_min_iff.mp hqright).1] using hkx
  · rintro (hx | ⟨q, hx⟩)
    · exact sInf_le ⟨observationTime N, (observationTime_pos N).le, hx, rfl⟩
    · have hq : hittingTime N start ω x ≤ ENNReal.ofReal (q.val : ℝ) :=
        sInf_le ⟨(q.val : ℝ), q.property.1, hx, rfl⟩
      exact hq.trans (ENNReal.ofReal_le_ofReal q.property.2)

theorem history_walk_measurable (N : Size) (start : Vertex N) (t : ℝ)
    (ht : 0 ≤ t ∧ t ≤ observationTime N) :
    @Measurable WalkSample (Vertex N) (observationHistory N start) ⊤
      (fun ω => walk N start ω t) := by
  apply Measurable.of_comap_le
  exact le_iSup (fun u : {u : ℝ // 0 ≤ u ∧ u ≤ observationTime N} =>
    MeasurableSpace.comap (fun ω => walk N start ω u.val) ⊤) ⟨t, ht⟩

def historyUnvisited (N : Size) (start : Vertex N) (ω : WalkSample) : Finset (Vertex N) := by
  classical
  exact Finset.univ.filter fun x =>
    walk N start ω (observationTime N) ≠ x ∧
      ∀ q : RationalObservation N, walk N start ω (q.val : ℝ) ≠ x

theorem historyUnvisited_measurable (N : Size) (start : Vertex N) :
    @Measurable WalkSample (Finset (Vertex N)) (observationHistory N start) inferInstance
      (historyUnvisited N start) := by
  classical
  let : MeasurableSpace WalkSample := observationHistory N start
  have hm (t : ℝ) (ht : 0 ≤ t ∧ t ≤ observationTime N) :
      Measurable (fun ω => walk N start ω t) :=
    (history_walk_measurable N start t ht).mono le_rfl le_top
  apply measurable_finset_iff.2
  intro x
  apply measurableSet_setOfPred.mp
  simp only [historyUnvisited, Finset.mem_filter, Finset.mem_univ, true_and,
    Set.ofPred_and, Set.ofPred_forall]
  refine MeasurableSet.inter ?_ (MeasurableSet.iInter fun q => ?_)
  · exact (measurableSet_eq_fun (hm _ ⟨(observationTime_pos N).le, le_rfl⟩) measurable_const).compl
  · exact (measurableSet_eq_fun (hm _ q.property) measurable_const).compl

theorem historyUnvisited_ae_eq (N : Size) (start : Vertex N) :
    historyUnvisited N start =ᵐ[walkLaw] unvisited N start := by
  classical
  filter_upwards [holding_positive_and_nonexplosive] with ω hω
  ext x
  simp only [historyUnvisited, unvisited, Finset.mem_filter, Finset.mem_univ, true_and]
  rw [← not_le, hittingTime_le_observation_iff N start hω.1 hω.2 x]
  simp

theorem selector_history_measurable (_hWalk : WalkModelRegular) : SelectorHistoryMeasurable := by
  intro N start
  refine ⟨fun ω => selectorFromSet N (historyUnvisited N start ω),
    (measurable_of_countable (selectorFromSet N)).comp (historyUnvisited_measurable N start), ?_⟩
  filter_upwards [historyUnvisited_ae_eq N start] with ω hω
  change selectorFromSet N (historyUnvisited N start ω) = selectorFromSet N (unvisited N start ω)
  rw [hω]

end TorusCoverTime.Blocks.A
