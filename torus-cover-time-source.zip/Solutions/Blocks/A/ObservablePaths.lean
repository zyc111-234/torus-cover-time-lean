import Solutions.Blocks.A.HistoryMeasurability

/-! The raw observation sigma algebra is contained in the product sample sigma algebra. -/

noncomputable section
open MeasureTheory Filter
open scoped ENNReal Topology

namespace TorusCoverTime.Blocks.A

theorem jumpCount_measurable (t : ℝ) : Measurable (fun ω => jumpCount ω t) := by
  classical
  let p (ω : WalkSample) (k : ℕ) : Prop :=
    t < jumpTime ω (k + 1) ∨ ¬ ∃ j, t < jumpTime ω (j + 1)
  have hp : ∀ ω, ∃ k, p ω k := by
    intro ω
    by_cases h : ∃ k, t < jumpTime ω (k + 1)
    · obtain ⟨k, hk⟩ := h
      exact ⟨k, Or.inl hk⟩
    · exact ⟨0, Or.inr h⟩
  have hm : ∀ k, MeasurableSet {ω | p ω k} := by
    intro k
    change MeasurableSet ({ω | t < jumpTime ω (k + 1)} ∪
      {ω | ∃ j, t < jumpTime ω (j + 1)}ᶜ)
    refine (measurableSet_lt measurable_const (measurable_jumpTime _)).union ?_
    apply MeasurableSet.compl
    simp only [Set.ofPred_exists]
    exact MeasurableSet.iUnion fun j => measurableSet_lt measurable_const (measurable_jumpTime _)
  convert measurable_find hp hm using 1
  funext ω
  by_cases h : ∃ k, t < jumpTime ω (k + 1)
  · rw [jumpCount, dif_pos h]
    exact Nat.find_congr' (by intro n; simp only [p, h, not_true_eq_false, or_false])
  · rw [jumpCount, dif_neg h]
    symm
    exact (Nat.find_eq_iff (hp ω)).2 ⟨Or.inr h, by intro n hn; omega⟩

theorem position_measurable (N : Size) (start : Vertex N) (k : ℕ) :
    Measurable (fun ω => position N start ω k) := by
  let dirs := fun ω : WalkSample => fun j : Fin k => (ω j.val).2
  have hdirs : Measurable dirs :=
    measurable_pi_lambda _ fun j => (measurable_pi_apply j.val).snd
  let p := fun d : Fin k → Fin 4 => start + ∑ j : Fin k, direction N (d j)
  convert (measurable_of_countable p).comp hdirs using 1
  funext ω
  simp only [p, dirs, Function.comp_apply, position]
  rw [Fin.sum_univ_eq_sum_range (fun j => direction N (ω j).2)]

theorem walk_measurable (N : Size) (start : Vertex N) (t : ℝ) :
    Measurable (fun ω => walk N start ω t) := by
  by_cases ht : t < 0
  · simpa only [walk, ht, if_true] using (measurable_const : Measurable (fun _ : WalkSample => start))
  · have hpos : Measurable (fun p : WalkSample × ℕ => position N start p.1 p.2) :=
      measurable_from_prod_countable_left (position_measurable N start)
    simpa only [walk, ht, if_false, Function.comp_def, id_eq] using
      hpos.comp (measurable_id.prodMk (jumpCount_measurable t))

theorem observationHistory_le (N : Size) (start : Vertex N) :
    observationHistory N start ≤ (inferInstance : MeasurableSpace WalkSample) := by
  apply iSup_le
  intro t
  have htop : (inferInstance : MeasurableSpace (Vertex N)) = ⊤ :=
    top_unique (fun s _ => s.toFinite.measurableSet)
  rw [← htop]
  exact (walk_measurable N start t.val).comap_le

end TorusCoverTime.Blocks.A
