import Solutions.Blocks.A.SequenceResidual
import Solutions.Blocks.A.KernelHistory

/-! Joining a finite past to a fresh future at a deterministic observation time. -/

noncomputable section
open MeasureTheory Filter Set
open scoped ENNReal Topology

namespace TorusCoverTime.Blocks.A

@[simp] theorem joinSequence_before (n : ℕ) (p : WalkPrefix n) (η : WalkSample) (j : Fin n) :
    joinSequence n p η j.val = p j := by simp [joinSequence]

@[simp] theorem joinSequence_after (n : ℕ) (p : WalkPrefix n) (η : WalkSample) (j : ℕ) :
    joinSequence n p η (n + j) = η j := by simp [joinSequence]

def prefixTime (n : ℕ) (p : WalkPrefix n) : ℝ := ∑ j : Fin n, max (p j).1 0

def prefixPosition (N : Size) (start : Vertex N) (n : ℕ) (p : WalkPrefix n) : Vertex N :=
  start + ∑ j : Fin n, direction N (p j).2

theorem prefixTime_nonneg (n : ℕ) (p : WalkPrefix n) : 0 ≤ prefixTime n p :=
  Finset.sum_nonneg fun _ _ => le_max_right _ _

theorem prefixTime_measurable (n : ℕ) : Measurable (prefixTime n) := by
  unfold prefixTime
  fun_prop

theorem jumpTime_join_prefix (n : ℕ) (p : WalkPrefix n) (η : WalkSample) :
    jumpTime (joinSequence n p η) n = prefixTime n p := by
  rw [jumpTime, ← Fin.sum_univ_eq_sum_range]
  simp only [holdingTime, joinSequence_before, prefixTime]

theorem jumpTime_join_add (n : ℕ) (p : WalkPrefix n) (η : WalkSample) (k : ℕ) :
    jumpTime (joinSequence n p η) (n + k) = prefixTime n p + jumpTime η k := by
  rw [jumpTime, Finset.sum_range_add]
  change jumpTime (joinSequence n p η) n + _ = _
  rw [jumpTime_join_prefix]
  simp only [holdingTime, joinSequence_after, jumpTime]

theorem position_join_prefix (N : Size) (start : Vertex N) (n : ℕ)
    (p : WalkPrefix n) (η : WalkSample) :
    position N start (joinSequence n p η) n = prefixPosition N start n p := by
  rw [position, ← Fin.sum_univ_eq_sum_range]
  simp only [joinSequence_before, prefixPosition]

theorem position_join_add (N : Size) (start : Vertex N) (n : ℕ)
    (p : WalkPrefix n) (η : WalkSample) (k : ℕ) :
    position N start (joinSequence n p η) (n + k) =
      position N (prefixPosition N start n p) η k := by
  simp only [position, Finset.sum_range_add, joinSequence_after]
  rw [← add_assoc]
  congr 1
  exact position_join_prefix N start n p η

@[simp] theorem delayHead_direction (r : ℝ) (η : WalkSample) (j : ℕ) :
    (delayHead r η j).2 = (η j).2 := by cases j <;> rfl

theorem delayHead_pos (r : ℝ) (hr : 0 ≤ r) {η : WalkSample} (hη : ∀ j, 0 < (η j).1) :
    ∀ j, 0 < (delayHead r η j).1 := by
  intro j
  cases j with
  | zero => exact add_pos_of_pos_of_nonneg (hη 0) hr
  | succ j => exact hη (j + 1)

theorem jumpTime_delayHead_succ (r : ℝ) (hr : 0 ≤ r) {η : WalkSample}
    (hη : ∀ j, 0 < (η j).1) (k : ℕ) :
    jumpTime (delayHead r η) (k + 1) = r + jumpTime η (k + 1) := by
  induction k with
  | zero =>
      simp [jumpTime, holdingTime, delayHead, consSequence, stepDelay,
        max_eq_left (hη 0).le, add_comm]
      exact add_nonneg hr (hη 0).le
  | succ k ih =>
      simp only [jumpTime, Finset.sum_range_succ] at ih ⊢
      change (_ + holdingTime (delayHead r η) k) + holdingTime η (k + 1) = _
      rw [ih, add_assoc]

def glueAt (n : ℕ) (p : WalkPrefix n) (s : ℝ) (η : WalkSample) : WalkSample :=
  joinSequence n p (delayHead (s - prefixTime n p) η)

theorem glueAt_measurable (n : ℕ) (s : ℝ) :
    Measurable (fun q : WalkPrefix n × WalkSample => glueAt n q.1 s q.2) := by
  apply measurable_pi_lambda
  intro j
  by_cases hj : j < n
  · simpa only [glueAt, joinSequence, dif_pos hj, Function.comp_def] using
      (measurable_pi_apply (⟨j, hj⟩ : Fin n)).comp measurable_fst
  · simp only [glueAt, joinSequence, dif_neg hj, delayHead]
    cases h : j - n with
    | zero =>
        simp only [consSequence, stepDelay]
        exact (((measurable_pi_apply 0).comp measurable_snd).fst.add
          (measurable_const.sub ((prefixTime_measurable n).comp measurable_fst))).prodMk
            ((measurable_pi_apply 0).comp measurable_snd).snd
    | succ k => exact (measurable_pi_apply (k + 1)).comp measurable_snd

theorem glueAt_pos (n : ℕ) {p : WalkPrefix n} (hp : ∀ j, 0 < (p j).1)
    (s : ℝ) (hs : prefixTime n p ≤ s) {η : WalkSample} (hη : ∀ j, 0 < (η j).1) :
    ∀ j, 0 < (glueAt n p s η j).1 := by
  intro j
  by_cases hj : j < n
  · simpa only [glueAt, joinSequence, dif_pos hj] using hp ⟨j, hj⟩
  · simpa only [glueAt, joinSequence, dif_neg hj] using
      delayHead_pos _ (sub_nonneg.mpr hs) hη (j - n)

theorem jumpTime_glueAt_succ (n : ℕ) (p : WalkPrefix n) (s : ℝ)
    (hs : prefixTime n p ≤ s) {η : WalkSample} (hη : ∀ j, 0 < (η j).1) (k : ℕ) :
    jumpTime (glueAt n p s η) (n + (k + 1)) = s + jumpTime η (k + 1) := by
  rw [glueAt, jumpTime_join_add, jumpTime_delayHead_succ _ (sub_nonneg.mpr hs) hη]
  ring

theorem glueAt_nonexplosive (n : ℕ) (p : WalkPrefix n) (s : ℝ)
    (hs : prefixTime n p ≤ s) {η : WalkSample} (hη : ∀ j, 0 < (η j).1)
    (hnon : Tendsto (jumpTime η) atTop atTop) :
    Tendsto (jumpTime (glueAt n p s η)) atTop atTop := by
  apply (tendsto_add_atTop_iff_nat (n + 1)).mp
  apply tendsto_atTop_mono (fun k => ?_) (hnon.comp (tendsto_add_atTop_nat 1))
  change jumpTime η (k + 1) ≤ jumpTime (glueAt n p s η) (k + (n + 1))
  rw [show k + (n + 1) = n + (k + 1) by omega, jumpTime_glueAt_succ n p s hs hη]
  exact le_add_of_nonneg_left ((prefixTime_nonneg n p).trans hs)

end TorusCoverTime.Blocks.A
