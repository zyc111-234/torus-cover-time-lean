import Solutions.Blocks.A.PathRestart

/-! Coverage after observation is exactly coverage of the remaining vertices by the fresh walk. -/

noncomputable section
open MeasureTheory Filter Set
open scoped ENNReal Topology
open Classical

namespace TorusCoverTime.Blocks.A

def regularSample : WalkSample := holding_positive_and_nonexplosive.exists.choose

theorem regularSample_spec : (∀ j, 0 < (regularSample j).1) ∧
    Tendsto (jumpTime regularSample) atTop atTop := holding_positive_and_nonexplosive.exists.choose_spec

theorem historyUnvisited_eq_of_regular (N : Size) (start : Vertex N) {ω : WalkSample}
    (hpos : ∀ j, 0 < (ω j).1) (hnon : Tendsto (jumpTime ω) atTop atTop) :
    historyUnvisited N start ω = unvisited N start ω := by
  ext x
  simp only [historyUnvisited, unvisited, Finset.mem_filter, Finset.mem_univ, true_and]
  rw [← not_le, hittingTime_le_observation_iff N start hpos hnon x]
  simp

theorem historyUnvisited_congr (N : Size) (start : Vertex N) {ω η : WalkSample}
    (h : ∀ t : ℝ, 0 ≤ t ∧ t ≤ observationTime N → walk N start ω t = walk N start η t) :
    historyUnvisited N start ω = historyUnvisited N start η := by
  have hq (q : RationalObservation N) := h (q.val : ℝ) q.property
  simp only [historyUnvisited, h (observationTime N) ⟨(observationTime_pos N).le, le_rfl⟩, hq]

theorem unvisited_glueAt_eq (N : Size) (start : Vertex N) (n : ℕ) {p : WalkPrefix n}
    (hp : ∀ j, 0 < (p j).1) (hs : prefixTime n p ≤ observationTime N)
    {η : WalkSample} (hη : ∀ j, 0 < (η j).1) (hnon : Tendsto (jumpTime η) atTop atTop) :
    unvisited N start (glueAt n p (observationTime N) η) =
      unvisited N start (glueAt n p (observationTime N) regularSample) := by
  rw [← historyUnvisited_eq_of_regular N start (glueAt_pos n hp _ hs hη)
    (glueAt_nonexplosive n p _ hs hη hnon),
    ← historyUnvisited_eq_of_regular N start (glueAt_pos n hp _ hs regularSample_spec.1)
    (glueAt_nonexplosive n p _ hs regularSample_spec.1 regularSample_spec.2)]
  exact historyUnvisited_congr N start
    (glueAt_history_eq N start n hp _ hs hη regularSample_spec.1 hnon)

theorem hittingTime_le_iff_exists_time (N : Size) (start : Vertex N) {ω : WalkSample}
    (hpos : ∀ j, 0 < (ω j).1) (hnon : Tendsto (jumpTime ω) atTop atTop)
    (x : Vertex N) (t : ℝ) (ht : 0 ≤ t) :
    hittingTime N start ω x ≤ ENNReal.ofReal t ↔
      ∃ v : ℝ, 0 ≤ v ∧ v ≤ t ∧ walk N start ω v = x := by
  constructor
  · intro hhit
    rcases (hittingTime_le_time_iff N start hpos hnon x t ht).mp hhit with hx | ⟨q, hq⟩
    · exact ⟨t, ht, le_rfl, hx⟩
    · exact ⟨(q : ℝ), hq⟩
  · rintro ⟨v, hv0, hvt, hx⟩
    have hh : hittingTime N start ω x ≤ ENNReal.ofReal v := sInf_le ⟨v, hv0, hx, rfl⟩
    exact hh.trans (ENNReal.ofReal_le_ofReal hvt)

theorem coverage_glueAt_iff (N : Size) (start : Vertex N) (n : ℕ) {p : WalkPrefix n}
    (hp : ∀ j, 0 < (p j).1) (hs : prefixTime n p ≤ observationTime N)
    {η : WalkSample} (hη : ∀ j, 0 < (η j).1) (hnon : Tendsto (jumpTime η) atTop atTop)
    (u : ℝ) (hu : 0 ≤ u) :
    coveredBy N start (glueAt n p (observationTime N) η) (observationTime N + u) ↔
      setCoverTime N (prefixPosition N start n p)
        (unvisited N start (glueAt n p (observationTime N) regularSample)) η ≤ ENNReal.ofReal u := by
  let ω := glueAt n p (observationTime N) η
  have hωpos := glueAt_pos n hp (observationTime N) hs hη
  have hωnon := glueAt_nonexplosive n p (observationTime N) hs hη hnon
  have hU := unvisited_glueAt_eq N start n hp hs hη hnon
  rw [← hU]
  change coveredBy N start ω (observationTime N + u) ↔
    setCoverTime N (prefixPosition N start n p) (unvisited N start ω) η ≤ ENNReal.ofReal u
  have hsu : 0 ≤ observationTime N + u := add_nonneg (observationTime_pos N).le hu
  simp only [coveredBy, hsu, true_and, coverTime, setCoverTime, iSup_le_iff]
  constructor
  · intro hc x hx
    obtain ⟨v, hv0, hvu, hvx⟩ :=
      (hittingTime_le_iff_exists_time N start hωpos hωnon x _ hsu).mp (hc x)
    have hv : observationTime N < v := by
      have hx' : ENNReal.ofReal (observationTime N) < hittingTime N start ω x := by
        simpa only [unvisited, Finset.mem_filter, Finset.mem_univ, true_and] using hx
      by_contra hv
      have hh : hittingTime N start ω x ≤ ENNReal.ofReal v := sInf_le ⟨v, hv0, hvx, rfl⟩
      exact not_lt_of_ge (hh.trans (ENNReal.ofReal_le_ofReal (not_lt.mp hv))) hx'
    apply (hittingTime_le_iff_exists_time N _ hη hnon x u hu).mpr
    refine ⟨v - observationTime N, sub_nonneg.mpr hv.le, by linarith, ?_⟩
    have hw := walk_glueAt_future N start n hp (observationTime N) hs hη hnon
      (v - observationTime N) (sub_nonneg.mpr hv.le)
    rw [add_sub_cancel] at hw
    exact hw.symm.trans hvx
  · intro hc x
    by_cases hx : x ∈ unvisited N start ω
    · obtain ⟨v, hv0, hvu, hvx⟩ :=
        (hittingTime_le_iff_exists_time N _ hη hnon x u hu).mp (hc x hx)
      apply (hittingTime_le_iff_exists_time N start hωpos hωnon x _ hsu).mpr
      refine ⟨observationTime N + v, add_nonneg (observationTime_pos N).le hv0, by linarith, ?_⟩
      exact (walk_glueAt_future N start n hp (observationTime N) hs hη hnon v hv0).trans hvx
    · have hh : hittingTime N start ω x ≤ ENNReal.ofReal (observationTime N) := by
        simpa only [unvisited, Finset.mem_filter, Finset.mem_univ, true_and, not_lt] using hx
      exact hh.trans (ENNReal.ofReal_le_ofReal (by linarith))

def measurableCoveredAt (N : Size) (start : Vertex N) (t : ℝ) (ω : WalkSample) : Prop :=
  0 ≤ t ∧ ∀ x : Vertex N, discreteHittingTime N start ω x ≤ ENNReal.ofReal t

theorem measurableCoveredAt_measurableSet (N : Size) (start : Vertex N) (t : ℝ) :
    MeasurableSet {ω | measurableCoveredAt N start t ω} := by
  simp only [measurableCoveredAt, Set.ofPred_and, Set.ofPred_forall]
  exact MeasurableSet.inter (MeasurableSet.const _) (MeasurableSet.iInter fun x =>
    measurableSet_le (measurable_discreteHittingTime N start x) measurable_const)

theorem measurableCoveredAt_iff (N : Size) (start : Vertex N) (t : ℝ) {ω : WalkSample}
    (hpos : ∀ j, 0 < (ω j).1) (hnon : Tendsto (jumpTime ω) atTop atTop) :
    measurableCoveredAt N start t ω ↔ coveredBy N start ω t := by
  simp only [measurableCoveredAt, coveredBy, coverTime, iSup_le_iff,
    hittingTime_eq_discrete N start hpos hnon]

theorem measurableCoveredAt_ae_iff (N : Size) (start : Vertex N) (t : ℝ) :
    ∀ᵐ ω ∂walkLaw, measurableCoveredAt N start t ω ↔ coveredBy N start ω t := by
  filter_upwards [holding_positive_and_nonexplosive] with ω hω
  exact measurableCoveredAt_iff N start t hω.1 hω.2

theorem historyKernel_glueAt_late (N : Size) (start : Vertex N) (n : ℕ) {p : WalkPrefix n}
    (hp : ∀ j, 0 < (p j).1) (hs : prefixTime n p ≤ observationTime N)
    {η : WalkSample} (hη : ∀ j, 0 < (η j).1) (hnon : Tendsto (jumpTime η) atTop atTop)
    (z : ℝ) (hz : observationTime N ≤ thresholdTime N z) :
    historyKernel N start z (glueAt n p (observationTime N) η) =
      (walkLaw {ξ | setCoverTime N (prefixPosition N start n p)
        (unvisited N start (glueAt n p (observationTime N) regularSample)) ξ ≤
          ENNReal.ofReal (remainingTime N z)}).toReal := by
  rw [historyKernel, if_pos hz,
    historyUnvisited_eq_of_regular N start (glueAt_pos n hp _ hs hη)
      (glueAt_nonexplosive n p _ hs hη hnon),
    unvisited_glueAt_eq N start n hp hs hη hnon,
    walk_glueAt_observation N start n hp _ hs hη hnon]

end TorusCoverTime.Blocks.A
